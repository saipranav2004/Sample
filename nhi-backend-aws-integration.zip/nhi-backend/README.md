# NHI Backend API — merged build

A hardened merge of the two candidate backends, validated against
`AWS-NHI Updated API.pdf` and against a real PostgreSQL instance.

**Base:** the `read.txt` tree — chosen because the tenant/account/region boundary is
enforced in one place (`internal/scope`), not re-implemented per endpoint.
**Harvested from:** the `b1.txt` tree — richer detail-tab payloads, concurrent dashboard
loading, and strict `time_range` handling, all re-expressed on top of the scoped base.

```
go build ./...            # clean
go vet ./...              # clean
go test ./...             # clean (also under -race)
```

---

## Tenant architecture

Three tiers, exactly as the document specifies:

```
nhi_global (config: global_database)
  └── nhi_schema.tenants     tenant_id (uuid) → db_name
  └── nhi_schema.nhi_users   email, bcrypt hash, role, tenant_id, status, last_login_at

nhi_tenant_<name>  (opened on demand, name comes from the JWT — never from config)
  └── nhi_scanner.*          identities, credentials, trust_edges, user_settings, …
```

**One choke point.** Every data request resolves through `scope.Resolver.Resolve()`,
which returns a `DataScope` carrying the tenant's pool *and* the effective
`AccountIDs / Regions / ScanID`:

```go
resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
// every repository entry point takes the scope, never a bare *sql.DB
rows, err := s.repo.List(ctx, resolved, filter)
// DataScope.Predicates("i") → i.scan_id = $1 AND i.account_id = ANY($2) AND i.region = ANY($3)
```

Because the repositories cannot be called without a `DataScope`, steps 3–7 of the
document's "Every Data API" flow are structurally impossible to skip.
`user_settings` appears in exactly one non-test file in the repository.

**No fallback.** `Manager.Tenant("")` returns `ErrTenantDBNotConfigured`. A tenant with no
`db_name` is an error, never a silent switch to another database.

---

## What changed relative to the two inputs

### Correctness / security

| Change | Why |
|---|---|
| **Scoped graph traversal** (`internal/repository/v1/graph_scope.go`) | A graph BFS cannot be constrained by a SQL predicate: hop 2 walks out of the selected accounts. The traversal now prunes every hop against the caller's account/region before expanding the frontier, and fails closed on unparseable ARNs. |
| **`relationships` tab enabled** on both detail endpoints | It was implemented but gated off in `read.txt` ("disabled until graph scope is enforced") and enabled-but-unscoped in `b1.txt`. It is now both enabled and safe — 6/6 tabs per the document. |
| **De-duplicated BFS edges** | Found against the live database: `loadEdgesTouching` matches `source = ANY(frontier) OR target = ANY(frontier)`, so an edge was re-emitted on every hop that touched it. A depth-2 walk reported the same edge twice. |
| **Consolidated `errScopeRequired` sentinel** | Four repositories each built their own `fmt.Errorf("tenant scope is required")`, so callers could not use `errors.Is`. |
| **`page_size` capped at 100**, **`depth` bounded to 1–3** | The document's stated limits were not enforced; `depth` accepted any value and `page_size` was unbounded. |
| **Strict `?time_range=`** (ported from `b1.txt`) | `"banana"` used to silently become 90 days. It is now a 400 with an actionable message, and the response echoes a canonical label rather than raw client input. |
| **Dead legacy code removed** | 301 → 43 Go files. Removed the unrouted dashboard/inventory/credential-exposure packages, which also cleared a genuine `go vet` failure (`fmt.Sprintf` arity bug in `shared_credentials_repo.go`). |
| **`migrations/tenant/001` creates its schema** | It assumed `nhi_scanner` already existed and failed on a fresh tenant database. |

### Performance

**Concurrent dashboard overview.** The four independent loaders (KPIs, identity charts,
credential charts, growth charts) now run in parallel with first-error cancellation of the
remaining queries, instead of sequentially. They write disjoint fields of the response
struct, verified under `-race`.

### Tests

Unit coverage for the parts where a mistake is a tenant-isolation bug:

| Package | Covers |
|---|---|
| `internal/repository/v1` | ARN account/region parsing, scope allow/deny including fail-closed, edge pruning, frontier never leaving scope, BFS de-duplication |
| `internal/scope` | `Predicates()` / `QueryArgs()` shape, empty-scope safety |
| `internal/database` | Identifier quoting, `Tenant()` has no fallback, validation rejects injection attempts |
| `internal/config` | Rejects a tenant `database_name` in config, unsafe schema identifiers, weak JWT secret, out-of-range expiry |
| `pkg/jwt` | Claim round-trip, tamper rejection, wrong-secret rejection, weak-secret rejection |
| `internal/routes` | All seven data endpoints return 401 without a token; 404/405 always return JSON |

---

## Running it locally

```bash
# 1. Postgres, then seed two tenants in two databases
export PGHOST=127.0.0.1 PGPORT=5432 PGUSER=postgres
./scripts/seed_two_tenants.sh

# 2. Point configs/config.yaml at that Postgres and run
NHI_CONFIG_FILE=configs/config.yaml go run ./cmd/api-server

# 3. Verify the tenant guarantees end to end
./scripts/e2e_tenant_scope.sh          # 16 assertions
```

`scripts/test_schema.sql` is a stand-in for the scanner's schema, which this repository
does not own. It is only for local verification — column names were derived from the
queries in `internal/repository/v1`, so treat it as a harness, not as the real schema.

### Endpoints

| # | Endpoint | Notes |
|---|---|---|
| — | `POST /api/v1/login`, `/api/auth/login` | bcrypt; rejects `status != 'active'`; updates `last_login_at` |
| 1a | `GET /api/v1/settings` | `user_settings` → `accounts.is_default` → latest completed scan |
| 1b | `PUT /api/v1/settings` | upsert; JWT is unchanged |
| 2 | `GET /api/v1/filters` | all dropdown options |
| 3 | `GET /api/v1/dashboard/overview` | KPIs + 13 charts, loaded concurrently |
| 4 | `GET /api/v1/identities` | paginated (max 100), searchable, filterable, sortable |
| 5 | `GET /api/v1/identities/{id}?tab=` | overview, permissions, activity, relationships, credentials, raw |
| 6 | `GET /api/v1/credentials` | |
| 7 | `GET /api/v1/credentials/{id}?tab=` | overview, trust, activity, rotation, relationships, raw |
| 8 | `GET /api/v1/integrations/aws` | AWS connection status; setup values (admin only) |
| 9 | `POST /api/v1/integrations/aws/verify` | run the three connection checks (admin only) |

---

## AWS account connection (Integrations page)

A client connects their AWS account by hand in the console: a read-only
cross-account role, and an EventBridge rule forwarding CloudTrail events to our
central bus. The dashboard shows the values to copy and a **Verify** button.

### Endpoints

**`GET /api/v1/integrations/aws`** — any signed-in user.

```json
{ "success": true, "data": {
  "status": "not_connected | action_needed | connected",
  "can_manage": true,
  "setup": {                                   // null unless can_manage (admin)
    "account_id": "123456789012", "external_id": "ext-…24 hex…",
    "event_bus_arn": "arn:aws:events:ap-south-1:123456789012:event-bus/nhi-central-bus",
    "region": "ap-south-1",
    "assumer_role_arn": "arn:aws:iam::123456789012:role/NHIPlatformAssumer",
    "role_name": "NHIPlatformCollector", "rule_name": "nhi-forward-events",
    "managed_policies": ["SecurityAudit", "ViewOnlyAccess"],
    "event_sources": ["aws.ec2", "aws.ecs", "aws.iam", "aws.sts", "aws.lambda", "aws.eks", "aws.secretsmanager", "aws.kms"]
  },
  "accounts": [{ "account_id", "role_arn", "status", "checks": [...], "last_verified_at", "last_verified_by", "connected_at" }]
}}
```

The tenant's External ID is generated on the first admin read and never changes.

**`POST /api/v1/integrations/aws/verify`** `{"role_arn": "arn:aws:iam::<client>:role/NHIPlatformCollector"}` — admin only.

| # | Check | Fails → fix shown |
|---|---|---|
| 1 | `sts:AssumeRole` with the ARN + tenant External ID | "Check the External ID matches" |
| 2 | `iam:ListRoles` (one item) with the assumed role | "Attach SecurityAudit + ViewOnlyAccess" |
| 3 | an event from that account reached the central bus | "Check the EventBridge rule target ARN" |

Each check is `pass`, `fail` (client must change something; `fix` says what),
`skipped` (an earlier check failed) or `error` (our side; logged, "try again").
All three pass → the account is `connected`. A failed check is still HTTP 200.

* Nothing is stored and no bus permission is granted until check 1 passes —
  only then has the tenant proved it controls the account.
* After check 1, the API adds `nhi-client-<account>` to the central bus policy
  (`events:PutPermission`, idempotent). This is "Step 3" — the client never sees it.
* One AWS account belongs to one tenant (unique index) → `409 AWS_ACCOUNT_IN_USE`.
* One verification per tenant at a time → `429 AWS_VERIFY_IN_PROGRESS`.
* Bad ARN (role name only, instance profile, user, our own account) → `400 INVALID_ROLE_ARN` with a readable message.
* Whole run is capped at 12s (server write timeout is 15s).

### One-time platform setup

1. Apply `migrations/global/002_aws_integration.sql` to the global DB and fill
   the single row of `nhi_schema.aws_platform_settings` (example in the file).
   Until then the endpoints answer `503 AWS_PLATFORM_NOT_CONFIGURED`.
2. Run the API as `NHIPlatformAssumer` (task role / instance profile), or set
   `aws_integration.assume_assumer_role: true` to assume it from the process identity.
   That role needs:
   ```json
   { "Effect": "Allow", "Action": "sts:AssumeRole", "Resource": "arn:aws:iam::*:role/NHIPlatformCollector" },
   { "Effect": "Allow", "Action": ["events:DescribeEventBus", "events:PutPermission"],
     "Resource": "arn:aws:events:ap-south-1:<ours>:event-bus/nhi-central-bus" },
   { "Effect": "Allow", "Action": "logs:FilterLogEvents",
     "Resource": "arn:aws:logs:ap-south-1:<ours>:log-group:/aws/events/nhi-central-bus:*" }
   ```
3. For check 3: on `nhi-central-bus`, add a rule matching every event
   (`{"account": [{"exists": true}]}`) with a CloudWatch Logs target
   `/aws/events/nhi-central-bus` (set a retention, e.g. 7 days), and put that name in
   `aws_integration.event_log_group`. The check runs
   `FilterLogEvents { $.account = "<client>" }` over `event_lookback_hours` (default 24).
   To check another store instead (e.g. your ingestion DB), implement
   `HasEventsFrom` in `internal/awsconnect` — the service depends only on that interface.

**`config.yaml` does not give the API any AWS access.** It only says how to use
the access the machine already has. Where that access comes from:

| Where the API runs | AWS access comes from | `assume_assumer_role` |
|---|---|---|
| ECS / EC2 / EKS (production) | The role attached to the task or instance - automatic, no keys | `false` |
| Your laptop | An AWS CLI profile you create once (below) | `true` |

Running it on your laptop (Windows PowerShell shown):

```powershell
aws configure --profile nhi-platform        # or: aws configure sso --profile nhi-platform
$env:AWS_PROFILE = "nhi-platform"
aws sts get-caller-identity                 # must show the platform account
go run .\cmd\api-server                    # same window, so it sees AWS_PROFILE
```

That identity must be allowed to assume `NHIPlatformAssumer`. Never put AWS keys
in `config.yaml`, and do not set `AWS_EC2_METADATA_DISABLED` on EC2.

Config / env: `aws_integration.assume_assumer_role` (`NHI_AWS_ASSUME_ASSUMER_ROLE`),
`event_log_group` (`NHI_AWS_EVENT_LOG_GROUP`), `event_lookback_hours` (`NHI_AWS_EVENT_LOOKBACK_HOURS`).

Scale note: an EventBridge bus policy is limited to ~10 KB, roughly 50 client
statements. Past that, request a quota increase or move to a policy that allows
any account and validate `account` against `tenant_aws_accounts` at ingestion.

### Tests

```
go test ./internal/awsconnect/ ./internal/services/v1/ ./internal/handlers/v1/
NHI_TEST_GLOBAL_DSN='postgres://…/nhi_global?sslmode=disable' go test ./internal/repository/
```
`awsconnect` tests run the real SDK against a fake AWS endpoint (request shapes,
assumed-credential hand-off, error classification).

---

## Known gaps

- **Endpoint 7 `trust` / `rotation` payloads** are thinner than endpoint 5's.
  `b1.txt` had richer bodies; porting them is mechanical (same
  `(ctx, resolved, id)` signature) but was not completed here.
- **`start_date` / `end_date`** — the document lists a `custom` value for
  `time_range`. `ResolveTimeRange` supports rolling windows only; adding fixed
  windows means threading start/end into the activity repositories.
- **`resources` in the graph** is not account-scoped at the SQL level (the pruning
  in `traverseGraph` still applies, so nothing leaks — it just costs one query).
- **`scripts/test_schema.sql`** is a local harness, not the production schema.
