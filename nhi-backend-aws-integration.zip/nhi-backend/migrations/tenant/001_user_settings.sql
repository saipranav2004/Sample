-- Apply this migration separately to every tenant data database.
-- user_id is the canonical email from the JWT's user_id claim. The database
-- itself is the tenant boundary; do not put this table in the global DB.
BEGIN;

-- The scanner schema is created by the discovery pipeline, but this migration
-- is often the first thing applied to a fresh tenant database, so create it
-- here too. Idempotent, and it makes the migration runnable standalone.
CREATE SCHEMA IF NOT EXISTS nhi_scanner;

CREATE TABLE IF NOT EXISTS nhi_scanner.user_settings (
    user_id                text PRIMARY KEY,
    selected_account_ids   jsonb NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(selected_account_ids) = 'array'),
    selected_regions       jsonb NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(selected_regions) = 'array'),
    selected_scan_id       text,
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now()
);

COMMIT;
