#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# Seed a local Postgres with TWO tenants in TWO separate databases, so the
# tenant isolation guarantees can actually be verified rather than assumed.
#
#   Tenant A  nhi_tenant_a   accounts 111…, 222…, 333…   (defaults: 111…)
#   Tenant B  nhi_tenant_b   account  999…
#
# The trust graph in tenant A deliberately crosses out of the default account
# selection:
#
#   web-1 (111…) ──assume_role──▶ api-1 (111…) ──assume_role──▶ secret-1 (333…)
#
# secret-1 lives in an account the user never selected, so it must never appear
# in the relationships tab at any depth. That is the assertion the e2e script
# makes.
#
# Usage: PGHOST=127.0.0.1 PGPORT=5432 PGUSER=postgres ./scripts/seed_two_tenants.sh
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

PGHOST="${PGHOST:-127.0.0.1}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-postgres}"
export PGHOST PGPORT PGUSER

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"

# bcrypt hash of "StrongPass123!" at default cost
HASH='$2a$10$f7Q2R6aA0ZRcXPIaLBAjmObMWS9NWPkszwXYpoTVrkoV35R8d46HC'

psql -q -c "DROP DATABASE IF EXISTS nhi_global;"
psql -q -c "DROP DATABASE IF EXISTS nhi_tenant_a;"
psql -q -c "DROP DATABASE IF EXISTS nhi_tenant_b;"
psql -q -c "CREATE DATABASE nhi_global;"
psql -q -c "CREATE DATABASE nhi_tenant_a;"
psql -q -c "CREATE DATABASE nhi_tenant_b;"

# ── Global registry: the only database that knows which tenant lives where ──
psql -q -d nhi_global -v ON_ERROR_STOP=1 -f "$ROOT/migrations/global/001_auth_tenant_registry.sql"
psql -q -d nhi_global <<SQL
INSERT INTO nhi_schema.tenants (tenant_id, db_name) VALUES
  ('11111111-1111-1111-1111-111111111111','nhi_tenant_a'),
  ('22222222-2222-2222-2222-222222222222','nhi_tenant_b');
INSERT INTO nhi_schema.nhi_users (email,password,full_name,role,tenant_id,status) VALUES
  ('alice@acme.test','$HASH','Alice (Tenant A)','admin','11111111-1111-1111-1111-111111111111','active'),
  ('bob@globex.test','$HASH','Bob (Tenant B)','admin','22222222-2222-2222-2222-222222222222','active');
SQL

# ── Tenant data schema + user_settings in every tenant database ──
for db in nhi_tenant_a nhi_tenant_b; do
  psql -q -d "$db" -v ON_ERROR_STOP=1 -f "$ROOT/scripts/test_schema.sql"
  psql -q -d "$db" -v ON_ERROR_STOP=1 -f "$ROOT/migrations/tenant/001_user_settings.sql"
done

psql -q -d nhi_tenant_a -v ON_ERROR_STOP=1 <<SQL
INSERT INTO nhi_scanner.nhi_scans_aws (scan_id,scan_start,scan_end,status,total_identities,total_credentials) VALUES
 ('scan-a-1', now()-interval '2 hours', now()-interval '1 hour','COMPLETED',4,2),
 ('scan-a-0', now()-interval '3 days',  now()-interval '3 days','COMPLETED',2,1);

-- Default selection is account 111… across two regions.
INSERT INTO nhi_scanner.accounts (tenant_id,account_id,region,is_default) VALUES
 ('11111111-1111-1111-1111-111111111111','111111111111','us-east-1',true),
 ('11111111-1111-1111-1111-111111111111','111111111111','eu-west-1',true),
 ('11111111-1111-1111-1111-111111111111','222222222222','us-east-1',false),
 ('11111111-1111-1111-1111-111111111111','333333333333','us-east-1',false);

-- In default scope.
INSERT INTO nhi_scanner.identities (scan_id,account_id,region,arn,name,identity_type,functional_class,environment,owner,status,last_activity_at) VALUES
 ('scan-a-1','111111111111','us-east-1','arn:aws:iam::111111111111:role/web-1','web-1','ec2_instance','application','production','platform-team','active',now()),
 ('scan-a-1','111111111111','eu-west-1','arn:aws:iam::111111111111:role/api-1','api-1','lambda_function','service','production','data-team','active',now()),
 ('scan-a-1','111111111111','us-east-1','arn:aws:iam::111111111111:role/batch-1','batch-1','batch_job','service','staging','data-team','active',now()-interval '200 days');
-- In the tenant's database but OUTSIDE the default account selection.
INSERT INTO nhi_scanner.identities (scan_id,account_id,region,arn,name,identity_type,functional_class,environment,owner,status,last_activity_at) VALUES
 ('scan-a-1','222222222222','us-east-1','arn:aws:iam::222222222222:role/other-1','other-1','ec2_instance','application','production','platform-team','active',now()),
 ('scan-a-1','333333333333','us-east-1','arn:aws:iam::333333333333:role/secret-1','secret-1','ec2_instance','application','production','platform-team','active',now());

INSERT INTO nhi_scanner.credentials (scan_id,account_id,region,arn,name,credential_type,status,last_used_at) VALUES
 ('scan-a-1','111111111111','us-east-1','arn:aws:iam::111111111111:role/web-role','web-role','iam_role','active',now()),
 ('scan-a-1','333333333333','us-east-1','arn:aws:iam::333333333333:role/secret-role','secret-role','iam_role','active',now());

INSERT INTO nhi_scanner.identity_credentials (scan_id,identity_id,credential_id,binding_type,is_primary)
 SELECT 'scan-a-1', i.id::text, c.id::text, 'instance_profile', true
 FROM nhi_scanner.identities i CROSS JOIN nhi_scanner.credentials c
 WHERE i.name='web-1' AND c.name='web-role';

-- The graph walks from an in-scope account into an out-of-scope one.
INSERT INTO nhi_scanner.trust_edges (scan_id,source_arn,target_arn,edge_type) VALUES
 ('scan-a-1','arn:aws:iam::111111111111:role/web-1','arn:aws:iam::111111111111:role/api-1','assume_role'),
 ('scan-a-1','arn:aws:iam::111111111111:role/api-1','arn:aws:iam::333333333333:role/secret-1','assume_role'),
 ('scan-a-1','arn:aws:iam::111111111111:role/web-role','arn:aws:iam::333333333333:role/secret-role','assume_role');
SQL

psql -q -d nhi_tenant_b -v ON_ERROR_STOP=1 <<SQL
INSERT INTO nhi_scanner.nhi_scans_aws (scan_id,scan_start,scan_end,status,total_identities,total_credentials) VALUES
 ('scan-b-1', now()-interval '2 hours', now()-interval '1 hour','COMPLETED',2,1);
INSERT INTO nhi_scanner.accounts (tenant_id,account_id,region,is_default) VALUES
 ('22222222-2222-2222-2222-222222222222','999999999999','ap-south-1',true);
INSERT INTO nhi_scanner.identities (scan_id,account_id,region,arn,name,identity_type,functional_class,environment,owner,status,last_activity_at) VALUES
 ('scan-b-1','999999999999','ap-south-1','arn:aws:iam::999999999999:role/b-1','b-1','ec2_instance','application','production','team-b','active',now()),
 ('scan-b-1','999999999999','ap-south-1','arn:aws:iam::999999999999:role/b-2','b-2','ec2_instance','application','production','team-b','active',now());
INSERT INTO nhi_scanner.credentials (scan_id,account_id,region,arn,name,credential_type,status,last_used_at) VALUES
 ('scan-b-1','999999999999','ap-south-1','arn:aws:iam::999999999999:role/b-role','b-role','iam_role','active',now());
SQL

echo "Seeded: nhi_global (2 tenants), nhi_tenant_a, nhi_tenant_b"
echo "Login:  alice@acme.test / bob@globex.test  password: StrongPass123!"
