// Package scope resolves the tenant database and the per-user/default filters
// required by every data request.
package scope

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/database"
	"nhi-backend-api/internal/repository"
)

type TenantDatabaseProvider interface {
	GetTenantDB(dbName string) (*sql.DB, error)
}

type DataScope struct {
	DB       *sql.DB
	UserID   string
	TenantID string
	DBName   string

	AccountIDs []string
	Regions    []string
	ScanID     string

	HasUserSettings bool
	SelectedScanID  *string
	ScanEnd         *time.Time
}

// QueryArgs are the first three PostgreSQL bind values used by scoped data
// queries: effective scan, selected account IDs and selected regions.
func (s *DataScope) QueryArgs() []any {
	if s == nil {
		return []any{"", pq.Array([]string{}), pq.Array([]string{})}
	}
	return []any{s.ScanID, pq.Array(s.AccountIDs), pq.Array(s.Regions)}
}

// Predicates returns the standard per-query scope predicates. Callers should
// also add their own deleted/status/business filters as appropriate.
func (s *DataScope) Predicates(alias string) []string {
	if alias == "" {
		alias = "t"
	}
	return []string{
		alias + ".scan_id = $1",
		alias + ".account_id = ANY($2::text[])",
		alias + ".region = ANY($3::text[])",
	}
}

func (s *DataScope) HasEffectiveScan() bool {
	return s != nil && strings.TrimSpace(s.ScanID) != ""
}

type Resolver struct {
	dbProvider TenantDatabaseProvider
	schema     string
}

func NewResolver(provider TenantDatabaseProvider, schema string) *Resolver {
	if strings.TrimSpace(schema) == "" {
		schema = repository.Schema
	}
	return &Resolver{dbProvider: provider, schema: strings.TrimSpace(schema)}
}

// Resolve loads the tenant's database, saved settings (by canonical email),
// tenant defaults, and the effective completed scan. A present settings row is
// authoritative even when one of its selected lists is empty.
func (r *Resolver) Resolve(ctx context.Context, userID, tenantID, dbName string) (*DataScope, error) {
	if r == nil || r.dbProvider == nil {
		return nil, errors.New("tenant scope resolver is not initialized")
	}
	userID, tenantID, dbName = strings.TrimSpace(userID), strings.TrimSpace(tenantID), strings.TrimSpace(dbName)
	if userID == "" || tenantID == "" || dbName == "" {
		return nil, errors.New("user_id, tenant_id and db_name are required to resolve data scope")
	}
	tenantDB, err := r.dbProvider.GetTenantDB(dbName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant data database: %w", err)
	}
	s := &DataScope{
		DB: tenantDB, UserID: userID, TenantID: tenantID, DBName: dbName,
		AccountIDs: make([]string, 0), Regions: make([]string, 0),
	}

	settings, err := r.loadUserSettings(ctx, tenantDB, userID)
	if err != nil {
		return nil, err
	}
	if settings.exists {
		s.HasUserSettings = true
		validAccounts, err := r.existingAccounts(ctx, tenantDB, tenantID, settings.accountIDs)
		if err != nil {
			return nil, err
		}
		validRegions, err := r.existingRegions(ctx, tenantDB, tenantID, settings.regions)
		if err != nil {
			return nil, err
		}
		s.AccountIDs, s.Regions = validAccounts, validRegions
		s.SelectedScanID = settings.scanID
	} else {
		s.AccountIDs, err = r.defaultAccounts(ctx, tenantDB, tenantID)
		if err != nil {
			return nil, err
		}
		s.Regions, err = r.defaultRegions(ctx, tenantDB, tenantID)
		if err != nil {
			return nil, err
		}
	}

	if s.SelectedScanID != nil {
		info, err := r.completedScan(ctx, tenantDB, *s.SelectedScanID)
		if err != nil {
			return nil, err
		}
		if info != nil {
			s.ScanID, s.ScanEnd = info.id, info.end
		} else {
			// A saved scan may have been purged or ceased to be completed. Do
			// not use it; resolve to the tenant's latest completed scan.
			s.SelectedScanID = nil
		}
	}
	if s.ScanID == "" {
		info, err := r.latestCompletedScan(ctx, tenantDB)
		if err != nil {
			return nil, err
		}
		if info != nil {
			s.ScanID, s.ScanEnd = info.id, info.end
		}
	}
	return s, nil
}

type savedSettings struct {
	exists     bool
	accountIDs []string
	regions    []string
	scanID     *string
}

func (r *Resolver) loadUserSettings(ctx context.Context, db *sql.DB, userID string) (savedSettings, error) {
	q := `SELECT selected_account_ids, selected_regions, selected_scan_id
		FROM ` + database.Table(r.schema, "user_settings") + ` WHERE user_id = $1 LIMIT 1`
	var accountJSON, regionJSON []byte
	var scanID sql.NullString
	err := db.QueryRowContext(ctx, q, userID).Scan(&accountJSON, &regionJSON, &scanID)
	if errors.Is(err, sql.ErrNoRows) {
		return savedSettings{exists: false}, nil
	}
	if err != nil {
		return savedSettings{}, fmt.Errorf("load user settings: %w", err)
	}
	out := savedSettings{exists: true, accountIDs: decodeStringList(accountJSON), regions: decodeStringList(regionJSON)}
	if scanID.Valid && strings.TrimSpace(scanID.String) != "" {
		v := strings.TrimSpace(scanID.String)
		out.scanID = &v
	}
	return out, nil
}

func (r *Resolver) defaultAccounts(ctx context.Context, db *sql.DB, tenantID string) ([]string, error) {
	q := `SELECT DISTINCT account_id FROM ` + database.Table(r.schema, "accounts") + `
		WHERE tenant_id = $1::uuid AND is_default = true AND account_id IS NOT NULL AND account_id <> ''
		ORDER BY account_id`
	return queryStrings(ctx, db, q, tenantID)
}

func (r *Resolver) defaultRegions(ctx context.Context, db *sql.DB, tenantID string) ([]string, error) {
	q := `SELECT DISTINCT region FROM ` + database.Table(r.schema, "accounts") + `
		WHERE tenant_id = $1::uuid AND is_default = true AND region IS NOT NULL AND region <> ''
		ORDER BY region`
	return queryStrings(ctx, db, q, tenantID)
}

func (r *Resolver) existingAccounts(ctx context.Context, db *sql.DB, tenantID string, selected []string) ([]string, error) {
	if len(selected) == 0 {
		return make([]string, 0), nil
	}
	q := `SELECT DISTINCT account_id FROM ` + database.Table(r.schema, "accounts") + `
		WHERE tenant_id = $1::uuid AND account_id = ANY($2::text[]) ORDER BY account_id`
	return queryStrings(ctx, db, q, tenantID, pq.Array(selected))
}

func (r *Resolver) existingRegions(ctx context.Context, db *sql.DB, tenantID string, selected []string) ([]string, error) {
	if len(selected) == 0 {
		return make([]string, 0), nil
	}
	q := `SELECT DISTINCT region FROM ` + database.Table(r.schema, "accounts") + `
		WHERE tenant_id = $1::uuid AND region = ANY($2::text[]) ORDER BY region`
	return queryStrings(ctx, db, q, tenantID, pq.Array(selected))
}

func queryStrings(ctx context.Context, db *sql.DB, q string, args ...any) ([]string, error) {
	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]string, 0)
	for rows.Next() {
		var value string
		if err := rows.Scan(&value); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

type scanInfo struct {
	id  string
	end *time.Time
}

func (r *Resolver) completedScan(ctx context.Context, db *sql.DB, scanID string) (*scanInfo, error) {
	q := `SELECT scan_id, scan_end FROM ` + database.Table(r.schema, "nhi_scans_aws") + `
		WHERE scan_id = $1 AND status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST LIMIT 1`
	return r.scanQuery(ctx, db, q, scanID)
}

func (r *Resolver) latestCompletedScan(ctx context.Context, db *sql.DB) (*scanInfo, error) {
	q := `SELECT scan_id, scan_end FROM ` + database.Table(r.schema, "nhi_scans_aws") + `
		WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1`
	return r.scanQuery(ctx, db, q)
}

func (r *Resolver) scanQuery(ctx context.Context, db *sql.DB, q string, args ...any) (*scanInfo, error) {
	var id string
	var end sql.NullTime
	if err := db.QueryRowContext(ctx, q, args...).Scan(&id, &end); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("resolve completed scan: %w", err)
	}
	out := &scanInfo{id: id}
	if end.Valid {
		t := end.Time.UTC()
		out.end = &t
	}
	return out, nil
}

func decodeStringList(raw []byte) []string {
	if len(raw) == 0 {
		return make([]string, 0)
	}
	var values []string
	if err := json.Unmarshal(raw, &values); err != nil {
		return make([]string, 0)
	}
	if values == nil {
		return make([]string, 0)
	}
	out := make([]string, 0, len(values))
	seen := make(map[string]struct{}, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		out = append(out, value)
	}
	return out
}
