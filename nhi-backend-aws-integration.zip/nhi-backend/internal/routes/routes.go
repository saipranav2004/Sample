package routes

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/handlers/credential_exposure"
	handlerv1 "nhi-backend-api/internal/handlers/v1"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler    *handlers.AuthHandler
	AuthMiddleware *middleware.AuthMiddleware

	NewAPIFilterHandler            *handlerv1.FilterHandler
	NewAPISettingsHandler          *handlerv1.SettingsHandler
	NewAPIDashboardOverviewHandler *handlerv1.DashboardOverviewHandler
	NewAPIIdentitiesListHandler    *handlerv1.IdentitiesListHandler
	NewAPIIdentityDetailHandler    *handlerv1.IdentityDetailHandler
	NewAPICredentialsHandler       *handlerv1.CredentialsHandler
	NewAPICredentialDetailHandler  *handlerv1.CredentialDetailHandler
	AWSIntegrationHandler          *handlerv1.AWSIntegrationHandler

	CredentialExposureFindingsHandler  *credential_exposure.FindingsHandler
	CredentialExposureAllowlistHandler *credential_exposure.AllowlistHandler
	CredentialExposureDecisionHandler  *credential_exposure.DecisionHandler
	CredentialExposureDeepScanHandler  *credential_exposure.DeepScanHandler
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()
	r.Use(middleware.RequestLogger)

	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusNotFound, map[string]any{
			"success": false,
			"message": "route not found: " + req.Method + " " + req.URL.Path,
		})
	})
	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{
			"success": false,
			"message": "method not allowed: " + req.Method + " " + req.URL.Path,
		})
	})

	r.HandleFunc("/health", func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "healthy", "service": "nhi-backend-api"})
	}).Methods(http.MethodGet)

	if h.AuthHandler != nil {
		r.HandleFunc("/api/v1/login", h.AuthHandler.Login).Methods(http.MethodPost)
		r.HandleFunc("/api/auth/login", h.AuthHandler.Login).Methods(http.MethodPost)
	}
	if h.AuthMiddleware == nil {
		return r
	}

	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.AuthMiddleware.Authenticate)
	protected := r.PathPrefix("/api").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)
	registerProtected(v1, h, true)
	registerProtected(protected, h, false)
	return r
}

func registerProtected(router *mux.Router, h HandlerContainer, versioned bool) {
	if h.AuthHandler != nil {
		path := "/auth/me"
		if versioned {
			path = "/me"
		}
		router.HandleFunc(path, h.AuthHandler.Me).Methods(http.MethodGet)
	}
	if h.NewAPIFilterHandler != nil {
		router.HandleFunc("/filters", h.NewAPIFilterHandler.GetFilters).Methods(http.MethodGet)
	}
	if h.NewAPISettingsHandler != nil {
		router.HandleFunc("/settings", h.NewAPISettingsHandler.Get).Methods(http.MethodGet)
		router.HandleFunc("/settings", h.NewAPISettingsHandler.Update).Methods(http.MethodPut)
	}
	if h.NewAPIDashboardOverviewHandler != nil {
		router.HandleFunc("/dashboard/overview", h.NewAPIDashboardOverviewHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPIIdentitiesListHandler != nil {
		router.HandleFunc("/identities", h.NewAPIIdentitiesListHandler.List).Methods(http.MethodGet)
	}
	if h.NewAPIIdentityDetailHandler != nil {
		router.HandleFunc("/identities/{id}", h.NewAPIIdentityDetailHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPICredentialsHandler != nil {
		router.HandleFunc("/credentials", h.NewAPICredentialsHandler.List).Methods(http.MethodGet)
	}
	if h.NewAPICredentialDetailHandler != nil {
		router.HandleFunc("/credentials/{id}", h.NewAPICredentialDetailHandler.Get).Methods(http.MethodGet)
	}
	if h.AWSIntegrationHandler != nil {
		router.HandleFunc("/integrations/aws", h.AWSIntegrationHandler.Get).Methods(http.MethodGet)
		router.HandleFunc("/integrations/aws/verify", h.AWSIntegrationHandler.Verify).Methods(http.MethodPost)
	}
	// Credential Exposure — secret scanner findings, tenant-isolated, admin-only
	// These were present in the original backends but not wired in the v1-only build.
	// They live in their own package with strict query validation and tenant scope.
	if h.CredentialExposureFindingsHandler != nil {
		router.HandleFunc("/credential-exposure/findings", h.CredentialExposureFindingsHandler.List).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/findings/flagged", h.CredentialExposureFindingsHandler.ListFlagged).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/findings/summary", h.CredentialExposureFindingsHandler.Summary).Methods(http.MethodGet)
	}
	if h.CredentialExposureAllowlistHandler != nil {
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.List).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.Create).Methods(http.MethodPost)
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.Delete).Methods(http.MethodDelete)
	}
	if h.CredentialExposureDecisionHandler != nil {
		router.HandleFunc("/credential-exposure/decisions", h.CredentialExposureDecisionHandler.Save).Methods(http.MethodPost)
	}
	if h.CredentialExposureDeepScanHandler != nil {
		router.HandleFunc("/credential-exposure/deep-scan", h.CredentialExposureDeepScanHandler.Trigger).Methods(http.MethodPost)
		router.HandleFunc("/credential-exposure/deep-scan/status", h.CredentialExposureDeepScanHandler.Status).Methods(http.MethodGet)
	}
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
