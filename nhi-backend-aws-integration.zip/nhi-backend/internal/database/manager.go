// Package database owns the global authentication pool and lazily opened tenant pools.
// Tenant database names are supplied by the trusted global tenants registry, carried
// in a signed JWT, and validated before they are used to open a pool.
package database

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"

	"nhi-backend-api/internal/config"
)

const driverName = "pgx"

var ErrTenantDBNotConfigured = errors.New("tenant database is not configured")

type Manager struct {
	global    *sql.DB
	globalCfg config.DatabaseConfig
	dataCfg   config.DatabaseConfig

	mu          sync.RWMutex
	tenantPools map[string]*sql.DB
}

func NewManager(cfg *config.Config) (*Manager, error) {
	if cfg == nil {
		return nil, errors.New("database: nil config")
	}
	if err := config.ValidateDatabaseName(cfg.GlobalDatabase.DBName()); err != nil {
		return nil, fmt.Errorf("global database name: %w", err)
	}
	m := &Manager{
		globalCfg:   cfg.GlobalDatabase,
		dataCfg:     cfg.Database,
		tenantPools: make(map[string]*sql.DB),
	}
	g, err := openPool(m.globalCfg, 20, 10)
	if err != nil {
		return nil, fmt.Errorf("connect global authentication database: %w", err)
	}
	m.global = g
	return m, nil
}

func (m *Manager) Global() *sql.DB {
	if m == nil {
		return nil
	}
	return m.global
}

func (m *Manager) GlobalSchema() string {
	if m == nil {
		return ""
	}
	return strings.TrimSpace(m.globalCfg.Schema)
}

func (m *Manager) DataSchema() string {
	if m == nil {
		return ""
	}
	return strings.TrimSpace(m.dataCfg.Schema)
}

// Tenant returns only a tenant data pool. It deliberately has no default/global
// fallback: a missing or invalid name is an error, not a request to use another DB.
func (m *Manager) Tenant(dbName string) (*sql.DB, error) {
	if m == nil {
		return nil, errors.New("database manager is not initialized")
	}
	dbName = strings.TrimSpace(dbName)
	if dbName == "" {
		return nil, ErrTenantDBNotConfigured
	}
	if err := config.ValidateDatabaseName(dbName); err != nil {
		return nil, err
	}

	m.mu.RLock()
	pool, ok := m.tenantPools[dbName]
	m.mu.RUnlock()
	if ok {
		return pool, nil
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	if pool, ok = m.tenantPools[dbName]; ok {
		return pool, nil
	}

	cfg := m.dataCfg.WithDBName(dbName)
	pool, err := openPool(cfg, 10, 5)
	if err != nil {
		return nil, fmt.Errorf("open tenant database %q: %w", dbName, err)
	}
	m.tenantPools[dbName] = pool
	return pool, nil
}

func (m *Manager) Close() error {
	if m == nil {
		return nil
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	var firstErr error
	for name, pool := range m.tenantPools {
		if err := pool.Close(); err != nil && firstErr == nil {
			firstErr = fmt.Errorf("close tenant database %q: %w", name, err)
		}
		delete(m.tenantPools, name)
	}
	if m.global != nil {
		if err := m.global.Close(); err != nil && firstErr == nil {
			firstErr = fmt.Errorf("close global database: %w", err)
		}
		m.global = nil
	}
	return firstErr
}

func Table(schema, table string) string {
	if strings.TrimSpace(schema) == "" {
		return quoteIdent(table)
	}
	return quoteIdent(schema) + "." + quoteIdent(table)
}

func quoteIdent(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func openPool(cfg config.DatabaseConfig, maxOpen, maxIdle int) (*sql.DB, error) {
	connStr := strings.TrimSpace(cfg.GetConnectionString())
	if cfg.DBName() == "" || connStr == "" {
		return nil, errors.New("empty database name or connection string")
	}
	db, err := sql.Open(driverName, connStr)
	if err != nil {
		return nil, fmt.Errorf("open postgres: %w", err)
	}
	db.SetMaxOpenConns(maxOpen)
	db.SetMaxIdleConns(maxIdle)
	db.SetConnMaxLifetime(30 * time.Minute)
	db.SetConnMaxIdleTime(5 * time.Minute)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}
	return db, nil
}
