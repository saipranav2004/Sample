package services

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/pkg/jwt"
)

var (
	ErrAccountDisabled     = errors.New("account is not active")
	ErrTenantNotConfigured = errors.New("tenant database is not configured for this account")
)

type AuthService struct {
	userRepo *repository.UserRepository
	jwtCfg   config.JWTConfig
}

func NewAuthService(userRepo *repository.UserRepository, jwtCfg config.JWTConfig) *AuthService {
	return &AuthService{userRepo: userRepo, jwtCfg: jwtCfg}
}

// Login authenticates against the global database, resolves the tenant database
// from the trusted registry, and issues a token with the PDF's claim contract.
func (s *AuthService) Login(ctx context.Context, req models.LoginRequest) (*models.LoginResponse, error) {
	email := strings.TrimSpace(req.Email)
	if email == "" || req.Password == "" {
		return nil, errors.New("email and password are required")
	}
	user, err := s.userRepo.GetByEmail(ctx, email)
	if err != nil {
		return nil, fmt.Errorf("authentication lookup failed: %w", err)
	}
	if user == nil {
		return nil, errors.New("invalid email or password")
	}
	if !strings.EqualFold(strings.TrimSpace(user.Status), "active") {
		return nil, ErrAccountDisabled
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return nil, errors.New("invalid email or password")
	}

	dbName, err := s.userRepo.GetTenantDBName(ctx, user.TenantID)
	if err != nil {
		return nil, fmt.Errorf("tenant resolution failed: %w", err)
	}
	if err := config.ValidateDatabaseName(dbName); err != nil {
		return nil, ErrTenantNotConfigured
	}
	user.Email = strings.ToLower(strings.TrimSpace(user.Email))

	// Do not issue a token if the audit update failed: the documented login
	// process requires last_login_at to be recorded for a successful login.
	if err := s.userRepo.UpdateLastLogin(ctx, user.ID); err != nil {
		return nil, fmt.Errorf("record last login: %w", err)
	}

	token, err := jwt.GenerateToken(
		user.Email, user.TenantID, dbName, user.Role,
		s.jwtCfg.Secret, s.jwtCfg.ExpiryHours,
	)
	if err != nil {
		return nil, fmt.Errorf("issue token: %w", err)
	}

	user.Email = strings.ToLower(strings.TrimSpace(user.Email))
	user.Password = ""
	now := time.Now().UTC()
	user.LastLoginAt = &now
	return &models.LoginResponse{
		Token:     token,
		User:      *user,
		ExpiresIn: s.jwtCfg.ExpiryHours * 3600,
	}, nil
}

func (s *AuthService) GetUserByID(ctx context.Context, id int) (*models.User, error) {
	user, err := s.userRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if user != nil {
		user.Password = ""
	}
	return user, nil
}
