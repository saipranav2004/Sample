package v1

import (
	"context"
	"fmt"

	models "nhi-backend-api/internal/models/v1"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/scope"
)

var ErrInvalidTab = fmt.Errorf("invalid or disabled credential detail tab")

// Relationship graph traversal is enabled: traverseGraph prunes every hop to
// the caller's resolved account/region scope before expanding the frontier.
var validTabs = map[string]bool{
	"overview":      true,
	"trust":         true,
	"activity":      true,
	"rotation":      true,
	"relationships": true,
	"raw":           true,
}

var ErrCredentialNotFound = repov1.ErrCredentialNotFound

type CredentialDetailService struct {
	repo     *repov1.CredentialDetailRepository
	resolver *scope.Resolver
}

func NewCredentialDetailService(repo *repov1.CredentialDetailRepository, resolver *scope.Resolver) *CredentialDetailService {
	return &CredentialDetailService{repo: repo, resolver: resolver}
}

func (s *CredentialDetailService) GetDetail(ctx context.Context, userID, tenantID, dbName string, f models.DetailFilter) (interface{}, error) {
	if !validTabs[f.Tab] {
		return nil, ErrInvalidTab
	}
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	// Same normalisation as Identity Detail — see ResolveTimeRange.
	tr, err := ResolveTimeRange(f.TimeRange)
	if err != nil {
		return nil, err
	}
	f.TimeRange = tr.Label

	switch f.Tab {
	case "overview":
		return s.repo.GetOverview(ctx, resolved, f.CredentialID)
	case "trust":
		return s.repo.GetTrust(ctx, resolved, f.CredentialID)
	case "activity":
		return s.repo.GetActivity(ctx, resolved, f.CredentialID, f.TimeRange)
	case "rotation":
		return s.repo.GetRotation(ctx, resolved, f.CredentialID)
	case "relationships":
		return s.repo.GetRelationships(ctx, resolved, f.CredentialID, f.Depth, f.EdgeType)
	case "raw":
		return s.repo.GetRaw(ctx, resolved, f.CredentialID)
	default:
		return nil, ErrInvalidTab
	}
}
