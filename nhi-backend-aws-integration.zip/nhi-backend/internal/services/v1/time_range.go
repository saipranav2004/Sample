package v1

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

// TimeRangeError is a client mistake in ?time_range= (HTTP 400). Each handler
// converts it into its own JSON error envelope.
type TimeRangeError struct{ Msg string }

func (e *TimeRangeError) Error() string { return e.Msg }

// ResolvedTimeRange is the normalised result of resolving ?time_range=.
//
// The window is rolling and ends now (UTC). Label is the canonical value that
// must be echoed back in the response — never the raw query parameter, which
// would let a client inject arbitrary strings into the payload.
type ResolvedTimeRange struct {
	Days  int
	Start time.Time
	End   time.Time
	Label string // "90d", "7d", "all", …
}

const maxRangeDays = 36500 // ~100 years — "no lower bound"

// ResolveTimeRange is shared by Identity Detail and Credential Detail so both
// endpoints behave identically for the same input.
//
//	""          → 90 days (the documented default)
//	"1", "55"   → that many days (bare number)
//	"7d", "30d" → that many days (optional "d" suffix)
//	"all"       → everything
//
// Anything else (0, negative, text, > 36500) is a TimeRangeError so the caller
// gets an explicit 400 rather than silently receiving a different window than
// the one it asked for.
func ResolveTimeRange(timeRange string) (*ResolvedTimeRange, error) {
	now := time.Now().UTC()
	tr := strings.ToLower(strings.TrimSpace(timeRange))
	if tr == "" {
		tr = "90"
	}
	if tr == "all" {
		return &ResolvedTimeRange{
			Days:  maxRangeDays,
			Start: now.AddDate(0, 0, -maxRangeDays),
			End:   now,
			Label: "all",
		}, nil
	}
	n, err := strconv.Atoi(strings.TrimSuffix(tr, "d"))
	if err != nil || n < 1 || n > maxRangeDays {
		return nil, &TimeRangeError{Msg: fmt.Sprintf(
			"time_range %q is not valid: use a number of days (e.g. 1, 7, 55) or \"all\"", timeRange)}
	}
	return &ResolvedTimeRange{
		Days:  n,
		Start: now.AddDate(0, 0, -n),
		End:   now,
		Label: fmt.Sprintf("%dd", n),
	}, nil
}
