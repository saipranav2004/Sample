package v1

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"nhi-backend-api/internal/awsconnect"
	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
)

var (
	// ErrAWSPlatformNotConfigured: aws_platform_settings is missing or
	// inconsistent. An operator has to fix it; clients cannot.
	ErrAWSPlatformNotConfigured = errors.New("aws integration is not configured on the platform")
	// ErrAWSUnavailable: this process has no usable AWS configuration.
	ErrAWSUnavailable = errors.New("aws is not reachable from the api")
	// ErrAWSVerifyInProgress: a verification for this tenant is already running.
	ErrAWSVerifyInProgress = errors.New("a connection check is already running")
	// ErrAWSAccountClaimed: the account belongs to another tenant.
	ErrAWSAccountClaimed = errors.New("aws account is connected to another workspace")
)

// What the client is asked to set up. Kept here, next to the checks that
// prove it, so the instructions and the verification cannot drift apart.
var (
	awsManagedPolicies = []string{"SecurityAudit", "ViewOnlyAccess"}
	awsEventSources    = []string{
		"aws.ec2", "aws.ecs", "aws.iam", "aws.sts",
		"aws.lambda", "aws.eks", "aws.secretsmanager", "aws.kms",
	}
)

// Time budget for one verification. The HTTP server's write timeout is 15s,
// so the whole run must answer well inside it.
const (
	awsVerifyBudget     = 12 * time.Second
	awsAssumeTimeout    = 4 * time.Second
	awsReadTimeout      = 3 * time.Second
	awsPermissionBudget = 3 * time.Second
)

// AWSIntegrationStore is the persistence the service needs
// (repository.AWSIntegrationRepository in production).
type AWSIntegrationStore interface {
	PlatformSettings(ctx context.Context) (*models.AWSPlatformSettings, error)
	ExternalID(ctx context.Context, tenantID string) (string, bool, error)
	EnsureExternalID(ctx context.Context, tenantID string) (string, error)
	ListAccounts(ctx context.Context, tenantID string) ([]models.AWSAccountRecord, error)
	AccountClaimedByOther(ctx context.Context, tenantID, accountID string) (bool, error)
	SaveAccount(ctx context.Context, rec models.AWSAccountRecord) (*models.AWSAccountRecord, error)
}

// AWSVerifier is the AWS side (awsconnect.Client in production).
type AWSVerifier interface {
	AssumeRole(ctx context.Context, p awsconnect.Platform, role awsconnect.RoleARN, externalID string) (*awsconnect.Session, error)
	TestRead(ctx context.Context, s *awsconnect.Session) error
	AllowAccountOnBus(ctx context.Context, p awsconnect.Platform, accountID string) error
	HasEventsFrom(ctx context.Context, p awsconnect.Platform, accountID string, since time.Time) (bool, error)
}

type AWSIntegrationService struct {
	store    AWSIntegrationStore
	verifier AWSVerifier
	lookback time.Duration
	now      func() time.Time

	running sync.Map // tenantID -> struct{}: one verification per tenant at a time
}

// NewAWSIntegrationService wires the service. verifier may be nil when the
// process has no AWS configuration; the setup page still loads, and
// verification answers ErrAWSUnavailable.
func NewAWSIntegrationService(store AWSIntegrationStore, verifier AWSVerifier, eventLookback time.Duration) *AWSIntegrationService {
	if eventLookback <= 0 {
		eventLookback = 24 * time.Hour
	}
	return &AWSIntegrationService{store: store, verifier: verifier, lookback: eventLookback, now: time.Now}
}

func (s *AWSIntegrationService) platform(ctx context.Context) (awsconnect.Platform, *models.AWSPlatformSettings, error) {
	settings, err := s.store.PlatformSettings(ctx)
	if err != nil {
		return awsconnect.Platform{}, nil, err
	}
	if settings == nil {
		log.Printf("aws integration: nhi_schema.aws_platform_settings has no row; see migrations/global/002_aws_integration.sql")
		return awsconnect.Platform{}, nil, ErrAWSPlatformNotConfigured
	}
	p, err := awsconnect.NewPlatform(settings.AccountID, settings.Region, settings.EventBusARN, settings.AssumerRoleARN)
	if err != nil {
		log.Printf("aws integration: %v", err)
		return awsconnect.Platform{}, nil, ErrAWSPlatformNotConfigured
	}
	return p, settings, nil
}

// Get returns the tenant's connection status and, for those who may manage
// it, the values to copy. The External ID is issued on the first such read.
func (s *AWSIntegrationService) Get(ctx context.Context, tenantID string, canManage bool) (*models.AWSIntegrationResponse, error) {
	records, err := s.store.ListAccounts(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	out := &models.AWSIntegrationResponse{
		Status:    tenantStatus(records),
		CanManage: canManage,
		Accounts:  make([]models.AWSConnectedAccount, 0, len(records)),
	}
	for _, rec := range records {
		out.Accounts = append(out.Accounts, models.AWSConnectedAccount{
			AccountID:      rec.AccountID,
			RoleARN:        rec.RoleARN,
			Status:         rec.Status,
			Checks:         rec.Checks,
			LastVerifiedAt: rec.LastVerifiedAt,
			LastVerifiedBy: rec.LastVerifiedBy,
			ConnectedAt:    rec.ConnectedAt,
		})
	}
	if !canManage {
		return out, nil
	}

	p, settings, err := s.platform(ctx)
	if err != nil {
		return nil, err
	}
	externalID, err := s.store.EnsureExternalID(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	out.Setup = &models.AWSSetupValues{
		AccountID:       p.AccountID,
		ExternalID:      externalID,
		EventBusARN:     p.EventBusARN,
		Region:          p.Region,
		AssumerRoleARN:  p.AssumerRoleARN,
		RoleName:        orDefault(settings.CollectorRoleName, "NHIPlatformCollector"),
		RuleName:        orDefault(settings.ForwardRuleName, "nhi-forward-events"),
		ManagedPolicies: append([]string(nil), awsManagedPolicies...),
		EventSources:    append([]string(nil), awsEventSources...),
	}
	return out, nil
}

func tenantStatus(records []models.AWSAccountRecord) string {
	if len(records) == 0 {
		return models.AWSStatusNotConnected
	}
	for _, rec := range records {
		if rec.Status == models.AWSStatusConnected {
			return models.AWSStatusConnected
		}
	}
	return models.AWSStatusActionNeeded
}

// Verify runs the three checks for a pasted role ARN, in order:
//
//  1. sts:AssumeRole with the ARN and the tenant's External ID
//  2. iam:ListRoles with the assumed role (one test read)
//  3. an event from the account has reached the central bus
//
// Before (3) the account is allowed to put events on the central bus - the
// client never sees that step. Nothing is stored or granted until (1) passes,
// because only then has the tenant shown it controls the account.
func (s *AWSIntegrationService) Verify(ctx context.Context, tenantID, actor, rawRoleARN string) (*models.AWSVerifyResponse, error) {
	p, _, err := s.platform(ctx)
	if err != nil {
		return nil, err
	}
	role, err := awsconnect.ParseRoleARN(rawRoleARN)
	if err != nil {
		return nil, err
	}
	if role.AccountID == p.AccountID {
		return nil, &awsconnect.ErrInvalidRoleARN{Message: "That ARN is in our account (" + p.AccountID + "). Paste the ARN of the role you created in your own AWS account."}
	}
	if s.verifier == nil {
		return nil, ErrAWSUnavailable
	}
	externalID, ok, err := s.store.ExternalID(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	if !ok {
		// The setup values were never loaded, so no role can trust this
		// tenant's External ID yet. Issue it so the next attempt can pass.
		if externalID, err = s.store.EnsureExternalID(ctx, tenantID); err != nil {
			return nil, err
		}
	}

	if _, busy := s.running.LoadOrStore(tenantID, struct{}{}); busy {
		return nil, ErrAWSVerifyInProgress
	}
	defer s.running.Delete(tenantID)

	ctx, cancel := context.WithTimeout(ctx, awsVerifyBudget)
	defer cancel()

	checks := newChecks()
	result := &models.AWSVerifyResponse{
		Status:     models.AWSStatusActionNeeded,
		AccountID:  role.AccountID,
		RoleARN:    role.ARN,
		Checks:     checks,
		VerifiedAt: s.now().UTC(),
	}

	// 1. AssumeRole
	stepCtx, stepCancel := context.WithTimeout(ctx, awsAssumeTimeout)
	session, err := s.verifier.AssumeRole(stepCtx, p, role, externalID)
	stepCancel()
	if err != nil {
		if errors.Is(err, awsconnect.ErrAccessDenied) {
			fail(&checks[0], "AWS would not let us use this role.", "Check the External ID matches")
		} else {
			logCheckError(tenantID, role.AccountID, checks[0].Key, err)
			unavailable(&checks[0])
		}
		skip(&checks[1])
		skip(&checks[2])
		return result, nil
	}
	pass(&checks[0], "Signed in to your account with your External ID.")

	// The tenant controls this account. It may still belong to another tenant.
	claimed, err := s.store.AccountClaimedByOther(ctx, tenantID, role.AccountID)
	if err != nil {
		return nil, err
	}
	if claimed {
		return nil, ErrAWSAccountClaimed
	}

	// 2. One test read
	stepCtx, stepCancel = context.WithTimeout(ctx, awsReadTimeout)
	err = s.verifier.TestRead(stepCtx, session)
	stepCancel()
	switch {
	case err == nil:
		pass(&checks[1], "Read access works.")
	case errors.Is(err, awsconnect.ErrAccessDenied), errors.Is(err, awsconnect.ErrNothingRead):
		fail(&checks[1], "The role cannot read your account.", "Attach SecurityAudit + ViewOnlyAccess")
	default:
		logCheckError(tenantID, role.AccountID, checks[1].Key, err)
		unavailable(&checks[1])
	}

	// 3. Events. Allow the account on the bus first (idempotent), so events
	// it forwards are accepted - EventBridge retries refused deliveries, so
	// events sent before this point still arrive.
	stepCtx, stepCancel = context.WithTimeout(ctx, awsPermissionBudget)
	err = s.verifier.AllowAccountOnBus(stepCtx, p, role.AccountID)
	stepCancel()
	if err != nil {
		logCheckError(tenantID, role.AccountID, "bus_permission", err)
		unavailable(&checks[2])
	} else {
		found, err := s.verifier.HasEventsFrom(ctx, p, role.AccountID, s.now().Add(-s.lookback))
		switch {
		case err != nil:
			logCheckError(tenantID, role.AccountID, checks[2].Key, err)
			unavailable(&checks[2])
		case found:
			pass(&checks[2], "Events from your account are arriving.")
		default:
			fail(&checks[2], fmt.Sprintf("No events from this account in the last %s.", humanHours(s.lookback)), "Check the EventBridge rule target ARN")
		}
	}

	if checks[0].State == models.AWSCheckPass && checks[1].State == models.AWSCheckPass && checks[2].State == models.AWSCheckPass {
		result.Status = models.AWSStatusConnected
	}

	// Saved even if the caller has gone: the checks really ran, and a fresh
	// context keeps a disconnect from losing the result.
	saveCtx, saveCancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer saveCancel()
	_, err = s.store.SaveAccount(saveCtx, models.AWSAccountRecord{
		TenantID:       tenantID,
		AccountID:      role.AccountID,
		RoleARN:        role.ARN,
		Status:         result.Status,
		Checks:         checks,
		LastVerifiedAt: result.VerifiedAt,
		LastVerifiedBy: actor,
	})
	if errors.Is(err, repository.ErrAWSAccountClaimed) {
		return nil, ErrAWSAccountClaimed
	}
	if err != nil {
		return nil, err
	}
	result.Saved = true
	return result, nil
}

func newChecks() []models.AWSCheck {
	return []models.AWSCheck{
		{Key: models.AWSCheckAssumeRole, Label: "Assume your role"},
		{Key: models.AWSCheckReadAccess, Label: "Read your account"},
		{Key: models.AWSCheckEvents, Label: "Receive your events"},
	}
}

func pass(c *models.AWSCheck, message string) {
	c.State, c.Message, c.Fix = models.AWSCheckPass, message, ""
}

func fail(c *models.AWSCheck, message, fix string) {
	c.State, c.Message, c.Fix = models.AWSCheckFail, message, fix
}

func skip(c *models.AWSCheck) {
	c.State, c.Message, c.Fix = models.AWSCheckSkipped, "Runs once the check above passes.", ""
}

func unavailable(c *models.AWSCheck) {
	c.State, c.Message, c.Fix = models.AWSCheckError, "We could not run this check just now. Try again in a minute.", ""
}

// logCheckError keeps AWS's own error text in the server log only; it can
// name internal resources and is no help to the client.
func logCheckError(tenantID, accountID, check string, err error) {
	log.Printf("aws integration: tenant=%s account=%s check=%s: %v", tenantID, accountID, check, err)
}

func humanHours(d time.Duration) string {
	hours := int(d.Round(time.Hour) / time.Hour)
	switch {
	case hours <= 1:
		return "hour"
	case hours%24 == 0 && hours > 24:
		return fmt.Sprintf("%d days", hours/24)
	default:
		return fmt.Sprintf("%d hours", hours)
	}
}

func orDefault(value, fallback string) string {
	if v := strings.TrimSpace(value); v != "" {
		return v
	}
	return fallback
}
