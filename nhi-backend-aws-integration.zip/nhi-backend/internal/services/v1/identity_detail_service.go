package v1

import (
	"context"
	"fmt"

	models "nhi-backend-api/internal/models/v1"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/scope"
)

var ErrInvalidIdentityTab = fmt.Errorf("invalid or disabled identity detail tab")

// Relationship graph expansion is deliberately disabled until every traversed
// node can be constrained to the user's account/region scope.
var validIdentityTabs = map[string]bool{
	"overview":      true,
	"permissions":   true,
	"activity":      true,
	"relationships": true,
	"credentials":   true,
	"raw":           true,
}

var ErrIdentityNotFound = repov1.ErrIdentityNotFound

type IdentityDetailService struct {
	repo     *repov1.IdentityDetailRepository
	resolver *scope.Resolver
}

func NewIdentityDetailService(repo *repov1.IdentityDetailRepository, resolver *scope.Resolver) *IdentityDetailService {
	return &IdentityDetailService{repo: repo, resolver: resolver}
}

func (s *IdentityDetailService) GetDetail(ctx context.Context, userID, tenantID, dbName string, f models.IdentityDetailFilter) (interface{}, error) {
	if !validIdentityTabs[f.Tab] {
		return nil, ErrInvalidIdentityTab
	}
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	// Normalise ?time_range= once, up front: garbage is a 400 and every tab
	// sees the same canonical label rather than the raw query string.
	tr, err := ResolveTimeRange(f.TimeRange)
	if err != nil {
		return nil, err
	}
	f.TimeRange = tr.Label

	switch f.Tab {
	case "overview":
		return s.repo.GetOverview(ctx, resolved, f.IdentityID)
	case "permissions":
		return s.repo.GetPermissions(ctx, resolved, f.IdentityID, f.Service, f.UsedOnly)
	case "activity":
		return s.repo.GetActivity(ctx, resolved, f.IdentityID, f.TimeRange, f.Service)
	case "relationships":
		return s.repo.GetRelationships(ctx, resolved, f.IdentityID, f.Depth, f.EdgeType)
	case "credentials":
		return s.repo.GetCredentialsTab(ctx, resolved, f.IdentityID)
	case "raw":
		return s.repo.GetRaw(ctx, resolved, f.IdentityID)
	default:
		return nil, ErrInvalidIdentityTab
	}
}
