package v1

import (
	"context"
	"fmt"

	models "nhi-backend-api/internal/models/v1"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/scope"
)

type DashboardOverviewService struct {
	repo     *repov1.DashboardOverviewRepository
	resolver *scope.Resolver
}

func NewDashboardOverviewService(repo *repov1.DashboardOverviewRepository, resolver *scope.Resolver) *DashboardOverviewService {
	return &DashboardOverviewService{repo: repo, resolver: resolver}
}

func (s *DashboardOverviewService) GetOverview(ctx context.Context, userID, tenantID, dbName string) (*models.DashboardOverviewResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetOverview(ctx, resolved)
	if err != nil {
		return nil, fmt.Errorf("get tenant-scoped dashboard: %w", err)
	}
	return result, nil
}
