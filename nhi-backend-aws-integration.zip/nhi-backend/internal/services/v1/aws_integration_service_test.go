package v1

import (
	"context"
	"errors"
	"strings"
	"sync"
	"testing"
	"time"

	"nhi-backend-api/internal/awsconnect"
	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
)

const (
	testTenant  = "11111111-1111-1111-1111-111111111111"
	testRoleARN = "arn:aws:iam::222222222222:role/NHIPlatformCollector"
)

type fakeStore struct {
	mu          sync.Mutex
	settings    *models.AWSPlatformSettings
	externalIDs map[string]string
	accounts    map[string]models.AWSAccountRecord // key tenant|account
	claimed     bool
	saveErr     error
	saves       int
}

func newFakeStore() *fakeStore {
	return &fakeStore{
		settings: &models.AWSPlatformSettings{
			AccountID:      "999999999999",
			Region:         "ap-south-1",
			EventBusARN:    "arn:aws:events:ap-south-1:999999999999:event-bus/nhi-central-bus",
			AssumerRoleARN: "arn:aws:iam::999999999999:role/NHIPlatformAssumer",
		},
		externalIDs: map[string]string{},
		accounts:    map[string]models.AWSAccountRecord{},
	}
}

func (f *fakeStore) PlatformSettings(context.Context) (*models.AWSPlatformSettings, error) {
	return f.settings, nil
}

func (f *fakeStore) ExternalID(_ context.Context, tenantID string) (string, bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	id, ok := f.externalIDs[tenantID]
	return id, ok, nil
}

func (f *fakeStore) EnsureExternalID(_ context.Context, tenantID string) (string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if id, ok := f.externalIDs[tenantID]; ok {
		return id, nil
	}
	f.externalIDs[tenantID] = "ext-0123456789abcdef01234567"
	return f.externalIDs[tenantID], nil
}

func (f *fakeStore) ListAccounts(_ context.Context, tenantID string) ([]models.AWSAccountRecord, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := []models.AWSAccountRecord{}
	for _, rec := range f.accounts {
		if rec.TenantID == tenantID {
			out = append(out, rec)
		}
	}
	return out, nil
}

func (f *fakeStore) AccountClaimedByOther(context.Context, string, string) (bool, error) {
	return f.claimed, nil
}

func (f *fakeStore) SaveAccount(_ context.Context, rec models.AWSAccountRecord) (*models.AWSAccountRecord, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.saves++
	if f.saveErr != nil {
		return nil, f.saveErr
	}
	f.accounts[rec.TenantID+"|"+rec.AccountID] = rec
	return &rec, nil
}

type fakeVerifier struct {
	assumeErr  error
	readErr    error
	busErr     error
	events     bool
	eventsErr  error
	gotExtID   string
	busAllowed []string
	block      chan struct{}
}

func (f *fakeVerifier) AssumeRole(_ context.Context, _ awsconnect.Platform, _ awsconnect.RoleARN, externalID string) (*awsconnect.Session, error) {
	if f.block != nil {
		<-f.block
	}
	f.gotExtID = externalID
	if f.assumeErr != nil {
		return nil, f.assumeErr
	}
	return &awsconnect.Session{}, nil
}

func (f *fakeVerifier) TestRead(context.Context, *awsconnect.Session) error { return f.readErr }

func (f *fakeVerifier) AllowAccountOnBus(_ context.Context, _ awsconnect.Platform, accountID string) error {
	if f.busErr != nil {
		return f.busErr
	}
	f.busAllowed = append(f.busAllowed, accountID)
	return nil
}

func (f *fakeVerifier) HasEventsFrom(context.Context, awsconnect.Platform, string, time.Time) (bool, error) {
	return f.events, f.eventsErr
}

func states(checks []models.AWSCheck) string {
	parts := make([]string, len(checks))
	for i, c := range checks {
		parts[i] = c.State
	}
	return strings.Join(parts, ",")
}

func TestVerifyAllPassConnects(t *testing.T) {
	store, verifier := newFakeStore(), &fakeVerifier{events: true}
	svc := NewAWSIntegrationService(store, verifier, 24*time.Hour)

	got, err := svc.Verify(context.Background(), testTenant, "alice@acme.test", "  "+testRoleARN+" ")
	if err != nil {
		t.Fatalf("Verify: %v", err)
	}
	if got.Status != models.AWSStatusConnected || !got.Saved || got.AccountID != "222222222222" {
		t.Fatalf("result = %+v", got)
	}
	if states(got.Checks) != "pass,pass,pass" {
		t.Fatalf("checks = %s", states(got.Checks))
	}
	if verifier.gotExtID == "" || verifier.gotExtID != store.externalIDs[testTenant] {
		t.Fatalf("AssumeRole used external id %q, tenant has %q", verifier.gotExtID, store.externalIDs[testTenant])
	}
	if len(verifier.busAllowed) != 1 || verifier.busAllowed[0] != "222222222222" {
		t.Fatalf("bus permission granted to %v", verifier.busAllowed)
	}
	saved := store.accounts[testTenant+"|222222222222"]
	if saved.Status != models.AWSStatusConnected || saved.LastVerifiedBy != "alice@acme.test" || saved.RoleARN != testRoleARN {
		t.Fatalf("saved = %+v", saved)
	}

	view, err := svc.Get(context.Background(), testTenant, false)
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if view.Status != models.AWSStatusConnected || view.Setup != nil || len(view.Accounts) != 1 {
		t.Fatalf("Get = %+v", view)
	}
}

func TestVerifyAssumeDeniedStoresNothing(t *testing.T) {
	store := newFakeStore()
	verifier := &fakeVerifier{assumeErr: awsconnect.ErrAccessDenied, events: true}
	svc := NewAWSIntegrationService(store, verifier, 24*time.Hour)

	got, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN)
	if err != nil {
		t.Fatalf("Verify: %v", err)
	}
	if got.Status != models.AWSStatusActionNeeded || got.Saved {
		t.Fatalf("result = %+v", got)
	}
	if states(got.Checks) != "fail,skipped,skipped" || got.Checks[0].Fix != "Check the External ID matches" {
		t.Fatalf("checks = %+v", got.Checks)
	}
	if store.saves != 0 || len(verifier.busAllowed) != 0 {
		t.Fatalf("stored %d rows and granted bus access to %v for an unproven account", store.saves, verifier.busAllowed)
	}
}

func TestVerifyFixesMatchSpec(t *testing.T) {
	cases := []struct {
		name    string
		v       *fakeVerifier
		states  string
		fixes   [3]string
		connect bool
	}{
		{"read denied", &fakeVerifier{readErr: awsconnect.ErrAccessDenied, events: true}, "pass,fail,pass", [3]string{"", "Attach SecurityAudit + ViewOnlyAccess", ""}, false},
		{"read empty", &fakeVerifier{readErr: awsconnect.ErrNothingRead, events: true}, "pass,fail,pass", [3]string{"", "Attach SecurityAudit + ViewOnlyAccess", ""}, false},
		{"no events", &fakeVerifier{}, "pass,pass,fail", [3]string{"", "", "Check the EventBridge rule target ARN"}, false},
		{"bus permission error", &fakeVerifier{busErr: errors.New("boom"), events: true}, "pass,pass,error", [3]string{}, false},
		{"event search error", &fakeVerifier{eventsErr: awsconnect.ErrEventSourceNotConfigured}, "pass,pass,error", [3]string{}, false},
		{"assume error is not the client's fault", &fakeVerifier{assumeErr: errors.New("network")}, "error,skipped,skipped", [3]string{}, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			svc := NewAWSIntegrationService(newFakeStore(), tc.v, 24*time.Hour)
			got, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN)
			if err != nil {
				t.Fatalf("Verify: %v", err)
			}
			if states(got.Checks) != tc.states {
				t.Fatalf("states = %s, want %s", states(got.Checks), tc.states)
			}
			for i, c := range got.Checks {
				if c.Fix != tc.fixes[i] {
					t.Fatalf("check %s fix = %q, want %q", c.Key, c.Fix, tc.fixes[i])
				}
			}
			if (got.Status == models.AWSStatusConnected) != tc.connect {
				t.Fatalf("status = %s", got.Status)
			}
		})
	}
}

func TestVerifyRejectsBadInput(t *testing.T) {
	svc := NewAWSIntegrationService(newFakeStore(), &fakeVerifier{events: true}, time.Hour)
	for _, arn := range []string{"", "NHIPlatformCollector", "arn:aws:iam::999999999999:role/NHIPlatformAssumer"} {
		_, err := svc.Verify(context.Background(), testTenant, "alice", arn)
		var invalid *awsconnect.ErrInvalidRoleARN
		if !errors.As(err, &invalid) {
			t.Fatalf("Verify(%q) = %v, want ErrInvalidRoleARN", arn, err)
		}
	}
}

func TestVerifyAccountOfAnotherTenant(t *testing.T) {
	store := newFakeStore()
	store.claimed = true
	svc := NewAWSIntegrationService(store, &fakeVerifier{events: true}, time.Hour)
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("err = %v, want ErrAWSAccountClaimed", err)
	}

	// The race the pre-check cannot see is caught by the unique index.
	store = newFakeStore()
	store.saveErr = repository.ErrAWSAccountClaimed
	svc = NewAWSIntegrationService(store, &fakeVerifier{events: true}, time.Hour)
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("err = %v, want ErrAWSAccountClaimed", err)
	}
}

func TestVerifyPlatformAndAWSUnavailable(t *testing.T) {
	store := newFakeStore()
	store.settings = nil
	svc := NewAWSIntegrationService(store, &fakeVerifier{}, time.Hour)
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); !errors.Is(err, ErrAWSPlatformNotConfigured) {
		t.Fatalf("err = %v, want ErrAWSPlatformNotConfigured", err)
	}
	if _, err := svc.Get(context.Background(), testTenant, true); !errors.Is(err, ErrAWSPlatformNotConfigured) {
		t.Fatalf("Get err = %v, want ErrAWSPlatformNotConfigured", err)
	}
	// A non-admin still sees status without the platform row.
	if view, err := svc.Get(context.Background(), testTenant, false); err != nil || view.Status != models.AWSStatusNotConnected {
		t.Fatalf("Get(non-admin) = %+v, %v", view, err)
	}

	store = newFakeStore()
	store.settings.EventBusARN = "arn:aws:events:us-east-1:999999999999:event-bus/nhi-central-bus"
	svc = NewAWSIntegrationService(store, &fakeVerifier{}, time.Hour)
	if _, err := svc.Get(context.Background(), testTenant, true); !errors.Is(err, ErrAWSPlatformNotConfigured) {
		t.Fatalf("inconsistent platform: err = %v", err)
	}

	svc = NewAWSIntegrationService(newFakeStore(), nil, time.Hour)
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); !errors.Is(err, ErrAWSUnavailable) {
		t.Fatalf("err = %v, want ErrAWSUnavailable", err)
	}
}

func TestVerifyOneAtATimePerTenant(t *testing.T) {
	block := make(chan struct{})
	verifier := &fakeVerifier{events: true, block: block}
	svc := NewAWSIntegrationService(newFakeStore(), verifier, time.Hour)

	done := make(chan error, 1)
	go func() {
		_, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN)
		done <- err
	}()
	// Wait until the first run holds the tenant's slot.
	deadline := time.Now().Add(2 * time.Second)
	for {
		if _, held := svc.running.Load(testTenant); held {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("first verification never started")
		}
		time.Sleep(time.Millisecond)
	}
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); !errors.Is(err, ErrAWSVerifyInProgress) {
		t.Fatalf("second concurrent Verify = %v, want ErrAWSVerifyInProgress", err)
	}
	close(block)
	if err := <-done; err != nil {
		t.Fatalf("first Verify: %v", err)
	}
	if _, err := svc.Verify(context.Background(), testTenant, "alice", testRoleARN); err != nil {
		t.Fatalf("Verify after the first finished: %v", err)
	}
}

func TestGetIssuesExternalIDForAdmins(t *testing.T) {
	store := newFakeStore()
	svc := NewAWSIntegrationService(store, &fakeVerifier{}, time.Hour)
	view, err := svc.Get(context.Background(), testTenant, true)
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if view.Status != models.AWSStatusNotConnected || view.Setup == nil {
		t.Fatalf("Get = %+v", view)
	}
	s := view.Setup
	if s.AccountID != "999999999999" || s.Region != "ap-south-1" || s.ExternalID == "" ||
		s.RoleName != "NHIPlatformCollector" || s.RuleName != "nhi-forward-events" ||
		len(s.ManagedPolicies) != 2 || len(s.EventSources) != 8 {
		t.Fatalf("Setup = %+v", s)
	}
	if again, _ := svc.Get(context.Background(), testTenant, true); again.Setup.ExternalID != s.ExternalID {
		t.Fatal("External ID changed between reads")
	}
}

func TestTenantStatus(t *testing.T) {
	if got := tenantStatus(nil); got != models.AWSStatusNotConnected {
		t.Fatal(got)
	}
	if got := tenantStatus([]models.AWSAccountRecord{{Status: models.AWSStatusActionNeeded}}); got != models.AWSStatusActionNeeded {
		t.Fatal(got)
	}
	if got := tenantStatus([]models.AWSAccountRecord{{Status: models.AWSStatusActionNeeded}, {Status: models.AWSStatusConnected}}); got != models.AWSStatusConnected {
		t.Fatal(got)
	}
}

func TestHumanHours(t *testing.T) {
	for d, want := range map[time.Duration]string{time.Hour: "hour", 24 * time.Hour: "24 hours", 72 * time.Hour: "3 days", 30 * time.Hour: "30 hours"} {
		if got := humanHours(d); got != want {
			t.Fatalf("humanHours(%v) = %q, want %q", d, got, want)
		}
	}
}
