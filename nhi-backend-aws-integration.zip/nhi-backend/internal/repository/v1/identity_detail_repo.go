package v1

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/lib/pq"

	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/scope"
)

// ErrIdentityNotFound is returned when the requested :id has no matching,
// non-deleted row in identities. Handlers must check this with errors.Is
// (never string-match) and translate it to 404.
var ErrIdentityNotFound = errors.New("identity not found")

type IdentityDetailRepository struct{}

func NewIdentityDetailRepository() *IdentityDetailRepository {
	return &IdentityDetailRepository{}
}

// coreIdentity mirrors every column of the identities table (28 columns,
// confirmed via information_schema.columns against the live database —
// same provenance, and cross-checked against the legacy, pre-existing
// internal/repository/inventory/identities_detail.go query, as
// coreCredential in credential_detail_repo.go).
type coreIdentity struct {
	ID                   string
	ARN                  string
	Name                 string
	IdentityType         string
	FunctionalClass      *string
	AccountID            string
	Region               string
	Status               string
	CreatedAtAWS         *time.Time
	FirstSeenAt          *time.Time
	LastSeenAt           *time.Time
	LastActivityAt       *time.Time
	DeletedAt            *time.Time
	VPCID                *string
	SubnetID             *string
	SecurityGroupIDs     []byte
	IsPubliclyAccessible bool
	Tags                 []byte
	Owner                *string
	Environment          *string
	ParentARN            *string
	CloudtrailCreatorARN *string
	DiscoverySource      *string
	ScanID               string
	TypeAttributes       []byte
	RawAPIResponse       []byte
	CreatedAt            *time.Time
	UpdatedAt            *time.Time
	ScopeAccountIDs      []string
	ScopeRegions         []string
}

// loadCoreIdentity fetches the row only if it belongs to the authenticated
// tenant's effective scan and selected account/region scope.
func (r *IdentityDetailRepository) loadCoreIdentity(ctx context.Context, resolved *scope.DataScope, id string) (*coreIdentity, error) {
	if resolved == nil || resolved.DB == nil || resolved.ScanID == "" {
		return nil, ErrIdentityNotFound
	}
	query := fmt.Sprintf(`
		SELECT
			id::text, arn, name, identity_type, functional_class,
			account_id, region, status,
			created_at_aws, first_seen_at, last_seen_at, last_activity_at, deleted_at,
			vpc_id, subnet_id, security_group_ids, COALESCE(is_publicly_accessible, false),
			tags, owner, environment, parent_arn, cloudtrail_creator_arn,
			discovery_source, scan_id, type_attributes, raw_api_response,
			created_at, updated_at
		FROM %s.identities
		WHERE id = $1::uuid AND scan_id = $2
		  AND account_id = ANY($3::text[]) AND region = ANY($4::text[])
		  AND deleted_at IS NULL
		LIMIT 1`, repository.Schema)

	var ci coreIdentity
	err := resolved.DB.QueryRowContext(ctx, query, id, resolved.ScanID, pq.Array(resolved.AccountIDs), pq.Array(resolved.Regions)).Scan(
		&ci.ID, &ci.ARN, &ci.Name, &ci.IdentityType, &ci.FunctionalClass,
		&ci.AccountID, &ci.Region, &ci.Status,
		&ci.CreatedAtAWS, &ci.FirstSeenAt, &ci.LastSeenAt, &ci.LastActivityAt, &ci.DeletedAt,
		&ci.VPCID, &ci.SubnetID, &ci.SecurityGroupIDs, &ci.IsPubliclyAccessible,
		&ci.Tags, &ci.Owner, &ci.Environment, &ci.ParentARN, &ci.CloudtrailCreatorARN,
		&ci.DiscoverySource, &ci.ScanID, &ci.TypeAttributes, &ci.RawAPIResponse,
		&ci.CreatedAt, &ci.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrIdentityNotFound
		}
		return nil, fmt.Errorf("load identity: %w", err)
	}
	ci.ScopeAccountIDs = append([]string(nil), resolved.AccountIDs...)
	ci.ScopeRegions = append([]string(nil), resolved.Regions...)
	return &ci, nil
}

// ── shared derivations ───────────────────────────────────────────────────

func identityAgeDays(ci *coreIdentity) *int {
	if ci.CreatedAtAWS == nil {
		return nil
	}
	d := daysBetween(*ci.CreatedAtAWS, time.Now())
	return &d
}

func identityIdleDays(ci *coreIdentity) *int {
	if ci.LastActivityAt == nil {
		return nil
	}
	d := daysBetween(*ci.LastActivityAt, time.Now())
	return &d
}

// deriveIdentityCategory is a best-effort, heuristic mapping from
// identity_type to a human-facing category. There is no stored "category"
// column in this schema, so this is a presentation-layer convenience only
// (same convention as deriveCategory for credentials in
// credential_detail_repo.go).
func deriveIdentityCategory(identityType string) string {
	switch strings.ToLower(strings.TrimSpace(identityType)) {
	case "ec2_instance", "ec2":
		return "Compute"
	case "lambda_function", "lambda":
		return "Serverless"
	case "ecs_task", "ecs_service", "fargate_task", "eks_pod", "eks_cluster", "container":
		return "Container"
	case "rds_instance", "rds_cluster", "dynamodb_table", "database":
		return "Database"
	case "s3_bucket":
		return "Storage"
	case "iam_role", "iam_user", "service_account":
		return "IAM"
	case "":
		return "Unknown"
	default:
		return strings.ToUpper(identityType[:1]) + identityType[1:]
	}
}

// deriveCredentialResolution is a best-effort, heuristic narrative of how
// this identity's credential was resolved, derived from identity_credentials
// .binding_type and (as a fallback) identities.discovery_source. There is
// no stored "credential_resolution" column in this schema.
func deriveCredentialResolution(bindingType string, discoverySource *string) string {
	switch strings.ToLower(strings.TrimSpace(bindingType)) {
	case "instance_profile":
		return "IAM instance profile association"
	case "execution_role":
		return "Execution role association"
	case "task_role":
		return "Task role association"
	case "service_linked_role", "service_role":
		return "Service-linked role association"
	case "assumed_role", "sts_assume_role":
		return "STS AssumeRole"
	}
	if discoverySource != nil && strings.TrimSpace(*discoverySource) != "" {
		return "Credential binding discovered via " + *discoverySource
	}
	return "Unknown binding mechanism"
}

// expectedTagKeys is a presentation-layer convention for "recommended"
// tags, not a stored configuration — there is no per-tenant required-tags
// table in this schema, so missing_tags is computed against this fixed
// list only.
var expectedTagKeys = []string{"Name", "Environment", "Owner", "CostCenter", "Project", "Team"}

func computeMissingTags(raw []byte) []string {
	missing := make([]string, 0)
	var tags map[string]interface{}
	if len(raw) > 0 {
		_ = json.Unmarshal(raw, &tags)
	}
	for _, k := range expectedTagKeys {
		if _, ok := tags[k]; !ok {
			missing = append(missing, k)
		}
	}
	return missing
}

func jsonArrayLen(raw []byte) int {
	if len(raw) == 0 {
		return 0
	}
	var arr []interface{}
	if err := json.Unmarshal(raw, &arr); err != nil {
		return 0
	}
	return len(arr)
}

// roundPctInt computes used/granted*100 rounded to the nearest integer, or
// nil when granted is zero/unknown (consistent with the +0.5 truncation
// idiom used by round1 elsewhere in this package).
func roundPctInt(used, granted int) *int {
	if granted <= 0 {
		return nil
	}
	v := int((float64(used)/float64(granted))*100 + 0.5)
	return &v
}

// boundCredentialIDs returns the distinct credential ids bound to this
// identity in its own scan.
func (r *IdentityDetailRepository) boundCredentialIDs(ctx context.Context, tenantDB *sql.DB, ci *coreIdentity) ([]string, error) {
	query := fmt.Sprintf(`
		SELECT DISTINCT ic.credential_id::text
		FROM %s.identity_credentials ic
		JOIN %s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id
		WHERE ic.identity_id::text = $1 AND ic.scan_id = $2 AND c.deleted_at IS NULL
		  AND c.account_id = ANY($3::text[]) AND c.region = ANY($4::text[])`, repository.Schema, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, query, ci.ID, ci.ScanID, pq.Array(ci.ScopeAccountIDs), pq.Array(ci.ScopeRegions))
	if err != nil {
		return nil, fmt.Errorf("query bound credential ids: %w", err)
	}
	defer rows.Close()

	var out []string
	for rows.Next() {
		var cid string
		if err := rows.Scan(&cid); err != nil {
			return nil, fmt.Errorf("scan credential id: %w", err)
		}
		out = append(out, cid)
	}
	return out, rows.Err()
}

// loadScanEndTime looks up nhi_scans_aws.scan_end for this identity's own
// scan_id (best-effort — a missing/incomplete scan row simply yields nil).
func (r *IdentityDetailRepository) loadScanEndTime(ctx context.Context, tenantDB *sql.DB, scanID string) *time.Time {
	var t sql.NullTime
	query := fmt.Sprintf(`SELECT scan_end FROM %s.nhi_scans_aws WHERE scan_id = $1 LIMIT 1`, repository.Schema)
	if err := tenantDB.QueryRowContext(ctx, query, scanID).Scan(&t); err != nil || !t.Valid {
		return nil
	}
	v := t.Time
	return &v
}

// ═════════════════════════════════════════════════════════════════════════
// tab=overview — Tables: identities (all 28), identity_credentials,
// credentials, effective_permissions (granted_count), permission_usage
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetOverview(ctx context.Context, resolved *scope.DataScope, id string) (*models.IdentityOverviewResponse, error) {
	tenantDB := resolved.DB
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	boundCreds, err := r.loadBoundCredentialsOverview(ctx, tenantDB, ci)
	if err != nil {
		return nil, err
	}

	resolution := "Unknown binding mechanism"
	if len(boundCreds) > 0 {
		resolution = deriveCredentialResolution(boundCreds[0].BindingType, ci.DiscoverySource)
	} else if ci.DiscoverySource != nil {
		resolution = deriveCredentialResolution("", ci.DiscoverySource)
	}

	resp := &models.IdentityOverviewResponse{
		Tab: "overview",
		Identity: models.IdentityOverviewCore{
			ID: ci.ID, Name: ci.Name, ARN: ci.ARN, IdentityType: ci.IdentityType,
			FunctionalClass: ci.FunctionalClass, Category: deriveIdentityCategory(ci.IdentityType),
			AccountID: ci.AccountID, Region: ci.Region,
			VPCID: ci.VPCID, SubnetID: ci.SubnetID,
			SecurityGroupIDs:     decodeJSON(ci.SecurityGroupIDs),
			Environment:          ci.Environment,
			Owner:                ci.Owner,
			Status:               ci.Status,
			IsPubliclyAccessible: ci.IsPubliclyAccessible,
			CreatedAtAWS:         ci.CreatedAtAWS,
			AgeDays:              identityAgeDays(ci),
			FirstSeenAt:          ci.FirstSeenAt,
			LastSeenAt:           ci.LastSeenAt,
			LastActivityAt:       ci.LastActivityAt,
			IdleDays:             identityIdleDays(ci),
			ParentARN:            ci.ParentARN,
			CreatedBy:            ci.CloudtrailCreatorARN,
		},
		Discovery: models.IdentityDiscovery{
			DiscoverySource:      ci.DiscoverySource,
			CredentialResolution: resolution,
			ScanID:               ci.ScanID,
			LastScanned:          r.loadScanEndTime(ctx, tenantDB, ci.ScanID),
			DataSources:          "AWS API + CloudTrail correlation",
		},
		TypeAttributes:   decodeJSON(ci.TypeAttributes),
		BoundCredentials: boundCreds,
		Tags:             decodeJSON(ci.Tags),
		MissingTags:      computeMissingTags(ci.Tags),
	}

	resp.RiskSignals, err = r.computeIdentityRiskSignals(ctx, tenantDB, ci, boundCreds)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (r *IdentityDetailRepository) loadBoundCredentialsOverview(ctx context.Context, tenantDB *sql.DB, ci *coreIdentity) ([]models.IdentityBoundCredential, error) {
	query := fmt.Sprintf(`
		SELECT c.id::text, COALESCE(c.name,''), COALESCE(c.credential_type,''),
		       COALESCE(ic.binding_type,''), COALESCE(ic.is_primary,false),
		       c.trust_policy, c.attached_policies, c.inline_policies,
		       COALESCE(ep.granted_count,0)
		FROM %[1]s.identity_credentials ic
		JOIN %[1]s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
		LEFT JOIN %[1]s.effective_permissions ep ON ep.credential_id::text = c.id::text AND ep.scan_id = c.scan_id
		WHERE ic.identity_id::text = $1 AND ic.scan_id = $2
		  AND c.account_id = ANY($3::text[]) AND c.region = ANY($4::text[])
		ORDER BY ic.is_primary DESC, c.name NULLS LAST`, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, query, ci.ID, ci.ScanID, pq.Array(ci.ScopeAccountIDs), pq.Array(ci.ScopeRegions))
	if err != nil {
		return nil, fmt.Errorf("query bound credentials: %w", err)
	}
	defer rows.Close()

	out := make([]models.IdentityBoundCredential, 0)
	for rows.Next() {
		var bc models.IdentityBoundCredential
		var trustPolicy, attachedPolicies, inlinePolicies []byte
		var granted int
		if err := rows.Scan(&bc.CredentialID, &bc.Name, &bc.CredentialType, &bc.BindingType, &bc.IsPrimary,
			&trustPolicy, &attachedPolicies, &inlinePolicies, &granted); err != nil {
			return nil, fmt.Errorf("scan bound credential: %w", err)
		}
		bc.GrantedActionsCount = granted
		bc.AttachedPoliciesCount = jsonArrayLen(attachedPolicies)
		bc.InlinePoliciesCount = jsonArrayLen(inlinePolicies)

		if len(trustPolicy) > 0 {
			var rawTrust map[string]interface{}
			if json.Unmarshal(trustPolicy, &rawTrust) == nil {
				for _, st := range parseTrustStatements(rawTrust) {
					if st.Effect == "Allow" && st.PrincipalValue != "" {
						v := st.PrincipalValue
						bc.TrustPrincipal = &v
						break
					}
				}
			}
		}

		var used int
		usedQuery := fmt.Sprintf(`SELECT COUNT(DISTINCT action) FROM %s.permission_usage WHERE credential_id::text = $1 AND scan_id = $2`, repository.Schema)
		_ = tenantDB.QueryRowContext(ctx, usedQuery, bc.CredentialID, ci.ScanID).Scan(&used)
		bc.UsedActionsCount = used
		bc.UtilizationPct = roundPctInt(used, granted)

		out = append(out, bc)
	}
	return out, rows.Err()
}

// computeIdentityRiskSignals builds the 8 risk signals called out explicitly
// by the spec's sample response, in the same order and with the same
// severities.
func (r *IdentityDetailRepository) computeIdentityRiskSignals(ctx context.Context, tenantDB *sql.DB, ci *coreIdentity, bound []models.IdentityBoundCredential) ([]models.RiskSignal, error) {
	stale := ci.LastActivityAt == nil
	if !stale {
		stale = daysBetween(*ci.LastActivityAt, time.Now()) > 90
	}

	var neverRotated, expiringOrExpired, crossAccountTrust, wildcardResource bool

	for _, bc := range bound {
		var lastRotated, expiresAt sql.NullTime
		var trustPolicy, permsRaw []byte
		var credAccountID string

		q := fmt.Sprintf(`SELECT last_rotated_at, expires_at, trust_policy, account_id FROM %s.credentials WHERE id::text = $1 AND scan_id = $2`, repository.Schema)
		if err := tenantDB.QueryRowContext(ctx, q, bc.CredentialID, ci.ScanID).Scan(&lastRotated, &expiresAt, &trustPolicy, &credAccountID); err != nil {
			continue // best-effort: a credential row that vanished mid-request shouldn't fail the whole response
		}

		if !lastRotated.Valid {
			neverRotated = true
		}
		if expiresAt.Valid {
			if expiresAt.Time.Before(time.Now()) {
				expiringOrExpired = true
			} else if daysBetween(time.Now(), expiresAt.Time) <= 30 {
				expiringOrExpired = true
			}
		}
		if len(trustPolicy) > 0 {
			var rawTrust map[string]interface{}
			if json.Unmarshal(trustPolicy, &rawTrust) == nil {
				risk := computeTrustRisk(parseTrustStatements(rawTrust), credAccountID)
				if risk.HasExternalAccount {
					crossAccountTrust = true
				}
			}
		}

		epQuery := fmt.Sprintf(`SELECT permissions FROM %s.effective_permissions WHERE credential_id::text = $1 AND scan_id = $2 LIMIT 1`, repository.Schema)
		if err := tenantDB.QueryRowContext(ctx, epQuery, bc.CredentialID, ci.ScanID).Scan(&permsRaw); err == nil && len(permsRaw) > 0 {
			var entries []map[string]interface{}
			if json.Unmarshal(permsRaw, &entries) == nil {
				for _, e := range entries {
					for _, key := range []string{"resource_arn", "resource", "Resource"} {
						if v, ok := e[key].(string); ok && v == "*" {
							wildcardResource = true
							break
						}
					}
					if wildcardResource {
						break
					}
				}
			}
		}
	}

	noOwner := ci.Owner == nil || strings.TrimSpace(*ci.Owner) == ""
	noVPC := ci.VPCID == nil || strings.TrimSpace(*ci.VPCID) == ""

	return []models.RiskSignal{
		{Signal: "Publicly accessible", Status: ci.IsPubliclyAccessible, Severity: "critical"},
		{Signal: "Stale (no activity > 90d)", Status: stale, Severity: "high"},
		{Signal: "No owner attribution", Status: noOwner, Severity: "medium"},
		{Signal: "Credential never rotated", Status: neverRotated, Severity: "high"},
		{Signal: "Credential expired/expiring", Status: expiringOrExpired, Severity: "critical"},
		{Signal: "Cross-account trust", Status: crossAccountTrust, Severity: "medium"},
		{Signal: "Wildcard resource scope", Status: wildcardResource, Severity: "high"},
		{Signal: "No VPC", Status: noVPC, Severity: "medium"},
	}, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=permissions — Tables: identity_credentials, effective_permissions
// (permissions JSONB — unnested here), permission_usage, credentials
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetPermissions(ctx context.Context, resolved *scope.DataScope, id, service string, usedOnly *bool) (*models.IdentityPermissionsResponse, error) {
	tenantDB := resolved.DB
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	resp := &models.IdentityPermissionsResponse{
		Tab:             "permissions",
		Permissions:     []models.IdentityPermissionItem{},
		PolicyBreakdown: []models.IdentityPolicyBreakdownItem{},
	}

	credIDs, err := r.boundCredentialIDs(ctx, tenantDB, ci)
	if err != nil {
		return nil, err
	}
	if len(credIDs) == 0 {
		return resp, nil
	}

	type usageKey struct{ credID, service, action string }
	usedMap := make(map[usageKey]*time.Time)

	usageQuery := fmt.Sprintf(`
		SELECT credential_id::text, COALESCE(service,''), COALESCE(action,''), last_used_at
		FROM %s.permission_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2`, repository.Schema)
	rows, err := tenantDB.QueryContext(ctx, usageQuery, pqStringArray(credIDs), ci.ScanID)
	if err != nil {
		return nil, fmt.Errorf("query permission_usage: %w", err)
	}
	for rows.Next() {
		var k usageKey
		var lastUsed sql.NullTime
		if err := rows.Scan(&k.credID, &k.service, &k.action, &lastUsed); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan permission_usage: %w", err)
		}
		if lastUsed.Valid {
			t := lastUsed.Time
			usedMap[k] = &t
		} else {
			usedMap[k] = nil
		}
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	type policyAgg struct {
		policyType  string
		total, used int
	}
	policyAggs := map[string]*policyAgg{}
	var policyOrder []string

	granted, usedCount := 0, 0

	getStr := func(m map[string]interface{}, keys ...string) string {
		for _, k := range keys {
			if v, ok := m[k].(string); ok && v != "" {
				return v
			}
		}
		return ""
	}

	for _, credID := range credIDs {
		var permsRaw []byte
		q := fmt.Sprintf(`SELECT permissions FROM %s.effective_permissions WHERE credential_id::text = $1 AND scan_id = $2 LIMIT 1`, repository.Schema)
		if err := tenantDB.QueryRowContext(ctx, q, credID, ci.ScanID).Scan(&permsRaw); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				continue
			}
			return nil, fmt.Errorf("query effective_permissions: %w", err)
		}
		var entries []map[string]interface{}
		if len(permsRaw) > 0 {
			_ = json.Unmarshal(permsRaw, &entries)
		}

		for _, e := range entries {
			svc := getStr(e, "service", "Service")
			action := getStr(e, "action", "Action")
			if service != "" && !strings.EqualFold(svc, service) {
				continue
			}
			resourceArn := getStr(e, "resource_arn", "resource", "Resource")
			if resourceArn == "" {
				resourceArn = "*"
			}
			effect := getStr(e, "effect", "Effect")
			if effect == "" {
				effect = "Allow"
			}
			policySource := getStr(e, "policy_source", "policy_name", "PolicySource")
			if policySource == "" {
				policySource = "unknown"
			}
			policyType := getStr(e, "policy_type", "PolicyType")
			if policyType == "" {
				policyType = "managed"
			}

			key := usageKey{credID: credID, service: svc, action: action}
			lastUsedPtr, used := usedMap[key]

			if usedOnly != nil && used != *usedOnly {
				continue
			}

			resp.Permissions = append(resp.Permissions, models.IdentityPermissionItem{
				Service: svc, Action: action, ResourceARN: resourceArn, Effect: effect,
				PolicySource: policySource, PolicyType: policyType, Used: used,
				LastUsedAt: lastUsedPtr, SourceIPs: []string{},
			})

			granted++
			if used {
				usedCount++
			}

			pa, ok := policyAggs[policySource]
			if !ok {
				pa = &policyAgg{policyType: policyType}
				policyAggs[policySource] = pa
				policyOrder = append(policyOrder, policySource)
			}
			pa.total++
			if used {
				pa.used++
			}
		}
	}

	sort.Strings(policyOrder)
	for _, name := range policyOrder {
		pa := policyAggs[name]
		resp.PolicyBreakdown = append(resp.PolicyBreakdown, models.IdentityPolicyBreakdownItem{
			PolicyName: name, PolicyType: pa.policyType, TotalPermissions: pa.total, UsedPermissions: pa.used,
		})
	}

	unused := granted - usedCount
	utilPct := 0
	if granted > 0 {
		utilPct = int((float64(usedCount)/float64(granted))*100 + 0.5)
	}
	resp.Summary = models.IdentityPermissionsSummary{
		GrantedCount: granted, UsedCount: usedCount, UnusedCount: unused, UtilizationPct: utilPct,
	}

	return resp, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=activity — Tables: identity_credentials, identity_usage
//
// identity_usage.identity_id is stored as bigint while identities.id is
// uuid (confirmed in credential_detail_repo.go), so activity cannot be
// joined to an identity directly. Instead, activity is attributed through
// this identity's bound credentials (identity_credentials.credential_id,
// a reliable uuid-to-uuid bridge), matching the spec's own table list for
// this tab ("identity_credentials, identity_usage").
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetActivity(ctx context.Context, resolved *scope.DataScope, id, timeRange, service string) (*models.IdentityActivityResponse, error) {
	tenantDB := resolved.DB
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	resp := &models.IdentityActivityResponse{
		Tab: "activity", TimeRange: timeRange,
		VolumeChart:  []models.VolumePoint{},
		RecentEvents: []models.IdentityRecentEvent{},
		ErrorEvents:  []models.IdentityErrorEvent{},
		Analytics: models.IdentityActivityAnalytics{
			SourceIPs: []models.IPPct{}, ActiveRegions: []models.RegionCnt{},
			TopServices: []models.ServicePct{}, TopActions: []models.IdentityActionCount{},
			PeakHours: []models.IdentityHourCount{}, UsagePattern: "Dormant",
		},
		EventsPagination: models.EventsPagination{Page: 1, PageSize: 50},
	}

	credIDs, err := r.boundCredentialIDs(ctx, tenantDB, ci)
	if err != nil {
		return nil, err
	}
	if len(credIDs) == 0 {
		return resp, nil
	}

	days := parseTimeRangeDays(timeRange)
	since := time.Now().AddDate(0, 0, -days)

	credArray := pqStringArray(credIDs)
	svcFilter := ""
	baseArgs := []interface{}{credArray, ci.ScanID, since}
	if service != "" {
		svcFilter = " AND service = $4"
		baseArgs = append(baseArgs, service)
	}

	// volume_chart
	volQuery := fmt.Sprintf(`
		SELECT DATE(COALESCE(window_start, first_seen)) AS d, SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(window_start, first_seen) >= $3 %s
		GROUP BY d ORDER BY d`, repository.Schema, svcFilter)
	rows, err := tenantDB.QueryContext(ctx, volQuery, baseArgs...)
	if err != nil {
		return nil, fmt.Errorf("query volume chart: %w", err)
	}
	for rows.Next() {
		var d time.Time
		var cnt int
		if err := rows.Scan(&d, &cnt); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan volume point: %w", err)
		}
		resp.VolumeChart = append(resp.VolumeChart, models.VolumePoint{Date: d.Format("2006-01-02"), Count: cnt})
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	// recent_events (newest first, capped at 50) + total count for pagination
	var totalCount int
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*) FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3 %s`, repository.Schema, svcFilter)
	if err := tenantDB.QueryRowContext(ctx, countQuery, baseArgs...).Scan(&totalCount); err != nil {
		return nil, fmt.Errorf("count identity_usage: %w", err)
	}

	evQuery := fmt.Sprintf(`
		SELECT last_seen, COALESCE(event_name,''), COALESCE(service,''), resource_arn
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3 %s
		ORDER BY last_seen DESC NULLS LAST
		LIMIT 50`, repository.Schema, svcFilter)
	rows, err = tenantDB.QueryContext(ctx, evQuery, baseArgs...)
	if err != nil {
		return nil, fmt.Errorf("query recent events: %w", err)
	}
	for rows.Next() {
		var ev models.IdentityRecentEvent
		var resourceArn sql.NullString
		if err := rows.Scan(&ev.EventTime, &ev.EventName, &ev.Service, &resourceArn); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan recent event: %w", err)
		}
		if resourceArn.Valid {
			v := resourceArn.String
			ev.ResourceARN = &v
		}
		resp.RecentEvents = append(resp.RecentEvents, ev)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	pageSize := 50
	totalPages := 0
	if pageSize > 0 {
		totalPages = (totalCount + pageSize - 1) / pageSize
	}
	resp.EventsPagination = models.EventsPagination{Page: 1, PageSize: pageSize, TotalCount: totalCount, TotalPages: totalPages}

	// analytics.top_services
	svcQuery := fmt.Sprintf(`
		SELECT COALESCE(service,'unknown'), SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3 %s
		GROUP BY service ORDER BY SUM(event_count) DESC`, repository.Schema, svcFilter)
	rows, err = tenantDB.QueryContext(ctx, svcQuery, baseArgs...)
	if err != nil {
		return nil, fmt.Errorf("query top services: %w", err)
	}
	total := 0
	type svcCount struct {
		service string
		count   int
	}
	var svcCounts []svcCount
	for rows.Next() {
		var sc svcCount
		if err := rows.Scan(&sc.service, &sc.count); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan top service: %w", err)
		}
		svcCounts = append(svcCounts, sc)
		total += sc.count
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()
	for _, sc := range svcCounts {
		pct := 0.0
		if total > 0 {
			pct = (float64(sc.count) / float64(total)) * 100
		}
		resp.Analytics.TopServices = append(resp.Analytics.TopServices, models.ServicePct{Service: sc.service, Pct: round1(pct), Count: sc.count})
	}

	// analytics.top_actions
	actionQuery := fmt.Sprintf(`
		SELECT COALESCE(action,'unknown'), SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3 %s
		GROUP BY action ORDER BY SUM(event_count) DESC LIMIT 10`, repository.Schema, svcFilter)
	rows, err = tenantDB.QueryContext(ctx, actionQuery, baseArgs...)
	if err != nil {
		return nil, fmt.Errorf("query top actions: %w", err)
	}
	for rows.Next() {
		var ac models.IdentityActionCount
		if err := rows.Scan(&ac.Action, &ac.Count); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan top action: %w", err)
		}
		resp.Analytics.TopActions = append(resp.Analytics.TopActions, ac)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	// analytics.peak_hours (identity_usage has no timezone-aware "hour of
	// day" concept beyond window_start, so this reflects window_start's
	// hour as stored, not a normalized local time).
	hourQuery := fmt.Sprintf(`
		SELECT EXTRACT(HOUR FROM window_start)::int AS hr, SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND window_start IS NOT NULL AND window_start >= $3 %s
		GROUP BY hr ORDER BY SUM(event_count) DESC LIMIT 5`, repository.Schema, svcFilter)
	rows, err = tenantDB.QueryContext(ctx, hourQuery, baseArgs...)
	if err != nil {
		return nil, fmt.Errorf("query peak hours: %w", err)
	}
	for rows.Next() {
		var hc models.IdentityHourCount
		if err := rows.Scan(&hc.Hour, &hc.Count); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan peak hour: %w", err)
		}
		resp.Analytics.PeakHours = append(resp.Analytics.PeakHours, hc)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	// analytics.active_regions: identity_usage carries no region column —
	// the only region signal available is the identity's own static
	// region, reported as a single entry when there was any activity.
	if ci.Region != "" && total > 0 {
		resp.Analytics.ActiveRegions = append(resp.Analytics.ActiveRegions, models.RegionCnt{Region: ci.Region, Count: total})
	}

	// usage_pattern: heuristic based on the fraction of days-in-range with
	// any recorded activity (same convention as credential_detail_repo.go).
	distinctDaysQuery := fmt.Sprintf(`
		SELECT COUNT(DISTINCT DATE(COALESCE(window_start, first_seen)))
		FROM %s.identity_usage
		WHERE credential_id::text = ANY($1) AND scan_id = $2 AND COALESCE(window_start, first_seen) >= $3 %s`, repository.Schema, svcFilter)
	var distinctDays int
	_ = tenantDB.QueryRowContext(ctx, distinctDaysQuery, baseArgs...).Scan(&distinctDays)

	rangeDays := int(time.Since(since).Hours() / 24)
	if rangeDays <= 0 {
		rangeDays = 1
	}
	switch {
	case distinctDays == 0:
		resp.Analytics.UsagePattern = "Dormant"
	case float64(distinctDays)/float64(rangeDays) >= 0.6:
		resp.Analytics.UsagePattern = "Continuous"
	default:
		resp.Analytics.UsagePattern = "Intermittent"
	}

	return resp, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=relationships — Tables: trust_edges, identities, credentials, resources
//
// Reuses the BFS graph-walk helpers already implemented for Credential
// Detail's relationships tab (loadEdgesTouching / resolveNodes /
// relationshipLabel / graphEdgeRow / nodeInfo) by instantiating the
// (stateless, zero-field) CredentialDetailRepository — both types live in
// this same package. Only the entry point (this identity's own ARN/scan_id
// instead of a credential's) differs.
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetRelationships(ctx context.Context, resolved *scope.DataScope, id string, depth int, edgeType string) (*models.RelationshipsResponse, error) {
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	cd := &CredentialDetailRepository{}

	allEdges, arns, err := cd.traverseGraph(ctx, resolved, ci.ARN, ci.ScanID, depth, parseEdgeTypes(edgeType))
	if err != nil {
		return nil, err
	}
	nodeInfoMap, err := cd.resolveNodes(ctx, resolved, arns)
	if err != nil {
		return nil, err
	}

	nodes := make([]models.GraphNode, 0, len(arns))
	for _, arn := range arns {
		info := nodeInfoMap[arn]
		nodes = append(nodes, models.GraphNode{ARN: arn, Name: info.name, Type: info.nodeType, Subtype: info.subtype, IsCurrent: arn == ci.ARN})
	}
	sort.Slice(nodes, func(i, j int) bool { return nodes[i].ARN < nodes[j].ARN })

	edges := make([]models.GraphEdge, 0, len(allEdges))
	relTable := make([]models.RelationshipRow, 0)
	for _, e := range allEdges {
		t := e.CreatedAt
		edges = append(edges, models.GraphEdge{Source: e.Source, Target: e.Target, EdgeType: e.EdgeType, LastObservedAt: &t})

		if e.Source != ci.ARN && e.Target != ci.ARN {
			continue
		}
		direction := "outbound"
		targetArn := e.Target
		if e.Target == ci.ARN {
			direction = "inbound"
			targetArn = e.Source
		}
		info := nodeInfoMap[targetArn]
		lastActive := &t
		if info.nodeType == "identity" && info.lastActivityAt != nil {
			lastActive = info.lastActivityAt
		}
		relTable = append(relTable, models.RelationshipRow{
			Relationship: relationshipLabel(e.EdgeType, direction), Direction: direction,
			TargetARN: targetArn, TargetName: info.name, TargetType: info.nodeType, LastActive: lastActive,
		})
	}

	return &models.RelationshipsResponse{
		Tab:               "relationships",
		Graph:             models.RelationshipGraph{Nodes: nodes, Edges: edges},
		RelationshipTable: relTable,
	}, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=credentials — Tables: identity_credentials, credentials (all 31),
// effective_permissions (granted_count, permissions), permission_usage
//
// Reuses loadCoreCredential / ageDays / daysSinceRotation / rotationOverdue
// / decodeJSON / nilIfEmptyStr / loadAssumableRoles from
// credential_detail_repo.go (same package) for every bound credential.
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetCredentialsTab(ctx context.Context, resolved *scope.DataScope, id string) (*models.IdentityCredentialsTabResponse, error) {
	tenantDB := resolved.DB
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	bindingQuery := fmt.Sprintf(`
		SELECT ic.credential_id::text, COALESCE(ic.binding_type,''), ic.binding_source, COALESCE(ic.is_primary,false)
		FROM %s.identity_credentials ic
		JOIN %s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
		WHERE ic.identity_id::text = $1 AND ic.scan_id = $2
		  AND c.account_id = ANY($3::text[]) AND c.region = ANY($4::text[])
		ORDER BY ic.is_primary DESC`, repository.Schema, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, bindingQuery, ci.ID, ci.ScanID, pq.Array(ci.ScopeAccountIDs), pq.Array(ci.ScopeRegions))
	if err != nil {
		return nil, fmt.Errorf("query identity_credentials: %w", err)
	}

	type binding struct {
		credID        string
		bindingType   string
		bindingSource *string
		isPrimary     bool
	}
	var bindings []binding
	for rows.Next() {
		var b binding
		if err := rows.Scan(&b.credID, &b.bindingType, &b.bindingSource, &b.isPrimary); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan identity_credentials: %w", err)
		}
		bindings = append(bindings, b)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	rows.Close()

	cd := &CredentialDetailRepository{}
	resp := &models.IdentityCredentialsTabResponse{Tab: "credentials", Credentials: make([]models.IdentityCredentialDetailItem, 0, len(bindings))}

	for _, b := range bindings {
		c, err := cd.loadCoreCredential(ctx, resolved, b.credID)
		if err != nil {
			if errors.Is(err, ErrCredentialNotFound) {
				continue // bound credential row vanished (e.g. deleted since scan) — skip, don't fail the whole tab
			}
			return nil, err
		}

		var rawTrust map[string]interface{}
		if len(c.TrustPolicy) > 0 {
			_ = json.Unmarshal(c.TrustPolicy, &rawTrust)
		}
		statements := parseTrustStatements(rawTrust)
		principals := make([]models.TrustPrincipal, 0, len(statements))
		for _, st := range statements {
			if st.PrincipalValue == "" {
				continue
			}
			var cond *string
			if st.HasCondition {
				cond = nilIfEmptyStr(st.ConditionDesc)
			}
			isExternal := false
			if st.Effect == "Allow" && st.PrincipalType == "AWS" {
				for _, part := range strings.Split(st.PrincipalValue, ",") {
					acct := principalAccountID(strings.TrimSpace(part))
					if acct != "" && c.AccountID != "" && acct != c.AccountID {
						isExternal = true
					}
				}
			}
			principals = append(principals, models.TrustPrincipal{
				Principal: st.PrincipalValue, Type: st.PrincipalType, Condition: cond, IsExternal: isExternal,
			})
		}

		assumableRoles, err := cd.loadAssumableRoles(ctx, tenantDB, c)
		if err != nil {
			return nil, err
		}

		resp.Credentials = append(resp.Credentials, models.IdentityCredentialDetailItem{
			CredentialID: c.ID, Name: c.Name, ARN: c.ARN, CredentialType: c.CredentialType,
			BindingType: b.bindingType, BindingSource: b.bindingSource, IsPrimary: b.isPrimary,
			TrustPolicy: decodeJSON(c.TrustPolicy), TrustPrincipals: principals,
			AttachedPolicies: decodeJSON(c.AttachedPolicies), InlinePolicies: decodeJSON(c.InlinePolicies),
			Lifecycle: models.IdentityCredLifecycle{
				CreatedAtAWS: c.CreatedAtAWS, LastUsedAt: c.LastUsedAt, LastRotatedAt: c.LastRotatedAt,
				AgeDays: ageDays(c), DaysSinceRotation: daysSinceRotation(c),
				RotationEnabled: c.RotationEnabled, RotationIntervalDays: c.RotationIntervalDays,
				RotationOverdue: rotationOverdue(c), ExpiresAt: c.ExpiresAt,
				MaxSessionDuration: c.MaxSessionDuration, PermissionBoundaryARN: c.PermissionBoundary,
			},
			AssumableRoles: assumableRoles,
		})
	}

	return resp, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=raw — Tables: identities (all 28), identity_credentials, credentials
// (raw_api_response, trust_policy, attached_policies, inline_policies,
// type_attributes), effective_permissions (permissions)
// ═════════════════════════════════════════════════════════════════════════

func (r *IdentityDetailRepository) GetRaw(ctx context.Context, resolved *scope.DataScope, id string) (*models.IdentityRawResponse, error) {
	tenantDB := resolved.DB
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	record := map[string]interface{}{
		"id": ci.ID, "arn": ci.ARN, "name": ci.Name, "identity_type": ci.IdentityType,
		"functional_class": ci.FunctionalClass, "account_id": ci.AccountID, "region": ci.Region,
		"status": ci.Status, "created_at_aws": ci.CreatedAtAWS, "first_seen_at": ci.FirstSeenAt,
		"last_seen_at": ci.LastSeenAt, "last_activity_at": ci.LastActivityAt, "deleted_at": ci.DeletedAt,
		"vpc_id": ci.VPCID, "subnet_id": ci.SubnetID, "security_group_ids": decodeJSON(ci.SecurityGroupIDs),
		"is_publicly_accessible": ci.IsPubliclyAccessible, "tags": decodeJSON(ci.Tags),
		"owner": ci.Owner, "environment": ci.Environment, "parent_arn": ci.ParentARN,
		"cloudtrail_creator_arn": ci.CloudtrailCreatorARN, "discovery_source": ci.DiscoverySource,
		"scan_id": ci.ScanID, "type_attributes": decodeJSON(ci.TypeAttributes),
		"raw_api_response": decodeJSON(ci.RawAPIResponse), "created_at": ci.CreatedAt, "updated_at": ci.UpdatedAt,
	}

	// resolved_credential: derived from the identity's primary (or, lacking
	// one, first-bound) credential — there is no dedicated "resolved
	// credential" table, so this is assembled from identity_credentials +
	// credentials.
	var resolvedCred interface{}
	primaryQuery := fmt.Sprintf(`
		SELECT credential_id::text, COALESCE(binding_type,'')
		FROM %s.identity_credentials ic
		JOIN %s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
		WHERE ic.identity_id::text = $1 AND ic.scan_id = $2
		  AND c.account_id = ANY($3::text[]) AND c.region = ANY($4::text[])
		ORDER BY ic.is_primary DESC
		LIMIT 1`, repository.Schema, repository.Schema)
	var primID, bindingType string
	if err := tenantDB.QueryRowContext(ctx, primaryQuery, ci.ID, ci.ScanID, pq.Array(ci.ScopeAccountIDs), pq.Array(ci.ScopeRegions)).Scan(&primID, &bindingType); err == nil {
		cd := &CredentialDetailRepository{}
		if c, err := cd.loadCoreCredential(ctx, resolved, primID); err == nil {
			resolvedCred = map[string]interface{}{
				"roleArn":          c.ARN,
				"assumedVia":       bindingType,
				"attachedPolicies": jsonArrayLen(c.AttachedPolicies),
				"inlinePolicies":   jsonArrayLen(c.InlinePolicies),
			}
		}
	}

	return &models.IdentityRawResponse{
		Tab: "raw", IdentityRecord: record, RawAPIResponse: decodeJSON(ci.RawAPIResponse),
		ResolvedCredential: resolvedCred, TypeAttributes: decodeJSON(ci.TypeAttributes),
	}, nil
}
