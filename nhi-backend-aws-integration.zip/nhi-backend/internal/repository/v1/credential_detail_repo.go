package v1

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/lib/pq"

	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/scope"
)

// pqStringArray adapts a []string for use as a Postgres text[] query
// argument (used with the `= ANY($n)` idiom).
func pqStringArray(ss []string) interface{} {
	return pq.Array(ss)
}

// ErrCredentialNotFound is returned when the requested :id has no matching,
// non-deleted row in credentials. Handlers must check this with errors.Is
// (never string-match) and translate it to 404.
var ErrCredentialNotFound = errors.New("credential not found")

type CredentialDetailRepository struct{}

func NewCredentialDetailRepository() *CredentialDetailRepository {
	return &CredentialDetailRepository{}
}

// coreCredential mirrors every column of the credentials table (31 columns,
// confirmed via information_schema.columns against the live database).
type coreCredential struct {
	ID                   string
	ARN                  string
	Name                 string
	CredentialType       string
	AccountID            string
	Region               string
	Status               string
	CreatedAtAWS         *time.Time
	FirstSeenAt          *time.Time
	LastSeenAt           *time.Time
	DeletedAt            *time.Time
	LastUsedAt           *time.Time
	LastRotatedAt        *time.Time
	ExpiresAt            *time.Time
	RotationEnabled      bool
	RotationIntervalDays *int
	Tags                 []byte
	OwnerPrincipalARN    *string
	TrustPolicy          []byte
	AttachedPolicies     []byte
	InlinePolicies       []byte
	PermissionBoundary   *string
	MaxSessionDuration   *int
	PrivilegeLevel       *int
	AssumableRoleARNs    []byte
	DiscoverySource      *string
	ScanID               string
	TypeAttributes       []byte
	RawAPIResponse       []byte
	CreatedAt            *time.Time
	UpdatedAt            *time.Time
	ScopeAccountIDs      []string
	ScopeRegions         []string
}

// loadCoreCredential fetches a credential only when its id belongs to the
// caller's effective completed scan and selected account/region scope. Every
// related query uses this row's own scan_id.
func (r *CredentialDetailRepository) loadCoreCredential(ctx context.Context, resolved *scope.DataScope, id string) (*coreCredential, error) {
	if resolved == nil || resolved.DB == nil || resolved.ScanID == "" {
		return nil, ErrCredentialNotFound
	}
	query := fmt.Sprintf(`
		SELECT
			id::text, arn, name, credential_type, account_id, region, status,
			created_at_aws, first_seen_at, last_seen_at, deleted_at,
			last_used_at, last_rotated_at, expires_at,
			COALESCE(rotation_enabled, false), rotation_interval_days,
			tags, owner_principal_arn, trust_policy, attached_policies, inline_policies,
			permission_boundary_arn, max_session_duration, privilege_level,
			assumable_role_arns, discovery_source, scan_id, type_attributes,
			raw_api_response, created_at, updated_at
		FROM %s.credentials
		WHERE id = $1::uuid AND scan_id = $2
		  AND account_id = ANY($3::text[]) AND region = ANY($4::text[])
		  AND deleted_at IS NULL
		LIMIT 1`, repository.Schema)

	var c coreCredential
	err := resolved.DB.QueryRowContext(ctx, query, id, resolved.ScanID, pq.Array(resolved.AccountIDs), pq.Array(resolved.Regions)).Scan(
		&c.ID, &c.ARN, &c.Name, &c.CredentialType, &c.AccountID, &c.Region, &c.Status,
		&c.CreatedAtAWS, &c.FirstSeenAt, &c.LastSeenAt, &c.DeletedAt,
		&c.LastUsedAt, &c.LastRotatedAt, &c.ExpiresAt,
		&c.RotationEnabled, &c.RotationIntervalDays,
		&c.Tags, &c.OwnerPrincipalARN, &c.TrustPolicy, &c.AttachedPolicies, &c.InlinePolicies,
		&c.PermissionBoundary, &c.MaxSessionDuration, &c.PrivilegeLevel,
		&c.AssumableRoleARNs, &c.DiscoverySource, &c.ScanID, &c.TypeAttributes,
		&c.RawAPIResponse, &c.CreatedAt, &c.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrCredentialNotFound
		}
		return nil, fmt.Errorf("load credential: %w", err)
	}
	c.ScopeAccountIDs = append([]string(nil), resolved.AccountIDs...)
	c.ScopeRegions = append([]string(nil), resolved.Regions...)
	return &c, nil
}

// ── shared derivations (reused across tabs) ─────────────────────────────

func daysBetween(from, to time.Time) int {
	return int(to.Sub(from).Hours() / 24)
}

func ageDays(c *coreCredential) *int {
	if c.CreatedAtAWS == nil {
		return nil
	}
	d := daysBetween(*c.CreatedAtAWS, time.Now())
	return &d
}

func idleDays(c *coreCredential) *int {
	if c.LastUsedAt == nil {
		return nil
	}
	d := daysBetween(*c.LastUsedAt, time.Now())
	return &d
}

func daysSinceRotation(c *coreCredential) *int {
	ref := c.LastRotatedAt
	if ref == nil {
		ref = c.CreatedAtAWS
	}
	if ref == nil {
		return nil
	}
	d := daysBetween(*ref, time.Now())
	return &d
}

func daysUntilExpiry(c *coreCredential) *int {
	if c.ExpiresAt == nil {
		return nil
	}
	d := daysBetween(time.Now(), *c.ExpiresAt)
	return &d
}

func rotationOverdue(c *coreCredential) bool {
	if !c.RotationEnabled || c.RotationIntervalDays == nil {
		return false
	}
	ref := c.LastRotatedAt
	if ref == nil {
		ref = c.CreatedAtAWS
	}
	if ref == nil {
		return false
	}
	return time.Now().After(ref.AddDate(0, 0, *c.RotationIntervalDays))
}

func rotationStatus(c *coreCredential) string {
	if !c.RotationEnabled {
		return "Disabled"
	}
	if rotationOverdue(c) {
		return "Overdue"
	}
	return "Enabled"
}

// deriveCategory is a best-effort, heuristic mapping from credential_type to
// a human-facing category. There is no stored "category" column in this
// schema, so this is a presentation-layer convenience only.
func deriveCategory(credentialType string) string {
	switch strings.ToLower(strings.TrimSpace(credentialType)) {
	case "iam_role", "iam_user", "iam_group", "access_key", "iam_policy":
		return "IAM"
	case "secret", "secrets_manager_secret", "secretsmanager_secret":
		return "Secrets Manager"
	case "kms_key", "kms":
		return "KMS"
	case "service_account", "service_account_key":
		return "Service Account"
	case "instance_profile":
		return "Compute"
	case "":
		return "Unknown"
	default:
		return strings.ToUpper(credentialType[:1]) + credentialType[1:]
	}
}

func decodeJSON(raw []byte) interface{} {
	if len(raw) == 0 {
		return nil
	}
	var v interface{}
	if err := json.Unmarshal(raw, &v); err != nil {
		return nil
	}
	return v
}

func nilIfEmptyStr(s string) *string {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	return &s
}

// ═════════════════════════════════════════════════════════════════════════
// tab=overview — Tables: credentials (all 31), identity_credentials, identities
// ═════════════════════════════════════════════════════════════════════════

func (r *CredentialDetailRepository) GetOverview(ctx context.Context, resolved *scope.DataScope, id string) (*models.OverviewResponse, error) {
	tenantDB := resolved.DB
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	boundIdentities, err := r.loadBoundIdentities(ctx, tenantDB, c)
	if err != nil {
		return nil, err
	}

	var rawTrust map[string]interface{}
	if len(c.TrustPolicy) > 0 {
		_ = json.Unmarshal(c.TrustPolicy, &rawTrust)
	}
	statements := parseTrustStatements(rawTrust)
	risk := computeTrustRisk(statements, c.AccountID)

	resp := &models.OverviewResponse{
		Tab: "overview",
		Credential: models.OverviewCredential{
			ID:                    c.ID,
			Name:                  c.Name,
			ARN:                   c.ARN,
			CredentialType:        c.CredentialType,
			Category:              deriveCategory(c.CredentialType),
			AccountID:             c.AccountID,
			Region:                c.Region,
			Status:                c.Status,
			OwnerPrincipalARN:     c.OwnerPrincipalARN,
			CreatedAtAWS:          c.CreatedAtAWS,
			AgeDays:               ageDays(c),
			LastUsedAt:            c.LastUsedAt,
			IdleDays:              idleDays(c),
			LastRotatedAt:         c.LastRotatedAt,
			DaysSinceRotation:     daysSinceRotation(c),
			RotationEnabled:       c.RotationEnabled,
			RotationIntervalDays:  c.RotationIntervalDays,
			RotationStatus:        rotationStatus(c),
			ExpiresAt:             c.ExpiresAt,
			DaysUntilExpiry:       daysUntilExpiry(c),
			MaxSessionDuration:    c.MaxSessionDuration,
			PermissionBoundaryARN: c.PermissionBoundary,
		},
		BoundIdentities: boundIdentities,
		TypeAttributes:  decodeJSON(c.TypeAttributes),
	}

	resp.RiskSignals = buildRiskSignals(c, len(boundIdentities), risk)
	return resp, nil
}

func (r *CredentialDetailRepository) loadBoundIdentities(ctx context.Context, tenantDB *sql.DB, c *coreCredential) ([]models.BoundIdentity, error) {
	query := fmt.Sprintf(`
		SELECT i.id::text, COALESCE(i.name,''), COALESCE(i.identity_type,''),
		       COALESCE(i.account_id,''), COALESCE(i.status,''), i.last_activity_at,
		       COALESCE(ic.binding_type,'')
		FROM %[1]s.identity_credentials ic
		JOIN %[1]s.identities i ON i.id::text = ic.identity_id::text AND i.scan_id = ic.scan_id
		WHERE ic.credential_id::text = $1 AND ic.scan_id = $2
		  AND i.deleted_at IS NULL AND i.account_id = ANY($3::text[]) AND i.region = ANY($4::text[])
		ORDER BY i.name NULLS LAST`, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, query, c.ID, c.ScanID, pq.Array(c.ScopeAccountIDs), pq.Array(c.ScopeRegions))
	if err != nil {
		return nil, fmt.Errorf("query bound identities: %w", err)
	}
	defer rows.Close()

	out := make([]models.BoundIdentity, 0)
	for rows.Next() {
		var bi models.BoundIdentity
		if err := rows.Scan(&bi.IdentityID, &bi.Name, &bi.IdentityType, &bi.AccountID, &bi.Status, &bi.LastActivityAt, &bi.BindingType); err != nil {
			return nil, fmt.Errorf("scan bound identity: %w", err)
		}
		out = append(out, bi)
	}
	return out, rows.Err()
}

func buildRiskSignals(c *coreCredential, boundCount int, risk trustRisk) []models.RiskSignal {
	expired := c.ExpiresAt != nil && c.ExpiresAt.Before(time.Now())
	expSoon := false
	if c.ExpiresAt != nil && !expired {
		d := daysUntilExpiry(c)
		if d != nil && *d <= 30 {
			expSoon = true
		}
	}
	idle := idleDays(c)
	stale := idle != nil && *idle > 90

	return []models.RiskSignal{
		{Signal: "Orphaned (no identity bound)", Status: boundCount == 0, Severity: "high"},
		{Signal: "Overshared (3+ identities)", Status: boundCount >= 3, Severity: "medium"},
		{Signal: "Never rotated", Status: c.LastRotatedAt == nil, Severity: "high"},
		{Signal: "Rotation overdue", Status: rotationOverdue(c), Severity: "high"},
		{Signal: "Expiring soon (< 30 days)", Status: expSoon, Severity: "high"},
		{Signal: "Already expired", Status: expired, Severity: "critical"},
		{Signal: "Stale (unused > 90 days)", Status: stale, Severity: "high"},
		{Signal: "External trust (cross-account)", Status: risk.HasExternalAccount, Severity: "medium"},
		{Signal: "Wildcard trust (Principal: *)", Status: risk.HasWildcardPrincipal, Severity: "critical"},
		{Signal: "No condition on trust policy", Status: risk.AnyAllowWithoutCond, Severity: "high"},
		{Signal: "No permission boundary", Status: c.PermissionBoundary == nil || *c.PermissionBoundary == "", Severity: "medium"},
		{Signal: "Wildcard resource in policies", Status: hasWildcardResourceInPermissions(c), Severity: "high"},
	}
}

// hasWildcardResourceInPermissions is a placeholder that is overridden by
// GetOverview's caller when effective_permissions data is available; kept
// as a cheap false default here since overview does not join
// effective_permissions per the spec's table list for this tab.
func hasWildcardResourceInPermissions(c *coreCredential) bool {
	// attached_policies / inline_policies are stored as app-summarized JSON
	// (name/type/arn/permissions_count, not full policy documents), so a
	// "Resource": "*" style scan isn't possible against them. Without a
	// join to effective_permissions (which overview's table list does not
	// include), this signal is conservatively reported as unknown/false.
	_ = c
	return false
}

// ═════════════════════════════════════════════════════════════════════════
// tab=trust — Tables: credentials, effective_permissions (permissions jsonb
// unnested for summary), permission_usage
// ═════════════════════════════════════════════════════════════════════════

func (r *CredentialDetailRepository) GetTrust(ctx context.Context, resolved *scope.DataScope, id string) (*models.TrustResponse, error) {
	tenantDB := resolved.DB
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	var rawTrust map[string]interface{}
	if len(c.TrustPolicy) > 0 {
		_ = json.Unmarshal(c.TrustPolicy, &rawTrust)
	}
	statements := parseTrustStatements(rawTrust)

	principals := make([]models.TrustPrincipal, 0, len(statements))
	var warnings []string
	for _, st := range statements {
		if st.PrincipalValue == "" {
			continue
		}
		var cond *string
		if st.HasCondition {
			cond = nilIfEmptyStr(st.ConditionDesc)
		}
		isExternal := false
		if st.Effect == "Allow" && st.PrincipalType == "AWS" {
			for _, part := range strings.Split(st.PrincipalValue, ",") {
				acct := principalAccountID(strings.TrimSpace(part))
				if acct != "" && c.AccountID != "" && acct != c.AccountID {
					isExternal = true
				}
			}
		}
		principals = append(principals, models.TrustPrincipal{
			Principal:  st.PrincipalValue,
			Type:       st.PrincipalType,
			Condition:  cond,
			IsExternal: isExternal,
		})
		if st.Effect == "Allow" {
			if st.PrincipalValue == "*" {
				warnings = append(warnings, "Trust policy allows a wildcard principal (*)")
			}
			if isExternal {
				warnings = append(warnings, fmt.Sprintf("Cross-account trust granted to principal '%s'", st.PrincipalValue))
			}
			if !st.HasCondition && st.PrincipalType == "AWS" {
				warnings = append(warnings, fmt.Sprintf("No condition restricts assumption by '%s'", st.PrincipalValue))
			}
		}
	}
	if warnings == nil {
		warnings = []string{}
	}

	effSummary, err := r.loadEffectivePermissionsSummary(ctx, tenantDB, c)
	if err != nil {
		return nil, err
	}

	assumableRoles, err := r.loadAssumableRoles(ctx, tenantDB, c)
	if err != nil {
		return nil, err
	}

	return &models.TrustResponse{
		Tab: "trust",
		TrustPolicy: models.TrustPolicyBlock{
			Raw:        decodeJSON(c.TrustPolicy),
			Principals: principals,
			Warnings:   warnings,
		},
		AttachedPolicies:            decodeJSON(c.AttachedPolicies),
		InlinePolicies:              decodeJSON(c.InlinePolicies),
		EffectivePermissionsSummary: effSummary,
		AssumableRoles:              assumableRoles,
		PermissionBoundary: models.PermissionBoundary{
			BoundaryARN: c.PermissionBoundary,
			// Not derivable from this schema: only the boundary policy's ARN
			// is stored, not its document, so the effective restriction and
			// blocked-action list cannot be computed.
			EffectiveRestriction: nil,
			ActionsBlocked:       []string{},
		},
	}, nil
}

// loadEffectivePermissionsSummary decodes effective_permissions.permissions
// (an app-defined JSONB array, NOT a standardized AWS format) defensively:
// each element is expected to carry some combination of service/Service,
// action/Action, resource/resource_arn/Resource and effect/Effect keys —
// exact key casing is tolerated. If the real shape differs, this degrades
// to an empty summary rather than erroring.
func (r *CredentialDetailRepository) loadEffectivePermissionsSummary(ctx context.Context, tenantDB *sql.DB, c *coreCredential) ([]models.EffectivePermSummary, error) {
	query := fmt.Sprintf(`
		SELECT permissions
		FROM %s.effective_permissions
		WHERE credential_id::text = $1 AND scan_id = $2
		LIMIT 1`, repository.Schema)

	var raw []byte
	err := tenantDB.QueryRowContext(ctx, query, c.ID, c.ScanID).Scan(&raw)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return []models.EffectivePermSummary{}, nil
		}
		return nil, fmt.Errorf("query effective_permissions: %w", err)
	}

	var entries []map[string]interface{}
	if err := json.Unmarshal(raw, &entries); err != nil {
		return []models.EffectivePermSummary{}, nil
	}

	type agg struct {
		allowed, denied int
		resources       map[string]struct{}
	}
	byService := map[string]*agg{}
	var order []string

	getStr := func(m map[string]interface{}, keys ...string) string {
		for _, k := range keys {
			if v, ok := m[k].(string); ok && v != "" {
				return v
			}
		}
		return ""
	}

	for _, e := range entries {
		service := getStr(e, "service", "Service")
		if service == "" {
			service = "unknown"
		}
		effect := strings.ToLower(getStr(e, "effect", "Effect"))
		resource := getStr(e, "resource_arn", "resource", "Resource")

		a, ok := byService[service]
		if !ok {
			a = &agg{resources: map[string]struct{}{}}
			byService[service] = a
			order = append(order, service)
		}
		if effect == "deny" {
			a.denied++
		} else {
			a.allowed++
		}
		if resource != "" {
			a.resources[resource] = struct{}{}
		}
	}

	sort.Strings(order)
	out := make([]models.EffectivePermSummary, 0, len(order))
	for _, svc := range order {
		a := byService[svc]
		scope := "Scoped"
		if _, ok := a.resources["*"]; ok {
			scope = "*"
		} else if len(a.resources) == 0 {
			scope = "Unknown"
		} else if len(a.resources) == 1 {
			for res := range a.resources {
				scope = res
			}
		}
		out = append(out, models.EffectivePermSummary{
			Service:        svc,
			AllowedActions: a.allowed,
			DeniedActions:  a.denied,
			ResourceScope:  scope,
		})
	}
	return out, nil
}

var arnAccountRe = regexp.MustCompile(`arn:aws[a-z0-9-]*:[a-z0-9-]+:[a-z0-9-]*:(\d{12}):`)

// loadAssumableRoles enriches credentials.assumable_role_arns (a JSONB array
// of ARN strings) with the target account id (parsed from the ARN) and, on a
// best-effort basis, trust_edges.conditions for the matching edge plus the
// most recent sts:AssumeRole usage recorded in permission_usage.
func (r *CredentialDetailRepository) loadAssumableRoles(ctx context.Context, tenantDB *sql.DB, c *coreCredential) ([]models.AssumableRole, error) {
	var arns []string
	if len(c.AssumableRoleARNs) > 0 {
		_ = json.Unmarshal(c.AssumableRoleARNs, &arns)
	}
	out := make([]models.AssumableRole, 0, len(arns))
	for _, arn := range arns {
		role := models.AssumableRole{TargetRoleARN: arn}
		if m := arnAccountRe.FindStringSubmatch(arn); m != nil {
			role.TargetAccount = m[1]
		}

		// trust_edges condition lookup (best-effort; edge_type naming is not
		// standardized in this schema, so match on the ARN pair only).
		var condRaw []byte
		condQuery := fmt.Sprintf(`
			SELECT conditions FROM %s.trust_edges
			WHERE source_arn = $1 AND target_arn = $2 AND scan_id = $3
			ORDER BY created_at DESC LIMIT 1`, repository.Schema)
		if err := tenantDB.QueryRowContext(ctx, condQuery, c.ARN, arn, c.ScanID).Scan(&condRaw); err == nil && len(condRaw) > 0 {
			s := string(condRaw)
			role.Conditions = &s
		}

		// Most recent recorded use of this credential assuming that role.
		var lastAssumed sql.NullTime
		usageQuery := fmt.Sprintf(`
			SELECT MAX(last_used_at) FROM %s.permission_usage
			WHERE credential_id::text = $1 AND resource_arn = $2 AND scan_id = $3
			  AND (action ILIKE '%%assumerole%%' OR service ILIKE 'sts')`, repository.Schema)
		if err := tenantDB.QueryRowContext(ctx, usageQuery, c.ID, arn, c.ScanID).Scan(&lastAssumed); err == nil && lastAssumed.Valid {
			t := lastAssumed.Time
			role.LastAssumed = &t
		}

		out = append(out, role)
	}
	return out, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=activity — Tables: identity_usage, identities
// ═════════════════════════════════════════════════════════════════════════

func (r *CredentialDetailRepository) GetActivity(ctx context.Context, resolved *scope.DataScope, id, timeRange string) (*models.ActivityResponse, error) {
	tenantDB := resolved.DB
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	days := parseTimeRangeDays(timeRange)
	since := time.Now().AddDate(0, 0, -days)

	volumeChart, err := r.loadVolumeChart(ctx, tenantDB, c, since)
	if err != nil {
		return nil, err
	}
	recentEvents, totalCount, err := r.loadRecentEvents(ctx, tenantDB, c, since)
	if err != nil {
		return nil, err
	}
	usingIdentities, err := r.loadBoundIdentitiesAsUsage(ctx, tenantDB, c)
	if err != nil {
		return nil, err
	}
	analytics, err := r.loadActivityAnalytics(ctx, tenantDB, c, since)
	if err != nil {
		return nil, err
	}

	const pageSize = 50
	totalPages := 0
	if pageSize > 0 {
		totalPages = (totalCount + pageSize - 1) / pageSize
	}

	return &models.ActivityResponse{
		Tab:                           "activity",
		TimeRange:                     timeRange,
		VolumeChart:                   volumeChart,
		RecentEvents:                  recentEvents,
		IdentitiesUsingThisCredential: usingIdentities,
		Analytics:                     analytics,
		EventsPagination: models.EventsPagination{
			Page: 1, PageSize: pageSize, TotalCount: totalCount, TotalPages: totalPages,
		},
	}, nil
}

func parseTimeRangeDays(tr string) int {
	tr = strings.ToLower(strings.TrimSpace(tr))
	if tr == "" {
		return 90
	}
	if tr == "all" {
		return 36500 // ~100 years — effectively "no lower bound"
	}
	if strings.HasSuffix(tr, "d") {
		if n, err := strconv.Atoi(strings.TrimSuffix(tr, "d")); err == nil && n > 0 {
			return n
		}
	}
	return 90
}

func (r *CredentialDetailRepository) loadVolumeChart(ctx context.Context, tenantDB *sql.DB, c *coreCredential, since time.Time) ([]models.VolumePoint, error) {
	query := fmt.Sprintf(`
		SELECT DATE(COALESCE(window_start, first_seen)) AS d, SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = $1 AND scan_id = $2
		  AND COALESCE(window_start, first_seen) >= $3
		GROUP BY d
		ORDER BY d`, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, query, c.ID, c.ScanID, since)
	if err != nil {
		return nil, fmt.Errorf("query volume chart: %w", err)
	}
	defer rows.Close()

	out := make([]models.VolumePoint, 0)
	for rows.Next() {
		var d time.Time
		var cnt int
		if err := rows.Scan(&d, &cnt); err != nil {
			return nil, fmt.Errorf("scan volume point: %w", err)
		}
		out = append(out, models.VolumePoint{Date: d.Format("2006-01-02"), Count: cnt})
	}
	return out, rows.Err()
}

// loadRecentEvents returns identity_usage rows (newest first, capped at 50)
// plus the total matching row count for pagination metadata. identity_usage
// is a pre-aggregated table (counts per window), NOT a raw CloudTrail event
// log, so source_ip/region/user_agent/error_code are not available and are
// always returned as null.
func (r *CredentialDetailRepository) loadRecentEvents(ctx context.Context, tenantDB *sql.DB, c *coreCredential, since time.Time) ([]models.RecentEvent, int, error) {
	var totalCount int
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*) FROM %s.identity_usage
		WHERE credential_id::text = $1 AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3`, repository.Schema)
	if err := tenantDB.QueryRowContext(ctx, countQuery, c.ID, c.ScanID, since).Scan(&totalCount); err != nil {
		return nil, 0, fmt.Errorf("count identity_usage: %w", err)
	}

	query := fmt.Sprintf(`
		SELECT last_seen, COALESCE(event_name,''), COALESCE(service,''), resource_arn, COALESCE(event_count,0)
		FROM %s.identity_usage
		WHERE credential_id::text = $1 AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3
		ORDER BY last_seen DESC NULLS LAST
		LIMIT 50`, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, query, c.ID, c.ScanID, since)
	if err != nil {
		return nil, 0, fmt.Errorf("query recent events: %w", err)
	}
	defer rows.Close()

	out := make([]models.RecentEvent, 0)
	for rows.Next() {
		var ev models.RecentEvent
		var resourceArn sql.NullString
		if err := rows.Scan(&ev.EventTime, &ev.EventName, &ev.Service, &resourceArn, &ev.EventCount); err != nil {
			return nil, 0, fmt.Errorf("scan recent event: %w", err)
		}
		if resourceArn.Valid {
			v := resourceArn.String
			ev.ResourceARN = &v
		}
		out = append(out, ev)
	}
	return out, totalCount, rows.Err()
}

// loadBoundIdentitiesAsUsage lists identities bound to this credential
// (via identity_credentials, a reliable uuid-to-uuid bridge). It does NOT
// attempt to attribute individual identity_usage events to a specific
// identity: identity_usage.identity_id is stored as bigint while
// identities.id is uuid, so no reliable join between them exists in this
// schema. last_action/last_action_time are therefore always null here —
// see loadRecentEvents for credential-level (not per-identity) activity.
func (r *CredentialDetailRepository) loadBoundIdentitiesAsUsage(ctx context.Context, tenantDB *sql.DB, c *coreCredential) ([]models.UsingIdentity, error) {
	bound, err := r.loadBoundIdentities(ctx, tenantDB, c)
	if err != nil {
		return nil, err
	}
	out := make([]models.UsingIdentity, 0, len(bound))
	for _, b := range bound {
		out = append(out, models.UsingIdentity{
			IdentityID:   b.IdentityID,
			Name:         b.Name,
			IdentityType: b.IdentityType,
		})
	}
	return out, nil
}

func (r *CredentialDetailRepository) loadActivityAnalytics(ctx context.Context, tenantDB *sql.DB, c *coreCredential, since time.Time) (models.ActivityAnalytics, error) {
	analytics := models.ActivityAnalytics{
		SourceIPs:     []models.IPPct{}, // identity_usage has no source_ip column
		ActiveRegions: []models.RegionCnt{},
		TopServices:   []models.ServicePct{},
		ErrorRatePct:  nil, // identity_usage has no error tracking column
	}

	// top_services: real data, grouped by the `service` column.
	svcQuery := fmt.Sprintf(`
		SELECT COALESCE(service,'unknown'), SUM(event_count)::int
		FROM %s.identity_usage
		WHERE credential_id::text = $1 AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3
		GROUP BY service
		ORDER BY SUM(event_count) DESC`, repository.Schema)

	rows, err := tenantDB.QueryContext(ctx, svcQuery, c.ID, c.ScanID, since)
	if err != nil {
		return analytics, fmt.Errorf("query top services: %w", err)
	}
	defer rows.Close()

	total := 0
	type svcCount struct {
		service string
		count   int
	}
	var svcCounts []svcCount
	for rows.Next() {
		var sc svcCount
		if err := rows.Scan(&sc.service, &sc.count); err != nil {
			return analytics, fmt.Errorf("scan top service: %w", err)
		}
		svcCounts = append(svcCounts, sc)
		total += sc.count
	}
	if err := rows.Err(); err != nil {
		return analytics, err
	}
	for _, sc := range svcCounts {
		pct := 0.0
		if total > 0 {
			pct = (float64(sc.count) / float64(total)) * 100
		}
		analytics.TopServices = append(analytics.TopServices, models.ServicePct{
			Service: sc.service, Pct: round1(pct), Count: sc.count,
		})
	}

	// active_regions: identity_usage carries no region column either. The
	// only region signal available is the credential's own static region,
	// so report it as a single entry (not a true per-call usage breakdown).
	if c.Region != "" && total > 0 {
		analytics.ActiveRegions = append(analytics.ActiveRegions, models.RegionCnt{Region: c.Region, Count: total})
	}

	// usage_pattern: heuristic based on the fraction of days-in-range with
	// any recorded activity.
	distinctDaysQuery := fmt.Sprintf(`
		SELECT COUNT(DISTINCT DATE(COALESCE(window_start, first_seen)))
		FROM %s.identity_usage
		WHERE credential_id::text = $1 AND scan_id = $2 AND COALESCE(window_start, first_seen) >= $3`, repository.Schema)
	var distinctDays int
	_ = tenantDB.QueryRowContext(ctx, distinctDaysQuery, c.ID, c.ScanID, since).Scan(&distinctDays)

	rangeDays := int(time.Since(since).Hours() / 24)
	if rangeDays <= 0 {
		rangeDays = 1
	}
	switch {
	case distinctDays == 0:
		analytics.UsagePattern = "Dormant"
	case float64(distinctDays)/float64(rangeDays) >= 0.6:
		analytics.UsagePattern = "Continuous"
	default:
		analytics.UsagePattern = "Intermittent"
	}

	return analytics, nil
}

func round1(f float64) float64 {
	return float64(int(f*10+0.5)) / 10
}

// ═════════════════════════════════════════════════════════════════════════
// tab=rotation — Tables: credentials
// ═════════════════════════════════════════════════════════════════════════

func (r *CredentialDetailRepository) GetRotation(ctx context.Context, resolved *scope.DataScope, id string) (*models.RotationResponse, error) {
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	// NOTE: the spec's sample shows a multi-event rotation history (Created,
	// Rotated x2) with actor attribution ("By admin@company.com"). That
	// requires a dedicated audit/history table which does not exist in this
	// schema (the spec itself lists only "credentials" as the backing table
	// for this tab). The timeline below is therefore limited to what a
	// single credentials row can actually support: creation + the single
	// most recent rotation timestamp it stores.
	var timeline []models.RotationEvent
	if c.CreatedAtAWS != nil {
		details := "Discovered by scan"
		if c.DiscoverySource != nil && *c.DiscoverySource != "" {
			details = "Discovered via " + *c.DiscoverySource
		}
		timeline = append(timeline, models.RotationEvent{Date: *c.CreatedAtAWS, Event: "Created", Details: details})
	}
	if c.LastRotatedAt != nil && (c.CreatedAtAWS == nil || !c.LastRotatedAt.Equal(*c.CreatedAtAWS)) {
		timeline = append(timeline, models.RotationEvent{Date: *c.LastRotatedAt, Event: "Rotated", Details: "Most recent rotation on record"})
	}
	if timeline == nil {
		timeline = []models.RotationEvent{}
	}

	var nextExpected *time.Time
	if c.RotationEnabled && c.RotationIntervalDays != nil {
		ref := c.LastRotatedAt
		if ref == nil {
			ref = c.CreatedAtAWS
		}
		if ref != nil {
			t := ref.AddDate(0, 0, *c.RotationIntervalDays)
			nextExpected = &t
		}
	}

	return &models.RotationResponse{
		Tab:      "rotation",
		Timeline: timeline,
		Configuration: models.RotationConfig{
			AutoRotation:         c.RotationEnabled,
			RotationIntervalDays: c.RotationIntervalDays,
			LastRotation:         c.LastRotatedAt,
			NextExpected:         nextExpected,
			Status:               rotationStatus(c),
			RotationLambdaARN:    nil, // not tracked anywhere in this schema
		},
		Lifecycle: models.RotationLifecycle{
			CreatedAtAWS:      c.CreatedAtAWS,
			AgeDays:           ageDays(c),
			DaysSinceRotation: daysSinceRotation(c),
			ExpiresAt:         c.ExpiresAt,
			DaysUntilExpiry:   daysUntilExpiry(c),
		},
	}, nil
}

// ═════════════════════════════════════════════════════════════════════════
// tab=relationships — Tables: trust_edges, identities, credentials, resources
// ═════════════════════════════════════════════════════════════════════════

type graphEdgeRow struct {
	Source    string
	Target    string
	EdgeType  string
	CreatedAt time.Time
}

func (r *CredentialDetailRepository) GetRelationships(ctx context.Context, resolved *scope.DataScope, id string, depth int, edgeType string) (*models.RelationshipsResponse, error) {
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	allEdges, arns, err := r.traverseGraph(ctx, resolved, c.ARN, c.ScanID, depth, parseEdgeTypes(edgeType))
	if err != nil {
		return nil, err
	}
	nodeInfo, err := r.resolveNodes(ctx, resolved, arns)
	if err != nil {
		return nil, err
	}

	nodes := make([]models.GraphNode, 0, len(arns))
	for _, arn := range arns {
		info := nodeInfo[arn]
		nodes = append(nodes, models.GraphNode{
			ARN: arn, Name: info.name, Type: info.nodeType, Subtype: info.subtype,
			IsCurrent: arn == c.ARN,
		})
	}
	sort.Slice(nodes, func(i, j int) bool { return nodes[i].ARN < nodes[j].ARN })

	edges := make([]models.GraphEdge, 0, len(allEdges))
	relTable := make([]models.RelationshipRow, 0)
	for _, e := range allEdges {
		t := e.CreatedAt
		edges = append(edges, models.GraphEdge{
			Source: e.Source, Target: e.Target, EdgeType: e.EdgeType, LastObservedAt: &t,
		})

		// Build the flat relationship_table only for edges that directly
		// touch the credential itself (first hop from its own perspective).
		if e.Source != c.ARN && e.Target != c.ARN {
			continue
		}
		direction := "outbound"
		targetArn := e.Target
		if e.Target == c.ARN {
			direction = "inbound"
			targetArn = e.Source
		}
		info := nodeInfo[targetArn]
		lastActive := &t
		if info.nodeType == "identity" && info.lastActivityAt != nil {
			lastActive = info.lastActivityAt
		}
		relTable = append(relTable, models.RelationshipRow{
			Relationship: relationshipLabel(e.EdgeType, direction),
			Direction:    direction,
			TargetARN:    targetArn,
			TargetName:   info.name,
			TargetType:   info.nodeType,
			LastActive:   lastActive,
		})
	}

	return &models.RelationshipsResponse{
		Tab: "relationships",
		Graph: models.RelationshipGraph{
			Nodes: nodes,
			Edges: edges,
		},
		RelationshipTable: relTable,
	}, nil
}

func relationshipLabel(edgeType, direction string) string {
	et := strings.ToUpper(strings.TrimSpace(edgeType))
	switch {
	case et == "BOUND_TO" && direction == "inbound":
		return "Used by"
	case et == "BOUND_TO" && direction == "outbound":
		return "Bound to"
	case strings.Contains(et, "ASSUME") && direction == "outbound":
		return "Can assume"
	case strings.Contains(et, "ASSUME") && direction == "inbound":
		return "Assumable by"
	case et == "":
		return "Related"
	default:
		return strings.Title(strings.ToLower(strings.ReplaceAll(et, "_", " ")))
	}
}

func (r *CredentialDetailRepository) loadEdgesTouching(ctx context.Context, tenantDB *sql.DB, scanID string, arns []string, edgeTypes []string) ([]graphEdgeRow, error) {
	if len(arns) == 0 {
		return nil, nil
	}
	args := []interface{}{scanID, pqStringArray(arns)}
	typeFilter := ""
	if len(edgeTypes) > 0 {
		args = append(args, pqStringArray(edgeTypes))
		typeFilter = "AND edge_type = ANY($3)"
	}

	query := fmt.Sprintf(`
		SELECT source_arn, target_arn, COALESCE(edge_type,''), created_at
		FROM %s.trust_edges
		WHERE scan_id = $1 AND (source_arn = ANY($2) OR target_arn = ANY($2)) %s`, repository.Schema, typeFilter)

	rows, err := tenantDB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query trust_edges: %w", err)
	}
	defer rows.Close()

	var out []graphEdgeRow
	for rows.Next() {
		var e graphEdgeRow
		if err := rows.Scan(&e.Source, &e.Target, &e.EdgeType, &e.CreatedAt); err != nil {
			return nil, fmt.Errorf("scan trust_edge: %w", err)
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

type nodeInfo struct {
	name           string
	nodeType       string
	subtype        string
	lastActivityAt *time.Time
}

// resolveNodes classifies each ARN as a credential, identity, or resource
// (checked in that order) by looking it up across all three tables scoped
// to the same scan. Anything not found in any of them falls back to
// type "unknown" with a name derived from the ARN's final path segment.
// resolveNodes classifies each ARN as a credential, identity or resource.
//
// The credential and identity lookups carry the caller's account/region
// predicate, so a node that exists in the tenant database but outside the
// selected accounts simply does not resolve. Combined with the edge pruning in
// traverseGraph, that means an out-of-scope neighbour can never be rendered,
// even if it is reachable in trust_edges.
func (r *CredentialDetailRepository) resolveNodes(ctx context.Context, resolved *scope.DataScope, arns []string) (map[string]nodeInfo, error) {
	result := make(map[string]nodeInfo, len(arns))
	if resolved == nil || resolved.DB == nil || len(arns) == 0 {
		return result, nil
	}
	tenantDB := resolved.DB
	scanID := resolved.ScanID
	arnArray := pqStringArray(arns)

	credQuery := fmt.Sprintf(`SELECT arn, COALESCE(name,''), COALESCE(credential_type,'') FROM %s.credentials WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL AND account_id = ANY($3::text[]) AND region = ANY($4::text[])`, repository.Schema)
	if rows, err := tenantDB.QueryContext(ctx, credQuery, scanID, arnArray, pqStringArray(resolved.AccountIDs), pqStringArray(resolved.Regions)); err == nil {
		for rows.Next() {
			var arn, name, subtype string
			if rows.Scan(&arn, &name, &subtype) == nil {
				result[arn] = nodeInfo{name: name, nodeType: "credential", subtype: subtype}
			}
		}
		rows.Close()
	}

	idQuery := fmt.Sprintf(`SELECT arn, COALESCE(name,''), COALESCE(identity_type,''), last_activity_at FROM %s.identities WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL AND account_id = ANY($3::text[]) AND region = ANY($4::text[])`, repository.Schema)
	if rows, err := tenantDB.QueryContext(ctx, idQuery, scanID, arnArray, pqStringArray(resolved.AccountIDs), pqStringArray(resolved.Regions)); err == nil {
		for rows.Next() {
			var arn, name, subtype string
			var lastActivity sql.NullTime
			if rows.Scan(&arn, &name, &subtype, &lastActivity) == nil {
				if _, exists := result[arn]; !exists {
					ni := nodeInfo{name: name, nodeType: "identity", subtype: subtype}
					if lastActivity.Valid {
						t := lastActivity.Time
						ni.lastActivityAt = &t
					}
					result[arn] = ni
				}
			}
		}
		rows.Close()
	}

	resQuery := fmt.Sprintf(`SELECT arn, COALESCE(name,''), COALESCE(resource_type,'') FROM %s.resources WHERE scan_id=$1 AND arn = ANY($2)`, repository.Schema)
	if rows, err := tenantDB.QueryContext(ctx, resQuery, scanID, arnArray); err == nil {
		for rows.Next() {
			var arn, name, subtype string
			if rows.Scan(&arn, &name, &subtype) == nil {
				if _, exists := result[arn]; !exists {
					result[arn] = nodeInfo{name: name, nodeType: "resource", subtype: subtype}
				}
			}
		}
		rows.Close()
	}

	for _, arn := range arns {
		if _, ok := result[arn]; !ok {
			result[arn] = nodeInfo{name: arnTail(arn), nodeType: "unknown", subtype: ""}
		}
	}
	return result, nil
}

func arnTail(arn string) string {
	parts := strings.Split(arn, "/")
	if len(parts) > 1 {
		return parts[len(parts)-1]
	}
	parts = strings.Split(arn, ":")
	return parts[len(parts)-1]
}

// ═════════════════════════════════════════════════════════════════════════
// tab=raw — Tables: credentials (all 31), effective_permissions (permissions)
// ═════════════════════════════════════════════════════════════════════════

func (r *CredentialDetailRepository) GetRaw(ctx context.Context, resolved *scope.DataScope, id string) (*models.RawResponse, error) {
	tenantDB := resolved.DB
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}

	var effPerms []byte
	effQuery := fmt.Sprintf(`SELECT permissions FROM %s.effective_permissions WHERE credential_id::text=$1 AND scan_id=$2 LIMIT 1`, repository.Schema)
	_ = tenantDB.QueryRowContext(ctx, effQuery, c.ID, c.ScanID).Scan(&effPerms)

	record := map[string]interface{}{
		"id":                      c.ID,
		"arn":                     c.ARN,
		"name":                    c.Name,
		"credential_type":         c.CredentialType,
		"account_id":              c.AccountID,
		"region":                  c.Region,
		"status":                  c.Status,
		"created_at_aws":          c.CreatedAtAWS,
		"first_seen_at":           c.FirstSeenAt,
		"last_seen_at":            c.LastSeenAt,
		"deleted_at":              c.DeletedAt,
		"last_used_at":            c.LastUsedAt,
		"last_rotated_at":         c.LastRotatedAt,
		"expires_at":              c.ExpiresAt,
		"rotation_enabled":        c.RotationEnabled,
		"rotation_interval_days":  c.RotationIntervalDays,
		"tags":                    decodeJSON(c.Tags),
		"owner_principal_arn":     c.OwnerPrincipalARN,
		"trust_policy":            decodeJSON(c.TrustPolicy),
		"attached_policies":       decodeJSON(c.AttachedPolicies),
		"inline_policies":         decodeJSON(c.InlinePolicies),
		"permission_boundary_arn": c.PermissionBoundary,
		"max_session_duration":    c.MaxSessionDuration,
		"privilege_level":         c.PrivilegeLevel,
		"assumable_role_arns":     decodeJSON(c.AssumableRoleARNs),
		"discovery_source":        c.DiscoverySource,
		"scan_id":                 c.ScanID,
		"type_attributes":         decodeJSON(c.TypeAttributes),
		"raw_api_response":        decodeJSON(c.RawAPIResponse),
		"created_at":              c.CreatedAt,
		"updated_at":              c.UpdatedAt,
	}

	return &models.RawResponse{
		Tab:                  "raw",
		CredentialRecord:     record,
		RawAPIResponse:       decodeJSON(c.RawAPIResponse),
		TrustPolicy:          decodeJSON(c.TrustPolicy),
		AttachedPolicies:     decodeJSON(c.AttachedPolicies),
		InlinePolicies:       decodeJSON(c.InlinePolicies),
		TypeAttributes:       decodeJSON(c.TypeAttributes),
		EffectivePermissions: decodeJSON(effPerms),
	}, nil
}
