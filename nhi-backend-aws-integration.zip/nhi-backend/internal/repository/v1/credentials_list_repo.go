package v1

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/lib/pq"

	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/scope"
)

type CredentialsRepository struct{}

func NewCredentialsRepository() *CredentialsRepository {
	return &CredentialsRepository{}
}

// credentialSortColumns maps the public `sort_by` query value to the column
// name exposed by the final SELECT (see GetCredentialsList). Only columns
// that are actually present in the final result set may be used — the
// ORDER BY runs against that result set, not against the raw `credentials`
// table, because several sortable fields (age_days, idle_days,
// bound_identities_count, ...) are computed.
var credentialSortColumns = map[string]string{
	"name":                   "name",
	"arn":                    "arn",
	"credential_type":        "credential_type",
	"account_id":             "account_id",
	"region":                 "region",
	"status":                 "status",
	"last_used_at":           "last_used_at",
	"last_rotated_at":        "last_rotated_at",
	"expires_at":             "expires_at",
	"age_days":               "age_days",
	"idle_days":              "idle_days",
	"days_until_expiry":      "days_until_expiry",
	"bound_identities_count": "bound_identities_count",
}

// GetCredentialsList implements "ENDPOINT 6: Credentials List"
// (GET /api/v1/credentials) from the AWS-NHI Updated API spec.
//
// It is scoped by the shared resolver to the user's saved account/region/scan
// selection, or the tenant's configured defaults when no settings row exists.
func (r *CredentialsRepository) GetCredentialsList(ctx context.Context, resolved *scope.DataScope, f models.CredentialListFilter) (*models.CredentialListResponse, error) {
	if resolved == nil || resolved.DB == nil {
		return nil, errScopeRequired
	}
	tenantDB := resolved.DB
	page := f.Page
	if page < 1 {
		page = 1
	}
	pageSize := f.PageSize
	if pageSize < 1 {
		pageSize = 25
	}
	if pageSize > 200 {
		pageSize = 200
	}

	resp := &models.CredentialListResponse{
		Pagination: models.CredentialListPagination{Page: page, PageSize: pageSize},
		Data:       make([]models.CredentialListItem, 0),
	}

	// The effective scan and user/tenant filters are resolved centrally.
	if resolved.ScanID == "" {
		return resp, nil
	}
	args := resolved.QueryArgs()
	addArg := func(v interface{}) string {
		args = append(args, v)
		return fmt.Sprintf("$%d", len(args))
	}

	// ── inner (raw-column) filters — pushed down onto indexed columns ───
	innerWhere := []string{"c.scan_id = $1", "c.account_id = ANY($2::text[])", "c.region = ANY($3::text[])", "c.deleted_at IS NULL"}

	if s := strings.TrimSpace(f.Search); s != "" {
		ph := addArg("%" + s + "%")
		innerWhere = append(innerWhere, fmt.Sprintf("(c.name ILIKE %s OR c.arn ILIKE %s)", ph, ph))
	}
	if len(f.CredentialTypes) > 0 {
		innerWhere = append(innerWhere, fmt.Sprintf("LOWER(c.credential_type) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.CredentialTypes)))))
	}
	if len(f.Statuses) > 0 {
		innerWhere = append(innerWhere, fmt.Sprintf("LOWER(c.status) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.Statuses)))))
	}
	if s := strings.TrimSpace(f.OwnerPrincipalARN); s != "" {
		innerWhere = append(innerWhere, fmt.Sprintf("c.owner_principal_arn = %s", addArg(s)))
	}
	if f.RotationEnabled != nil {
		innerWhere = append(innerWhere, fmt.Sprintf("COALESCE(c.rotation_enabled, false) = %s", addArg(*f.RotationEnabled)))
	}
	if f.MinIdleDays != nil {
		innerWhere = append(innerWhere, fmt.Sprintf(
			"COALESCE(c.last_used_at, c.created_at_aws, c.first_seen_at) <= NOW() - (%s * INTERVAL '1 day')", addArg(*f.MinIdleDays)))
	}
	if f.MaxDaysUntilExpiry != nil {
		innerWhere = append(innerWhere, fmt.Sprintf(
			"c.expires_at IS NOT NULL AND c.expires_at <= NOW() + (%s * INTERVAL '1 day')", addArg(*f.MaxDaysUntilExpiry)))
	}

	// ── outer (computed-column) filters ──────────────────────────────────
	var outerWhere []string
	if f.IsOrphaned != nil {
		outerWhere = append(outerWhere, fmt.Sprintf("is_orphaned = %s", addArg(*f.IsOrphaned)))
	}
	if f.RotationOverdue != nil {
		outerWhere = append(outerWhere, fmt.Sprintf("rotation_overdue = %s", addArg(*f.RotationOverdue)))
	}
	if f.HasExternalTrust != nil {
		outerWhere = append(outerWhere, fmt.Sprintf("has_external_trust = %s", addArg(*f.HasExternalTrust)))
	}
	outerWhereSQL := ""
	if len(outerWhere) > 0 {
		outerWhereSQL = "WHERE " + strings.Join(outerWhere, " AND ")
	}

	// ── sort ──────────────────────────────────────────────────────────
	sortCol, ok := credentialSortColumns[strings.ToLower(strings.TrimSpace(f.SortBy))]
	if !ok {
		sortCol = "last_used_at"
	}
	sortDir := "DESC"
	if strings.EqualFold(strings.TrimSpace(f.SortOrder), "asc") {
		sortDir = "ASC"
	}

	offset := (page - 1) * pageSize
	limitPH := addArg(pageSize)
	offsetPH := addArg(offset)

	// "bound" counts DISTINCT identities bound to each credential. Note:
	// identity_credentials has NO "is_active"/status column in the real
	// schema (confirmed via information_schema.columns: id, identity_id,
	// credential_id, binding_type, binding_source, is_primary,
	// discovered_at, scan_id, created_at, updated_at) — several other
	// files in this codebase (orphaned_credentials.go, identity_credentials.go,
	// identity_blast_radius.go, blast_radius_repo.go, shared_credentials_repo.go,
	// credentials_bound_identities.go) incorrectly assume an `is_active`
	// column exists; that assumption does not hold against the real
	// database and would fail the same way this endpoint originally did.
	// Every row discovered for a scan is simply a binding that existed at
	// scan time, so presence of a row (scoped to the latest scan_id) is
	// sufficient to count a credential as bound.
	//
	// has_external_trust is a SQL regex approximation of the precise,
	// per-statement Effect=Allow trust-policy evaluation implemented in
	// internal/repository/inventory/trust_policy.go#computeTrustPolicyRisk.
	// That function walks each trust-policy statement in Go; replicating
	// it exactly in SQL is not practical for a paginated list endpoint, so
	// this instead flags any ARN embedded in trust_policy whose account id
	// differs from the credential's own account_id. It ignores the
	// Allow/Deny distinction, which is an accepted simplification for a
	// list view (the precise computation remains available via the
	// single-credential detail endpoint).
	query := fmt.Sprintf(`
		WITH bound AS (
			SELECT ic.credential_id::text AS credential_id,
			       COUNT(DISTINCT ic.identity_id)::int AS cnt
			FROM %[1]s.identity_credentials ic
			JOIN %[1]s.identities i ON i.id::text = ic.identity_id::text AND i.scan_id = ic.scan_id AND i.deleted_at IS NULL
			WHERE ic.scan_id = $1 AND i.account_id = ANY($2::text[]) AND i.region = ANY($3::text[])
			GROUP BY ic.credential_id
		),
		scoped AS (
			SELECT
				c.id::text                       AS id,
				COALESCE(c.name, '')              AS name,
				COALESCE(c.arn, '')                AS arn,
				COALESCE(c.credential_type, '')    AS credential_type,
				COALESCE(c.account_id, '')         AS account_id,
				COALESCE(c.region, '')             AS region,
				COALESCE(c.status, '')             AS status,
				c.owner_principal_arn               AS owner_principal_arn,
				COALESCE(b.cnt, 0)                  AS bound_identities_count,
				(COALESCE(b.cnt, 0) = 0)            AS is_orphaned,
				c.last_used_at                      AS last_used_at,
				c.last_rotated_at                   AS last_rotated_at,
				COALESCE(c.rotation_enabled, false) AS rotation_enabled,
				(
					COALESCE(c.rotation_enabled, false)
					AND c.rotation_interval_days IS NOT NULL
					AND COALESCE(c.last_rotated_at, c.created_at_aws) IS NOT NULL
					AND NOW() > COALESCE(c.last_rotated_at, c.created_at_aws)
						+ (c.rotation_interval_days * INTERVAL '1 day')
				)                                   AS rotation_overdue,
				CASE WHEN c.created_at_aws IS NULL THEN NULL
				     ELSE FLOOR(EXTRACT(EPOCH FROM (NOW() - c.created_at_aws)) / 86400)::int
				END                                  AS age_days,
				CASE WHEN c.last_used_at IS NULL THEN NULL
				     ELSE FLOOR(EXTRACT(EPOCH FROM (NOW() - c.last_used_at)) / 86400)::int
				END                                  AS idle_days,
				c.expires_at                         AS expires_at,
				CASE WHEN c.expires_at IS NULL THEN NULL
				     ELSE FLOOR(EXTRACT(EPOCH FROM (c.expires_at - NOW())) / 86400)::int
				END                                  AS days_until_expiry,
				(
					c.trust_policy IS NOT NULL
					AND c.trust_policy::text ~ ('arn:aws:iam::(?!' || COALESCE(c.account_id, '') || ')[0-9]{12}:')
				)                                    AS has_external_trust,
				c.permission_boundary_arn            AS permission_boundary_arn
			FROM %[1]s.credentials c
			LEFT JOIN bound b ON b.credential_id = c.id::text
			WHERE %[2]s
		)
		SELECT
			id, name, arn, credential_type, account_id, region, status, owner_principal_arn,
			bound_identities_count, is_orphaned, last_used_at, last_rotated_at,
			rotation_enabled, rotation_overdue, age_days, idle_days, expires_at,
			days_until_expiry, has_external_trust, permission_boundary_arn,
			COUNT(*) OVER()::int AS total_count
		FROM scoped
		%[3]s
		ORDER BY %[4]s %[5]s NULLS LAST
		LIMIT %[6]s OFFSET %[7]s`,
		repository.Schema, strings.Join(innerWhere, " AND "), outerWhereSQL, sortCol, sortDir, limitPH, offsetPH)

	rows, err := tenantDB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query credentials list: %w", err)
	}
	defer rows.Close()

	totalCount := 0
	for rows.Next() {
		var item models.CredentialListItem
		var ownerArn, permBoundary sql.NullString
		var ageDays, idleDays, daysUntilExpiry sql.NullInt64

		if err := rows.Scan(
			&item.ID, &item.Name, &item.ARN, &item.CredentialType, &item.AccountID,
			&item.Region, &item.Status, &ownerArn, &item.BoundIdentitiesCount, &item.IsOrphaned,
			&item.LastUsedAt, &item.LastRotatedAt, &item.RotationEnabled, &item.RotationOverdue,
			&ageDays, &idleDays, &item.ExpiresAt, &daysUntilExpiry,
			&item.HasExternalTrust, &permBoundary, &totalCount,
		); err != nil {
			return nil, fmt.Errorf("scan credential row: %w", err)
		}

		if ownerArn.Valid && ownerArn.String != "" {
			v := ownerArn.String
			item.OwnerPrincipalARN = &v
		}
		if permBoundary.Valid && permBoundary.String != "" {
			v := permBoundary.String
			item.PermissionBoundaryARN = &v
		}
		if ageDays.Valid {
			v := int(ageDays.Int64)
			item.AgeDays = &v
		}
		if idleDays.Valid {
			v := int(idleDays.Int64)
			item.IdleDays = &v
		}
		if daysUntilExpiry.Valid {
			v := int(daysUntilExpiry.Int64)
			item.DaysUntilExpiry = &v
		}

		resp.Data = append(resp.Data, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials list: %w", err)
	}

	totalPages := 0
	if pageSize > 0 {
		totalPages = (totalCount + pageSize - 1) / pageSize
	}
	resp.Pagination.TotalCount = totalCount
	resp.Pagination.TotalPages = totalPages

	return resp, nil
}

func lowerTrimAll(in []string) []string {
	out := make([]string, 0, len(in))
	for _, s := range in {
		s = strings.ToLower(strings.TrimSpace(s))
		if s != "" {
			out = append(out, s)
		}
	}
	return out
}
