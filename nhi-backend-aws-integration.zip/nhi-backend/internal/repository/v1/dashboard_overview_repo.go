package v1

import (
	"context"
	"database/sql"
	"fmt"
	"sync"
	"time"

	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/scope"
)

// DashboardOverviewRepository implements "ENDPOINT 3: Dashboard Overview"
// (GET /api/v1/dashboard/overview). Tables used (per the spec's explicit
// table/column list): identities, credentials, identity_credentials,
// effective_permissions, permission_usage, nhi_scans_aws.
//
// The PDF's detail risk signals define stale as no activity/usage for more
// than 90 days, but do not specify NULL handling. For a missing activity/use
// timestamp, use created_at_aws as the never-used age baseline, then
// first_seen_at if AWS creation time is unavailable. Rows with no usable
// timestamp are not asserted stale. This assumes a missing activity/use date
// means no use was recorded; if NULL instead means telemetry is unavailable,
// the source data needs a separate unknown state. The PDF provides no
// calculation for shadow_identities. The current owner-missing proxy is only
// provisional and must not be presented as an approval-based shadow finding.
//
// Other documented choices:
//   - "permission_utilization_pct": SUM(permission_usage.usage_count_90d)
//     as a percentage of SUM(effective_permissions.granted_count).
//   - identity_growth / credential_growth: cumulative count by month of
//     first_seen_at, among rows that still exist in the effective scan
//     (a historical "when did today's inventory first appear" curve, since
//     each scan's rows are a snapshot rather than an immutable event log).
type DashboardOverviewRepository struct{}

func NewDashboardOverviewRepository() *DashboardOverviewRepository {
	return &DashboardOverviewRepository{}
}

const staleThresholdDays = 90
const expiringSoonDays = 30
const topOwnersLimit = 10
const expiringSoonLimit = 10
const scanHistoryLimit = 20

func (r *DashboardOverviewRepository) GetOverview(ctx context.Context, resolved *scope.DataScope) (*models.DashboardOverviewResponse, error) {
	resp := &models.DashboardOverviewResponse{
		Charts: models.DashboardCharts{
			IdentitiesByType:            []models.TypeCountFilter{},
			IdentitiesByFunctionalClass: []models.ClassCountFilter{},
			IdentitiesByAccount:         []models.AccountCountItem{},
			IdentitiesByRegion:          []models.RegionFilter{},
			IdentitiesByEnvironment:     []models.EnvironmentCountFilter{},
			IdentitiesByStatus:          []models.StatusCountFilter{},
			IdentityGrowth:              []models.GrowthPoint{},
			CredentialGrowth:            []models.GrowthPoint{},
			CredentialTypes:             []models.TypeCountFilter{},
			TopOwners:                   []models.OwnerCountItem{},
			CredentialsExpiringSoon:     []models.ExpiringCredentialItem{},
			ScanHistory:                 []models.ScanFilter{},
		},
	}
	if resolved == nil || resolved.DB == nil {
		return nil, errScopeRequired
	}
	if resolved.ScanEnd != nil {
		t := *resolved.ScanEnd
		resp.KPIs.LastScanTime = &t
	}
	// The four loaders below touch disjoint fields of resp (KPIs, identity
	// charts, credential charts, growth charts) and issue independent queries,
	// so they run concurrently. On the first error the shared context is
	// cancelled, which aborts the queries still in flight instead of leaving
	// them to run to completion on a request that has already failed.
	if resolved.ScanID != "" {
		runCtx, cancel := context.WithCancel(ctx)
		defer cancel()
		if err := runAll(runCtx, cancel,
			func() error { return r.loadKPIs(runCtx, resolved, resp) },
			func() error { return r.loadIdentityCharts(runCtx, resolved, resp) },
			func() error { return r.loadCredentialCharts(runCtx, resolved, resp) },
			func() error { return r.loadGrowthCharts(runCtx, resolved, resp) },
		); err != nil {
			return nil, err
		}
	}
	if err := r.loadScanHistory(ctx, resolved.DB, resp); err != nil {
		return nil, err
	}
	return resp, nil
}

// runAll runs independent loaders concurrently and returns the first error,
// cancelling the context so the remaining queries are abandoned rather than
// left to finish for a request that has already failed.
func runAll(ctx context.Context, cancel context.CancelFunc, fns ...func() error) error {
	var (
		wg       sync.WaitGroup
		once     sync.Once
		firstErr error
	)
	for _, fn := range fns {
		wg.Add(1)
		go func(fn func() error) {
			defer wg.Done()
			if err := fn(); err != nil {
				once.Do(func() { firstErr = err; cancel() })
			}
		}(fn)
	}
	wg.Wait()
	return firstErr
}

func (r *DashboardOverviewRepository) loadKPIs(ctx context.Context, resolved *scope.DataScope, resp *models.DashboardOverviewResponse) error {
	tenantDB, queryArgs := resolved.DB, resolved.QueryArgs()
	// total_identities, stale_identities, publicly_accessible, shadow_identities, stale_vs_active
	idQuery := fmt.Sprintf(`
		SELECT
			COUNT(*)::int,
			COUNT(*) FILTER (WHERE COALESCE(i.last_activity_at, i.created_at_aws, i.first_seen_at) < NOW() - INTERVAL '%d days')::int,
			COUNT(*) FILTER (WHERE is_publicly_accessible IS TRUE)::int,
			COUNT(*) FILTER (WHERE owner IS NULL OR BTRIM(owner) = '')::int
		FROM %s.identities i
		WHERE i.scan_id = $1 AND i.account_id = ANY($2::text[]) AND i.region = ANY($3::text[])
		  AND i.deleted_at IS NULL`, staleThresholdDays, repository.Schema)

	var totalIdentities, staleIdentities, publicCount, shadowCount int
	if err := tenantDB.QueryRowContext(ctx, idQuery, queryArgs...).Scan(&totalIdentities, &staleIdentities, &publicCount, &shadowCount); err != nil {
		return fmt.Errorf("query identity KPIs: %w", err)
	}
	resp.KPIs.TotalIdentities = totalIdentities
	resp.KPIs.StaleIdentities = staleIdentities
	resp.KPIs.PubliclyAccessible = publicCount
	resp.KPIs.ShadowIdentities = shadowCount
	resp.Charts.StaleVsActive = models.StaleVsActive{Active: totalIdentities - staleIdentities, Stale: staleIdentities}

	// total_credentials, stale_credentials, orphaned_credentials
	credQuery := fmt.Sprintf(`
		SELECT
			COUNT(*)::int,
			COUNT(*) FILTER (WHERE COALESCE(c.last_used_at, c.created_at_aws, c.first_seen_at) < NOW() - INTERVAL '%[1]d days')::int,
			COUNT(*) FILTER (
				WHERE NOT EXISTS (
					SELECT 1 FROM %[2]s.identity_credentials ic
					WHERE ic.credential_id::text = c.id::text AND ic.scan_id = $1
				)
			)::int
		FROM %[2]s.credentials c
		WHERE c.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
		  AND c.deleted_at IS NULL`, staleThresholdDays, repository.Schema)

	var totalCredentials, staleCredentials, orphanedCredentials int
	if err := tenantDB.QueryRowContext(ctx, credQuery, queryArgs...).Scan(&totalCredentials, &staleCredentials, &orphanedCredentials); err != nil {
		return fmt.Errorf("query credential KPIs: %w", err)
	}
	resp.KPIs.TotalCredentials = totalCredentials
	resp.KPIs.StaleCredentials = staleCredentials
	resp.KPIs.OrphanedCredentials = orphanedCredentials

	// accounts_scanned: distinct accounts across both identities and credentials.
	acctQuery := fmt.Sprintf(`
		SELECT COUNT(DISTINCT account_id) FROM (
			SELECT account_id FROM %[1]s.identities WHERE scan_id = $1 AND account_id = ANY($2::text[]) AND region = ANY($3::text[]) AND deleted_at IS NULL AND account_id IS NOT NULL AND account_id != ''
			UNION
			SELECT account_id FROM %[1]s.credentials WHERE scan_id = $1 AND account_id = ANY($2::text[]) AND region = ANY($3::text[]) AND deleted_at IS NULL AND account_id IS NOT NULL AND account_id != ''
		) a`, repository.Schema)
	var accountsScanned int
	if err := tenantDB.QueryRowContext(ctx, acctQuery, queryArgs...).Scan(&accountsScanned); err != nil {
		return fmt.Errorf("query accounts_scanned: %w", err)
	}
	resp.KPIs.AccountsScanned = accountsScanned

	// permission_utilization_pct: SUM(usage_count_90d) / SUM(granted_count) * 100
	permQuery := fmt.Sprintf(`
		SELECT
			COALESCE(SUM(ep.granted_count), 0)::bigint AS granted,
			COALESCE(SUM(pu.total_usage), 0)::bigint AS used
		FROM %[1]s.credentials c
		LEFT JOIN %[1]s.effective_permissions ep ON ep.credential_id::text = c.id::text AND ep.scan_id = $1
		LEFT JOIN (
			SELECT credential_id, SUM(usage_count_90d) AS total_usage
			FROM %[1]s.permission_usage
			WHERE scan_id = $1
			GROUP BY credential_id
		) pu ON pu.credential_id::text = c.id::text
		WHERE c.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
		  AND c.deleted_at IS NULL`, repository.Schema)

	var granted, used int64
	if err := tenantDB.QueryRowContext(ctx, permQuery, queryArgs...).Scan(&granted, &used); err != nil {
		return fmt.Errorf("query permission_utilization_pct: %w", err)
	}
	if granted > 0 {
		resp.KPIs.PermissionUtilizationPct = round1(float64(used) / float64(granted) * 100)
	}

	return nil
}

func (r *DashboardOverviewRepository) loadIdentityCharts(ctx context.Context, resolved *scope.DataScope, resp *models.DashboardOverviewResponse) error {
	tenantDB := resolved.DB
	// identities_by_type
	if err := r.groupCount(ctx, resolved, "identities", "identity_type", func(rows *sql.Rows) error {
		var item models.TypeCountFilter
		if err := rows.Scan(&item.Type, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByType = append(resp.Charts.IdentitiesByType, item)
		return nil
	}); err != nil {
		return err
	}

	// identities_by_functional_class
	if err := r.groupCount(ctx, resolved, "identities", "functional_class", func(rows *sql.Rows) error {
		var item models.ClassCountFilter
		if err := rows.Scan(&item.Class, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByFunctionalClass = append(resp.Charts.IdentitiesByFunctionalClass, item)
		return nil
	}); err != nil {
		return err
	}

	// identities_by_account
	if err := r.groupCount(ctx, resolved, "identities", "account_id", func(rows *sql.Rows) error {
		var item models.AccountCountItem
		if err := rows.Scan(&item.AccountID, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByAccount = append(resp.Charts.IdentitiesByAccount, item)
		return nil
	}); err != nil {
		return err
	}

	// identities_by_region
	if err := r.groupCount(ctx, resolved, "identities", "region", func(rows *sql.Rows) error {
		var item models.RegionFilter
		if err := rows.Scan(&item.Region, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByRegion = append(resp.Charts.IdentitiesByRegion, item)
		return nil
	}); err != nil {
		return err
	}

	// identities_by_environment
	if err := r.groupCount(ctx, resolved, "identities", "environment", func(rows *sql.Rows) error {
		var item models.EnvironmentCountFilter
		if err := rows.Scan(&item.Environment, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByEnvironment = append(resp.Charts.IdentitiesByEnvironment, item)
		return nil
	}); err != nil {
		return err
	}

	// identities_by_status
	if err := r.groupCount(ctx, resolved, "identities", "status", func(rows *sql.Rows) error {
		var item models.StatusCountFilter
		if err := rows.Scan(&item.Status, &item.Count); err != nil {
			return err
		}
		resp.Charts.IdentitiesByStatus = append(resp.Charts.IdentitiesByStatus, item)
		return nil
	}); err != nil {
		return err
	}

	// top_owners
	ownerQuery := fmt.Sprintf(`
		SELECT owner, COUNT(*)::int
		FROM %s.identities i
		WHERE i.scan_id = $1 AND i.account_id = ANY($2::text[]) AND i.region = ANY($3::text[])
		  AND i.deleted_at IS NULL AND i.owner IS NOT NULL AND BTRIM(i.owner) != ''
		GROUP BY i.owner
		ORDER BY COUNT(*) DESC
		LIMIT %d`, repository.Schema, topOwnersLimit)
	rows, err := tenantDB.QueryContext(ctx, ownerQuery, resolved.QueryArgs()...)
	if err != nil {
		return fmt.Errorf("query top_owners: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var item models.OwnerCountItem
		if err := rows.Scan(&item.Owner, &item.Count); err != nil {
			return fmt.Errorf("scan top_owners row: %w", err)
		}
		resp.Charts.TopOwners = append(resp.Charts.TopOwners, item)
	}
	return rows.Err()
}

// groupCount returns a selected-scan aggregate constrained to the current
// account and region scope and hands each row to scanFn.
func (r *DashboardOverviewRepository) groupCount(ctx context.Context, resolved *scope.DataScope, table, column string, scanFn func(rows *sql.Rows) error) error {
	query := fmt.Sprintf(`
		SELECT x.%[2]s, COUNT(*)::int
		FROM %[3]s.%[1]s x
		WHERE x.scan_id = $1 AND x.account_id = ANY($2::text[]) AND x.region = ANY($3::text[])
		  AND x.deleted_at IS NULL AND x.%[2]s IS NOT NULL AND x.%[2]s != ''
		GROUP BY x.%[2]s ORDER BY COUNT(*) DESC`, table, column, repository.Schema)
	rows, err := resolved.DB.QueryContext(ctx, query, resolved.QueryArgs()...)
	if err != nil {
		return fmt.Errorf("query %s grouped by %s: %w", table, column, err)
	}
	defer rows.Close()
	for rows.Next() {
		if err := scanFn(rows); err != nil {
			return fmt.Errorf("scan %s grouped by %s: %w", table, column, err)
		}
	}
	return rows.Err()
}

func (r *DashboardOverviewRepository) loadCredentialCharts(ctx context.Context, resolved *scope.DataScope, resp *models.DashboardOverviewResponse) error {
	tenantDB := resolved.DB
	queryArgs := resolved.QueryArgs()
	// credential_types
	credTypeQuery := fmt.Sprintf(`
		SELECT credential_type, COUNT(*)::int
		FROM %s.credentials c
		WHERE c.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
		  AND c.deleted_at IS NULL AND c.credential_type IS NOT NULL AND c.credential_type != ''
		GROUP BY c.credential_type
		ORDER BY COUNT(*) DESC`, repository.Schema)
	rows, err := tenantDB.QueryContext(ctx, credTypeQuery, queryArgs...)
	if err != nil {
		return fmt.Errorf("query credential_types: %w", err)
	}
	for rows.Next() {
		var item models.TypeCountFilter
		if err := rows.Scan(&item.Type, &item.Count); err != nil {
			rows.Close()
			return fmt.Errorf("scan credential_types row: %w", err)
		}
		resp.Charts.CredentialTypes = append(resp.Charts.CredentialTypes, item)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return err
	}
	rows.Close()

	// credentials_expiring_soon
	expQuery := fmt.Sprintf(`
		SELECT COALESCE(name, arn, id::text), expires_at,
		       GREATEST(CEIL(EXTRACT(EPOCH FROM (expires_at - NOW())) / 86400), 0)::int
		FROM %s.credentials c
		WHERE c.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
		  AND c.deleted_at IS NULL AND c.expires_at IS NOT NULL
		  AND c.expires_at BETWEEN NOW() AND NOW() + INTERVAL '%d days'
		ORDER BY c.expires_at ASC
		LIMIT %d`, repository.Schema, expiringSoonDays, expiringSoonLimit)
	expRows, err := tenantDB.QueryContext(ctx, expQuery, queryArgs...)
	if err != nil {
		return fmt.Errorf("query credentials_expiring_soon: %w", err)
	}
	defer expRows.Close()
	for expRows.Next() {
		var item models.ExpiringCredentialItem
		if err := expRows.Scan(&item.CredentialName, &item.ExpiresAt, &item.DaysRemaining); err != nil {
			return fmt.Errorf("scan credentials_expiring_soon row: %w", err)
		}
		resp.Charts.CredentialsExpiringSoon = append(resp.Charts.CredentialsExpiringSoon, item)
	}
	return expRows.Err()
}

// loadGrowthCharts builds a cumulative "growth" curve bucketed by month,
// using first_seen_at among rows that still exist in the effective scan.
// This reflects "when did today's inventory first appear" rather than a
// true historical event log (each scan's rows are a point-in-time
// snapshot, not an append-only ledger).
func (r *DashboardOverviewRepository) loadGrowthCharts(ctx context.Context, resolved *scope.DataScope, resp *models.DashboardOverviewResponse) error {
	idGrowth, err := r.monthlyCumulativeGrowth(ctx, resolved, "identities")
	if err != nil {
		return err
	}
	resp.Charts.IdentityGrowth = idGrowth

	credGrowth, err := r.monthlyCumulativeGrowth(ctx, resolved, "credentials")
	if err != nil {
		return err
	}
	resp.Charts.CredentialGrowth = credGrowth

	return nil
}

func (r *DashboardOverviewRepository) monthlyCumulativeGrowth(ctx context.Context, resolved *scope.DataScope, table string) ([]models.GrowthPoint, error) {
	query := fmt.Sprintf(`
		SELECT DATE_TRUNC('month', first_seen_at) AS month, COUNT(*)::int
		FROM %s.%s x
		WHERE x.scan_id = $1 AND x.account_id = ANY($2::text[]) AND x.region = ANY($3::text[])
		  AND x.deleted_at IS NULL AND x.first_seen_at IS NOT NULL
		GROUP BY month ORDER BY month`, repository.Schema, table)

	rows, err := resolved.DB.QueryContext(ctx, query, resolved.QueryArgs()...)
	if err != nil {
		return nil, fmt.Errorf("query %s growth: %w", table, err)
	}
	defer rows.Close()

	points := make([]models.GrowthPoint, 0)
	running := 0
	for rows.Next() {
		var month time.Time
		var cnt int
		if err := rows.Scan(&month, &cnt); err != nil {
			return nil, fmt.Errorf("scan %s growth row: %w", table, err)
		}
		running += cnt
		points = append(points, models.GrowthPoint{Date: month.Format("2006-01-02"), Count: running})
	}
	return points, rows.Err()
}

func (r *DashboardOverviewRepository) loadScanHistory(ctx context.Context, tenantDB *sql.DB, resp *models.DashboardOverviewResponse) error {
	query := fmt.Sprintf(`
		SELECT scan_id, scan_end, status,
		       COALESCE(total_identities, 0), COALESCE(total_credentials, 0)
		FROM %s.nhi_scans_aws
		ORDER BY scan_end DESC NULLS LAST
		LIMIT %d`, repository.Schema, scanHistoryLimit)

	rows, err := tenantDB.QueryContext(ctx, query)
	if err != nil {
		return fmt.Errorf("query scan_history: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var item models.ScanFilter
		var scanEnd sql.NullTime
		if err := rows.Scan(&item.ScanID, &scanEnd, &item.Status, &item.TotalIdentities, &item.TotalCredentials); err != nil {
			return fmt.Errorf("scan scan_history row: %w", err)
		}
		if scanEnd.Valid {
			item.ScanEnd = scanEnd.Time.Format(time.RFC3339)
		}
		resp.Charts.ScanHistory = append(resp.Charts.ScanHistory, item)
	}
	return rows.Err()
}

// Note: round1() is already defined in credential_detail_repo.go (shared
// within this package).
