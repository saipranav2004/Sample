package v1

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/lib/pq"

	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/scope"
)

type IdentitiesListRepository struct{}

func NewIdentitiesListRepository() *IdentitiesListRepository {
	return &IdentitiesListRepository{}
}

// identitySortColumns maps the public `sort_by` query value to the column
// name exposed by the final SELECT (see GetIdentitiesList). Only columns
// present in the final result set may be used.
var identitySortColumns = map[string]string{
	"name":                       "name",
	"arn":                        "arn",
	"identity_type":              "identity_type",
	"functional_class":           "functional_class",
	"account_id":                 "account_id",
	"region":                     "region",
	"environment":                "environment",
	"owner":                      "owner",
	"status":                     "status",
	"last_activity_at":           "last_activity_at",
	"created_at_aws":             "created_at_aws",
	"age_days":                   "age_days",
	"idle_days":                  "idle_days",
	"bound_credentials_count":    "bound_credentials_count",
	"permission_utilization_pct": "permission_utilization_pct",
}

// GetIdentitiesList implements "ENDPOINT 4: Identities List"
// (GET /api/v1/identities) from the AWS-NHI Updated API spec.
//
// Scoped to the effective completed scan and selected account/region lists
// provided by the shared tenant scope resolver. "bound_credentials_count"
// counts DISTINCT credentials bound
// to each identity via identity_credentials (presence-based — that table
// has no is_active/status column in the real schema, confirmed during the
// Credentials List endpoint's implementation).
//
// permission_utilization_pct per identity = (COUNT DISTINCT actions used
// across ALL of this identity's bound credentials, from permission_usage)
// / (SUM of effective_permissions.granted_count across the same
// credentials) * 100, rounded to the nearest integer — this matches the
// table list in the spec ("permission_usage credential_id, action (COUNT
// used)") rather than the usage_count_90d-based formula used for the
// Dashboard Overview KPI, since the two endpoints cite different source
// columns for the same concept.
func (r *IdentitiesListRepository) GetIdentitiesList(ctx context.Context, resolved *scope.DataScope, f models.IdentityListFilter) (*models.IdentityListResponse, error) {
	if resolved == nil || resolved.DB == nil {
		return nil, errScopeRequired
	}
	tenantDB := resolved.DB
	page := f.Page
	if page < 1 {
		page = 1
	}
	pageSize := f.PageSize
	if pageSize < 1 {
		pageSize = 25
	}
	if pageSize > 100 {
		pageSize = 100
	}

	resp := &models.IdentityListResponse{
		Pagination: models.IdentityListPagination{Page: page, PageSize: pageSize},
		Data:       make([]models.IdentityListItem, 0),
	}

	latestScanID := resolved.ScanID
	if latestScanID == "" {
		return resp, nil
	}

	args := resolved.QueryArgs()
	addArg := func(v interface{}) string {
		args = append(args, v)
		return fmt.Sprintf("$%d", len(args))
	}

	where := []string{"i.scan_id = $1", "i.account_id = ANY($2::text[])", "i.region = ANY($3::text[])", "i.deleted_at IS NULL"}

	if s := strings.TrimSpace(f.Search); s != "" {
		ph := addArg("%" + s + "%")
		where = append(where, fmt.Sprintf("(i.name ILIKE %s OR i.arn ILIKE %s OR i.tags::text ILIKE %s)", ph, ph, ph))
	}
	if len(f.IdentityTypes) > 0 {
		where = append(where, fmt.Sprintf("LOWER(i.identity_type) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.IdentityTypes)))))
	}
	if len(f.FunctionalClasses) > 0 {
		where = append(where, fmt.Sprintf("LOWER(i.functional_class) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.FunctionalClasses)))))
	}
	if len(f.Environments) > 0 {
		where = append(where, fmt.Sprintf("LOWER(i.environment) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.Environments)))))
	}
	if len(f.Statuses) > 0 {
		where = append(where, fmt.Sprintf("LOWER(i.status) = ANY(%s)", addArg(pq.Array(lowerTrimAll(f.Statuses)))))
	}
	if s := strings.TrimSpace(f.Owner); s != "" {
		where = append(where, fmt.Sprintf("i.owner = %s", addArg(s)))
	}
	if s := strings.TrimSpace(f.VPCID); s != "" {
		where = append(where, fmt.Sprintf("i.vpc_id = %s", addArg(s)))
	}
	if f.IsPubliclyAccessible != nil {
		where = append(where, fmt.Sprintf("COALESCE(i.is_publicly_accessible, false) = %s", addArg(*f.IsPubliclyAccessible)))
	}
	if f.MinIdleDays != nil {
		where = append(where, fmt.Sprintf(
			"COALESCE(i.last_activity_at, i.created_at_aws, i.first_seen_at) <= NOW() - (%s * INTERVAL '1 day')", addArg(*f.MinIdleDays)))
	}

	sortCol, ok := identitySortColumns[strings.ToLower(strings.TrimSpace(f.SortBy))]
	if !ok {
		sortCol = "last_activity_at"
	}
	sortDir := "DESC"
	if strings.EqualFold(strings.TrimSpace(f.SortOrder), "asc") {
		sortDir = "ASC"
	}

	offset := (page - 1) * pageSize
	limitPH := addArg(pageSize)
	offsetPH := addArg(offset)

	query := fmt.Sprintf(`
		WITH bound AS (
			SELECT ic.identity_id::text AS identity_id,
			       COUNT(DISTINCT ic.credential_id)::int AS cnt
			FROM %[1]s.identity_credentials ic
			JOIN %[1]s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
			WHERE ic.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
			GROUP BY ic.identity_id
		),
		perm_grant AS (
			SELECT ic.identity_id::text AS identity_id,
			       COALESCE(SUM(ep.granted_count), 0)::bigint AS granted
			FROM %[1]s.identity_credentials ic
			JOIN %[1]s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
			JOIN %[1]s.effective_permissions ep
			  ON ep.credential_id::text = ic.credential_id::text AND ep.scan_id = ic.scan_id
			WHERE ic.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
			GROUP BY ic.identity_id
		),
		perm_used AS (
			SELECT ic.identity_id::text AS identity_id,
			       COUNT(DISTINCT pu.action)::bigint AS used
			FROM %[1]s.identity_credentials ic
			JOIN %[1]s.credentials c ON c.id::text = ic.credential_id::text AND c.scan_id = ic.scan_id AND c.deleted_at IS NULL
			JOIN %[1]s.permission_usage pu
			  ON pu.credential_id::text = ic.credential_id::text AND pu.scan_id = ic.scan_id
			WHERE ic.scan_id = $1 AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
			GROUP BY ic.identity_id
		),
		scoped AS (
			SELECT
				i.id::text                         AS id,
				COALESCE(i.name, '')                AS name,
				COALESCE(i.arn, '')                  AS arn,
				COALESCE(i.identity_type, '')         AS identity_type,
				i.functional_class                    AS functional_class,
				COALESCE(i.account_id, '')             AS account_id,
				COALESCE(i.region, '')                  AS region,
				i.environment                            AS environment,
				i.owner                                   AS owner,
				COALESCE(i.status, '')                     AS status,
				COALESCE(i.is_publicly_accessible, false)   AS is_publicly_accessible,
				i.vpc_id                                     AS vpc_id,
				COALESCE(b.cnt, 0)                            AS bound_credentials_count,
				i.last_activity_at                             AS last_activity_at,
				i.created_at_aws                                AS created_at_aws,
				CASE WHEN i.created_at_aws IS NULL THEN NULL
				     ELSE FLOOR(EXTRACT(EPOCH FROM (NOW() - i.created_at_aws)) / 86400)::int
				END                                               AS age_days,
				CASE WHEN i.last_activity_at IS NULL THEN NULL
				     ELSE FLOOR(EXTRACT(EPOCH FROM (NOW() - i.last_activity_at)) / 86400)::int
				END                                               AS idle_days,
				i.cloudtrail_creator_arn                           AS created_by,
				CASE WHEN COALESCE(pg.granted, 0) = 0 THEN NULL
				     ELSE ROUND((COALESCE(pu2.used, 0)::numeric / pg.granted::numeric) * 100)::int
				END                                               AS permission_utilization_pct
			FROM %[1]s.identities i
			LEFT JOIN bound b ON b.identity_id = i.id::text
			LEFT JOIN perm_grant pg ON pg.identity_id = i.id::text
			LEFT JOIN perm_used pu2 ON pu2.identity_id = i.id::text
			WHERE %[2]s
		)
		SELECT
			id, name, arn, identity_type, functional_class, account_id, region,
			environment, owner, status, is_publicly_accessible, vpc_id,
			bound_credentials_count, last_activity_at, created_at_aws, age_days,
			idle_days, created_by, permission_utilization_pct,
			COUNT(*) OVER()::int AS total_count
		FROM scoped
		ORDER BY %[3]s %[4]s NULLS LAST
		LIMIT %[5]s OFFSET %[6]s`,
		repository.Schema, strings.Join(where, " AND "), sortCol, sortDir, limitPH, offsetPH)

	rows, err := tenantDB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query identities list: %w", err)
	}
	defer rows.Close()

	totalCount := 0
	for rows.Next() {
		var item models.IdentityListItem
		var functionalClass, environment, owner, vpcID, createdBy sql.NullString
		var ageDays, idleDays, utilizationPct sql.NullInt64

		if err := rows.Scan(
			&item.ID, &item.Name, &item.ARN, &item.IdentityType, &functionalClass,
			&item.AccountID, &item.Region, &environment, &owner, &item.Status,
			&item.IsPubliclyAccessible, &vpcID, &item.BoundCredentialsCount,
			&item.LastActivityAt, &item.CreatedAtAWS, &ageDays, &idleDays, &createdBy,
			&utilizationPct, &totalCount,
		); err != nil {
			return nil, fmt.Errorf("scan identity row: %w", err)
		}

		if functionalClass.Valid && functionalClass.String != "" {
			v := functionalClass.String
			item.FunctionalClass = &v
		}
		if environment.Valid && environment.String != "" {
			v := environment.String
			item.Environment = &v
		}
		if owner.Valid && owner.String != "" {
			v := owner.String
			item.Owner = &v
		}
		if vpcID.Valid && vpcID.String != "" {
			v := vpcID.String
			item.VPCID = &v
		}
		if createdBy.Valid && createdBy.String != "" {
			v := createdBy.String
			item.CreatedBy = &v
		}
		if ageDays.Valid {
			v := int(ageDays.Int64)
			item.AgeDays = &v
		}
		if idleDays.Valid {
			v := int(idleDays.Int64)
			item.IdleDays = &v
		}
		if utilizationPct.Valid {
			v := int(utilizationPct.Int64)
			item.PermissionUtilizationPct = &v
		}

		resp.Data = append(resp.Data, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identities list: %w", err)
	}

	totalPages := 0
	if pageSize > 0 {
		totalPages = (totalCount + pageSize - 1) / pageSize
	}
	resp.Pagination.TotalCount = totalCount
	resp.Pagination.TotalPages = totalPages

	return resp, nil
}
