package repository

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5/pgconn"

	"nhi-backend-api/internal/database"
	modelsv1 "nhi-backend-api/internal/models/v1"
)

const (
	awsPlatformTable     = "aws_platform_settings"
	awsIntegrationsTable = "tenant_aws_integrations"
	awsAccountsTable     = "tenant_aws_accounts"
	awsAccountUniqueIdx  = "uq_tenant_aws_accounts_account"
)

// ErrAWSAccountClaimed: the AWS account is already connected to another tenant.
var ErrAWSAccountClaimed = errors.New("aws account is connected to another tenant")

// AWSIntegrationRepository reads and writes the AWS connection tables. They
// are in the global database (see migrations/global/002_aws_integration.sql),
// so every query is keyed by the tenant_id from the signed token.
type AWSIntegrationRepository struct {
	db     *PostgresDB
	schema string
}

func NewAWSIntegrationRepository(db *PostgresDB) *AWSIntegrationRepository {
	schema := "nhi_schema"
	if db != nil && strings.TrimSpace(db.GlobalSchema()) != "" {
		schema = db.GlobalSchema()
	}
	return &AWSIntegrationRepository{db: db, schema: schema}
}

func (r *AWSIntegrationRepository) globalDB() (*sql.DB, error) {
	if r == nil || r.db == nil || r.db.DB == nil {
		return nil, errors.New("aws integration repository is not initialized")
	}
	return r.db.DB, nil
}

// PlatformSettings returns the platform's AWS values, or nil when the row has
// not been filled in yet.
func (r *AWSIntegrationRepository) PlatformSettings(ctx context.Context) (*modelsv1.AWSPlatformSettings, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `SELECT account_id, region, event_bus_arn, assumer_role_arn, collector_role_name, forward_rule_name
		FROM ` + database.Table(r.schema, awsPlatformTable) + ` WHERE id = 1`
	var s modelsv1.AWSPlatformSettings
	err = db.QueryRowContext(ctx, q).Scan(&s.AccountID, &s.Region, &s.EventBusARN, &s.AssumerRoleARN, &s.CollectorRoleName, &s.ForwardRuleName)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("load aws platform settings: %w", err)
	}
	return &s, nil
}

// ExternalID returns the tenant's External ID, if one has been issued.
func (r *AWSIntegrationRepository) ExternalID(ctx context.Context, tenantID string) (string, bool, error) {
	db, err := r.globalDB()
	if err != nil {
		return "", false, err
	}
	var id string
	q := `SELECT external_id FROM ` + database.Table(r.schema, awsIntegrationsTable) + ` WHERE tenant_id = $1::uuid`
	err = db.QueryRowContext(ctx, q, tenantID).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return "", false, nil
	}
	if err != nil {
		return "", false, fmt.Errorf("load external id: %w", err)
	}
	return id, true, nil
}

// EnsureExternalID returns the tenant's External ID, issuing one the first
// time. Safe under concurrent first requests: the insert is a no-op for every
// request but one, and all of them read back the same value.
func (r *AWSIntegrationRepository) EnsureExternalID(ctx context.Context, tenantID string) (string, error) {
	if id, ok, err := r.ExternalID(ctx, tenantID); err != nil || ok {
		return id, err
	}
	db, err := r.globalDB()
	if err != nil {
		return "", err
	}
	insert := `INSERT INTO ` + database.Table(r.schema, awsIntegrationsTable) + ` (tenant_id, external_id)
		VALUES ($1::uuid, $2) ON CONFLICT (tenant_id) DO NOTHING`
	// A collision on external_id (96 random bits) is not expected; retrying
	// keeps it from ever surfacing as an error.
	for attempt := 0; attempt < 3; attempt++ {
		candidate, err := newExternalID()
		if err != nil {
			return "", err
		}
		if _, err := db.ExecContext(ctx, insert, tenantID, candidate); err != nil {
			var pgErr *pgconn.PgError
			if errors.As(err, &pgErr) && pgErr.Code == "23505" {
				continue
			}
			return "", fmt.Errorf("issue external id: %w", err)
		}
		id, ok, err := r.ExternalID(ctx, tenantID)
		if err != nil {
			return "", err
		}
		if ok {
			return id, nil
		}
	}
	return "", errors.New("could not issue a unique external id")
}

func newExternalID() (string, error) {
	buf := make([]byte, 12)
	if _, err := rand.Read(buf); err != nil {
		return "", fmt.Errorf("generate external id: %w", err)
	}
	return "ext-" + hex.EncodeToString(buf), nil
}

// ListAccounts returns the tenant's AWS accounts, connected first.
func (r *AWSIntegrationRepository) ListAccounts(ctx context.Context, tenantID string) ([]modelsv1.AWSAccountRecord, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `SELECT tenant_id::text, aws_account_id, role_arn, status, checks, last_verified_at, last_verified_by, connected_at
		FROM ` + database.Table(r.schema, awsAccountsTable) + `
		WHERE tenant_id = $1::uuid
		ORDER BY (status = 'connected') DESC, aws_account_id`
	rows, err := db.QueryContext(ctx, q, tenantID)
	if err != nil {
		return nil, fmt.Errorf("list aws accounts: %w", err)
	}
	defer rows.Close()
	out := make([]modelsv1.AWSAccountRecord, 0)
	for rows.Next() {
		var rec modelsv1.AWSAccountRecord
		var checks []byte
		var connectedAt sql.NullTime
		if err := rows.Scan(&rec.TenantID, &rec.AccountID, &rec.RoleARN, &rec.Status, &checks, &rec.LastVerifiedAt, &rec.LastVerifiedBy, &connectedAt); err != nil {
			return nil, fmt.Errorf("scan aws account: %w", err)
		}
		rec.Checks = make([]modelsv1.AWSCheck, 0)
		if len(checks) > 0 {
			if err := json.Unmarshal(checks, &rec.Checks); err != nil {
				return nil, fmt.Errorf("decode aws account checks: %w", err)
			}
		}
		rec.LastVerifiedAt = rec.LastVerifiedAt.UTC()
		if connectedAt.Valid {
			t := connectedAt.Time.UTC()
			rec.ConnectedAt = &t
		}
		out = append(out, rec)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate aws accounts: %w", err)
	}
	return out, nil
}

// AccountClaimedByOther reports whether the AWS account is connected to a
// tenant other than tenantID.
func (r *AWSIntegrationRepository) AccountClaimedByOther(ctx context.Context, tenantID, accountID string) (bool, error) {
	db, err := r.globalDB()
	if err != nil {
		return false, err
	}
	var claimed bool
	q := `SELECT EXISTS (SELECT 1 FROM ` + database.Table(r.schema, awsAccountsTable) + `
		WHERE aws_account_id = $1 AND tenant_id <> $2::uuid)`
	if err := db.QueryRowContext(ctx, q, accountID, tenantID).Scan(&claimed); err != nil {
		return false, fmt.Errorf("check aws account owner: %w", err)
	}
	return claimed, nil
}

// SaveAccount records the outcome of a verification. connected_at is set the
// first time the account passes and kept afterwards; status always reflects
// the latest run. Returns the stored row.
func (r *AWSIntegrationRepository) SaveAccount(ctx context.Context, rec modelsv1.AWSAccountRecord) (*modelsv1.AWSAccountRecord, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	checks, err := json.Marshal(rec.Checks)
	if err != nil {
		return nil, fmt.Errorf("encode aws account checks: %w", err)
	}
	table := database.Table(r.schema, awsAccountsTable)
	q := `INSERT INTO ` + table + ` AS a
			(tenant_id, aws_account_id, role_arn, status, checks, last_verified_at, last_verified_by, connected_at, updated_at)
		VALUES ($1::uuid, $2, $3, $4, $5::jsonb, $6, $7, CASE WHEN $4 = 'connected' THEN $6::timestamptz END, now())
		ON CONFLICT (tenant_id, aws_account_id) DO UPDATE SET
			role_arn = EXCLUDED.role_arn,
			status = EXCLUDED.status,
			checks = EXCLUDED.checks,
			last_verified_at = EXCLUDED.last_verified_at,
			last_verified_by = EXCLUDED.last_verified_by,
			connected_at = COALESCE(a.connected_at, EXCLUDED.connected_at),
			updated_at = now()
		RETURNING connected_at`
	var connectedAt sql.NullTime
	err = db.QueryRowContext(ctx, q, rec.TenantID, rec.AccountID, rec.RoleARN, rec.Status, checks, rec.LastVerifiedAt, rec.LastVerifiedBy).Scan(&connectedAt)
	if err != nil {
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == "23505" && pgErr.ConstraintName == awsAccountUniqueIdx {
			return nil, ErrAWSAccountClaimed
		}
		return nil, fmt.Errorf("save aws account: %w", err)
	}
	out := rec
	out.ConnectedAt = nil
	if connectedAt.Valid {
		t := connectedAt.Time.UTC()
		out.ConnectedAt = &t
	}
	return &out, nil
}
