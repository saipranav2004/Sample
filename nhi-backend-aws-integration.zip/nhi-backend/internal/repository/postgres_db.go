package repository

import (
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/database"
)

// Schema is the schema used by tenant data repositories. It must match
// database.schema in configs/config.yaml and migrations.
const Schema = "nhi_scanner"

const latestCompletedScanSQL = `(SELECT scan_id FROM ` + Schema + `.nhi_scans_aws ` +
	`WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)`

const LatestScanFilter = `scan_id = ` + latestCompletedScanSQL

type PostgresDB struct {
	// DB is reserved for global authentication/tenant-registry queries only.
	DB      *sql.DB
	manager *database.Manager
}

func NewPostgresDB(cfg *config.Config) (*PostgresDB, error) {
	manager, err := database.NewManager(cfg)
	if err != nil {
		return nil, err
	}
	if cfg.Database.Schema != Schema {
		_ = manager.Close()
		return nil, fmt.Errorf("database.schema must be %q to match the data repositories", Schema)
	}
	return &PostgresDB{DB: manager.Global(), manager: manager}, nil
}

// GetTenantDB returns a tenant data pool only; blank names never fall back to
// the global authentication database.
func (p *PostgresDB) GetTenantDB(dbName string) (*sql.DB, error) {
	if p == nil || p.manager == nil {
		return nil, fmt.Errorf("postgres database manager is not initialized")
	}
	return p.manager.Tenant(dbName)
}

func (p *PostgresDB) GlobalSchema() string {
	if p == nil || p.manager == nil {
		return ""
	}
	return p.manager.GlobalSchema()
}

func (p *PostgresDB) DataSchema() string {
	if p == nil || p.manager == nil {
		return ""
	}
	return p.manager.DataSchema()
}

func (p *PostgresDB) Close() error {
	if p == nil || p.manager == nil {
		return nil
	}
	return p.manager.Close()
}

func ownedCredsArray(alias string) string {
	col := "NULLIF(" + alias + ".owned_credentials::text, '')::jsonb"
	return "(CASE WHEN jsonb_typeof(" + col + ") = 'array' THEN " + col + " ELSE '[]'::jsonb END)"
}

// Identifier quotes a static schema/table name safely.
func Identifier(name string) string {
	return `"` + strings.ReplaceAll(name, `"`, `""`) + `"`
}
