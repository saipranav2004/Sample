package repository

import (
	"context"
	"database/sql"
	"errors"
	"os"
	"regexp"
	"sync"
	"testing"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"

	modelsv1 "nhi-backend-api/internal/models/v1"
)

// Runs against a real global database with migrations 001 and 002 applied and
// tenants 1111…/2222… registered, e.g.
//
//	NHI_TEST_GLOBAL_DSN='postgres://postgres@localhost:5432/nhi_global?sslmode=disable' go test ./internal/repository/
func openTestGlobalDB(t *testing.T) *AWSIntegrationRepository {
	t.Helper()
	dsn := os.Getenv("NHI_TEST_GLOBAL_DSN")
	if dsn == "" {
		t.Skip("NHI_TEST_GLOBAL_DSN not set")
	}
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = db.Close() })
	for _, q := range []string{
		`DELETE FROM nhi_schema.tenant_aws_accounts`,
		`DELETE FROM nhi_schema.tenant_aws_integrations`,
		`DELETE FROM nhi_schema.aws_platform_settings`,
	} {
		if _, err := db.Exec(q); err != nil {
			t.Fatalf("%s: %v", q, err)
		}
	}
	return NewAWSIntegrationRepository(&PostgresDB{DB: db})
}

const (
	tenantA = "11111111-1111-1111-1111-111111111111"
	tenantB = "22222222-2222-2222-2222-222222222222"
)

func TestAWSIntegrationRepositoryAgainstPostgres(t *testing.T) {
	repo := openTestGlobalDB(t)
	ctx := context.Background()

	if s, err := repo.PlatformSettings(ctx); err != nil || s != nil {
		t.Fatalf("PlatformSettings on empty table = %+v, %v", s, err)
	}
	if _, err := repo.db.DB.Exec(`INSERT INTO nhi_schema.aws_platform_settings (account_id, region, event_bus_arn, assumer_role_arn)
		VALUES ('999999999999','ap-south-1','arn:aws:events:ap-south-1:999999999999:event-bus/nhi-central-bus','arn:aws:iam::999999999999:role/NHIPlatformAssumer')`); err != nil {
		t.Fatal(err)
	}
	s, err := repo.PlatformSettings(ctx)
	if err != nil || s == nil || s.CollectorRoleName != "NHIPlatformCollector" || s.ForwardRuleName != "nhi-forward-events" {
		t.Fatalf("PlatformSettings = %+v, %v", s, err)
	}

	// External ID: issued once, stable, concurrent-safe, distinct per tenant.
	var wg sync.WaitGroup
	ids := make([]string, 8)
	errs := make([]error, 8)
	for i := range ids {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			ids[i], errs[i] = repo.EnsureExternalID(ctx, tenantA)
		}(i)
	}
	wg.Wait()
	for i := range ids {
		if errs[i] != nil || ids[i] != ids[0] {
			t.Fatalf("concurrent EnsureExternalID: %v / %q vs %q", errs[i], ids[i], ids[0])
		}
	}
	if !regexp.MustCompile(`^ext-[0-9a-f]{24}$`).MatchString(ids[0]) {
		t.Fatalf("external id %q has the wrong shape", ids[0])
	}
	idB, err := repo.EnsureExternalID(ctx, tenantB)
	if err != nil || idB == ids[0] {
		t.Fatalf("tenant B external id %q, %v", idB, err)
	}

	// Accounts: first failure, then success; connected_at set once and kept.
	now := time.Now().UTC().Truncate(time.Microsecond)
	rec := modelsv1.AWSAccountRecord{
		TenantID: tenantA, AccountID: "222222222222", RoleARN: "arn:aws:iam::222222222222:role/NHIPlatformCollector",
		Status: modelsv1.AWSStatusActionNeeded, LastVerifiedAt: now, LastVerifiedBy: "alice",
		Checks: []modelsv1.AWSCheck{{Key: "assume_role", Label: "Assume your role", State: "pass", Message: "ok"}},
	}
	saved, err := repo.SaveAccount(ctx, rec)
	if err != nil || saved.ConnectedAt != nil {
		t.Fatalf("SaveAccount(action_needed) = %+v, %v", saved, err)
	}
	rec.Status, rec.LastVerifiedAt = modelsv1.AWSStatusConnected, now.Add(time.Minute)
	saved, err = repo.SaveAccount(ctx, rec)
	if err != nil || saved.ConnectedAt == nil || !saved.ConnectedAt.Equal(rec.LastVerifiedAt) {
		t.Fatalf("SaveAccount(connected) = %+v, %v", saved, err)
	}
	firstConnected := *saved.ConnectedAt
	rec.Status, rec.LastVerifiedAt = modelsv1.AWSStatusActionNeeded, now.Add(2*time.Minute)
	saved, err = repo.SaveAccount(ctx, rec)
	if err != nil || saved.ConnectedAt == nil || !saved.ConnectedAt.Equal(firstConnected) {
		t.Fatalf("connected_at not kept: %+v, %v", saved, err)
	}

	list, err := repo.ListAccounts(ctx, tenantA)
	if err != nil || len(list) != 1 || list[0].Status != modelsv1.AWSStatusActionNeeded || len(list[0].Checks) != 1 || list[0].Checks[0].Key != "assume_role" {
		t.Fatalf("ListAccounts = %+v, %v", list, err)
	}
	if list, err := repo.ListAccounts(ctx, tenantB); err != nil || len(list) != 0 {
		t.Fatalf("tenant B sees tenant A's accounts: %+v, %v", list, err)
	}

	// One account, one tenant.
	if claimed, err := repo.AccountClaimedByOther(ctx, tenantB, "222222222222"); err != nil || !claimed {
		t.Fatalf("AccountClaimedByOther(B) = %v, %v", claimed, err)
	}
	if claimed, err := repo.AccountClaimedByOther(ctx, tenantA, "222222222222"); err != nil || claimed {
		t.Fatalf("AccountClaimedByOther(A) = %v, %v", claimed, err)
	}
	rec.TenantID = tenantB
	if _, err := repo.SaveAccount(ctx, rec); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("SaveAccount for another tenant = %v, want ErrAWSAccountClaimed", err)
	}
}
