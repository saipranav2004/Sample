package v1

import "time"

// ─────────────────────────────────────────────────────────────────────────
// GET  /api/v1/integrations/aws          setup values + connection status
// POST /api/v1/integrations/aws/verify   run the three checks for a role
//
// Backing tables (global database, migrations/global/002_aws_integration.sql):
// aws_platform_settings, tenant_aws_integrations, tenant_aws_accounts.
// ─────────────────────────────────────────────────────────────────────────

// Connection status of a tenant, and of one AWS account.
const (
	AWSStatusNotConnected = "not_connected" // tenant only: no account has passed AssumeRole yet
	AWSStatusActionNeeded = "action_needed" // role assumed, but a later check failed
	AWSStatusConnected    = "connected"     // all three checks passed
)

// State of one check.
const (
	AWSCheckPass    = "pass"
	AWSCheckFail    = "fail"    // the client's setup needs a change; Fix says which
	AWSCheckSkipped = "skipped" // not run because an earlier check failed
	AWSCheckError   = "error"   // could not be run (our side); try again
)

// Check keys, in the order they run.
const (
	AWSCheckAssumeRole = "assume_role"
	AWSCheckReadAccess = "read_access"
	AWSCheckEvents     = "events"
)

type AWSIntegrationResponse struct {
	// Status is the tenant's overall state: connected when any account is.
	Status string `json:"status"`
	// CanManage is true for roles allowed to connect accounts (admin). Setup
	// is null for everyone else.
	CanManage bool                  `json:"can_manage"`
	Setup     *AWSSetupValues       `json:"setup"`
	Accounts  []AWSConnectedAccount `json:"accounts"`
}

// AWSSetupValues is everything the client copies into the AWS console.
type AWSSetupValues struct {
	AccountID       string   `json:"account_id"`
	ExternalID      string   `json:"external_id"`
	EventBusARN     string   `json:"event_bus_arn"`
	Region          string   `json:"region"`
	AssumerRoleARN  string   `json:"assumer_role_arn"`
	RoleName        string   `json:"role_name"`
	RuleName        string   `json:"rule_name"`
	ManagedPolicies []string `json:"managed_policies"`
	EventSources    []string `json:"event_sources"`
}

type AWSConnectedAccount struct {
	AccountID      string     `json:"account_id"`
	RoleARN        string     `json:"role_arn"`
	Status         string     `json:"status"`
	Checks         []AWSCheck `json:"checks"`
	LastVerifiedAt time.Time  `json:"last_verified_at"`
	LastVerifiedBy string     `json:"last_verified_by"`
	ConnectedAt    *time.Time `json:"connected_at"`
}

type AWSCheck struct {
	Key     string `json:"key"`
	Label   string `json:"label"`
	State   string `json:"state"`
	Message string `json:"message"`
	// Fix is the one change that makes a failed check pass. Empty unless
	// State is "fail".
	Fix string `json:"fix,omitempty"`
}

type AWSVerifyRequest struct {
	RoleARN string `json:"role_arn"`
}

type AWSVerifyResponse struct {
	Status     string     `json:"status"` // connected | action_needed
	AccountID  string     `json:"account_id"`
	RoleARN    string     `json:"role_arn"`
	Checks     []AWSCheck `json:"checks"`
	VerifiedAt time.Time  `json:"verified_at"`
	// Saved is false when the role could not be assumed: nothing about an
	// account is stored until the tenant has proved it controls it.
	Saved bool `json:"saved"`
}

// AWSPlatformSettings is the single row of nhi_schema.aws_platform_settings.
type AWSPlatformSettings struct {
	AccountID         string
	Region            string
	EventBusARN       string
	AssumerRoleARN    string
	CollectorRoleName string
	ForwardRuleName   string
}

// AWSAccountRecord is one row of nhi_schema.tenant_aws_accounts.
type AWSAccountRecord struct {
	TenantID       string
	AccountID      string
	RoleARN        string
	Status         string
	Checks         []AWSCheck
	LastVerifiedAt time.Time
	LastVerifiedBy string
	ConnectedAt    *time.Time
}
