package v1

import "time"

// ─────────────────────────────────────────────────────────────────────────
// GET/PUT /api/v1/settings ("ENDPOINT 1A: Get Settings" /
// "ENDPOINT 1B: Update Settings")
//
// Backing tables: user_settings (user_id, selected_account_ids,
// selected_regions, selected_scan_id, updated_at), accounts (tenant_id,
// account_id, region, is_default), nhi_scans_aws (scan_id, scan_end,
// status).
//
// Multi-tenant note: user_settings is provisioned separately in every
// tenant data database by migrations/tenant/001_user_settings.sql. The
// repository does not create schema objects at request time; apply the
// migration before serving traffic.
// ─────────────────────────────────────────────────────────────────────────

type SettingsResponse struct {
	Settings SettingsBlock `json:"settings"`
	Source   string        `json:"source"` // "user_settings" | "accounts"
}

type SettingsBlock struct {
	Accounts SettingsAccounts `json:"accounts"`
	Regions  SettingsRegions  `json:"regions"`
	Scan     SettingsScan     `json:"scan"`
}

type SettingsAccounts struct {
	Selected  []string `json:"selected"`
	IsDefault bool     `json:"is_default"`
}

type SettingsRegions struct {
	Selected  []string `json:"selected"`
	IsDefault bool     `json:"is_default"`
}

type SettingsScan struct {
	SelectedScanID    *string    `json:"selected_scan_id"`
	EffectiveScanID   *string    `json:"effective_scan_id"`
	EffectiveScanTime *time.Time `json:"effective_scan_time"`
	IsDefault         bool       `json:"is_default"`
}

// UpdateSettingsRequest is the PUT /api/v1/settings request body.
type UpdateSettingsRequest struct {
	SelectedAccountIDs []string `json:"selected_account_ids"`
	SelectedRegions    []string `json:"selected_regions"`
	SelectedScanID     *string  `json:"selected_scan_id"`
}

type UpdateSettingsResponse struct {
	Success  bool               `json:"success"`
	Settings UpdateSettingsEcho `json:"settings"`
}

type UpdateSettingsEcho struct {
	SelectedAccountIDs []string `json:"selected_account_ids"`
	SelectedRegions    []string `json:"selected_regions"`
	SelectedScanID     *string  `json:"selected_scan_id"`
}
