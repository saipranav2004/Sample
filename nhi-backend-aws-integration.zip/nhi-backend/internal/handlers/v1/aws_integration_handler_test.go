package v1

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"nhi-backend-api/internal/middleware"
	svcv1 "nhi-backend-api/internal/services/v1"
	"nhi-backend-api/pkg/jwt"
)

func withClaims(r *http.Request, role string) *http.Request {
	claims := &jwt.CustomClaims{UserID: "u@acme.test", Email: "u@acme.test", TenantID: "11111111-1111-1111-1111-111111111111", DBName: "nhi_tenant_a", Role: role}
	return r.WithContext(context.WithValue(r.Context(), middleware.UserClaimsKey, claims))
}

func decode(t *testing.T, rec *httptest.ResponseRecorder) map[string]any {
	t.Helper()
	var body map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("response is not JSON: %q", rec.Body.String())
	}
	return body
}

// The service is never reached on these paths, so it can be nil-backed.
func newTestAWSHandler() *AWSIntegrationHandler {
	return NewAWSIntegrationHandler(svcv1.NewAWSIntegrationService(nil, nil, 0))
}

func TestAWSVerifyRequiresAdmin(t *testing.T) {
	h := newTestAWSHandler()
	for _, role := range []string{"developer", "auditor", "team_lead", ""} {
		req := withClaims(httptest.NewRequest(http.MethodPost, "/api/v1/integrations/aws/verify", strings.NewReader(`{"role_arn":"x"}`)), role)
		rec := httptest.NewRecorder()
		h.Verify(rec, req)
		if rec.Code != http.StatusForbidden || decode(t, rec)["error"] != "FORBIDDEN" {
			t.Fatalf("role %q: status %d body %s", role, rec.Code, rec.Body.String())
		}
	}
}

func TestAWSVerifyRejectsMalformedBodies(t *testing.T) {
	h := newTestAWSHandler()
	for _, body := range []string{``, `not json`, `{"role_arn":"x","extra":1}`, `{"role_arn":"x"}{"role_arn":"y"}`, `{"role_arn":` + strings.Repeat(`"x`, 20000) + `"}`} {
		req := withClaims(httptest.NewRequest(http.MethodPost, "/api/v1/integrations/aws/verify", strings.NewReader(body)), "admin")
		rec := httptest.NewRecorder()
		h.Verify(rec, req)
		if rec.Code != http.StatusBadRequest || decode(t, rec)["error"] != "INVALID_REQUEST" {
			t.Fatalf("body %.40q: status %d body %s", body, rec.Code, rec.Body.String())
		}
	}
}

func TestAWSHandlersRejectUnknownQueryAndMissingClaims(t *testing.T) {
	h := newTestAWSHandler()

	rec := httptest.NewRecorder()
	h.Get(rec, httptest.NewRequest(http.MethodGet, "/api/v1/integrations/aws", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("no claims: status %d", rec.Code)
	}

	rec = httptest.NewRecorder()
	h.Get(rec, withClaims(httptest.NewRequest(http.MethodGet, "/api/v1/integrations/aws?x=1", nil), "admin"))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("unknown query: status %d", rec.Code)
	}
}
