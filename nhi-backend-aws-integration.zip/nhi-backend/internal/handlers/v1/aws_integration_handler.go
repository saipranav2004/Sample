package v1

import (
	"encoding/json"
	"errors"
	"io"
	"log"
	"net/http"
	"strings"

	"nhi-backend-api/internal/awsconnect"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	modelsv1 "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
	svcv1 "nhi-backend-api/internal/services/v1"
)

// AWSIntegrationHandler serves the "Connect AWS Account" setup.
//
//	GET  /api/v1/integrations/aws         any signed-in user (setup values: admin only)
//	POST /api/v1/integrations/aws/verify  admin only
type AWSIntegrationHandler struct{ service *svcv1.AWSIntegrationService }

func NewAWSIntegrationHandler(service *svcv1.AWSIntegrationService) *AWSIntegrationHandler {
	return &AWSIntegrationHandler{service: service}
}

// Connecting an account changes what the whole tenant sees, so it is an admin
// action, like the other tenant-wide writes in this API.
func canManageAWS(role string) bool {
	return strings.EqualFold(strings.TrimSpace(role), "admin")
}

func (h *AWSIntegrationHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		sendJSONResponse(w, http.StatusUnauthorized, models.APIResponse{Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED"})
		return
	}
	if rejectUnknownQuery(w, r, noQueryAllowed) {
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	result, err := h.service.Get(r.Context(), claims.TenantID, canManageAWS(claims.Role))
	if err != nil {
		writeAWSError(w, err, "Failed to load the AWS connection", "AWS_INTEGRATION_LOAD_FAILED")
		return
	}
	sendJSONResponse(w, http.StatusOK, models.APIResponse{Success: true, Message: "AWS connection retrieved", Data: result})
}

func (h *AWSIntegrationHandler) Verify(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		sendJSONResponse(w, http.StatusUnauthorized, models.APIResponse{Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED"})
		return
	}
	if rejectUnknownQuery(w, r, noQueryAllowed) {
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	if !canManageAWS(claims.Role) {
		sendJSONResponse(w, http.StatusForbidden, models.APIResponse{Success: false, Message: "Only an admin can connect an AWS account", Error: "FORBIDDEN"})
		return
	}

	var req modelsv1.AWSVerifyRequest
	r.Body = http.MaxBytesReader(w, r.Body, 16<<10)
	defer r.Body.Close()
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&req); err != nil {
		sendJSONResponse(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "Request body must be JSON: {\"role_arn\": \"…\"}", Error: "INVALID_REQUEST"})
		return
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		sendJSONResponse(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "Request body must contain exactly one JSON object", Error: "INVALID_REQUEST"})
		return
	}

	result, err := h.service.Verify(r.Context(), claims.TenantID, claims.UserID, req.RoleARN)
	if err != nil {
		writeAWSError(w, err, "Failed to verify the AWS connection", "AWS_VERIFY_FAILED")
		return
	}
	message := "Some checks need attention"
	if result.Status == modelsv1.AWSStatusConnected {
		message = "AWS account connected"
	}
	sendJSONResponse(w, http.StatusOK, models.APIResponse{Success: true, Message: message, Data: result})
}

// writeAWSError maps service errors to responses. Messages are written for
// the person on the setup page; internal detail stays in the server log.
func writeAWSError(w http.ResponseWriter, err error, fallback, fallbackCode string) {
	var invalid *awsconnect.ErrInvalidRoleARN
	switch {
	case errors.As(err, &invalid):
		sendJSONResponse(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: invalid.Message, Error: "INVALID_ROLE_ARN"})
	case errors.Is(err, svcv1.ErrAWSAccountClaimed):
		sendJSONResponse(w, http.StatusConflict, models.APIResponse{Success: false, Message: "This AWS account is already connected to another workspace. Contact support if that is unexpected", Error: "AWS_ACCOUNT_IN_USE"})
	case errors.Is(err, svcv1.ErrAWSVerifyInProgress):
		sendJSONResponse(w, http.StatusTooManyRequests, models.APIResponse{Success: false, Message: "A connection check is already running. Wait for it to finish", Error: "AWS_VERIFY_IN_PROGRESS"})
	case errors.Is(err, repository.ErrAWSTablesMissing):
		log.Printf("aws integration: %v", err)
		sendJSONResponse(w, http.StatusServiceUnavailable, models.APIResponse{Success: false, Message: "AWS connections are not set up on this platform yet. Contact support", Error: "AWS_PLATFORM_NOT_CONFIGURED"})
	case errors.Is(err, svcv1.ErrAWSPlatformNotConfigured):
		sendJSONResponse(w, http.StatusServiceUnavailable, models.APIResponse{Success: false, Message: "AWS connections are not set up on this platform yet. Contact support", Error: "AWS_PLATFORM_NOT_CONFIGURED"})
	case errors.Is(err, svcv1.ErrAWSUnavailable):
		sendJSONResponse(w, http.StatusServiceUnavailable, models.APIResponse{Success: false, Message: "AWS cannot be reached right now. Try again shortly", Error: "AWS_UNAVAILABLE"})
	default:
		log.Printf("aws integration: %v", err)
		sendJSONResponse(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: fallback, Error: fallbackCode})
	}
}
