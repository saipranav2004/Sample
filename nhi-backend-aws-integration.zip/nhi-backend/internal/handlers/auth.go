package handlers

import (
	"encoding/json"
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/services"
)

type AuthHandler struct {
	authService *services.AuthService
}

func NewAuthHandler(authService *services.AuthService) *AuthHandler {
	return &AuthHandler{authService: authService}
}

// Login handles POST /api/v1/login
func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	if rejectUnknownQuery(w, r, noQueryAllowed) {
		return
	}

	// Prevent large payloads / slowloris
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20) // 1MB
	defer r.Body.Close()

	var req models.LoginRequest
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(&req); err != nil {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "Invalid request payload",
			Error:   err.Error(),
		})
		return
	}

	if req.Email == "" || req.Password == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "Email and password are required",
		})
		return
	}

	resp, err := h.authService.Login(r.Context(), req)
	if err != nil {
		log.Printf("login failed: %v", err)
		sendJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false,
			Message: "Invalid email or password",
			Error:   "AUTHENTICATION_FAILED",
		})
		return
	}

	sendJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "Login successful",
		Data:    resp,
	})
}

// Me handles GET /api/v1/me
func (h *AuthHandler) Me(w http.ResponseWriter, r *http.Request) {
	if rejectUnknownQuery(w, r, noQueryAllowed) {
		return
	}

	claims := middleware.GetClaims(r)
	if claims == nil {
		sendJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false,
			Message: "Unauthorized",
		})
		return
	}

	sendJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "User profile retrieved",
		Data: map[string]interface{}{
			"user_id":   claims.UserID,
			"tenant_id": claims.TenantID,
			"db_name":   claims.DBName,
			"role":      claims.Role,
		},
	})
}

// Helper utility for sending JSON responses
func sendJSON(w http.ResponseWriter, statusCode int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(data)
}
