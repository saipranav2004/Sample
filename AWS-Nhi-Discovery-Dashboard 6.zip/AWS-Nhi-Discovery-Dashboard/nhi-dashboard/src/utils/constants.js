// Classification colors and labels
export const CLASSIFICATION_CONFIG = {
  HUMAN:         { color: '#3B82F6', bg: 'bg-blue-100',   text: 'text-blue-800',   icon: '🧑', label: 'Human' },
  NHI_SERVICE:   { color: '#8B5CF6', bg: 'bg-purple-100', text: 'text-purple-800', icon: '🤖', label: 'NHI Service' },
  NHI_AGENT:     { color: '#F59E0B', bg: 'bg-amber-100',  text: 'text-amber-800',  icon: '🔧', label: 'NHI Agent' },
  NHI_CICD:      { color: '#10B981', bg: 'bg-emerald-100',text: 'text-emerald-800',icon: '🏭', label: 'NHI CI/CD' },
  NHI_SAAS:      { color: '#EC4899', bg: 'bg-pink-100',   text: 'text-pink-800',   icon: '🤝', label: 'NHI SaaS' },
  NHI_EPHEMERAL: { color: '#06B6D4', bg: 'bg-cyan-100',   text: 'text-cyan-800',   icon: '⏳', label: 'NHI Ephemeral' },
  DUAL_IDENTITY: { color: '#F97316', bg: 'bg-orange-100', text: 'text-orange-800', icon: '🔀', label: 'Dual Identity' },
  UNCLASSIFIED:  { color: '#6B7280', bg: 'bg-gray-100',   text: 'text-gray-800',   icon: '❓', label: 'Unclassified' },
};

// Severity colors
export const SEVERITY_CONFIG = {
  CRITICAL: { color: '#DC2626', bg: 'bg-red-100',     text: 'text-red-800',     icon: '🔴' },
  HIGH:     { color: '#EA580C', bg: 'bg-orange-100',  text: 'text-orange-800',  icon: '🟠' },
  MEDIUM:   { color: '#CA8A04', bg: 'bg-yellow-100',  text: 'text-yellow-800',  icon: '🟡' },
  LOW:      { color: '#16A34A', bg: 'bg-green-100',   text: 'text-green-800',   icon: '🟢' },
};

// Owner type labels
export const OWNER_TYPE_LABELS = {
  HUMAN:       '👤 Human',
  NHI_CICD:    '🏭 CI/CD Pipeline',
  NHI_IAC:     '📦 IaC Managed',
  AWS_SERVICE: '☁️ AWS Service',
  ORPHANED:    '⚠️ Orphaned',
};

// Navigation menu items
export const NAV_ITEMS = [
  { path: '/dashboard',  label: 'Dashboard',   icon: 'LayoutDashboard' },
  { path: '/identities', label: 'Identities',  icon: 'Fingerprint' },
  { path: '/secrets',    label: 'Secrets',     icon: 'KeyRound' },
  { path: '/scans',      label: 'Scan History',icon: 'History' },
];