import { CLASSIFICATION_CONFIG } from './constants';

// Format date safely with error handling and fallback
export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '—';
    return date.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '—';
  }
};

// Truncate long strings safely
export const truncate = (str, maxLen = 50) => {
  if (!str || typeof str !== 'string') return '—';
  return str.length > maxLen ? `${str.substring(0, maxLen - 3)}...` : str;
};

// Safe classification badge config accessor
export const getClassificationConfig = (classification) => {
  const key = classification?.toString()?.toUpperCase() ?? 'UNCLASSIFIED';
  return CLASSIFICATION_CONFIG?.[key] ?? CLASSIFICATION_CONFIG.UNCLASSIFIED;
};