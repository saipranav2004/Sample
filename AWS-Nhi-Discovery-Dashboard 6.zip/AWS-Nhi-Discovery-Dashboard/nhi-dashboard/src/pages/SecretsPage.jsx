import React, { useState, useEffect } from 'react';
import { getSecrets } from '../services/secretService';
import { SeverityBadge } from '../components/common/Badge';
import Pagination from '../components/common/Pagination';
import Loader from '../components/common/Loader';
import ScanSelector from '../components/common/ScanSelector';
import IdentityDetailModal from '../components/common/IdentityDetailModal';
import { formatDate, truncate } from '../utils/helpers';
import { 
  KeyRound, 
  Search, 
  RefreshCw, 
  AlertOctagon, 
  ShieldAlert, 
  Eye, 
  FileCode 
} from 'lucide-react';

const SecretsPage = () => {
  const [secrets, setSecrets] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);

  // Filters & Pagination state
  const [search, setSearch] = useState('');
  const [scanId, setScanId] = useState(''); // '' defaults to latest scan
  const [page, setPage] = useState(1);
  const pageSize = 15;

  const [selectedSecret, setSelectedSecret] = useState(null);

  const fetchSecrets = async () => {
    setLoading(true);
    try {
      const res = await getSecrets(page, pageSize, search, scanId || undefined);
      if (res?.success) {
        setSecrets(res?.data ?? []);
        setTotalCount(res?.total_count ?? 0);
      }
    } catch (err) {
      console.error('Failed to fetch secrets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchSecrets();
    }, 250);
    return () => clearTimeout(timer);
  }, [search, page, scanId]);

  const handleResetFilters = () => {
    setSearch('');
    setPage(1);
  };

  return (
    <div className="space-y-6">
      {/* Header with Scan Selector & Refresh */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <KeyRound className="w-6 h-6 text-amber-500 dark:text-amber-400" />
            Secrets & Machine Credentials
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Audit of all {totalCount ?? 0} exposed credentials, unrotated keys, and cryptographic tokens.
          </p>
        </div>

        {/* Scan Selector & Refresh alignment */}
        <div className="flex items-center gap-3">
          <ScanSelector selectedScanId={scanId} onScanChange={(id) => { setScanId(id); setPage(1); }} />
          <button
            onClick={fetchSecrets}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition-colors w-fit cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search secrets by name, evidence, or resource..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <ShieldAlert className="w-4 h-4 text-amber-500 dark:text-amber-400" />
          <span>Non-IAM secret scan enabled across 6 subsystems</span>
        </div>
      </div>

      {/* Secrets Table */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[400px]">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-20 flex justify-center"><Loader text="Scanning secrets inventory..." /></div>
          ) : (secrets?.length ?? 0) === 0 ? (
            <div className="py-20 text-center text-slate-400 dark:text-slate-500 text-sm flex flex-col items-center gap-2">
              <AlertOctagon className="w-8 h-8 text-slate-300 dark:text-slate-600" />
              <span>No exposed secrets or credentials detected for this scan run.</span>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-5">Secret Name & Resource</th>
                  <th className="py-3 px-4">Service Category</th>
                  <th className="py-3 px-4">Evidence / Violation</th>
                  <th className="py-3 px-4">Owner / Lineage</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {secrets?.map((s) => (
                  <tr key={s?.id ?? Math.random()} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors">
                    <td className="py-3.5 px-5 max-w-[260px]">
                      <div className="font-semibold text-amber-600 dark:text-amber-400 truncate flex items-center gap-1.5" title={s?.name ?? ''}>
                        <FileCode className="w-3.5 h-3.5 shrink-0" />
                        {s?.name ?? '—'}
                      </div>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 font-mono truncate" title={s?.arn ?? ''}>
                        {truncate(s?.arn, 40)}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-mono text-[11px]">
                        {s?.trust_type || s?.identity_type || 'SECRET'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 max-w-[340px]">
                      <div className="text-slate-600 dark:text-slate-300 text-[11px] font-mono leading-relaxed truncate" title={s?.evidence ?? ''}>
                        {s?.evidence ?? 'Stored sensitive credential'}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 max-w-[160px] whitespace-nowrap">
                      <div className="text-slate-700 dark:text-slate-200 font-medium truncate">
                        {s?.owner_name || s?.owner_type || 'Unassigned'}
                      </div>
                      {s?.created_at && (
                        <div className="text-[10px] text-slate-400 dark:text-slate-500">
                          {formatDate(s?.created_at)}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-5 text-right whitespace-nowrap">
                      <button
                        onClick={() => setSelectedSecret(s)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-500 dark:hover:bg-amber-500 text-amber-600 dark:text-amber-400 hover:text-white border border-amber-200 dark:border-amber-500/20 text-[11px] font-semibold transition-all cursor-pointer"
                      >
                        <Eye className="w-3 h-3" />
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        {(totalCount ?? 0) > 0 && (
          <Pagination
            page={page}
            pageSize={pageSize}
            totalCount={totalCount ?? 0}
            onPageChange={(newPage) => setPage(newPage)}
          />
        )}
      </div>

      {/* Reusable Detail Modal */}
      {selectedSecret && (
        <IdentityDetailModal
          identity={selectedSecret}
          onClose={() => setSelectedSecret(null)}
        />
      )}
    </div>
  );
};

export default SecretsPage;