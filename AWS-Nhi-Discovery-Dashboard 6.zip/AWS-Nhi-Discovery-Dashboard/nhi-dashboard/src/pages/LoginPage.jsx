import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { login as loginApi } from '../services/authService';
import ThemeToggle from '../components/common/ThemeToggle';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  AlertCircle, 
  Fingerprint, 
  KeyRound, 
  Activity, 
  ArrowRight,
  CheckCircle2,
  Eye
} from 'lucide-react';

const LoginPage = () => {
  const [email, setEmail] = useState('abhishek.tiwari@gmail.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await loginApi(email, password);
      if (res?.success) {
        login(res.data.token, res.data.user);
        navigate('/dashboard');
      } else {
        setError(res?.message ?? 'Login failed');
      }
    } catch (err) {
      setError(err?.response?.data?.message ?? 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: Fingerprint, text: 'Discover 1000+ Non-Human Identity types' },
    { icon: KeyRound, text: 'Detect exposed secrets across 6 subsystems' },
    { icon: Activity, text: 'Real-time CloudTrail activity correlation' },
    // { icon: Eye, text: 'Zero-configuration ownership lineage tracking' },
  ];

  return (
    <div className="h-screen w-full bg-white dark:bg-slate-950 flex overflow-hidden transition-colors duration-300">
      
      {/* Theme Toggle */}
      <div className="fixed top-6 right-6 z-30">
        <ThemeToggle />
      </div>

      {/* ============================================================ */}
      {/* LEFT PANEL - Enterprise Branding                             */}
      {/* ============================================================ */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 dark:from-indigo-950 dark:via-slate-950 dark:to-purple-950 relative overflow-hidden">
        
        {/* Decorative Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div 
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), 
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}
          ></div>
          <div className="absolute top-1/4 -left-24 w-96 h-96 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 -right-24 w-96 h-96 bg-indigo-400/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-10 right-10 w-64 h-64 border border-white/10 rounded-full"></div>
          <div className="absolute top-20 right-20 w-48 h-48 border border-white/10 rounded-full"></div>
        </div>

        {/* Content - Structured to guarantee no collisions */}
        <div className="relative z-10 flex flex-col justify-between h-full p-12 xl:p-16 w-full text-white">
          
          {/* Top: Brand Logo (Natural flow in flex, absolutely no overlap) */}
          <div className="shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <ShieldCheck className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-extrabold tracking-tight">NHI Discovery and Inventory</h1>
                <p className="text-xs text-indigo-200">Enterprise Identity Governance</p>
              </div>
            </div>
          </div>

          {/* Middle: Marketing Content & Features (Vertically centered within remaining space) */}
          <div className="my-auto py-8 space-y-8">
            <div>
              <h2 className="text-4xl xl:text-5xl font-extrabold leading-tight tracking-tight">
                Secure every <br />
                <span className="bg-gradient-to-r from-yellow-200 to-pink-200 bg-clip-text text-transparent">
                  Non-Human Identity
                </span> <br />
                in your cloud.
              </h2>

              <p className="mt-4 text-base text-indigo-100 max-w-md leading-relaxed">
                Discover, classify, and govern every AWS service account, machine identity, and exposed credential across your entire multi-account environment.
              </p>
            </div>

            {/* Feature List */}
            <div className="space-y-3">
              {features.map((feature, idx) => {
                const Icon = feature.icon;
                return (
                  <div key={idx} className="flex items-center gap-3 text-sm">
                    <div className="p-1.5 bg-white/10 rounded-lg border border-white/20">
                      <Icon className="w-3.5 h-3.5 text-white" />
                    </div>
                    <span className="text-indigo-100">{feature.text}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom: Empty spacer to keep Flex structure balanced and aligned */}
          <div className="shrink-0 h-4"></div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* RIGHT PANEL - Login Form                                     */}
      {/* ============================================================ */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center items-center px-6 sm:px-12 bg-slate-50 dark:bg-slate-950 relative overflow-hidden">
        
        <div className="absolute inset-0 bg-gradient-to-br from-white via-slate-50 to-indigo-50/30 dark:from-slate-950 dark:via-slate-950 dark:to-indigo-950/20 pointer-events-none"></div>

        <div className="w-full max-w-md z-10">
          
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8 flex justify-center">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/30">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
              <span className="font-extrabold text-2xl text-slate-900 dark:text-white">NHI Engine</span>
            </div>
          </div>

          {/* Welcome Header with restored success badge */}
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-full text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-4">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Secure Enterprise Access</span>
            </div>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Welcome back
            </h2>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
              Sign in to continue to your identity governance console.
            </p>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 flex items-start gap-3 text-red-700 dark:text-red-400 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Authentication Failed</p>
                <p className="text-xs mt-0.5 opacity-90">{error}</p>
              </div>
            </div>
          )}

          {/* Login Form */}
          <form className="space-y-5" onSubmit={handleSubmit}>
            
            {/* Email */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                Work Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Password
                </label>
                {/* <a href="#" className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300">
                  Forgot password?
                </a> */}
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl shadow-lg shadow-indigo-500/20 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer group"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In to Console</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;