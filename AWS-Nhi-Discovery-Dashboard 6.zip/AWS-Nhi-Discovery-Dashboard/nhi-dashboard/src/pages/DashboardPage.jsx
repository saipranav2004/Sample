// src/pages/DashboardPage.jsx
import React, { useState, useEffect } from 'react';
import { getDashboardSummary } from '../services/dashboardService';
import { useAuth } from '../hooks/useAuth';
import { useScan } from '../context/ScanContext';
import StatCard from '../components/common/StatCard';
import ClassificationPie from '../components/charts/ClassificationPie';
import CredentialBarChart from '../components/charts/CredentialBarChart';
import Loader from '../components/common/Loader';
import { 
  Bot, KeyRound, AlertTriangle, Users, ShieldCheck, ShieldOff, 
  Fingerprint, BarChart3, Workflow, ShieldAlert, Moon, UsersRound, Globe, Clock 
} from 'lucide-react';

const DashboardPage = () => {
  const { user } = useAuth();
  const { selectedScanId } = useScan();
  const [summary, setSummary] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(true);

  useEffect(() => {
    let isMounted = true;
    const fetchSummary = async () => {
      setLoadingSummary(true);
      try {
        const res = await getDashboardSummary({ scan_id: selectedScanId || undefined });
        if (isMounted && res?.success) {
          setSummary(res?.data || null);
        }
      } catch (err) { 
        console.error('Failed to load dashboard metrics:', err); 
      } finally { 
        if (isMounted) setLoadingSummary(false); 
      }
    };
    fetchSummary();
    return () => { isMounted = false; };
  }, [selectedScanId]);

  if (loadingSummary) return <Loader text="Loading dashboard metrics..." />;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
          Welcome back, {user?.full_name || 'Admin'} 👋
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Here is the security posture and identity distribution across your AWS environment.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* Row 1 */}
        <StatCard title="Total Identities" value={summary?.total_identities || 0} icon={Fingerprint} color="indigo" subtitle="All users, roles & service IDs" />
        <StatCard title="Total NHIs" value={summary?.total_nhis || 0} icon={Bot} color="cyan" subtitle="Services, bots & pipelines" />
        <StatCard title="Human Users" value={summary?.total_humans || 0} icon={Users} color="emerald" subtitle="Console & SSO identities" />
        <StatCard title="Humans Without MFA" value={summary?.total_humans_without_mfa || 0} icon={ShieldOff} color="red" subtitle="Critical: MFA disabled" />

        {/* Row 2 */}
        <StatCard title="Total Credentials" value={summary?.total_credentials || 0} icon={KeyRound} color="amber" subtitle="Keys, passwords, certs & tokens" />
        <StatCard title="Orphaned Identities" value={summary?.total_orphaned || 0} icon={AlertTriangle} color="red" subtitle="No assigned team / creator" />
        <StatCard title="Total NHI Agents" value={summary?.total_nhi_agents || 0} icon={UsersRound} color="blue" subtitle="Discovered running machine agents" />
        <StatCard title="CI/CD Pipelines" value={summary?.total_nhi_cicd || 0} icon={Workflow} color="violet" subtitle="Pipelines & deployment bots" />

        {/* Row 3 */}
        <StatCard title="Federated Identities" value={summary?.total_federated || 0} icon={Globe} color="teal" subtitle="SSO, SAML & OIDC logins" />
        <StatCard title="Admin Accounts" value={summary?.total_admin || 0} icon={ShieldAlert} color="red" subtitle="Identities with admin level access" />
        <StatCard title="Stale Accounts (90+ Days)" value={summary?.total_stale_90plus || 0} icon={Moon} color="red" subtitle="No activity in over 90 days" />
        <StatCard title="Inactive Accounts (30+ Days)" value={summary?.total_inactive_30plus || 0} icon={Clock} color="amber" subtitle="Unused between 30-90 days" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Classification Chart Card */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />
            Identity Classification
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-2">Breakdown of all discovery categories</p>
          <ClassificationPie data={summary?.classification_breakdown || {}} />
        </div>

        {/* Credentials Breakdown Chart Card */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col">
          <div className="mb-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />
              Credential Distributions
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Distribution of credentials, certificates, and access keys active inside identities
            </p>
          </div>

          <div className="flex-1 overflow-y-auto max-h-[340px] pr-2">
            <CredentialBarChart data={summary?.credentials_breakdown || {}} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;