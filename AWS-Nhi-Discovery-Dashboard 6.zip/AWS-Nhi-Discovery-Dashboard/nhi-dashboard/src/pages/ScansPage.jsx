import React, { useState, useEffect } from 'react';
import { getScans } from '../services/scanService';
import Pagination from '../components/common/Pagination';
import Loader from '../components/common/Loader';
import { formatDate } from '../utils/helpers';
import { History, RefreshCw, CheckCircle2, Clock, Bot, KeyRound, Activity } from 'lucide-react';

const ScansPage = () => {
  const [scans, setScans] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const fetchScans = async () => {
    setLoading(true);
    try {
      const res = await getScans(page, pageSize);
      if (res?.success) {
        setScans(res?.data ?? []);
        setTotalCount(res?.total_count ?? 0);
      }
    } catch (err) {
      console.error('Failed to fetch scan history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchScans(); }, [page]);

  const calculateDuration = (startStr, endStr) => {
    if (!startStr || !endStr) return '—';
    try {
      const diffMs = Math.abs(new Date(endStr) - new Date(startStr));
      const seconds = Math.floor((diffMs / 1000) % 60);
      const minutes = Math.floor((diffMs / (1000 * 60)) % 60);
      return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
    } catch {
      return '—';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <History className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
            Scan History & Audits
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Historical log of all {totalCount ?? 0} discovery scans executed across client environments.
          </p>
        </div>
        <button
          onClick={fetchScans}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition-colors w-fit cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Scans Table */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[400px]">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-20 flex justify-center"><Loader text="Loading scan audit history..." /></div>
          ) : (scans?.length ?? 0) === 0 ? (
            <div className="py-20 text-center text-slate-400 dark:text-slate-500 text-sm">
              No previous scan logs found in database.
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-5">Scan ID</th>
                  <th className="py-3 px-4">Target Account</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-center">Identities</th>
                  <th className="py-3 px-4 text-center">Events</th>
                  <th className="py-3 px-4 text-center">Secrets</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-5 text-right">Executed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {scans?.map((scan) => (
                  <tr key={scan?.scan_id ?? Math.random()} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors">
                    <td className="py-3.5 px-5 font-mono text-indigo-600 dark:text-indigo-400 font-semibold whitespace-nowrap">
                      {scan?.scan_id ?? '—'}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="text-slate-900 dark:text-white font-medium">{scan?.target_name || 'AWS Account'}</div>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">{scan?.account_id ?? '—'}</div>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {scan?.status ?? 'COMPLETED'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono font-semibold text-slate-900 dark:text-white">
                      <span className="inline-flex items-center gap-1">
                        <Bot className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                        {scan?.total_identities ?? 0}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-slate-600 dark:text-slate-300">
                      <span className="inline-flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5 text-cyan-500 dark:text-cyan-400" />
                        {scan?.total_events ?? 0}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-amber-600 dark:text-amber-400">
                      <span className="inline-flex items-center gap-1">
                        <KeyRound className="w-3.5 h-3.5" />
                        {scan?.total_secrets ?? 0}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 dark:text-slate-400 whitespace-nowrap font-mono flex items-center gap-1.5 mt-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                      {calculateDuration(scan?.scan_start, scan?.scan_end)}
                    </td>
                    <td className="py-3.5 px-5 text-right text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatDate(scan?.scan_start)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        {(totalCount ?? 0) > 0 && (
          <Pagination page={page} pageSize={pageSize} totalCount={totalCount ?? 0} onPageChange={(newPage) => setPage(newPage)} />
        )}
      </div>
    </div>
  );
};

export default ScansPage;