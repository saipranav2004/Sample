// src/pages/CredentialsPage.jsx
import React, { useState, useEffect } from 'react';
import { getFlattenedCredentials } from '../services/credentialService';
import Pagination from '../components/common/Pagination';
import Loader from '../components/common/Loader';
import { useScan } from '../context/ScanContext';
import { formatDate, truncate } from '../utils/helpers';
import CredentialDetailModal from '../components/common/CredentialDetailModal';
import { 
  Search, RefreshCw, KeyRound, Key, Smartphone, Fingerprint, FileLock, 
  FileText, Terminal, Cloud, ShieldCheck, HelpCircle, Activity, Eye 
} from 'lucide-react';

const CRED_TYPES = [
  'AWS_ACCESS_KEY', 'CONSOLE_PASSWORD', 'MFA_DEVICE', 'SSH_PUBLIC_KEY',
  'ENV_SECRET', 'SSM_PARAMETER', 'SECRETS_MANAGER_SECRET', 'X509_CERTIFICATE',
  'OAUTH_CLIENT_SECRET', 'API_KEY', 'OIDC_TOKEN'
];

const CREDENTIAL_ICONS = {
  AWS_ACCESS_KEY:         Key,
  CONSOLE_PASSWORD:       ShieldCheck,
  MFA_DEVICE:             Smartphone,
  SSH_PUBLIC_KEY:         Fingerprint,
  ENV_SECRET:             FileLock,
  SSM_PARAMETER:          FileText,
  SECRETS_MANAGER_SECRET: KeyRound,
  X509_CERTIFICATE:       ShieldCheck,
  OAUTH_CLIENT_SECRET:    Key,
  API_KEY:                Terminal,
  IOT_ROLE_ALIAS:         Cloud,
  OIDC_TOKEN:             ShieldCheck,
};

const safeLen = (arr) => (Array.isArray(arr) ? arr.length : 0);

const CredentialsPage = () => {
  const { selectedScanId } = useScan();
  const [credentials, setCredentials] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [credType, setCredType] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 15;

  // Modal State
  const [selectedCredential, setSelectedCredential] = useState(null);

  const fetchCredentials = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getFlattenedCredentials({
        search: search?.trim() ? search.trim() : undefined,
        type: credType || undefined,
        scan_id: selectedScanId || undefined,
        page: page || 1,
        page_size: pageSize,
      });

      if (res?.success) {
        setCredentials(Array.isArray(res?.data) ? res.data : []);
        setTotalCount(typeof res?.total_count === 'number' ? res.total_count : 0);
      } else {
        setCredentials([]);
        setTotalCount(0);
        setError(res?.message || 'Failed to load credentials.');
      }
    } catch (err) {
      console.error('Failed to load credentials:', err);
      setCredentials([]);
      setTotalCount(0);
      setError(err?.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchCredentials();
    }, 250);
    return () => clearTimeout(timer);
  }, [search, credType, selectedScanId, page]);

  const handleResetFilters = () => {
    setSearch('');
    setCredType('');
    setPage(1);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2 tracking-tight">
            <KeyRound className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
            Exposed Credentials Inventory
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Drill down into all {totalCount || 0} individual credentials, tokens, and secrets across identities.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchCredentials}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search || ''}
            onChange={(e) => {
              setSearch(e?.target?.value || '');
              setPage(1);
            }}
            placeholder="Search credential ID or identity name..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>
        <div>
          <select
            value={credType || ''}
            onChange={(e) => {
              setCredType(e?.target?.value || '');
              setPage(1);
            }}
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="">All Credential Types</option>
            {CRED_TYPES.map((t) => (
              <option key={t} value={t}>{t?.replace(/_/g, ' ')}</option>
            ))}
          </select>
        </div>
        <button
          onClick={handleResetFilters}
          className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-800 transition-colors cursor-pointer text-center"
        >
          Clear Filters
        </button>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 rounded-xl px-4 py-2.5 text-xs font-medium animate-pulse">
          {error}
        </div>
      )}

      {/* Table Container */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[400px]">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-20 flex justify-center">
              <Loader text="Loading credentials..." />
            </div>
          ) : safeLen(credentials) === 0 ? (
            <div className="py-20 text-center text-slate-400 dark:text-slate-500 text-sm">
              No matching credentials found.
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="py-3 pl-6 pr-4 whitespace-nowrap">Credential ID & Type</th>
                  <th className="py-3 px-4 whitespace-nowrap">Owning Identity</th>
                  {/* <th className="py-3 px-4 whitespace-nowrap">Status</th> */}
                  <th className="py-3 px-4 whitespace-nowrap">Last Used</th>
                  <th className="py-3 px-4 whitespace-nowrap">Created At</th>
                  <th className="py-3 px-4 whitespace-nowrap">Description</th>
                  <th className="py-3 pl-4 pr-6 text-right whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {credentials.map((cred, idx) => {
                  if (!cred) return null;
                  const Icon = CREDENTIAL_ICONS[cred?.type] || HelpCircle;
                  const rowKey = `${cred?.identity_id || idx}-${cred?.cred_id || idx}-${idx}`;

                  return (
                    <tr 
                      key={rowKey} 
                      onClick={() => setSelectedCredential(cred)}
                      className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors cursor-pointer"
                    >
                      {/* Credential ID & Type */}
                      <td className="py-3.5 pl-6 pr-4 max-w-[240px]">
                        <div className="flex items-center gap-3">
                          <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
                            <Icon className="w-4 h-4 shrink-0" />
                          </div>
                          <div className="min-w-0">
                            <div className="font-semibold text-slate-900 dark:text-white truncate font-mono text-[11px]" title={cred?.cred_id}>
                              {cred?.cred_id || '—'}
                            </div>
                            <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mt-0.5">
                              {cred?.type ? cred.type.replace(/_/g, ' ') : 'UNKNOWN'}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Owning Identity */}
                      <td className="py-3.5 px-4 max-w-[200px]">
                        <div className="font-semibold text-slate-900 dark:text-white truncate" title={cred?.identity_name}>
                          {cred?.identity_name || '—'}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">{truncate(cred?.identity_arn || '', 30)}</div>
                      </td>

                      {/* Status */}
                      {/* <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700/60">
                          {cred?.status || 'Active'}
                        </span>
                      </td> */}

                      {/* Last Used */}
                      <td className="py-3.5 px-4 whitespace-nowrap text-slate-600 dark:text-slate-300">
                        {cred?.last_used_date ? (
                          <div>
                            <div>{formatDate(cred.last_used_date)?.split(',')[0]}</div>
                            {cred?.last_used_service && (
                              <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                                <Activity className="w-3 h-3" /> {cred.last_used_service}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Never</span>
                        )}
                      </td>

                      {/* Created At */}
                      <td className="py-3.5 px-4 whitespace-nowrap text-slate-500">
                        {cred?.created_at ? formatDate(cred.created_at)?.split(',')[0] : '—'}
                      </td>

                      {/* Description */}
                      <td className="py-3.5 px-4 max-w-[220px] text-slate-500 dark:text-slate-400 truncate" title={cred?.description}>
                        {cred?.description || '—'}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 pl-4 pr-6 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => setSelectedCredential(cred)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 bg-indigo-50 dark:bg-indigo-500/10 hover:bg-indigo-100 dark:hover:bg-indigo-500/20 px-2.5 py-1.5 rounded-lg border border-indigo-200/60 dark:border-indigo-500/20 transition-colors cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        {totalCount > 0 && (
          <Pagination
            page={page || 1}
            pageSize={pageSize}
            totalCount={totalCount}
            onPageChange={(p) => setPage(p || 1)}
          />
        )}
      </div>

      {/* Detailed Inspection Modal */}
      {selectedCredential && (
        <CredentialDetailModal
          credential={selectedCredential}
          onClose={() => setSelectedCredential(null)}
        />
      )}
    </div>
  );
};

export default CredentialsPage;