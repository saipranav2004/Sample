// src/pages/Identities.jsx
import React, { useState, useEffect } from 'react';
import { getIdentities } from '../services/identityService';
import { ClassificationBadge } from '../components/common/Badge';
import Pagination from '../components/common/Pagination';
import Loader from '../components/common/Loader';
import IdentityDetailModal from '../components/common/IdentityDetailModal';
import { useScan } from '../context/ScanContext';
import { truncate } from '../utils/helpers';
import { Search, RefreshCw, KeyRound, Eye, Fingerprint, Shield, Key, UsersRound } from 'lucide-react';

// ── Standard AWS classification enum values ──
const CLASSIFICATIONS = [
  'HUMAN', 'NHI_SERVICE', 'NHI_AGENT', 'NHI_CICD',
  'NHI_SAAS', 'NHI_EPHEMERAL', 'DUAL_IDENTITY', 'UNCLASSIFIED',
];

// ── Synthetic security posture filters (not backed by classification column) ──
const SYNTHETIC_FILTERS = [
  { value: 'HUMANS_WITHOUT_MFA', label: 'Humans Without MFA' },
  { value: 'FEDERATED', label: 'Federated Identities' },
  { value: 'ADMINS', label: 'Admin Accounts' },
  { value: 'STALE', label: 'Stale Accounts (90+ days)' },
  { value: 'INACTIVE', label: 'Inactive Accounts (30-90 days)' },
];

const countCredentials = (raw) => {
  try {
    if (raw == null) return 0;
    if (Array.isArray(raw)) return raw.length;
    if (typeof raw === 'string') {
      const trimmed = raw.trim();
      if (!trimmed || !trimmed.startsWith('[')) return 0;
      const parsed = JSON.parse(trimmed);
      return Array.isArray(parsed) ? parsed.length : 0;
    }
    return 0;
  } catch (err) {
    console.warn('countCredentials parser error:', err);
    return 0;
  }
};

const safeLen = (arr) => (Array.isArray(arr) ? arr.length : 0);

const daysSince = (dateStr) => {
  if (!dateStr) return null;
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  } catch {
    return null;
  }
};

const stalenessColor = (days) => {
  if (days == null) return 'text-slate-300 dark:text-slate-600';
  if (days <= 30) return 'text-green-600 dark:text-green-400';
  if (days <= 90) return 'text-yellow-600 dark:text-yellow-400';
  return 'text-red-600 dark:text-red-400';
};

const IdentitiesPage = () => {
  const { selectedScanId } = useScan();
  const [identities, setIdentities] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [classification, setClassification] = useState('');
  const [ownerType, setOwnerType] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 15;

  const [selectedIdentity, setSelectedIdentity] = useState(null);

  const fetchIdentities = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        search: search?.trim() ? search.trim() : undefined,
        owner_type: ownerType || undefined,
        scan_id: selectedScanId || undefined,
        page: page || 1,
        page_size: pageSize,
      };

      switch (classification) {
        case 'HUMANS_WITHOUT_MFA':
          params.classification = 'HUMAN';
          params.without_mfa = true;
          break;
        case 'FEDERATED':
          params.is_federated = true;
          break;
        case 'ADMINS':
          params.is_admin = true;
          break;
        case 'STALE':
          params.is_stale = true;
          break;
        case 'INACTIVE':
          params.is_inactive = true;
          break;
        default:
          if (classification) params.classification = classification;
      }

      const res = await getIdentities(params);
      if (res?.success) {
        setIdentities(Array.isArray(res?.data) ? res.data : []);
        setTotalCount(typeof res?.total_count === 'number' ? res.total_count : 0);
      } else {
        setIdentities([]);
        setTotalCount(0);
        setError(res?.message || 'Failed to load identities.');
      }
    } catch (err) {
      console.error('Failed to fetch identities:', err);
      setIdentities([]);
      setTotalCount(0);
      setError(err?.message || 'Unexpected error occurred while fetching identities.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchIdentities();
    }, 250);
    return () => clearTimeout(timer);
  }, [search, classification, ownerType, selectedScanId, page]);

  const handleResetFilters = () => {
    setSearch('');
    setClassification('');
    setOwnerType('');
    setPage(1);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Fingerprint className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
            NHI Inventory Explorer
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Browse, search, and inspect all {totalCount || 0} discovered identities.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchIdentities}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="lg:col-span-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search || ''}
            onChange={(e) => {
              setSearch(e?.target?.value || '');
              setPage(1);
            }}
            placeholder="Search name, ARN..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>
        <div>
          <select
            value={classification || ''}
            onChange={(e) => {
              setClassification(e?.target?.value || '');
              setPage(1);
            }}
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="">All Classifications</option>
            {CLASSIFICATIONS?.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
            <option disabled>──────────</option>
            {SYNTHETIC_FILTERS?.map((f) => (
              <option key={f?.value} value={f?.value}>{f?.label}</option>
            ))}
          </select>
        </div>
        <div>
          <select
            value={ownerType || ''}
            onChange={(e) => {
              setOwnerType(e?.target?.value || '');
              setPage(1);
            }}
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="">All Owner Types</option>
            <option value="HUMAN">Human Owner</option>
            <option value="NHI_CICD">CI/CD Pipeline</option>
            <option value="NHI_IAC">IaC Managed</option>
            <option value="AWS_SERVICE">AWS Service</option>
            <option value="ORPHANED">Orphaned</option>
          </select>
        </div>
        <button
          onClick={handleResetFilters}
          className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-800 transition-colors cursor-pointer text-center"
        >
          Clear Filters
        </button>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 rounded-xl px-4 py-2.5 text-xs font-medium">
          {error}
        </div>
      )}

      {/* Table */}
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[400px]">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-20 flex justify-center">
              <Loader text="Loading inventory..." />
            </div>
          ) : safeLen(identities) === 0 ? (
            <div className="py-20 text-center text-slate-400 dark:text-slate-500 text-sm">
              No matching identities found.
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-5">Identity Name & ARN</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Owner</th>
                  <th className="py-3 px-4">Last Active</th>
                  <th className="py-3 px-4 text-center">Consumers</th> {/* ── NEW COLUMN ── */}
                  <th className="py-3 px-4 text-center">MFA</th>
                  <th className="py-3 px-4 text-center">Console</th>
                  <th className="py-3 px-4 text-center">Policies</th>
                  <th className="py-3 px-4 text-center">Credentials</th>
                  <th className="py-3 px-4 text-center">Secret</th>
                  <th className="py-3 px-4 text-center">Events</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {(identities || []).map((id, idx) => {
                  if (!id) return null;

                  const credCount = countCredentials(id?.owned_credentials);
                  const policyCount = safeLen(id?.attached_policies);
                  const rowKey = id?.id || id?.arn || `row-${idx}`;
                  const isAdmin = Boolean(id?.is_admin);
                  const isSecret = Boolean(id?.is_secret);
                  const isUser = id?.identity_type === 'IAM_USER';
                  const isRole = id?.identity_type === 'IAM_ROLE';
                  const lastActiveDays = daysSince(id?.last_active);

                  return (
                    <tr key={rowKey} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors">
                      <td className="py-3.5 px-5 max-w-[220px]">
                        <div className="font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2" title={id?.name || ''}>
                          <span>{id?.name || '—'}</span>
                          {isAdmin && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400 border border-red-300 dark:border-red-500/30 shrink-0">
                              ADMIN
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">{truncate(id?.arn || '', 35)}</div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <ClassificationBadge classification={id?.classification || 'UNCLASSIFIED'} />
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-mono text-[11px] whitespace-nowrap">{id?.identity_type || '—'}</td>
                      <td className="py-3.5 px-4 max-w-[130px]">
                        <div className="text-slate-700 dark:text-slate-200 font-medium truncate">{id?.owner_name || id?.owner_type || 'Unassigned'}</div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {lastActiveDays != null ? (
                          <span className={`text-[11px] font-semibold ${stalenessColor(lastActiveDays)}`}>{lastActiveDays}d ago</span>
                        ) : (
                          <span className="text-slate-300 dark:text-slate-600 text-[11px]">—</span>
                        )}
                      </td>

                      {/* ── Role Consumers Count Column (NEW) ── */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        {isRole ? (
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-[10px] font-bold border ${
                            (id?.consumer_count || 0) > 0 
                              ? 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400' 
                              : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'
                          }`}>
                            <UsersRound className="w-3.5 h-3.5 shrink-0" />
                            {id?.consumer_count || 0}
                          </span>
                        ) : (
                          <span className="text-slate-300 dark:text-slate-600">—</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {isUser ? (
                          <span className={`inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border ${id?.mfa_enabled ? 'bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20 text-green-600 dark:text-green-400' : 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-600 dark:text-red-400'}`}>
                            {id?.mfa_enabled ? 'Yes' : 'No'}
                          </span>
                        ) : (<span className="text-slate-300 dark:text-slate-600">—</span>)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isUser ? (
                          <span className={`inline-flex px-2 py-0.5 rounded-lg text-[10px] font-bold border ${id?.console_access === 'Yes' ? 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400' : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'}`}>
                            {id?.console_access || 'No'}
                          </span>
                        ) : (<span className="text-slate-300 dark:text-slate-600">—</span>)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border ${isAdmin ? 'bg-red-100 dark:bg-red-500/10 border-red-300 dark:border-red-500/20 text-red-700 dark:text-red-400' : policyCount > 0 ? 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400' : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'}`}>
                          <Shield className="w-3.5 h-3.5" />{policyCount}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border ${credCount > 0 ? 'bg-cyan-50 dark:bg-cyan-500/10 border-cyan-200 dark:border-cyan-500/20 text-cyan-600 dark:text-cyan-400' : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'}`}>
                          <Key className="w-3.5 h-3.5" />{credCount}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isSecret ? (<span className="inline-flex p-1 rounded bg-amber-50 dark:bg-amber-500/10 text-amber-500"><KeyRound className="w-3.5 h-3.5" /></span>) : (<span className="text-slate-300 dark:text-slate-600">—</span>)}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono text-slate-600 dark:text-slate-300">{id?.total_events || 0}</td>
                      <td className="py-3.5 px-5 text-right whitespace-nowrap">
                        <button onClick={() => setSelectedIdentity(id)} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-600/10 hover:bg-indigo-600 text-indigo-600 dark:text-indigo-400 hover:text-white border border-indigo-200 dark:border-indigo-500/20 text-[11px] font-semibold transition-all cursor-pointer">
                          <Eye className="w-3 h-3" />Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        {(totalCount || 0) > 0 && (
          <Pagination page={page || 1} pageSize={pageSize} totalCount={totalCount || 0} onPageChange={(p) => setPage(p || 1)} />
        )}
      </div>

      {selectedIdentity && (
        <IdentityDetailModal identity={selectedIdentity} onClose={() => setSelectedIdentity(null)} />
      )}
    </div>
  );
};

export default IdentitiesPage;