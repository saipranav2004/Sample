import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage = () => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4 transition-colors duration-300">
      <h1 className="text-6xl font-extrabold text-indigo-500 dark:text-indigo-400">404</h1>
      <p className="text-xl text-slate-900 dark:text-white font-semibold mt-4">Page Not Found</p>
      <Link
        to="/dashboard"
        className="mt-6 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl transition-colors"
      >
        Return to Dashboard
      </Link>
    </div>
  );
};

export default NotFoundPage;