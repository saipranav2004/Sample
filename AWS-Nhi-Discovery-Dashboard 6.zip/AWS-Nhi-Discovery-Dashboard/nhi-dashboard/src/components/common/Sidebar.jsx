import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Fingerprint, KeyRound, History, ShieldCheck } from 'lucide-react';

const NAV_ITEMS = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/identities', label: 'NHI Inventory', icon: Fingerprint },
  { path: '/credentials', label: 'Credentials', icon: KeyRound }, // <-- Restored with correct path
  { path: '/scans', label: 'Scan History', icon: History },
];

const Sidebar = () => {
  return (
    <aside className="w-64 h-screen shrink-0 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-colors duration-300 select-none">
      <div className="flex flex-col flex-1 min-h-0">
        {/* Brand Logo */}
        <div className="h-16 shrink-0 flex items-center gap-3 px-6 border-b border-slate-200 dark:border-slate-800">
          <div className="p-2 bg-indigo-600 rounded-lg">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-slate-900 dark:text-white tracking-wide text-lg">NHI Discovery</span>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
          {(NAV_ITEMS ?? []).map((item) => {
            if (!item?.path) return null;
            const Icon = item?.icon ?? ShieldCheck;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-50 dark:bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-500/20 shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      <div className="p-4 shrink-0 border-t border-slate-200 dark:border-slate-800/60 text-xs text-slate-400 dark:text-slate-500 text-center">
        AWS Identity Discovery v1.0
      </div>
    </aside>
  );
};

export default Sidebar;