// src/components/common/CredentialDetailModal.jsx
import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  Terminal,
  Copy,
  Check
} from 'lucide-react';

const daysSince = (dateStr) => {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d?.getTime())) return null;
  return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
};

const stalenessColor = (days) => {
  if (days === null || days === undefined) return 'text-slate-400 bg-slate-100 dark:bg-slate-800';
  if (days <= 30) return 'text-emerald-700 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50';
  if (days <= 90) return 'text-amber-700 bg-amber-50 dark:text-amber-400 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/50';
  return 'text-rose-700 bg-rose-50 dark:text-rose-400 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/50 font-semibold';
};

const formatDate = (dateStr) => {
  if (!dateStr) return 'Never / Not recorded';
  const d = new Date(dateStr);
  if (isNaN(d?.getTime())) return '—';
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export default function CredentialDetailModal({ credential, onClose }) {
  const [copiedCli, setCopiedCli] = useState(false);

  if (!credential) return null;

  const credType = credential?.type || 'UNKNOWN';
  const credId = credential?.cred_id || '—';
  const identityName = credential?.identity_name || '—';
  const status = credential?.status || 'Active';

  const createdDate = credential?.created_at;
  const lastUsedDate = credential?.last_used_date;
  const lastUsedService = credential?.last_used_service;

  const ageDays = daysSince(createdDate);
  const lastUsedDays = daysSince(lastUsedDate);

  // Risk flags
  const riskFlags = [];

  if (credType === 'AWS_ACCESS_KEY') {
    if (ageDays !== null && ageDays > 90) {
      riskFlags.push({
        severity: 'HIGH',
        title: 'Key Rotation Overdue',
        desc: `Access key is ${ageDays} days old. CIS recommends rotation every 90 days.`,
      });
    }
    if (lastUsedDays !== null && lastUsedDays > 90 && status === 'Active') {
      riskFlags.push({
        severity: 'MEDIUM',
        title: 'Inactive Key Enabled',
        desc: `Key unused for ${lastUsedDays} days but still active.`,
      });
    }
  } else if (credType === 'CONSOLE_PASSWORD') {
    if (ageDays !== null && ageDays > 90) {
      riskFlags.push({
        severity: 'HIGH',
        title: 'Password Age Exceeded',
        desc: `Console password not updated in ${ageDays} days.`,
      });
    }
  }

  // CLI remediation
  const cliSnippet = (() => {
    const user = identityName !== '—' ? identityName : '<IAM_USER>';
    const key = credId !== '—' ? credId : '<KEY_ID>';

    switch (credType) {
      case 'AWS_ACCESS_KEY':
        return `# Deactivate stale access key\naws iam update-access-key --user-name "${user}" --access-key-id "${key}" --status Inactive\n\n# Delete after validation\naws iam delete-access-key --user-name "${user}" --access-key-id "${key}"`;
      case 'CONSOLE_PASSWORD':
        return `# Force password reset on next sign-in\naws iam update-login-profile --user-name "${user}" --password-reset-required`;
      case 'SECRETS_MANAGER_SECRET':
        return `# Rotate secret immediately\naws secretsmanager rotate-secret --secret-id "${key}"`;
      case 'SSM_PARAMETER':
        return `# Update parameter value\naws ssm put-parameter --name "${key}" --type SecureString --overwrite --value "<NEW_VALUE>"`;
      default:
        return `# Audit identity\naws iam get-user --user-name "${user}"`;
    }
  })();

  const handleCopyCli = () => {
    navigator?.clipboard?.writeText(cliSnippet);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">

        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-900 shrink-0">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight font-mono">
                  {credId}
                </h2>
                <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200/50 dark:border-slate-800">
                  {credType?.replace(/_/g, ' ')}
                </span>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  status === 'Active' || status === 'Enabled'
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
                    : 'bg-slate-100 text-slate-600 dark:bg-slate-900 dark:text-slate-400'
                }`}>
                  {status}
                </span>
              </div>
              <div className="text-sm text-slate-500 dark:text-slate-400 flex items-center gap-2 pt-0.5">
                <span>Owning Identity: <strong className="text-slate-800 dark:text-slate-200">{identityName}</strong></span>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* Risk Banner (Only shown if risk findings exist) */}
          {riskFlags?.length > 0 && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 rounded-xl space-y-3">
              <div className="flex items-center gap-2 text-amber-800 dark:text-amber-400 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Security Findings ({riskFlags.length})</span>
              </div>
              <div className="space-y-2">
                {riskFlags?.map((risk, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200 shrink-0 uppercase tracking-wider">
                      {risk?.severity}
                    </span>
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">{risk?.title}: </strong>
                      <span className="text-slate-600 dark:text-slate-400">{risk?.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lifecycle Metrics */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
              Key Metrics & Lifecycles
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

              <div className="p-4 rounded-xl border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/20">
                <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Created</span>
                <span className="text-xs font-semibold text-slate-800 dark:text-white block truncate">
                  {formatDate(createdDate)}
                </span>
                {ageDays !== null && (
                  <div className="mt-2.5">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full ${stalenessColor(ageDays)}`}>
                      {ageDays} days old
                    </span>
                  </div>
                )}
              </div>

              <div className="p-4 rounded-xl border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/20">
                <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Last Used</span>
                <span className="text-xs font-semibold text-slate-800 dark:text-white block truncate">
                  {formatDate(lastUsedDate)}
                </span>
                {lastUsedDays !== null ? (
                  <div className="mt-2.5">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full ${stalenessColor(lastUsedDays)}`}>
                      {lastUsedDays} days ago
                    </span>
                  </div>
                ) : (
                  <div className="mt-2.5">
                    <span className="text-[11px] px-2 py-0.5 rounded-full text-slate-400 bg-slate-100 dark:bg-slate-900">
                      Never used
                    </span>
                  </div>
                )}
                {lastUsedService && (
                  <div className="text-[10px] text-slate-400 mt-1.5 truncate">
                    Service: {lastUsedService}
                  </div>
                )}
              </div>

              <div className="p-4 rounded-xl border border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-900/20">
                <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Description</span>
                <span className="text-xs font-semibold text-slate-800 dark:text-white block">
                  {credential?.description || 'No description available'}
                </span>
              </div>

            </div>
          </div>

          {/* CLI Remediation */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-indigo-500" /> Remediation (AWS CLI)
              </h3>
              <button
                type="button"
                onClick={handleCopyCli}
                className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 transition-colors cursor-pointer"
              >
                {copiedCli ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 bg-slate-900 dark:bg-slate-950 text-slate-200 dark:text-slate-300 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800/80 leading-relaxed">
              {cliSnippet}
            </pre>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-900 bg-slate-50 dark:bg-slate-900/10 flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900/60 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}