import React from 'react';
import { CLASSIFICATION_CONFIG, SEVERITY_CONFIG } from '../../utils/constants';

export const ClassificationBadge = ({ classification }) => {
  const key = classification?.toString()?.toUpperCase() ?? 'UNCLASSIFIED';
  const config = CLASSIFICATION_CONFIG?.[key] ?? CLASSIFICATION_CONFIG?.UNCLASSIFIED;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${config?.bg ?? 'bg-gray-100'} ${config?.text ?? 'text-gray-800'} border border-current/10`}>
      <span>{config?.icon ?? '❓'}</span>
      <span>{config?.label ?? classification ?? 'Unclassified'}</span>
    </span>
  );
};

export const SeverityBadge = ({ severity }) => {
  if (!severity) return null;
  const key = severity?.toString()?.toUpperCase() ?? 'LOW';
  const config = SEVERITY_CONFIG?.[key] ?? SEVERITY_CONFIG?.LOW;

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${config?.bg ?? 'bg-green-100'} ${config?.text ?? 'text-green-800'} border border-current/10`}>
      <span>{config?.icon ?? '🟢'}</span>
      <span>{severity}</span>
    </span>
  );
};