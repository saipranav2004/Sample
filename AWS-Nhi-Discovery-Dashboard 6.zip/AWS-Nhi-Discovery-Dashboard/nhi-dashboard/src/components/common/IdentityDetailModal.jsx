import React, { useState, useEffect } from 'react';
import { getIdentityEvents } from '../../services/eventService';
import { getIdentityLineage, getRoleConsumers } from '../../services/identityService';
import { ClassificationBadge, SeverityBadge } from './Badge';
import Pagination from './Pagination';
import { formatDate, truncate } from '../../utils/helpers';
import { 
  X, ShieldAlert, Activity, UserCheck, KeyRound, FileLock, Terminal,
  Key, Fingerprint, Smartphone, FileText, Cloud, ShieldCheck, Calendar, AlertTriangle,
  Users, Clock, Shield, Server, Globe, ArrowRightLeft, UsersRound
} from 'lucide-react';

const CREDENTIAL_ICONS = {
  AWS_ACCESS_KEY:         Key,
  CONSOLE_PASSWORD:       ShieldCheck,
  MFA_DEVICE:             Smartphone,
  SSH_PUBLIC_KEY:         Fingerprint,
  ENV_SECRET:             FileLock,
  SSM_PARAMETER:          FileText,
  SECRETS_MANAGER_SECRET: KeyRound,
  X509_CERTIFICATE:       ShieldCheck,
  OAUTH_CLIENT_SECRET:    Key,
  API_KEY:                Terminal,
  IOT_ROLE_ALIAS:         Cloud,
  OIDC_TOKEN:             ShieldCheck,
};

// Helper: Calculate days between now and a given date string
const daysSince = (dateStr) => {
  if (!dateStr) return null;
  try {
    const d = new Date(dateStr);
    if (isNaN(d?.getTime())) return null;
    return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  } catch {
    return null;
  }
};

// Helper: Get staleness color based on days
const stalenessColor = (days) => {
  if (days == null) return 'text-slate-400';
  if (days <= 30) return 'text-green-600 dark:text-green-400';
  if (days <= 90) return 'text-yellow-600 dark:text-yellow-400';
  return 'text-red-600 dark:text-red-400';
};

const IdentityDetailModal = ({ identity, onClose }) => {
  const [events, setEvents] = useState([]);
  const [totalEventsCount, setTotalEventsCount] = useState(0);
  const [eventsPage, setEventsPage] = useState(1);
  const eventsPageSize = 10;
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // ── Service Access Lineage State (Backend Driven) ──
  const [lineage, setLineage] = useState([]);
  const [totalLineageCount, setTotalLineageCount] = useState(0);
  const [lineagePage, setLineagePage] = useState(1);
  const lineagePageSize = 10;
  const [loadingLineage, setLoadingLineage] = useState(false);

  // ── Role Consumers State (Backend Driven) ──
  const [consumers, setConsumers] = useState([]);
  const [totalConsumersCount, setTotalConsumersCount] = useState(0);
  const [consumersPage, setConsumersPage] = useState(1);
  const consumersPageSize = 10;
  const [loadingConsumers, setLoadingConsumers] = useState(false);

  // ── Fetch CloudTrail Events ──
  useEffect(() => {
    let isMounted = true;
    if (identity?.arn && activeTab === 'activity') {
      const fetchEvents = async () => {
        setLoadingEvents(true);
        try {
          const res = await getIdentityEvents(identity?.arn, eventsPage, eventsPageSize);
          if (isMounted && res) {
            const rawData = res.data || res.events || res;
            setEvents(Array.isArray(rawData) ? rawData : []);
            setTotalEventsCount(res.total_count || res.total || (Array.isArray(rawData) ? rawData.length : 0));
          }
        } catch (err) {
          console.error('Failed to load events:', err);
        } finally {
          if (isMounted) setLoadingEvents(false);
        }
      };
      fetchEvents();
    }
    return () => { isMounted = false; };
  }, [identity?.arn, activeTab, eventsPage]);

  // ── Fetch Service Access Lineage with Backend Pagination ──
  useEffect(() => {
    let isMounted = true;
    if (identity?.arn && activeTab === 'services') {
      const fetchLineage = async () => {
        setLoadingLineage(true);
        try {
          const res = await getIdentityLineage(
            identity?.arn, 
            identity?.scan_id, 
            lineagePage, 
            lineagePageSize
          );
          if (isMounted && res) {
            const rawData = res.data || res.relationships || res;
            setLineage(Array.isArray(rawData) ? rawData : []);
            setTotalLineageCount(res.total_count || res.total || (Array.isArray(rawData) ? rawData.length : 0));
          }
        } catch (err) {
          console.error('Failed to load service access:', err);
        } finally {
          if (isMounted) setLoadingLineage(false);
        }
      };
      fetchLineage();
    }
    return () => { isMounted = false; };
  }, [identity?.arn, identity?.scan_id, activeTab, lineagePage]);

  // ── Fetch Role Consumers with Backend Pagination ──
  useEffect(() => {
    let isMounted = true;
    if (identity?.arn && activeTab === 'consumers' && identity?.identity_type === 'IAM_ROLE') {
      const fetchConsumers = async () => {
        setLoadingConsumers(true);
        try {
          const res = await getRoleConsumers(
            identity?.arn,
            identity?.scan_id,
            consumersPage,
            consumersPageSize
          );
          if (isMounted && res) {
            const rawData = res.data || res.consumers || res;
            setConsumers(Array.isArray(rawData) ? rawData : []);
            setTotalConsumersCount(res.total_count || res.total || (Array.isArray(rawData) ? rawData.length : 0));
          }
        } catch (err) {
          console.error('Failed to load role consumers:', err);
        } finally {
          if (isMounted) setLoadingConsumers(false);
        }
      };
      fetchConsumers();
    }
    return () => { isMounted = false; };
  }, [identity?.arn, identity?.scan_id, activeTab, consumersPage]);

  if (!identity) return null;

  const matchedRulesList = identity?.matched_rules
    ? (typeof identity.matched_rules === 'string'
        ? identity.matched_rules.split(',').map((r) => r.trim()).filter(Boolean)
        : identity.matched_rules)
    : [];

  const attachedPoliciesList = identity?.attached_policies
    ? Array.from(new Set((identity.attached_policies || []).map((p) => p.trim()).filter(Boolean)))
    : [];

  // Safely parse owned_credentials whether it's an array or a JSON string
  let ownedCredentials = [];
  try {
    const raw = identity?.owned_credentials;
    if (Array.isArray(raw)) {
      ownedCredentials = raw;
    } else if (typeof raw === 'string' && raw.trim().startsWith('[')) {
      ownedCredentials = JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Failed to parse owned_credentials:', e);
    ownedCredentials = [];
  }

  // Check if a date has expired
  const isExpired = (expiryStr) => {
    if (!expiryStr) return false;
    try {
      return new Date(expiryStr).getTime() < new Date().getTime();
    } catch {
      return false;
    }
  };

  // Parse Groups from CSV string
  const groupsList = identity?.groups
    ? String(identity.groups).split(',').map((g) => g.trim()).filter(Boolean)
    : [];

  const isUser = identity?.identity_type === 'IAM_USER';
  const isRole = identity?.identity_type === 'IAM_ROLE';
  const consoleLastSignInDays = daysSince(identity?.console_last_signin);
  const keyLastUsedDays = daysSince(identity?.access_key_1_last_used);
  const paginatedLineage = Array.isArray(lineage) ? lineage : [];
  const paginatedConsumers = Array.isArray(consumers) ? consumers : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 dark:bg-black/70 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden transition-colors duration-300">

        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between bg-slate-50 dark:bg-slate-900/50">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                {identity?.name || 'Identity Details'}
              </h2>
              <ClassificationBadge classification={identity?.classification} />
              {identity?.is_secret && <SeverityBadge severity="HIGH" />}
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-500 font-mono mt-1 break-all select-all">
              {identity?.arn || '—'}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 gap-6 bg-white dark:bg-slate-950 text-xs font-semibold overflow-x-auto shrink-0 scrollbar-none">
          <button 
            onClick={() => { setActiveTab('overview'); setEventsPage(1); }} 
            className={`py-3.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${activeTab === 'overview' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-700'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => { setActiveTab('credentials'); setEventsPage(1); }} 
            className={`py-3.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${activeTab === 'credentials' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-700'}`}
          >
            <Key className="w-3.5 h-3.5 shrink-0" />
            Credentials ({ownedCredentials.length})
          </button>
          
          {/* Service Access Tab */}
          <button 
            onClick={() => { setActiveTab('services'); setLineagePage(1); }} 
            className={`py-3.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${activeTab === 'services' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-700'}`}
          >
            <ArrowRightLeft className="w-3.5 h-3.5 shrink-0" />
            Service Access
          </button>

          {/* Role Consumers Tab (Only for IAM_ROLE) */}
          {isRole && (
            <button 
              onClick={() => { setActiveTab('consumers'); setConsumersPage(1); }} 
              className={`py-3.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${activeTab === 'consumers' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-700'}`}
            >
              <UsersRound className="w-3.5 h-3.5 shrink-0" />
              Role Consumers
            </button>
          )}
          
          <button 
            onClick={() => { setActiveTab('activity'); setEventsPage(1); }} 
            className={`py-3.5 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${activeTab === 'activity' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-700'}`}
          >
            <Activity className="w-3.5 h-3.5 shrink-0" />
            CloudTrail ({identity?.total_events || 0})
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">

          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <>
              {identity?.is_admin && (
                <div className="p-4 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30 flex items-start gap-3.5">
                  <ShieldAlert className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-base text-red-700 dark:text-red-400 block">Full Administrator Privileges</span>
                    <span className="text-xs mt-1 block text-red-600/90 dark:text-red-400/80">Wildcard (*:*) or AdministratorAccess detected.</span>
                  </div>
                </div>
              )}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80">
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Type</span><p className="text-slate-900 dark:text-white font-semibold font-mono mt-0.5">{identity?.identity_type || '—'}</p></div>
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Trust</span><p className="text-slate-900 dark:text-white font-semibold mt-0.5">{identity?.trust_type || '—'}</p></div>
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Service</span><p className="text-indigo-600 dark:text-indigo-400 font-mono mt-0.5">{identity?.trust_service || '—'}</p></div>
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Owner</span><p className="text-slate-900 dark:text-white font-semibold mt-0.5">{identity?.owner_name || 'Unassigned'}</p></div>
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Owner Type</span><p className="text-slate-900 dark:text-white font-semibold mt-0.5">{identity?.owner_type || 'ORPHANED'}</p></div>
                <div><span className="text-slate-500 dark:text-slate-400 font-medium">Created</span><p className="text-slate-600 dark:text-slate-300 mt-0.5">{formatDate(identity?.created_at)}</p></div>
              </div>

              {/* User Posture Section (Only shown for IAM_USER) */}
              {isUser && (
                <div className="space-y-2">
                  <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-indigo-500" />
                    User Posture
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80">

                    {/* Console Access */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Console Access</span>
                      <p className={`font-semibold mt-0.5 ${identity?.console_access === 'Yes' ? 'text-green-600 dark:text-green-400' : 'text-slate-400'}`}>
                        {identity?.console_access || 'No'}
                      </p>
                    </div>

                    {/* MFA */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">MFA</span>
                      <p className={`font-semibold mt-0.5 ${identity?.mfa_enabled ? 'text-green-600 dark:text-green-400' : 'text-red-500'}`}>
                        {identity?.mfa_enabled ? 'Enabled' : 'Disabled'}
                      </p>
                    </div>

                    {/* Password Age */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Password Age</span>
                      <p className={`font-semibold mt-0.5 ${identity?.password_age_days > 90 ? 'text-red-500' : 'text-slate-900 dark:text-white'}`}>
                        {identity?.password_age_days != null ? `${identity.password_age_days} days` : '—'}
                      </p>
                    </div>

                    {/* Console Last Sign-in */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Console Last Sign-in</span>
                      <p className={`font-semibold mt-0.5 ${stalenessColor(consoleLastSignInDays)}`}>
                        {identity?.console_last_signin ? formatDate(identity.console_last_signin) : '—'}
                      </p>
                    </div>

                    {/* Access Key ID */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Access Key ID</span>
                      <p className="text-slate-900 dark:text-white font-mono text-[11px] mt-0.5 break-all">
                        {identity?.access_key_1_id || '—'}
                      </p>
                    </div>

                    {/* Active Key Age */}
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Active Key Age</span>
                      <p className={`font-semibold mt-0.5 ${identity?.access_key_1_age_days > 90 ? 'text-red-500' : 'text-slate-900 dark:text-white'}`}>
                        {identity?.access_key_1_age_days != null ? `${identity.access_key_1_age_days} days` : '—'}
                      </p>
                    </div>

                    {/* Access Key Last Used */}
                    <div className="col-span-2 sm:col-span-3">
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Access Key Last Used</span>
                      <p className={`font-semibold mt-0.5 ${stalenessColor(keyLastUsedDays)}`}>
                        {identity?.access_key_1_last_used ? formatDate(identity.access_key_1_last_used) : '—'}
                      </p>
                    </div>
                  </div>

                  {/* Groups */}
                  {groupsList.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <span className="text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1.5 mb-2">
                        <Users className="w-3.5 h-3.5 shrink-0" />
                        Groups ({groupsList.length})
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {groupsList.map((g, i) => (
                          <span key={i} className="px-2 py-1 rounded-lg text-[10px] font-mono font-bold uppercase border bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
                            {g}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {identity?.primary_owner && (
                <div className="p-3.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-500/20 flex items-start gap-3">
                  <UserCheck className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                  <div><span className="font-semibold text-indigo-700 dark:text-indigo-300 block">Creator / Lineage</span><p className="text-slate-600 dark:text-slate-300 font-mono text-[11px] mt-0.5 break-all">{identity?.primary_owner}</p></div>
                </div>
              )}
              <div className="space-y-2">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5"><FileLock className="w-4 h-4 text-indigo-500" />Attached Policies ({attachedPoliciesList.length})</span>
                <div className="flex flex-wrap gap-1.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  {attachedPoliciesList.length > 0 ? attachedPoliciesList.map((p, i) => (
                    <span key={i} className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold uppercase border ${p.includes('Admin') ? 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/30 text-red-600 dark:text-red-400' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'}`}>{p}</span>
                  )) : <span className="text-slate-400 italic">None</span>}
                </div>
              </div>
              <div className="space-y-2">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5"><ShieldAlert className="w-4 h-4 text-amber-500" />Evidence</span>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[11px]">{identity?.evidence ?? 'None'}</div>
              </div>
            </>
          )}

          {/* CREDENTIALS TAB */}
          {activeTab === 'credentials' && (
            <div className="space-y-3">
              {ownedCredentials.length === 0 ? (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-sm">
                  No authentication credentials, tokens, or keys owned by this identity.
                </div>
              ) : (
                ownedCredentials.map((cred, idx) => {
                  const Icon = CREDENTIAL_ICONS[cred?.type] || Key;
                  const expired = isExpired(cred?.expires_at);

                  const sevColor =
                    cred?.severity === 'CRITICAL' ? 'text-red-500 bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/30' :
                    cred?.severity === 'HIGH'     ? 'text-orange-500 bg-orange-50 dark:bg-orange-500/10 border-orange-200 dark:border-orange-500/30' :
                    cred?.severity === 'MEDIUM'   ? 'text-amber-500 bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/30' :
                                                  'text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/30';
                  return (
                    <div key={idx} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-500/40 transition-all">
                      <div className="flex items-start justify-between gap-4">
                        
                        {/* Left Column (Metadata) */}
                        <div className="flex gap-3 min-w-0">
                          <div className={`p-2 rounded-lg border shrink-0 h-fit ${sevColor}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider">
                                {cred?.type?.replace(/_/g, ' ') ?? 'UNKNOWN'}
                              </span>
                              {cred?.severity && (
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold border ${sevColor}`}>
                                  {cred.severity}
                                </span>
                              )}
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                                {cred?.status ?? ''}
                              </span>
                            </div>
                            {cred?.id && <p className="text-[11px] text-slate-700 dark:text-slate-300 font-mono mt-1 break-all">{cred.id}</p>}
                            {cred?.description && <p className="text-[10px] text-slate-500 mt-1">{cred.description}</p>}
                            
                            {(cred?.last_used_date || cred?.last_used_service) && (
                              <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-400 dark:text-slate-500">
                                {cred?.last_used_date && <span>🕐 Last Used: {formatDate(cred.last_used_date)}</span>}
                                {cred?.last_used_service && <span>⚡ Service: {cred.last_used_service}</span>}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Right Column (Lifecycle Dates) */}
                        <div className="text-right shrink-0 flex flex-col gap-1.5 text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                          {cred?.created_at && (
                            <div className="flex items-center gap-1 justify-end">
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              <span>Created: {formatDate(cred.created_at).split(',')[0]}</span>
                            </div>
                          )}

                          {cred?.expires_at && (
                            <div className={`flex items-center gap-1 justify-end px-2 py-0.5 rounded-lg border ${
                              expired 
                                ? 'bg-red-500/10 border-red-500/20 text-red-500' 
                                : 'bg-amber-500/10 border-amber-500/20 text-amber-500'
                            }`}>
                              <AlertTriangle className="w-3 h-3" />
                              <span>
                                {expired ? 'Expired' : 'Expires'}: {formatDate(cred.expires_at).split(',')[0]}
                              </span>
                            </div>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* ── SERVICE ACCESS TAB ── */}
          {activeTab === 'services' && (
            <div className="space-y-3">
              {loadingLineage ? (
                <div className="py-12 text-center text-slate-400">Loading service access...</div>
              ) : totalLineageCount === 0 ? (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-sm">
                  No service access lineage detected for this identity.
                </div>
              ) : (
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col bg-white dark:bg-slate-950">
                  <div className="overflow-x-auto w-full custom-scrollbar">
                    <table className="w-full text-left min-w-[600px] border-collapse">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900 text-[10px] text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800 whitespace-nowrap">
                          <th className="py-2.5 px-3.5">Service Name</th>
                          <th className="py-2.5 px-3">Service Type</th>
                          <th className="py-2.5 px-3">Relationship</th>
                          <th className="py-2.5 px-3.5 text-center">External</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-[11px] whitespace-nowrap">
                        {paginatedLineage?.map((edge, idx) => {
                          if (!edge) return null;
                          return (
                            <tr key={`${edge?.target_name || 'service'}-${idx}`} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                              {/* Service Name */}
                              <td className="py-2.5 px-3.5">
                                <div className="flex items-center gap-2">
                                  <Server className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400 shrink-0" />
                                  <span className="font-semibold text-slate-900 dark:text-white truncate max-w-[200px]" title={edge?.target_name}>
                                    {edge?.target_name || '—'}
                                  </span>
                                </div>
                              </td>

                              {/* Service Type */}
                              <td className="py-2.5 px-3">
                                <span className="font-mono text-[10px] text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                                  {edge?.target_type || '—'}
                                </span>
                              </td>

                              {/* Relationship */}
                              <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                                {edge?.rel_type || '—'}
                              </td>

                              {/* External */}
                              <td className="py-2.5 px-3.5 text-center">
                                {edge?.is_external === 1 ? (
                                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-1.5 py-0.5 rounded">
                                    <Globe className="w-3 h-3" /> Yes
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-slate-400 dark:text-slate-500">No</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  
                  {totalLineageCount > lineagePageSize && (
                    <div className="border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/30 shrink-0">
                      <Pagination 
                        page={lineagePage} 
                        pageSize={lineagePageSize} 
                        totalCount={totalLineageCount} 
                        onPageChange={setLineagePage} 
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ── ROLE CONSUMERS TAB ── */}
          {activeTab === 'consumers' && isRole && (
            <div className="space-y-3">
              {loadingConsumers ? (
                <div className="py-12 text-center text-slate-400">Loading role consumers...</div>
              ) : totalConsumersCount === 0 ? (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-sm">
                  No AssumeRole activity detected for this role in CloudTrail scans.
                </div>
              ) : (
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col bg-white dark:bg-slate-950">
                  <div className="overflow-x-auto w-full custom-scrollbar">
                    <table className="w-full text-left min-w-[800px] border-collapse">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900 text-[10px] text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800 whitespace-nowrap">
                          <th className="py-2.5 px-3.5">Assumed By (Caller)</th>
                          <th className="py-2.5 px-3">Source IP</th>
                          <th className="py-2.5 px-3">Client / User Agent</th>
                          <th className="py-2.5 px-3">Region</th>
                          <th className="py-2.5 px-3 text-center">Sessions</th>
                          <th className="py-2.5 px-3">First Assumed</th>
                          <th className="py-2.5 px-3.5 text-right">Last Assumed</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-[11px] whitespace-nowrap">
                        {paginatedConsumers?.map((c, idx) => {
                          if (!c) return null;
                          return (
                            <tr key={`${c?.caller_arn || 'caller'}-${idx}`} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                              {/* Assumed By (Caller) */}
                              <td className="py-2.5 px-3.5">
                                <div className="font-semibold text-slate-900 dark:text-white truncate max-w-[180px]" title={c?.caller_arn}>
                                  {c?.caller_arn?.split('/')?.pop() || c?.caller_arn || 'Unknown'}
                                </div>
                                <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate max-w-[180px]" title={c?.caller_arn}>
                                  {c?.caller_arn || '—'}
                                </div>
                              </td>

                              {/* Source IP */}
                              <td className="py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300">
                                {c?.source_ip || '—'}
                              </td>

                              {/* User Agent / Client */}
                              <td className="py-2.5 px-3">
                                <span className="text-slate-600 dark:text-slate-300 truncate max-w-[160px] block font-mono text-[10px]" title={c?.user_agent}>
                                  {c?.user_agent || 'AWS SDK'}
                                </span>
                              </td>

                              {/* Region */}
                              <td className="py-2.5 px-3 text-slate-500 font-mono text-[10px]">
                                {c?.region || '—'}
                              </td>

                              {/* Session Count */}
                              <td className="py-2.5 px-3 text-center">
                                <span className="inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400 font-mono">
                                  {c?.session_count || 0}
                                </span>
                              </td>

                              {/* First Assumed */}
                              <td className="py-2.5 px-3 text-slate-500">
                                {c?.first_assumed ? formatDate(c.first_assumed) : '—'}
                              </td>

                              {/* Last Assumed */}
                              <td className="py-2.5 px-3.5 text-right text-slate-700 dark:text-slate-200 font-semibold">
                                {c?.last_assumed ? formatDate(c.last_assumed) : '—'}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  
                  {totalConsumersCount > consumersPageSize && (
                    <div className="border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/30 shrink-0">
                      <Pagination 
                        page={consumersPage} 
                        pageSize={consumersPageSize} 
                        totalCount={totalConsumersCount} 
                        onPageChange={setConsumersPage} 
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ACTIVITY TAB */}
          {activeTab === 'activity' && (
            <div className="space-y-3">
              {loadingEvents ? (
                <div className="py-12 text-center text-slate-400">Loading...</div>
              ) : events.length === 0 ? (
                <div className="py-12 text-center text-slate-400">No CloudTrail events.</div>
              ) : (
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col bg-white dark:bg-slate-950">
                  <div className="overflow-x-auto w-full custom-scrollbar">
                    <table className="w-full text-left min-w-[700px] border-collapse">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900 text-[10px] text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800 whitespace-nowrap">
                          <th className="py-2.5 px-3.5">Event</th>
                          <th className="py-2.5 px-3">Service</th>
                          <th className="py-2.5 px-3">Region</th>
                          <th className="py-2.5 px-3">IP Source</th>
                          <th className="py-2.5 px-3.5 text-right">Time</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-[11px] whitespace-nowrap">
                        {events.map((ev) => (
                          <tr key={ev?.id ?? Math.random()} className="hover:bg-slate-50 dark:hover:bg-slate-900/50">
                            <td className="py-2 px-3.5 font-semibold text-indigo-600 dark:text-indigo-400 font-mono">{ev?.event_name}</td>
                            <td className="py-2 px-3 text-slate-600 dark:text-slate-300">{ev?.event_source}</td>
                            <td className="py-2 px-3 text-slate-500">{ev?.region}</td>
                            <td className="py-2 px-3 font-mono text-slate-500">{ev?.source_ip}</td>
                            <td className="py-2 px-3.5 text-right text-slate-500">{formatDate(ev?.event_time)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  
                  {totalEventsCount > eventsPageSize && (
                    <div className="border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/30 shrink-0">
                      <Pagination 
                        page={eventsPage} 
                        pageSize={eventsPageSize} 
                        totalCount={totalEventsCount} 
                        onPageChange={setEventsPage} 
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 flex justify-end">
          <button onClick={onClose} className="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white text-xs font-semibold cursor-pointer">Close</button>
        </div>
      </div>
    </div>
  );
};

export default IdentityDetailModal;