import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const Pagination = ({ page = 1, pageSize = 10, totalCount = 0, onPageChange }) => {
  const safeTotal = Number(totalCount ?? 0);
  const safePageSize = Number(pageSize ?? 10) > 0 ? Number(pageSize) : 10;
  const safePage = Number(page ?? 1) > 0 ? Number(page) : 1;
  const totalPages = Math.max(1, Math.ceil(safeTotal / safePageSize));
  const startItem = safeTotal === 0 ? 0 : Math.min((safePage - 1) * safePageSize + 1, safeTotal);
  const endItem = Math.min(safePage * safePageSize, safeTotal);

  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 dark:border-slate-800 text-sm text-slate-500 dark:text-slate-400">
      <div>
        Showing <span className="font-semibold text-slate-900 dark:text-white">{startItem}</span> to{' '}
        <span className="font-semibold text-slate-900 dark:text-white">{endItem}</span> of{' '}
        <span className="font-semibold text-slate-900 dark:text-white">{safeTotal}</span> results
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onPageChange?.(safePage - 1)}
          disabled={safePage <= 1}
          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 px-2">
          Page {safePage} of {totalPages}
        </span>
        <button
          onClick={() => onPageChange?.(safePage + 1)}
          disabled={safePage >= totalPages}
          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default Pagination;