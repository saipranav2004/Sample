import React, { useState, useEffect } from 'react';
import { getScans } from '../../services/scanService';
import { useScan } from '../../context/ScanContext';
import { History, ChevronDown } from 'lucide-react';
import { formatDate } from '../../utils/helpers';

const ScanSelector = () => {
  const { selectedScanId, setSelectedScanId } = useScan();
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const fetchScans = async () => {
      try {
        const res = await getScans(1, 50);
        if (res?.success) {
          setScans(res?.data ?? []);
        }
      } catch (err) {
        console.error('Failed to fetch scans:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchScans();
  }, []);

  const activeScan = scans.find((s) => s?.scan_id === selectedScanId);
  const displayLabel = activeScan
    ? `${activeScan.target_name || activeScan.account_id} — ${formatDate(activeScan.scan_start)}`
    : 'Latest Scan (Auto)';

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:border-indigo-400 dark:hover:border-indigo-500 transition-colors cursor-pointer min-w-[220px] justify-between"
      >
        <div className="flex items-center gap-2 truncate">
          <History className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
          <span className="truncate">{loading ? 'Loading scans...' : displayLabel}</span>
        </div>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && !loading && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)}></div>
          <div className="absolute right-0 mt-1 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl z-20 overflow-hidden">
            <div className="p-2 border-b border-slate-100 dark:border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3">
              Select Scan Run
            </div>

            {/* Latest Scan Option */}
            <button
              onClick={() => { setSelectedScanId(''); setIsOpen(false); }}
              className={`w-full text-left px-3 py-2.5 text-xs hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-colors cursor-pointer flex items-center justify-between ${
                !selectedScanId ? 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-700 dark:text-slate-300'
              }`}
            >
              <span>🔄 Latest Scan (Auto)</span>
              {!selectedScanId && <span className="text-[10px] text-indigo-500">ACTIVE</span>}
            </button>

            {/* Historical Scans */}
            <div className="max-h-60 overflow-y-auto">
              {scans.map((scan) => (
                <button
                  key={scan?.scan_id}
                  onClick={() => { setSelectedScanId(scan.scan_id); setIsOpen(false); }}
                  className={`w-full text-left px-3 py-2.5 text-xs hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-colors cursor-pointer border-t border-slate-50 dark:border-slate-800/50 ${
                    selectedScanId === scan.scan_id ? 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{scan?.target_name || scan?.account_id}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {formatDate(scan?.scan_start)} · {scan?.total_identities ?? 0} identities · {scan?.total_secrets ?? 0} secrets
                      </div>
                    </div>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                      scan?.status === 'COMPLETED'
                        ? 'bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                        : 'bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400'
                    }`}>
                      {scan?.status}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ScanSelector;