// src/components/charts/CredentialBarChart.jsx
import React from 'react';
import { KeyRound } from 'lucide-react';

const TYPE_LABELS = {
  AWS_ACCESS_KEY: 'AWS Access Keys',
  CONSOLE_PASSWORD: 'Console Passwords',
  MFA_DEVICE: 'MFA Devices',
  SSH_PUBLIC_KEY: 'SSH Public Keys',
  ENV_SECRET: 'Environment Secrets',
  SSM_PARAMETER: 'SSM Parameters',
  SECRETS_MANAGER_SECRET: 'Secrets Manager Secrets',
  X509_CERTIFICATE: 'X.509 Certificates',
  OAUTH_CLIENT_SECRET: 'OAuth Client Secrets',
  API_KEY: 'API Keys',
  IOT_ROLE_ALIAS: 'IoT Role Aliases',
  OIDC_TOKEN: 'OIDC Tokens',
};

const TYPE_COLORS = {
  AWS_ACCESS_KEY: 'bg-amber-500 dark:bg-amber-400',
  CONSOLE_PASSWORD: 'bg-blue-500 dark:bg-blue-400',
  MFA_DEVICE: 'bg-emerald-500 dark:bg-emerald-400',
  SSH_PUBLIC_KEY: 'bg-indigo-500 dark:bg-indigo-400',
  ENV_SECRET: 'bg-rose-500 dark:bg-rose-400',
  SSM_PARAMETER: 'bg-teal-500 dark:bg-teal-400',
  SECRETS_MANAGER_SECRET: 'bg-purple-500 dark:bg-purple-400',
  X509_CERTIFICATE: 'bg-cyan-500 dark:bg-cyan-400',
  OAUTH_CLIENT_SECRET: 'bg-pink-500 dark:bg-pink-400',
  API_KEY: 'bg-orange-500 dark:bg-orange-400',
  IOT_ROLE_ALIAS: 'bg-slate-500 dark:bg-slate-400',
  OIDC_TOKEN: 'bg-violet-500 dark:bg-violet-400',
};

export default function CredentialBarChart({ data }) {
  const entries = Object.entries(data || {})
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1]);

  const totalCredentials = entries.reduce((acc, [_, count]) => acc + count, 0);
  const maxVal = entries.length > 0 ? Math.max(...entries.map(([_, v]) => v)) : 1;

  if (entries.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400 dark:text-slate-500">
        <KeyRound className="w-10 h-10 mb-2 stroke-1 opacity-60" />
        <p className="text-sm">No credentials detected in this scan.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-3">
      {/* Header Stat Pill */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pb-2 border-b border-slate-100 dark:border-slate-800">
        <span>{entries.length} Active Categories</span>
        <span className="font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700/60">
          {totalCredentials} Total
        </span>
      </div>

      {/* 2-Column Grid of Progress Bars */}
      <div className={`grid gap-x-6 gap-y-3.5 ${entries.length > 3 ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
        {entries.map(([type, count]) => {
          const label = TYPE_LABELS[type] || type.replace(/_/g, ' ');
          const percent = Math.max(6, (count / maxVal) * 100);
          const colorClass = TYPE_COLORS[type] || 'bg-slate-500 dark:bg-slate-400';

          return (
            <div key={type} className="space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="font-medium text-slate-700 dark:text-slate-300 truncate max-w-[160px]" title={label}>
                  {label}
                </span>
                <span className="font-bold text-slate-900 dark:text-white px-1.5 py-0.5 rounded text-[11px] bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 ml-2">
                  {count}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden border border-slate-200/40 dark:border-slate-800/60">
                <div
                  className={`h-full rounded-full transition-all duration-500 ease-out ${colorClass}`}
                  style={{ width: `${percent}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}