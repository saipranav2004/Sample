import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CLASSIFICATION_CONFIG } from '../../utils/constants';

// 100% solid, non-transparent tooltip
const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const data = payload[0];
  const percentage = data.payload?.percentage ?? 0;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 shadow-2xl z-50">
      <div className="flex items-center gap-2 mb-1">
        <div
          className="w-3 h-3 rounded-full shrink-0"
          style={{ backgroundColor: data.payload?.color }}
        />
        <span className="text-xs font-bold text-slate-900 dark:text-white">
          {data.name}
        </span>
      </div>
      <div className="flex items-baseline gap-2 ml-5">
        <span className="text-base font-extrabold text-slate-900 dark:text-white">
          {Number(data.value ?? 0).toLocaleString()}
        </span>
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          ({percentage}%)
        </span>
      </div>
    </div>
  );
};

const ClassificationPie = ({ data }) => {
  const safeData = data ?? {};
  const [activeIndex, setActiveIndex] = useState(null);

  const total = Object.values(safeData).reduce((sum, val) => sum + Number(val ?? 0), 0);

  const chartData = Object.entries(safeData)
    ?.map(([key, value]) => {
      const numVal = Number(value ?? 0);
      return {
        key: key,
        name: CLASSIFICATION_CONFIG?.[key]?.label ?? key ?? 'Unknown',
        value: numVal,
        color: CLASSIFICATION_CONFIG?.[key]?.color ?? '#6B7280',
        percentage: total > 0 ? ((numVal / total) * 100).toFixed(1) : 0,
      };
    })
    ?.filter((item) => (item?.value ?? 0) > 0)
    ?.sort((a, b) => b.value - a.value) ?? [];

  if (chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-72 text-slate-400 dark:text-slate-500 text-sm">
        No classification data available
      </div>
    );
  }

  // Active hovered slice data
  const hoveredItem = activeIndex !== null && chartData[activeIndex] ? chartData[activeIndex] : null;

  return (
    <div className="relative h-72 w-full flex items-center justify-center">
      {/* 🎯 Dynamic Center Content (Switches between Total and Hovered Item) */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none select-none z-10 px-4 text-center">
        {hoveredItem ? (
          <>
            <span
              className="text-2xl font-extrabold tracking-tight leading-none"
              style={{ color: hoveredItem.color }}
            >
              {Number(hoveredItem.value ?? 0).toLocaleString()}
            </span>
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mt-1 truncate max-w-[130px]">
              {hoveredItem.name}
            </span>
            <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
              {hoveredItem.percentage}%
            </span>
          </>
        ) : (
          <>
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-none">
              {Number(total ?? 0).toLocaleString()}
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mt-1">
              Total NHIs
            </span>
          </>
        )}
      </div>

      {/* Donut Chart with Hover Handlers */}
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={72}
            outerRadius={100}
            paddingAngle={3}
            dataKey="value"
            stroke="none"
            isAnimationActive={true}
            animationBegin={0}
            animationDuration={800}
            onMouseEnter={(_, index) => setActiveIndex(index)}
            onMouseLeave={() => setActiveIndex(null)}
          >
            {chartData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry?.color ?? '#6B7280'}
                className="cursor-pointer transition-transform duration-200"
                style={{
                  outline: 'none',
                  transform: activeIndex === index ? 'scale(1.04)' : 'scale(1)',
                  transformOrigin: 'center center',
                }}
              />
            ))}
          </Pie>

          <Tooltip
            content={<CustomTooltip />}
            wrapperStyle={{ zIndex: 1000, pointerEvents: 'none' }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ClassificationPie;