import React, { createContext, useContext, useState } from 'react';

const ScanContext = createContext(null);

export const ScanProvider = ({ children }) => {
  const [selectedScanId, setSelectedScanId] = useState(''); // Empty string means "Latest Scan"

  return (
    <ScanContext.Provider value={{ selectedScanId, setSelectedScanId }}>
      {children}
    </ScanContext.Provider>
  );
};

export const useScan = () => {
  const context = useContext(ScanContext);
  if (!context) {
    throw new Error('useScan must be used within a ScanProvider');
  }
  return context;
};