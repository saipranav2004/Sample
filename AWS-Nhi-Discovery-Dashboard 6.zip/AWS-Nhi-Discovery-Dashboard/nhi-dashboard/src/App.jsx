import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ScanProvider } from './context/ScanContext';
import { useAuth } from './hooks/useAuth';
import LoginPage from './pages/LoginPage';
import DashboardLayout from './components/layout/DashboardLayout';
import DashboardPage from './pages/DashboardPage';
import IdentitiesPage from './pages/IdentitiesPage';
import SecretsPage from './pages/SecretsPage';
import ScansPage from './pages/ScansPage';
import NotFoundPage from './pages/NotFoundPage';
import Loader from './components/common/Loader';
import CredentialsPage from './pages/CredentialsPage';

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <Loader />;
  return user ? children : <Navigate to="/login" replace />;
};

const App = () => {
  return (
      <ScanProvider>
        <ThemeProvider>
          <AuthProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route path="/" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
                  <Route index element={<Navigate to="/dashboard" replace />} />
                  <Route path="dashboard" element={<DashboardPage />} />
                  <Route path="identities" element={<IdentitiesPage />} />
                  <Route path="/credentials" element={<CredentialsPage />} />
                  <Route path="secrets" element={<SecretsPage />} />
                  <Route path="scans" element={<ScansPage />} />
                </Route>
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </BrowserRouter>
          </AuthProvider>
        </ThemeProvider>
      </ScanProvider>
  );
};

export default App;