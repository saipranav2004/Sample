import api from './api';

export const getIdentityEvents = async (identityARN, page = 1, pageSize = 10, scanID = '') => {
  const params = {
    identity_arn: identityARN,
    page: page || 1,
    page_size: pageSize || 10,
  };

  // Attach scan_id if available to isolate events to a specific scan
  if (scanID) {
    params.scan_id = scanID;
  }

  const response = await api.get('/api/events', { params });
  return response?.data || { success: false, data: [], total_count: 0 };
};