import api from './api';

export const getFlattenedCredentials = async (filters = {}) => {
  try {
    const response = await api.get('/api/credentials', { params: filters });
    return response.data;
  } catch (err) {
    console.error('getFlattenedCredentials error:', err);
    return { success: false, data: [], total_count: 0 };
  }
};