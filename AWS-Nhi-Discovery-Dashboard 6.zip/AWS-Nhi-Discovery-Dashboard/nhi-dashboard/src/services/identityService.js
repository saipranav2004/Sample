import api from './api';

export const getIdentities = async (params = {}) => {
  const response = await api.get('/api/identities', { params });
  return response?.data;
};

export const getIdentityLineage = async (arn, scanId, page = 1, pageSize = 10) => {
  const params = { arn, page, page_size: pageSize };
  if (scanId) params.scan_id = scanId;
  const response = await api.get('/api/identities/lineage', { params });
  return response?.data;
};

export const getIdentityEvents = async (arn, scanId, page = 1, pageSize = 10) => {
  const params = { arn, page, page_size: pageSize };
  if (scanId) params.scan_id = scanId;
  const response = await api.get('/api/identities/events', { params });
  return response?.data;
};

export const getRoleConsumers = async (arn, scanId, page = 1, pageSize = 10) => {
  const params = { arn, page, page_size: pageSize };
  if (scanId) params.scan_id = scanId;
  const response = await api.get('/api/identities/consumers', { params });
  return response?.data?.data || response?.data || response;
};