import api from './api';

export const login = async (email, password) => {
  const response = await api.post('/api/auth/login', { email, password });
  return response.data;
};

export const getProfile = async () => {
  const response = await api.get('/api/auth/me');
  return response.data;
};