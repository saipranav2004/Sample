// src/services/dashboardService.js
import api from './api';

/**
 * Fetch dashboard summary metrics.
 * @param {object} params - Optional search/filter parameters (e.g. { scan_id })
 */
export const getDashboardSummary = async (params = {}) => {
  const response = await api.get('/api/dashboard/summary', { params });
  return response.data;
};