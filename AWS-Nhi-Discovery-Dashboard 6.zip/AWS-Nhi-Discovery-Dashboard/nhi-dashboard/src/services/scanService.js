import api from './api';

export const getScans = async (page = 1, pageSize = 10) => {
  const response = await api.get('/api/scans', {
    params: { page, page_size: pageSize },
  });
  return response.data;
};