import api from './api';

export const getSecrets = async (page = 1, pageSize = 10, search = '', scanId = '') => {
  const params = { page, page_size: pageSize };
  if (search) params.search = search;
  if (scanId) params.scan_id = scanId;
  const response = await api.get('/api/secrets', { params });
  return response?.data ?? { success: false, data: [], total_count: 0 };
};