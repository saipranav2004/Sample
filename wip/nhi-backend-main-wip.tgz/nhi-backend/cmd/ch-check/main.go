// Command ch-check connects to ClickHouse using the same NHI_CLICKHOUSE_*
// settings as the API server and prints read-only facts about the CloudTrail
// table: schema, row count, time span, account IDs and ARN-field coverage.
// It exists to validate the assumptions in the ClickHouse integration plan
// against real data. It only ever runs SELECT / DESCRIBE.
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"reflect"
	"strings"
	"time"

	"github.com/joho/godotenv"

	"nhi-backend-api/internal/clickhouse"
	"nhi-backend-api/internal/config"
)

func main() {
	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
		log.Fatalf("load .env: %v", err)
	}
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load configuration: %v", err)
	}
	if !cfg.ClickHouse.Enabled() {
		log.Fatalf("clickhouse is not configured: set NHI_CLICKHOUSE_HOST, NHI_CLICKHOUSE_DATABASE, NHI_CLICKHOUSE_USER and NHI_CLICKHOUSE_PASSWORD")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	client, err := clickhouse.New(ctx, cfg.ClickHouse)
	if err != nil {
		log.Fatalf("connect: %v", err)
	}
	defer client.Close()
	table := client.Table() // validated identifier
	fmt.Printf("connected to %s:%d/%s, table %s\n\n", cfg.ClickHouse.Host, cfg.ClickHouse.Port, cfg.ClickHouse.Database, table)

	section("SCHEMA")
	show(ctx, client, "DESCRIBE TABLE "+table)

	section("ROW COUNT / TIME SPAN")
	show(ctx, client, fmt.Sprintf("SELECT count() AS total_rows, min(event_time) AS oldest, max(event_time) AS newest FROM %s", table))

	section("ACCOUNT IDS (top 20 by rows)")
	show(ctx, client, fmt.Sprintf("SELECT account_id, count() AS rows FROM %s GROUP BY account_id ORDER BY rows DESC LIMIT 20", table))

	section("ARN FIELD COVERAGE (rows where the field is non-empty)")
	show(ctx, client, fmt.Sprintf(`SELECT
		count() AS total,
		countIf(caller_arn != '')         AS caller_arn,
		countIf(session_issuer_arn != '') AS session_issuer_arn,
		countIf(access_key_id != '')      AS access_key_id,
		countIf(resource_arn != '')       AS resource_arn,
		countIf(error_code != '')         AS error_code,
		countIf(source_ip != '')          AS source_ip
	FROM %s`, table))

	section("CALLER ARN SHAPES (assumed-role / user / root / other)")
	show(ctx, client, fmt.Sprintf(`SELECT
		multiIf(caller_arn LIKE '%%:assumed-role/%%', 'assumed-role',
		        caller_arn LIKE '%%:user/%%', 'iam-user',
		        caller_arn LIKE '%%:root', 'root',
		        caller_arn = '', 'empty', 'other') AS shape,
		countIf(session_issuer_arn != '') AS with_issuer,
		count() AS rows
	FROM %s GROUP BY shape ORDER BY rows DESC`, table))

	section("TOP EVENT SOURCES")
	show(ctx, client, fmt.Sprintf("SELECT event_source, count() AS rows FROM %s GROUP BY event_source ORDER BY rows DESC LIMIT 15", table))

	section("IAM CREATE EVENTS (can we find who created identities?)")
	show(ctx, client, fmt.Sprintf(`SELECT event_name, count() AS rows, countIf(resource_arn != '') AS with_resource_arn
	FROM %s WHERE event_name IN ('CreateRole','CreateUser','CreateAccessKey','CreateInstanceProfile')
	GROUP BY event_name`, table))

	section("SAMPLE ROWS (5 most recent; values truncated to 120 chars)")
	show(ctx, client, fmt.Sprintf("SELECT * FROM %s ORDER BY event_time DESC LIMIT 5", table))
}

func section(title string) { fmt.Printf("=== %s ===\n", title) }

// show runs a read-only query and prints every row as column=value pairs.
func show(ctx context.Context, c *clickhouse.Client, query string) {
	qctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	rows, err := c.Conn().Query(qctx, query)
	if err != nil {
		fmt.Printf("  query failed: %v\n\n", err)
		return
	}
	defer rows.Close()

	names := rows.Columns()
	types := rows.ColumnTypes()
	n := 0
	for rows.Next() {
		dest := make([]any, len(types))
		for i, t := range types {
			dest[i] = reflect.New(t.ScanType()).Interface()
		}
		if err := rows.Scan(dest...); err != nil {
			fmt.Printf("  scan failed: %v\n\n", err)
			return
		}
		parts := make([]string, len(dest))
		for i := range dest {
			v := fmt.Sprintf("%v", reflect.ValueOf(dest[i]).Elem().Interface())
			if len(v) > 120 {
				v = v[:120] + "..."
			}
			parts[i] = names[i] + "=" + v
		}
		fmt.Println("  " + strings.Join(parts, "  "))
		n++
	}
	if err := rows.Err(); err != nil {
		fmt.Printf("  read failed: %v\n", err)
	}
	if n == 0 {
		fmt.Println("  (no rows)")
	}
	fmt.Println()
}
