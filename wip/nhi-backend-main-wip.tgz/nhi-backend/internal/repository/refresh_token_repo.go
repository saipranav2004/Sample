package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"nhi-backend-api/internal/database"
)

const globalRefreshTokensTable = "refresh_tokens"

func (r *UserRepository) refreshTable() string {
	return database.Table(r.schema, globalRefreshTokensTable)
}

// CreateRefreshToken stores the hash of a newly issued refresh token.
func (r *UserRepository) CreateRefreshToken(ctx context.Context, userID int, tokenHash string, expiresAt time.Time) error {
	db, err := r.globalDB()
	if err != nil {
		return err
	}
	query := `INSERT INTO ` + r.refreshTable() + ` (user_id, token_hash, expires_at) VALUES ($1, $2, $3)`
	if _, err := db.ExecContext(ctx, query, userID, tokenHash, expiresAt.UTC()); err != nil {
		return fmt.Errorf("store refresh token: %w", err)
	}
	return nil
}

// ConsumeRefreshToken atomically revokes a valid (unrevoked, unexpired) token
// and returns its owner. found=false means the token is unknown, expired or
// already used. reused=true means it existed but was already revoked, so the
// caller should treat it as theft and revoke the user's other sessions.
func (r *UserRepository) ConsumeRefreshToken(ctx context.Context, tokenHash string) (userID int, found, reused bool, err error) {
	db, err := r.globalDB()
	if err != nil {
		return 0, false, false, err
	}
	query := `UPDATE ` + r.refreshTable() + ` SET revoked_at = NOW()
		WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > NOW()
		RETURNING user_id`
	err = db.QueryRowContext(ctx, query, tokenHash).Scan(&userID)
	if err == nil {
		return userID, true, false, nil
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return 0, false, false, fmt.Errorf("consume refresh token: %w", err)
	}
	// Not consumable: distinguish "already revoked" (reuse) from unknown/expired.
	var owner int
	var revoked bool
	lookup := `SELECT user_id, revoked_at IS NOT NULL FROM ` + r.refreshTable() + ` WHERE token_hash = $1`
	err = db.QueryRowContext(ctx, lookup, tokenHash).Scan(&owner, &revoked)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, false, false, nil
	}
	if err != nil {
		return 0, false, false, fmt.Errorf("lookup refresh token: %w", err)
	}
	return owner, false, revoked, nil
}

// RevokeRefreshToken revokes a single token by hash (idempotent).
func (r *UserRepository) RevokeRefreshToken(ctx context.Context, tokenHash string) error {
	db, err := r.globalDB()
	if err != nil {
		return err
	}
	query := `UPDATE ` + r.refreshTable() + ` SET revoked_at = NOW() WHERE token_hash = $1 AND revoked_at IS NULL`
	if _, err := db.ExecContext(ctx, query, tokenHash); err != nil {
		return fmt.Errorf("revoke refresh token: %w", err)
	}
	return nil
}

// RevokeAllRefreshTokens revokes every active refresh token of a user.
func (r *UserRepository) RevokeAllRefreshTokens(ctx context.Context, userID int) error {
	db, err := r.globalDB()
	if err != nil {
		return err
	}
	query := `UPDATE ` + r.refreshTable() + ` SET revoked_at = NOW() WHERE user_id = $1 AND revoked_at IS NULL`
	if _, err := db.ExecContext(ctx, query, userID); err != nil {
		return fmt.Errorf("revoke user refresh tokens: %w", err)
	}
	return nil
}
