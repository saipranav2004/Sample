package v1

import (
	"context"
	"fmt"

	models "nhi-backend-api/internal/models/v1"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/scope"
)

type IdentitiesListService struct {
	repo     *repov1.IdentitiesListRepository
	resolver *scope.Resolver
	activity *ActivityService
}

func NewIdentitiesListService(repo *repov1.IdentitiesListRepository, resolver *scope.Resolver, activity *ActivityService) *IdentitiesListService {
	return &IdentitiesListService{repo: repo, resolver: resolver, activity: activity}
}

func (s *IdentitiesListService) GetIdentities(ctx context.Context, userID, tenantID, dbName string, f models.IdentityListFilter) (*models.IdentityListResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetIdentitiesList(ctx, resolved, f, s.activity.ForRequest(resolved))
	if err != nil {
		return nil, fmt.Errorf("get scoped identities: %w", err)
	}
	return result, nil
}
