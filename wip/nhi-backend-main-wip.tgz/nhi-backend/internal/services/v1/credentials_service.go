package v1

import (
	"context"
	"fmt"

	models "nhi-backend-api/internal/models/v1"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/scope"
)

type CredentialsService struct {
	repo     *repov1.CredentialsRepository
	resolver *scope.Resolver
	activity *ActivityService
}

func NewCredentialsService(repo *repov1.CredentialsRepository, resolver *scope.Resolver, activity *ActivityService) *CredentialsService {
	return &CredentialsService{repo: repo, resolver: resolver, activity: activity}
}

func (s *CredentialsService) GetCredentials(ctx context.Context, userID, tenantID, dbName string, f models.CredentialListFilter) (*models.CredentialListResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetCredentialsList(ctx, resolved, f, s.activity.ForRequest(resolved))
	if err != nil {
		return nil, fmt.Errorf("get scoped credentials: %w", err)
	}
	return result, nil
}
