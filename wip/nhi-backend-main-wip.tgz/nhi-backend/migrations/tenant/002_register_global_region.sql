-- Run once per tenant schema after inventory data is present:
--   psql "$DSN" -v schema=tenant_a -f migrations/tenant/002_register_global_region.sql
-- Register the synthetic AWS "global" region for accounts that have
-- non-deleted global resources. Existing tenant,
-- account, and default values are derived from the tenant's accounts table;
-- no tenant ID, account ID, or database name is hard-coded.
--
-- Re-runnable: rows are inserted only when the tenant/account/global mapping
-- does not already exist. The schema must provide the four columns used here.
BEGIN;

WITH global_account_ids AS (
    SELECT DISTINCT resources.account_id
    FROM (
        SELECT i.account_id
        FROM :"schema".identities AS i
        WHERE i.deleted_at IS NULL
          AND LOWER(BTRIM(i.region)) = 'global'
          AND i.account_id IS NOT NULL
          AND BTRIM(i.account_id) <> ''

        UNION

        SELECT c.account_id
        FROM :"schema".credentials AS c
        WHERE c.deleted_at IS NULL
          AND LOWER(BTRIM(c.region)) = 'global'
          AND c.account_id IS NOT NULL
          AND BTRIM(c.account_id) <> ''
    ) AS resources
),
tenant_account_defaults AS (
    SELECT a.tenant_id,
           a.account_id,
           BOOL_OR(COALESCE(a.is_default, false)) AS is_default
    FROM :"schema".accounts AS a
    JOIN global_account_ids AS g ON g.account_id = a.account_id
    GROUP BY a.tenant_id, a.account_id
)
INSERT INTO :"schema".accounts (tenant_id, account_id, region, is_default)
SELECT t.tenant_id, t.account_id, 'global', t.is_default
FROM tenant_account_defaults AS t
WHERE NOT EXISTS (
    SELECT 1
    FROM :"schema".accounts AS existing
    WHERE existing.tenant_id = t.tenant_id
      AND existing.account_id = t.account_id
      AND LOWER(BTRIM(existing.region)) = 'global'
);

COMMIT;
