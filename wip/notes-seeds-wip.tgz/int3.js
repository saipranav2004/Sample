const { chromium } = require('playwright');
const OUT = process.argv[2];
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  for (const [name, vp, scheme] of [['dark', { width: 1440, height: 900 }, 'dark'], ['mobile', { width: 390, height: 844 }, 'light']]) {
    const page = await (await browser.newContext({ viewport: vp, colorScheme: scheme })).newPage();
    const errs = []; page.on('pageerror', (e) => errs.push(e.message));
    await page.goto('http://localhost:3000/login'); await page.fill('#login-username', 'alice@acme.test'); await page.fill('#login-password', 'Passw0rd!'); await page.click('button[type=submit]');
    await page.waitForURL('**/overview', { timeout: 15000 });
    await page.goto('http://localhost:3000/integrations?exposure=111111111111'); await page.waitForTimeout(2000);
    await page.screenshot({ path: `${OUT}/20-${name}-drawer.png` });
    await page.keyboard.press('Escape'); await page.waitForTimeout(500);
    await page.screenshot({ path: `${OUT}/21-${name}-page.png`, fullPage: true });
    const sw = await page.evaluate(() => document.documentElement.scrollWidth);
    console.log(name, 'scrollWidth', sw, 'errors', errs);
  }
  await browser.close();
})();
