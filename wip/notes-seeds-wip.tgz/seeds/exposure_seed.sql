-- Credential exposure seed for local verification (idempotent).
-- Apply: psql "host=127.0.0.1 user=postgres dbname=nhi_db sslmode=require" -v schema=tenant_a -f exposure_seed.sql
-- Tables come from w5/nhi-backend/scripts/test_schema.sql. Values are masked the way the scanner masks them.

INSERT INTO :"schema".secscan_findings_github
  (finding_id, client_id, repository, branch, commit_id, author, created_at, detector, severity, file_path, line_number,
   redacted, verification_status, risk_tier, recommended_action, codecommit_uri, platform, github_uri, line_preview,
   confidence, category, committer, commit_message, commit_authored_at, files_changed, additions, deletions,
   repo_visibility, repo_stars, repo_forks, repo_pushed_at, ml_score, ml_decision, ml_model_version)
VALUES
  ('gh-acme-0001', 'acme-prod', 'acme-corp/payments-api', 'refs/heads/main', '9f2c4e1a7b3d5f60812ab4c9d0e1f2a3b4c5d6e7',
   'Priya Raman <priya.raman@acme.test>', '2026-10-14T08:12:44Z', 'aws_access_key', 'HIGH', 'config/settings.py', 42,
   'AKIA****************QX7M', 'UNSUPPORTED', 'HIGH', 'TRIGGER_REMEDIATION', NULL, 'github',
   'https://github.com/acme-corp/payments-api/blob/9f2c4e1a7b3d5f60812ab4c9d0e1f2a3b4c5d6e7/config/settings.py#L42',
   'AWS_ACCESS_KEY_ID = "AKIA****************QX7M"', 'high', 'cloud_credential',
   'Priya Raman <priya.raman@acme.test>', 'Add S3 export for settlement reports', '2026-10-13T17:40:02Z', 3, 58, 4,
   'private', 4, 1, '2026-10-14T07:55:10Z', 0.97, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('gh-acme-0002', 'acme-prod', 'acme-corp/payments-api', 'refs/heads/main', '9f2c4e1a7b3d5f60812ab4c9d0e1f2a3b4c5d6e7',
   'Priya Raman <priya.raman@acme.test>', '2026-10-14T08:12:44Z', 'aws_secret_key', 'HIGH', 'config/settings.py', 43,
   'wJal************************************', 'UNSUPPORTED', 'HIGH', 'TRIGGER_REMEDIATION', NULL, 'github',
   'https://github.com/acme-corp/payments-api/blob/9f2c4e1a7b3d5f60812ab4c9d0e1f2a3b4c5d6e7/config/settings.py#L43',
   'AWS_SECRET_ACCESS_KEY = "wJal************************************"', 'high', 'cloud_credential',
   'Priya Raman <priya.raman@acme.test>', 'Add S3 export for settlement reports', '2026-10-13T17:40:02Z', 3, 58, 4,
   'private', 4, 1, '2026-10-14T07:55:10Z', 0.96, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('gh-acme-0003', 'acme-prod', 'acme-corp/storefront-web', 'refs/heads/feature/checkout-v2', '1b7e93c0d4f2a6b8c0e1d2f3a4b5c6d7e8f90a1b',
   'Marco Lin <marco.lin@acme.test>', '2026-10-11T15:03:19Z', 'stripe_live_key', 'HIGH', 'src/lib/payments.ts', 17,
   'sk_live_****************************9aZ', 'UNSUPPORTED', 'HIGH', 'PAGE_ON_CALL', NULL, 'github',
   'https://github.com/acme-corp/storefront-web/blob/1b7e93c0d4f2a6b8c0e1d2f3a4b5c6d7e8f90a1b/src/lib/payments.ts#L17',
   'const stripe = new Stripe("sk_live_****************************9aZ");', 'high', 'payment_credential',
   'GitHub <noreply@github.com>', 'Wire live checkout behind flag', '2026-10-11T14:58:40Z', 6, 211, 37,
   'public', 128, 23, '2026-10-12T09:20:00Z', 0.93, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('gh-acme-0004', 'acme-prod', 'acme-corp/storefront-web', 'refs/heads/main', '5d1a2b3c4d5e6f708192a3b4c5d6e7f809102a3b',
   'Sara Okafor <sara.okafor@acme.test>', '2026-10-06T10:41:07Z', 'slack_webhook', 'MEDIUM', '.github/workflows/deploy.yml', 61,
   'https://hooks.slack.com/services/T0****/B0****/********', 'UNSUPPORTED', 'MEDIUM', 'NOTIFY_SOC', NULL, 'github',
   'https://github.com/acme-corp/storefront-web/blob/5d1a2b3c4d5e6f708192a3b4c5d6e7f809102a3b/.github/workflows/deploy.yml#L61',
   '          SLACK_WEBHOOK: https://hooks.slack.com/services/T0****/B0****/********', 'medium', 'webhook',
   'Sara Okafor <sara.okafor@acme.test>', 'Notify #releases on deploy', '2026-10-06T10:30:55Z', 1, 9, 0,
   'public', 128, 23, '2026-10-12T09:20:00Z', 0.81, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('gh-acme-0005', 'acme-prod', 'acme-corp/infra-terraform', 'refs/heads/main', 'c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6',
   'Dev Bot <devbot@acme.test>', '2026-09-29T21:15:33Z', 'generic_password_assignment', 'LOW', 'modules/rds/variables.tf', 88,
   'pass********', 'UNSUPPORTED', 'LOW', 'LOG_ONLY', NULL, 'github',
   'https://github.com/acme-corp/infra-terraform/blob/c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6/modules/rds/variables.tf#L88',
   '  default = "pass********"', 'medium', 'password',
   'Dev Bot <devbot@acme.test>', 'Bump RDS module defaults', '2026-09-29T21:10:12Z', 2, 14, 6,
   'private', 2, 0, '2026-10-09T12:00:00Z', 0.64, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  -- Two the model scored as false positives: served by /findings/flagged only.
  ('gh-acme-0006', 'acme-prod', 'acme-corp/storefront-web', 'refs/heads/main', '77aa88bb99cc00dd11ee22ff33aa44bb55cc66dd',
   'Marco Lin <marco.lin@acme.test>', '2026-10-08T12:00:00Z', 'generic_api_key', 'MEDIUM', 'tests/fixtures/stripe_mock.json', 5,
   'test_****************', 'UNSUPPORTED', 'MEDIUM', 'NOTIFY_SOC', NULL, 'github',
   'https://github.com/acme-corp/storefront-web/blob/77aa88bb99cc00dd11ee22ff33aa44bb55cc66dd/tests/fixtures/stripe_mock.json#L5',
   '  "api_key": "test_****************",', 'medium', 'api_key',
   'Marco Lin <marco.lin@acme.test>', 'Add checkout fixtures', '2026-10-08T11:52:00Z', 4, 120, 0,
   'public', 128, 23, '2026-10-12T09:20:00Z', 0.08, 'FALSE_POSITIVE', 'secret-clf-2026.09')
ON CONFLICT (finding_id) DO NOTHING;

INSERT INTO :"schema".secscan_findings_codecommit
  (finding_id, client_id, repository, branch, commit_id, author, created_at, detector, severity, file_path, line_number,
   redacted, verification_status, risk_tier, recommended_action, codecommit_uri, platform, github_uri, line_preview,
   confidence, category, committer, commit_message, commit_authored_at, files_changed, additions, deletions,
   ml_score, ml_decision, ml_model_version)
VALUES
  ('cc-acme-0001', 'acme-prod', 'data-pipeline', 'refs/heads/main', 'e1f2a3b4c5d6e7f8091a2b3c4d5e6f708192a3b4',
   'Leah Kim <leah.kim@acme.test>', '2026-10-13T06:22:10Z', 'aws_access_key', 'HIGH', 'jobs/etl/load_orders.py', 12,
   'AKIA****************7KPD', 'UNSUPPORTED', 'HIGH', 'TRIGGER_REMEDIATION',
   'https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/data-pipeline/browse/e1f2a3b4c5d6e7f8091a2b3c4d5e6f708192a3b4/--/jobs/etl/load_orders.py?region=us-east-1',
   'codecommit', NULL, 'boto3.client("s3", aws_access_key_id="AKIA****************7KPD")', 'high', 'cloud_credential',
   'Leah Kim <leah.kim@acme.test>', 'Hotfix: load orders from legacy bucket', '1760335200 +0000', 1, NULL, NULL,
   0.95, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('cc-acme-0002', 'acme-prod', 'data-pipeline', 'refs/heads/develop', 'a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0',
   'Leah Kim <leah.kim@acme.test>', '2026-10-02T19:47:51Z', 'private_key', 'HIGH', 'deploy/keys/bastion.pem', 1,
   '-----BEGIN RSA PRIVATE KEY-----****', 'UNSUPPORTED', 'HIGH', 'PAGE_ON_CALL',
   'https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/data-pipeline/browse/a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0/--/deploy/keys/bastion.pem?region=us-east-1',
   'codecommit', NULL, '-----BEGIN RSA PRIVATE KEY-----****', 'high', 'private_key',
   'Leah Kim <leah.kim@acme.test>', 'Temp: bastion access for migration', '1759434400 +0000', 2, NULL, NULL,
   0.99, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('cc-acme-0003', 'acme-prod', 'payments-api', 'refs/heads/main', '0f1e2d3c4b5a69788796a5b4c3d2e1f0a1b2c3d4',
   'Tom Becker <tom.becker@acme.test>', '2026-09-24T09:05:00Z', 'database_connection_string', 'MEDIUM', 'helm/values-prod.yaml', 33,
   'postgres://payments:********@prod-db.internal:5432/payments', 'UNSUPPORTED', 'MEDIUM', 'NOTIFY_SOC',
   'https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/payments-api/browse/0f1e2d3c4b5a69788796a5b4c3d2e1f0a1b2c3d4/--/helm/values-prod.yaml?region=us-east-1',
   'codecommit', NULL, '  url: postgres://payments:********@prod-db.internal:5432/payments', 'high', 'database_credential',
   'Tom Becker <tom.becker@acme.test>', 'Move DB url into chart values', '1758704700 +0000', 3, NULL, NULL,
   0.88, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  ('cc-acme-0004', 'acme-prod', 'payments-api', 'refs/heads/main', '0f1e2d3c4b5a69788796a5b4c3d2e1f0a1b2c3d4',
   'Tom Becker <tom.becker@acme.test>', '2026-09-24T09:05:00Z', 'generic_password_assignment', 'LOW', 'scripts/local_setup.sh', 7,
   'pass****', 'UNSUPPORTED', 'LOW', 'LOG_ONLY',
   'https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/payments-api/browse/0f1e2d3c4b5a69788796a5b4c3d2e1f0a1b2c3d4/--/scripts/local_setup.sh?region=us-east-1',
   'codecommit', NULL, 'export DB_PASSWORD="pass****"', 'medium', 'password',
   'Tom Becker <tom.becker@acme.test>', 'Move DB url into chart values', '1758704700 +0000', 3, NULL, NULL,
   0.71, 'TRUE_POSITIVE', 'secret-clf-2026.09'),
  -- Model-flagged false positive.
  ('cc-acme-0005', 'acme-prod', 'data-pipeline', 'refs/heads/main', 'b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0',
   'Leah Kim <leah.kim@acme.test>', '2026-10-01T11:00:00Z', 'aws_access_key', 'HIGH', 'docs/README.md', 54,
   'AKIA****************MPLE', 'UNSUPPORTED', 'HIGH', 'TRIGGER_REMEDIATION',
   'https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/data-pipeline/browse/b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0/--/docs/README.md?region=us-east-1',
   'codecommit', NULL, 'Example: AKIA****************MPLE', 'medium', 'cloud_credential',
   'Leah Kim <leah.kim@acme.test>', 'Document credential setup', '1759316400 +0000', 1, NULL, NULL,
   0.04, 'FALSE_POSITIVE', 'secret-clf-2026.09')
ON CONFLICT (finding_id) DO NOTHING;

-- One accepted (allowlisted) exposure, so the Accepted view has a record.
INSERT INTO :"schema".secscan_findings_github
  (finding_id, client_id, repository, branch, commit_id, author, created_at, detector, severity, file_path, line_number,
   redacted, verification_status, risk_tier, recommended_action, platform, github_uri, line_preview, confidence, category,
   repo_visibility, ml_score, ml_decision, ml_model_version)
VALUES
  ('gh-acme-0007', 'acme-prod', 'acme-corp/infra-terraform', 'refs/heads/main', 'd4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6a7',
   'Dev Bot <devbot@acme.test>', '2026-09-18T13:30:00Z', 'generic_api_key', 'MEDIUM', 'examples/provider.tf', 9,
   'demo_**********', 'UNSUPPORTED', 'MEDIUM', 'NOTIFY_SOC', 'github',
   'https://github.com/acme-corp/infra-terraform/blob/d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6a7/examples/provider.tf#L9',
   '  token = "demo_**********"', 'medium', 'api_key', 'private', 0.42, 'TRUE_POSITIVE', 'secret-clf-2026.09')
ON CONFLICT (finding_id) DO NOTHING;

INSERT INTO :"schema".secscan_allowlist_dashboard (client_id, file_path, detector, redacted, reason, dismissed_by, dismissed_at)
VALUES ('acme-prod', 'examples/provider.tf', 'generic_api_key', 'demo_**********',
        'Documentation placeholder, not a real token', 'alice@acme.test', '2026-09-19T08:00:00Z')
ON CONFLICT DO NOTHING;
