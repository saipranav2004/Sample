"""Shared helpers for the posture and genome seeds: read the tenant_a inventory
(written by inventory_seed.py) from Postgres, query ClickHouse, quote SQL."""
import datetime as dt
import json
import os
import subprocess
import urllib.parse
import urllib.request
import uuid

TENANT = "11111111-1111-1111-1111-111111111111"
NS = uuid.UUID("6f1f7a10-0000-4000-8000-000000000001")  # same namespace as inventory_seed.py
A1, A2 = "111111111111", "222222222222"
ACCOUNT_NAMES = {A1: "acme-prod", A2: "acme-data"}
PG_DSN = os.environ.get("PG_DSN", "host=127.0.0.1 user=postgres dbname=nhi_db sslmode=require")
PG_ENV = dict(os.environ, PGPASSWORD=os.environ.get("PGPASSWORD", "localpass"))
CH_URL = os.environ.get("CH_URL", "http://127.0.0.1:8123")
NOW = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


def uid(key):
    return str(uuid.uuid5(NS, key))


def psql_json(sql):
    """Run a query that returns one json value per row; return the parsed rows."""
    out = subprocess.run(["psql", PG_DSN, "-AtX", "-v", "ON_ERROR_STOP=1", "-c", sql],
                         env=PG_ENV, check=True, capture_output=True, text=True).stdout
    return [json.loads(line) for line in out.splitlines() if line.strip()]


def psql_file(path):
    subprocess.run(["psql", PG_DSN, "-qX", "-v", "ON_ERROR_STOP=1", "-f", path], env=PG_ENV, check=True)


def ch_query(sql):
    """Return rows of a ClickHouse query as dicts (JSONEachRow), or None if unreachable."""
    try:
        req = urllib.request.Request(CH_URL + "/", data=(sql + " FORMAT JSONEachRow").encode(), method="POST")
        with urllib.request.urlopen(req, timeout=30) as r:
            return [json.loads(x) for x in r.read().decode().splitlines() if x.strip()]
    except Exception as e:  # noqa: BLE001
        print(f"clickhouse unavailable ({e}); continuing without it")
        return None


def ch_exec(sql, data=None):
    url = CH_URL + "/"
    body = sql
    if data is not None:
        url += "?query=" + urllib.parse.quote(sql)
        body = data
    req = urllib.request.Request(url, data=body.encode(), method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read().decode()


def q(v):
    """SQL literal."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(round(v, 2)) if isinstance(v, float) else str(v)
    if isinstance(v, dt.datetime):
        return "'" + v.astimezone(dt.timezone.utc).isoformat() + "'::timestamptz"
    if isinstance(v, dt.date):
        return "'" + v.isoformat() + "'::date"
    if isinstance(v, (dict, list)):
        return "'" + json.dumps(v).replace("'", "''") + "'::jsonb"
    return "'" + str(v).replace("'", "''") + "'"


def text_array(vals):
    return "ARRAY[" + ",".join(q(v) for v in vals) + "]::text[]" if vals else "ARRAY[]::text[]"


def load_inventory():
    """Identities with their bound credentials, plus trust edges, from tenant_a."""
    idents = psql_json(f"""
        SELECT row_to_json(x) FROM (
          SELECT i.id::text, i.arn, i.name, i.identity_type, i.functional_class, i.account_id, i.region,
                 i.owner, i.status, i.environment, i.is_publicly_accessible AS public,
                 i.type_attributes, i.cloudtrail_creator_arn,
                 extract(epoch FROM now() - i.last_activity_at) / 86400 AS idle_days,
                 extract(epoch FROM now() - i.created_at_aws) / 86400 AS age_days,
                 i.last_activity_at, i.created_at_aws
          FROM tenant_a.identities i WHERE i.deleted_at IS NULL ORDER BY i.arn) x""")
    creds = psql_json("""
        SELECT row_to_json(x) FROM (
          SELECT ic.identity_id, ic.binding_type, c.id::text AS credential_id, c.arn, c.name, c.credential_type,
                 c.status, c.privilege_level, c.attached_policies, c.trust_policy, c.permission_boundary_arn,
                 c.max_session_duration, c.rotation_enabled, c.owner_principal_arn,
                 extract(epoch FROM now() - c.created_at_aws) / 86400 AS age_days,
                 extract(epoch FROM now() - c.last_used_at) / 86400 AS unused_days,
                 c.created_at_aws, c.last_used_at
          FROM tenant_a.identity_credentials ic JOIN tenant_a.credentials c ON c.id::text = ic.credential_id::text
          ORDER BY c.arn) x""")
    owned = psql_json("""
        SELECT row_to_json(x) FROM (
          SELECT arn, name, credential_type, rotation_enabled, owner_principal_arn,
                 extract(epoch FROM expires_at - now()) / 86400 AS days_left
          FROM tenant_a.credentials WHERE credential_type IN ('secret','api_key','tls_cert','ssh_key')) x""")
    edges = psql_json("SELECT row_to_json(x) FROM (SELECT source_arn, target_arn, edge_type FROM tenant_a.trust_edges) x")
    by_id = {i["id"]: i for i in idents}
    for i in idents:
        i["creds"] = []
    for c in creds:
        if c["identity_id"] in by_id:
            by_id[c["identity_id"]]["creds"].append(c)
    for i in idents:
        roles = [c for c in i["creds"] if c["credential_type"] in ("iam_role", "iam_user")]
        i["primary"] = roles[0] if roles else None
        i["keys"] = [c for c in i["creds"] if c["credential_type"] == "access_key"]
        i["policies"] = [p["policy_name"] for p in (i["primary"] or {}).get("attached_policies") or []]
        lvl = str((i["primary"] or {}).get("privilege_level") or "1")
        i["priv"] = {"4": "admin", "3": "high", "2": "medium", "1": "low"}.get(lvl, lvl)  # stored numerically
        i["role_arn"] = (i["primary"] or {}).get("arn")
        i["owned_secrets"] = [o for o in owned if o["owner_principal_arn"] and o["owner_principal_arn"] == i["role_arn"]]
    return idents, edges
