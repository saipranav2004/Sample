#!/usr/bin/env python3
"""Deterministic inventory seed for tenant_a (schema in nhi_db).

Writes SQL to stdout. Replaces tenant_a's inventory tables and account scope
for accounts 111111111111 and 222222222222. Other tenants are untouched.

Identity ids are fixed UUIDs (uuid5 of the ARN) so other seeds (posture,
genome, ClickHouse events) can reference the same identities.
"""
import json
import random
import uuid

random.seed(7)
TENANT = "11111111-1111-1111-1111-111111111111"
NS = uuid.UUID("6f1f7a10-0000-4000-8000-000000000001")
A1, A2 = "111111111111", "222222222222"


def uid(key):
    return str(uuid.uuid5(NS, key))


def q(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, (dict, list)):
        return "'" + json.dumps(v).replace("'", "''") + "'::jsonb"
    return "'" + str(v).replace("'", "''") + "'"


def ago(days, hours=0):
    return f"now() - interval '{days} days {hours} hours'"


out = []
w = out.append
w("BEGIN;")
for t in ["identities", "credentials", "identity_credentials", "effective_permissions",
          "permission_usage", "trust_edges", "resources", "identity_usage"]:
    w(f"DELETE FROM tenant_a.{t};")
w(f"DELETE FROM tenant_a.accounts WHERE account_id IN ('{A1}','{A2}','333333333333');")
for acct, regions in [(A1, ["us-east-1", "eu-west-1", "global"]), (A2, ["us-east-1", "ap-south-1", "global"])]:
    for r in regions:
        w(f"INSERT INTO tenant_a.accounts (tenant_id, account_id, region, is_default) VALUES ('{TENANT}', '{acct}', '{r}', true);")

OWNERS = ["platform-team", "payments-team", "data-team", "security-team", "growth-team", None]
ENVS = ["production", "production", "staging", "development"]

identities = []   # dicts
credentials = []  # dicts
bindings = []     # (identity_id, credential_id, binding_type)
edges = []        # (source, target, type)
perms = {}        # credential_id -> (granted, [actions])
usage = []        # (credential_id, action, service, used, count, last_used_days)


def role_cred(acct, name, privilege, policies, trust_services=None, trust_accounts=None, last_used=1, created=400, boundary=None):
    arn = f"arn:aws:iam::{acct}:role/{name}"
    cid = uid("cred:" + arn)
    stmts = []
    for svc in trust_services or []:
        stmts.append({"Effect": "Allow", "Principal": {"Service": svc}, "Action": "sts:AssumeRole"})
    for a in trust_accounts or []:
        stmts.append({"Effect": "Allow", "Principal": {"AWS": f"arn:aws:iam::{a}:root"}, "Action": "sts:AssumeRole"})
    credentials.append(dict(
        id=cid, account_id=acct, region="global", arn=arn, name=name, credential_type="iam_role",
        status="active", last_used_at=None if last_used is None else ago(last_used), created_at_aws=ago(created),
        rotation_enabled=False, max_session_duration=3600, privilege_level=privilege,
        attached_policies=[{"policy_name": p, "policy_arn": f"arn:aws:iam::aws:policy/{p}"} for p in policies],
        trust_policy={"Version": "2012-10-17", "Statement": stmts}, permission_boundary_arn=boundary,
        owner_principal_arn=None, expires_at=None, last_rotated_at=None))
    return cid, arn


def add_identity(acct, region, arn, name, itype, fclass, env, owner, status="active", last=1, created=300,
                 public=False, attrs=None, creator=None):
    iid = uid(arn)
    identities.append(dict(
        id=iid, account_id=acct, region=region, arn=arn, name=name, identity_type=itype,
        functional_class=fclass, category="workload" if itype not in ("iam_user", "iam_role") else "iam",
        environment=env, owner=owner, status=status, is_publicly_accessible=public,
        created_at_aws=ago(created), first_seen_at=ago(min(created, 120)), last_seen_at=ago(0, 2),
        last_activity_at=None if last is None else ago(last), type_attributes=attrs or {},
        cloudtrail_creator_arn=creator, discovery_source="aws_api"))
    return iid


ADMIN = ["AdministratorAccess"]
READ = ["ReadOnlyAccess"]

# ── Lambda functions ────────────────────────────────────────────────────────
lambdas = [
    ("payments-api", A1, "us-east-1", "payments-team", "production", ["AmazonDynamoDBFullAccess"], "high", 0),
    ("payments-refunds", A1, "us-east-1", "payments-team", "production", ["AmazonDynamoDBFullAccess", "AmazonSQSFullAccess"], "high", 1),
    ("order-events", A1, "eu-west-1", "growth-team", "production", ["AmazonKinesisFullAccess"], "medium", 0),
    ("thumbnailer", A1, "us-east-1", None, "production", ADMIN, "admin", 2),
    ("report-builder", A2, "ap-south-1", "data-team", "production", ["AmazonS3ReadOnlyAccess"], "low", 3),
    ("ledger-sync", A2, "us-east-1", "payments-team", "production", ["AmazonRDSFullAccess"], "high", 0),
    ("legacy-cron", A1, "us-east-1", None, "production", ADMIN, "admin", 210),
    ("email-sender", A1, "eu-west-1", "growth-team", "staging", ["AmazonSESFullAccess"], "medium", 6),
    ("fraud-score", A2, "ap-south-1", "security-team", "production", ["AmazonSageMakerFullAccess"], "high", 0),
    ("feature-flags", A1, "us-east-1", "platform-team", "development", READ, "low", 45),
]
for name, acct, region, owner, env, pol, priv, last in lambdas:
    cid, rarn = role_cred(acct, f"{name}-role", priv, pol, trust_services=["lambda.amazonaws.com"], last_used=last)
    arn = f"arn:aws:lambda:{region}:{acct}:function:{name}"
    iid = add_identity(acct, region, arn, name, "lambda_function", "service", env, owner, last=last,
                       attrs={"role_arn": rarn, "runtime": "python3.12"},
                       creator=f"arn:aws:iam::{acct}:user/ci-deployer")
    bindings.append((iid, cid, "execution_role"))
    edges.append((arn, rarn, "bound_to"))
    edges.append(("lambda.amazonaws.com", rarn, "service_trust"))

# ── EC2 instances ───────────────────────────────────────────────────────────
ec2 = [
    ("web-1", A1, "us-east-1", "platform-team", "production", ["AmazonS3ReadOnlyAccess"], "medium", 0, True),
    ("web-2", A1, "us-east-1", "platform-team", "production", ["AmazonS3ReadOnlyAccess"], "medium", 0, True),
    ("bastion", A1, "us-east-1", "security-team", "production", ADMIN, "admin", 1, True),
    ("batch-runner", A2, "us-east-1", "data-team", "production", ["AmazonS3FullAccess"], "high", 2, False),
    ("jenkins", A1, "eu-west-1", None, "production", ADMIN, "admin", 0, True),
    ("analytics-1", A2, "ap-south-1", "data-team", "staging", ["AmazonAthenaFullAccess"], "medium", 95, False),
    ("vpn-gw", A1, "us-east-1", "security-team", "production", ["AmazonEC2ReadOnlyAccess"], "low", 0, True),
    ("old-worker", A2, "us-east-1", None, "development", ["AmazonSQSFullAccess"], "medium", 300, False),
]
for i, (name, acct, region, owner, env, pol, priv, last, public) in enumerate(ec2):
    cid, rarn = role_cred(acct, f"{name}-profile", priv, pol, trust_services=["ec2.amazonaws.com"], last_used=last)
    arn = f"arn:aws:ec2:{region}:{acct}:instance/i-0{i}{name.replace('-', '')[:6]}a1b2c3"
    iid = add_identity(acct, region, arn, name, "ec2_instance", "compute", env, owner,
                       status="stopped" if last > 200 else "running", last=last, public=public,
                       attrs={"role_arn": rarn, "instance_type": "t3.medium", "vpc_id": "vpc-0a1b2c"})
    bindings.append((iid, cid, "instance_profile"))
    edges.append((arn, rarn, "bound_to"))
    edges.append(("ec2.amazonaws.com", rarn, "service_trust"))

# ── ECS tasks ───────────────────────────────────────────────────────────────
ecs = [
    ("checkout", "prod-cluster", A1, "us-east-1", "payments-team", ["AmazonDynamoDBFullAccess"], "high", 0),
    ("checkout-2", "prod-cluster", A1, "us-east-1", "payments-team", ["AmazonDynamoDBFullAccess"], "high", 0),
    ("search", "prod-cluster", A1, "us-east-1", "growth-team", ["AmazonOpenSearchServiceFullAccess"], "high", 0),
    ("recommender", "ml-cluster", A2, "ap-south-1", "data-team", ["AmazonS3ReadOnlyAccess"], "low", 1),
    ("inventory", "prod-cluster", A1, "eu-west-1", "growth-team", ["AmazonRDSReadOnlyAccess"], "low", 0),
    ("notifier", "prod-cluster", A1, "eu-west-1", None, ["AmazonSNSFullAccess"], "medium", 4),
    ("etl-loader", "data-cluster", A2, "us-east-1", "data-team", ["AmazonS3FullAccess", "AmazonRedshiftFullAccess"], "high", 0),
    ("admin-console", "ops-cluster", A1, "us-east-1", "platform-team", ADMIN, "admin", 12),
]
for i, (name, cluster, acct, region, owner, pol, priv, last) in enumerate(ecs):
    cid, rarn = role_cred(acct, f"{name}-task-role", priv, pol, trust_services=["ecs-tasks.amazonaws.com"], last_used=last)
    arn = f"arn:aws:ecs:{region}:{acct}:task/{cluster}/{uuid.uuid5(NS, name).hex[:24]}"
    iid = add_identity(acct, region, arn, name, "ecs_task", "application", "production", owner, last=last,
                       attrs={"role_arn": rarn, "cluster_name": cluster, "service_name": name, "launch_type": "FARGATE"})
    bindings.append((iid, cid, "task_role"))
    edges.append((arn, rarn, "bound_to"))
    edges.append(("ecs-tasks.amazonaws.com", rarn, "service_trust"))

# ── Step Functions, Glue, CodeBuild ─────────────────────────────────────────
others = [
    ("order-saga", "step_function", A1, "us-east-1", "payments-team", "service", ["AWSLambdaRole"], "medium", 0, "states.amazonaws.com", "arn:aws:states:{r}:{a}:stateMachine:{n}"),
    ("refund-flow", "step_function", A1, "eu-west-1", "payments-team", "service", ["AWSLambdaRole"], "medium", 3, "states.amazonaws.com", "arn:aws:states:{r}:{a}:stateMachine:{n}"),
    ("nightly-etl", "glue_job", A2, "us-east-1", "data-team", "data", ["AWSGlueServiceRole", "AmazonS3FullAccess"], "high", 0, "glue.amazonaws.com", "arn:aws:glue:{r}:{a}:job/{n}"),
    ("pii-scrub", "glue_job", A2, "ap-south-1", "security-team", "data", ["AWSGlueServiceRole"], "medium", 1, "glue.amazonaws.com", "arn:aws:glue:{r}:{a}:job/{n}"),
    ("app-build", "codebuild_project", A1, "us-east-1", "platform-team", "infrastructure", ADMIN, "admin", 0, "codebuild.amazonaws.com", "arn:aws:codebuild:{r}:{a}:project/{n}"),
    ("infra-plan", "codebuild_project", A1, "us-east-1", "platform-team", "infrastructure", ["PowerUserAccess"], "high", 2, "codebuild.amazonaws.com", "arn:aws:codebuild:{r}:{a}:project/{n}"),
]
for name, itype, acct, region, owner, fclass, pol, priv, last, svc, pattern in others:
    cid, rarn = role_cred(acct, f"{name}-role", priv, pol, trust_services=[svc], last_used=last)
    arn = pattern.format(r=region, a=acct, n=name)
    iid = add_identity(acct, region, arn, name, itype, fclass, "production", owner, last=last, attrs={"role_arn": rarn})
    bindings.append((iid, cid, "service_role"))
    edges.append((arn, rarn, "bound_to"))
    edges.append((svc, rarn, "service_trust"))

# ── IAM roles assumed by other roles (the trust graph) ──────────────────────
deploy_cid, deploy_arn = role_cred(A1, "deploy-role", "admin", ADMIN, trust_accounts=[A1], last_used=0)
xacct_cid, xacct_arn = role_cred(A2, "cross-account-admin", "admin", ADMIN, trust_accounts=[A1], last_used=5)
audit_cid, audit_arn = role_cred(A2, "audit-reader", "low", ["SecurityAudit"], trust_accounts=[A1], last_used=1)
data_cid, data_arn = role_cred(A2, "data-lake-writer", "high", ["AmazonS3FullAccess"], trust_accounts=[A1], last_used=0)
breakglass_cid, breakglass_arn = role_cred(A1, "break-glass", "admin", ADMIN, trust_accounts=[A1], last_used=None, created=900)
for name, cid, arn, acct, owner, last in [
    ("deploy-role", deploy_cid, deploy_arn, A1, "platform-team", 0),
    ("cross-account-admin", xacct_cid, xacct_arn, A2, None, 5),
    ("audit-reader", audit_cid, audit_arn, A2, "security-team", 1),
    ("data-lake-writer", data_cid, data_arn, A2, "data-team", 0),
    ("break-glass", breakglass_cid, breakglass_arn, A1, "security-team", None),
]:
    iid = add_identity(acct, "global", arn, name, "iam_role", "security" if "audit" in name or "glass" in name else "infrastructure",
                       "production", owner, last=last, created=500)
    bindings.append((iid, cid, "self"))

def role_of(name):
    for c in credentials:
        if c["name"] == name:
            return c["arn"]
    raise KeyError(name)

edges += [
    (role_of("app-build-role"), deploy_arn, "assume_role"),
    (role_of("infra-plan-role"), deploy_arn, "assume_role"),
    (deploy_arn, xacct_arn, "cross_account"),
    (deploy_arn, xacct_arn, "assume_role"),
    (role_of("jenkins-profile"), deploy_arn, "assume_role"),
    (role_of("nightly-etl-role"), data_arn, "assume_role"),
    (role_of("etl-loader-task-role"), data_arn, "assume_role"),
    (role_of("bastion-profile"), break_arn := breakglass_arn, "assume_role"),
    (role_of("fraud-score-role"), audit_arn, "assume_role"),
    (f"arn:aws:iam::{A1}:root", audit_arn, "trusts"),
]

# ── IAM users and access keys ───────────────────────────────────────────────
users = [
    ("ci-deployer", A1, "platform-team", 0, [(400, 0), (20, None)], ADMIN, "admin"),
    ("terraform-bot", A1, "platform-team", 1, [(120, 1)], ["PowerUserAccess"], "high"),
    ("backup-agent", A2, None, 140, [(700, 140)], ["AmazonS3FullAccess"], "high"),
    ("datadog-integration", A2, "security-team", 0, [(60, 0)], ["SecurityAudit"], "low"),
]
for name, acct, owner, last, keys, pol, priv in users:
    arn = f"arn:aws:iam::{acct}:user/{name}"
    iid = add_identity(acct, "global", arn, name, "iam_user", "infrastructure", "production", owner,
                       status="active" if last < 100 else "inactive", last=last, created=800)
    ucid = uid("cred:" + arn)
    credentials.append(dict(
        id=ucid, account_id=acct, region="global", arn=arn, name=name, credential_type="iam_user", status="active",
        last_used_at=ago(last), created_at_aws=ago(800), rotation_enabled=False, max_session_duration=None,
        privilege_level=priv, attached_policies=[{"policy_name": p, "policy_arn": f"arn:aws:iam::aws:policy/{p}"} for p in pol],
        trust_policy=None, permission_boundary_arn=None, owner_principal_arn=arn, expires_at=None, last_rotated_at=None))
    bindings.append((iid, ucid, "self"))
    for k, (age, used) in enumerate(keys):
        kid = f"AKIA{uuid.uuid5(NS, name + str(k)).hex[:16].upper()}"
        kcid = uid("key:" + kid)
        credentials.append(dict(
            id=kcid, account_id=acct, region="global", arn=f"{arn}/accesskey/{kid}", name=kid, credential_type="access_key",
            status="active" if used is not None or age < 30 else "inactive",
            last_used_at=None if used is None else ago(used), created_at_aws=ago(age),
            rotation_enabled=False, max_session_duration=None, privilege_level=priv, attached_policies=[],
            trust_policy=None, permission_boundary_arn=None, owner_principal_arn=arn, expires_at=None,
            last_rotated_at=ago(age)))
        bindings.append((iid, kcid, "access_key"))
    edges.append((arn, deploy_arn, "assume_role")) if name == "ci-deployer" else None

# ── Secrets, certificates and API keys with expiry ──────────────────────────
for name, acct, ctype, days_left, owner_arn in [
    ("prod/db/password", A1, "secret", 9, role_of("ledger-sync-role")),
    ("prod/stripe/api-key", A1, "api_key", 21, role_of("payments-api-role")),
    ("api.acme.com", A1, "tls_cert", 5, None),
    ("partner-sftp-key", A2, "ssh_key", -3, None),
    ("analytics/token", A2, "secret", 140, role_of("report-builder-role")),
]:
    arn = (f"arn:aws:secretsmanager:us-east-1:{acct}:secret:{name}-Ab12Cd" if ctype in ("secret", "api_key", "ssh_key")
           else f"arn:aws:acm:us-east-1:{acct}:certificate/{uuid.uuid5(NS, name)}")
    cid = uid("cred:" + arn)
    credentials.append(dict(
        id=cid, account_id=acct, region="us-east-1", arn=arn, name=name, credential_type=ctype,
        status="expired" if days_left < 0 else "active", last_used_at=ago(2), created_at_aws=ago(365),
        rotation_enabled=ctype == "secret", rotation_interval_days=30 if ctype == "secret" else None,
        max_session_duration=None, privilege_level="high", attached_policies=[], trust_policy=None,
        permission_boundary_arn=None, owner_principal_arn=owner_arn,
        expires_at=f"now() + interval '{days_left} days'", last_rotated_at=ago(40)))

# ── Permissions granted and used ────────────────────────────────────────────
SERVICES = {
    "AdministratorAccess": ["iam:*", "s3:*", "ec2:*", "sts:AssumeRole", "kms:Decrypt", "secretsmanager:GetSecretValue"],
    "AmazonS3FullAccess": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"],
    "AmazonDynamoDBFullAccess": ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:Query", "dynamodb:DeleteItem"],
}
for c in credentials:
    if c["credential_type"] not in ("iam_role", "iam_user"):
        continue
    actions = []
    for p in c["attached_policies"]:
        actions += SERVICES.get(p["policy_name"], [p["policy_name"].lower() + ":Read*"])
    granted = {"admin": 412, "high": 120, "medium": 46, "low": 18}.get(c["privilege_level"], 20)
    perms[c["id"]] = (granted, actions)
    for j, act in enumerate(actions[: max(1, len(actions) // 2)]):
        usage.append((c["id"], act, act.split(":")[0], True, 30 + j * 11, 1 + j))

# ── Resources ───────────────────────────────────────────────────────────────
resources = [
    (f"arn:aws:s3:::acme-payments-ledger", "acme-payments-ledger", "s3_bucket", A1, "us-east-1"),
    (f"arn:aws:s3:::acme-data-lake", "acme-data-lake", "s3_bucket", A2, "us-east-1"),
    (f"arn:aws:dynamodb:us-east-1:{A1}:table/orders", "orders", "dynamodb_table", A1, "us-east-1"),
    (f"arn:aws:kms:us-east-1:{A1}:key/1a2b3c4d", "payments-cmk", "kms_key", A1, "us-east-1"),
]

# ── Emit ────────────────────────────────────────────────────────────────────
icols = ["id", "account_id", "region", "arn", "name", "identity_type", "functional_class", "category", "environment",
         "owner", "status", "is_publicly_accessible", "created_at_aws", "first_seen_at", "last_seen_at",
         "last_activity_at", "type_attributes", "cloudtrail_creator_arn", "discovery_source"]
TIME = {"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "last_used_at", "expires_at", "last_rotated_at"}
for i in identities:
    vals = [(i[c] if (c in TIME and i[c] is not None) else q(i[c])) for c in icols]
    w(f"INSERT INTO tenant_a.identities ({', '.join(icols)}) VALUES ({', '.join(vals)});")
ccols = ["id", "account_id", "region", "arn", "name", "credential_type", "status", "last_used_at", "created_at_aws",
         "rotation_enabled", "max_session_duration", "privilege_level", "attached_policies", "trust_policy",
         "permission_boundary_arn", "owner_principal_arn", "expires_at", "last_rotated_at"]
# The discovery API scans credentials.privilege_level into an int
# (credential_detail_repo.go), so it is stored as a numeric level here.
PRIV_LEVEL = {"admin": "4", "high": "3", "medium": "2", "low": "1"}
for c in credentials:
    c = {**c, "privilege_level": PRIV_LEVEL.get(c.get("privilege_level"), c.get("privilege_level"))}
    vals = [(c[k] if (k in TIME and c.get(k) is not None) else q(c.get(k))) for k in ccols]
    w(f"INSERT INTO tenant_a.credentials ({', '.join(ccols)}, rotation_interval_days, first_seen_at, last_seen_at) VALUES ({', '.join(vals)}, {q(c.get('rotation_interval_days'))}, now() - interval '100 days', now() - interval '2 hours');")
for iid, cid, btype in bindings:
    w(f"INSERT INTO tenant_a.identity_credentials (identity_id, credential_id, binding_type, binding_source, is_primary) VALUES ({q(iid)}, {q(cid)}, {q(btype)}, 'aws_api', true);")
for cid, (granted, actions) in perms.items():
    # Objects, as identity_detail_repo.go / credential_detail_repo.go read them.
    entries = [{"service": a.split(":")[0], "action": a, "resource_arn": "*", "effect": "Allow",
                "policy_source": "attached", "policy_type": "managed"} for a in actions]
    w(f"INSERT INTO tenant_a.effective_permissions (credential_id, granted_count, permissions) VALUES ({q(cid)}, {granted}, {q(entries)});")
for cid, act, svc, used, count, last in usage:
    w(f"INSERT INTO tenant_a.permission_usage (credential_id, usage_count_90d, action, service, event_count, used, last_used_at) VALUES ({q(cid)}, {count}, {q(act)}, {q(svc)}, {count}, {q(used)}, {ago(last)});")
for s, t, typ in edges:
    w(f"INSERT INTO tenant_a.trust_edges (source_arn, target_arn, edge_type) VALUES ({q(s)}, {q(t)}, {q(typ)});")
for arn, name, rtype, acct, region in resources:
    w(f"INSERT INTO tenant_a.resources (arn, name, resource_type, account_id, region) VALUES ({q(arn)}, {q(name)}, {q(rtype)}, {q(acct)}, {q(region)});")
w("COMMIT;")
print("\n".join(out))
