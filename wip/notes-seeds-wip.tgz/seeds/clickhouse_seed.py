#!/usr/bin/env python3
"""CloudTrail-like events for tenant_a identities, in ClickHouse.

Creates nhi_events.cloudtrail_events (read by MAIN and POSTURE, see
internal/repository/clickhouse/*.go in either backend) and fills it with
~4-5k events over the last 90 days for the identities written by
inventory_seed.py. Identity ARNs, role ARNs and access key ids are derived the
same way inventory_seed.py derives them (uuid5 namespace below), so the events
resolve to the Postgres inventory.

Idempotent: the table is dropped and recreated on every run. Times are
relative to the moment the script runs.

Usage:  python3 clickhouse_seed.py            # (re)create + insert over HTTP :8123
        python3 clickhouse_seed.py --sql-only # only write clickhouse_seed.sql
Env:    CH_URL (default http://127.0.0.1:8123), CH_DB (default nhi_events)
"""
import datetime as dt
import json
import os
import random
import sys
import urllib.request
import uuid

random.seed(42)
NS = uuid.UUID("6f1f7a10-0000-4000-8000-000000000001")  # same as inventory_seed.py
A1, A2 = "111111111111", "222222222222"
CH_URL = os.environ.get("CH_URL", "http://127.0.0.1:8123")
DB = os.environ.get("CH_DB", "nhi_events")
TABLE = "cloudtrail_events"
NOW = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
HERE = os.path.dirname(os.path.abspath(__file__))

DDL = f"""
CREATE TABLE {DB}.{TABLE}
(
    event_id            String,
    event_time          DateTime64(3, 'UTC'),
    account_id          LowCardinality(String),
    aws_region          LowCardinality(String),
    event_source        LowCardinality(String),
    event_name          LowCardinality(String),
    event_type          LowCardinality(String) DEFAULT 'AwsApiCall',
    caller_arn          String,
    session_issuer_arn  String,
    access_key_id       String,
    caller_type         LowCardinality(String),
    source_ip           String,
    user_agent          String,
    error_code          LowCardinality(String),
    error_message       String,
    resource_arn        String,
    resource_type       LowCardinality(String),
    resources           String,   -- CloudTrail "resources" array as JSON (not read by the API)
    is_read_only        UInt8,
    request_parameters  String
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(event_time)
ORDER BY (account_id, event_time, event_id)
"""

# ── identities (mirrors inventory_seed.py) ──────────────────────────────────

def akid(name, k):
    return f"AKIA{uuid.uuid5(NS, name + str(k)).hex[:16].upper()}"


def role(acct, name):
    return f"arn:aws:iam::{acct}:role/{name}"


ECS_TASK = lambda name: uuid.uuid5(NS, name).hex[:24]  # noqa: E731

DDB = lambda acct, t, r="us-east-1": (f"arn:aws:dynamodb:{r}:{acct}:table/{t}", "AWS::DynamoDB::Table")  # noqa: E731
S3 = lambda b: (f"arn:aws:s3:::{b}", "AWS::S3::Bucket")  # noqa: E731
S3O = lambda b, k: (f"arn:aws:s3:::{b}/{k}", "AWS::S3::Object")  # noqa: E731
KMS = (f"arn:aws:kms:us-east-1:{A1}:key/1a2b3c4d", "AWS::KMS::Key")
SEC_DB = (f"arn:aws:secretsmanager:us-east-1:{A1}:secret:prod/db/password-Ab12Cd", "AWS::SecretsManager::Secret")
SEC_STRIPE = (f"arn:aws:secretsmanager:us-east-1:{A1}:secret:prod/stripe/api-key-Ab12Cd", "AWS::SecretsManager::Secret")
SEC_ANALYTICS = (f"arn:aws:secretsmanager:us-east-1:{A2}:secret:analytics/token-Ab12Cd", "AWS::SecretsManager::Secret")
ROLE = lambda acct, n: (role(acct, n), "AWS::IAM::Role")  # noqa: E731
NONE = ("", "")

UA = {
    "go": "aws-sdk-go-v2/1.30.3 os/linux lang/go#1.22.5 md/GOOS#linux md/GOARCH#amd64",
    "py": "Boto3/1.34.84 md/Botocore#1.34.84 ua/2.0 os/linux#5.10.219 md/arch#x86_64 lang/python#3.12.3 exec-env/AWS_Lambda_python3.12",
    "java": "aws-sdk-java/2.25.40 Linux/5.10.215 OpenJDK_64-Bit_Server_VM/21.0.3 Java/21.0.3 vendor/Amazon.com_Inc. exec-env/AWS_ECS_FARGATE",
    "cli": "aws-cli/2.15.30 Python/3.11.8 Linux/6.5.0-1017-azure exe/x86_64.ubuntu.22 prompt/off command/sts.assume-role",
    "tf": "APN/1.0 HashiCorp/1.0 Terraform/1.8.2 (+https://www.terraform.io) terraform-provider-aws/5.46.0 aws-sdk-go-v2/1.26.1",
    "dd": "datadog-agent/7.52.0 aws-sdk-go/1.51.21 (go1.21.9; linux; amd64)",
    "glue": "aws-sdk-java/1.12.701 Linux/5.10 OpenJDK_64-Bit_Server_VM/17 java/17 scala/2.12 vendor/Amazon.com_Inc. exec-env/AWS_Glue",
    "jenkins": "aws-cli/2.13.2 Python/3.11.4 Linux/5.15.0 exe/x86_64.ubuntu.22 prompt/off command/ecr.get-login-password jenkins/2.440",
    "states": "states.amazonaws.com",
    "codebuild": "aws-cli/2.15.30 Python/3.11.8 Linux/4.14.336 exec-env/AWS_ECS_EC2 exe/x86_64.amzn.2 codebuild",
    "console": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
}


def op(src, name, res=NONE, ro=None, w=1.0, err=None, err_rate=0.0, region=None):
    if ro is None:
        ro = name.startswith(("Get", "List", "Describe", "Query", "Scan", "BatchGet", "Head", "Lookup", "Search", "Select"))
    return dict(src=src + ".amazonaws.com", name=name, res=res, ro=ro, w=w, err=err, err_rate=err_rate, region=region)


ACCESS_DENIED = ("AccessDenied", "User: {caller} is not authorized to perform: {action} on resource: {resource} because no identity-based policy allows the {action} action")

# Profile: identity name -> how it behaves.
#   kind: lambda | ec2 | ecs | states | glue | codebuild | role | user
#   rate: mean events per active day; hours: "biz" | "flat" | "night"
P = {}


def prof(name, acct, region, kind, last, rate, hours, ua, ips, ops, **kw):
    P[name] = dict(name=name, acct=acct, region=region, kind=kind, last=last, rate=rate, hours=hours,
                   ua=ua, ips=ips, ops=ops, **kw)


VPC1 = ["10.0.1.23", "10.0.1.57", "10.0.2.14", "10.0.3.201"]
VPC1E = ["10.10.4.11", "10.10.4.98", "10.10.5.37"]
VPC2 = ["10.20.1.8", "10.20.1.44", "10.20.2.130"]
VPC2A = ["10.30.0.15", "10.30.0.77"]
GHA = ["140.82.112.21", "4.175.114.51", "20.42.73.108"]
OFFICE = ["203.0.113.24", "203.0.113.25"]
DATADOG = ["3.233.146.12", "3.233.146.87", "44.192.28.40"]
TOR = "185.220.101.47"

# Lambda functions
prof("payments-api", A1, "us-east-1", "lambda", 0, 6.0, "biz", "py", VPC1, [
    op("dynamodb", "GetItem", DDB(A1, "orders"), w=5), op("dynamodb", "PutItem", DDB(A1, "orders"), w=3),
    op("dynamodb", "Query", DDB(A1, "payments"), w=3), op("dynamodb", "UpdateItem", DDB(A1, "payments"), w=2,
                                                          err="ConditionalCheckFailedException", err_rate=0.04),
    op("kms", "Decrypt", KMS, w=2), op("secretsmanager", "GetSecretValue", SEC_STRIPE, w=1),
    op("logs", "PutLogEvents", (f"arn:aws:logs:us-east-1:{A1}:log-group:/aws/lambda/payments-api", "AWS::Logs::LogGroup"), w=1)])
prof("payments-refunds", A1, "us-east-1", "lambda", 1, 3.0, "biz", "py", VPC1, [
    op("dynamodb", "GetItem", DDB(A1, "payments"), w=3), op("dynamodb", "PutItem", DDB(A1, "refunds"), w=2,
                                                         err="ConditionalCheckFailedException", err_rate=0.05),
    op("sqs", "SendMessage", (f"arn:aws:sqs:us-east-1:{A1}:refund-events", "AWS::SQS::Queue"), w=2),
    op("sqs", "ReceiveMessage", (f"arn:aws:sqs:us-east-1:{A1}:refund-requests", "AWS::SQS::Queue"), w=2, ro=True),
    op("kms", "Decrypt", KMS, w=1)])
prof("order-events", A1, "eu-west-1", "lambda", 0, 4.0, "flat", "go", VPC1E, [
    op("kinesis", "PutRecords", (f"arn:aws:kinesis:eu-west-1:{A1}:stream/order-events", "AWS::Kinesis::Stream"), w=5),
    op("kinesis", "DescribeStreamSummary", (f"arn:aws:kinesis:eu-west-1:{A1}:stream/order-events", "AWS::Kinesis::Stream"), w=1),
    op("kinesis", "PutRecord", (f"arn:aws:kinesis:eu-west-1:{A1}:stream/order-audit", "AWS::Kinesis::Stream"), w=1,
       err="ProvisionedThroughputExceededException", err_rate=0.06)])
prof("thumbnailer", A1, "us-east-1", "lambda", 2, 2.5, "biz", "py", VPC1, [
    op("s3", "GetObject", S3O("acme-uploads", "incoming/"), w=4), op("s3", "PutObject", S3O("acme-thumbnails", "thumbs/"), w=4),
    op("s3", "ListBuckets", NONE, w=0.3), op("iam", "ListRoles", NONE, w=0.2, region="us-east-1"),
    op("ec2", "DescribeRegions", NONE, w=0.2)])
prof("report-builder", A2, "ap-south-1", "lambda", 3, 1.5, "night", "py", VPC2A, [
    op("s3", "GetObject", S3O("acme-data-lake", "curated/"), w=4), op("s3", "ListObjectsV2", S3("acme-data-lake"), w=2),
    op("s3", "PutObject", S3O("acme-reports", "daily/"), w=1, err="AccessDenied", err_rate=0.5),
    op("secretsmanager", "GetSecretValue", SEC_ANALYTICS, w=1, region="us-east-1")])
prof("ledger-sync", A2, "us-east-1", "lambda", 0, 3.0, "flat", "py", VPC2, [
    op("rds-data", "ExecuteStatement", (f"arn:aws:rds:us-east-1:{A2}:cluster:ledger-db", "AWS::RDS::DBCluster"), w=5, ro=False),
    op("rds", "DescribeDBClusters", (f"arn:aws:rds:us-east-1:{A2}:cluster:ledger-db", "AWS::RDS::DBCluster"), w=1),
    op("secretsmanager", "GetSecretValue", SEC_DB, w=2),  # cross-account secret in 111111111111
    op("dynamodb", "Query", DDB(A1, "payments"), w=1, err="AccessDeniedException", err_rate=0.3)])  # cross-account table
prof("email-sender", A1, "eu-west-1", "lambda", 6, 1.5, "biz", "py", VPC1E, [
    op("ses", "SendEmail", (f"arn:aws:ses:eu-west-1:{A1}:identity/acme.com", "AWS::SES::EmailIdentity"), w=5, ro=False),
    op("ses", "SendTemplatedEmail", (f"arn:aws:ses:eu-west-1:{A1}:identity/acme.com", "AWS::SES::EmailIdentity"), w=2, ro=False,
       err="Throttling", err_rate=0.05)])
prof("fraud-score", A2, "ap-south-1", "lambda", 0, 4.0, "flat", "py", VPC2A, [
    op("sagemaker", "InvokeEndpoint", (f"arn:aws:sagemaker:ap-south-1:{A2}:endpoint/fraud-xgb-v7", "AWS::SageMaker::Endpoint"), w=6, ro=False),
    op("sts", "AssumeRole", ROLE(A2, "audit-reader"), w=0.5, ro=True),
    op("s3", "GetObject", S3O("acme-ml-models", "fraud/"), w=0.5)])
prof("feature-flags", A1, "us-east-1", "lambda", 45, 1.5, "biz", "go", VPC1, [
    op("ssm", "GetParameter", (f"arn:aws:ssm:us-east-1:{A1}:parameter/flags/checkout", "AWS::SSM::Parameter"), w=4),
    op("ssm", "GetParametersByPath", (f"arn:aws:ssm:us-east-1:{A1}:parameter/flags", "AWS::SSM::Parameter"), w=1)])
# EC2 instances
prof("web-1", A1, "us-east-1", "ec2", 0, 2.0, "flat", "go", ["10.0.1.23"], [
    op("s3", "GetObject", S3O("acme-static-assets", "web/"), w=5), op("ssm", "UpdateInstanceInformation", NONE, w=2, ro=False),
    op("ec2messages", "GetMessages", NONE, w=1)])
prof("web-2", A1, "us-east-1", "ec2", 0, 2.0, "flat", "go", ["10.0.1.57"], [
    op("s3", "GetObject", S3O("acme-static-assets", "web/"), w=5), op("ssm", "UpdateInstanceInformation", NONE, w=2, ro=False),
    op("ec2messages", "GetMessages", NONE, w=1)])
prof("bastion", A1, "us-east-1", "ec2", 1, 1.5, "biz", "cli", ["10.0.0.10", "10.0.0.10", "198.51.100.77"], [
    op("ec2", "DescribeInstances", NONE, w=3), op("ssm", "StartSession", NONE, w=1, ro=False),
    op("sts", "AssumeRole", ROLE(A1, "break-glass"), w=0.6, ro=True, err="AccessDenied", err_rate=1.0),
    op("iam", "ListUsers", NONE, w=0.5, region="us-east-1"), op("iam", "GetAccountAuthorizationDetails", NONE, w=0.2, region="us-east-1")])
prof("batch-runner", A2, "us-east-1", "ec2", 2, 2.5, "night", "py", ["10.20.2.130"], [
    op("s3", "GetObject", S3O("acme-data-lake", "raw/"), w=3), op("s3", "PutObject", S3O("acme-data-lake", "staged/"), w=3),
    op("s3", "DeleteObject", S3O("acme-data-lake", "tmp/"), w=1)])
prof("jenkins", A1, "eu-west-1", "ec2", 0, 3.0, "biz", "jenkins", ["10.10.4.11", "34.240.12.88"], [
    op("ecr", "GetAuthorizationToken", NONE, w=3), op("ecr", "PutImage", (f"arn:aws:ecr:eu-west-1:{A1}:repository/checkout", "AWS::ECR::Repository"), w=2, ro=False),
    op("sts", "AssumeRole", ROLE(A1, "deploy-role"), w=2, ro=True),
    op("s3", "PutObject", S3O("acme-build-artifacts", "jenkins/"), w=2),
    op("iam", "CreateAccessKey", (f"arn:aws:iam::{A1}:user/terraform-bot", "AWS::IAM::User"), w=0.1, region="us-east-1",
       err="AccessDenied", err_rate=1.0)])
prof("vpn-gw", A1, "us-east-1", "ec2", 0, 1.0, "flat", "go", ["10.0.0.5"], [
    op("ec2", "DescribeNetworkInterfaces", NONE, w=3), op("ec2", "DescribeRouteTables", NONE, w=1),
    op("cloudwatch", "PutMetricData", NONE, w=2, ro=False)])
# ECS tasks
for n, rate in [("checkout", 6.0), ("checkout-2", 5.0)]:
    prof(n, A1, "us-east-1", "ecs", 0, rate, "biz", "java", VPC1, [
        op("dynamodb", "GetItem", DDB(A1, "orders"), w=4), op("dynamodb", "PutItem", DDB(A1, "orders"), w=3),
        op("dynamodb", "TransactWriteItems", DDB(A1, "payments"), w=1, ro=False, err="TransactionCanceledException", err_rate=0.03),
        op("kms", "GenerateDataKey", KMS, w=1, ro=True)], cluster="prod-cluster")
prof("search", A1, "us-east-1", "ecs", 0, 3.0, "biz", "java", VPC1, [
    op("es", "ESHttpGet", (f"arn:aws:es:us-east-1:{A1}:domain/catalog", "AWS::OpenSearchService::Domain"), w=5, ro=True),
    op("es", "ESHttpPost", (f"arn:aws:es:us-east-1:{A1}:domain/catalog", "AWS::OpenSearchService::Domain"), w=2, ro=False),
    op("es", "DeleteDomain", (f"arn:aws:es:us-east-1:{A1}:domain/catalog-old", "AWS::OpenSearchService::Domain"), w=0.05)],
    cluster="prod-cluster")
prof("recommender", A2, "ap-south-1", "ecs", 1, 2.0, "flat", "py", VPC2A, [
    op("s3", "GetObject", S3O("acme-ml-models", "recs/"), w=4), op("s3", "ListObjectsV2", S3("acme-ml-models"), w=1)], cluster="ml-cluster")
prof("inventory", A1, "eu-west-1", "ecs", 0, 2.0, "biz", "java", VPC1E, [
    op("rds", "DescribeDBInstances", (f"arn:aws:rds:eu-west-1:{A1}:db:inventory", "AWS::RDS::DBInstance"), w=2),
    op("rds-db", "connect", (f"arn:aws:rds-db:eu-west-1:{A1}:dbuser:db-INV/app", "AWS::RDS::DBInstance"), w=4, ro=True)], cluster="prod-cluster")
prof("notifier", A1, "eu-west-1", "ecs", 4, 2.0, "biz", "go", VPC1E, [
    op("sns", "Publish", (f"arn:aws:sns:eu-west-1:{A1}:order-updates", "AWS::SNS::Topic"), w=5, ro=False),
    op("sns", "Publish", (f"arn:aws:sns:eu-west-1:{A1}:ops-alerts", "AWS::SNS::Topic"), w=1, ro=False, err="AuthorizationError", err_rate=0.4)],
    cluster="prod-cluster")
prof("etl-loader", A2, "us-east-1", "ecs", 0, 3.0, "night", "py", VPC2, [
    op("s3", "GetObject", S3O("acme-data-lake", "staged/"), w=3), op("redshift-data", "ExecuteStatement",
                                                                  (f"arn:aws:redshift:us-east-1:{A2}:cluster:warehouse", "AWS::Redshift::Cluster"), w=3, ro=False),
    op("sts", "AssumeRole", ROLE(A2, "data-lake-writer"), w=1, ro=True)], cluster="data-cluster")
prof("admin-console", A1, "us-east-1", "ecs", 12, 1.2, "biz", "go", ["10.0.3.201"], [
    op("iam", "ListRoles", NONE, w=3, region="us-east-1"), op("iam", "GetRole", NONE, w=2, region="us-east-1"),
    op("iam", "AttachRolePolicy", ROLE(A1, "notifier-task-role"), w=0.3, region="us-east-1"),
    op("iam", "PutRolePolicy", ROLE(A1, "search-task-role"), w=0.2, region="us-east-1"),
    op("ec2", "DescribeInstances", NONE, w=2), op("ecs", "UpdateService", NONE, w=0.5, ro=False, err="ThrottlingException", err_rate=0.1)],
    cluster="ops-cluster")
# Step Functions, Glue, CodeBuild
prof("order-saga", A1, "us-east-1", "states", 0, 3.0, "biz", "states", ["states.amazonaws.com"], [
    op("lambda", "Invoke", (f"arn:aws:lambda:us-east-1:{A1}:function:payments-api", "AWS::Lambda::Function"), w=4, ro=False),
    op("lambda", "Invoke", (f"arn:aws:lambda:us-east-1:{A1}:function:payments-refunds", "AWS::Lambda::Function"), w=1, ro=False,
       err="TooManyRequestsException", err_rate=0.05)])
prof("refund-flow", A1, "eu-west-1", "states", 3, 1.0, "biz", "states", ["states.amazonaws.com"], [
    op("lambda", "Invoke", (f"arn:aws:lambda:us-east-1:{A1}:function:payments-refunds", "AWS::Lambda::Function"), w=3, ro=False),
    op("sqs", "SendMessage", (f"arn:aws:sqs:eu-west-1:{A1}:refund-dlq", "AWS::SQS::Queue"), w=1)])
prof("nightly-etl", A2, "us-east-1", "glue", 0, 4.0, "night", "glue", ["10.20.1.8", "10.20.1.44"], [
    op("glue", "GetTable", (f"arn:aws:glue:us-east-1:{A2}:table/lake/events", "AWS::Glue::Table"), w=2),
    op("s3", "GetObject", S3O("acme-data-lake", "raw/"), w=4), op("s3", "PutObject", S3O("acme-data-lake", "curated/"), w=3),
    op("sts", "AssumeRole", ROLE(A2, "data-lake-writer"), w=1, ro=True),
    op("glue", "BatchCreatePartition", (f"arn:aws:glue:us-east-1:{A2}:table/lake/events", "AWS::Glue::Table"), w=1, ro=False,
       err="AlreadyExistsException", err_rate=0.15)])
prof("pii-scrub", A2, "ap-south-1", "glue", 1, 1.5, "night", "glue", ["10.30.0.15"], [
    op("glue", "GetTable", (f"arn:aws:glue:ap-south-1:{A2}:table/pii/customers", "AWS::Glue::Table"), w=2),
    op("s3", "GetObject", S3O("acme-pii-raw", "customers/"), w=3), op("s3", "PutObject", S3O("acme-pii-masked", "customers/"), w=3)])
prof("app-build", A1, "us-east-1", "codebuild", 0, 4.0, "biz", "codebuild", ["10.0.9.12", "10.0.9.40"], [
    op("ecr", "GetAuthorizationToken", NONE, w=2), op("ecr", "PutImage", (f"arn:aws:ecr:us-east-1:{A1}:repository/payments-api", "AWS::ECR::Repository"), w=2, ro=False),
    op("s3", "PutObject", S3O("acme-build-artifacts", "app-build/"), w=2),
    op("sts", "AssumeRole", ROLE(A1, "deploy-role"), w=2, ro=True),
    op("iam", "PassRole", ROLE(A1, "payments-api-role"), w=0.3, region="us-east-1", ro=False),
    op("iam", "CreateRole", (f"arn:aws:iam::{A1}:role/tmp-build-role", "AWS::IAM::Role"), w=0.05, region="us-east-1")])
prof("infra-plan", A1, "us-east-1", "codebuild", 2, 3.0, "biz", "tf", ["10.0.9.12"], [
    op("sts", "AssumeRole", ROLE(A1, "deploy-role"), w=1, ro=True), op("iam", "GetRole", NONE, w=2, region="us-east-1"),
    op("ec2", "DescribeVpcs", NONE, w=2), op("ec2", "DescribeSecurityGroups", NONE, w=2),
    op("s3", "GetObject", S3O("acme-terraform-state", "prod/terraform.tfstate"), w=2),
    op("dynamodb", "PutItem", DDB(A1, "terraform-locks"), w=1)])
# IAM roles assumed by other roles. sessions: (session name, weight)
prof("deploy-role", A1, "us-east-1", "role", 0, 5.0, "biz", "cli", ["10.0.9.12", "10.10.4.11"] + GHA, [
    op("lambda", "UpdateFunctionCode", (f"arn:aws:lambda:us-east-1:{A1}:function:payments-api", "AWS::Lambda::Function"), w=2),
    op("ecs", "UpdateService", (f"arn:aws:ecs:us-east-1:{A1}:service/prod-cluster/checkout", "AWS::ECS::Service"), w=2),
    op("ecs", "RunTask", (f"arn:aws:ecs:us-east-1:{A1}:task-definition/checkout:42", "AWS::ECS::TaskDefinition"), w=1),
    op("cloudformation", "UpdateStack", (f"arn:aws:cloudformation:us-east-1:{A1}:stack/payments/1a2b", "AWS::CloudFormation::Stack"), w=1),
    op("iam", "PassRole", ROLE(A1, "checkout-task-role"), w=1, region="us-east-1", ro=False),
    op("sts", "AssumeRole", ROLE(A2, "cross-account-admin"), w=1, ro=True),  # cross-account 111 -> 222
    op("s3", "GetObject", S3O("acme-build-artifacts", "releases/"), w=2)],
    sessions=[("codebuild-app-build", 3), ("codebuild-infra-plan", 2), ("jenkins-deploy", 2), ("gha-ci-deployer", 2)])
prof("cross-account-admin", A2, "us-east-1", "role", 5, 1.2, "biz", "cli", ["10.0.9.12", "140.82.112.21"], [
    op("iam", "ListRoles", NONE, w=2, region="us-east-1"), op("ec2", "DescribeInstances", NONE, w=2),
    op("lambda", "UpdateFunctionCode", (f"arn:aws:lambda:us-east-1:{A2}:function:ledger-sync", "AWS::Lambda::Function"), w=1),
    op("iam", "UpdateAssumeRolePolicy", ROLE(A2, "data-lake-writer"), w=0.15, region="us-east-1"),
    op("s3", "PutBucketPolicy", S3("acme-data-lake"), w=0.1, ro=False)],
    sessions=[("deploy-role-xacct", 1)])
prof("audit-reader", A2, "us-east-1", "role", 1, 2.0, "flat", "dd", DATADOG + ["10.30.0.77"], [
    op("config", "DescribeConfigRules", NONE, w=2), op("iam", "GetAccountAuthorizationDetails", NONE, w=1, region="us-east-1"),
    op("securityhub", "GetFindings", NONE, w=2), op("iam", "ListPolicies", NONE, w=1, region="us-east-1")],
    sessions=[("fraud-score-audit", 1), ("terraform-audit", 1)])
prof("data-lake-writer", A2, "us-east-1", "role", 0, 3.0, "night", "py", VPC2, [
    op("s3", "PutObject", S3O("acme-data-lake", "curated/"), w=4), op("s3", "DeleteObject", S3O("acme-data-lake", "staged/"), w=1),
    op("s3", "GetBucketLocation", S3("acme-data-lake"), w=1), op("lakeformation", "GetDataAccess", NONE, w=1, ro=True)],
    sessions=[("GlueJobRunnerSession", 1), ("etl-loader", 1)])
# IAM users
prof("ci-deployer", A1, "us-east-1", "user", 0, 4.0, "biz", "cli", GHA, [
    op("sts", "AssumeRole", ROLE(A1, "deploy-role"), w=3, ro=True), op("sts", "GetCallerIdentity", NONE, w=2, ro=True),
    op("ecr", "GetAuthorizationToken", NONE, w=2), op("s3", "PutObject", S3O("acme-build-artifacts", "gha/"), w=2),
    op("lambda", "UpdateFunctionConfiguration", (f"arn:aws:lambda:us-east-1:{A1}:function:payments-api", "AWS::Lambda::Function"), w=0.5)],
    key=akid("ci-deployer", 0))
prof("terraform-bot", A1, "us-east-1", "user", 1, 3.0, "biz", "tf", OFFICE + ["10.0.9.12"], [
    op("iam", "GetRole", NONE, w=2, region="us-east-1"), op("iam", "ListAttachedRolePolicies", NONE, w=2, region="us-east-1"),
    op("ec2", "DescribeInstances", NONE, w=2), op("s3", "GetObject", S3O("acme-terraform-state", "prod/terraform.tfstate"), w=1),
    op("sts", "AssumeRole", ROLE(A2, "audit-reader"), w=0.7, ro=True),  # cross-account 111 -> 222
    op("organizations", "DescribeOrganization", NONE, w=0.5, region="us-east-1", err="AccessDeniedException", err_rate=1.0),
    op("iam", "CreatePolicyVersion", (f"arn:aws:iam::{A1}:policy/deploy-boundary", "AWS::IAM::Policy"), w=0.2, region="us-east-1")],
    key=akid("terraform-bot", 0))
prof("datadog-integration", A2, "us-east-1", "user", 0, 4.0, "flat", "dd", DATADOG, [
    op("monitoring", "GetMetricData", NONE, w=5), op("tagging", "GetResources", NONE, w=2),
    op("ec2", "DescribeInstances", NONE, w=1), op("logs", "DescribeLogGroups", NONE, w=1),
    op("cloudtrail", "LookupEvents", NONE, w=0.3, err="ThrottlingException", err_rate=0.3)],
    key=akid("datadog-integration", 0))
# Stale identities (legacy-cron 210d, old-worker 300d, analytics-1 95d, backup-agent 140d,
# break-glass never) deliberately get no events in the 90-day window.

ROLE_NAME = {"lambda": "{n}-role", "ec2": "{n}-profile", "ecs": "{n}-task-role", "states": "{n}-role",
             "glue": "{n}-role", "codebuild": "{n}-role"}
EC2_ID = {"web-1": "i-00web1a1b2c3", "web-2": "i-01web2a1b2c3", "bastion": "i-02bastioa1b2c3",
          "batch-runner": "i-03batchra1b2c3", "jenkins": "i-04jenkina1b2c3", "vpn-gw": "i-06vpngwa1b2c3"}

HOURS = {
    "biz": [1, 1, 1, 1, 1, 1, 2, 4, 8, 10, 10, 10, 9, 10, 10, 10, 9, 7, 4, 2, 2, 1, 1, 1],
    "flat": [5, 4, 4, 4, 4, 5, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 7, 6, 6, 5, 5],
    "night": [10, 10, 10, 10, 6, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 4, 8],
}


def caller_for(p, day):
    """(caller_arn, session_issuer_arn, access_key_id, caller_type) for one call."""
    n, a, kind = p["name"], p["acct"], p["kind"]
    if kind == "user":
        return f"arn:aws:iam::{a}:user/{n}", "", p["key"], "IAMUser"
    if kind == "role":
        rname = n
        sess = random.choices([s for s, _ in p["sessions"]], [w for _, w in p["sessions"]])[0]
        sess = f"{sess}-{day:02d}{random.randint(10, 99)}"
    else:
        rname = ROLE_NAME[kind].format(n=n)
        if kind == "lambda":
            sess = n
        elif kind == "ec2":
            sess = EC2_ID[n]
        elif kind == "ecs":
            sess = ECS_TASK(n)
        elif kind == "glue":
            sess = "GlueJobRunnerSession"
        elif kind == "codebuild":
            sess = f"AWSCodeBuild-{uuid.UUID(int=random.getrandbits(128)).hex[:8]}"
        else:
            sess = f"{n}-execution-{random.randint(1000, 9999)}"
    temp = "ASIA" + uuid.UUID(int=random.getrandbits(128)).hex[:16].upper()
    return f"arn:aws:sts::{a}:assumed-role/{rname}/{sess}", role(a, rname), temp, "AssumedRole"


def pick_time(p, days_ago):
    weights = HOURS[p["hours"]]
    base = (NOW - dt.timedelta(days=days_ago)).date()
    for _ in range(20):
        h = random.choices(range(24), weights)[0]
        t = dt.datetime(base.year, base.month, base.day, h, random.randint(0, 59), random.randint(0, 59),
                        random.randint(0, 999) * 1000, tzinfo=dt.timezone.utc)
        if t <= NOW - dt.timedelta(minutes=5):
            return t
    return NOW - dt.timedelta(minutes=random.randint(10, 300))


def make_event(p, o, t, ip=None):
    caller, issuer, key, ctype = caller_for(p, t.day)
    region = o["region"] or (p["region"] if p["region"] != "global" else "us-east-1")
    res_arn, res_type = o["res"]
    if res_arn.endswith("/"):  # object prefix -> concrete object
        res_arn += f"part-{random.randint(0, 40):05d}.parquet" if "lake" in res_arn else f"obj-{random.randint(0, 25):04d}"
    err_code = err_msg = ""
    if o["err"] and random.random() < o["err_rate"]:
        err_code = o["err"]
        action = f"{o['src'].split('.')[0]}:{o['name']}"
        err_msg = ACCESS_DENIED[1].format(caller=caller, action=action, resource=res_arn or "*") \
            if "Denied" in err_code else f"{err_code}: request could not be completed"
    ip = ip or random.choice(p["ips"])
    ua = UA[p["ua"]]
    if p["kind"] == "states":
        ip, ua = "states.amazonaws.com", "states.amazonaws.com"
    req = {}
    if o["name"] == "AssumeRole":
        req = {"roleArn": res_arn, "roleSessionName": f"{p['name']}-session"}
    elif res_arn.startswith("arn:aws:s3:::"):
        bucket, _, key_name = res_arn[len("arn:aws:s3:::"):].partition("/")
        req = {"bucketName": bucket, **({"key": key_name} if key_name else {})}
    acct = p["acct"]
    return dict(
        event_id=str(uuid.UUID(int=random.getrandbits(128), version=4)),
        event_time=t.strftime("%Y-%m-%d %H:%M:%S.") + f"{t.microsecond // 1000:03d}",
        account_id=acct, aws_region=region, event_source=o["src"], event_name=o["name"],
        caller_arn=caller, session_issuer_arn=issuer, access_key_id=key, caller_type=ctype,
        source_ip=ip, user_agent=ua, error_code=err_code, error_message=err_msg,
        resource_arn=res_arn, resource_type=res_type,
        resources=json.dumps([{"ARN": res_arn, "type": res_type, "accountId": acct}]) if res_arn else "[]",
        is_read_only=1 if o["ro"] else 0, request_parameters=json.dumps(req))


def generate():
    rows = []
    for p in P.values():
        last = p["last"]
        for d in range(last, 90):
            mult = 0.45 if (NOW - dt.timedelta(days=d)).weekday() >= 5 and p["hours"] == "biz" else 1.0
            lam = p["rate"] * mult
            # poisson-ish
            n = sum(1 for _ in range(int(lam * 3) + 1) if random.random() < lam / (int(lam * 3) + 1))
            if d == last:
                n = max(n, 2)
            for _ in range(n):
                o = random.choices(p["ops"], [x["w"] for x in p["ops"]])[0]
                rows.append(make_event(p, o, pick_time(p, d)))
        # make sure the most recent event lands where the inventory says it does
        t = NOW - dt.timedelta(days=last, hours=random.randint(1, 4)) if last else NOW - dt.timedelta(minutes=random.randint(20, 150))
        rows.append(make_event(p, p["ops"][0], t))
    # A suspicious burst: ci-deployer's key used from a Tor exit node, mostly denied (10 days ago).
    p = P["ci-deployer"]
    base = NOW - dt.timedelta(days=10, hours=3)
    for i, (src, name, res) in enumerate([
        ("sts", "GetCallerIdentity", NONE), ("iam", "ListUsers", NONE), ("iam", "CreateUser", (f"arn:aws:iam::{A1}:user/svc-backup2", "AWS::IAM::User")),
        ("iam", "CreateAccessKey", (f"arn:aws:iam::{A1}:user/svc-backup2", "AWS::IAM::User")),
        ("s3", "ListBuckets", NONE), ("s3", "GetObject", S3O("acme-payments-ledger", "exports/2026-09.csv")),
        ("secretsmanager", "ListSecrets", NONE), ("ec2", "DescribeRegions", NONE)]):
        o = op(src, name, res, err="AccessDenied", err_rate=0.0 if name in ("GetCallerIdentity", "ListBuckets", "DescribeRegions") else 1.0,
               region="us-east-1")
        rows.append(make_event(p, o, base + dt.timedelta(seconds=37 * i), ip=TOR))
    # Creation events (older than the activity window) so creator lookups work.
    creators = [
        (f"arn:aws:iam::{A1}:user/ci-deployer", "lambda", "CreateFunction", f"arn:aws:lambda:{r}:{a}:function:{n}", "AWS::Lambda::Function", r, a, 300)
        for n, r, a in [("payments-api", "us-east-1", A1), ("payments-refunds", "us-east-1", A1), ("order-events", "eu-west-1", A1),
                        ("thumbnailer", "us-east-1", A1), ("legacy-cron", "us-east-1", A1), ("email-sender", "eu-west-1", A1),
                        ("feature-flags", "us-east-1", A1)]]
    creators += [
        (f"arn:aws:iam::{A1}:user/terraform-bot", "ec2", "RunInstances", f"arn:aws:ec2:us-east-1:{A1}:instance/{EC2_ID[n]}", "AWS::EC2::Instance", "us-east-1", A1, 300)
        for n in ("web-1", "web-2", "bastion", "vpn-gw")]
    creators += [(f"arn:aws:iam::{A1}:user/terraform-bot", "iam", "CreateRole", role(A1, n), "AWS::IAM::Role", "us-east-1", A1, 500)
                 for n in ("deploy-role", "break-glass")]
    for caller, src, name, res, rtype, region, acct, days in creators:
        t = NOW - dt.timedelta(days=days, hours=random.randint(0, 20))
        key = akid("ci-deployer", 0) if "ci-deployer" in caller else akid("terraform-bot", 0)
        rows.append(dict(
            event_id=str(uuid.UUID(int=random.getrandbits(128), version=4)),
            event_time=t.strftime("%Y-%m-%d %H:%M:%S.000"), account_id=acct, aws_region=region,
            event_source=src + ".amazonaws.com", event_name=name, caller_arn=caller, session_issuer_arn="",
            access_key_id=key, caller_type="IAMUser", source_ip=random.choice(GHA + OFFICE), user_agent=UA["tf"],
            error_code="", error_message="", resource_arn=res, resource_type=rtype,
            resources=json.dumps([{"ARN": res, "type": rtype, "accountId": acct}]), is_read_only=0, request_parameters="{}"))
    rows.sort(key=lambda r: r["event_time"])
    return rows


def ch(sql, data=None):
    url = CH_URL + "/?query=" + urllib.parse.quote(sql) if data is not None else CH_URL + "/"
    body = (data if data is not None else sql).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read().decode()


def main():
    import urllib.parse  # noqa: F401
    rows = generate()
    stmts = [f"CREATE DATABASE IF NOT EXISTS {DB}", f"DROP TABLE IF EXISTS {DB}.{TABLE}", DDL.strip()]
    payload = "\n".join(json.dumps(r) for r in rows)
    with open(os.path.join(HERE, "clickhouse_seed.sql"), "w") as f:
        f.write("-- generated by clickhouse_seed.py at %s; re-run the .py to refresh times\n" % NOW.isoformat())
        for s in stmts:
            f.write(s + ";\n")
        f.write(f"INSERT INTO {DB}.{TABLE} FORMAT JSONEachRow\n{payload}\n")
    if "--sql-only" in sys.argv:
        print(f"wrote {len(rows)} events to clickhouse_seed.sql")
        return
    for s in stmts:
        ch(s)
    ch(f"INSERT INTO {DB}.{TABLE} FORMAT JSONEachRow", payload)
    print(ch(f"SELECT count(), min(event_time), max(event_time), uniqExact(session_issuer_arn), countIf(error_code != '') FROM {DB}.{TABLE} FORMAT TSV").strip())


if __name__ == "__main__":
    import urllib.parse  # noqa: F401,E402
    main()
