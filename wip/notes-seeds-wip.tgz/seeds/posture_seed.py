#!/usr/bin/env python3
"""ISPM posture data for tenant_a (POSTURE service, /api/v1/ispm/*).

The posture backend ships no migrations for its ispm_* tables; the DDL below is
derived from the queries in internal/repository/postures/*.go of
main4/x_backend_ispm_posture/nhi-backend (column names, types implied by the
Scan targets, enum values from internal/models/postures and the frontend's
src/lib/posture.js: severities CRITICAL/HIGH/MEDIUM/LOW worth 25/15/8/3
points, bands HEALTHY>=80 / FAIR>=60 / POOR>=40 / CRITICAL, grades A-F).

Scoring model (coherent end to end):
  * 15 rules in 6 pillars; every identity is evaluated on the rules that apply
    to its type; a FAIL loses the rule's penalty points; score = max(0, 100 - lost).
  * every failing check has failing_since; some checks failed in the past and
    were fixed (RESOLVED findings). Scores at any past time are recomputed from
    those intervals, so history, snapshots, daily cache rows and score_change_*
    all agree with each other.

Idempotent: drops and recreates the ispm_* tables in tenant_a (they belong to
this seed only). Reads the inventory (inventory_seed.py) and, when reachable,
ClickHouse AssumeRole events (clickhouse_seed.py) for role-use counts.

Usage: python3 posture_seed.py   (writes posture_seed.sql and applies it)
"""
import datetime as dt
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from seedlib import (A1, A2, ACCOUNT_NAMES, NOW, TENANT, ch_query, load_inventory, psql_file, q,  # noqa: E402
                     text_array, uid)

random.seed(11)
HERE = os.path.dirname(os.path.abspath(__file__))
S = "tenant_a"
SCAN_EVERY_H = 6
SCANS = 90 * 24 // SCAN_EVERY_H  # 360 scans over 90 days
POINTS = {"CRITICAL": 25, "HIGH": 15, "MEDIUM": 8, "LOW": 3}

DDL = f"""
DROP TABLE IF EXISTS {S}.ispm_pillars, {S}.ispm_categories, {S}.ispm_rule_weights, {S}.ispm_scan_history,
  {S}.ispm_identity_posture, {S}.ispm_identity_checks, {S}.ispm_identity_posture_hourly, {S}.ispm_identity_posture_daily,
  {S}.ispm_posture_snapshots, {S}.ispm_nhi_dashboard_cache, {S}.ispm_nhi_findings, {S}.ispm_finding_history,
  {S}.ispm_access_edges, {S}.ispm_role_use CASCADE;

-- Catalog (not tenant-filtered by the API)
CREATE TABLE {S}.ispm_pillars (
  pillar_code text PRIMARY KEY, pillar_name text NOT NULL, description text,
  display_order int NOT NULL DEFAULT 0, enabled boolean NOT NULL DEFAULT true);
CREATE TABLE {S}.ispm_categories (
  category_code text PRIMARY KEY, category_name text NOT NULL,
  pillar_code text NOT NULL REFERENCES {S}.ispm_pillars(pillar_code), enabled boolean NOT NULL DEFAULT true);
CREATE TABLE {S}.ispm_rule_weights (
  rule_id text PRIMARY KEY, rule_name text NOT NULL, check_title text, description text, fix_label text,
  severity text NOT NULL CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW')),
  penalty_points int NOT NULL, category_code text REFERENCES {S}.ispm_categories(category_code),
  applies_to text[], enabled boolean NOT NULL DEFAULT true, updated_at timestamptz NOT NULL DEFAULT now());

CREATE TABLE {S}.ispm_scan_history (
  scan_id uuid PRIMARY KEY, tenant_id uuid NOT NULL,
  status text NOT NULL CHECK (status IN ('RUNNING','COMPLETED','PARTIAL','FAILED')),
  trigger text, started_at timestamptz, completed_at timestamptz,
  identities_scanned int, checks_evaluated int, findings_open int, error_message text);
CREATE INDEX ON {S}.ispm_scan_history (tenant_id, started_at DESC);

CREATE TABLE {S}.ispm_identity_posture (
  tenant_id uuid NOT NULL, identity_id uuid NOT NULL, identity_arn text, identity_name text, identity_type text,
  functional_class text, account_id text, account_name text, region text,
  score numeric(5,1), band text CHECK (band IN ('HEALTHY','FAIR','POOR','CRITICAL')), grade text,
  points_lost numeric(6,1), checks_failed int, checks_evaluated int,
  failed_critical int, failed_high int, failed_medium int, failed_low int,
  weakest_pillar text, credential_type text, credential_age_days int,
  score_change_1d numeric(5,1), score_change_3d numeric(5,1), score_change_7d numeric(5,1),
  score_change_30d numeric(5,1), score_change_60d numeric(5,1), score_change_90d numeric(5,1),
  open_alerts int NOT NULL DEFAULT 0, mfa_enabled boolean, console_access boolean,
  pillar_scores jsonb, why_this_score text, scan_id uuid, computed_at timestamptz,
  PRIMARY KEY (tenant_id, identity_id));
CREATE INDEX ON {S}.ispm_identity_posture (tenant_id, score, identity_id);
CREATE INDEX ON {S}.ispm_identity_posture (tenant_id, identity_arn);

CREATE TABLE {S}.ispm_identity_checks (
  tenant_id uuid NOT NULL, identity_id uuid NOT NULL, rule_id text NOT NULL,
  status text NOT NULL CHECK (status IN ('PASS','FAIL')), severity text, pillar_code text,
  points_lost numeric(6,1) NOT NULL DEFAULT 0, penalty_points int, detail text,
  failing_since timestamptz, finding_id uuid, evaluated_at timestamptz,
  PRIMARY KEY (tenant_id, identity_id, rule_id));
CREATE INDEX ON {S}.ispm_identity_checks (tenant_id, rule_id, status);

CREATE TABLE {S}.ispm_identity_posture_hourly (
  tenant_id uuid NOT NULL, identity_id uuid NOT NULL, captured_at timestamptz NOT NULL, scan_id uuid,
  score numeric(5,1), band text, checks_failed int, PRIMARY KEY (tenant_id, identity_id, captured_at));
CREATE TABLE {S}.ispm_identity_posture_daily (
  tenant_id uuid NOT NULL, identity_id uuid NOT NULL, snapshot_date date NOT NULL,
  score numeric(5,1), band text, checks_failed int, PRIMARY KEY (tenant_id, identity_id, snapshot_date));

CREATE TABLE {S}.ispm_posture_snapshots (
  snapshot_id uuid PRIMARY KEY, tenant_id uuid NOT NULL, scan_id uuid, captured_at timestamptz NOT NULL,
  fleet_score numeric(5,1), identities_scored int,
  band_healthy int, band_fair int, band_poor int, band_critical int);
CREATE INDEX ON {S}.ispm_posture_snapshots (tenant_id, captured_at);

CREATE TABLE {S}.ispm_nhi_dashboard_cache (
  tenant_id uuid NOT NULL, snapshot_date date NOT NULL, computed_at timestamptz NOT NULL, last_scan_id uuid,
  fleet_score numeric(5,1), fleet_grade text, fleet_band text, identities_scored int,
  band_healthy int, band_fair int, band_poor int, band_critical int,
  identities_with jsonb,      -- {{"over_permissioned": n, ...}}
  pillar_summary jsonb,       -- {{"<pillar_code>": {{"score", "evaluated", "failing"}}}}
  quick_wins jsonb,           -- [{{"rule_id", "title", "pillar", "identities", "fleet_gain"}}]
  by_functional_class jsonb,  -- [{{"functional_class", "count", "mean", "change": {{"1d": .., "30d": ..}}}}]
  by_account_mean jsonb,      -- [{{"account", "account_id", "count", "mean", "change": {{...}}}}]
  PRIMARY KEY (tenant_id, snapshot_date));

CREATE TABLE {S}.ispm_nhi_findings (
  finding_id uuid PRIMARY KEY, tenant_id uuid NOT NULL, identity_id uuid, identity_arn text, credential_arn text,
  rule_id text, title text, severity text, risk_score numeric(5,1),
  status text NOT NULL CHECK (status IN ('OPEN','ACCEPTED','SUPPRESSED','RESOLVED')),
  first_seen timestamptz, last_seen timestamptz, resolved_at timestamptz,
  remediation text, compliance_tags text[], accepted_reason text, suppressed_until timestamptz,
  assigned_to text, notes text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX ON {S}.ispm_nhi_findings (tenant_id, identity_id);
CREATE INDEX ON {S}.ispm_nhi_findings (tenant_id, credential_arn);
CREATE INDEX ON {S}.ispm_nhi_findings (tenant_id, rule_id);

CREATE TABLE {S}.ispm_finding_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), finding_id uuid NOT NULL,
  action text NOT NULL, old_value text, new_value text, actor text, reason text,
  created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX ON {S}.ispm_finding_history (finding_id, created_at);

CREATE TABLE {S}.ispm_access_edges (
  tenant_id uuid NOT NULL, source_arn text NOT NULL, source_type text,
  edge_type text NOT NULL CHECK (edge_type IN ('BOUND_TO','CAN_ASSUME','TRUSTED_BY','CROSS_ACCOUNT')),
  target_arn text NOT NULL, target_type text, attributes jsonb NOT NULL DEFAULT '{{}}'::jsonb,
  first_seen timestamptz, last_seen timestamptz, PRIMARY KEY (tenant_id, source_arn, edge_type, target_arn));
CREATE INDEX ON {S}.ispm_access_edges (tenant_id, target_arn, edge_type);

CREATE TABLE {S}.ispm_role_use (
  tenant_id uuid NOT NULL, identity_id uuid NOT NULL,
  direction text NOT NULL CHECK (direction IN ('ASSUMES','ASSUMED_BY')),
  counterpart_arn text NOT NULL, counterpart_name text, counterpart_class text,
  sessions bigint, first_assumed_at timestamptz, last_assumed_at timestamptz,
  PRIMARY KEY (tenant_id, identity_id, direction, counterpart_arn));
"""

PILLARS = [
    ("least_privilege", "Least privilege", "Holds only the access it uses."),
    ("credential_hygiene", "Credential hygiene", "Keys are rotated, short-lived and never left expired."),
    ("trust_access", "Trust & access", "Who can sign in as it or assume it, and on what terms."),
    ("escalation", "Escalation", "Cannot widen its own access."),
    ("exposure", "Exposure", "Its credentials are used only by it, from where they should be."),
    ("lifecycle", "Lifecycle", "Has an owner and is still in use."),
]
CATEGORIES = [
    ("admin_access", "Administrative access", "least_privilege"),
    ("wildcard_permissions", "Wildcard / service-wide permissions", "least_privilege"),
    ("unused_permissions", "Unused permissions", "least_privilege"),
    ("key_rotation", "Key rotation", "credential_hygiene"),
    ("unused_credentials", "Unused credentials", "credential_hygiene"),
    ("secret_rotation", "Secret rotation", "credential_hygiene"),
    ("cross_account_trust", "Cross-account trust", "trust_access"),
    ("broad_trust", "Broad trust principals", "trust_access"),
    ("privilege_escalation", "Privilege escalation", "escalation"),
    ("role_chaining", "Role chaining", "escalation"),
    ("network_exposure", "Network exposure", "exposure"),
    ("anomalous_usage", "Anomalous credential use", "exposure"),
    ("ownership", "Ownership", "lifecycle"),
    ("dormancy", "Dormancy", "lifecycle"),
    ("guardrails", "Guardrails", "lifecycle"),
]
COMPUTE = ["lambda_function", "ec2_instance", "ecs_task"]
WORKLOADS = COMPUTE + ["step_function", "glue_job", "codebuild_project"]
# rule_id, title, category, severity, fix, description, applies_to (None = all), compliance tags
RULES = [
    ("NHI-LP-001", "Administrator access attached", "admin_access", "CRITICAL",
     "Replace AdministratorAccess with a scoped policy",
     "The identity's role or user has the AWS managed AdministratorAccess policy (\"*:*\"). Replace it with a policy generated from the actions it actually uses.",
     None, ["CIS-AWS-1.16", "NIST-AC-6", "SOC2-CC6.3"]),
    ("NHI-LP-002", "Wildcard or service-wide permissions", "wildcard_permissions", "HIGH",
     "Scope *FullAccess policies to the resources used",
     "A *FullAccess / PowerUser policy grants every action on a service. Restrict actions and resources to what the workload calls.",
     None, ["NIST-AC-6(1)", "SOC2-CC6.3"]),
    ("NHI-LP-003", "Most granted permissions unused (90d)", "unused_permissions", "MEDIUM",
     "Remove permissions unused for 90 days",
     "More than 80% of the granted actions were not called in the last 90 days of CloudTrail.",
     None, ["NIST-AC-6(7)", "ISO27001-A.9.2.5"]),
    ("NHI-CH-001", "Access key older than 90 days", "key_rotation", "HIGH",
     "Rotate the access key and delete the old one",
     "An active long-lived access key has not been rotated in more than 90 days.",
     ["iam_user"], ["CIS-AWS-1.14", "PCI-DSS-8.3.9", "SOC2-CC6.1"]),
    ("NHI-CH-002", "Access key unused for 90 days", "unused_credentials", "MEDIUM",
     "Deactivate and delete the unused access key",
     "An active access key has not been used for more than 90 days (or since it was created more than 30 days ago).",
     ["iam_user"], ["CIS-AWS-1.12", "SOC2-CC6.2"]),
    ("NHI-CH-003", "Owned secret without rotation", "secret_rotation", "MEDIUM",
     "Enable automatic rotation for the secret",
     "A Secrets Manager secret or API key used by this workload has no rotation configured.",
     WORKLOADS, ["PCI-DSS-3.6.4", "SOC2-CC6.1"]),
    ("NHI-TA-001", "Cross-account trust without ExternalId", "cross_account_trust", "HIGH",
     "Require sts:ExternalId in the trust policy",
     "The role trusts another AWS account's root without an sts:ExternalId or aws:PrincipalArn condition.",
     ["iam_role"], ["CIS-AWS-1.20", "NIST-AC-17"]),
    ("NHI-TA-002", "Trust policy allows an entire account", "broad_trust", "MEDIUM",
     "Restrict the trust policy to named principals",
     "The trust policy principal is arn:aws:iam::<account>:root, so any principal in that account with sts:AssumeRole can assume it.",
     ["iam_role"], ["NIST-AC-3"]),
    ("NHI-ES-001", "Can modify IAM policies (escalation path)", "privilege_escalation", "CRITICAL",
     "Remove iam:CreatePolicyVersion / iam:PassRole or add a permission boundary",
     "The identity can change IAM policies or pass roles to new compute without being an administrator, which lets it grant itself more access.",
     None, ["NIST-AC-6(10)", "SOC2-CC6.3"]),
    ("NHI-ES-002", "Can assume an administrator role", "role_chaining", "HIGH",
     "Limit which principals may assume the admin role",
     "Through sts:AssumeRole this identity reaches a role with AdministratorAccess.",
     None, ["NIST-AC-6(5)"]),
    ("NHI-EX-001", "Internet-reachable compute with a privileged role", "network_exposure", "CRITICAL",
     "Move behind a load balancer / VPN or reduce the role's privileges",
     "The workload has a public IP or public endpoint and its role is admin or high privilege.",
     COMPUTE, ["CIS-AWS-5.2", "NIST-SC-7"]),
    ("NHI-EX-002", "Credential used from an unexpected network", "anomalous_usage", "HIGH",
     "Rotate the credential and add an aws:SourceIp condition",
     "CloudTrail shows calls with this credential from an address outside its usual ranges (e.g. a Tor exit node).",
     None, ["NIST-SI-4", "SOC2-CC7.2"]),
    ("NHI-LC-001", "No owner assigned", "ownership", "LOW",
     "Tag the identity with an owning team",
     "No owner tag or ownership mapping exists for this identity.",
     None, ["SOC2-CC1.3", "ISO27001-A.8.1.2"]),
    ("NHI-LC-002", "Dormant identity (no activity for 90 days)", "dormancy", "MEDIUM",
     "Decommission the identity or document why it is kept",
     "No CloudTrail activity in more than 90 days.",
     None, ["CIS-AWS-1.12", "NIST-AC-2(3)"]),
    ("NHI-LC-003", "Privileged role without a permission boundary", "guardrails", "LOW",
     "Attach a permission boundary",
     "An admin or high-privilege role/user has no IAM permission boundary.",
     None, ["NIST-AC-6"]),
]
RULE = {r[0]: r for r in RULES}
CAT_PILLAR = {c: p for c, _, p in CATEGORIES}


def pillar_of(rule_id):
    return CAT_PILLAR[RULE[rule_id][2]]


def band_of(s):
    return "HEALTHY" if s >= 80 else "FAIR" if s >= 60 else "POOR" if s >= 40 else "CRITICAL"


def grade_of(s):
    return "A" if s >= 90 else "B" if s >= 80 else "C" if s >= 60 else "D" if s >= 40 else "F"


def applies(rule, ident):
    a = rule[6]
    return a is None or ident["identity_type"] in a


ADMIN_ROLES = {"deploy-role", "cross-account-admin", "break-glass"}


def evaluate(i, edges_by_src):
    """rule_id -> (fail: bool, detail, failing_days_ago or None). failing_days is when it started failing."""
    out = {}
    name, priv, pols = i["name"], i["priv"], i["policies"]
    role = i["role_arn"] or i["arn"]
    idle = i["idle_days"]
    rnd = random.Random(i["id"])

    def since(lo, hi):
        return rnd.randint(lo, hi)

    out["NHI-LP-001"] = (priv == "admin", f"AdministratorAccess is attached to {role.split('/')[-1]}.", since(20, 85))
    broad = [p for p in pols if p.endswith("FullAccess") or p in ("PowerUserAccess", "AdministratorAccess")]
    out["NHI-LP-002"] = (bool(broad), f"Service-wide policies: {', '.join(broad) or 'none'}.", since(15, 85))
    out["NHI-LP-003"] = (priv in ("admin", "high", "medium"),
                         {"admin": "4 of 412", "high": "9 of 120", "medium": "5 of 46"}.get(priv, "") + " granted actions used in 90 days.",
                         since(10, 80))
    if i["identity_type"] == "iam_user":
        keys = [k for k in i["keys"] if k["status"] == "active"]
        old = [k for k in keys if (k["age_days"] or 0) > 90]
        out["NHI-CH-001"] = (bool(old), "; ".join(f"{k['name']} is {int(k['age_days'])} days old" for k in old) or "All active keys are younger than 90 days.",
                             max(1, int(min((k["age_days"] for k in old), default=91)) - 90))
        unused = [k for k in keys if (k["unused_days"] or 0) > 90 or (k["unused_days"] is None and (k["age_days"] or 0) > 30)]
        out["NHI-CH-002"] = (bool(unused), "; ".join(f"{k['name']} last used {int(k['unused_days'])} days ago" for k in unused) or "Every active key was used recently.",
                             max(1, int(min(((k["unused_days"] or 0) for k in unused), default=91)) - 90))
    if i["identity_type"] in WORKLOADS:
        norot = [o for o in i["owned_secrets"] if not o["rotation_enabled"]]
        out["NHI-CH-003"] = (bool(norot), "; ".join(f"{o['name']} ({o['credential_type']}) has no rotation" for o in norot) or "Owned secrets rotate automatically.", since(30, 80))
    if i["identity_type"] == "iam_role":
        stmts = (i["primary"].get("trust_policy") or {}).get("Statement", [])
        roots = [s["Principal"]["AWS"] for s in stmts if "AWS" in s.get("Principal", {})]
        foreign = [r for r in roots if i["account_id"] not in r]
        out["NHI-TA-001"] = (bool(foreign), f"Trusts {', '.join(foreign)} without sts:ExternalId." if foreign else "No cross-account trust.", since(40, 88))
        out["NHI-TA-002"] = (bool(roots), f"Trust principal {', '.join(roots)}." if roots else "Trust limited to named principals.", since(40, 88))
    esc = name in ("terraform-bot", "infra-plan")
    out["NHI-ES-001"] = (esc, "Has iam:CreatePolicyVersion / iam:PassRole via PowerUserAccess plus an inline policy." if esc else "No IAM write actions outside admin.", since(20, 70))
    targets = edges_by_src.get(role, []) + edges_by_src.get(i["arn"], [])
    admin_t = [t for t in targets if t.split("/")[-1] in ADMIN_ROLES]
    out["NHI-ES-002"] = (bool(admin_t), f"Can assume {', '.join(sorted(set(admin_t)))}." if admin_t else "Cannot reach an admin role.", since(25, 80))
    if i["identity_type"] in COMPUTE:
        exp = bool(i["public"]) and priv in ("admin", "high")
        out["NHI-EX-001"] = (exp, f"Public endpoint with a {priv}-privilege role." if exp else "Not internet-reachable with a privileged role.", since(10, 60))
    tor = name == "ci-deployer"
    out["NHI-EX-002"] = (tor, "Access key AKIAAE5B1F6FECCC530A used from 185.220.101.47 (Tor exit) 10 days ago; 5 of 8 calls denied." if tor else "All calls from known networks.", 10)
    out["NHI-LC-001"] = (not i["owner"], "No owner tag." if not i["owner"] else f"Owned by {i['owner']}.", since(30, 88))
    dormant = idle is None or idle > 90
    out["NHI-LC-002"] = (dormant, "Never used." if idle is None else f"Last activity {int(idle)} days ago.",
                         120 if idle is None else max(1, int(idle) - 90))
    nb = priv in ("admin", "high") and not (i["primary"] or {}).get("permission_boundary_arn")
    out["NHI-LC-003"] = (nb, "No permission boundary on a privileged principal." if nb else "Boundary not required.", since(30, 88))
    return {k: v for k, v in out.items() if applies(RULE[k], i)}


def main():
    idents, trust = load_inventory()
    by_arn = {i["arn"]: i for i in idents}
    role_owner = {}  # role arn -> identity (workload bound to role, or role identity itself)
    for i in idents:
        if i["role_arn"]:
            role_owner.setdefault(i["role_arn"], i)
    edges_by_src = {}
    for e in trust:
        if e["edge_type"] == "assume_role":
            edges_by_src.setdefault(e["source_arn"], []).append(e["target_arn"])

    scan_times = []
    last_scan = NOW.replace(minute=0, second=0) - dt.timedelta(hours=NOW.hour % SCAN_EVERY_H) + dt.timedelta(minutes=2)
    if last_scan > NOW:
        last_scan -= dt.timedelta(hours=SCAN_EVERY_H)
    for k in range(SCANS):
        scan_times.append(last_scan - dt.timedelta(hours=SCAN_EVERY_H * k))
    scan_times.reverse()
    scan_ids = {t: uid(f"ispm-scan:{t.isoformat()}") for t in scan_times}
    current_scan = scan_ids[scan_times[-1]]

    # ── evaluate every identity, build failure intervals ──────────────────
    checks = {}   # identity_id -> rule -> dict
    intervals = {}  # identity_id -> [(rule, start, end)]
    for i in idents:
        res = evaluate(i, edges_by_src)
        checks[i["id"]] = {}
        iv = []
        for rid, (fail, detail, days) in res.items():
            start = last_scan - dt.timedelta(days=days, hours=random.randint(0, 5)) if fail else None
            checks[i["id"]][rid] = dict(fail=fail, detail=detail, since=start)
            if fail:
                iv.append((rid, start, None))
        # Past failures that were fixed (RESOLVED findings) on ~1/3 of identities.
        rnd = random.Random("fixed" + i["id"])
        passing = [r for r, c in checks[i["id"]].items() if not c["fail"]]
        if passing and rnd.random() < 0.4:
            rid = rnd.choice(passing)
            st = last_scan - dt.timedelta(days=rnd.randint(40, 85))
            en = last_scan - dt.timedelta(days=rnd.randint(2, 35), hours=rnd.randint(0, 20))
            iv.append((rid, st, en))
            checks[i["id"]][rid]["resolved"] = (st, en)
        intervals[i["id"]] = iv

    def state_at(iid, t):
        failing = [r for r, st, en in intervals[iid] if st <= t and (en is None or en > t)]
        lost = sum(POINTS[RULE[r][3]] for r in failing)
        return max(0.0, 100.0 - lost), failing

    def change(iid, days):
        now_s, _ = state_at(iid, last_scan)
        then_s, _ = state_at(iid, last_scan - dt.timedelta(days=days))
        return round(now_s - then_s, 1)

    sql = ["SET client_min_messages = warning;", "BEGIN;", DDL]
    w = sql.append
    for n, (code, name, desc) in enumerate(PILLARS):
        w(f"INSERT INTO {S}.ispm_pillars VALUES ({q(code)}, {q(name)}, {q(desc)}, {n + 1}, true);")
    for code, name, pillar in CATEGORIES:
        w(f"INSERT INTO {S}.ispm_categories VALUES ({q(code)}, {q(name)}, {q(pillar)}, true);")
    for rid, title, cat, sev, fix, desc, ap, _tags in RULES:
        w(f"INSERT INTO {S}.ispm_rule_weights (rule_id, rule_name, check_title, description, fix_label, severity, penalty_points, category_code, applies_to) "
          f"VALUES ({q(rid)}, {q(rid.lower().replace('-', '_'))}, {q(title)}, {q(desc)}, {q(fix)}, {q(sev)}, {POINTS[sev]}, {q(cat)}, {text_array(ap or ['*'])});")

    # ── scan history ──────────────────────────────────────────────────────
    for k, t in enumerate(scan_times):
        failed = k in (37, 211) and t != last_scan
        partial = k in (120, 305) and t != last_scan
        status = "FAILED" if failed else "PARTIAL" if partial else "COMPLETED"
        w(f"INSERT INTO {S}.ispm_scan_history VALUES ({q(scan_ids[t])}, {q(TENANT)}, {q(status)}, {q('scheduled' if k % 4 else 'event')}, "
          f"{q(t - dt.timedelta(minutes=2))}, {q(None if failed else t + dt.timedelta(seconds=40 + k % 30))}, {0 if failed else 41}, "
          f"{0 if failed else 41 * 12}, NULL, {q('AccessDenied: sts:AssumeRole on arn:aws:iam::222222222222:role/nhi-scanner' if failed else 'eu-west-1 timed out for 111111111111' if partial else None)});")

    # ── findings ──────────────────────────────────────────────────────────
    findings = []  # dicts
    special = {  # (identity name, rule) -> (status, extra)
        ("break-glass", "NHI-LC-002"): ("ACCEPTED", dict(accepted_reason="Emergency role; kept unused by design, reviewed quarterly.", assigned_to="security-team")),
        ("audit-reader", "NHI-TA-001"): ("ACCEPTED", dict(accepted_reason="Third-party auditor; ExternalId enforced by SCP.", assigned_to="security-team")),
        ("old-worker", "NHI-LC-002"): ("SUPPRESSED", dict(suppressed_until=NOW + dt.timedelta(days=14), assigned_to="data-team")),
        ("legacy-cron", "NHI-LC-001"): ("SUPPRESSED", dict(suppressed_until=NOW + dt.timedelta(days=30))),
        ("thumbnailer", "NHI-LP-001"): ("OPEN", dict(assigned_to="alice@acme.test", notes=f"[{(NOW - dt.timedelta(days=3)).isoformat()} alice@acme.test] Ticket SEC-1423 opened with the media team.")),
    }
    for i in idents:
        primary = i["role_arn"]
        for rid, c in checks[i["id"]].items():
            rule = RULE[rid]
            sev = rule[3]
            base = {"CRITICAL": 85, "HIGH": 65, "MEDIUM": 40, "LOW": 12}[sev]
            cred = primary
            if rid in ("NHI-CH-001", "NHI-CH-002", "NHI-EX-002") and i["keys"]:
                cred = i["keys"][0]["arn"]
            if c["fail"]:
                status, extra = special.get((i["name"], rid), ("OPEN", {}))
                fid = uid(f"ispm-finding:{i['id']}:{rid}")
                c["finding_id"] = fid
                upd = max(c["since"], NOW - dt.timedelta(days=random.randint(0, 6), hours=random.randint(1, 20)))
                findings.append(dict(finding_id=fid, identity_id=i["id"], identity_arn=i["arn"], credential_arn=cred, rule_id=rid,
                                     title=f"{rule[1]}: {i['name']}", severity=sev, risk_score=base + random.randint(0, 12),
                                     status=status, first_seen=c["since"], last_seen=last_scan, resolved_at=None,
                                     remediation=rule[4] + ". " + rule[5], tags=rule[7], updated_at=upd, **extra))
            if "resolved" in c:
                st, en = c["resolved"]
                fid = uid(f"ispm-finding:{i['id']}:{rid}:resolved")
                findings.append(dict(finding_id=fid, identity_id=i["id"], identity_arn=i["arn"], credential_arn=cred, rule_id=rid,
                                     title=f"{rule[1]}: {i['name']}", severity=sev, risk_score=base + random.randint(0, 12),
                                     status="RESOLVED", first_seen=st, last_seen=en, resolved_at=en,
                                     remediation=rule[4] + ". " + rule[5], tags=rule[7], updated_at=en))
    open_by_ident = {}
    for f in findings:
        if f["status"] == "OPEN":
            open_by_ident[f["identity_id"]] = open_by_ident.get(f["identity_id"], 0) + 1
        w(f"INSERT INTO {S}.ispm_nhi_findings (finding_id, tenant_id, identity_id, identity_arn, credential_arn, rule_id, title, severity, "
          f"risk_score, status, first_seen, last_seen, resolved_at, remediation, compliance_tags, accepted_reason, suppressed_until, "
          f"assigned_to, notes, created_at, updated_at) VALUES ({q(f['finding_id'])}, {q(TENANT)}, {q(f['identity_id'])}, {q(f['identity_arn'])}, "
          f"{q(f['credential_arn'])}, {q(f['rule_id'])}, {q(f['title'])}, {q(f['severity'])}, {f['risk_score']}, {q(f['status'])}, "
          f"{q(f['first_seen'])}, {q(f['last_seen'])}, {q(f['resolved_at'])}, {q(f['remediation'])}, {text_array(f['tags'])}, "
          f"{q(f.get('accepted_reason'))}, {q(f.get('suppressed_until'))}, {q(f.get('assigned_to'))}, {q(f.get('notes'))}, "
          f"{q(f['first_seen'])}, {q(f['updated_at'])});")
        w(f"INSERT INTO {S}.ispm_finding_history (finding_id, action, old_value, new_value, actor, reason, created_at) VALUES "
          f"({q(f['finding_id'])}, 'CREATED', NULL, 'OPEN', 'ispm-engine', NULL, {q(f['first_seen'])});")
        if f["status"] in ("ACCEPTED", "SUPPRESSED"):
            w(f"INSERT INTO {S}.ispm_finding_history (finding_id, action, old_value, new_value, actor, reason, created_at) VALUES "
              f"({q(f['finding_id'])}, {q(f['status'])}, 'OPEN', {q(f['status'])}, 'alice@acme.test', {q(f.get('accepted_reason') or 'until ' + str(f.get('suppressed_until')))}, {q(f['updated_at'])});")
        if f["status"] == "RESOLVED":
            w(f"INSERT INTO {S}.ispm_finding_history (finding_id, action, old_value, new_value, actor, reason, created_at) VALUES "
              f"({q(f['finding_id'])}, 'RESOLVED', 'OPEN', 'RESOLVED', 'ispm-engine', 'Check passed on rescan', {q(f['resolved_at'])});")

    # ── current posture + checks ──────────────────────────────────────────
    cur_scores = {}
    for i in idents:
        iid = i["id"]
        score, failing = state_at(iid, last_scan)
        cur_scores[iid] = score
        sevs = [RULE[r][3] for r in failing]
        pill = {}
        for rid in checks[iid]:
            p = pillar_of(rid)
            d = pill.setdefault(p, dict(evaluated=0, failing=0, penalty=0, lost=0))
            d["evaluated"] += 1
            d["penalty"] += POINTS[RULE[rid][3]]
            if rid in failing:
                d["failing"] += 1
                d["lost"] += POINTS[RULE[rid][3]]
        pillar_scores = {p: dict(score=round(100 * (1 - d["lost"] / d["penalty"]), 1), evaluated=d["evaluated"], failing=d["failing"])
                         for p, d in pill.items()}
        weakest = min(pillar_scores.items(), key=lambda kv: (kv[1]["score"], kv[0]))[0] if failing else None
        prim = i["primary"] or {}
        if i["keys"]:
            ctype, cage = "ACCESS_KEY", int(max(k["age_days"] for k in i["keys"]))
        else:
            ctype, cage = (prim.get("credential_type") or "iam_role").upper(), int(prim.get("age_days") or 0)
        top = sorted(failing, key=lambda r: -POINTS[RULE[r][3]])[:3]
        why = (f"{i['name']} scores {score:g} because " + ", ".join(f"{RULE[r][1].lower()} (-{POINTS[RULE[r][3]]})" for r in top) + "."
               if failing else f"{i['name']} passes every applicable check.")
        user = i["identity_type"] == "iam_user"
        w(f"INSERT INTO {S}.ispm_identity_posture VALUES ({q(TENANT)}, {q(iid)}, {q(i['arn'])}, {q(i['name'])}, {q(i['identity_type'])}, "
          f"{q(i['functional_class'])}, {q(i['account_id'])}, {q(ACCOUNT_NAMES.get(i['account_id']))}, {q(i['region'])}, "
          f"{score}, {q(band_of(score))}, {q(grade_of(score))}, {sum(POINTS[x] for x in sevs)}, {len(failing)}, {len(checks[iid])}, "
          f"{sevs.count('CRITICAL')}, {sevs.count('HIGH')}, {sevs.count('MEDIUM')}, {sevs.count('LOW')}, {q(weakest)}, {q(ctype)}, {cage}, "
          f"{change(iid, 1)}, {change(iid, 3)}, {change(iid, 7)}, {change(iid, 30)}, {change(iid, 60)}, {change(iid, 90)}, "
          f"{open_by_ident.get(iid, 0)}, {q(False if user else None)}, {q(False if user else None)}, {q(pillar_scores)}, {q(why)}, "
          f"{q(current_scan)}, {q(last_scan + dt.timedelta(seconds=41))});")
        for rid, c in checks[iid].items():
            sev = RULE[rid][3]
            fail = rid in failing
            w(f"INSERT INTO {S}.ispm_identity_checks VALUES ({q(TENANT)}, {q(iid)}, {q(rid)}, {q('FAIL' if fail else 'PASS')}, {q(sev)}, "
              f"{q(pillar_of(rid))}, {POINTS[sev] if fail else 0}, {POINTS[sev]}, {q(c['detail'])}, {q(c['since'] if fail else None)}, "
              f"{q(c.get('finding_id') if fail else None)}, {q(last_scan)});")

    # ── per-scan history (hourly table), snapshots; daily tables + dashboard cache ──
    for t in scan_times:
        scores = []
        for i in idents:
            s, failing = state_at(i["id"], t)
            scores.append(s)
            w(f"INSERT INTO {S}.ispm_identity_posture_hourly VALUES ({q(TENANT)}, {q(i['id'])}, {q(t)}, {q(scan_ids[t])}, {s}, {q(band_of(s))}, {len(failing)});")
        bands = [band_of(s) for s in scores]
        w(f"INSERT INTO {S}.ispm_posture_snapshots VALUES ({q(uid('ispm-snap:' + scan_ids[t]))}, {q(TENANT)}, {q(scan_ids[t])}, {q(t)}, "
          f"{round(sum(scores) / len(scores), 1)}, {len(scores)}, {bands.count('HEALTHY')}, {bands.count('FAIR')}, {bands.count('POOR')}, {bands.count('CRITICAL')});")

    def fleet_at(t):
        res = {}
        for i in idents:
            res[i["id"]] = state_at(i["id"], t)
        return res

    WINDOWS = {"1d": 1, "3d": 3, "7d": 7, "30d": 30, "60d": 60, "90d": 90}
    for d in range(90, -1, -1):
        day_t = last_scan - dt.timedelta(days=d)
        day = day_t.date()
        st = fleet_at(day_t)
        for i in idents:
            s, failing = st[i["id"]]
            w(f"INSERT INTO {S}.ispm_identity_posture_daily VALUES ({q(TENANT)}, {q(i['id'])}, {q(day)}, {s}, {q(band_of(s))}, {len(failing)});")
        scores = [st[i["id"]][0] for i in idents]
        fleet = round(sum(scores) / len(scores), 1)
        bands = [band_of(s) for s in scores]
        fails = {i["id"]: set(st[i["id"]][1]) for i in idents}

        def count_any(rules):
            return sum(1 for f in fails.values() if f & set(rules))
        with_ = {"over_permissioned": count_any(["NHI-LP-001", "NHI-LP-002"]), "stale_credentials": count_any(["NHI-CH-001", "NHI-CH-002", "NHI-CH-003"]),
                 "escalation_paths": count_any(["NHI-ES-001", "NHI-ES-002"]), "exposed": count_any(["NHI-EX-001", "NHI-EX-002"]),
                 "dormant": count_any(["NHI-LC-002"]), "trust_issues": count_any(["NHI-TA-001", "NHI-TA-002"])}
        pillar_summary = {}
        for code, _, _ in PILLARS:
            vals, ev, fl = [], 0, 0
            for i in idents:
                rs = [r for r in checks[i["id"]] if pillar_of(r) == code]
                if not rs:
                    continue
                pen = sum(POINTS[RULE[r][3]] for r in rs)
                lost = sum(POINTS[RULE[r][3]] for r in rs if r in fails[i["id"]])
                vals.append(100 * (1 - lost / pen))
                ev += 1
                fl += 1 if lost else 0
            pillar_summary[code] = dict(score=round(sum(vals) / len(vals), 1), evaluated=ev, failing=fl)
        wins = []
        for rule in RULES:
            rid = rule[0]
            n = sum(1 for f in fails.values() if rid in f)
            if n:
                wins.append(dict(rule_id=rid, title=rule[1], pillar=pillar_of(rid), identities=n,
                                 fleet_gain=round(n * POINTS[rule[3]] / len(idents), 1)))
        wins = sorted(wins, key=lambda x: -x["fleet_gain"])[:5]

        def group_stats(keyf, label):
            groups = {}
            for i in idents:
                groups.setdefault(keyf(i), []).append(i)
            out = []
            for k, members in sorted(groups.items()):
                mean = sum(st[m["id"]][0] for m in members) / len(members)
                chg = {}
                for wl, wd in WINDOWS.items():
                    prev = [state_at(m["id"], day_t - dt.timedelta(days=wd))[0] for m in members]
                    chg[wl] = round(mean - sum(prev) / len(prev), 1)
                row = {label: k, "count": len(members), "mean": round(mean, 1), "change": chg}
                if label == "account":
                    row = {"account": ACCOUNT_NAMES.get(k, k), "account_id": k, "count": len(members), "mean": round(mean, 1), "change": chg}
                out.append(row)
            return out
        latest = d == 0
        by_class = group_stats(lambda i: i["functional_class"] or "unknown", "functional_class") if latest or d % 7 == 0 else []
        by_acct = group_stats(lambda i: i["account_id"], "account") if latest or d % 7 == 0 else []
        computed = day_t + dt.timedelta(seconds=41)
        w(f"INSERT INTO {S}.ispm_nhi_dashboard_cache VALUES ({q(TENANT)}, {q(day)}, {q(computed)}, {q(scan_ids.get(day_t, current_scan))}, "
          f"{fleet}, {q(grade_of(fleet))}, {q(band_of(fleet))}, {len(scores)}, {bands.count('HEALTHY')}, {bands.count('FAIR')}, "
          f"{bands.count('POOR')}, {bands.count('CRITICAL')}, {q(with_)}, {q(pillar_summary)}, {q(wins)}, {q(by_class)}, {q(by_acct)});")

    # ── access edges (mirrors trust_edges + bindings) ─────────────────────
    edges = {}

    def edge(src, stype, et, tgt, ttype, attrs=None, first=None):
        edges[(src, et, tgt)] = (stype, ttype, attrs or {}, first or NOW - dt.timedelta(days=88))
    ctype_map = {"iam_role": "IAM_ROLE", "access_key": "ACCESS_KEY", "iam_user": "IAM_USER"}
    for i in idents:
        for c in i["creds"]:
            if i["identity_type"] == "iam_user" and c["credential_type"] == "iam_user":
                continue
            priv = {"4": True, "3": True}.get(str(c["privilege_level"]), False)
            edge(i["arn"], "IDENTITY", "BOUND_TO", c["arn"], ctype_map.get(c["credential_type"], c["credential_type"].upper()),
                 {"binding_type": c["binding_type"], "target_privileged": "true" if priv else "false"})

    def node_type(arn):
        if ":role/" in arn:
            return "IAM_ROLE"
        if ":user/" in arn:
            return "IAM_USER"
        if arn.endswith(":root"):
            return "ACCOUNT"
        if arn.endswith(".amazonaws.com"):
            return "SERVICE"
        return "IDENTITY"
    admin_arns = {i["role_arn"] for i in idents if i["priv"] == "admin"}
    for e in trust:
        s_, t_, et = e["source_arn"], e["target_arn"], e["edge_type"]
        if et == "assume_role":
            edge(s_, node_type(s_), "CAN_ASSUME", t_, "IAM_ROLE", {"target_privileged": "true" if t_ in admin_arns else "false"})
        elif et == "cross_account":
            edge(s_, node_type(s_), "CROSS_ACCOUNT", t_, "IAM_ROLE", {"source_account": s_.split(":")[4], "target_account": t_.split(":")[4],
                                                                     "external_id": False})
        elif et in ("service_trust", "trusts"):
            edge(t_, "IAM_ROLE", "TRUSTED_BY", s_, node_type(s_), {"principal": s_})
    for i in idents:  # trust policies that name an account root
        if i["identity_type"] == "iam_role":
            for st in (i["primary"].get("trust_policy") or {}).get("Statement", []):
                root = st.get("Principal", {}).get("AWS")
                if root:
                    edge(i["arn"], "IAM_ROLE", "TRUSTED_BY", root, "ACCOUNT", {"principal": root, "external_id": False})
                    if root.split(":")[4] != i["account_id"]:
                        edge(i["arn"], "IAM_ROLE", "CROSS_ACCOUNT", root, "ACCOUNT",
                             {"source_account": i["account_id"], "target_account": root.split(":")[4], "external_id": False})
    for (src, et, tgt), (stype, ttype, attrs, first) in sorted(edges.items()):
        w(f"INSERT INTO {S}.ispm_access_edges VALUES ({q(TENANT)}, {q(src)}, {q(stype)}, {q(et)}, {q(tgt)}, {q(ttype)}, {q(attrs)}, {q(first)}, {q(last_scan)});")

    # ── role use (from ClickHouse AssumeRole events when available) ───────
    rows = ch_query("""SELECT if(session_issuer_arn != '', session_issuer_arn, caller_arn) AS src, resource_arn AS tgt,
                         count() AS n, toString(min(event_time)) AS first, toString(max(event_time)) AS last
                       FROM nhi_events.cloudtrail_events
                       WHERE event_name = 'AssumeRole' AND error_code = '' AND resource_arn != ''
                       GROUP BY src, tgt""")
    if not rows:
        rows = [dict(src=e["source_arn"], tgt=e["target_arn"], n=random.randint(5, 200),
                     first=str(NOW - dt.timedelta(days=89)), last=str(NOW - dt.timedelta(hours=5)))
                for e in trust if e["edge_type"] == "assume_role"]
    seen = set()
    for r in rows:
        src_i = role_owner.get(r["src"]) or by_arn.get(r["src"])
        tgt_i = by_arn.get(r["tgt"]) or role_owner.get(r["tgt"])
        first = dt.datetime.fromisoformat(str(r["first"])[:19]).replace(tzinfo=dt.timezone.utc)
        last = dt.datetime.fromisoformat(str(r["last"])[:19]).replace(tzinfo=dt.timezone.utc)
        if src_i:
            key = (src_i["id"], "ASSUMES", r["tgt"])
            if key not in seen:
                seen.add(key)
                w(f"INSERT INTO {S}.ispm_role_use VALUES ({q(TENANT)}, {q(src_i['id'])}, 'ASSUMES', {q(r['tgt'])}, {q(r['tgt'].split('/')[-1])}, "
                  f"{q(tgt_i['functional_class'] if tgt_i else None)}, {int(r['n'])}, {q(first)}, {q(last)});")
        if tgt_i and src_i:
            key = (tgt_i["id"], "ASSUMED_BY", src_i["arn"])
            if key not in seen:
                seen.add(key)
                w(f"INSERT INTO {S}.ispm_role_use VALUES ({q(TENANT)}, {q(tgt_i['id'])}, 'ASSUMED_BY', {q(src_i['arn'])}, {q(src_i['name'])}, "
                  f"{q(src_i['functional_class'])}, {int(r['n'])}, {q(first)}, {q(last)});")
    w("COMMIT;")
    path = os.path.join(HERE, "posture_seed.sql")
    with open(path, "w") as f:
        f.write(f"-- generated by posture_seed.py at {NOW.isoformat()}; re-run the .py to refresh relative times\n")
        f.write("\n".join(sql) + "\n")
    if "--sql-only" not in sys.argv:
        psql_file(path)
    bands = [band_of(s) for s in cur_scores.values()]
    print(f"posture: {len(idents)} identities, fleet {sum(cur_scores.values()) / len(cur_scores):.1f}, "
          f"bands {[(b, bands.count(b)) for b in ('HEALTHY', 'FAIR', 'POOR', 'CRITICAL')]}, findings {len(findings)}, edges {len(edges)}")


if __name__ == "__main__":
    main()
