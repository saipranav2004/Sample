#!/usr/bin/env python3
"""NHI Genome (behaviour monitoring) data for tenant_a (GENOME service).

Postgres (tenant_a): baselines, baseline_versions, identity_risk_scores, alerts,
daily_stats. The genome backend ships no migrations; DDL is derived from
internal/repository/genome/*.go (columns + Scan targets: NOT NULL wherever the
code scans into a plain string/int) and GENOME.md. Enum values follow the
frontend (src/features/genome/meta.jsx): baselines.status 'active' (established)
| 'inactive' (still learning); alerts.status 'open' | 'acknowledged' | 'expected'
| 'suppressed'; severity critical/high/medium/low.

ClickHouse: nhi_monitoring.log_events, ReplacingMergeTree(ingested_at) ORDER BY
event_id (monitoring_events.go). ~5k events over 30 days; a few events have a
second, later-ingested version (as the pipeline re-scores them), so the API's
uniqExact(event_id)/FINAL handling is exercised.

Identity keys: (source_type, identity_name) exactly as
internal/services/genome/identity_normalizer.go derives them from
tenant_a.identities: source_type = family (LAMBDA, EC2, ECS, GLUE, CODEBUILD,
STEP_FUNCTIONS), identity_name = canonical ARN. IAM roles/users are not
monitored by genome. One ECS identity (checkout-2) keeps its baseline under its
workload key to exercise the shared-profile fallback.

Behaviour per identity reuses the profiles in clickhouse_seed.py, so genome's
"typical actions/resources" agree with the CloudTrail store.

Idempotent: drops/recreates the five Postgres tables and the ClickHouse table.
Usage: python3 genome_seed.py
"""
import datetime as dt
import json
import os
import random
import sys
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import clickhouse_seed as cts  # noqa: E402  (behaviour profiles; importing does not touch ClickHouse)
from seedlib import NOW, ch_exec, load_inventory, psql_file, q  # noqa: E402

random.seed(23)
cts.random.seed(23)
S = "tenant_a"
CH_DB = os.environ.get("GENOME_CH_DB", "nhi_monitoring")
CH_TABLE = os.environ.get("GENOME_CH_TABLE", "log_events")
DAYS = 30
RATE = 2.4  # events/day multiplier over the CloudTrail profile rates (~5k events)
REQUIRED_DAYS = 14

FAMILY = {"ec2_instance": "EC2", "lambda_function": "LAMBDA", "ecs_task": "ECS", "glue_job": "GLUE",
          "codebuild_project": "CODEBUILD", "step_function": "STEP_FUNCTIONS"}

PG_DDL = f"""
SET client_min_messages = warning;
DROP TABLE IF EXISTS {S}.baselines, {S}.baseline_versions, {S}.identity_risk_scores, {S}.alerts, {S}.daily_stats;
CREATE TABLE {S}.baselines (
  source_type text NOT NULL, identity_name text NOT NULL,
  status text NOT NULL CHECK (status IN ('active','inactive')),
  required_days int NOT NULL, built_days int NOT NULL, days_remaining int NOT NULL,
  first_seen_date date, active_since timestamptz, profile_json jsonb,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (source_type, identity_name));
CREATE TABLE {S}.baseline_versions (
  id bigserial PRIMARY KEY, source_type text NOT NULL, identity_name text NOT NULL, version bigint NOT NULL,
  published_at timestamptz NOT NULL, profile_json jsonb, UNIQUE (source_type, identity_name, version));
CREATE TABLE {S}.identity_risk_scores (
  id bigserial PRIMARY KEY, source_type text NOT NULL, identity_name text NOT NULL,
  risk_score int CHECK (risk_score BETWEEN 0 AND 100), severity text NOT NULL, score_status text NOT NULL,
  event_count int NOT NULL DEFAULT 0, anomalous_event_count int NOT NULL DEFAULT 0,
  window_start timestamptz NOT NULL, window_end timestamptz NOT NULL, computed_at timestamptz NOT NULL);
CREATE INDEX ON {S}.identity_risk_scores (source_type, identity_name, window_end DESC, computed_at DESC);
CREATE TABLE {S}.alerts (
  id bigserial PRIMARY KEY, source_type text NOT NULL, identity_name text NOT NULL,
  dimension text NOT NULL, reason text NOT NULL,
  status text NOT NULL CHECK (status IN ('open','acknowledged','expected','suppressed')),
  severity text, observed_value text, baseline_value text, event_id text, event_risk_score int,
  created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL, decided_by text);
CREATE INDEX ON {S}.alerts (source_type, identity_name, status);
CREATE TABLE {S}.daily_stats (
  nhi_type text NOT NULL, identity_name text NOT NULL, period_start date NOT NULL,
  event_count int NOT NULL, distinct_actions int, error_count int, anomalous_count int,
  PRIMARY KEY (nhi_type, identity_name, period_start));
"""

CH_DDL = f"""CREATE TABLE {CH_DB}.{CH_TABLE}
(
    event_id          String,
    source_type       LowCardinality(String),
    identity_name     String,
    event_time        DateTime64(3, 'UTC'),
    ingested_at       DateTime64(3, 'UTC'),
    is_resolved       UInt8,
    account_id        LowCardinality(String),
    region            LowCardinality(String),
    event_name        LowCardinality(String),
    event_source      LowCardinality(String),
    source_ip         String,
    user_agent        String,
    caller_arn        String,
    error_code        LowCardinality(String),
    resource_arns     String,
    risk_status       LowCardinality(String),
    event_risk_score  Nullable(UInt8),
    dimensions_json   String
)
ENGINE = ReplacingMergeTree(ingested_at)
PARTITION BY toYYYYMM(event_time)
ORDER BY event_id"""


def ua_family(ua):
    for k, v in [("Boto3", "boto3"), ("aws-sdk-go-v2", "aws-sdk-go-v2"), ("aws-sdk-go", "aws-sdk-go"), ("aws-sdk-java", "aws-sdk-java"),
                 ("Terraform", "terraform"), ("aws-cli", "aws-cli"), ("states.amazonaws.com", "aws-internal"), ("Mozilla", "browser")]:
        if k in ua:
            return v
    return "other"


def net_class(ip):
    if ip.startswith("10."):
        return "vpc_private"
    if ip.endswith("amazonaws.com"):
        return "aws_service"
    if ip.startswith("185.220."):
        return "tor_exit"
    return "public_internet"


def resource_pattern(arn):
    if not arn:
        return ""
    if arn.startswith("arn:aws:s3:::"):
        b = arn[13:].split("/")[0]
        return f"arn:aws:s3:::{b}/*" if "/" in arn[13:] else f"arn:aws:s3:::{b}"
    return arn


def main():
    idents, _ = load_inventory()
    monitored = []
    for i in idents:
        if FAMILY.get(i["identity_type"]):
            monitored.append(i)
    for i in monitored:
        i["st"] = FAMILY[i["identity_type"]]
        i["key"] = i["arn"]  # canonical ARN == discovery ARN for these types
        attrs = i["type_attributes"] or {}
        if i["identity_type"] == "ecs_task":
            role = (attrs.get("role_arn") or "").split("/")[-1]
            i["workload_key"] = ":".join(["ecs", i["account_id"], i["region"], attrs.get("cluster_name") or "-",
                                          attrs.get("service_name") or "-", "-"] + ([role] if role else []))

    # ── log events (ClickHouse) ───────────────────────────────────────────
    events = []  # dicts for log_events
    rescored = []  # later versions of some events (inserted in a second part so both versions exist until a merge)
    per_ident = {}

    def to_log(i, ev, anomalous=False, score=None, risk="normal"):
        t = dt.datetime.strptime(ev["event_time"], "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=dt.timezone.utc)
        attrs = i["type_attributes"] or {}
        dims = {
            "api_operation": f"{ev['event_source'].split('.')[0]}:{ev['event_name']}",
            "api_service": ev["event_source"].split(".")[0],
            "region": ev["aws_region"],
            "read_write": "read" if ev["is_read_only"] else "write",
            "result": "success" if not ev["error_code"] else f"error:{ev['error_code']}",
            "resource_type": ev["resource_type"],
            "resource_pattern": resource_pattern(ev["resource_arn"]),
            "source_network_class": net_class(ev["source_ip"]),
            "user_agent_family": ua_family(ev["user_agent"]),
            "hour_of_week_utc": str(t.weekday() * 24 + t.hour),
            "timing": "business_hours" if 8 <= t.hour < 19 and t.weekday() < 5 else "off_hours",
        }
        if i["identity_type"] == "ecs_task":
            dims.update(cluster_name=attrs.get("cluster_name", ""), launch_type=attrs.get("launch_type", "FARGATE"),
                        task_definition_family=attrs.get("service_name", i["name"]))
        if i["identity_type"] == "step_function":
            dims.update(state_machine_name=i["name"], execution_status="FAILED" if ev["error_code"] else "SUCCEEDED")
        dims = {k: v for k, v in dims.items() if v != ""}
        ingested = t + dt.timedelta(seconds=random.randint(20, 400))
        if score is None:
            score = random.randint(0, 18) if not ev["error_code"] else random.randint(20, 45)
        row = dict(event_id=ev["event_id"], source_type=i["st"], identity_name=i["key"],
                   event_time=ev["event_time"], ingested_at=ingested.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
                   is_resolved=0 if random.random() < 0.015 else 1, account_id=ev["account_id"], region=ev["aws_region"],
                   event_name=ev["event_name"], event_source=ev["event_source"], source_ip=ev["source_ip"],
                   user_agent=ev["user_agent"], caller_arn=ev["caller_arn"], error_code=ev["error_code"],
                   resource_arns=",".join(a for a in [ev["resource_arn"]] + ev.get("extra_arns", []) if a),
                   risk_status="anomalous" if anomalous else ("elevated" if score >= 30 else "normal"),
                   event_risk_score=None if (not anomalous and random.random() < 0.05) else score,
                   dimensions_json=json.dumps(dims))
        events.append(row)
        per_ident.setdefault(i["arn"], []).append((t, row))
        # ~3% get re-scored by the pipeline: a second version with a later ingested_at
        if not anomalous and random.random() < 0.03:
            v2 = dict(row, ingested_at=(ingested + dt.timedelta(minutes=random.randint(5, 90))).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
                      risk_status="normal", event_risk_score=max(0, (row["event_risk_score"] or 5) - 3))
            rescored.append(v2)
        return row

    for i in monitored:
        p = cts.P.get(i["name"])
        if not p:
            continue
        for d in range(p["last"], DAYS):
            lam = p["rate"] * RATE * (0.45 if (NOW - dt.timedelta(days=d)).weekday() >= 5 and p["hours"] == "biz" else 1.0)
            n = int(lam) + (1 if random.random() < lam - int(lam) else 0)
            for _ in range(n):
                o = random.choices(p["ops"], [x["w"] for x in p["ops"]])[0]
                to_log(i, cts.make_event(p, o, cts.pick_time(p, d)))
        if p["last"] < DAYS:
            t = NOW - dt.timedelta(days=p["last"], hours=random.randint(1, 4)) if p["last"] else NOW - dt.timedelta(minutes=random.randint(15, 90))
            to_log(i, cts.make_event(p, p["ops"][0], t))

    # ── baselines + alerts with matching anomalous events ─────────────────
    by_name = {i["name"]: i for i in monitored}
    learning = {"pii-scrub": 9, "refund-flow": 5, "recommender": 11, "email-sender": 12}
    no_baseline = {"old-worker"}
    # (identity, dimension, reason, observed, baseline, severity, op override, ip override, region override, hour)
    ANOM = [
        ("thumbnailer", "api_operation", "API operation iam:CreateAccessKey has never been called by this function", "iam:CreateAccessKey", "s3:GetObject, s3:PutObject", "critical", ("iam", "CreateAccessKey", "arn:aws:iam::111111111111:user/svc-backup2"), None, "us-east-1", 3),
        ("thumbnailer", "api_service", "First calls to the IAM service in 30 days", "iam", "s3, ec2", "high", ("iam", "ListUsers", ""), None, "us-east-1", 3),
        ("thumbnailer", "hour_of_week_utc", "Activity on Sunday 03:00 UTC; the baseline is weekday business hours", "Sun 03:00", "Mon-Fri 08:00-18:00", "medium", None, None, None, 3),
        ("jenkins", "source_network_class", "Calls from a public address 34.240.12.88 instead of the VPC", "public_internet", "vpc_private", "high", None, "34.240.12.88", None, 22),
        ("jenkins", "api_operation", "iam:CreateAccessKey attempted (AccessDenied)", "iam:CreateAccessKey", "ecr:*, sts:AssumeRole, s3:PutObject", "critical", ("iam", "CreateAccessKey", "arn:aws:iam::111111111111:user/terraform-bot"), None, "us-east-1", 23),
        ("bastion", "result", "Repeated AccessDenied on sts:AssumeRole to break-glass", "error:AccessDenied x4", "success", "high", ("sts", "AssumeRole", "arn:aws:iam::111111111111:role/break-glass"), None, None, 2),
        ("bastion", "api_operation", "iam:GetAccountAuthorizationDetails is outside the baseline", "iam:GetAccountAuthorizationDetails", "ec2:DescribeInstances, ssm:StartSession", "high", ("iam", "GetAccountAuthorizationDetails", ""), None, "us-east-1", 1),
        ("payments-api", "resource_pattern", "Read of a DynamoDB table not in the baseline (refunds)", "table/refunds", "table/orders, table/payments", "medium", ("dynamodb", "Scan", "arn:aws:dynamodb:us-east-1:111111111111:table/refunds"), None, None, 14),
        ("payments-api", "region", "Calls to eu-central-1; baseline is us-east-1 only", "eu-central-1", "us-east-1", "high", None, None, "eu-central-1", 4),
        ("payments-api", "timing", "Burst of 40 calls between 02:00 and 03:00 UTC", "off_hours", "business_hours", "low", None, None, None, 2),
        ("checkout", "result", "TransactionCanceledException rate 6x the baseline", "error:TransactionCanceledException", "success", "low", None, None, None, 12),
        ("search", "api_operation", "es:DeleteDomain called for catalog-old", "es:DeleteDomain", "es:ESHttpGet, es:ESHttpPost", "critical", ("es", "DeleteDomain", "arn:aws:es:us-east-1:111111111111:domain/catalog-old"), None, None, 16),
        ("search", "read_write", "Write share rose to 61% (baseline 28%)", "write 61%", "write 28%", "medium", None, None, None, 15),
        ("admin-console", "api_operation", "iam:PutRolePolicy on search-task-role", "iam:PutRolePolicy", "iam:ListRoles, iam:GetRole", "critical", ("iam", "PutRolePolicy", "arn:aws:iam::111111111111:role/search-task-role"), None, "us-east-1", 11),
        ("ledger-sync", "resource_pattern", "Cross-account read of dynamodb table/payments in 111111111111", "arn:aws:dynamodb:us-east-1:111111111111:table/payments", "arn:aws:rds:us-east-1:222222222222:cluster:ledger-db", "high", ("dynamodb", "Query", "arn:aws:dynamodb:us-east-1:111111111111:table/payments"), None, None, 9),
        ("ledger-sync", "result", "AccessDeniedException on cross-account DynamoDB", "error:AccessDeniedException", "success", "medium", None, None, None, 9),
        ("fraud-score", "api_operation", "sts:AssumeRole into audit-reader is new", "sts:AssumeRole", "sagemaker:InvokeEndpoint", "medium", ("sts", "AssumeRole", "arn:aws:iam::222222222222:role/audit-reader"), None, None, 13),
        ("fraud-score", "user_agent_family", "Calls from aws-cli instead of boto3", "aws-cli", "boto3", "low", None, None, None, 13),
        ("nightly-etl", "hour_of_week_utc", "Run at Wednesday 14:00 UTC; the job runs nightly", "Wed 14:00", "daily 00:00-04:00", "low", None, None, None, 14),
        ("nightly-etl", "resource_pattern", "PutObject to acme-payments-ledger (not a data-lake bucket)", "arn:aws:s3:::acme-payments-ledger/*", "arn:aws:s3:::acme-data-lake/*", "high", ("s3", "PutObject", "arn:aws:s3:::acme-payments-ledger/exports/x.csv"), None, None, 2),
        ("etl-loader", "api_service", "First calls to secretsmanager", "secretsmanager", "s3, redshift-data, sts", "medium", ("secretsmanager", "GetSecretValue", "arn:aws:secretsmanager:us-east-1:111111111111:secret:prod/db/password-Ab12Cd"), None, None, 1),
        ("batch-runner", "read_write", "DeleteObject volume 9x the baseline", "write 70%", "write 35%", "medium", ("s3", "DeleteObject", "arn:aws:s3:::acme-data-lake/raw/part-00001.parquet"), None, None, 3),
        ("batch-runner", "source_network_class", "Calls from a public address", "public_internet", "vpc_private", "high", None, "52.95.110.1", None, 3),
        ("app-build", "api_operation", "iam:CreateRole tmp-build-role", "iam:CreateRole", "ecr:*, s3:PutObject, sts:AssumeRole", "high", ("iam", "CreateRole", "arn:aws:iam::111111111111:role/tmp-build-role"), None, "us-east-1", 15),
        ("app-build", "region", "Calls to ap-northeast-1", "ap-northeast-1", "us-east-1", "medium", None, None, "ap-northeast-1", 15),
        ("infra-plan", "api_operation", "iam:CreatePolicyVersion on deploy-boundary", "iam:CreatePolicyVersion", "Describe*/Get*", "critical", ("iam", "CreatePolicyVersion", "arn:aws:iam::111111111111:policy/deploy-boundary"), None, "us-east-1", 10),
        ("web-1", "api_service", "First calls to secretsmanager from a web node", "secretsmanager", "s3, ssm, ec2messages", "high", ("secretsmanager", "ListSecrets", ""), None, None, 21),
        ("web-2", "source_network_class", "Calls from 198.51.100.23 (outside the VPC)", "public_internet", "vpc_private", "medium", None, "198.51.100.23", None, 20),
        ("vpn-gw", "api_operation", "ec2:AuthorizeSecurityGroupIngress 0.0.0.0/0", "ec2:AuthorizeSecurityGroupIngress", "ec2:Describe*", "critical", ("ec2", "AuthorizeSecurityGroupIngress", "arn:aws:ec2:us-east-1:111111111111:security-group/sg-0a1b2c"), None, None, 1),
        ("order-saga", "execution_status", "Execution failure rate 18% (baseline 1%)", "FAILED", "SUCCEEDED", "medium", None, None, None, 12),
        ("order-events", "result", "ProvisionedThroughputExceeded spike", "error:ProvisionedThroughputExceededException", "success", "low", None, None, None, 18),
        ("checkout-2", "api_operation", "dynamodb:DeleteTable attempted", "dynamodb:DeleteTable", "dynamodb:GetItem, PutItem", "critical", ("dynamodb", "DeleteTable", "arn:aws:dynamodb:us-east-1:111111111111:table/orders"), None, None, 4),
        ("inventory", "user_agent_family", "Calls from a browser user agent", "browser", "aws-sdk-java", "medium", None, None, None, 13),
        ("report-builder", "result", "AccessDenied on s3:PutObject acme-reports", "error:AccessDenied", "success", "low", None, None, None, 2),
        ("thumbnailer", "source_network_class", "Calls from 185.220.101.47 (Tor exit)", "tor_exit", "vpc_private", "critical", ("s3", "ListBuckets", ""), "185.220.101.47", None, 4),
        ("jenkins", "user_agent_family", "Console-like user agent on an instance role", "browser", "aws-cli", "high", None, None, None, 22),
        ("payments-refunds", "resource_pattern", "SendMessage to an unknown queue", "arn:aws:sqs:us-east-1:111111111111:refund-events-tmp", "refund-events", "low", ("sqs", "SendMessage", "arn:aws:sqs:us-east-1:111111111111:refund-events-tmp"), None, None, 15),
        ("search", "source_network_class", "Calls from a public address", "public_internet", "vpc_private", "high", None, "203.0.113.200", None, 16),
    ]
    ANOM = [a for a in ANOM if a[1]]
    STATUSES = (["open"] * 22) + (["acknowledged"] * 8) + (["expected"] * 6) + (["suppressed"] * 5)
    random.shuffle(STATUSES)
    alerts = []
    for k, (name, dim, reason, observed, base, sev, opov, ipov, regov, hour) in enumerate(ANOM):
        i = by_name.get(name)
        if not i or name in learning or name in no_baseline:
            continue
        p = cts.P.get(name)
        days_ago = min(13, (k * 5) % 14)
        if p and p["last"] > days_ago:
            days_ago = min(13, p["last"])
        t = (NOW - dt.timedelta(days=days_ago)).replace(hour=hour % 24, minute=random.randint(0, 59), second=random.randint(0, 59))
        if t > NOW - dt.timedelta(minutes=10):
            t = NOW - dt.timedelta(minutes=random.randint(30, 200))
        prof = p or {"name": name, "acct": i["account_id"], "region": i["region"], "kind": "lambda", "ips": ["10.0.1.23"],
                     "ua": "py", "hours": "biz", "last": 0, "ops": []}
        if opov:
            src, en, res = opov
            o = cts.op(src, en, (res, "AWS::Resource") if res else cts.NONE, region=regov,
                       err="AccessDenied" if name in ("jenkins", "bastion") else None, err_rate=1.0)
        else:
            o = dict(random.choice(prof["ops"]) if prof["ops"] else cts.op("lambda", "GetFunction"))
            if regov:
                o["region"] = regov
            if dim == "result":
                o["err"], o["err_rate"] = (observed.split(":", 1)[1].split(" ")[0] if ":" in observed else "AccessDenied"), 1.0
        ev = cts.make_event(prof, o, t, ip=ipov or (cts.TOR if dim == "source_network_class" and not ipov else None))
        if dim == "user_agent_family":
            ev["user_agent"] = cts.UA["console"] if observed == "browser" else cts.UA["cli"]
        score = {"critical": random.randint(88, 99), "high": random.randint(70, 87), "medium": random.randint(45, 69), "low": random.randint(25, 44)}[sev]
        row = to_log(i, ev, anomalous=True, score=score, risk="anomalous")
        status = STATUSES[len(alerts) % len(STATUSES)]
        if sev == "critical" and status in ("expected", "suppressed"):
            status = "open"
        created = t + dt.timedelta(minutes=random.randint(2, 9))
        updated = created if status == "open" else min(NOW, created + dt.timedelta(hours=random.randint(1, 30)))
        alerts.append(dict(st=i["st"], key=i["key"], dimension=dim, reason=reason, status=status, severity=sev,
                           observed=observed, baseline=base, event_id=row["event_id"], score=score,
                           created=created, updated=updated, by=None if status == "open" else "alice@acme.test"))

    # ── Postgres rows ─────────────────────────────────────────────────────
    sql = [PG_DDL, "BEGIN;"]
    w = sql.append
    today = NOW.date()
    for i in monitored:
        name = i["name"]
        evs = sorted(per_ident.get(i["arn"], []), key=lambda x: x[0])
        counts = {}
        for t, r in evs:
            c = counts.setdefault(t.date(), dict(n=set(), acts=set(), err=0, anom=0))
            c["n"].add(r["event_id"])
            c["acts"].add(r["event_name"])
            c["err"] += 1 if r["error_code"] else 0
            c["anom"] += 1 if r["risk_status"] == "anomalous" else 0
        p = cts.P.get(name)
        key = i.get("workload_key") if name == "checkout-2" else i["key"]  # checkout-2: shared workload profile
        # daily_stats: 60 days; days in the log window use real counts, older days use the profile rate.
        for d in range(60, -1, -1):
            day = today - dt.timedelta(days=d)
            if p is None or d < (p["last"] if p else 0):
                continue
            if day in counts:
                c = counts[day]
                n, acts, err, anom = len(c["n"]), len(c["acts"]), c["err"], c["anom"]
            elif d >= DAYS:
                n = max(0, int(random.gauss(p["rate"] * RATE, 1.5)))
                acts, err, anom = min(n, len(p["ops"])), int(n * 0.02), 0
            else:
                continue
            if n:
                w(f"INSERT INTO {S}.daily_stats VALUES ({q(i['st'])}, {q(key)}, {q(day)}, {n}, {acts}, {err}, {anom});")
        if name in no_baseline:
            continue
        # profile from the identity's log events: per-dimension value counts
        prof = {}
        for _, r in evs:
            if r["risk_status"] == "anomalous":
                continue
            for dim, val in json.loads(r["dimensions_json"]).items():
                prof.setdefault(dim, {})
                prof[dim][val] = prof[dim].get(val, 0) + 1
        for dim in prof:  # keep the 12 most common values per dimension
            prof[dim] = dict(sorted(prof[dim].items(), key=lambda kv: -kv[1])[:12])
        if name in learning:
            built = learning[name]
            first_seen = today - dt.timedelta(days=built + random.randint(0, 2))
            status, active_since, remaining = "inactive", None, REQUIRED_DAYS - built
        else:
            built = REQUIRED_DAYS
            idle = i["idle_days"] or 0
            first_seen = today - dt.timedelta(days=int(idle) + random.randint(45, 80))
            active_since = dt.datetime.combine(first_seen + dt.timedelta(days=REQUIRED_DAYS), dt.time(2, 15), dt.timezone.utc)
            status, remaining = "active", 0
        meta = {"generated_by": "genome-pipeline", "window_days": REQUIRED_DAYS, "events": sum(prof.get("api_operation", {}).values()),
                "built_days": built}
        profile = {"_meta": meta, **prof}
        upd = NOW - dt.timedelta(hours=random.randint(1, 20))
        w(f"INSERT INTO {S}.baselines VALUES ({q(i['st'])}, {q(key)}, {q(status)}, {REQUIRED_DAYS}, {built}, {remaining}, "
          f"{q(first_seen)}, {q(active_since)}, {q(profile)}, {q(dt.datetime.combine(first_seen, dt.time(0, 5), dt.timezone.utc))}, {q(upd)});")
        if active_since:
            v, pub = 1, active_since
            while pub < NOW:
                vmeta = dict(meta, version=v)
                vprof = {"_meta": vmeta, **{d: dict(list(vals.items())[: max(1, len(vals) - (5 - min(v, 5)))]) for d, vals in prof.items()}}
                w(f"INSERT INTO {S}.baseline_versions (source_type, identity_name, version, published_at, profile_json) VALUES "
                  f"({q(i['st'])}, {q(key)}, {v}, {q(pub)}, {q(vprof)});")
                v += 1
                pub += dt.timedelta(days=7)
        # risk scores: one daily window per day for 14 days (latest window ends today 00:00)
        my_alerts = [a for a in alerts if a["key"] == i["key"]]
        for d in range(14, 0, -1):
            ws = dt.datetime.combine(today - dt.timedelta(days=d), dt.time(0), dt.timezone.utc)
            we = ws + dt.timedelta(days=1)
            c = counts.get(ws.date())
            n = len(c["n"]) if c else 0
            anom = c["anom"] if c else 0
            open_recent = [a for a in my_alerts if a["created"] < we and a["status"] in ("open", "acknowledged")]
            if status != "active":
                score, sev, st = None, "none", "insufficient_baseline"
            else:
                base = random.randint(4, 18)
                bump = sum({"critical": 30, "high": 18, "medium": 10, "low": 4}[a["severity"]] for a in open_recent
                           if (we - a["created"]).days < 7)
                score = min(99, base + bump + anom * 5)
                sev = "critical" if score >= 80 else "high" if score >= 60 else "medium" if score >= 30 else "low"
                st = "scored"
            w(f"INSERT INTO {S}.identity_risk_scores (source_type, identity_name, risk_score, severity, score_status, event_count, "
              f"anomalous_event_count, window_start, window_end, computed_at) VALUES ({q(i['st'])}, {q(key)}, {q(score)}, {q(sev)}, {q(st)}, "
              f"{n}, {anom}, {q(ws)}, {q(we)}, {q(we + dt.timedelta(minutes=12))});")
    for a in sorted(alerts, key=lambda a: a["created"]):
        w(f"INSERT INTO {S}.alerts (source_type, identity_name, dimension, reason, status, severity, observed_value, baseline_value, "
          f"event_id, event_risk_score, created_at, updated_at, decided_by) VALUES ({q(a['st'])}, {q(a['key'])}, {q(a['dimension'])}, "
          f"{q(a['reason'])}, {q(a['status'])}, {q(a['severity'])}, {q(a['observed'])}, {q(a['baseline'])}, {q(a['event_id'])}, "
          f"{a['score']}, {q(a['created'])}, {q(a['updated'])}, {q(a['by'])});")
    w("COMMIT;")
    path = os.path.join(HERE, "genome_seed.sql")
    with open(path, "w") as f:
        f.write(f"-- generated by genome_seed.py at {NOW.isoformat()}; re-run the .py to refresh relative times\n")
        f.write("\n".join(sql) + "\n")

    # ── apply ─────────────────────────────────────────────────────────────
    payload = "\n".join(json.dumps(e) for e in events)
    with open(os.path.join(HERE, "genome_log_events.jsonl"), "w") as f:
        f.write(payload + "\n" + "".join(json.dumps(e) + "\n" for e in rescored))
    if "--sql-only" in sys.argv:
        return
    psql_file(path)
    ch_exec(f"CREATE DATABASE IF NOT EXISTS {CH_DB}")
    ch_exec(f"DROP TABLE IF EXISTS {CH_DB}.{CH_TABLE}")
    ch_exec(CH_DDL)
    ch_exec(f"INSERT INTO {CH_DB}.{CH_TABLE} FORMAT JSONEachRow", payload)
    if rescored:
        ch_exec(f"INSERT INTO {CH_DB}.{CH_TABLE} FORMAT JSONEachRow", "\n".join(json.dumps(e) for e in rescored))
    res = ch_exec(f"SELECT count(), uniqExact(event_id), uniqExact(identity_name), countIf(risk_status='anomalous') FROM {CH_DB}.{CH_TABLE} FORMAT TSV")
    print(f"genome: {len(monitored)} monitored identities, {len(alerts)} alerts "
          f"({sum(a['status'] == 'open' for a in alerts)} open); log_events rows/uniq/identities/anomalous: {res.strip()}")


if __name__ == "__main__":
    main()
