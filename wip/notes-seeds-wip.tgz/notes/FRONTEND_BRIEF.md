# NHI console — frontend rebuild brief (shared by all page agents)

S = /tmp/claude-0/-home-user-Sample/2b3a3b2a-3f9d-593b-be57-05acaa96a9d4/scratchpad

## Mission
The console's design is the reference app `$S/main4/x_frontend/frontend` (read-only original; it runs on demo data in
`src/lib/demo/*`). Our working copy is `$S/fe5/frontend` (same code, being rewired). Your job: make your pages show
REAL data from the three Go services, keeping the design's look, layout, components and interaction quality exactly
(same visual language, panels, tables, drawers, charts, empty/loading/error states). Enterprise quality: think as the
end user (a cloud security engineer). Ask yourself "is this the best we can do?" at every screen.

Hard rules
1. No demo data in production paths. Do not import from `src/lib/demo/*` or call demo-backed functions in
   `src/lib/api/endpoints.js` (that file is legacy; it will be deleted). `src/lib/demo` will be deleted at the end.
   You may READ the demo modules to understand the shapes the design's components expect.
2. Never invent data. If the API has no source for something the design shows, either derive it honestly from real
   fields, or remove/hide that UI element (or show an honest "not available" state). Never fabricate numbers, names,
   trends or statuses. Never leave a control that does nothing.
3. Only edit files you own (see Ownership). If you need a change in a shared file, describe it in your final report
   (exact diff); do not make it. You may add new files inside your own feature folder and your own `src/lib/api/<area>.js`.
4. `cd $S/fe5/frontend && npx oxlint src` must report 0 errors (do not add new warnings in your files), and
   `npm run build` must pass. Do not change package.json or install packages.
5. Handle loading, empty, error (incl. 401/403/404/429/5xx and "service not configured") for every request. Use the
   design's existing `ui/*` components (EmptyState, ErrorState, InlineError, Skeleton, Panel, DataGrid, Drawer...).
6. Accessibility and responsiveness as good as the design (keyboard, focus, labels; works 1280px+ and on mobile widths).
7. No secrets, tokens or internal error text in the UI or console logs.

## Architecture already in place (do not modify these files)
- Proxy (vite.config.js; nginx in production), all same-origin:
  - `/api/v1/ispm/*` -> POSTURE service (local :8086)
  - `/genome-api/*`  -> GENOME service (local :8087), rewritten to `/api/v1/*` (genome's /identities clashes with main's)
  - `/api/*`         -> MAIN discovery service (local :8085)
- `src/lib/api/client.js` (default export `client`, axios): adds the bearer token, transparently refreshes the session on
  401 (single-use refresh tokens, cross-tab safe). Errors are rejected as `ApiError` {message, status, code, field,
  retryable, retryAfter} (see `src/lib/api/http.js`), already normalised across all services' error shapes.
- `src/lib/api/http.js` helpers: `unwrapMain(res)` -> data of `{success,message,data}`; `unwrapPosture(res)` ->
  `{data, page, meta}`; `unwrapGenome(res)` -> `{data, meta}`; `expectField(res, field)` for bare JSON; `params(obj)` drops
  empty values and joins arrays with commas (the APIs reject unknown or blank params - send only what is set).
- `src/lib/api/auth.js`, `src/app/AuthContext.jsx`: `useAuth()` -> {user:{email,name,team,role,serverRole,tenantId}, ...}.
- `src/app/WorkspaceContext.jsx`: `useWorkspace()` -> {hasConnectedAccount, exposureEnabled, canManage, domain, refresh}.
- `src/app/useAccess.js` + `src/lib/roles.js`: `can(permission)` / `lock(permission)`. Server roles map to console roles:
  admin->admin, analyst->analyst, others->viewer. Relevant permissions: `exposure.view|deepScan|review` (admin only - the
  API is admin-only), `posture.findings` (analyst+admin: PATCH posture findings), `integrations.manage` (admin),
  `data.view`, `data.export`. There are NO alerts, reports, users or scans APIs: those screens were removed. Genome is
  read-only (no anomaly status changes / containment) - hide such actions.
- `src/app/ScanContext.jsx` is a stub (no scan picker: the services serve the latest scan and scope by saved settings).
  Stop depending on it in your pages if you can.
- `src/lib/hooks/useQuery.js`: `useQuery(fetcher(signal), deps, {enabled, keepPrevious})` and `useMutation`.
  `useDemoQuery` is demo-only; replace it with `useQuery` (+ explicit `refetch` after mutations).
- Shared link helpers: `src/lib/identityLinks.js` (genome id/route for a discovery identity etc.) - use them for
  cross-page links so all pages agree.

## Ownership (only edit your own files)
- INVENTORY agent: `src/features/identities/*`, `src/features/credentials/*`, `src/features/activity/*`,
  `src/shell/CommandPalette.jsx`, new `src/lib/api/inventory.js`.
- DASHBOARD agent: `src/features/overview/*`, `src/features/exposure/*`, `src/charts/*`, new `src/lib/api/overview.js`.
  (`src/lib/api/exposure.js` exists and is real - use it; ask for changes via report.)
- POSTURE agent: `src/features/posture/*`, new `src/lib/api/posture.js`. Also provides the identity page's Posture tab:
  `PostureRecord` must render from `{ identity: { id, arn, name } }` where id is the DISCOVERY identity id (see Linking).
- GENOME agent: `src/features/genome/*`, new `src/lib/api/genome.js`.
- ACCESS agent: `src/features/access/*`, new `src/lib/api/access.js`.
- Lead (not you): app/*, shell/* (except CommandPalette), ui/*, lib/api/{client,http,session,auth,integrations,exposure}.js,
  lib/roles.js, lib/identityLinks.js, features/integrations/*, features/auth/*, vite.config.js, nginx, docs.

## Running and testing
- Backends run already (do not restart them; if one is down, say so in your report): MAIN :8085, POSTURE :8086,
  GENOME :8087 (sources: MAIN `$S/w5/nhi-backend`, POSTURE `$S/main4/x_backend_ispm_posture/nhi-backend`, GENOME
  `$S/main4/x_backend_nhi_genome/nhi-backend-final-genome (1)/nhi-backend-final/nhi-backend` - quote the path).
  Read their source for exact JSON field names (models' json tags) - it is the contract. A separate agent is seeding
  realistic data for posture/genome/ClickHouse events right now; if a service returns empty data early on, build
  against the contract and re-check later. Inventory data (41 identities, 51 credentials, trust edges) is in.
- Your own dev server: `cd $S/fe5/frontend && npx vite --port <YOUR_PORT> --strictPort` (INVENTORY 3101, DASHBOARD
  3102, POSTURE 3103, GENOME 3104, ACCESS 3105). Stop it when you finish.
- Login: alice@acme.test / Passw0rd! (admin, tenant_a). Viewer-role check: `UPDATE nhi_global.nhi_users SET role='user'
  WHERE email='bob@globex.test'` is tenant_b - instead create your own temporary viewer user in tenant_a if you need one
  and delete it after (bcrypt hash of Passw0rd!: copy alice's `password` column value).
  Postgres: PGPASSWORD=localpass psql "host=127.0.0.1 user=postgres dbname=nhi_db sslmode=require".
- Browser checks with Playwright: `NODE_PATH=$(npm root -g) node script.js`, launch
  `chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })`. Log in via the form
  (`#login-username`, `#login-password`, submit). Take screenshots of every state you build into `$S/shots/<area>/`
  and LOOK at them (Read tool). The ORIGINAL design runs on demo data at http://localhost:3199 (read-only reference;
  demo login: read `src/lib/demo/users.js` in the reference for a user and DEMO_PASSWORD - do not print it in reports).
  Screenshot the same screen there and compare: ours must look like the design, with real data.
  Check the browser console for errors.

## Linking identities across services
- MAIN identity: `id` (uuid), `arn`, `name`, `identity_type` (ec2_instance, lambda_function, ecs_task, iam_role,
  iam_user, step_function, glue_job, codebuild_project, ...), account_id, region.
- POSTURE identity: `identity_id` (uuid) + `identity_arn`. Do NOT assume posture ids equal discovery ids (in the local
  seed they do; in production they may not). Resolve by ARN: `GET /api/v1/ispm/identities?q=<arn>` (q = 2-100 runes,
  ILIKE on name/arn) and pick the exact `arn` match; fall back to "no posture score yet".
- GENOME identity: `(source_type, identity_name)` where identity_name is the canonical ARN; id string is
  `SOURCE_TYPE:identity_name`. Use `src/lib/identityLinks.js` (`genomeRouteFor`, `genomeSourceType`).
- Routes: identity page `/identities/:id` (discovery id, `?tab=`), posture tab `/identities/:id?tab=posture`,
  access graph `/access-graph?focus=<discovery id>` and `/access-graph/:id`, genome `/genome/:id` (id =
  encodeURIComponent(`SOURCE_TYPE:ARN`)), credentials `/credentials?search=...`.

## MAIN API (discovery) - envelope {success,message,data}; protected routes exist under /api/v1 and /api
Every handler rejects unknown query params (400 INVALID_QUERY_PARAM).
- GET /api/v1/me -> {user_id, tenant_id, db_name, role}
- GET /api/v1/filters -> {accounts[{account_id,identity_count,credential_count,is_default}], regions[{region,count}],
  identity_types[{type,count}], functional_classes[{class,count}], credential_types[{type,count}],
  environments[{environment,count}], statuses[{status,count}]}
- GET /api/v1/settings -> {settings:{accounts:{selected[],is_default}, regions:{selected[],is_default}}, source}
  PUT /api/v1/settings body {selected_account_ids[], selected_regions[]} (strict). This is the user's data scope.
- GET /api/v1/dashboard/overview (no params) -> {kpis{total_identities,total_credentials,orphaned_credentials,
  stale_identities,stale_credentials,publicly_accessible,shadow_identities,accounts_scanned,last_scan_time,
  permission_utilization_pct}, charts{identities_by_type[{type,count}], identities_by_functional_class[{class,count}],
  identities_by_account, identities_by_region, identities_by_environment, identities_by_status, identity_growth[{date,count}],
  credential_growth, stale_vs_active{active,stale}, credential_types, top_owners[{owner,count}],
  credentials_expiring_soon[{credential_name,expires_at,days_remaining}]}, activity_data_available}
- GET /api/v1/identities params page,page_size(<=100),search,identity_type,functional_class,environment,status (comma
  lists, enum-checked), owner,vpc_id,is_publicly_accessible,min_idle_days,sort_by,sort_order ->
  {pagination{page,page_size,total_count,total_pages}, data[IdentityListItem], activity_data_available}
- GET /api/v1/identities/{id}?tab=overview|permissions|activity|relationships|credentials|raw (+ time_range default 90d:
  N|Nd|all|custom with start_date,end_date; service, used_only, depth 1-3, edge_type, page, page_size<=100)
- GET /api/v1/identities/{id}/events?section=timeline|detail(event_id)|credentials|resources|heatmap|sessions|errors|
  cross_account|ips, time_range 1h|6h|24h(default)|7d|30d|90d|custom, filters service,action,result(success|error|all),
  resource,source_ip,credential,read_write(read|write|all), page, page_size(<=500)
- GET /api/v1/credentials (page,page_size,search,credential_type,status,owner_principal_arn,rotation_enabled,
  rotation_overdue,is_orphaned,has_external_trust,min_idle_days,max_days_until_expiry,sort_by,sort_order)
- GET /api/v1/credentials/{id}?tab=overview|trust|activity|rotation|relationships|raw (+time_range,start_date,end_date,
  depth,edge_type,page,page_size)
- relationships tab (identity and credential): {tab, graph:{nodes:[{arn,name,type(credential|identity|resource|unknown),
  subtype,is_current}], edges:[{source,target,edge_type,last_observed_at,call_count}]}, relationship_table:[{relationship,
  direction(inbound|outbound),target_arn,target_name,target_type,last_active,call_count}]}. edge_type enum: assume_role,
  bound_to, accesses, trusts, contains, manages, attached_to, uses, service_trust, cross_account, federated_oidc,
  federated_saml, created_by. Graph is scoped to the user's accounts/regions.
- GET /api/v1/permission-source?credential_id=&event_source=&event_name= -> {matched, policy_source, policy_type, effect,
  resource_arn, matched_action, note}
- Credential exposure (admin only, bare JSON) - see src/lib/api/exposure.js.
- Exact item shapes: read MAIN models (internal/models/v1/*.go) json tags.

## POSTURE API - prefix /api/v1/ispm, envelope {data, page?, meta{scan_id,computed_at,window,data_available}}
Errors {error:{code,message,field}}; strict params; rate limit 20 rps/tenant (429 + Retry-After); ETag/304 on GETs.
window: 24h|3d|7d|30d|60d|90d (default 30d); limit default 50 (>100 clamped); cursor opaque; CSV filters max 50 values.
1 GET /posture/overview?window -> {fleet{score,grade,band,identities_scored,change{window,previous,delta}},
  trend[{at,score}], distribution{healthy,fair,poor,critical}, identities_with{over_permissioned,stale_credentials,
  escalation_paths,exposed,dormant,trust_issues}, quick_wins[{rule_id,title,pillar,identities,fleet_gain}],
  pillars[{pillar,name,score,evaluated,failing,status PASS|WARN|FAIL}], weakest_identities[{identity_id,name,
  functional_class,account,score,band,checks_failed}], by_category[{functional_class,count,mean,change}],
  by_account[{account,count,mean,change}]}
2 GET /posture/quick-wins/{rule_id}/identities?limit,cursor -> {rule{rule_id,title,severity,penalty_points},
  identities[{identity_id,name,account,score,band,points_if_fixed,failing_since}]}
3 GET /posture/export?format=csv&<identity filters> -> CSV download
4 GET /identities?window,band,severity,category,account,type,pillar,failing_check,changed,q,sort(score|-score|failed|
  change|name),limit,cursor -> [{identity_id,name,type,functional_class,account{id,name},score,band,grade,weakest_pillar,
  failed{total,critical,high,medium,low},credential{type,age_days}|null,change{window,value}}]
5 GET /identities/facets?<filters> -> {total, band{}, severity{}, category{}, account{id:{name,count}}, type{}, pillar{}, changed{}}
6 GET /identities/{id} -> {identity_id,name,arn,type,functional_class,account{id,name},region,score,band,grade,
  badges{mfa_enabled,console_access},counts{credentials,open_alerts}}
7 GET /identities/{id}/posture?window -> {score,band,grade,points_lost,checks_failed,checks_evaluated,change,
  after_every_fix{score,delta},open_alerts,why_this_score,pillars[],score_impact[{rule_id,fix,points}],
  peer_group{functional_class,size,average,best,rank,standing}|null,bound_credentials[{type,id,age_days,last_used_days,status}]}
8 GET /identities/{id}/checks?status=failed|passed|all&pillar -> [{rule_id,title,status,severity,pillar,points_if_fixed,
  detail,failing_since,compliance[],finding_id}]
9 GET /identities/{id}/history?window -> [{at,score,band,checks_failed}]
10 GET /identities/{id}/credentials -> [{credential_arn,type,binding,status,age_days,last_used_days,usage_state,
  privileged,has_boundary,max_session_duration,open_findings}]
11 GET /identities/{id}/role-use -> {assumable, assumed_by[RoleUseItem], assumes[RoleUseItem]}
12 GET /identities/{id}/activity?window,mutating,service,limit,cursor -> [{event_time,action,service,source_ip,region,mutating,error_code}]
13 GET /identities/{id}/alerts?window,status=open|closed|all,limit,cursor -> [{finding_id,rule_id,title,severity,risk_score,
  status,raised_at,resolved_at,source}]
14 GET /identities/{id}/graph?depth(1-3),max_nodes(<=500),edge_types(BOUND_TO,CAN_ASSUME,TRUSTED_BY,CROSS_ACCOUNT) ->
  {nodes[{id(ARN),type,label,score?,privileged?}], edges[{source,target,type}], truncated}
15 GET /checks/{rule_id} -> {rule_id,title,severity,penalty_points,pillar,fix,remediation,compliance[],identities_failing}
16 PATCH /findings/{id} with header If-Match: "<updated_at>" body any of {status: ACCEPTED|SUPPRESSED|OPEN,
  accepted_reason (required for ACCEPTED), suppressed_until (future RFC3339, for SUPPRESSED), assigned_to, note} ->
  FindingState{finding_id,status,accepted_reason,suppressed_until,assigned_to,notes,updated_at}; 403 unless analyst/admin;
  409 stale If-Match. Read the posture source for any detail.

## GENOME API - via /genome-api/* (= service /api/v1/*), envelope {data, meta{request_id,generated_at,next_cursor}}
Errors {error:{code,message,request_id}}: VALIDATION_ERROR 400, IDENTITY_NOT_FOUND 404, STORE_UNAVAILABLE 503.
Missing monitoring data gives 200 with nulls/empty lists. Not admin-only. from/to (RFC3339 or YYYY-MM-DD; default last
14d), limit 1-100 (default 25), cursor = meta.next_cursor.
- GET /dashboard/summary?from,to,source_type,account_id,region -> {cards{baselines_established,identities_watched,
  still_learning,open_anomalies,critical_anomalies(null),baseline_coverage_percent,mean_provenance_confidence(null),
  mean_confidence_percent(null),drifting_baselines(null),drifting_baselines_available(false),window_hours},
  departures_by_dimension[{dimension,count}], anomalies_by_day[{day,count}], most_anomalous_identities[{id,source_type,
  identity_name,display_name,account_id,region,service_name,workload_key,risk_score,severity,score_status,event_count,
  anomalous_event_count,window_start,window_end,computed_at}], peer_group_outliers[{id,source_type,identity_name,
  display_name,peer_key,peer_count,risk_score,peer_mean_risk_score,anomaly_count,peer_mean_anomaly_count}],
  recently_baselined[{id,source_type,identity_name,display_name,account_id,region,event,occurred_at,version}]}
- GET /identities?source_type,search,account_id,region,status,sort(risk_desc|last_seen_desc|name_asc),limit,cursor ->
  {items[{id,source_type,identity_name,display_name,workload_key,status,account_id,region,service_name,role_type,role_arn,
  baseline{status,built_days,required_days},risk{score,severity,status},last_seen,open_anomaly_count,provenance_confidence(null)}]}
- GET /identities/{source_type}/{identity_name (URL-encoded ARN)}?from,to -> {identity{...,nhi_identity_type},risk,
  baseline_summary,headline_metrics{calls_in_window,open_anomalies,last_seen},links}
- .../activity?from,to,bucket(day|hour),recent_limit,recent_cursor -> {volume[{bucket,calls}], recent_calls[{event_id,
  event_time,api_call,resource,source_ip,region,risk_status,risk_score}], total_calls}
- .../genome?from,to,limit -> {fingerprint[{dimension,value,share_percent}], typical_actions[{api_operation,calls,
  share_percent}], typical_resources[{resource,resource_type,calls}], activity_schedule[{day_of_week 1-7 Mon=1,hour 0-23 UTC,calls}]}
- .../baseline?limit -> {status(active|inactive=learning),required_days,built_days,days_remaining,first_seen_date,
  active_since,updated_at,data_points,model_confidence_percent(null),model_confidence_available(false),
  dimensions[{dimension,ready,value_count}], versions[{version,published_at,profile{meta,dimensions}}]}
- .../timeline?limit,cursor -> {items[{type(anomaly|baseline_version_published|learning_started|baseline_established),
  title,description?,occurred_at,status?}]}
- .../peers?from,to,limit,cursor -> {peers[{identity_name,display_name,risk_score,open_anomaly_count,recent_call_count,
  outlier_dimension}]}
Read GENOME.md in the genome source for semantics. Anomaly list per se does not exist as an endpoint: anomalies appear
as timeline items (type=anomaly) and as counts.

## Final report (keep it under ~700 words)
What you changed (files), how each screen maps design -> API, what design elements you removed/changed because no API
supports them (and why), verification done (screenshots list + what you checked), lint/build status, any requested
changes to shared files (exact diff), and any backend bugs you hit (describe, don't fix).
