survey agents: main=a8983f9e333ff77e6 posture=ab563e896a145b9e9 genome=ad4171eebcfe1a812 design=a872197f5f3d0d758
work backend: /tmp/claude-0/-home-user-Sample/2b3a3b2a-3f9d-593b-be57-05acaa96a9d4/scratchpad/w5/nhi-backend
DECISIONS
- Our AWS APIs go into MAIN backend (work copy w5/nhi-backend). Pristine originals in main4/x_*.
- Integration table: <tenant_schema>.aws_accounts (user's columns + ours); scope rows still registered in <tenant_schema>.accounts.
- tenants: domain_name, collector_aws_account_id, collector_external_id, collector_event_bridge_arn, collector_regions(text[]; empty=all regions).
- Frontend routing: /api/v1/ispm/* -> posture (8086 local), /genome-api/* -> genome rewritten to /api/v1/* (8087), else main (8085).
- Posture: envelope {data,page,meta}, errors {error:{code,message,field}}, PATCH findings needs If-Match. Genome: {data,meta{request_id,generated_at,next_cursor}}, errors {error:{code,message,request_id}}.
- Main: {success,message,data}; credential-exposure bare JSON; login returns token+refresh_token (body), refresh POST /api/v1/refresh {refresh_token}.
- Re-query survey agents via SendMessage for details.
- Local: Postgres via su postgres pg_ctl -D /var/lib/pgtest/data -l /var/lib/pgtest/log start; nhi_db seeded by main seed_two_tenants.sh (tenant_a/tenant_b), users alice@acme.test / bob@globex.test pw Passw0rd!. run4/ has main-api(8085) posture-api(8086) genome-api(8087).
DESIGN FRONTEND (main4/x_frontend/frontend): demo data in src/lib/demo; access/genome/reports import demo directly. No github/codecommit connect flow in design (catalog.js marks them managed by scanner). Exposure gating there = role exposure.view only.
Pages w/o backend: alerts, reports, users, scans(commented). Plan: hide them (no fake data in prod), document.
GitHub exposure approach: token in client's Secrets Manager under prefix nhi/github, role gets secretsmanager:GetSecretValue on it; verify reads secret + calls GitHub API. CodeCommit: AWSCodeCommitReadOnly; verify ListRepositories per region + GetFolder.
- PRE-EXISTING: data race in main backend test fake identity_events_service_test.go:44 fakeEventStore.rec (test-only), go test -race fails TestHeatmapErrorsAndIPs on original code too.
/opt/ch/clickhouse server -- --path=/var/lib/chtest/ --tcp_port=9000 --http_port=8123 --listen_host=127.0.0.1 (cwd /var/lib/chtest)
