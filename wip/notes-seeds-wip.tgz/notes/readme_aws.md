## Connect AWS Account and exposed credentials (Integrations page)

Six endpoints back the console's Integrations page. They live in this service
(`internal/handlers/v1/aws_integration_handler.go`, service, repository,
`internal/awsconnect`, `internal/githubcheck`) and are mounted under both
`/api/v1` and `/api`. Reads are open to every signed-in user; changes need the
`admin` (or `super_admin`) role.

| Method | Path | What it does |
|---|---|---|
| GET | `/integrations/aws` | Setup values for this tenant, every connected account, `has_connected_account`, `exposure_enabled`, `can_manage` |
| POST | `/integrations/aws/verify` | `{role_arn, regions}` - runs the three checks, saves the account |
| PUT | `/integrations/aws/accounts/{id}/regions` | `{regions}` - regions a sync may read |
| PUT | `/integrations/aws/accounts/{id}/exposure` | `{github, codecommit, github_secret_arn}` - switch exposed-credential scanning on or off per platform |
| POST | `/integrations/aws/accounts/{id}/sync` | queue a discovery sync |
| DELETE | `/integrations/aws/accounts/{id}` | disconnect the account |

### Database

Apply once to `nhi_db` (both safe to run again):

```sh
psql "$DSN" -f migrations/global/003_tenant_collector.sql            # nhi_global.tenants columns
psql "$DSN" -v schema=bimasugam -f migrations/tenant/003_aws_accounts.sql   # per tenant schema
```

`nhi_global.tenants` gains `domain_name`, `collector_aws_account_id` (our
account the customer's role trusts), `collector_external_id` (generated, unique,
never change it once used), `collector_event_bridge_arn` (our central bus) and
`collector_regions` (regions customers may choose; empty means all).

`<tenant schema>.aws_accounts` holds one row per customer AWS account:
`client_aws_account_id`, `client_role_arn`, `regions`, `external_id`,
`is_connected`, `account_status` (`pending` / `connected` / `action_needed`),
`github_connected`, `codecommit_connected`, plus check results, the GitHub
secret ARN, and the sync queue columns. An AWS account can belong to one tenant
only (checked across schemas under an advisory lock).

The scanner's existing per-region scope table `<tenant schema>.accounts` is
kept in step: a connected account gets one row per allowed region, editing
regions updates them, removing the account deletes them. Dashboards, filters,
settings and ClickHouse isolation keep working unchanged.

Without the migrations the page answers 503 `AWS_PLATFORM_NOT_CONFIGURED`.

### Connection checks (verify)

| Check | How | Fix shown |
|---|---|---|
| Assume your role | `sts:AssumeRole` with the tenant's External ID | Check the trust policy / External ID |
| Read your account | `iam:ListRoles` (1 item) | Attach SecurityAudit + ViewOnlyAccess |
| Receive your events | allows the account on our bus, then looks for one of its events in the last `event_lookback_hours` (ClickHouse, else `event_log_group`) | Check the EventBridge rule target ARN |

One check per tenant at a time (429 `AWS_VERIFY_IN_PROGRESS`), 12 s budget.
Nothing is saved unless AssumeRole succeeds. The first full pass sets
`connected_at`, registers the scope rows and queues the first sync.

### Exposed credentials (GitHub / CodeCommit)

Only for an account that has connected. Each platform needs one extra grant on
the customer's existing role; the page shows the steps with their values filled in.

- **CodeCommit:** attach the AWS-managed `AWSCodeCommitReadOnly`, or an inline
  policy with `codecommit:ListRepositories, BatchGetRepositories, GetRepository,
  ListBranches, GetBranch, GetCommit, GetDifferences, GetBlob, GetFile,
  GetFolder, GitPull`. Checked by listing repositories in the account's regions
  and reading one repository's root folder.
- **GitHub:** a fine-grained token with *Contents: Read-only* (and
  *Metadata: Read-only*) stored in the customer's own Secrets Manager under a name
  starting with `github_secret_prefix` (`nhi/github`), and an inline policy on
  the role allowing `secretsmanager:GetSecretValue` and `DescribeSecret` on
  `arn:aws:secretsmanager:*:<account>:secret:nhi/github*` (plus `kms:Decrypt` if
  the secret uses a customer managed key). Checked by reading the secret through
  the role and calling GitHub (`/user`, `/user/repos`, one repository's
  contents). The token is never stored or logged; only the secret ARN is.

A platform is switched on only when its checks pass. `exposure_enabled` is
true when any account has one on; the console shows the exposed-credential
screens only then.

Secret scanner contract: scan CodeCommit where `codecommit_connected`, and the
GitHub token at `github_secret_arn` where `github_connected`, by assuming
`client_role_arn` with `external_id`.

### Sync contract (discovery worker)

The API only queues (`sync_status = 'queued'`). The worker claims one account
at a time per tenant schema:

```sql
UPDATE <schema>.aws_accounts SET sync_status = 'running', sync_started_at = now()
 WHERE client_aws_account_id = (
       SELECT client_aws_account_id FROM <schema>.aws_accounts
        WHERE sync_status = 'queued' ORDER BY sync_requested_at
        FOR UPDATE SKIP LOCKED LIMIT 1)
RETURNING client_aws_account_id, client_role_arn, external_id, regions;
```

It reads only `regions`, then sets `sync_status = 'succeeded', last_synced_at =
now(), last_sync_error = ''`, or `'failed'` with a short `last_sync_error`
(shown to the customer).

### AWS identity of this service

No AWS keys in config. The SDK default chain is used:

- **Production:** run the API as `NHIPlatformAssumer` (ECS task role / EC2
  instance profile) with `assume_assumer_role: false`.
- **Locally:** `AWS_PROFILE=<profile>` and `NHI_AWS_ASSUME_ASSUMER_ROLE=true`;
  the profile must be allowed to assume
  `arn:aws:iam::<collector_aws_account_id>:role/NHIPlatformAssumer`.

`NHIPlatformAssumer` needs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    { "Effect": "Allow", "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/NHIPlatformCollector" },
    { "Effect": "Allow",
      "Action": ["events:DescribeEventBus", "events:PutPermission", "events:RemovePermission"],
      "Resource": "arn:aws:events:<region>:<our account>:event-bus/<bus name>" },
    { "Effect": "Allow", "Action": "logs:FilterLogEvents",
      "Resource": "arn:aws:logs:<region>:<our account>:log-group:<event_log_group>:*" }
  ]
}
```

The last statement is only needed with `event_log_group`. Settings are under
`aws_integration` in `configs/config.yaml`, with `NHI_AWS_*` /
`NHI_GITHUB_API_URL` overrides (see `.env.example`). Each connected account adds
one statement to the bus policy (about 10 KB, roughly 100 accounts per bus).

### Errors

| HTTP | `error` | When |
|---|---|---|
| 400 | `INVALID_ROLE_ARN`, `INVALID_REGIONS`, `INVALID_SECRET_ARN`, `INVALID_ACCOUNT_ID`, `INVALID_REQUEST` | bad input |
| 403 | `FORBIDDEN` | not an admin |
| 404 | `AWS_ACCOUNT_NOT_FOUND` | not this tenant's account |
| 409 | `AWS_ACCOUNT_NOT_CONNECTED` | sync or exposure before the account has connected |
| 409 | `AWS_ACCOUNT_IN_USE` | account belongs to another tenant |
| 429 | `AWS_VERIFY_IN_PROGRESS` | a check is already running for this tenant |
| 503 | `AWS_PLATFORM_NOT_CONFIGURED` | migrations missing or the tenant row has no collector values |
| 503 | `AWS_UNAVAILABLE` | AWS unreachable, or this service has no AWS identity |

---

