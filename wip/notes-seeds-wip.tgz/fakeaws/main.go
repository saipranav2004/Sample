// Fake AWS for end-to-end runs: STS AssumeRole, IAM ListRoles, EventBridge
// Describe/Put/RemovePermission, CloudWatch Logs FilterLogEvents.
// A role ARN containing "denied" fails AssumeRole; "noread" fails ListRoles;
// account 555555555555 has no events.
package main

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
)

var (
	mu        sync.Mutex
	statements = map[string]bool{}
	lastRole  string
)

func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		target := r.Header.Get("X-Amz-Target")
		mu.Lock()
		defer mu.Unlock()
		switch {
		case strings.HasPrefix(target, "AWSEvents."):
			var in map[string]any
			_ = json.Unmarshal(body, &in)
			w.Header().Set("Content-Type", "application/x-amz-json-1.1")
			switch strings.TrimPrefix(target, "AWSEvents.") {
			case "DescribeEventBus":
				stmts := []map[string]string{}
				for sid := range statements {
					stmts = append(stmts, map[string]string{"Sid": sid})
				}
				pol, _ := json.Marshal(map[string]any{"Statement": stmts})
				_ = json.NewEncoder(w).Encode(map[string]any{"Name": in["Name"], "Policy": string(pol)})
			case "PutPermission":
				statements[in["StatementId"].(string)] = true
				log.Printf("PutPermission %v", in["StatementId"])
				_, _ = io.WriteString(w, `{}`)
			case "RemovePermission":
				delete(statements, in["StatementId"].(string))
				log.Printf("RemovePermission %v", in["StatementId"])
				_, _ = io.WriteString(w, `{}`)
			}
		case strings.HasPrefix(target, "CodeCommit_20150413."):
			w.Header().Set("Content-Type", "application/x-amz-json-1.1")
			if strings.Contains(lastRole, "nocc") {
				w.WriteHeader(400)
				_, _ = io.WriteString(w, `{"__type":"AccessDeniedException","message":"no"}`)
				return
			}
			switch strings.TrimPrefix(target, "CodeCommit_20150413.") {
			case "ListRepositories":
				if strings.Contains(lastRole, "norepo") {
					_, _ = io.WriteString(w, `{"repositories":[]}`)
				} else {
					_, _ = io.WriteString(w, `{"repositories":[{"repositoryName":"payments-api","repositoryId":"1"},{"repositoryName":"infra","repositoryId":"2"}]}`)
				}
			case "GetRepository":
				_, _ = io.WriteString(w, `{"repositoryMetadata":{"repositoryName":"payments-api","defaultBranch":"main"}}`)
			case "GetFolder":
				if strings.Contains(lastRole, "listonly") {
					w.WriteHeader(400)
					_, _ = io.WriteString(w, `{"__type":"AccessDeniedException","message":"no"}`)
					return
				}
				_, _ = io.WriteString(w, `{"commitId":"abc","folderPath":"/","files":[]}`)
			}
		case target == "secretsmanager.GetSecretValue":
			var in map[string]any
			_ = json.Unmarshal(body, &in)
			id, _ := in["SecretId"].(string)
			w.Header().Set("Content-Type", "application/x-amz-json-1.1")
			switch {
			case strings.Contains(id, "missing"):
				w.WriteHeader(400)
				_, _ = io.WriteString(w, `{"__type":"ResourceNotFoundException","Message":"no"}`)
			case strings.Contains(id, "denied"):
				w.WriteHeader(400)
				_, _ = io.WriteString(w, `{"__type":"AccessDeniedException","Message":"no"}`)
			case strings.Contains(id, "badtoken"):
				_, _ = io.WriteString(w, `{"ARN":"x","Name":"x","SecretString":"{\"token\":\"ghp_bad\"}"}`)
			default:
				_, _ = io.WriteString(w, `{"ARN":"x","Name":"x","SecretString":"ghp_good"}`)
			}
		case target == "Logs_20140328.FilterLogEvents":
			var in map[string]any
			_ = json.Unmarshal(body, &in)
			w.Header().Set("Content-Type", "application/x-amz-json-1.1")
			if strings.Contains(in["filterPattern"].(string), "555555555555") {
				_, _ = io.WriteString(w, `{"events":[]}`)
			} else {
				_, _ = io.WriteString(w, `{"events":[{"message":"{}","timestamp":1}]}`)
			}
		default:
			form, _ := url.ParseQuery(string(body))
			w.Header().Set("Content-Type", "text/xml")
			switch form.Get("Action") {
			case "AssumeRole":
				lastRole = form.Get("RoleArn")
				log.Printf("AssumeRole %s ExternalId=%s", lastRole, form.Get("ExternalId"))
				if strings.Contains(lastRole, "denied") {
					w.WriteHeader(403)
					_, _ = io.WriteString(w, `<ErrorResponse><Error><Type>Sender</Type><Code>AccessDenied</Code><Message>no</Message></Error><RequestId>1</RequestId></ErrorResponse>`)
					return
				}
				_, _ = io.WriteString(w, `<AssumeRoleResponse><AssumeRoleResult><Credentials><AccessKeyId>ASIACLIENT</AccessKeyId><SecretAccessKey>s</SecretAccessKey><SessionToken>t</SessionToken><Expiration>2099-01-01T00:00:00Z</Expiration></Credentials><AssumedRoleUser><Arn>a</Arn><AssumedRoleId>b</AssumedRoleId></AssumedRoleUser></AssumeRoleResult></AssumeRoleResponse>`)
			case "ListRoles":
				if strings.Contains(lastRole, "noread") {
					w.WriteHeader(403)
					_, _ = io.WriteString(w, `<ErrorResponse><Error><Type>Sender</Type><Code>AccessDenied</Code><Message>no</Message></Error><RequestId>1</RequestId></ErrorResponse>`)
					return
				}
				_, _ = io.WriteString(w, `<ListRolesResponse><ListRolesResult><IsTruncated>false</IsTruncated><Roles><member><Path>/</Path><RoleName>r</RoleName><RoleId>AROAX</RoleId><Arn>arn:aws:iam::1:role/r</Arn><CreateDate>2020-01-01T00:00:00Z</CreateDate></member></Roles></ListRolesResult></ListRolesResponse>`)
			default:
				w.WriteHeader(400)
			}
		}
	})
	log.Fatal(http.ListenAndServe("127.0.0.1:4566", nil))
}
