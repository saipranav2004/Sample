#!/usr/bin/env bash
# Restart the local test stack after a container restart. Idempotent: anything
# already running is left alone. Options:
#   --restart-apis   kill and restart main-api, posture-api and genome-api
#   --reseed         re-run the ClickHouse, posture and genome seeds (not inventory)
# Seed data that is missing (e.g. ClickHouse came back empty) is re-applied
# automatically before the APIs start, because MAIN/POSTURE/GENOME only connect
# to ClickHouse at startup.
S=/tmp/claude-0/-home-user-Sample/2b3a3b2a-3f9d-593b-be57-05acaa96a9d4/scratchpad
R=$S/run4
SEEDS=$S/seeds
export PGPASSWORD=localpass
PSQL=(psql "host=127.0.0.1 user=postgres dbname=nhi_db sslmode=require" -AtX)
RESTART=0; RESEED=0
for a in "$@"; do
  case $a in --restart-apis) RESTART=1 ;; --reseed) RESEED=1 ;; esac
done

# ── Postgres ────────────────────────────────────────────────────────────────
pg_isready -q -h 127.0.0.1 || su postgres -s /bin/bash -c "/usr/lib/postgresql/16/bin/pg_ctl -D /var/lib/pgtest/data -l /var/lib/pgtest/log -w start" >/dev/null

# ── ClickHouse ──────────────────────────────────────────────────────────────
if ! curl -s 'http://127.0.0.1:8123/ping' >/dev/null 2>&1; then
  (cd /var/lib/chtest && nohup /opt/ch/clickhouse server -- --path=/var/lib/chtest/ --tcp_port=9000 --http_port=8123 \
     --listen_host=127.0.0.1 --logger.log=/var/lib/chtest/server.log --logger.errorlog=/var/lib/chtest/error.log \
     > /var/lib/chtest/stdout.log 2>&1 &)
  for i in $(seq 1 60); do curl -s 'http://127.0.0.1:8123/ping' >/dev/null 2>&1 && break; sleep 1; done
fi
chq() { curl -s 'http://127.0.0.1:8123/' --data-binary "$1"; }

# ── Seeds (only what is missing, or everything with --reseed) ───────────────
if [ "$("${PSQL[@]}" -c "select count(*) from tenant_a.identities" 2>/dev/null)" = "0" ]; then
  echo "tenant_a inventory is empty: loading $SEEDS/inventory_seed.sql"
  "${PSQL[@]}" -q -f $SEEDS/inventory_seed.sql >/dev/null
fi
if [ $RESEED = 1 ] || [ "$(chq 'EXISTS TABLE nhi_events.cloudtrail_events')" != "1" ]; then
  echo "seeding ClickHouse CloudTrail events"; python3 $SEEDS/clickhouse_seed.py
fi
if [ $RESEED = 1 ] || [ "$("${PSQL[@]}" -c "select to_regclass('tenant_a.ispm_identity_posture') is not null")" != "t" ]; then
  echo "seeding posture tables"; python3 $SEEDS/posture_seed.py
fi
if [ $RESEED = 1 ] || [ "$(chq 'EXISTS TABLE nhi_monitoring.log_events')" != "1" ] \
   || [ "$("${PSQL[@]}" -c "select to_regclass('tenant_a.baselines') is not null")" != "t" ]; then
  echo "seeding genome tables"; python3 $SEEDS/genome_seed.py
fi

# ── Fakes ───────────────────────────────────────────────────────────────────
pgrep -x fakeaws >/dev/null || (cd $R && nohup $S/fakeaws/fakeaws > fakeaws.log 2>&1 &)
pgrep -x fakegh >/dev/null || (cd $R && nohup $S/fakegh/fakegh > fakegh.log 2>&1 &)

# ── APIs (always run from $R: each loads a .env from its cwd) ────────────────
if [ $RESTART = 1 ]; then pkill -x main-api; pkill -x posture-api; pkill -x genome-api; sleep 1; fi
# Genome's behaviour-monitoring ClickHouse (log_events) is configured only through env.
CHENV="NHI_MONITORING_CLICKHOUSE_HOST=127.0.0.1 NHI_MONITORING_CLICKHOUSE_PORT=8123 NHI_MONITORING_CLICKHOUSE_PROTOCOL=http NHI_MONITORING_CLICKHOUSE_DATABASE=nhi_monitoring NHI_MONITORING_CLICKHOUSE_TABLE=log_events NHI_MONITORING_CLICKHOUSE_USER=default NHI_MONITORING_CLICKHOUSE_PASSWORD= NHI_MONITORING_CLICKHOUSE_SECURE=false NHI_MONITORING_CLICKHOUSE_TIMEOUT_SECONDS=10"
[ -f $R/clickhouse.env ] && CHENV="$(cat $R/clickhouse.env)"
# MAIN and POSTURE read the CloudTrail ClickHouse from the clickhouse: block of their YAML configs.
pgrep -x main-api >/dev/null || (cd $R && env AWS_ENDPOINT_URL=http://127.0.0.1:4566 AWS_ACCESS_KEY_ID=AKIAPLATFORM AWS_SECRET_ACCESS_KEY=x AWS_REGION=ap-south-1 AWS_EC2_METADATA_DISABLED=true NHI_CONFIG_FILE=$R/main-config.yaml nohup ./main-api > main-api.log 2>&1 &)
pgrep -x posture-api >/dev/null || (cd $R && env NHI_CONFIG_FILE=$R/posture-config.yaml nohup ./posture-api > posture-api.log 2>&1 &)
pgrep -x genome-api >/dev/null || (cd $R && env $CHENV NHI_CONFIG_FILE=$R/genome-config.yaml nohup ./genome-api > genome-api.log 2>&1 &)

# ── Frontends ───────────────────────────────────────────────────────────────
curl -s -o /dev/null --max-time 2 http://127.0.0.1:3000/ || (cd $S/fe5/frontend && nohup npx vite --port 3000 --strictPort > $R/vite.log 2>&1 &)
curl -s -o /dev/null --max-time 2 http://127.0.0.1:3199/ || (cd $S/main4/x_frontend/frontend && SCANNER_UPSTREAM=http://127.0.0.1:9 SCANNER_DASHBOARD_KEY=none API_UPSTREAM=http://127.0.0.1:9 nohup npx vite --port 3199 --strictPort > $R/reference-vite.log 2>&1 &)

# ── Health ──────────────────────────────────────────────────────────────────
for i in $(seq 1 40); do
  ok=1
  for u in 8085/health 8086/health 8087/health 3000/ 3199/; do curl -s -o /dev/null http://127.0.0.1:$u || ok=0; done
  [ $ok = 1 ] && break; sleep 1
done
for u in 8085/health 8086/health 8087/health 3000/ 3199/ 8123/ping; do printf "%-14s %s\n" "$u" "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$u)"; done
printf "%-14s %s\n" "postgres" "$(pg_isready -h 127.0.0.1 >/dev/null && echo up || echo DOWN)"
printf "%-14s %s\n" "fakeaws" "$(pgrep -x fakeaws >/dev/null && echo up || echo DOWN)"
printf "%-14s %s\n" "fakegh" "$(pgrep -x fakegh >/dev/null && echo up || echo DOWN)"
printf "%-14s %s\n" "ch events" "$(chq 'SELECT count() FROM nhi_events.cloudtrail_events' 2>/dev/null)"
printf "%-14s %s\n" "ch log_events" "$(chq 'SELECT count() FROM nhi_monitoring.log_events' 2>/dev/null)"
for f in main-api posture-api genome-api; do
  printf "%-14s %s\n" "$f ch" "$(grep -h -o 'monitoring clickhouse connected\|clickhouse connected\|clickhouse unavailable\|monitoring clickhouse unavailable' $R/$f.log | sort -u | tr '\n' ';')"
done
