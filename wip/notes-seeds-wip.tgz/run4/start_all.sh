#!/usr/bin/env bash
# Restart the local test stack after a container restart. Idempotent.
S=/tmp/claude-0/-home-user-Sample/2b3a3b2a-3f9d-593b-be57-05acaa96a9d4/scratchpad
R=$S/run4
export PGPASSWORD=localpass
pg_isready -q -h 127.0.0.1 || su postgres -s /bin/bash -c "/usr/lib/postgresql/16/bin/pg_ctl -D /var/lib/pgtest/data -l /var/lib/pgtest/log -w start" >/dev/null
curl -s 'http://127.0.0.1:8123/?query=SELECT%201' >/dev/null 2>&1 || (cd /var/lib/chtest && nohup /opt/ch/clickhouse server -- --path=/var/lib/chtest/ --tcp_port=9000 --http_port=8123 --listen_host=127.0.0.1 --logger.log=/var/lib/chtest/server.log --logger.errorlog=/var/lib/chtest/error.log > /var/lib/chtest/stdout.log 2>&1 &)
pgrep -x fakeaws >/dev/null || (cd $R && nohup $S/fakeaws/fakeaws > fakeaws.log 2>&1 &)
pgrep -x fakegh >/dev/null || (cd $R && nohup $S/fakegh/fakegh > fakegh.log 2>&1 &)
CHENV=""
[ -f $R/clickhouse.env ] && CHENV="$(cat $R/clickhouse.env)"
pgrep -x main-api >/dev/null || (cd $R && env AWS_ENDPOINT_URL=http://127.0.0.1:4566 AWS_ACCESS_KEY_ID=AKIAPLATFORM AWS_SECRET_ACCESS_KEY=x AWS_REGION=ap-south-1 AWS_EC2_METADATA_DISABLED=true NHI_CONFIG_FILE=$R/main-config.yaml nohup ./main-api > main-api.log 2>&1 &)
pgrep -x posture-api >/dev/null || (cd $R && env NHI_CONFIG_FILE=$R/posture-config.yaml nohup ./posture-api > posture-api.log 2>&1 &)
pgrep -x genome-api >/dev/null || (cd $R && env $CHENV NHI_CONFIG_FILE=$R/genome-config.yaml nohup ./genome-api > genome-api.log 2>&1 &)
curl -s -o /dev/null --max-time 2 http://127.0.0.1:3000/ || (cd $S/fe5/frontend && nohup npx vite --port 3000 --strictPort > $R/vite.log 2>&1 &)
curl -s -o /dev/null --max-time 2 http://127.0.0.1:3199/ || (cd $S/main4/x_frontend/frontend && SCANNER_UPSTREAM=http://127.0.0.1:9 SCANNER_DASHBOARD_KEY=none API_UPSTREAM=http://127.0.0.1:9 nohup npx vite --port 3199 --strictPort > $R/reference-vite.log 2>&1 &)
for i in $(seq 1 40); do
  ok=1
  for u in 8085/health 8086/health 8087/health 3000/ 3199/; do curl -s -o /dev/null http://127.0.0.1:$u || ok=0; done
  [ $ok = 1 ] && break; sleep 1
done
for u in 8085/health 8086/health 8087/health 3000/ 3199/ 8123/ping; do printf "%-14s %s\n" "$u" "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$u)"; done
