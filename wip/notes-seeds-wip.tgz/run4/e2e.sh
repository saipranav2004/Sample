#!/usr/bin/env bash
set -u
B=localhost:8085/api/v1/integrations/aws
P() { psql "host=127.0.0.1 user=postgres dbname=nhi_db sslmode=require" -tAc "$1"; }
export PGPASSWORD=localpass
tok() { curl -s localhost:8085/api/v1/login -H 'content-type: application/json' -d "{\"email\":\"$1\",\"password\":\"Passw0rd!\"}" | python3 -c 'import sys,json;print(json.load(sys.stdin)["data"]["token"])'; }
A=$(tok alice@acme.test); Bt=$(tok bob@globex.test)
call() { local t=$1 m=$2 u=$3 d=${4:-}; if [ -n "$d" ]; then curl -s -X $m "$u" -H "authorization: Bearer $t" -H 'content-type: application/json' -d "$d" -w ' HTTP%{http_code}'; else curl -s -X $m "$u" -H "authorization: Bearer $t" -w ' HTTP%{http_code}'; fi; }
ok() { if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; FAILED=1; fi; }
FAILED=0
P "DELETE FROM tenant_a.aws_accounts; DELETE FROM tenant_b.aws_accounts; DELETE FROM tenant_a.accounts WHERE account_id IN ('222222222222','555555555555','777777777777')" >/dev/null
r=$(call $A POST $B/verify '{"role_arn":"arn:aws:iam::222222222222:role/NHIPlatformCollector","regions":["us-east-1","ap-south-1"]}')
ok "verify connects" '[[ "$r" == *"\"status\":\"connected\""* && "$r" == *"\"sync_queued\":true"* && "$r" == *HTTP200 ]]'
ok "row: user columns" '[[ "$(P "select client_role_arn||'"'"'|'"'"'||regions::text||'"'"'|'"'"'||is_connected||'"'"'|'"'"'||account_status||'"'"'|'"'"'||github_connected||codecommit_connected||'"'"'|'"'"'||sync_status||'"'"'|'"'"'||(external_id=(select collector_external_id from nhi_global.tenants where db_name='"'"'tenant_a'"'"')) from tenant_a.aws_accounts where client_aws_account_id='"'"'222222222222'"'"'")" == "arn:aws:iam::222222222222:role/NHIPlatformCollector|{us-east-1,ap-south-1}|true|connected|falsefalse|queued|true" ]]'
ok "scope rows registered" '[[ "$(P "select string_agg(region, '"'"','"'"' order by region) from tenant_a.accounts where account_id='"'"'222222222222'"'"' and is_default")" == "ap-south-1,us-east-1" ]]'
r=$(call $A POST $B/verify '{"role_arn":"arn:aws:iam::555555555555:role/NHIPlatformCollector","regions":["eu-west-1"]}')
ok "events missing -> pending" '[[ "$r" == *"\"status\":\"pending\""* && "$r" == *"Check the EventBridge rule target ARN"* ]]'
ok "pending not registered" '[[ "$(P "select count(*) from tenant_a.accounts where account_id='"'"'555555555555'"'"'")" == 0 ]]'
r=$(call $Bt POST localhost:8085/api/v1/integrations/aws/verify '{"role_arn":"arn:aws:iam::222222222222:role/NHIPlatformCollector","regions":["us-east-1"]}')
ok "other tenant cannot claim (no collector values -> 503, or 409)" '[[ "$r" == *HTTP503* || "$r" == *HTTP409* ]]'
P "UPDATE nhi_global.tenants SET collector_aws_account_id='189160505560', collector_event_bridge_arn='arn:aws:events:ap-south-1:189160505560:event-bus/nhi-central-bus' WHERE db_name='tenant_b'" >/dev/null
r=$(call $Bt POST localhost:8085/api/v1/integrations/aws/verify '{"role_arn":"arn:aws:iam::222222222222:role/NHIPlatformCollector","regions":["us-east-1"]}')
ok "other tenant claim -> 409 AWS_ACCOUNT_IN_USE" '[[ "$r" == *AWS_ACCOUNT_IN_USE* && "$r" == *HTTP409* ]]'
r=$(call $A PUT $B/accounts/555555555555/exposure '{"codecommit":true}')
ok "exposure on never-connected account -> 409" '[[ "$r" == *HTTP409* ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"codecommit":true}')
ok "codecommit enabled" '[[ "$r" == *"\"codecommit\":{\"connected\":true"* && "$r" == *"4 repositories in 2 regions"* && "$r" == *"\"exposure_enabled\":true"* ]]'
ok "db codecommit_connected" '[[ "$(P "select codecommit_connected||'"'"'|'"'"'||github_connected from tenant_a.aws_accounts where client_aws_account_id='"'"'222222222222'"'"'")" == "true|false" ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"codecommit":true,"github":true,"github_secret_arn":"arn:aws:secretsmanager:us-east-1:222222222222:secret:nhi/github-token-AbCdEf"}')
ok "github enabled (both on)" '[[ "$r" == *"\"github\":{\"connected\":true"* && "$r" == *"2 repositories visible as acme-scanner"* && "$r" == *"\"codecommit\":{\"connected\":true"* ]]'
ok "secret arn stored, token not stored" '[[ "$(P "select github_secret_arn from tenant_a.aws_accounts where client_aws_account_id='"'"'222222222222'"'"'")" == *nhi/github-token* && "$(P "select count(*) from tenant_a.aws_accounts where row_to_json(aws_accounts)::text like '"'"'%ghp_%'"'"'")" == 0 ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"codecommit":true,"github":true,"github_secret_arn":"arn:aws:secretsmanager:us-east-1:222222222222:secret:nhi/github-badtoken-AbCdEf"}')
ok "bad token -> github not connected with fix" '[[ "$r" == *"\"github\":{\"connected\":false"* && "$r" == *"Create a new token and update the secret"* && "$r" == *"Some checks need attention"* ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"github":true,"github_secret_arn":"arn:aws:secretsmanager:us-east-1:222222222222:secret:nhi/github-missing-AbCdEf"}')
ok "missing secret fix; codecommit turned off" '[[ "$r" == *"Check the secret ARN"* && "$r" == *"\"codecommit\":{\"connected\":false,\"checks\":[]"* ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"github":true,"github_secret_arn":"arn:aws:secretsmanager:us-east-1:999999999999:secret:nhi/github-x"}')
ok "secret in other account -> 400" '[[ "$r" == *INVALID_SECRET_ARN* && "$r" == *HTTP400* ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"github":true,"github_secret_arn":"arn:aws:secretsmanager:us-east-1:222222222222:secret:other/token-AbCdEf"}')
ok "secret outside prefix -> 400" '[[ "$r" == *"starting with nhi/github"* ]]'
r=$(call $A PUT $B/accounts/222222222222/exposure '{"github":false,"codecommit":false}')
ok "all off -> exposure disabled" '[[ "$r" == *"\"exposure_enabled\":false"* && "$r" == *HTTP200* ]]'
r=$(call $A PUT $B/accounts/222222222222/regions '{"regions":["eu-west-1","us-east-1"]}')
ok "regions updated + scope follows" '[[ "$r" == *HTTP200* && "$(P "select string_agg(region, '"'"','"'"' order by region) from tenant_a.accounts where account_id='"'"'222222222222'"'"'")" == "eu-west-1,us-east-1" ]]'
r=$(call $A POST $B/accounts/222222222222/sync)
ok "sync while queued -> already_queued 202" '[[ "$r" == *"\"already_queued\":true"* && "$r" == *HTTP202* ]]'
P "UPDATE tenant_a.aws_accounts SET sync_status='succeeded', last_synced_at=now()" >/dev/null
r=$(call $A POST $B/accounts/222222222222/sync)
ok "sync queued 202" '[[ "$r" == *"\"already_queued\":false"* && "$r" == *HTTP202* ]]'
r=$(call $A POST $B/accounts/555555555555/sync)
ok "sync pending account -> 409" '[[ "$r" == *AWS_ACCOUNT_NOT_CONNECTED* ]]'
P "UPDATE nhi_global.tenants SET collector_regions='{us-east-1,eu-west-1}' WHERE db_name='tenant_a'" >/dev/null
r=$(call $A PUT $B/accounts/222222222222/regions '{"regions":["ap-south-1"]}')
ok "collector_regions restricts choices" '[[ "$r" == *INVALID_REGIONS* && "$r" == *"not available for your workspace"* ]]'
ok "setup lists only collector regions" '[[ "$(curl -s $B -H "authorization: Bearer $A" | python3 -c "import sys,json;print(len(json.load(sys.stdin)[\"data\"][\"setup\"][\"regions\"]))")" == 2 ]]'
P "UPDATE nhi_global.tenants SET collector_regions='{}' WHERE db_name='tenant_a'" >/dev/null
r=$(call $A DELETE $B/accounts/222222222222)
ok "remove" '[[ "$r" == *HTTP200* && "$(P "select count(*) from tenant_a.aws_accounts where client_aws_account_id='"'"'222222222222'"'"'")" == 0 && "$(P "select count(*) from tenant_a.accounts where account_id='"'"'222222222222'"'"'")" == 0 ]]'
r=$(call $A DELETE $B/accounts/222222222222)
ok "remove again -> 404" '[[ "$r" == *HTTP404* ]]'
r=$(call $Bt POST localhost:8085/api/v1/integrations/aws/verify '{"role_arn":"arn:aws:iam::222222222222:role/NHIPlatformCollector","regions":["us-east-1"]}')
ok "after removal tenant B can claim it" '[[ "$r" == *"\"saved\":true"* ]]'
P "UPDATE nhi_global.nhi_users SET role='user' WHERE email='alice@acme.test'" >/dev/null
U=$(tok alice@acme.test)
r=$(call $U GET $B); ok "non-admin GET: no setup" '[[ "$r" == *"\"setup\":null"* && "$r" == *HTTP200* ]]'
r=$(call $U PUT $B/accounts/555555555555/exposure '{"codecommit":true}'); ok "non-admin write -> 403" '[[ "$r" == *HTTP403* ]]'
P "UPDATE nhi_global.nhi_users SET role='admin' WHERE email='alice@acme.test'" >/dev/null
r=$(call $A PUT "$B/accounts/555555555555/exposure?x=1" '{"codecommit":true}'); ok "unknown query -> 400" '[[ "$r" == *HTTP400* ]]'
r=$(call $A PUT $B/accounts/555555555555/exposure '{"codecommit":true,"extra":1}'); ok "unknown field -> 400" '[[ "$r" == *HTTP400* ]]'
echo "FAILED=$FAILED"
