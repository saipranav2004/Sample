// Fake GitHub API: token ghp_good works; anything else is 401.
package main

import (
	"io"
	"log"
	"net/http"
	"strings"
)

func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer ghp_good" {
			w.WriteHeader(401)
			_, _ = io.WriteString(w, `{"message":"Bad credentials"}`)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/user":
			_, _ = io.WriteString(w, `{"login":"acme-scanner"}`)
		case r.URL.Path == "/user/repos":
			_, _ = io.WriteString(w, `[{"full_name":"acme/payments"},{"full_name":"acme/web"}]`)
		case strings.HasPrefix(r.URL.Path, "/repos/acme/payments/contents"):
			_, _ = io.WriteString(w, `[]`)
		default:
			w.WriteHeader(404)
		}
	})
	log.Fatal(http.ListenAndServe("127.0.0.1:4567", nil))
}
