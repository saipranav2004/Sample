import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Globe2,
  KeyRound,
  Loader2,
  MapPin,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  XCircle,
} from 'lucide-react';
import { removeAwsAccount, syncAwsAccount, updateAwsAccountRegions, verifyAwsConnection } from '../../lib/api/integrations';
import { formatDateTime, formatRelative } from '../../lib/format';
import { Button } from '../../ui/Button';
import { CopyButton } from '../../ui/Copyable';
import { Field, Input } from '../../ui/Field';
import { Menu } from '../../ui/Menu';
import { Modal } from '../../ui/Overlay';
import { Panel } from '../../ui/Panel';
import { InlineError } from '../../ui/States';
import { useToast } from '../../ui/Toast';
import { cn } from '../../ui/cn';
import { ACCOUNT_STATUS } from './awsSetup';
import { AwsMark } from './parts';
import { ExposureBadges } from './ExposureBadges';
import { CheckDots, CheckList } from './CheckList';
import { RegionPicker } from './RegionPicker';

const GRID = '@min-[62rem]:grid-cols-[minmax(0,1.45fr)_minmax(0,1fr)_minmax(0,0.7fr)_minmax(0,0.95fr)_minmax(0,1fr)_auto]';

const SYNC = {
  idle: { label: 'Not synced yet', icon: Clock3, tone: 'text-ink-3' },
  queued: { label: 'Queued', icon: Clock3, tone: 'text-info' },
  running: { label: 'Syncing', icon: Loader2, tone: 'text-brand', spin: true },
  succeeded: { label: 'Synced', icon: CheckCircle2, tone: 'text-low' },
  failed: { label: 'Sync failed', icon: XCircle, tone: 'text-critical' },
};

/**
 * Every account the workspace has connected: what it reads (regions), whether
 * the connection holds (checks), and how fresh its data is (sync) - with the
 * actions an admin takes on one account in reach: sync it now, change its
 * regions, re-run the checks, remove it.
 */
export function AccountsTable({ accounts, catalogue, canManage, onChanged, onRemoved, onAdd, onExposure }) {
  const [editing, setEditing] = useState(null);
  const [removing, setRemoving] = useState(null);
  const connectedCount = accounts.filter((account) => account.status === 'connected').length;

  return (
    <Panel flush className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3.5 sm:px-5">
        <div>
          <h2 className="text-[14.5px] font-semibold text-ink">
            AWS accounts <span className="font-normal text-ink-3" data-numeric="">· {accounts.length}</span>
          </h2>
          <p className="mt-0.5 text-[12px] text-ink-3">Read-only access through the role you created in each account.</p>
        </div>
        {onAdd && (
          <Button variant="primary" size="sm" icon={Plus} onClick={onAdd}>
            Connect another account
          </Button>
        )}
      </div>
      <div
        aria-hidden="true"
        className={cn('hidden gap-4 border-b border-line bg-surface-2 px-5 py-2 text-[11px] font-medium text-ink-3 @min-[62rem]:grid', GRID)}
      >
        <span>Account</span>
        <span>Regions</span>
        <span>Checks</span>
        <span>Data</span>
        <span>Exposed credentials</span>
        <span className="w-[164px]" />
      </div>
      <ul className="divide-y divide-line">
        {accounts.map((account) => (
          <AccountRow
            key={account.accountId}
            account={account}
            catalogue={catalogue}
            canManage={canManage}
            onChanged={onChanged}
            onEdit={() => setEditing(account)}
            onRemove={() => setRemoving(account)}
            onExposure={onExposure ? () => onExposure(account) : null}
          />
        ))}
      </ul>

      <EditRegionsModal
        account={editing}
        catalogue={catalogue}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          onChanged?.();
        }}
      />
      <RemoveAccountModal
        account={removing}
        lastConnected={removing?.status === 'connected' && connectedCount === 1}
        onClose={() => setRemoving(null)}
        onRemoved={(accountId) => {
          setRemoving(null);
          onRemoved?.(accountId);
        }}
      />
    </Panel>
  );
}

function AccountRow({ account, catalogue, canManage, onChanged, onEdit, onRemove, onExposure }) {
  const { notify } = useToast();
  const [busy, setBusy] = useState('');
  const attention = account.status !== 'connected';
  const [open, setOpen] = useState(attention);
  const meta = ACCOUNT_STATUS[account.status] ?? ACCOUNT_STATUS.action_needed;
  const sync = SYNC[account.sync.status] ?? SYNC.idle;
  const SyncIcon = sync.icon;
  const syncing = account.sync.status === 'queued' || account.sync.status === 'running';
  const names = useMemo(() => new Map(catalogue.map((region) => [region.code, region.name])), [catalogue]);
  const passed = account.checks.filter((check) => check.state === 'pass').length;

  const runSync = async () => {
    setBusy('sync');
    try {
      const result = await syncAwsAccount({ accountId: account.accountId });
      notify(
        result.alreadyQueued
          ? { variant: 'info', title: 'A sync is already on its way', description: `${account.accountId} is queued or syncing now.` }
          : {
              variant: 'success',
              title: `Sync queued for ${account.accountId}`,
              description: `Reading ${account.regions.length} ${account.regions.length === 1 ? 'region' : 'regions'}. This page updates as it runs.`,
            },
      );
      onChanged?.();
    } catch (error) {
      notify({ variant: 'error', title: 'Could not start the sync', description: error?.message });
    } finally {
      setBusy('');
    }
  };

  const recheck = async () => {
    if (account.regions.length === 0) {
      notify({ variant: 'info', title: 'Choose regions first', description: 'This account has no regions to read yet.' });
      onEdit();
      return;
    }
    setBusy('check');
    try {
      const outcome = await verifyAwsConnection({ roleArn: account.roleArn, regions: account.regions });
      const failing = outcome.checks.find((check) => check.state !== 'pass');
      notify(
        outcome.status === 'connected'
          ? { variant: 'success', title: `${account.accountId} is healthy`, description: 'All three checks passed.' }
          : {
              variant: 'error',
              title: `${account.accountId}: ${failing?.label ?? 'a check'} did not pass`,
              description: failing?.fix || failing?.message,
            },
      );
      if (outcome.saved) onChanged?.();
    } catch (error) {
      notify({ variant: 'error', title: 'Could not run the checks', description: error?.message });
    } finally {
      setBusy('');
    }
  };

  const syncBlocked = attention
    ? 'Verify the connection before syncing'
    : syncing
      ? 'A sync is already queued or running'
      : account.regions.length === 0
        ? 'Choose regions to read first'
        : '';

  return (
    <li className="px-4 py-3.5 transition-colors hover:bg-surface-2/50 sm:px-5">
      <div className={cn('grid items-center gap-x-4 gap-y-3', GRID)}>
        {/* Account */}
        <div className="flex min-w-0 items-center gap-3">
          <AwsMark size="sm" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[13.5px] font-semibold text-ink">{account.accountId}</span>
              <span className={cn('text-[11.5px] font-medium', { low: 'text-low', info: 'text-info' }[meta.tone] ?? 'text-medium')}>{meta.label}</span>
            </div>
            <div className="mt-0.5 flex min-w-0 items-center gap-1">
              <span className="truncate font-mono text-[11.5px] text-ink-3" title={account.roleArn}>
                {account.roleArn}
              </span>
              <CopyButton value={account.roleArn} label="Copy role ARN" size="sm" />
            </div>
          </div>
        </div>

        {/* Regions */}
        <div className="min-w-0">
          {account.regions.length === 0 ? (
            <span className="inline-flex items-center gap-1.5 text-[12px] font-medium text-medium">
              <AlertTriangle aria-hidden="true" className="size-3.5" />
              No regions chosen
            </span>
          ) : (
            <div className="flex flex-wrap items-center gap-1" title={account.regions.map((code) => names.get(code) ?? code).join('\n')}>
              <MapPin aria-hidden="true" className="mr-0.5 size-3.5 shrink-0 text-ink-3" />
              {account.regions.slice(0, 2).map((code) => (
                <span key={code} className="rounded border border-line bg-surface-2 px-1.5 py-0.5 font-mono text-[11px] text-ink-2">
                  {code}
                </span>
              ))}
              {account.regions.length > 2 && (
                <span className="rounded px-1 text-[11.5px] font-medium text-ink-3">+{account.regions.length - 2}</span>
              )}
            </div>
          )}
        </div>

        {/* Checks */}
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          className="inline-flex w-fit items-center gap-2 rounded-md px-1.5 py-1 text-[12px] text-ink-2 transition-colors hover:bg-surface-3"
        >
          <CheckDots checks={account.checks} />
          {account.checks.length ? `${passed}/3` : 'No results'}
          <ChevronDown aria-hidden="true" className={cn('size-3.5 text-ink-3 transition-transform', open && 'rotate-180')} />
        </button>

        {/* Data freshness */}
        <div className="min-w-0 text-[12px]" aria-live="polite">
          <span className={cn('inline-flex items-center gap-1.5 font-medium', sync.tone)}>
            <SyncIcon aria-hidden="true" className={cn('size-3.5', sync.spin && 'animate-spin')} />
            {sync.label}
          </span>
          <span className="block truncate text-[11.5px] text-ink-3" title={account.sync.lastError || undefined}>
            {account.sync.status === 'failed' && account.sync.lastError
              ? account.sync.lastError
              : account.sync.status === 'running' && account.sync.startedAt
                ? `Started ${formatRelative(account.sync.startedAt)}`
                : account.sync.status === 'queued' && account.sync.requestedAt
                  ? `Requested ${formatRelative(account.sync.requestedAt)}`
                  : account.sync.lastSyncedAt
                    ? `Last ${formatRelative(account.sync.lastSyncedAt)}`
                    : attention
                      ? 'After the checks pass'
                      : 'Starts automatically'}
          </span>
        </div>

        {/* Exposed credentials */}
        <div className="min-w-0">
          <ExposureBadges account={account} onOpen={canManage && onExposure && account.connectedAt ? onExposure : null} />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 @min-[62rem]:w-[164px] @min-[62rem]:justify-end">
          {canManage && (
            <>
              <span title={syncBlocked || undefined}>
                <Button
                  variant="secondary"
                  size="sm"
                  icon={RefreshCw}
                  loading={busy === 'sync'}
                  disabled={Boolean(syncBlocked) || Boolean(busy)}
                  onClick={runSync}
                  aria-label={`Sync ${account.accountId} now`}
                >
                  Sync now
                </Button>
              </span>
              <Menu
                label={`More actions for ${account.accountId}`}
                items={[
                  { key: 'regions', label: 'Edit regions', icon: Globe2, onSelect: onEdit, disabled: Boolean(busy) },
                  onExposure && account.connectedAt
                    ? { key: 'exposure', label: 'Exposed credentials…', icon: KeyRound, onSelect: onExposure, disabled: Boolean(busy) }
                    : null,
                  { key: 'check', label: busy === 'check' ? 'Checking…' : 'Re-check connection', icon: ShieldCheck, onSelect: recheck, disabled: Boolean(busy) },
                  { key: 'remove', label: 'Remove account', icon: Trash2, onSelect: onRemove, tone: 'critical', disabled: Boolean(busy) },
                ]}
              />
            </>
          )}
        </div>
      </div>

      {open && (
        <div className="mt-3 rounded-[var(--radius-control)] border border-line bg-surface-2 px-3 py-1 @min-[62rem]:ml-11">
          <CheckList checks={account.checks} />
          {account.lastVerifiedAt && (
            <p className="border-t border-line py-1.5 text-[11.5px] text-ink-3" title={formatDateTime(account.lastVerifiedAt)}>
              Checked {formatRelative(account.lastVerifiedAt)}
              {account.lastVerifiedBy ? ` by ${account.lastVerifiedBy}` : ''}
            </p>
          )}
        </div>
      )}
    </li>
  );
}

/* ── Edit regions ──────────────────────────────────────────────────────── */

function EditRegionsModal({ account, catalogue, onClose, onSaved }) {
  return (
    <Modal
      open={Boolean(account)}
      onClose={onClose}
      icon={Globe2}
      title={account ? `Regions for ${account.accountId}` : ''}
      description="We read regional resources only in the regions you allow."
    >
      {/* Keyed by account so every opening starts from that account's regions. */}
      {account && <EditRegionsBody key={account.accountId} account={account} catalogue={catalogue} onClose={onClose} onSaved={onSaved} />}
    </Modal>
  );
}

function EditRegionsBody({ account, catalogue, onClose, onSaved }) {
  const { notify } = useToast();
  const [regions, setRegions] = useState(account.regions);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const before = new Set(account.regions);
  const after = new Set(regions);
  const added = regions.filter((code) => !before.has(code));
  const removed = account.regions.filter((code) => !after.has(code));
  const changed = added.length > 0 || removed.length > 0;

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      await updateAwsAccountRegions({ accountId: account.accountId, regions });
      notify({
        variant: 'success',
        title: 'Regions updated',
        description: added.length ? 'Sync now to read the new regions.' : 'The next sync reads only these regions.',
      });
      onSaved();
    } catch (failure) {
      setError(failure);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 px-5 pb-5">
      <RegionPicker
        catalogue={catalogue}
        value={regions}
        onChange={setRegions}
        defaultExpanded
        error={regions.length === 0 ? 'Choose at least one region.' : undefined}
      />
      {changed && (
        <div className="rounded-[var(--radius-control)] bg-surface-2 px-3 py-2 text-[12px] leading-relaxed text-ink-2">
          {added.length > 0 && (
            <p>
              <span className="font-semibold text-low">Adding</span> <span className="font-mono">{added.join(', ')}</span> - create the
              EventBridge rule in {added.length === 1 ? 'that region' : 'those regions'} too.
            </p>
          )}
          {removed.length > 0 && (
            <p>
              <span className="font-semibold text-critical">Removing</span> <span className="font-mono">{removed.join(', ')}</span> - its
              records leave your dashboards.
            </p>
          )}
        </div>
      )}
      {error && <InlineError error={error} label="Not saved" />}
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose} disabled={saving}>
          Cancel
        </Button>
        <Button variant="primary" onClick={save} loading={saving} disabled={!changed || regions.length === 0}>
          Save regions
        </Button>
      </div>
    </div>
  );
}

/* ── Remove ────────────────────────────────────────────────────────────── */

function RemoveAccountModal({ account, lastConnected, onClose, onRemoved }) {
  return (
    <Modal
      open={Boolean(account)}
      onClose={onClose}
      icon={Trash2}
      tone="critical"
      title={account ? `Remove AWS account ${account.accountId}?` : ''}
      description="You can connect it again at any time."
    >
      {account && (
        <RemoveAccountBody key={account.accountId} account={account} lastConnected={lastConnected} onClose={onClose} onRemoved={onRemoved} />
      )}
    </Modal>
  );
}

function RemoveAccountBody({ account, lastConnected, onClose, onRemoved }) {
  const { notify } = useToast();
  const [typed, setTyped] = useState('');
  const [removing, setRemoving] = useState(false);
  const [error, setError] = useState(null);
  const confirmed = typed.trim() === account.accountId;

  const remove = async () => {
    setRemoving(true);
    setError(null);
    try {
      await removeAwsAccount({ accountId: account.accountId });
      notify({ variant: 'success', title: `${account.accountId} removed`, description: 'Delete the role and rule in that AWS account to finish.' });
      onRemoved(account.accountId);
    } catch (failure) {
      setError(failure);
      setRemoving(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 px-5 pb-5">
      <ul className="flex flex-col gap-1.5 text-[12.5px] leading-relaxed text-ink-2">
        <li className="flex gap-2">
          <span aria-hidden="true" className="mt-[7px] size-1.5 shrink-0 rounded-full bg-ink-3" />
          We stop reading this account and refuse the events it forwards.
        </li>
        <li className="flex gap-2">
          <span aria-hidden="true" className="mt-[7px] size-1.5 shrink-0 rounded-full bg-ink-3" />
          Its identities and credentials leave your dashboards and lists.
        </li>
        <li className="flex gap-2">
          <span aria-hidden="true" className="mt-[7px] size-1.5 shrink-0 rounded-full bg-ink-3" />
          Nothing changes in the AWS account itself - delete the role and the EventBridge rule there.
        </li>
      </ul>
      {lastConnected && (
        <p className="flex items-start gap-2 rounded-[var(--radius-control)] border border-medium/30 bg-medium-soft px-3 py-2 text-[12.5px] text-ink-2">
          <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-medium" />
          This is your only connected account. Until you connect another, the console shows only the setup.
        </p>
      )}
      <Field label={`Type ${account.accountId} to confirm`} htmlFor="remove-account-confirm">
        <Input
          id="remove-account-confirm"
          value={typed}
          onChange={(event) => setTyped(event.target.value)}
          inputMode="numeric"
          autoComplete="off"
          spellCheck={false}
          className="font-mono"
          placeholder={account.accountId}
        />
      </Field>
      {error && <InlineError error={error} label="Not removed" />}
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose} disabled={removing}>
          Cancel
        </Button>
        <Button variant="danger" icon={Trash2} onClick={remove} loading={removing} disabled={!confirmed}>
          Remove account
        </Button>
      </div>
    </div>
  );
}
