import { createContext, useContext, useMemo } from 'react';

/**
 * Scan scope. The services serve the latest completed scan and scope by the
 * accounts and regions saved to the user's settings, so there is no scan to
 * pick; this keeps the shape older screens read while they move off it.
 */
const ScanContext = createContext(null);

const LATEST = {
  selectedScanId: '',
  setSelectedScanId: () => {},
  scans: [],
  activeScan: null,
  isLatest: true,
  loading: false,
  error: null,
  refetch: () => {},
};

export function ScanProvider({ children }) {
  const value = useMemo(() => LATEST, []);
  return <ScanContext.Provider value={value}>{children}</ScanContext.Provider>;
}

export function useScanContext() {
  return useContext(ScanContext) ?? LATEST;
}
