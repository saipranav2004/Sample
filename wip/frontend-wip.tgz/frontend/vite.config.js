import { fileURLToPath } from 'node:url';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/**
 * Three Go services sit behind this app. They share one database and one JWT
 * secret, so the token from signing in works on all of them:
 *
 *   /api/v1/ispm/*  -> ISPM posture API        (POSTURE_UPSTREAM)
 *   /genome-api/*   -> NHI Genome API          (GENOME_UPSTREAM), rewritten to /api/v1/*
 *   /api/*          -> NHI Discovery API       (API_UPSTREAM): sign-in, inventory,
 *                      access graph, credential exposure, integrations
 *
 * Genome gets its own prefix because its /api/v1/identities is a different
 * list from the discovery API's. The browser only ever talks to this origin;
 * production nginx routes the same paths (nginx/nginx.conf.template).
 */
const ROOT = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ROOT, '');
  const upstream = (name, fallback) => (env[name] || fallback).trim();

  return {
    envDir: ROOT,
    plugins: [react(), tailwindcss()],
    server: {
      port: 3000,
      proxy: {
        // Most specific first: Vite matches proxy keys in order.
        '/api/v1/ispm': { target: upstream('POSTURE_UPSTREAM', 'http://localhost:8086'), changeOrigin: true },
        '/genome-api': {
          target: upstream('GENOME_UPSTREAM', 'http://localhost:8087'),
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/genome-api/, '/api/v1'),
        },
        '/api': { target: upstream('API_UPSTREAM', 'http://localhost:8085'), changeOrigin: true },
      },
    },
    build: { outDir: 'dist', sourcemap: false },
  };
});
