/* Applied before first paint so the shell never flashes the wrong theme.
   A file rather than an inline script so the production CSP
   (`script-src 'self'`) allows it. Keep the key in step with ThemeContext. */
try {
  var stored = localStorage.getItem('nhi.theme');
  var system = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  document.documentElement.dataset.theme = stored === 'light' || stored === 'dark' ? stored : system;
} catch (e) {
  document.documentElement.dataset.theme = 'light';
}
