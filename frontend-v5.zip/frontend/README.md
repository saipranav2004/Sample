# NHI Console - Deep Algorithms

Operator console for AWS non-human identity discovery: the identities acting in
your accounts, the credentials they hold, and which of those need attention.

React 19, Vite, Tailwind v4, React Router 7. Motion (motion.dev) for interface
movement, anime.js for the sign-in illustration. Charts are hand-built SVG.

## What it talks to

One backend: the Go NHI API (v5). Every call carries the signed-in user's
bearer token. There is no key or secret of any kind in this app.

| Screen | Endpoints |
|---|---|
| Sign-in | `POST /api/auth/login`, `GET /api/auth/me` |
| Dashboard | `GET /api/v1/dashboard/summary`, `filters`, `identities/by-type`, `by-class`, `by-account`, `by-region`, `exposure`, `credentials/by-type`, `credentials/hygiene`, `credentials/privilege-distribution`, `ownership-coverage`, `recent-discoveries` |
| Identities | `GET /api/v1/inventory/identities`, `counts`, `grouped-by-class`, `export`; `GET`/`PATCH .../{id}`, `.../{id}/attributes`, `.../{id}/timeline` |
| Dormant identities | `GET /api/v1/inventory/identities/dormant` |
| Credentials | `GET /api/v1/inventory/credentials`, `counts`, `export`; `GET`/`PATCH .../{id}`, `.../{id}/hygiene`, `.../{id}/trust-policy`, `.../{id}/policies` |
| Credential hygiene | `GET /api/v1/inventory/credentials/expiring`, `stale` |
| Recent discoveries | `GET /api/v1/dashboard/recent-discoveries` |
| Search (Ctrl/Cmd+K) | `GET /api/v1/inventory/search` |

Not used, because the v5 router does not serve them: `dashboard/scan-health`
and `dashboard/trends` (listed in the API document, absent from the code).

## Running it

```bash
cp .env.example .env     # optional: only if the API is not on localhost:8080
npm install
npm run dev              # http://localhost:3000
```

Start the Go API first. The dev server proxies `/api/*` to `API_UPSTREAM`.

`npm run build` emits `dist/`. `npm run lint` runs oxlint.

| Variable | Side | Meaning |
|---|---|---|
| `VITE_API_URL` | client | Base URL of the API. Leave empty so the browser calls same-origin `/api`. Set it only when the API is on another origin, and allow that origin in the API's CORS settings. |
| `API_UPSTREAM` | dev server | Where `npm run dev` proxies `/api/*`. Default `http://localhost:8080`. |

**Keep the API same-origin.** The API's CORS `AllowedMethods` does not include
`PATCH`, so editing an identity or a credential fails cross-origin. Through the
dev proxy or the nginx image it works.

## Roles

The roles are the API's own (`users.role`). The API checks no role on any route
today, so the console applies this policy itself:

| Role | Can |
|---|---|
| `admin`, `team_lead` | read and export everything; edit an identity's functional class, owner and environment; edit a credential's owner principal and tags |
| `developer`, `auditor` | read and export everything |

Enforce the same rule on the server before relying on it.

## Deploying it

```bash
docker build -t nhi-console:latest .
docker run --rm -p 8080:8080 -e API_UPSTREAM=http://nhi-api:8080 nhi-console:latest
```

The image is nginx serving the built files. nginx proxies `/api/*` to
`API_UPSTREAM` (resolved at container start, so one image serves every
environment), sets security headers including a CSP with `connect-src 'self'`,
and answers `/healthz` itself. See `Dockerfile` and `nginx/`.

## Behaviour worth knowing

- **Rows open a preview, not a page.** Clicking a row in Identities,
  Credentials, Credential hygiene or Dormant identities opens a side panel
  with what needs attention, ownership and key dates. J/K or the arrow keys
  step through the rows; Ctrl/Cmd-click opens the full page in a new tab.
- **Details open on the problem.** An identity or credential page starts with
  "What needs attention"; its particulars follow.
- **Filters live in the URL.** A dashboard drill-down, a bookmark and a shared
  link open the same list. Values the API would reject are dropped when the
  URL is read, so a stale link never turns a screen into an error.
- **Counts link only where definitions match.** A dashboard figure links to a
  list only when that list, filtered, returns the same set.
- **Each panel fails on its own.** One failing endpoint shows an inline error
  with Retry in its panel; the rest of the screen still loads.
- **Server internals are never shown.** On a 5xx the API puts raw database text
  in `error`; the console shows only `message`.
- **Credential ids are checked before any request.** The API answers 500, not
  404, for an unknown or malformed credential id.
- **Edits send only what changed.** A credential's tags are replaced as a whole
  by the API, so the dialog always sends the complete set.
- **Reduced motion is respected** everywhere, including the sign-in
  illustration, which is drawn still.

## Backend issues found while building this

Observed against the v5 code and a seeded database. None are worked around by
inventing data; the console simply does not display what is not real.

1. `GET /inventory/credentials/{id}` and its sub-routes return **500** for a
   missing id and for a non-UUID (Postgres 22P02), instead of 404 / 400.
2. Dashboard summary: `scan_status` is hard-coded `"completed"` and
   `scan_duration_seconds` is hard-coded `0`. Not displayed.
3. Hygiene flag `wildcard_action` always carries the detail `"Allow s3:* on *"`
   whatever the policy says. The detail is hidden.
4. Dashboard hygiene `public_trust_roles` and `wildcard_actions` match JSON
   text with `ILIKE` patterns that have no spaces, while Postgres renders jsonb
   with spaces, so both likely always read 0.
5. Privilege thresholds disagree: dashboard `high_privilege_roles` uses 7
   (`HYGIENE_PRIVILEGE_THRESHOLD`, marked unconfirmed in the code), the
   per-credential `high_privilege` flag uses 8.
6. Trust-policy `has_external_account` is true for any AWS account principal,
   including the role's own account.
7. Infrastructure-as-code detection is a guess on both dashboards
   (`discovery_source` values for coverage, `type_attributes.managed_by_iac`
   for exposure).
8. `identities/by-type`, `by-class` and `exposure` return 400 "invalid
   account_id" for an account that has credentials but no identities.
9. CORS `AllowedMethods` lacks `PATCH` (see above).

## Structure

```
src/
  app/        providers, auth, route guard, role checks
  shell/      top bar, sidebar, breadcrumbs, command palette
  features/   overview, identities, credentials, activity, auth
  lib/api/    the HTTP client, session storage and every endpoint call
  lib/        labels, formatting, roles, motion, hooks
  ui/         design-system primitives (panels, grids, dialogs, fields)
  charts/     bar chart, histogram, ring
docs/         WIREFRAMES.md (screen plans), UX-AUDIT.md (audit, findings, outcome)
```
