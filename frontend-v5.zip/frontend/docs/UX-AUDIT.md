# UX audit - October 2026

Every route was captured in light, dark and at 390px, plus loading, error,
empty, dialog, palette and menu states (`audit/before`). Each screen was then
judged against one question: **what is the operator here to decide, and does
the screen answer it first?**

Yardsticks used:

- Security dashboards should start from the decision, not the data, and put
  the "what needs attention first" answer at the top; every element should
  pass "what decision becomes easier because this is here?"
  ([Vectra](https://www.vectra.ai/blog/how-to-design-better-security-dashboards)).
- Strong hierarchy, F-pattern placement, limit the number of metrics,
  consistent colour per data set ([IBM Carbon](https://carbondesignsystem.com/data-visualization/dashboards)).
- Reduce chrome colour and visual noise; neutral, timeless surfaces; alignment
  you feel rather than see ([Linear](https://linear.app/now/how-we-redesigned-the-linear-ui)).
- A neutral grey scale does almost all the work; colour is reserved for state
  (Vercel Geist; shadcn's neutral tokens, [shadcn theming](https://ui.shadcn.com/docs/theming)).
- Charts grow with `cubic-bezier(0.85,0,0.15,1)` over about 1.1s, staggered,
  hover dims the others to 0.3, and loading uses a static or shimmering
  skeleton that respects reduced motion ([Bklit bar chart](https://bklit.com/docs/components/bar-chart)).
- Springs with `bounce: 0` for UI, duration-based easing for opacity and
  colour ([Motion transitions](https://motion.dev/docs/react-transitions)).

## Findings, worst first

| # | Screen | Problem | Why it matters to the user | Fix |
|---|---|---|---|---|
| 1 | Dashboard | 12 panels, 3,300px tall. The "what to fix" answer is one of 12 equal-weight panels, and 5 of its 9 tiles read 0. | The operator scans past zeros and near-uniform distributions to find the 3 numbers that matter. | **Needs attention** list first, ranked by severity, zero checks folded into one "clear" line. Six distribution panels become one **Inventory** panel with a switch. |
| 2 | Everywhere | Hue used as decoration: KPI tiles each have a different coloured edge and icon; identity bars are blue and credential bars orange; privilege columns run green to red. | When everything is coloured, colour no longer means "look here". | Neutral tiles and bars. Colour only for severity and status; privilege bars are neutral, with 8-10 critical and 6-7 high. |
| 3 | Sidebar | Inventory, Risk and Activity groups start collapsed; 4 of 6 pages are hidden. | New users do not discover Hygiene, Dormant or Discoveries. | No collapsing: six items fit. |
| 4 | Lists | At 1440px nearly every cell truncates ("Bedrock a...", "Stop...", "Expired 1...", "33333333..."). Rows are two lines because the ARN sits under every name. | The table cannot be read without hovering each cell. | One-line rows, ARN moved to the preview, fixed widths so type, account and dates show in full, status as dot plus word. |
| 5 | Lists | Clicking a row leaves the list. | Triage means checking ten rows in a row; each one costs a page load and lost scroll. | **Preview drawer**: click a row to see what is wrong and who owns it, step through with the arrow keys, open the full page from there. |
| 6 | Mobile lists | Every column is stacked into each card: the credentials page is 9,000px. | Unusable on a phone. | Two-line cards: name, then type, status and the one signal that matters. |
| 7 | Detail pages | The first panel repeats the header (name, type, status, account). Hygiene findings sit behind a tab. A second back button duplicates the breadcrumb. | The user came because something is wrong; the page starts with what they already know. | Overview opens with **Findings** (flags or attention signals) and ownership; the duplicated fields are gone; one back control. |
| 8 | Icon buttons | Dialog close, remove-tag and row actions rendered as 2px dots (text padding squeezed the glyph). | Controls were invisible. | Fixed in `IconButton`. |
| 9 | Dashboard error | With the API down, ten identical red boxes. | Noise that says one thing ten times. | One page-level error when everything failed; per-panel errors only when one source fails. |
| 10 | Palette | A second focus rectangle inside the search box. | Looks broken. | Input focus outline removed; the dialog owns focus styling. |
| 11 | Login | (Fixed earlier) illustration crossed the body copy. | Legibility. | Moved and dimmed. |

## What stayed

- Skeletons shaped like the content they replace, never spinners.
- Filters in the URL; every count links only where the list returns the same set.
- Tokens: the slate neutrals, one brand blue and four status tones are already
  a restrained palette. The problem was usage, not the palette.

## Outcome

All eleven findings are fixed. Measured on the same seeded data:

| Screen | Before | After |
|---|---|---|
| Dashboard, desktop | 3,275px, 12 panels | 2,013px, 6 panels, decision first |
| Dashboard, 390px | 5,972px | 3,735px |
| Credentials, 390px | 9,049px | 4,224px |
| Identities, 390px | 8,922px | 4,293px |

Motion, after the audit:

- Springs are critically damped (`bounce: 0`, `visualDuration` 0.3s): drawers,
  dialogs and the sliding tab, nav and segment indicators arrive and stop.
- Rows replacing a skeleton rise in 18ms apart, capped at 12 rows; dashboard
  panel bodies fade in over their skeletons; the preview drawer cross-fades
  between records as you step through them.
- Charts keep the Bklit behaviour: grow from the baseline on
  `cubic-bezier(0.85,0,0.15,1)`, hovering one dims the rest.
- Everything is dropped under `prefers-reduced-motion`.

Colour, after the audit: slate neutrals and one brand blue carry everything
that is not a state. Critical, high and medium appear only where something is
wrong; green appears only for healthy states and the "clear" line.
