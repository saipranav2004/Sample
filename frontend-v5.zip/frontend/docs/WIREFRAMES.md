# NHI Console - screen plan and wireframes

Every screen maps to endpoints that exist in `AWS-NHI-Discovery-Backend-API`.
Nothing on screen is invented: where the API has no data, the screen says so.

## Information architecture

```
Overview      Dashboard ............... /overview
Inventory     Identities .............. /identities          (+ /identities/:id)
              Credentials ............. /credentials         (+ /credentials/:id)
Risk          Credential hygiene ...... /hygiene             (Expiring | Stale tabs)
              Dormant identities ...... /dormant
Activity      Recent discoveries ...... /discoveries
Global        Search (Ctrl/Cmd+K) ..... /api/v1/inventory/search
```

## API map

| Screen | Endpoints |
|---|---|
| Sign in | POST /api/auth/login, GET /api/auth/me |
| Dashboard | /dashboard/filters, summary, identities/by-type, by-class, by-account, by-region, identities/exposure, credentials/by-type, credentials/hygiene, credentials/privilege-distribution, ownership-coverage, recent-discoveries |
| Identities | /inventory/identities, /inventory/identities/counts, /inventory/identities/grouped-by-class, /inventory/identities/export, /dashboard/filters |
| Identity | /inventory/identities/{id}, /{id}/attributes, /{id}/timeline, PATCH /{id} |
| Credentials | /inventory/credentials, /inventory/credentials/counts, /inventory/credentials/export, /dashboard/filters |
| Credential | /inventory/credentials/{id}, /{id}/hygiene, /{id}/trust-policy, /{id}/policies, PATCH /{id} |
| Credential hygiene | /inventory/credentials/expiring, /inventory/credentials/stale |
| Dormant identities | /inventory/identities/dormant |
| Recent discoveries | /dashboard/recent-discoveries |
| Search palette | /inventory/search |

Not built because the API does not have them yet: `/dashboard/scan-health`
and `/dashboard/trends` (listed in the dashboard API document, absent from
the router).

## Shell

```
+--------------------------------------------------------------------------+
| [logo]                                   [ Search  Ctrl K ] [theme] (AB) |
+-----------+--------------------------------------------------------------+
| OVERVIEW  |  < Overview / Dashboard                                      |
|  Dashboard|  Title ................................ [actions]            |
| INVENTORY |  ------------------------------------------------------------|
|  Identit. |                                                              |
|  Credent. |   page content (fades and rises in, children stagger)        |
| RISK      |                                                              |
|  Hygiene  |                                                              |
|  Dormant  |                                                              |
| ACTIVITY  |                                                              |
|  Discov.  |                                                              |
+-----------+--------------------------------------------------------------+
  Active nav item: sliding indicator (shared layout animation).
  Below 1024px the sidebar becomes a sheet.
```

## Dashboard

```
 Dashboard                                   [Account v] [Region v] [Refresh]
 Last data refresh 12 min ago - 4 accounts - 5 regions

 +-----------+ +-----------+ +-----------+ +-----------+
 |IDENTITIES | |CREDENTIALS| |NEW IN 24H | |EXPIRING 30D|   counters animate
 | 197  ▮▮▮▮ | | 238       | | 17 / 18   | | 26         |   in once
 +-----------+ +-----------+ +-----------+ +-----------+

 +---------------- Credential risk ---------------+ +-- Privilege levels --+
 | Expired 20 | Expiring 26 | Stale keys 28 |      | histogram 0..10,      |
 | Unrotated secrets 25 | Root keys 0 |            | bars grow, hover      |
 | High-privilege roles 9 | Public trust 0         | fades the others      |
 +------------------------------------------------+ +-----------------------+

 +--- Exposure signals (identities) --------------+ +-- Ownership coverage -+
 | Public 19 > | Dormant 90d 131 > | No activity  | | identities  creds     |
 | Missing owner | Missing env | Not in IaC       | | owner  ███████░ 75%   |
 +------------------------------------------------+ +-----------------------+

 +-- Identities by type --+ +-- Functional class (ring) --+ +-- Status --+
 +-- Credentials by type -+ +-- Accounts table ---------- + +-- Regions -+

 +-- Recent discoveries (24h): new / removed feed ---------- [View all] --+
```

Filters: account applies to every panel that accepts it; region applies to
summary, by-type, by-class, credentials by type. A panel that ignores the
active filter says "All accounts".

## Identities

```
 Identities                                            [Export v]
 [All 197] [Active 171] [Stopped 15] [Terminated 11]          (counts)
 +- Filters -------+ +--------------------------------------------------+
 | Status  (radio) | | [search name / ARN]   197 identities  [Table|By class]
 | Type            | | chips: Type: Lambda x                            |
 | Class           | | IDENTITY       TYPE   CLASS  ACCOUNT  STATUS ... |
 | Account         | | row ... (click -> detail)                        |
 | Region          | | ...                                              |
 | Public          | | 1-50 of 197                    Rows [50] < 1/4 > |
 | Owner / Env     | +--------------------------------------------------+
 | Active before   |
 +-----------------+
```

## Identity / Credential detail

```
 [<- back]  orders-api-12                            [Edit ownership]
 Lambda function - Service - 111111111111 - us-east-1
 (Active) arn:aws:...  [copy]
 [Overview] [Attributes] [Timeline] [Raw]        <- animated tab underline
```

Credential detail tabs: Overview (lifecycle, rotation, owner, tags),
Hygiene (overall health + flags), Access (trust policy statements, risk
summary, managed/inline policies, permission boundary, assumable roles; IAM
roles only), Attributes.

## Credential hygiene

```
 Credential hygiene
 [Expiring | Stale]         Within [7d 30d 60d 90d]   [Type v] [Account v]
 NAME           TYPE          EXPIRES          IN
 cert-...       ACM cert      Oct 10, 2026     4 days   (red < 7, amber < 30)
```

## Recent discoveries

```
 Recent discoveries          [24h 7d 30d] [All|Identities|Credentials] [New|Removed]
 25 new - 5 removed
 o  NEW  identity  orders-api-12   Lambda - 111111111111 - us-east-1   2h ago
 o  REM  credential AKIA...        Access key - global                 5h ago
```

## Motion rules

- Page enter: opacity 0 to 1, y 8px to 0, 320ms, children stagger 40ms.
- Counters: count up once on first load (700ms); refreshes change in place.
- Bars and histogram: grow from the baseline with
  `cubic-bezier(0.85, 0, 0.15, 1)`, staggered; hovering one dims the others.
- Tabs and nav: a shared-layout indicator slides between items.
- Drawers, dialogs and toasts: spring in and out with presence animation.
- `prefers-reduced-motion`: all of the above are reduced to fades or none.
