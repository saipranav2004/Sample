import { fileURLToPath } from 'node:url';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/**
 * One upstream: the Go NHI API (v5). It serves every screen, so there is one
 * proxy and no key of any kind in this app.
 *
 * In development `/api/*` is proxied to API_UPSTREAM so the browser stays
 * same-origin and the bearer token is the only credential it ever sends.
 */
const ROOT = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ROOT, '');
  return {
    envDir: ROOT,
    plugins: [react(), tailwindcss()],
    server: {
      port: 3000,
      proxy: {
        '/api': {
          target: (env.API_UPSTREAM || 'http://localhost:8080').trim(),
          changeOrigin: true,
        },
      },
    },
    build: { outDir: 'dist', sourcemap: false },
  };
});
