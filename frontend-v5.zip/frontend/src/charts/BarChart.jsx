import { useState } from 'react';
import { motion } from 'motion/react';
import { formatNumber, formatPercent } from '../lib/format';
import { EASE_GROW } from '../lib/motion';
import { cn } from '../ui/cn';

/**
 * Ranked horizontal bars, in the manner of Bklit's bar chart: bars grow from
 * the baseline on an in-out curve with a short stagger, and hovering one bar
 * fades the others so the reader's eye stays on it.
 *
 * Long category names from the API stay readable because they sit above each
 * bar rather than on a rotated axis. One hue: length carries the value.
 *
 * items: [{ key, label, value, to? }]
 */
export function BarChart({ items, total, onSelect, color = 'var(--t-ramp-4)', valueSuffix, className, label }) {
  const [hovered, setHovered] = useState(null);
  const max = Math.max(1, ...items.map((item) => Number(item.value) || 0));
  const sum = total ?? items.reduce((acc, item) => acc + (Number(item.value) || 0), 0);

  return (
    <ul className={cn('flex flex-col', className)} aria-label={label} onMouseLeave={() => setHovered(null)}>
      {items.map((item, index) => {
        const value = Number(item.value) || 0;
        const width = Math.max((value / max) * 100, value > 0 ? 1.5 : 0);
        const dimmed = hovered !== null && hovered !== item.key;
        const Row = onSelect ? 'button' : 'div';
        return (
          <li key={item.key} className="border-b border-line/70 last:border-b-0">
            <Row
              type={onSelect ? 'button' : undefined}
              onClick={onSelect ? () => onSelect(item) : undefined}
              onMouseEnter={() => setHovered(item.key)}
              onFocus={() => setHovered(item.key)}
              onBlur={() => setHovered(null)}
              className={cn(
                'group flex w-full items-center gap-3 rounded-md py-2.5 text-left transition-opacity duration-200',
                onSelect && 'cursor-pointer focus-visible:bg-surface-2',
                dimmed ? 'opacity-35' : 'opacity-100',
              )}
            >
              <span className="flex min-w-0 flex-1 flex-col gap-1.5">
                <span className="flex items-baseline justify-between gap-3">
                  <span className="truncate text-[12.5px] font-medium text-ink" title={item.label}>
                    {item.label}
                  </span>
                  <span className="shrink-0 text-[11.5px] text-ink-3" data-numeric="">
                    {formatPercent(value, sum, 1)}
                  </span>
                </span>
                <span className="h-1.5 w-full overflow-hidden rounded-full bg-track">
                  <motion.span
                    className="block h-full rounded-full"
                    style={{ background: color, transformOrigin: 'left center' }}
                    initial={{ width: 0 }}
                    animate={{ width: `${width}%` }}
                    transition={{ duration: 0.9, ease: EASE_GROW, delay: Math.min(index * 0.045, 0.4) }}
                  />
                </span>
              </span>
              <span data-numeric="" className="w-14 shrink-0 text-right font-display text-[15px] font-bold text-ink">
                {formatNumber(value)}
                {valueSuffix}
              </span>
            </Row>
          </li>
        );
      })}
    </ul>
  );
}
