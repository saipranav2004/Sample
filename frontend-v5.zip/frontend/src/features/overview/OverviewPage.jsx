import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Fingerprint,
  KeyRound,
  Plus,
  RotateCw,
  ShieldAlert,
  TimerReset,
} from 'lucide-react';
import {
  fetchCredentialHygiene,
  fetchCredentialsByType,
  fetchExposure,
  fetchIdentitiesByAccount,
  fetchIdentitiesByClass,
  fetchIdentitiesByRegion,
  fetchIdentitiesByType,
  fetchOwnershipCoverage,
  fetchPrivilegeDistribution,
  fetchRecentDiscoveries,
  fetchSummary,
} from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative, percentValue } from '../../lib/format';
import { AnimatedNumber, Page, Reveal, RevealItem, RevealList } from '../../lib/motion';
import {
  credentialTypeLabel,
  functionalClassLabel,
  identityTypeLabel,
  regionLabel,
  statusMeta,
} from '../../lib/labels';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { DiscoveryRow } from '../activity/DiscoveryRow';
import { BarChart } from '../../charts/BarChart';
import { Histogram } from '../../charts/Histogram';
import { Button } from '../../ui/Button';
import { Select } from '../../ui/Field';
import { Meter, ProportionBar } from '../../ui/Meter';
import { Panel, PanelHeader } from '../../ui/Panel';
import { MetricTile } from '../../ui/Stat';
import { ChartSkeleton, ListSkeleton, Skeleton, StatStripSkeleton } from '../../ui/Skeleton';
import { ClearState, EmptyState, ErrorState, InlineError } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { TONE_VAR, cn } from '../../ui/cn';

const ACCOUNT = /^[0-9]{12}$/;
const REGION = /^[a-z0-9-]{1,64}$/;


/**
 * Dashboard: every number comes from a /api/v1/dashboard endpoint. Each panel
 * loads and fails on its own, so one unavailable source never blanks the
 * screen.
 *
 * Account and region filters live in the URL. They are passed only to the
 * endpoints that accept them; a panel that ignores one says so.
 */
export default function OverviewPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const accountId = ACCOUNT.test(searchParams.get('account_id') ?? '') ? searchParams.get('account_id') : '';
  const region = REGION.test(searchParams.get('region') ?? '') ? searchParams.get('region') : '';
  const filtered = Boolean(accountId || region);
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);

  const both = { account_id: accountId, region };
  const acct = { account_id: accountId };
  const key = `${accountId}|${region}`;

  const summary = useQuery((signal) => fetchSummary(both, signal), [key]);
  const byType = useQuery((signal) => fetchIdentitiesByType(both, signal), [key]);
  const byClass = useQuery((signal) => fetchIdentitiesByClass(both, signal), [key]);
  const byAccount = useQuery((signal) => fetchIdentitiesByAccount({ region }, signal), [region]);
  const byRegion = useQuery((signal) => fetchIdentitiesByRegion(acct, signal), [accountId]);
  const credentials = useQuery((signal) => fetchCredentialsByType(both, signal), [key]);
  const hygiene = useQuery((signal) => fetchCredentialHygiene(acct, signal), [accountId]);
  const exposure = useQuery((signal) => fetchExposure(acct, signal), [accountId]);
  const privilege = useQuery((signal) => fetchPrivilegeDistribution(acct, signal), [accountId]);
  const coverage = useQuery((signal) => fetchOwnershipCoverage(acct, signal), [accountId]);
  const discoveries = useQuery((signal) => fetchRecentDiscoveries({ hours: 24, limit: 6 }, signal), []);

  const queries = [summary, byType, byClass, byAccount, byRegion, credentials, hygiene, exposure, privilege, coverage, discoveries];
  const refreshing = queries.some((query) => query.isRefreshing);
  const refreshAll = () => queries.forEach((query) => query.refetch());
  /* When the API is down every panel fails the same way; say it once. */
  const allFailed = queries.every((query) => query.isError && !query.data);

  const setFilter = (name, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(name, value);
    else next.delete(name);
    setSearchParams(next, { replace: true });
  };

  const scope = { accountId, region };

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Dashboard"
          lede="Non-human identities and the credentials they hold, across every AWS account the scanner reaches."
          actions={
            <>
              <Select
                size="sm"
                aria-label="AWS account"
                value={accountId}
                onChange={(event) => setFilter('account_id', event.target.value)}
                options={[{ value: '', label: 'All accounts' }, ...options.accounts.map((id) => ({ value: id, label: id }))]}
                className="w-40"
              />
              <Select
                size="sm"
                aria-label="Region"
                value={region}
                onChange={(event) => setFilter('region', event.target.value)}
                options={[{ value: '', label: 'All regions' }, ...options.regions.map((r) => ({ value: r, label: regionLabel(r) }))]}
                className="w-36"
              />
              <Button variant="secondary" size="sm" icon={RotateCw} onClick={refreshAll} loading={refreshing}>
                Refresh
              </Button>
            </>
          }
          meta={<RefreshStrip query={summary} filtered={filtered} onClear={() => setSearchParams({}, { replace: true })} />}
        />
      </Reveal>

      {allFailed ? (
        <Reveal>
          <Panel>
            <ErrorState
              error={summary.error}
              onRetry={refreshAll}
              title="The dashboard could not be loaded"
            />
          </Panel>
        </Reveal>
      ) : (
        <>
          <Reveal>
            <Headline summary={summary} />
          </Reveal>

          {/* The decision first: what to fix, most severe first. */}
          <Reveal className="grid gap-4 @min-[64rem]:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
            <AttentionPanel hygiene={hygiene} exposure={exposure} scope={scope} />
            <div className="flex flex-col gap-4">
              <PrivilegePanel query={privilege} scope={scope} />
              <StatusPanel summary={summary} />
            </div>
          </Reveal>

          <Reveal className="grid gap-4 @min-[64rem]:grid-cols-2">
            <CoveragePanel query={coverage} scope={scope} />
            <CompositionPanel
              byType={byType}
              byClass={byClass}
              credentials={credentials}
              byAccount={byAccount}
              byRegion={byRegion}
              order={options.functionalClasses}
              scope={scope}
            />
          </Reveal>

          <Reveal>
            <DiscoveriesPanel query={discoveries} />
          </Reveal>
        </>
      )}
    </Page>
  );
}

function withScope(path, { accountId, region }) {
  const url = new URL(path, 'http://x');
  if (accountId) url.searchParams.set('account_id', accountId);
  if (region && !url.searchParams.has('region')) url.searchParams.set('region', region);
  return `${url.pathname}${url.search}`;
}

/**
 * The identity endpoints validate a filter against the identities table, so
 * an account that only holds credentials answers 400 "invalid account_id".
 * That is "nothing here", not a failure.
 */
function PanelBody({ query, children, skeleton, emptyTitle = 'Nothing in this scope', emptyText }) {
  if (query.isLoading && !query.data) return skeleton ?? <ChartSkeleton height={200} bars={5} />;
  if (query.isError && query.error?.status === 400) {
    return <EmptyState compact title={emptyTitle} description={emptyText ?? query.error.message} />;
  }
  if (query.isError && !query.data) return <InlineError error={query.error} onRetry={query.refetch} label="Could not load" />;
  /* Content replacing a skeleton fades in rather than snapping. */
  return <div className="animate-fade">{children(query.data)}</div>;
}

function ScopeNote({ children }) {
  if (!children) return null;
  return <span className="rounded-full bg-surface-3 px-2 py-0.5 text-[10.5px] font-medium text-ink-3">{children}</span>;
}

/* ── Header strip ────────────────────────────────────────────────────────── */

function RefreshStrip({ query, filtered, onClear }) {
  if (query.isLoading && !query.data) return <Skeleton className="h-5 w-72 rounded" />;
  const data = query.data;
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[12.5px] text-ink-3">
      {data?.last_scan_at && (
        /* last_scan_at is the newest last_seen_at in the inventory - when the
           data was last refreshed. The API's scan_status and
           scan_duration_seconds are fixed placeholders, so they are not shown. */
        <span className="inline-flex items-center gap-1.5">
          <Clock aria-hidden="true" className="size-3.5" />
          Data last refreshed{' '}
          <time dateTime={data.last_scan_at} title={formatDateTime(data.last_scan_at)} className="font-medium text-ink-2">
            {formatRelative(data.last_scan_at)}
          </time>
        </span>
      )}
      {data && (
        <span>
          {formatNumber(data.total_accounts_scanned)} account{data.total_accounts_scanned === 1 ? '' : 's'} ·{' '}
          {formatNumber(data.total_regions_scanned)} region{data.total_regions_scanned === 1 ? '' : 's'}
        </span>
      )}
      {filtered && (
        <button type="button" onClick={onClear} className="font-medium text-brand hover:underline">
          Clear filters
        </button>
      )}
    </div>
  );
}

/* ── Headline ────────────────────────────────────────────────────────────── */

function Headline({ summary }) {
  if (summary.isLoading && !summary.data) return <StatStripSkeleton count={4} />;
  if (summary.isError && !summary.data) {
    return (
      <Panel>
        <ErrorState error={summary.error} onRetry={summary.refetch} title="The summary could not be loaded" compact />
      </Panel>
    );
  }
  const data = summary.data;
  const active = Number(data.identities_by_status?.active) || 0;
  const activeCredentials = Number(data.credentials_by_status?.active) || 0;
  return (
    <div className="grid grid-cols-2 gap-3 @min-[60rem]:grid-cols-4">
      <MetricTile
        as={Link}
        to="/identities"
        label="Identities"
        value={data.total_identities}
        icon={Fingerprint}
        caption={`${formatNumber(active)} active`}
        meter={percentValue(active, data.total_identities)}
        meterLabel="Share active"
      />
      <MetricTile
        as={Link}
        to="/credentials"
        label="Credentials"
        value={data.total_credentials}
        icon={KeyRound}
        caption={`${formatNumber(activeCredentials)} active`}
        meter={percentValue(activeCredentials, data.total_credentials)}
        meterLabel="Share active"
      />
      <MetricTile
        as={Link}
        to="/discoveries"
        label="New in 24 hours"
        value={(Number(data.new_identities_last_24h) || 0) + (Number(data.new_credentials_last_24h) || 0)}
        icon={Plus}
        caption={`${formatNumber(data.new_identities_last_24h)} identities · ${formatNumber(data.new_credentials_last_24h)} credentials`}
      />
      <MetricTile
        as={Link}
        to="/hygiene?days=30"
        label="Expiring in 30 days"
        value={data.expiring_credentials_30d}
        icon={TimerReset}
        tone={data.expiring_credentials_30d > 0 ? 'high' : undefined}
        caption="Renew or retire before they lapse"
      />
    </div>
  );
}

/* ── Privilege ───────────────────────────────────────────────────────────── */

function PrivilegePanel({ query, scope }) {
  const navigate = useNavigate();
  return (
    <Panel>
      <PanelHeader
        title="IAM role privilege"
        subtitle="Roles at each privilege level, 0 (minimal) to 10 (full control)."
        actions={<ScopeNote>{scope.region ? 'All regions' : null}</ScopeNote>}
      />
      <div className="mt-4">
        <PanelBody query={query} skeleton={<ChartSkeleton height={190} bars={11} />}>
          {(data) => {
            const bins = [...(data.distribution ?? [])]
              .sort((a, b) => a.privilege_level - b.privilege_level)
              .map((row) => ({
                key: String(row.privilege_level),
                axisLabel: String(row.privilege_level),
                value: row.count,
                label: row.label,
                /* Colour carries severity only: roles at 8-10 are critical,
                   6-7 high; everything below is one quiet tone. */
                color: row.privilege_level >= 8 ? TONE_VAR.critical : row.privilege_level >= 6 ? TONE_VAR.high : 'var(--t-ramp-3)',
              }));
            if (bins.every((bin) => !bin.value)) {
              return <EmptyState compact title="No scored roles" description="No IAM role in this scope has a privilege level yet." />;
            }
            return (
              <>
                <Histogram
                  bins={bins}
                  ariaLabel="IAM roles by privilege level"
                  onSelect={(bin) => navigate(`/credentials?credential_type=iam_role&privilege_level_min=${bin.key}&privilege_level_max=${bin.key}`)}
                />
                <p className="mt-3 text-[12px] text-ink-3">
                  {formatNumber(data.total_roles_with_score)} roles scored · {formatNumber(data.total_roles_unscored)} not scored yet
                </p>
              </>
            );
          }}
        </PanelBody>
      </div>
    </Panel>
  );
}

/* ── Ownership coverage ──────────────────────────────────────────────────── */

function CoveragePanel({ query, scope }) {
  return (
    <Panel>
      <PanelHeader
        title="Tag and ownership coverage"
        subtitle="Share of the inventory carrying the tags governance relies on."
        actions={<ScopeNote>{scope.region ? 'All regions' : null}</ScopeNote>}
      />
      <div className="mt-4">
        <PanelBody query={query} skeleton={<ListSkeleton rows={5} />}>
          {(data) => (
            <div className="grid gap-5 @min-[30rem]:grid-cols-2">
              <CoverageColumn title="Identities" data={data.identities} />
              <CoverageColumn title="Credentials" data={data.credentials} />
            </div>
          )}
        </PanelBody>
      </div>
    </Panel>
  );
}

function CoverageColumn({ title, data }) {
  if (!data) return null;
  const rows = [
    ['Owner tag', data.has_owner_tag],
    ['Environment tag', data.has_environment_tag],
    ['Any tag', data.has_any_tag],
    ['Managed as code', data.is_in_iac],
  ].filter(([, stat]) => stat);
  return (
    <div>
      <p className="text-[11px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
        {title} <span className="font-medium normal-case tracking-normal">· {formatNumber(data.total)}</span>
      </p>
      <ul className="mt-2.5 flex flex-col gap-3">
        {rows.map(([label, stat]) => {
          const pct = Number(stat.percentage) || 0;
          /* Neutral when healthy; colour only flags thin coverage. */
          const tone = pct >= 75 ? 'brand' : pct >= 50 ? 'medium' : 'high';
          return (
            <li key={label}>
              <div className="flex items-baseline justify-between text-[12.5px]">
                <span className="text-ink-2">{label}</span>
                <span data-numeric="" className="font-semibold text-ink">
                  {pct.toFixed(pct % 1 ? 1 : 0)}%
                </span>
              </div>
              <Meter value={pct} tone={tone} height={6} className="mt-1.5" label={`${title} with ${label.toLowerCase()}`} />
            </li>
          );
        })}
      </ul>
      {data.has_no_tags && (
        <p className="mt-3 text-[11.5px] text-ink-3">{formatNumber(data.has_no_tags.count)} carry no tags at all.</p>
      )}
    </div>
  );
}

function StatusPanel({ summary }) {
  const navigate = useNavigate();
  const data = summary.data;
  const toSegments = (map) =>
    Object.entries(map ?? {})
      .map(([key, value]) => ({ key, label: statusMeta(key).label, value: Number(value) || 0, color: TONE_VAR[statusMeta(key).tone] }))
      .filter((segment) => segment.value > 0)
      .sort((a, b) => b.value - a.value);
  const identity = toSegments(data?.identities_by_status);
  const credential = toSegments(data?.credentials_by_status);
  return (
    <Panel prominence="quiet">
      <PanelHeader prominence="quiet" title="Lifecycle status" />
      <div className="mt-4 flex flex-col gap-5">
        {summary.isLoading && !data ? (
          <ListSkeleton rows={4} />
        ) : !data ? null : (
          [
            ['Identities', identity, '/identities'],
            ['Credentials', credential, '/credentials'],
          ].map(([title, segments, path]) => (
            <div key={title}>
              <p className="mb-2 text-[11px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{title}</p>
              {segments.length === 0 ? (
                <p className="text-[12.5px] text-ink-3">None recorded.</p>
              ) : (
                <>
                  <ProportionBar
                    segments={segments}
                    onSelect={(segment) => navigate(`${path}?status=${encodeURIComponent(segment.key)}`)}
                    ariaLabel={`${title} by status`}
                  />
                  <ul className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1.5">
                    {segments.map((segment) => (
                      <li key={segment.key}>
                        <Link
                          to={`${path}?status=${encodeURIComponent(segment.key)}`}
                          className="inline-flex items-center gap-1.5 text-[12.5px] text-ink-2 hover:text-ink"
                        >
                          <span aria-hidden="true" className="size-2 rounded-full" style={{ background: segment.color }} />
                          {segment.label}
                          <span data-numeric="" className="font-semibold text-ink">
                            {formatNumber(segment.value)}
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </Panel>
  );
}

/* ── Recent discoveries ──────────────────────────────────────────────────── */

function DiscoveriesPanel({ query }) {
  return (
    <Panel>
      <PanelHeader
        title="Last 24 hours"
        subtitle="Identities and credentials the scanner discovered or saw removed."
        actions={
          <Button as={Link} to="/discoveries" variant="secondary" size="sm" iconRight={ArrowRight}>
            All activity
          </Button>
        }
      >
        {query.data && (
          <p className="mt-2 flex gap-3 text-[12px]">
            <span className="font-semibold text-low">+{formatNumber(query.data.total_new)} new</span>
            <span className="font-semibold text-ink-2">-{formatNumber(query.data.total_removed)} removed</span>
          </p>
        )}
      </PanelHeader>
      <div className="mt-2">
        <PanelBody query={query} skeleton={<ListSkeleton rows={4} />}>
          {(data) =>
            data.discoveries.length === 0 ? (
              <ClearState compact title="Quiet day" description="Nothing was discovered or removed in the last 24 hours." />
            ) : (
              <RevealList className="grid grid-cols-1 divide-y divide-line @min-[60rem]:grid-cols-2 @min-[60rem]:gap-x-8 @min-[60rem]:divide-y-0">
                {data.discoveries.map((item, index) => (
                  <RevealItem index={index} key={`${item.entity}-${item.arn}-${item.event}-${index}`} className="@min-[60rem]:border-b @min-[60rem]:border-line">
                    <DiscoveryRow item={item} />
                  </RevealItem>
                ))}
              </RevealList>
            )
          }
        </PanelBody>
      </div>
    </Panel>
  );
}

/* ── Needs attention ─────────────────────────────────────────────────────── */

const SEVERITY = { critical: 0, high: 1, medium: 2 };
const SEVERITY_LABEL = { critical: 'Critical', high: 'High', medium: 'Medium' };

function identityTypes(byType) {
  const rows = (byType ?? []).filter((row) => row.count > 0).slice(0, 3);
  return rows.length ? rows.map((row) => `${identityTypeLabel(row.identity_type)} ${formatNumber(row.count)}`).join(' · ') : null;
}
function credentialTypes(byType) {
  const rows = (byType ?? []).filter((row) => row.count > 0).slice(0, 3);
  return rows.length ? rows.map((row) => `${credentialTypeLabel(row.credential_type)} ${formatNumber(row.count)}`).join(' · ') : null;
}

/**
 * One ranked list of everything the hygiene and exposure endpoints count,
 * most severe first, then largest first. Checks that read zero are folded
 * into a single "clear" line: they matter as reassurance, not as tiles.
 * A row links to a list only where that list returns the same set.
 */
function AttentionPanel({ hygiene, exposure, scope }) {
  const h = hygiene.data;
  const e = exposure.data;
  const items = [];
  if (h) {
    items.push(
      { key: 'expired', severity: 'critical', label: 'Credentials already expired', value: h.already_expired?.total, detail: credentialTypes(h.already_expired?.by_type) },
      { key: 'root', severity: 'critical', label: 'Root account access keys', value: h.root_access_keys_present, detail: 'Delete them; root should not have keys' },
      { key: 'public-trust', severity: 'critical', label: 'Roles anyone can assume', value: h.public_trust_roles, detail: 'Trust policy allows any principal' },
      {
        key: 'privileged',
        severity: 'high',
        label: 'High-privilege IAM roles',
        value: h.high_privilege_roles?.total,
        detail: `Privilege 7 or above · ${formatNumber(h.high_privilege_roles?.admin_access)} with admin access`,
        to: '/credentials?credential_type=iam_role&privilege_level_min=7',
      },
      { key: 'expiring', severity: 'high', label: 'Credentials expiring in 30 days', value: h.expiring_within_30d?.total, detail: credentialTypes(h.expiring_within_30d?.by_type), to: '/hygiene?days=30' },
      { key: 'stale-keys', severity: 'high', label: 'Access keys unused for 90 days', value: h.stale_access_keys_90d, detail: 'Disable after checking with the owner' },
      { key: 'unrotated', severity: 'medium', label: 'Secrets not rotated in 90 days', value: h.unrotated_secrets_90d },
      { key: 'rotation-off', severity: 'medium', label: 'Secrets with rotation turned off', value: h.rotation_disabled_secrets },
      { key: 'never-used', severity: 'medium', label: 'Access keys never used', value: h.never_used_access_keys },
    );
  }
  if (e) {
    items.push(
      {
        key: 'public',
        severity: 'critical',
        label: 'Identities reachable from the internet',
        value: e.publicly_accessible?.total,
        detail: identityTypes(e.publicly_accessible?.by_type),
        to: withScope('/identities?is_public=true', { accountId: scope.accountId }),
      },
      { key: 'dormant', severity: 'high', label: 'Identities unused for 90 days', value: e.dormant_90d?.total, detail: identityTypes(e.dormant_90d?.by_type), to: '/dormant?days=90' },
      { key: 'no-owner', severity: 'medium', label: 'Identities with no owner', value: e.missing_owner_tag, detail: 'Nobody is answerable for them' },
      { key: 'no-env', severity: 'medium', label: 'Identities with no environment', value: e.missing_environment_tag },
    );
  }
  const open = items
    .filter((item) => Number(item.value) > 0)
    .sort((a, b) => SEVERITY[a.severity] - SEVERITY[b.severity] || b.value - a.value);
  const clear = items.filter((item) => Number(item.value) === 0);
  const loading = (hygiene.isLoading && !h) || (exposure.isLoading && !e);

  return (
    <Panel prominence="lead">
      <PanelHeader
        prominence="lead"
        icon={ShieldAlert}
        title="Needs attention"
        subtitle="Every credential and identity check, most severe first."
        actions={<ScopeNote>{scope.region ? 'All regions' : null}</ScopeNote>}
      />
      <div className="mt-3 flex flex-col gap-2">
        {hygiene.isError && !h && hygiene.error?.status !== 400 && (
          <InlineError error={hygiene.error} onRetry={hygiene.refetch} label="Credential checks could not load" />
        )}
        {exposure.isError && !e && exposure.error?.status !== 400 && (
          <InlineError error={exposure.error} onRetry={exposure.refetch} label="Identity checks could not load" />
        )}
        {loading && open.length === 0 ? (
          <ListSkeleton rows={6} />
        ) : open.length === 0 && (h || e) ? (
          <ClearState compact title="Nothing needs attention" description="Every check in this scope reads zero." />
        ) : (
          <RevealList className="-mx-2 flex flex-col">
            {open.map((item, index) => (
              <RevealItem index={index} key={item.key}>
                <AttentionRow item={item} />
              </RevealItem>
            ))}
          </RevealList>
        )}
        {clear.length > 0 && (
          <p className="mt-1 flex items-start gap-2 border-t border-line pt-3 text-[12px] text-ink-3">
            <CheckCircle2 aria-hidden="true" className="mt-px size-3.5 shrink-0 text-low" />
            <span>
              <span className="font-medium text-ink-2">{clear.length} clear:</span> {clear.map((item) => item.label).join(', ')}.
            </span>
          </p>
        )}
      </div>
    </Panel>
  );
}

function AttentionRow({ item }) {
  const body = (
    <span className="flex items-center gap-3 rounded-[var(--radius-control)] px-2 py-2.5">
      {/* A word where there is room for one, a dot where there is not; the
          severity is also read out for screen readers either way. */}
      <span className="hidden w-[4.5rem] shrink-0 @min-[34rem]:block">
        <Tag size="sm" tone={item.severity}>
          {SEVERITY_LABEL[item.severity]}
        </Tag>
      </span>
      <span aria-hidden="true" className="size-2 shrink-0 rounded-full @min-[34rem]:hidden" style={{ background: TONE_VAR[item.severity] }} />
      <span className="min-w-0 flex-1">
        <span className="sr-only @min-[34rem]:hidden">{SEVERITY_LABEL[item.severity]}: </span>
        <span className="block text-[13px] leading-snug font-medium text-ink @min-[34rem]:truncate">{item.label}</span>
        {item.detail && <span className="mt-0.5 block truncate text-[11.5px] text-ink-3">{item.detail}</span>}
      </span>
      <AnimatedNumber value={item.value} className="shrink-0 font-display text-[18px] leading-none font-bold text-ink" />
      <ArrowRight
        aria-hidden="true"
        className={cn('size-4 shrink-0 text-ink-3 transition-transform group-hover:translate-x-0.5', !item.to && 'invisible')}
      />
    </span>
  );
  return item.to ? (
    <Link to={item.to} className="group block rounded-[var(--radius-control)] transition-colors hover:bg-surface-2 focus-visible:bg-surface-2">
      {body}
    </Link>
  ) : (
    body
  );
}

/* ── Inventory composition ───────────────────────────────────────────────── */

const COMPOSITION = [
  { value: 'type', label: 'Identity type' },
  { value: 'class', label: 'Class' },
  { value: 'credential', label: 'Credential type' },
  { value: 'account', label: 'Account' },
  { value: 'region', label: 'Region' },
];

/**
 * Where the inventory sits, one breakdown at a time. These are reference
 * views, not alarms, so they share one panel and one neutral colour.
 */
function CompositionPanel({ byType, byClass, credentials, byAccount, byRegion, order, scope }) {
  const navigate = useNavigate();
  const [view, setView] = useState('type');
  const config = {
    type: {
      query: byType,
      rows: (data) =>
        data.breakdown.map((row) => ({
          key: row.identity_type,
          label: identityTypeLabel(row.identity_type),
          value: row.count,
          to: withScope(`/identities?identity_type=${encodeURIComponent(row.identity_type)}`, scope),
        })),
    },
    class: {
      query: byClass,
      rows: (data) => {
        const position = (value) => (order.indexOf(value) === -1 ? order.length : order.indexOf(value));
        return [...(data.breakdown ?? [])]
          .sort((a, b) => b.count - a.count || position(a.functional_class) - position(b.functional_class))
          .map((row) => ({
            key: row.functional_class,
            label: functionalClassLabel(row.functional_class),
            value: row.count,
            to: withScope(`/identities?functional_class=${encodeURIComponent(row.functional_class)}`, scope),
          }));
      },
    },
    credential: {
      query: credentials,
      rows: (data) =>
        data.breakdown.map((row) => ({
          key: row.credential_type,
          label: credentialTypeLabel(row.credential_type),
          value: row.count,
          to: withScope(`/credentials?credential_type=${encodeURIComponent(row.credential_type)}`, scope),
        })),
    },
    account: {
      query: byAccount,
      note: scope.region ? `In ${regionLabel(scope.region)}` : null,
      rows: (data) =>
        data.breakdown.map((row) => ({
          key: row.account_id,
          label: row.account_name ? `${row.account_id} · ${row.account_name}` : row.account_id,
          value: row.identity_count,
          to: `/identities?account_id=${row.account_id}`,
        })),
      suffix: 'identities',
    },
    region: {
      query: byRegion,
      note: scope.region ? 'Every region' : null,
      rows: (data) =>
        data.breakdown.map((row) => ({
          key: row.region,
          label: regionLabel(row.region),
          value: row.identity_count,
          to: withScope(`/identities?region=${encodeURIComponent(row.region)}`, { accountId: scope.accountId }),
        })),
      suffix: 'identities',
    },
  }[view];

  return (
    <Panel>
      <PanelHeader title="Inventory" subtitle="Where identities and credentials sit. Select a bar to open that slice." actions={<ScopeNote>{config.note}</ScopeNote>} />
      <div className="mt-3 overflow-x-auto pb-1 [scrollbar-width:none]">
        <SegmentedControl label="Break down by" value={view} onChange={setView} options={COMPOSITION} />
      </div>
      <div className="mt-4">
        <PanelBody query={config.query} emptyText={scope.accountId || scope.region ? 'Nothing matches the current filters.' : undefined}>
          {(data) => {
            const items = config.rows(data).filter((row) => row.value > 0);
            if (items.length === 0) return <EmptyState compact title="Nothing recorded" description="The scanner has not recorded anything here yet." />;
            return (
              <>
                <BarChart key={view} items={items.slice(0, 10)} onSelect={(item) => navigate(item.to)} color="var(--t-brand)" label={COMPOSITION.find((entry) => entry.value === view).label} />
                {items.length > 10 && <p className="mt-2 text-[12px] text-ink-3">Top 10 of {formatNumber(items.length)}.</p>}
              </>
            );
          }}
        </PanelBody>
      </div>
    </Panel>
  );
}
