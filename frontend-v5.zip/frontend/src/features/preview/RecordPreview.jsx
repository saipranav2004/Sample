import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { fetchCredential, fetchCredentialFlags, fetchIdentity } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatRelative } from '../../lib/format';
import { credentialTypeLabel, functionalClassLabel, identityTypeLabel, privilegeMeta, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { EASE_OUT } from '../../lib/motion';
import { Button, IconButton } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Drawer } from '../../ui/Overlay';
import { DetailList, DetailRow } from '../../ui/Panel';
import { DetailSkeleton, ListSkeleton } from '../../ui/Skeleton';
import { ErrorState } from '../../ui/States';
import { StatusText, Tag } from '../../ui/Tag';
import { FlagList } from '../credentials/flags';
import { ExpiryCell, RotationCell, TagChips } from '../credentials/parts';
import { SignalList, identitySignals } from '../identities/signals';

/**
 * Quick look at one row without leaving the list: what is wrong with it,
 * who owns it, and the dates that matter. Up and down (or J and K) step
 * through the rows behind it; the full page is one click away.
 *
 * Triage is "check ten rows in a row". Opening each one as a page costs a
 * load and the reader's place in the list every time.
 */
export function RecordPreview({ kind, rows, index, onIndexChange, onClose }) {
  const open = index !== null && index >= 0 && index < rows.length;
  const row = open ? rows[index] : null;
  const total = rows.length;

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      const tag = event.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((event.key === 'ArrowDown' || event.key === 'j') && index < total - 1) {
        event.preventDefault();
        onIndexChange(index + 1);
      }
      if ((event.key === 'ArrowUp' || event.key === 'k') && index > 0) {
        event.preventDefault();
        onIndexChange(index - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, index, total, onIndexChange]);

  const href = row ? `/${kind === 'identity' ? 'identities' : 'credentials'}/${encodeURIComponent(row.id)}` : '#';
  const typeLabel = row ? (kind === 'identity' ? identityTypeLabel(row.identity_type) : credentialTypeLabel(row.credential_type)) : '';

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="md"
      eyebrow={kind === 'identity' ? 'Identity' : 'Credential'}
      title={row ? row.name || row.arn : ''}
      subtitle={row ? [typeLabel, row.account_id && `account ${row.account_id}`, row.region && regionLabel(row.region)].filter(Boolean).join(' · ') : null}
      footer={
        <>
          <span className="mr-auto flex items-center gap-1">
            <IconButton icon={ChevronUp} label="Previous row (K)" size="sm" variant="secondary" disabled={!open || index === 0} onClick={() => onIndexChange(index - 1)} />
            <IconButton icon={ChevronDown} label="Next row (J)" size="sm" variant="secondary" disabled={!open || index >= total - 1} onClick={() => onIndexChange(index + 1)} />
            <span data-numeric="" className="ml-1.5 text-[12px] text-ink-3">
              {open ? `${index + 1} of ${total}` : ''}
            </span>
          </span>
          <Button as={Link} to={href} variant="primary" iconRight={ArrowRight}>
            Open {kind === 'identity' ? 'identity' : 'credential'}
          </Button>
        </>
      }
    >
      {/* Stepping between rows swaps the body with a short cross-fade, so the
          change of record is visible without the panel moving. */}
      <AnimatePresence mode="wait" initial={false}>
        {row && (
          <motion.div
            key={row.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_OUT }}
            className="flex flex-col gap-6 p-4 sm:p-5"
          >
            {kind === 'identity' ? <IdentityBody id={row.id} /> : <CredentialBody id={row.id} />}
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}

function Section({ title, children }) {
  return (
    <section>
      <h3 className="mb-2 text-[12px] font-semibold text-ink-3">{title}</h3>
      {children}
    </section>
  );
}

function When({ value, fallback }) {
  if (!value) return <span className="text-ink-3">{fallback}</span>;
  return <span title={formatDateTime(value)}>{formatRelative(value)}</span>;
}

function CredentialBody({ id }) {
  const detail = useQuery((signal) => fetchCredential(id, signal), [id]);
  const flags = useQuery((signal) => fetchCredentialFlags(id, signal), [id]);
  const credential = detail.data;

  return (
    <>
      <Section title="What needs attention">
        {flags.isError ? (
          <ErrorState compact error={flags.error} onRetry={flags.refetch} />
        ) : !flags.data ? (
          <ListSkeleton rows={2} />
        ) : (
          <FlagList flags={flags.data.flags} compact />
        )}
      </Section>
      {detail.isError ? (
        <ErrorState compact error={detail.error} onRetry={detail.refetch} />
      ) : !credential ? (
        <DetailSkeleton rows={6} />
      ) : (
        <>
          <Section title="Ownership">
            <DetailList>
              <DetailRow label="Owner principal" mono>
                {credential.owner_principal_arn ? <CopyableValue value={credential.owner_principal_arn} /> : <span className="font-sans text-ink-3">None recorded</span>}
              </DetailRow>
              <DetailRow label="Tags">
                <TagChips tags={credential.tags} />
              </DetailRow>
            </DetailList>
          </Section>
          <Section title="Lifecycle">
            <DetailList>
              <DetailRow label="Status">
                <StatusText tone={statusMeta(credential.status).tone}>{statusMeta(credential.status).label}</StatusText>
              </DetailRow>
              {credential.credential_type === 'iam_role' && (
                <DetailRow label="Privilege">
                  {credential.iam_role_details?.privilege_level ?? '-'} of 10 · {privilegeMeta(credential.iam_role_details?.privilege_level).label}
                </DetailRow>
              )}
              <DetailRow label="Last used">
                <When value={credential.last_used_at} fallback="Never, or not reported" />
              </DetailRow>
              <DetailRow label="Expires">
                <ExpiryCell value={credential.expires_at} />
              </DetailRow>
              <DetailRow label="Rotation">
                <RotationCell value={credential.rotation_enabled} />
              </DetailRow>
              <DetailRow label="Last rotated">
                <When value={credential.last_rotated_at} fallback="Never rotated" />
              </DetailRow>
            </DetailList>
          </Section>
          <Section title="ARN">
            <span className="text-[12px]">
              <CopyableValue value={credential.arn} />
            </span>
          </Section>
        </>
      )}
    </>
  );
}

function IdentityBody({ id }) {
  const detail = useQuery((signal) => fetchIdentity(id, signal), [id]);
  const identity = detail.data;
  if (detail.isError) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!identity) {
    return (
      <>
        <ListSkeleton rows={2} />
        <DetailSkeleton rows={6} />
      </>
    );
  }
  const status = statusMeta(identity.status);
  return (
    <>
      <Section title="What needs attention">
        <SignalList signals={identitySignals(identity)} />
      </Section>
      <Section title="Ownership">
        <DetailList>
          <DetailRow label="Owner">{identity.ownership?.owner || <span className="text-ink-3">None recorded</span>}</DetailRow>
          <DetailRow label="Environment">{identity.ownership?.environment || <span className="text-ink-3">None recorded</span>}</DetailRow>
          <DetailRow label="Class">{functionalClassLabel(identity.functional_class)}</DetailRow>
        </DetailList>
      </Section>
      <Section title="Activity">
        <DetailList>
          <DetailRow label="Status">
            <StatusText tone={status.tone}>{status.label}</StatusText>
          </DetailRow>
          <DetailRow label="Last active">
            <When value={identity.last_activity_at} fallback="Not tracked by AWS" />
          </DetailRow>
          <DetailRow label="First discovered">
            <When value={identity.first_seen_at} fallback="-" />
          </DetailRow>
          <DetailRow label="Source">{tokenLabel(identity.discovery?.discovery_source)}</DetailRow>
        </DetailList>
      </Section>
      {identity.deleted_at && <Tag tone="neutral">Removed {formatRelative(identity.deleted_at)}</Tag>}
      <Section title="ARN">
        <span className="text-[12px]">
          <CopyableValue value={identity.arn} />
        </span>
      </Section>
    </>
  );
}
