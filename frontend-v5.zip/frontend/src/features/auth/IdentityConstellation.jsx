import { memo, useEffect, useRef } from 'react';
import { animate, createDrawable, createTimeline, stagger } from 'animejs';

/**
 * Decorative backdrop for the sign-in screen, animated with anime.js: an AWS
 * account at the centre, the workloads acting in it, and the credentials
 * those workloads hold. Links draw outward from the account (createDrawable),
 * nodes settle in a stagger, then credentials pulse slowly as if being
 * re-scanned. Purely visual, hidden from assistive tech, and still when the
 * reader asks for reduced motion.
 */

const W = 1200;
const H = 800;
const HUB = { x: 600, y: 400 };

/* Fixed geometry so the picture is the same on every load. */
const WORKLOADS = [0, 1, 2, 3, 4, 5, 6].map((index) => {
  const angle = (-90 + index * (360 / 7) + 12) * (Math.PI / 180);
  const radius = index % 2 ? 205 : 180;
  return { id: `w${index}`, x: HUB.x + Math.cos(angle) * radius, y: HUB.y + Math.sin(angle) * radius, angle };
});

const CREDENTIALS = WORKLOADS.flatMap((workload, index) => {
  const spread = index % 3 === 0 ? [-0.32, 0.3] : [index % 2 ? 0.18 : -0.2];
  return spread.map((offset, sub) => {
    const angle = workload.angle + offset;
    const radius = 330 + ((index + sub) % 3) * 34;
    return { id: `c${index}-${sub}`, parent: workload, x: HUB.x + Math.cos(angle) * radius, y: HUB.y + Math.sin(angle) * radius };
  });
});

/* A few workloads share a credential's reach: the cross links an inventory
   exists to surface. */
const CROSS = [
  [WORKLOADS[0], WORKLOADS[1]],
  [WORKLOADS[3], WORKLOADS[4]],
  [WORKLOADS[5], WORKLOADS[6]],
];

function prefersReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

export const IdentityConstellation = memo(function IdentityConstellation({ className }) {
  const root = useRef(null);
  const still = useRef(prefersReducedMotion());

  useEffect(() => {
    const svg = root.current;
    if (!svg || still.current) return undefined;

    const spokes = createDrawable(svg.querySelectorAll('[data-link="spoke"]'));
    const branches = createDrawable(svg.querySelectorAll('[data-link="branch"]'));
    const cross = createDrawable(svg.querySelectorAll('[data-link="cross"]'));

    const intro = createTimeline({ defaults: { ease: 'outExpo' } })
      .add(svg.querySelector('[data-node="hub"]'), { scale: [0, 1], opacity: [0, 1], duration: 700 })
      .add(spokes, { draw: ['0 0', '0 1'], opacity: [0, 1], duration: 900, delay: stagger(70) }, '-=450')
      .add(svg.querySelectorAll('[data-node="workload"]'), { scale: [0, 1], opacity: [0, 1], duration: 600, delay: stagger(70) }, '-=800')
      .add(branches, { draw: ['0 0', '0 1'], opacity: [0, 1], duration: 800, delay: stagger(45) }, '-=500')
      .add(svg.querySelectorAll('[data-node="credential"]'), { scale: [0, 1], opacity: [0, 1], duration: 500, delay: stagger(40) }, '-=700')
      .add(cross, { draw: ['0 0', '0 1'], opacity: [0, 1], duration: 1100, delay: stagger(160), ease: 'inOutQuad' }, '-=300');

    const pulse = animate(svg.querySelectorAll('[data-pulse]'), {
      scale: [1, 2.6],
      opacity: [0.55, 0],
      duration: 2600,
      delay: stagger(380, { start: 2600 }),
      loop: true,
      ease: 'outQuad',
    });

    const scan = animate(svg.querySelector('[data-scan]'), {
      rotate: [0, 360],
      duration: 14000,
      loop: true,
      ease: 'linear',
    });

    return () => {
      intro.revert();
      pulse.revert();
      scan.revert();
    };
  }, []);

  /* Before the intro runs, everything that animates in starts hidden; with
     reduced motion it is simply drawn. */
  const hidden = still.current ? undefined : { opacity: 0 };

  return (
    <svg ref={root} viewBox={`0 0 ${W} ${H}`} aria-hidden="true" focusable="false" className={className} preserveAspectRatio="xMidYMid meet">
      <defs>
        <radialGradient id="constellation-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--t-auth-accent)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--t-auth-accent)" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="constellation-sweep" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="var(--t-auth-accent)" stopOpacity="0" />
          <stop offset="100%" stopColor="var(--t-auth-accent)" stopOpacity="0.22" />
        </linearGradient>
      </defs>

      <circle cx={HUB.x} cy={HUB.y} r="390" fill="url(#constellation-glow)" />
      {[180, 270, 360].map((r) => (
        <circle key={r} cx={HUB.x} cy={HUB.y} r={r} fill="none" stroke="var(--t-auth-ink-2)" strokeOpacity="0.12" strokeDasharray="2 7" />
      ))}

      {/* Scanner sweep: a slow wedge turning round the account. */}
      <g data-scan="" style={{ transformOrigin: `${HUB.x}px ${HUB.y}px`, transformBox: 'view-box' }}>
        <path d={`M ${HUB.x} ${HUB.y} L ${HUB.x + 380} ${HUB.y} A 380 380 0 0 0 ${HUB.x + 380 * Math.cos(-0.5)} ${HUB.y + 380 * Math.sin(-0.5)} Z`} fill="url(#constellation-sweep)" />
      </g>

      <g fill="none" strokeLinecap="round">
        {WORKLOADS.map((node) => (
          <line key={node.id} data-link="spoke" x1={HUB.x} y1={HUB.y} x2={node.x} y2={node.y} stroke="var(--t-auth-accent)" strokeOpacity="0.55" strokeWidth="1.6" style={hidden} />
        ))}
        {CREDENTIALS.map((node) => (
          <line key={node.id} data-link="branch" x1={node.parent.x} y1={node.parent.y} x2={node.x} y2={node.y} stroke="var(--t-auth-ink-2)" strokeOpacity="0.4" strokeWidth="1.2" style={hidden} />
        ))}
        {CROSS.map(([a, b]) => (
          <line
            key={`${a.id}-${b.id}`}
            data-link="cross"
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke="var(--t-auth-accent)"
            strokeOpacity="0.35"
            strokeWidth="1"
            style={hidden}
          />
        ))}
      </g>

      {CREDENTIALS.map((node, index) => (
        <g key={node.id} transform={`translate(${node.x} ${node.y})`}>
          {index % 3 === 0 && <circle data-pulse="" r="7" fill="none" stroke="var(--t-auth-accent)" strokeWidth="1.2" style={{ transformBox: 'fill-box', transformOrigin: 'center', opacity: 0 }} />}
          <g data-node="credential" style={{ transformBox: 'fill-box', transformOrigin: 'center', ...hidden }}>
            <rect x="-6" y="-6" width="12" height="12" rx="3" fill="var(--t-auth-canvas)" stroke="var(--t-auth-ink-2)" strokeOpacity="0.85" strokeWidth="1.4" transform="rotate(45)" />
          </g>
        </g>
      ))}

      {WORKLOADS.map((node) => (
        <g key={node.id} transform={`translate(${node.x} ${node.y})`}>
          <g data-node="workload" style={{ transformBox: 'fill-box', transformOrigin: 'center', ...hidden }}>
            <circle r="13" fill="var(--t-auth-canvas)" stroke="var(--t-auth-accent)" strokeWidth="1.8" />
            <circle r="4.5" fill="var(--t-auth-accent)" />
          </g>
        </g>
      ))}

      <g transform={`translate(${HUB.x} ${HUB.y})`}>
        <g data-node="hub" style={{ transformBox: 'fill-box', transformOrigin: 'center', ...hidden }}>
          <circle r="30" fill="var(--t-auth-canvas)" stroke="var(--t-auth-accent)" strokeWidth="2" />
          <circle r="21" fill="var(--t-auth-accent)" fillOpacity="0.16" />
          {/* A cloud, for the account. */}
          <path d="M-10 6 h20 a6 6 0 0 0 0-12 a8 8 0 0 0-15-2 a5.5 5.5 0 0 0-5 14 z" fill="none" stroke="var(--t-auth-accent)" strokeWidth="2" strokeLinejoin="round" />
        </g>
      </g>
    </svg>
  );
});
