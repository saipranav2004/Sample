import { Minus, Plus } from 'lucide-react';
import { formatDateTime, formatRelative } from '../../lib/format';
import { regionLabel, tokenLabel } from '../../lib/labels';
import { Tag } from '../../ui/Tag';
import { cn } from '../../ui/cn';

/** One discovered or removed identity or credential, as the feed shows it. */
export function DiscoveryRow({ item }) {
  const isNew = item.event === 'new';
  const identity = item.entity === 'identity';
  return (
    <span className="flex min-w-0 items-center gap-3 px-1 py-2.5">
      <span
        aria-hidden="true"
        className={cn(
          'grid size-7 shrink-0 place-items-center rounded-full border',
          isNew ? 'border-low/25 bg-low-soft text-low' : 'border-line-strong bg-surface-3 text-ink-3',
        )}
      >
        {isNew ? <Plus className="size-3.5" /> : <Minus className="size-3.5" />}
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex min-w-0 items-center gap-2">
          <span className="truncate text-[13px] font-medium text-ink">{item.name || item.arn || 'Unnamed'}</span>
          <Tag size="sm" tone={identity ? 'brand' : 'info'}>
            {identity ? 'Identity' : 'Credential'}
          </Tag>
        </span>
        <span className="mt-0.5 block truncate text-[11.5px] text-ink-3">
          {[tokenLabel(item.type), item.account_id, regionLabel(item.region)].filter((part) => part && part !== '-').join(' · ')}
        </span>
      </span>
      <span className="shrink-0 text-right text-[11.5px] text-ink-3">
        <span className={cn('block font-semibold', isNew ? 'text-low' : 'text-ink-2')}>{isNew ? 'Discovered' : 'Removed'}</span>
        <time dateTime={item.discovered_at} title={formatDateTime(item.discovered_at)}>
          {formatRelative(item.discovered_at)}
        </time>
      </span>
    </span>
  );
}
