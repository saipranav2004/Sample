/**
 * The identity list's URL state, read and validated against the rules
 * `GET /api/v1/inventory/identities` enforces. A hand-edited or stale link
 * with a value the API would reject is dropped here instead of turning the
 * whole screen into a 400.
 */

export const SORTABLE = [
  'name',
  'identity_type',
  'functional_class',
  'account_id',
  'region',
  'status',
  'created_at_aws',
  'last_seen_at',
  'last_activity_at',
];

export const PAGE_SIZES = [25, 50, 100, 200];
export const DEFAULT_LIMIT = 50;

const ACCOUNT = /^[0-9]{12}$/;
const REGION = /^[a-z0-9-]{1,64}$/;
const TOKEN = /^[a-zA-Z0-9_-]{1,100}$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

function cleanText(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  return text.length > 256 || /[\0\r\n]/.test(text) ? '' : text;
}

function positiveInt(value, fallback, max) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1 && n <= max ? n : fallback;
}

/** Every filter the screen supports, as it appears in the URL. */
export const FILTER_KEYS = [
  'search',
  'identity_type',
  'functional_class',
  'account_id',
  'region',
  'status',
  'owner',
  'environment',
  'is_public',
  'last_active_before',
];

export function readListState(searchParams) {
  const get = (key) => cleanText(searchParams.get(key) ?? '');
  const filters = {
    search: get('search'),
    identity_type: TOKEN.test(get('identity_type')) ? get('identity_type') : '',
    functional_class: TOKEN.test(get('functional_class')) ? get('functional_class') : '',
    account_id: ACCOUNT.test(get('account_id')) ? get('account_id') : '',
    region: REGION.test(get('region')) ? get('region') : '',
    status: TOKEN.test(get('status')) ? get('status') : '',
    owner: get('owner'),
    environment: get('environment'),
    is_public: ['true', 'false'].includes(get('is_public')) ? get('is_public') : '',
    last_active_before:
      DATE.test(get('last_active_before')) && !Number.isNaN(Date.parse(`${get('last_active_before')}T00:00:00Z`))
        ? get('last_active_before')
        : '',
  };
  const sortBy = SORTABLE.includes(get('sort_by')) ? get('sort_by') : 'last_seen_at';
  const sortOrder = get('sort_order') === 'asc' ? 'asc' : 'desc';
  return {
    filters,
    page: positiveInt(get('page'), 1, 1_000_000),
    limit: PAGE_SIZES.includes(Number(get('limit'))) ? Number(get('limit')) : DEFAULT_LIMIT,
    sort: { key: sortBy, direction: sortOrder },
  };
}

/** Filters as the API takes them: dates become RFC 3339 instants. */
export function toApiFilters(filters) {
  return {
    ...filters,
    last_active_before: filters.last_active_before ? `${filters.last_active_before}T00:00:00Z` : '',
  };
}

export function appliedCount(filters) {
  return FILTER_KEYS.filter((key) => filters[key]).length;
}
