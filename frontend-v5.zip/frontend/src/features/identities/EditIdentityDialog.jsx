import { useEffect, useId, useState } from 'react';
import { Pencil } from 'lucide-react';
import { updateIdentity } from '../../lib/api/endpoints';
import { useMutation } from '../../lib/hooks';
import { functionalClassLabel } from '../../lib/labels';
import { optionsOf, resetFilterOptions, useFilterOptions } from '../../lib/useFilterOptions';
import { Button } from '../../ui/Button';
import { Field, Input, Select } from '../../ui/Field';
import { Modal } from '../../ui/Overlay';
import { useToast } from '../../ui/Toast';

const MAX = 256;
const FIELDS = ['functional_class', 'owner', 'environment'];

function initialOf(identity) {
  return {
    functional_class: identity.functional_class ?? '',
    owner: identity.ownership?.owner ?? '',
    environment: identity.ownership?.environment ?? '',
  };
}

/**
 * PATCH /api/v1/inventory/identities/{id}: functional class, owner and
 * environment. Only fields that changed are sent. Clearing owner or
 * environment sends an empty value, which the inventory counts as missing.
 */
export function EditIdentityDialog({ open, identity, onClose, onSaved }) {
  const formId = useId();
  const { notify } = useToast();
  const filterQuery = useFilterOptions();
  const classes = optionsOf(filterQuery).functionalClasses;
  const save = useMutation((patch) => updateIdentity(identity.id, patch));

  /* Restart from the saved record on every open, during render so the last
     session's values are never painted. */
  const [form, setForm] = useState(() => ({ open, initial: initialOf(identity), values: initialOf(identity) }));
  if (form.open !== open) setForm({ open, initial: initialOf(identity), values: initialOf(identity) });
  const { initial, values } = form;
  const setValues = (update) => setForm((current) => ({ ...current, values: update(current.values) }));

  useEffect(() => {
    if (open) save.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const patch = Object.fromEntries(
    FIELDS.map((name) => [name, values[name].trim()]).filter(([name, value]) => value !== initial[name].trim()),
  );
  const tooLong = FIELDS.find((name) => values[name].trim().length > MAX);
  const invalid = Boolean(tooLong) || (patch.functional_class !== undefined && !patch.functional_class);
  const nothing = Object.keys(patch).length === 0;

  const classOptions = [...new Set([...classes, initial.functional_class].filter(Boolean))].map((value) => ({
    value,
    label: functionalClassLabel(value),
  }));

  const submit = async (event) => {
    event.preventDefault();
    if (invalid || nothing) return;
    const result = await save.mutate(patch);
    if (result.ok) {
      const fields = result.result.updated_fields ?? Object.keys(patch);
      notify({ variant: 'success', title: 'Identity updated', description: `Saved ${fields.map((field) => field.replace('_', ' ')).join(', ')}.` });
      if (patch.functional_class) resetFilterOptions();
      onSaved();
    }
  };

  return (
    <Modal
      open={open}
      onClose={save.pending ? () => {} : onClose}
      title="Edit ownership"
      description={`Saved to the inventory record for ${identity.name || identity.arn}.`}
      icon={Pencil}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={save.pending}>
            Cancel
          </Button>
          <Button variant="primary" type="submit" form={formId} loading={save.pending} disabled={nothing || invalid}>
            Save changes
          </Button>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Field label="Functional class" htmlFor={`${formId}-class`} hint="What the identity is for.">
          <Select
            id={`${formId}-class`}
            value={values.functional_class}
            onChange={(event) => setValues((current) => ({ ...current, functional_class: event.target.value }))}
            placeholder={initial.functional_class ? undefined : 'Not classified'}
            options={classOptions}
          />
        </Field>
        <Field
          label="Owner"
          htmlFor={`${formId}-owner`}
          hint="The team or person responsible. Leave empty to clear."
          error={values.owner.trim().length > MAX ? `Keep it to ${MAX} characters or fewer.` : null}
        >
          <Input
            id={`${formId}-owner`}
            value={values.owner}
            maxLength={MAX}
            autoComplete="off"
            spellCheck={false}
            placeholder="platform-team"
            onChange={(event) => setValues((current) => ({ ...current, owner: event.target.value }))}
          />
        </Field>
        <Field
          label="Environment"
          htmlFor={`${formId}-env`}
          hint="Where it runs. Leave empty to clear."
          error={values.environment.trim().length > MAX ? `Keep it to ${MAX} characters or fewer.` : null}
        >
          <Input
            id={`${formId}-env`}
            value={values.environment}
            maxLength={MAX}
            autoComplete="off"
            spellCheck={false}
            placeholder="production"
            onChange={(event) => setValues((current) => ({ ...current, environment: event.target.value }))}
          />
        </Field>
        {save.error && (
          <p role="alert" className="rounded-[var(--radius-control)] border border-critical/25 bg-critical-soft px-3 py-2 text-[12.5px] text-ink-2">
            <span className="font-medium text-critical">Not saved.</span> {save.error.message}
          </p>
        )}
      </form>
    </Modal>
  );
}
