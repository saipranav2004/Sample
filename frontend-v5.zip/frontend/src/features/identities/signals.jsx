import { CheckCircle2, Globe2, Moon, Tag as TagIcon, UserX } from 'lucide-react';
import { parseDate } from '../../lib/format';
import { RevealItem, RevealList } from '../../lib/motion';
import { Tag } from '../../ui/Tag';
import { TONE_VAR } from '../../ui/cn';

const DAY = 86400000;

/**
 * What needs attention on one identity, read from fields the API returns.
 * The same tests the dashboard's exposure panel counts, applied to one record
 * - no score is invented.
 */
export function identitySignals(identity) {
  if (!identity || identity.deleted_at) return [];
  const signals = [];
  const pub = identity.network?.is_publicly_accessible ?? identity.is_publicly_accessible;
  if (pub === true) {
    signals.push({
      key: 'public',
      tone: 'critical',
      label: 'Reachable from the internet',
      hint: 'Check it needs to be public; restrict its security groups if not.',
      icon: Globe2,
    });
  }
  const last = parseDate(identity.last_activity_at);
  if (last) {
    const days = Math.floor((Date.now() - last.getTime()) / DAY);
    if (days >= 90) {
      signals.push({
        key: 'dormant',
        tone: 'high',
        label: `Not used for ${days} days`,
        hint: 'Confirm with the owner, then remove it if it is no longer needed.',
        icon: Moon,
      });
    }
  }
  const owner = identity.ownership ? identity.ownership.owner : identity.owner;
  if (!owner) {
    signals.push({
      key: 'owner',
      tone: 'medium',
      label: 'No owner recorded',
      hint: 'Nobody is answerable for it. Set an owner.',
      icon: UserX,
    });
  }
  const environment = identity.ownership ? identity.ownership.environment : identity.environment;
  if (!environment && identity.ownership) {
    signals.push({
      key: 'environment',
      tone: 'medium',
      label: 'No environment recorded',
      hint: 'Mark it production, staging or similar so it can be prioritised.',
      icon: TagIcon,
    });
  }
  return signals;
}

export function SignalList({ signals, emptyText = 'Nothing needs attention on this identity.' }) {
  if (signals.length === 0) {
    return (
      <div className="flex items-center gap-2.5 rounded-[var(--radius-control)] border border-line bg-surface-2/60 px-3.5 py-3 text-[13px] text-ink-2">
        <CheckCircle2 aria-hidden="true" className="size-4 shrink-0 text-low" />
        {emptyText}
      </div>
    );
  }
  return (
    <RevealList as="ul" className="flex flex-col gap-2">
      {signals.map((signal, index) => (
        <RevealItem as="li" index={index} key={signal.key} className="flex items-start gap-3 rounded-[var(--radius-control)] border border-line bg-surface px-3.5 py-3">
          <signal.icon aria-hidden="true" className="mt-0.5 size-4 shrink-0" style={{ color: TONE_VAR[signal.tone] }} />
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-medium text-ink">{signal.label}</p>
            <p className="mt-0.5 text-[12px] text-ink-2">{signal.hint}</p>
          </div>
          <Tag size="sm" tone={signal.tone}>
            {signal.tone === 'critical' ? 'Critical' : signal.tone === 'high' ? 'High' : 'Medium'}
          </Tag>
        </RevealItem>
      ))}
    </RevealList>
  );
}
