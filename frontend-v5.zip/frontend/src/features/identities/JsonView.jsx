import { tokenLabel } from '../../lib/labels';
import { CopyButton } from '../../ui/Copyable';
import { DetailList, DetailRow } from '../../ui/Panel';
import { EmptyState } from '../../ui/States';

/**
 * Read-only views of the JSON columns the API passes through untouched
 * (`type_attributes`, `raw_api_response`, `tags`). Values are rendered as text
 * by React, never as HTML, so nothing in the scanned data can run in the page.
 */

function isEmpty(value) {
  if (value === null || value === undefined) return true;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return value === '';
}

function scalar(value) {
  if (value === null || value === undefined) return <span className="text-ink-3">-</span>;
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  return String(value);
}

/** Top-level keys as rows; nested values as formatted JSON beneath their key. */
export function AttributeList({ value, emptyTitle, emptyText }) {
  if (isEmpty(value) || typeof value !== 'object') {
    if (!isEmpty(value)) return <p className="font-mono text-[12.5px] break-words text-ink">{scalar(value)}</p>;
    return <EmptyState compact title={emptyTitle} description={emptyText} />;
  }
  const entries = Array.isArray(value) ? value.map((item, index) => [String(index + 1), item]) : Object.entries(value);
  return (
    <DetailList>
      {entries.map(([key, item]) => (
        <DetailRow key={key} label={Array.isArray(value) ? `Item ${key}` : tokenLabel(key)} mono={typeof item !== 'object' || item === null}>
          {item !== null && typeof item === 'object' ? <JsonBlock value={item} compact /> : scalar(item)}
        </DetailRow>
      ))}
    </DetailList>
  );
}

export function JsonBlock({ value, compact = false, copyLabel }) {
  const text = JSON.stringify(value, null, 2);
  return (
    <div className="relative">
      {copyLabel && (
        <div className="absolute top-2 right-2">
          <CopyButton value={text} label={copyLabel} size="sm" />
        </div>
      )}
      <pre
        className={
          compact
            ? 'max-h-64 overflow-auto rounded-md border border-line bg-surface-2 p-2.5 font-mono text-[11.5px] leading-relaxed whitespace-pre-wrap break-words text-ink-2'
            : 'max-h-[70vh] overflow-auto rounded-[var(--radius-control)] border border-line bg-surface-2 p-4 font-mono text-[12px] leading-relaxed whitespace-pre-wrap break-words text-ink-2'
        }
      >
        {text}
      </pre>
    </div>
  );
}

/**
 * AWS returns tags as `[{ Key, Value }]`; the inventory may also hold them as
 * a plain object. Both read as key/value pairs here.
 */
export function tagEntries(tags) {
  if (!tags || typeof tags !== 'object') return [];
  if (Array.isArray(tags)) {
    return tags
      .filter((tag) => tag && typeof tag === 'object' && ('Key' in tag || 'key' in tag))
      .map((tag) => [String(tag.Key ?? tag.key), tag.Value ?? tag.value ?? '']);
  }
  return Object.entries(tags).map(([key, value]) => [key, value]);
}
