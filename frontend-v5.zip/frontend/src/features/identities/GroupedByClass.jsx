import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { fetchIdentitiesGrouped } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatNumber } from '../../lib/format';
import { RevealItem, RevealList } from '../../lib/motion';
import { functionalClassLabel, identityTypeLabel, statusMeta } from '../../lib/labels';
import { Select } from '../../ui/Field';
import { Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tag } from '../../ui/Tag';

const PER_CLASS = [5, 10, 25];

/**
 * GET /api/v1/inventory/identities/grouped-by-class: every functional class
 * with its total and a sample of its identities. The endpoint filters by
 * account and region only, so other list filters do not apply here.
 */
export function GroupedByClass({ accountId, region }) {
  const [perClass, setPerClass] = useState(5);
  const query = useQuery(
    (signal) => fetchIdentitiesGrouped({ account_id: accountId, region, limit_per_class: perClass }, signal),
    [accountId, region, perClass],
  );

  return (
    <div className="p-3 sm:p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-[12.5px] text-ink-3">
          Grouping honours the account and region filters only.
        </p>
        <label className="flex items-center gap-2 text-[12.5px] text-ink-3">
          Show per class
          <Select
            size="sm"
            value={String(perClass)}
            onChange={(event) => setPerClass(Number(event.target.value))}
            options={PER_CLASS.map((n) => ({ value: String(n), label: String(n) }))}
            className="w-18"
            aria-label="Identities shown per class"
          />
        </label>
      </div>

      {query.isLoading && !query.data ? (
        <div className="grid gap-3 @min-[48rem]:grid-cols-2 @min-[80rem]:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <Skeleton key={index} className="h-48 rounded-[var(--radius-panel)]" />
          ))}
        </div>
      ) : query.isError && !query.data ? (
        <ErrorState error={query.error} onRetry={query.refetch} compact />
      ) : query.data.groups.length === 0 ? (
        <EmptyState title="No identities to group" description="Nothing matches the account and region filters." />
      ) : (
        <RevealList as="div" className="grid gap-3 @min-[48rem]:grid-cols-2 @min-[80rem]:grid-cols-3">
          {query.data.groups.map((group, index) => (
            <RevealItem
              index={index}
              as="section"
              key={group.functional_class}
              className="flex flex-col rounded-[var(--radius-panel)] border border-line bg-surface-2/50 p-3.5"
            >
              <header className="flex items-baseline justify-between gap-2">
                <h3 className="truncate text-[13.5px] font-semibold text-ink">{functionalClassLabel(group.functional_class)}</h3>
                <span data-numeric="" className="font-display text-[18px] font-bold text-ink">
                  {formatNumber(group.count)}
                </span>
              </header>
              <ul className="mt-2 flex-1 divide-y divide-line/70">
                {group.identities.map((identity) => {
                  const status = statusMeta(identity.status);
                  return (
                    <li key={identity.id}>
                      <Link
                        to={`/identities/${encodeURIComponent(identity.id)}`}
                        className="flex items-center gap-2 rounded-md px-1 py-2 text-[12.5px] transition-colors hover:bg-surface"
                      >
                        <span className="min-w-0 flex-1">
                          <span className="block truncate font-medium text-ink">{identity.name}</span>
                          <span className="block truncate text-[11.5px] text-ink-3">{identityTypeLabel(identity.identity_type)}</span>
                        </span>
                        <Tag size="sm" tone={status.tone} dot>
                          {status.label}
                        </Tag>
                      </Link>
                    </li>
                  );
                })}
              </ul>
              {group.count > group.identities.length && (
                <Link
                  to={`/identities?functional_class=${encodeURIComponent(group.functional_class)}${accountId ? `&account_id=${accountId}` : ''}${region ? `&region=${encodeURIComponent(region)}` : ''}`}
                  className="mt-2 inline-flex items-center gap-1 self-start text-[12.5px] font-medium text-brand hover:underline"
                >
                  All {formatNumber(group.count)} <ArrowRight aria-hidden="true" className="size-3.5" />
                </Link>
              )}
            </RevealItem>
          ))}
        </RevealList>
      )}
    </div>
  );
}
