import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Copy, Download, FileJson, Globe2, LayoutGrid, Rows3, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import {
  fetchIdentities,
  fetchIdentitiesByAccount,
  fetchIdentitiesByRegion,
  fetchIdentityCounts,
} from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { useExport } from '../../lib/useExport';
import { Page, Reveal } from '../../lib/motion';
import { SegmentedControl } from '../../ui/Tabs';
import { GroupedByClass } from './GroupedByClass';
import { formatDateTime, formatNumber, formatRelativeShort } from '../../lib/format';
import { functionalClassLabel, identityTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { StatStripSkeleton } from '../../ui/Skeleton';
import { MetricTile } from '../../ui/Stat';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { StatusText } from '../../ui/Tag';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { FILTER_KEYS, PAGE_SIZES, appliedCount, readListState, toApiFilters } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const FILTER_LABELS = {
  search: 'Search',
  identity_type: 'Type',
  functional_class: 'Class',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  owner: 'Owner',
  environment: 'Environment',
  is_public: 'Public',
  last_active_before: 'Last active before',
};

/**
 * Identity inventory: `GET /api/v1/inventory/identities`, filtered, sorted and
 * paged on the server. All state lives in the URL, so a dashboard drill-down,
 * a bookmark and a shared link resolve to the same list.
 */
export default function IdentitiesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const { railOpen, toggleRail } = useFacetRail();
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => readDensity());

  /* Apply URL changes: every filter change returns to page one. */
  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next, { replace: false });
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  /* Back/forward or a link can change the search in the URL underneath. */
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const apiFilters = toApiFilters(filters);
  const listKey = JSON.stringify([apiFilters, page, limit, sort]);
  const list = useQuery(
    (signal) =>
      fetchIdentities({ ...apiFilters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
  );
  const counts = useQuery((signal) => fetchIdentityCounts({}, signal), []);
  const accounts = useQuery((signal) => fetchIdentitiesByAccount({}, signal), []);
  const regions = useQuery((signal) => fetchIdentitiesByRegion({}, signal), []);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  /* A page past the end (rows removed since the link was made) goes back to
     the last page that exists rather than showing an empty table. */
  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const facetGroups = useFacetGroups({ filters, counts: counts.data, accounts: accounts.data, regions: regions.data, update });

  const chips = FILTER_KEYS.filter((key) => filters[key]).map((key) => ({
    key,
    label: FILTER_LABELS[key],
    value: describeValue(key, filters[key]),
  }));

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('identities');
  const exporting = exporter.exporting;
  /* Export takes the list filters; page and limit are left off so the file
     holds every match, not the page on screen. */
  const onExport = (format) => exporter.run(format, { ...apiFilters, sort_by: sort.key, sort_order: sort.direction });
  const view = searchParams.get('view') === 'class' ? 'class' : 'table';

  const columns = [
    {
      key: 'name',
      header: 'Identity',
      primary: true,
      sortable: true,
      cell: (row) => <CellStack title={row.name || row.arn} />,
    },
    {
      key: 'identity_type',
      header: 'Type',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => <span className="block truncate" title={identityTypeLabel(row.identity_type)}>{identityTypeLabel(row.identity_type)}</span>,
    },
    {
      key: 'functional_class',
      header: 'Class',
      sortable: true,
      width: '112px',
      priority: 'wide',
      cell: (row) => <span className="block truncate" title={functionalClassLabel(row.functional_class)}>{functionalClassLabel(row.functional_class)}</span>,
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '122px',
      priority: 'wide',
      cell: (row) => <span className="block font-mono text-[12px]">{row.account_id}</span>,
    },
    {
      key: 'region',
      header: 'Region',
      sortable: true,
      width: '104px',
      priority: 'xl',
      cell: (row) => <span className="block truncate font-mono text-[12px]">{regionLabel(row.region)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '112px',
      mobile: true,
      cell: (row) => {
        const meta = statusMeta(row.status);
        return (
          <span className="inline-flex max-w-full items-center gap-2">
            <StatusText tone={meta.tone}>{meta.label}</StatusText>
            {row.is_publicly_accessible === true && (
              <Globe2 aria-label="Publicly accessible" className="size-3.5 shrink-0 text-critical">
                <title>Publicly accessible</title>
              </Globe2>
            )}
          </span>
        );
      },
    },
    {
      key: 'owner',
      header: 'Owner',
      width: '120px',
      priority: 'xl',
      cell: (row) => (row.owner ? <span className="block truncate" title={row.owner}>{row.owner}</span> : <span className="block truncate text-ink-3">None</span>),
    },
    {
      key: 'last_activity_at',
      header: 'Last active',
      sortable: true,
      width: '104px',
      mobile: true,
      cell: (row) =>
        row.last_activity_at ? (
          <span className="block truncate" title={formatDateTime(row.last_activity_at)}>{formatRelativeShort(row.last_activity_at)}</span>
        ) : (
          <span className="block truncate text-ink-3" title="AWS records no last-used time for this identity">
            Not tracked
          </span>
        ),
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
      <PageHeader
        title="Identities"
        lede="Every non-human identity discovered in your AWS accounts. Open one for its full record, timeline and type-specific attributes."
        actions={
          <>
            <Button
              variant="secondary"
              icon={Download}
              loading={exporting === 'csv'}
              disabled={Boolean(exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          </>
        }
      />
      </Reveal>

      <Reveal>
        <CountsStrip query={counts} onSelect={(status) => update({ status })} />
      </Reveal>

      <Reveal>
      <WorkArea
        railOpen={railOpen}
        rail={
          <FacetRail
            groups={facetGroups}
            appliedCount={applied}
            onClearAll={clearAll}
            onClose={toggleRail}
          />
        }
      >
        <Panel flush className="overflow-hidden">
          <RecordBar
            trailing={
              <TableToolbar>
                <SegmentedControl
                  label="View"
                  value={view}
                  onChange={(next) => update({ view: next === 'class' ? 'class' : '' }, { keepPage: true })}
                  options={[
                    { value: 'table', label: 'Table', icon: Rows3 },
                    { value: 'class', label: 'By class', icon: LayoutGrid },
                  ]}
                />
                {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                <TableSettings
                  density={density}
                  onDensityChange={(value) => {
                    setDensity(value);
                    writeDensity(value);
                  }}
                />
                <OverflowMenu
                  items={[
                    {
                      key: 'json',
                      label: 'Export as JSON',
                      hint: 'Every identity matching these filters, with full records',
                      icon: FileJson,
                      onSelect: () => onExport('json'),
                      disabled: Boolean(exporting) || !can('data.export'),
                      disabledHint: exporting ? 'An export is already running' : lock('data.export'),
                    },
                  ]}
                />
              </TableToolbar>
            }
          >
            <SearchInput
              size="sm"
              value={searchDraft}
              onChange={setSearchDraft}
              maxLength={256}
              placeholder="Search name or ARN…"
              className="w-full min-w-0 sm:max-w-sm"
            />
            <ResultCount
              shown={formatNumber(total)}
              unit={total === 1 ? 'identity' : 'identities'}
              loading={list.isLoading && !list.data}
            />
          </RecordBar>

          <AppliedFilters
            filters={chips}
            onRemove={(key) => {
              if (key === 'search') setSearchDraft('');
              update({ [key]: '' });
            }}
            onClearAll={clearAll}
          />

          {view === 'class' ? (
            <GroupedByClass accountId={filters.account_id} region={filters.region} />
          ) : list.isError && !list.data ? (
            <ErrorState
              error={list.error}
              onRetry={list.error?.status === 400 ? undefined : list.refetch}
              title={list.error?.status === 400 ? 'These filters were not accepted' : undefined}
            />
          ) : (
            <>
              {list.isError && (
                <div className="p-3">
                  <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                </div>
              )}
              <DataGrid
                caption="Discovered identities"
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                loading={list.isLoading && !list.data}
                refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                onRowClick={(row, event) => {
                  if (event?.metaKey || event?.ctrlKey) window.open(`/identities/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                  else setPeek(rows.indexOf(row));
                }}
                selectedKey={peek !== null ? rows[peek]?.id : undefined}
                rowLabel={(row) => `Preview ${row.name || row.arn}`}
                sort={sort}
                onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction }, { keepPage: false })}
                density={density}
                skeletonRows={10}
                rowActions={(row) => (
                  <IconButton
                    icon={Copy}
                    label={`Copy ARN for ${row.name || row.arn}`}
                    size="sm"
                    onClick={(event) => {
                      event.stopPropagation();
                      copyText(row.arn).then((ok) =>
                        notify(
                          ok
                            ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                            : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                        ),
                      );
                    }}
                  />
                )}
                emptyState={
                  applied > 0 ? (
                    <EmptyState
                      icon={SearchX}
                      title="No identities match these filters"
                      description="Remove a filter or change the search to widen the list."
                      action={
                        <Button variant="secondary" size="sm" onClick={clearAll}>
                          Clear all filters
                        </Button>
                      }
                    />
                  ) : (
                    <EmptyState
                      title="No identities discovered yet"
                      description="Identities appear here after the scanner completes a discovery run on a connected AWS account."
                    />
                  )
                }
              />
              {total > 0 && (
                <Pagination
                  page={page}
                  pageSize={limit}
                  total={total}
                  pageSizes={PAGE_SIZES}
                  unit="identities"
                  onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                  onPageSizeChange={(size) => update({ limit: size })}
                />
              )}
            </>
          )}
        </Panel>
      </WorkArea>
      </Reveal>
      <RecordPreview kind="identity" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

/* ── Counts ──────────────────────────────────────────────────────────────── */

function CountsStrip({ query, onSelect }) {
  if (query.isLoading && !query.data) return <StatStripSkeleton count={4} />;
  if (query.isError) return <InlineError error={query.error} onRetry={query.refetch} label="Counts unavailable" />;
  const data = query.data;
  const tiles = [
    { key: '', label: 'All identities', value: data.total, tone: 'brand' },
    { key: 'active', label: 'Active', value: data.active, tone: 'low' },
    { key: 'stopped', label: 'Stopped', value: data.stopped, tone: 'medium' },
    { key: 'terminated', label: 'Terminated', value: data.terminated, tone: 'neutral' },
  ];
  return (
    <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto overscroll-x-contain pb-1 [scrollbar-width:none] [&>*]:w-[42%] [&>*]:min-w-[9.5rem] [&>*]:shrink-0 [&>*]:snap-start @min-[40rem]:grid @min-[40rem]:overflow-visible @min-[40rem]:pb-0 @min-[40rem]:[&>*]:w-auto @min-[40rem]:grid-cols-4">
      {tiles.map((tile) => (
        <MetricTile
          key={tile.label}
          as="button"
          type="button"
          onClick={() => onSelect(tile.key)}
          label={tile.label}
          value={tile.value}
          tone={tile.tone}
          aria-label={`${tile.label}: ${formatNumber(tile.value)}. Show these.`}
        />
      ))}
    </div>
  );
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacetGroups({ filters, counts, accounts, regions, update }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner);
  const [environmentDraft, setEnvironmentDraft] = useState(filters.environment);
  useEffect(() => setOwnerDraft(filters.owner), [filters.owner]);
  useEffect(() => setEnvironmentDraft(filters.environment), [filters.environment]);

  const optionsFrom = (map, key, label) => {
    const entries = Object.entries(map ?? {}).filter(([, count]) => count > 0);
    if (filters[key] && !entries.some(([value]) => value === filters[key])) entries.push([filters[key], undefined]);
    return entries
      .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0))
      .map(([value, count]) => ({ value, label: label(value), count, active: filters[key] === value }));
  };

  const single = (key, options, extra = {}) => ({
    key,
    single: true,
    options,
    onToggle: (value) => update({ [key]: value }),
    ...extra,
  });

  const statusMap = counts ? { active: counts.active, stopped: counts.stopped, terminated: counts.terminated } : {};
  const accountMap = Object.fromEntries((accounts?.breakdown ?? []).map((row) => [row.account_id, row.identity_count]));
  const regionMap = Object.fromEntries((regions?.breakdown ?? []).map((row) => [row.region, row.identity_count]));

  const textFilter = (key, draft, setDraft, placeholder) => (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        update({ [key]: draft.trim().slice(0, 256) });
      }}
      className="flex flex-col gap-1.5"
    >
      <Input
        size="sm"
        value={draft}
        maxLength={256}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={() => {
          if (draft.trim() !== filters[key]) update({ [key]: draft.trim().slice(0, 256) });
        }}
        placeholder={placeholder}
        aria-label={FILTER_LABELS[key]}
      />
      <span className="text-[11px] text-ink-3">Exact value. Press Enter to apply.</span>
    </form>
  );

  return [
    single('status', optionsFrom(statusMap, 'status', (value) => statusMeta(value).label)),
    single('identity_type', optionsFrom(counts?.by_type, 'identity_type', identityTypeLabel), {
      label: 'Type',
      emptyText: counts ? 'No identities yet.' : 'Loading…',
    }),
    single('functional_class', optionsFrom(counts?.by_class, 'functional_class', functionalClassLabel), {
      label: 'Functional class',
      emptyText: counts ? 'No identities yet.' : 'Loading…',
    }),
    single('account_id', optionsFrom(accountMap, 'account_id', (value) => value), {
      label: 'AWS account',
      emptyText: accounts ? 'No accounts yet.' : 'Loading…',
      defaultOpen: false,
    }),
    single('region', optionsFrom(regionMap, 'region', regionLabel), {
      label: 'Region',
      emptyText: regions ? 'No regions yet.' : 'Loading…',
      defaultOpen: false,
    }),
    single(
      'is_public',
      [
        { value: 'true', label: 'Publicly accessible', active: filters.is_public === 'true' },
        { value: 'false', label: 'Not public', active: filters.is_public === 'false' },
      ],
      { label: 'Internet exposure', defaultOpen: false },
    ),
    {
      key: 'owner',
      label: 'Owner',
      defaultOpen: Boolean(filters.owner),
      activeCount: filters.owner ? 1 : 0,
      content: textFilter('owner', ownerDraft, setOwnerDraft, 'e.g. platform-team'),
    },
    {
      key: 'environment',
      label: 'Environment',
      defaultOpen: Boolean(filters.environment),
      activeCount: filters.environment ? 1 : 0,
      content: textFilter('environment', environmentDraft, setEnvironmentDraft, 'e.g. production'),
    },
    {
      key: 'last_active_before',
      label: 'Last active before',
      defaultOpen: Boolean(filters.last_active_before),
      activeCount: filters.last_active_before ? 1 : 0,
      content: (
        <div className="flex flex-col gap-1.5">
          <Input
            size="sm"
            type="date"
            value={filters.last_active_before}
            max={new Date().toISOString().slice(0, 10)}
            onChange={(event) => update({ last_active_before: event.target.value })}
            aria-label="Last active before"
          />
          <span className="text-[11px] text-ink-3">Identities with no tracked activity are not included.</span>
        </div>
      ),
    },
  ].map((group) => ({ label: FILTER_LABELS[group.key], ...group }));
}

function describeValue(key, value) {
  switch (key) {
    case 'identity_type':
      return identityTypeLabel(value);
    case 'functional_class':
      return functionalClassLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'is_public':
      return value === 'true' ? 'Yes' : 'No';
    default:
      return value;
  }
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */

function readDensity() {
  try {
    return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
  } catch {
    return 'comfortable';
  }
}

function writeDensity(value) {
  try {
    localStorage.setItem(DENSITY_KEY, value);
  } catch {
    /* a reading preference; safe to lose */
  }
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
