import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Copy, Download, FileJson, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchCredentialCounts, fetchCredentials } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { formatNumber } from '../../lib/format';
import { credentialTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { Page, Reveal } from '../../lib/motion';
import { useExport } from '../../lib/useExport';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { StatStripSkeleton } from '../../ui/Skeleton';
import { MetricTile } from '../../ui/Stat';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { StatusText } from '../../ui/Tag';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { copyText } from '../identities/IdentitiesPage';
import { ExpiryCell, LastUsedCell, PrivilegeCell, RotationCell } from './parts';
import { EXPORT_SORTABLE, FILTER_KEYS, PAGE_SIZES, appliedCount, readListState } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const LABELS = {
  search: 'Search',
  credential_type: 'Type',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  rotation_enabled: 'Rotation',
  expiring_within_days: 'Expires within',
  stale_days: 'Unused for',
  privilege_level_min: 'Privilege',
  privilege_level_max: 'Privilege',
  owner_principal_arn: 'Owner',
};

const PRIVILEGE_BANDS = [
  { value: '8-10', label: 'Critical (8-10)' },
  { value: '6-7', label: 'High (6-7)' },
  { value: '4-5', label: 'Medium (4-5)' },
  { value: '0-3', label: 'Low (0-3)' },
];

/**
 * Credential inventory: GET /api/v1/inventory/credentials, filtered, sorted
 * and paged on the server. All state lives in the URL.
 */
export default function CredentialsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const { railOpen, toggleRail } = useFacetRail();
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => {
    try {
      return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
    } catch {
      return 'comfortable';
    }
  });

  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const listKey = JSON.stringify([filters, page, limit, sort]);
  const list = useQuery(
    (signal) => fetchCredentials({ ...filters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
  );
  const counts = useQuery(
    (signal) => fetchCredentialCounts({ account_id: filters.account_id, region: filters.region }, signal),
    [filters.account_id, filters.region],
  );
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('credentials');
  const onExport = (format) =>
    exporter.run(format, {
      ...filters,
      ...(EXPORT_SORTABLE.has(sort.key) ? { sort_by: sort.key, sort_order: sort.direction } : {}),
    });

  const chips = FILTER_KEYS.filter((key) => filters[key] && key !== 'privilege_level_max')
    .map((key) => ({ key, label: LABELS[key], value: describe(key, filters) }))
    .concat(
      filters.privilege_level_max && !filters.privilege_level_min
        ? [{ key: 'privilege_level_max', label: 'Privilege', value: `0-${filters.privilege_level_max}` }]
        : [],
    );

  const facetGroups = useFacets({ filters, counts: counts.data, options, update });

  const columns = [
    {
      key: 'name',
      header: 'Credential',
      primary: true,
      sortable: true,
      cell: (row) => <CellStack title={row.name || row.arn} mono={row.credential_type === 'access_key'} />,
    },
    {
      key: 'credential_type',
      header: 'Type',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => <span className="block truncate" title={credentialTypeLabel(row.credential_type)}>{credentialTypeLabel(row.credential_type)}</span>,
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '122px',
      priority: 'xl',
      cell: (row) => <span className="block font-mono text-[12px]">{row.account_id}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '118px',
      mobile: true,
      cell: (row) => {
        const meta = statusMeta(row.status);
        return <StatusText tone={meta.tone}>{meta.label}</StatusText>;
      },
    },
    {
      key: 'privilege_level',
      header: 'Privilege',
      sortable: true,
      width: '112px',
      priority: 'wide',
      cell: (row) => <PrivilegeCell level={row.privilege_level} credentialType={row.credential_type} />,
    },
    {
      key: 'last_used_at',
      header: 'Last used',
      sortable: true,
      width: '100px',
      priority: 'wide',
      cell: (row) => <LastUsedCell value={row.last_used_at} />,
    },
    {
      key: 'expires_at',
      header: 'Expires',
      sortable: true,
      width: '142px',
      mobile: true,
      cell: (row) => <ExpiryCell value={row.expires_at} />,
    },
    {
      key: 'rotation',
      header: 'Rotation',
      width: '92px',
      priority: 'xl',
      cell: (row) => <RotationCell value={row.rotation_enabled} />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Credentials"
          lede="Roles, access keys, secrets, certificates and parameters the scanner found. Open one for its hygiene, trust policy and permissions."
          actions={
            <Button
              variant="secondary"
              icon={Download}
              loading={exporter.exporting === 'csv'}
              disabled={Boolean(exporter.exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          }
        />
      </Reveal>

      <Reveal>
        <CountsStrip query={counts} update={update} filters={filters} />
      </Reveal>

      <Reveal>
        <WorkArea
          railOpen={railOpen}
          rail={<FacetRail groups={facetGroups} appliedCount={applied} onClearAll={clearAll} onClose={toggleRail} />}
        >
          <Panel flush className="overflow-hidden">
            <RecordBar
              trailing={
                <TableToolbar>
                  {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                  <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                  <TableSettings
                    density={density}
                    onDensityChange={(value) => {
                      setDensity(value);
                      try {
                        localStorage.setItem(DENSITY_KEY, value);
                      } catch {
                        /* a reading preference; safe to lose */
                      }
                    }}
                  />
                  <OverflowMenu
                    items={[
                      {
                        key: 'json',
                        label: 'Export as JSON',
                        hint: 'Every credential matching these filters, with full records',
                        icon: FileJson,
                        onSelect: () => onExport('json'),
                        disabled: Boolean(exporter.exporting) || !can('data.export'),
                        disabledHint: exporter.exporting ? 'An export is already running' : lock('data.export'),
                      },
                    ]}
                  />
                </TableToolbar>
              }
            >
              <SearchInput
                size="sm"
                value={searchDraft}
                onChange={setSearchDraft}
                maxLength={256}
                placeholder="Search name or ARN…"
                className="w-full min-w-0 sm:max-w-sm"
              />
              <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'credential' : 'credentials'} loading={list.isLoading && !list.data} />
            </RecordBar>

            <AppliedFilters
              filters={chips}
              onRemove={(key) => {
                if (key === 'search') setSearchDraft('');
                if (key === 'privilege_level_min' || key === 'privilege_level_max') update({ privilege_level_min: '', privilege_level_max: '' });
                else update({ [key]: '' });
              }}
              onClearAll={clearAll}
            />

            {list.isError && !list.data ? (
              <ErrorState error={list.error} onRetry={list.refetch} />
            ) : (
              <>
                {list.isError && (
                  <div className="p-3">
                    <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                  </div>
                )}
                <DataGrid
                  caption="Credentials"
                  columns={columns}
                  rows={rows}
                  rowKey={(row) => row.id}
                  loading={list.isLoading && !list.data}
                  refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                  onRowClick={(row, event) => {
                    if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                    else setPeek(rows.indexOf(row));
                  }}
                  selectedKey={peek !== null ? rows[peek]?.id : undefined}
                  rowLabel={(row) => `Preview ${row.name || row.arn}`}
                  sort={sort}
                  onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction })}
                  density={density}
                  skeletonRows={10}
                  rowActions={(row) => (
                    <IconButton
                      icon={Copy}
                      label={`Copy ARN for ${row.name || row.arn}`}
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation();
                        copyText(row.arn).then((ok) =>
                          notify(
                            ok
                              ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                              : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                          ),
                        );
                      }}
                    />
                  )}
                  emptyState={
                    applied > 0 ? (
                      <EmptyState
                        icon={SearchX}
                        title="No credentials match these filters"
                        description="Remove a filter or change the search to widen the list."
                        action={
                          <Button variant="secondary" size="sm" onClick={clearAll}>
                            Clear all filters
                          </Button>
                        }
                      />
                    ) : (
                      <EmptyState title="No credentials discovered yet" description="Credentials appear here after the scanner completes a discovery run." />
                    )
                  }
                />
                {total > 0 && (
                  <Pagination
                    page={page}
                    pageSize={limit}
                    total={total}
                    pageSizes={PAGE_SIZES}
                    unit="credentials"
                    onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                    onPageSizeChange={(size) => update({ limit: size })}
                  />
                )}
              </>
            )}
          </Panel>
        </WorkArea>
      </Reveal>
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

function describe(key, filters) {
  const value = filters[key];
  switch (key) {
    case 'credential_type':
      return credentialTypeLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'rotation_enabled':
      return value === 'true' ? 'On' : 'Off';
    case 'expiring_within_days':
      return `${value} days`;
    case 'stale_days':
      return `${value} days`;
    case 'privilege_level_min':
      return `${value}-${filters.privilege_level_max || 10}`;
    default:
      return value;
  }
}

/* ── Counts ──────────────────────────────────────────────────────────────── */

function CountsStrip({ query, update, filters }) {
  if (query.isLoading && !query.data) return <StatStripSkeleton count={5} />;
  if (query.isError && !query.data) return <InlineError error={query.error} onRetry={query.refetch} label="Counts unavailable" />;
  const data = query.data;
  const tiles = [
    { label: 'All credentials', value: data.total, tone: 'brand', apply: () => update(Object.fromEntries(FILTER_KEYS.filter((k) => !['account_id', 'region'].includes(k)).map((k) => [k, '']))) },
    { label: 'Active', value: data.active, tone: 'low', apply: () => update({ status: 'active' }), active: filters.status === 'active' },
    { label: 'Expiring in 30 days', value: data.expiring_within_30d, tone: 'high', apply: () => update({ expiring_within_days: 30 }), active: filters.expiring_within_days === '30' },
    { label: 'Unused 90 days', value: data.stale_90d, tone: 'medium', apply: () => update({ stale_days: 90 }), active: filters.stale_days === '90' },
    {
      label: 'High privilege',
      value: data.high_privilege,
      tone: 'critical',
      caption: 'Privilege level 7 or above',
      apply: () => update({ privilege_level_min: 7, privilege_level_max: '' }),
      active: filters.privilege_level_min === '7' && !filters.privilege_level_max,
    },
  ];
  return (
    <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto overscroll-x-contain pb-1 [scrollbar-width:none] [&>*]:w-[42%] [&>*]:min-w-[9.5rem] [&>*]:shrink-0 [&>*]:snap-start @min-[40rem]:grid @min-[40rem]:overflow-visible @min-[40rem]:pb-0 @min-[40rem]:[&>*]:w-auto @min-[40rem]:grid-cols-3 @min-[70rem]:grid-cols-5">
      {tiles.map((tile) => (
        <MetricTile
          key={tile.label}
          as="button"
          type="button"
          onClick={tile.apply}
          label={tile.label}
          value={tile.value}
          tone={tile.tone}
          caption={tile.caption}
          aria-pressed={tile.active || undefined}
          className={tile.active ? 'ring-2 ring-brand/40' : undefined}
        />
      ))}
    </div>
  );
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacets({ filters, counts, options, update }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner_principal_arn);
  useEffect(() => setOwnerDraft(filters.owner_principal_arn), [filters.owner_principal_arn]);

  const single = (key, label, opts, extra = {}) => ({
    key,
    label,
    single: true,
    options: opts.map((option) => ({ ...option, active: filters[key] === option.value })),
    onToggle: (value) => update({ [key]: value }),
    ...extra,
  });

  const byType = counts?.by_type ?? {};
  const typeValues = [...new Set([...options.credentialTypes, ...Object.keys(byType)])].sort((a, b) => (byType[b] ?? 0) - (byType[a] ?? 0));
  const statusCounts = counts ? { active: counts.active, inactive: counts.inactive, expired: counts.expired } : {};
  const credentialStatuses = ['active', 'inactive', 'expired', 'pending_deletion'].filter(
    (status) => options.statuses.includes(status) || statusCounts[status] > 0 || filters.status === status,
  );
  const band = filters.privilege_level_min || filters.privilege_level_max ? `${filters.privilege_level_min || 0}-${filters.privilege_level_max || 10}` : '';

  return [
    single('status', 'Status', credentialStatuses.map((value) => ({ value, label: statusMeta(value).label, count: statusCounts[value] }))),
    single('credential_type', 'Type', typeValues.map((value) => ({ value, label: credentialTypeLabel(value), count: byType[value] })), {
      emptyText: counts ? 'No credentials yet.' : 'Loading…',
    }),
    {
      key: 'privilege',
      label: 'Privilege (IAM roles)',
      single: true,
      options: PRIVILEGE_BANDS.map((option) => ({ ...option, active: band === option.value })),
      onToggle: (value) => {
        if (!value) update({ privilege_level_min: '', privilege_level_max: '' });
        else {
          const [min, max] = value.split('-');
          update({ privilege_level_min: min, privilege_level_max: max === '10' ? '' : max });
        }
      },
    },
    single('expiring_within_days', 'Expires within', [7, 30, 90].map((d) => ({ value: String(d), label: `${d} days` })), { defaultOpen: false }),
    single('stale_days', 'Unused for', [30, 90, 180, 365].map((d) => ({ value: String(d), label: `${d}+ days` })), { defaultOpen: false }),
    single('rotation_enabled', 'Rotation', [
      { value: 'true', label: 'Enabled' },
      { value: 'false', label: 'Disabled' },
    ], { defaultOpen: false }),
    single('account_id', 'AWS account', options.accounts.map((value) => ({ value, label: value })), { defaultOpen: false }),
    single('region', 'Region', options.regions.map((value) => ({ value, label: regionLabel(value) })), { defaultOpen: false }),
    {
      key: 'owner_principal_arn',
      label: 'Owner principal',
      defaultOpen: Boolean(filters.owner_principal_arn),
      activeCount: filters.owner_principal_arn ? 1 : 0,
      content: (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            const value = ownerDraft.trim();
            update({ owner_principal_arn: value.startsWith('arn:') ? value : '' });
          }}
          className="flex flex-col gap-1.5"
        >
          <Input
            size="sm"
            value={ownerDraft}
            onChange={(event) => setOwnerDraft(event.target.value)}
            placeholder="arn:aws:iam::123456789012:role/…"
            aria-label="Owner principal ARN"
            spellCheck={false}
          />
          <span className="text-[11px] text-ink-3">Exact ARN. Press Enter to apply.</span>
        </form>
      ),
    },
  ];
}
