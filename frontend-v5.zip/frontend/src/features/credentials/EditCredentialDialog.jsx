import { useEffect, useId, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { KeyRound, Plus, Trash2 } from 'lucide-react';
import { updateCredential } from '../../lib/api/endpoints';
import { useMutation } from '../../lib/hooks';
import { Button, IconButton } from '../../ui/Button';
import { Field, Input } from '../../ui/Field';
import { Modal } from '../../ui/Overlay';
import { useToast } from '../../ui/Toast';
import { tagPairs } from './parts';

/* AWS tag limits; the API itself does not check them. */
const KEY_MAX = 128;
const VALUE_MAX = 256;
const ARN_MAX = 2048;
const TAG_MAX = 50;

let rowSeq = 0;
const row = (key = '', value = '') => ({ rid: ++rowSeq, key, value });

function initialOf(credential) {
  return {
    owner: credential.owner_principal_arn ?? '',
    rows: tagPairs(credential.tags).map(([key, value]) => row(key, value)),
  };
}

function toMap(rows) {
  return Object.fromEntries(rows.filter((entry) => entry.key.trim()).map((entry) => [entry.key.trim(), entry.value.trim()]));
}

function sameMap(a, b) {
  const ak = Object.keys(a);
  return ak.length === Object.keys(b).length && ak.every((key) => key in b && a[key] === b[key]);
}

function ownerError(value) {
  const text = value.trim();
  if (!text) return null;
  if (text.length > ARN_MAX) return `Keep it to ${ARN_MAX} characters or fewer.`;
  if (!/^arn:aws[a-z-]*:[a-z0-9-]+:/.test(text)) return 'Enter an ARN, for example arn:aws:iam::123456789012:role/name.';
  return null;
}

function rowErrors(rows) {
  const seen = new Map();
  const errors = {};
  for (const entry of rows) {
    const key = entry.key.trim();
    if (!key) {
      if (entry.value.trim()) errors[entry.rid] = 'Add a key, or remove this row.';
      continue;
    }
    if (key.length > KEY_MAX) errors[entry.rid] = `Keys are ${KEY_MAX} characters at most.`;
    else if (entry.value.trim().length > VALUE_MAX) errors[entry.rid] = `Values are ${VALUE_MAX} characters at most.`;
    else if (key.toLowerCase().startsWith('aws:')) errors[entry.rid] = 'Keys starting with aws: are reserved by AWS.';
    else if (seen.has(key)) errors[entry.rid] = `"${key}" is already used above.`;
    seen.set(key, entry.rid);
  }
  return errors;
}

/**
 * PATCH /api/v1/inventory/credentials/{id}: owner principal and tags. The
 * API replaces the whole tag map, so the full set is sent whenever any tag
 * changes; an unchanged field is left out.
 */
export function EditCredentialDialog({ open, credential, onClose, onSaved }) {
  const formId = useId();
  const { notify } = useToast();
  const save = useMutation((patch) => updateCredential(credential.id, patch));

  /* The form restarts from the saved record each time the dialog opens. It is
     reset during render, not in an effect, so the previous session's rows are
     never painted (and never play their exit animation) on reopen. */
  const [form, setForm] = useState(() => {
    const fresh = initialOf(credential);
    return { open, initial: fresh, values: fresh };
  });
  if (form.open !== open) {
    const fresh = initialOf(credential);
    setForm({ open, initial: fresh, values: fresh });
  }
  const { initial, values } = form;
  const setValues = (update) => setForm((current) => ({ ...current, values: update(current.values) }));

  useEffect(() => {
    if (open) save.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const owner = values.owner.trim();
  const tags = toMap(values.rows);
  const patch = {};
  if (owner !== initial.owner.trim()) patch.owner_principal_arn = owner;
  if (!sameMap(tags, toMap(initial.rows))) patch.tags = tags;

  const errors = rowErrors(values.rows);
  const arnError = ownerError(values.owner);
  const tooMany = Object.keys(tags).length > TAG_MAX;
  const invalid = Boolean(arnError) || Object.keys(errors).length > 0 || tooMany;
  const nothing = Object.keys(patch).length === 0;

  const setRow = (rid, field, value) =>
    setValues((current) => ({ ...current, rows: current.rows.map((entry) => (entry.rid === rid ? { ...entry, [field]: value } : entry)) }));
  const removeRow = (rid) => setValues((current) => ({ ...current, rows: current.rows.filter((entry) => entry.rid !== rid) }));
  const addRow = () => setValues((current) => ({ ...current, rows: [...current.rows, row()] }));

  const submit = async (event) => {
    event.preventDefault();
    if (invalid || nothing) return;
    const result = await save.mutate(patch);
    if (result.ok) {
      const fields = result.result.updated_fields ?? Object.keys(patch);
      notify({
        variant: 'success',
        title: 'Credential updated',
        description: `Saved ${fields.map((field) => (field === 'owner_principal_arn' ? 'owner principal' : field)).join(' and ')}.`,
      });
      onSaved();
    }
  };

  return (
    <Modal
      open={open}
      onClose={save.pending ? () => {} : onClose}
      title="Edit ownership"
      description={`Saved to the inventory record for ${credential.name || credential.arn}. AWS itself is not changed.`}
      icon={KeyRound}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={save.pending}>
            Cancel
          </Button>
          <Button variant="primary" type="submit" form={formId} loading={save.pending} disabled={nothing || invalid}>
            Save changes
          </Button>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="flex flex-col gap-5" noValidate>
        <Field
          label="Owner principal"
          htmlFor={`${formId}-owner`}
          hint="The IAM user or role that owns this credential. Leave empty to clear."
          error={arnError}
        >
          <Input
            id={`${formId}-owner`}
            value={values.owner}
            maxLength={ARN_MAX}
            invalid={Boolean(arnError)}
            autoComplete="off"
            spellCheck={false}
            className="font-mono text-[12.5px]"
            placeholder="arn:aws:iam::123456789012:role/owner"
            onChange={(event) => setValues((current) => ({ ...current, owner: event.target.value }))}
          />
        </Field>

        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1.5 flex w-full items-baseline justify-between text-[12.5px] font-medium text-ink-2">
            Tags
            <span className="text-[11.5px] font-normal text-ink-3">
              {Object.keys(tags).length} of {TAG_MAX}
            </span>
          </legend>
          {values.rows.length === 0 && (
            <p className="rounded-[var(--radius-control)] border border-dashed border-line px-3 py-3 text-center text-[12.5px] text-ink-3">
              No tags. Saving with none clears every tag on the record.
            </p>
          )}
          <ul className="flex flex-col gap-2">
            <AnimatePresence initial={false}>
              {values.rows.map((entry, index) => (
                <motion.li
                  key={entry.rid}
                  layout
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0, marginTop: 0 }}
                  transition={{ duration: 0.18 }}
                >
                  <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)_auto] items-start gap-2">
                    <Input
                      size="sm"
                      aria-label={`Tag ${index + 1} key`}
                      value={entry.key}
                      maxLength={KEY_MAX + 1}
                      invalid={Boolean(errors[entry.rid])}
                      placeholder="key"
                      autoComplete="off"
                      spellCheck={false}
                      className="font-mono text-[12px]"
                      onChange={(event) => setRow(entry.rid, 'key', event.target.value)}
                    />
                    <Input
                      size="sm"
                      aria-label={`Tag ${index + 1} value`}
                      value={entry.value}
                      maxLength={VALUE_MAX + 1}
                      placeholder="value"
                      autoComplete="off"
                      spellCheck={false}
                      className="font-mono text-[12px]"
                      onChange={(event) => setRow(entry.rid, 'value', event.target.value)}
                    />
                    <IconButton icon={Trash2} size="sm" label={`Remove tag ${entry.key || index + 1}`} onClick={() => removeRow(entry.rid)} />
                  </div>
                  {errors[entry.rid] && (
                    <p role="alert" className="mt-1 text-[11.5px] font-medium text-critical">
                      {errors[entry.rid]}
                    </p>
                  )}
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
          {tooMany && (
            <p role="alert" className="text-[12px] font-medium text-critical">
              AWS allows {TAG_MAX} tags per resource.
            </p>
          )}
          <Button variant="ghost" size="sm" icon={Plus} onClick={addRow} className="self-start" disabled={values.rows.length >= TAG_MAX + 5}>
            Add tag
          </Button>
        </fieldset>

        {save.error && (
          <p role="alert" className="rounded-[var(--radius-control)] border border-critical/25 bg-critical-soft px-3 py-2 text-[12.5px] text-ink-2">
            <span className="font-medium text-critical">Not saved.</span> {save.error.message}
          </p>
        )}
      </form>
    </Modal>
  );
}
