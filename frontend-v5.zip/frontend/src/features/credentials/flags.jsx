import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import { formatDateTime } from '../../lib/format';
import { flagLabel, healthMeta } from '../../lib/labels';
import { RevealItem, RevealList } from '../../lib/motion';
import { Tag } from '../../ui/Tag';
import { TONE_VAR, cn } from '../../ui/cn';

/* The API returns the same fixed text for every wildcard_action flag, so it
   says nothing about this credential and is not shown. */
const UNRELIABLE_DETAIL = new Set(['wildcard_action']);
const ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

/** What each flag asks the reader to do. Shown under the flag. */
const NEXT_STEP = {
  expired: 'Renew it, or remove it if nothing depends on it.',
  high_privilege: 'Check what the role needs and narrow its policies.',
  wildcard_action: 'Replace the wildcard with the actions actually used.',
  no_permission_boundary: 'Attach a boundary so the role cannot be granted more later.',
  rotation_disabled: 'Turn on automatic rotation.',
  not_rotated_90d: 'Rotate it.',
  unused_90d: 'Confirm with the owner, then disable it.',
  no_attached_policies: 'Remove the role if nothing assumes it.',
};

export function sortFlags(flags = []) {
  return [...flags].sort((a, b) => (ORDER[a.severity] ?? 9) - (ORDER[b.severity] ?? 9));
}

/* Details carry RFC 3339 timestamps; show them the way the rest of the page does. */
function flagDetail(flag) {
  return String(flag.detail).replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z/g, (stamp) => formatDateTime(stamp));
}

/** Hygiene flags, most severe first, each with what to do about it. */
export function FlagList({ flags, compact = false, emptyText = 'No hygiene flags. Nothing to act on for this credential.' }) {
  const sorted = sortFlags(flags);
  if (sorted.length === 0) {
    return (
      <div className="flex items-center gap-2.5 rounded-[var(--radius-control)] border border-line bg-surface-2/60 px-3.5 py-3 text-[13px] text-ink-2">
        <CheckCircle2 aria-hidden="true" className="size-4 shrink-0 text-low" />
        {emptyText}
      </div>
    );
  }
  return (
    <RevealList as="ul" className="flex flex-col gap-2">
      {sorted.map((flag, index) => {
        const meta = healthMeta(flag.severity);
        const detail = flag.detail && !UNRELIABLE_DETAIL.has(flag.flag) ? flagDetail(flag) : null;
        return (
          <RevealItem
            as="li"
            index={index}
            key={`${flag.flag}-${index}`}
            className={cn(
              'flex items-start gap-3 rounded-[var(--radius-control)] border border-line bg-surface',
              compact ? 'px-3 py-2.5' : 'px-3.5 py-3',
            )}
          >
            <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0" style={{ color: TONE_VAR[meta.tone] }} />
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-medium text-ink">{flagLabel(flag.flag)}</p>
              {detail && <p className="mt-0.5 text-[12px] break-words text-ink-3">{detail}</p>}
              {NEXT_STEP[flag.flag] && <p className="mt-0.5 text-[12px] text-ink-2">{NEXT_STEP[flag.flag]}</p>}
            </div>
            <Tag size="sm" tone={meta.tone}>
              {meta.label}
            </Tag>
          </RevealItem>
        );
      })}
    </RevealList>
  );
}
