import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarClock, Hourglass, SearchX, TimerReset } from 'lucide-react';
import { fetchExpiringCredentials, fetchStaleCredentials } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDate, formatDateTime, formatNumber, formatRelativeShort } from '../../lib/format';
import { credentialTypeLabel } from '../../lib/labels';
import { AnimatedNumber, Page, Reveal } from '../../lib/motion';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { RecordPreview } from '../preview/RecordPreview';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { Select } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState } from '../../ui/States';
import { SegmentedControl, Tabs } from '../../ui/Tabs';
import { RefreshButton, TableToolbar } from '../../ui/TableTools';
import { RecordBar, ResultCount } from '../../ui/WorkArea';
import { cn } from '../../ui/cn';

const VIEWS = {
  expiring: {
    presets: [7, 30, 60, 90],
    fallback: 30,
    max: 50000,
    fetch: fetchExpiringCredentials,
    totalKey: 'total_expiring',
  },
  stale: {
    presets: [30, 90, 180, 365],
    fallback: 90,
    max: 3650,
    fetch: fetchStaleCredentials,
    totalKey: 'total_stale',
  },
};

const TABS = [
  { value: 'expiring', label: 'Expiring', icon: CalendarClock },
  { value: 'stale', label: 'Unused', icon: Hourglass },
];

const PAGE_SIZES = [25, 50, 100, 200];
const ACCOUNT = /^[0-9]{12}$/;
const TOKEN = /^[a-zA-Z0-9_-]{1,100}$/;

/**
 * Credentials that need attention on a clock:
 *   expiring  GET /api/v1/inventory/credentials/expiring  (expires within N days)
 *   unused    GET /api/v1/inventory/credentials/stale     (active, not used for N days)
 * Both page on the server and filter by type and account only.
 */
export default function HygienePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);

  const view = searchParams.get('view') === 'stale' ? 'stale' : 'expiring';
  const config = VIEWS[view];
  const rawDays = Number(searchParams.get('days'));
  const days = Number.isInteger(rawDays) && rawDays >= 1 && rawDays <= config.max ? rawDays : config.fallback;
  const page = Math.max(1, Math.min(1_000_000, Number.parseInt(searchParams.get('page') ?? '1', 10) || 1));
  const limit = PAGE_SIZES.includes(Number(searchParams.get('limit'))) ? Number(searchParams.get('limit')) : 50;
  const accountId = ACCOUNT.test(searchParams.get('account_id') ?? '') ? searchParams.get('account_id') : '';
  const credentialType = TOKEN.test(searchParams.get('credential_type') ?? '') ? searchParams.get('credential_type') : '';

  const update = (changes, keepPage = false) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  const query = useQuery(
    (signal) => config.fetch({ days, page, limit, account_id: accountId, credential_type: credentialType }, signal),
    [view, days, page, limit, accountId, credentialType],
  );

  const accountOptions = useMemo(
    () => [{ value: '', label: 'All accounts' }, ...options.accounts.map((value) => ({ value, label: value }))],
    [options.accounts],
  );
  const typeOptions = useMemo(
    () => [{ value: '', label: 'All types' }, ...options.credentialTypes.map((value) => ({ value, label: credentialTypeLabel(value) }))],
    [options.credentialTypes],
  );
  const presetOptions = config.presets.includes(days) ? config.presets : [...config.presets, days].sort((a, b) => a - b);

  /* A result for the other view can linger for a frame while the new one loads. */
  const current = query.data && config.totalKey in query.data && Number(query.data.threshold_days) === days ? query.data : null;
  const rows = current?.data ?? [];
  const [peek, setPeek] = useState(null);
  const [peekData, setPeekData] = useState(current);
  if (peekData !== current) {
    setPeekData(current);
    if (peek !== null) setPeek(null);
  }
  const total = Number(current?.[config.totalKey] ?? 0);
  const filtered = Boolean(accountId || credentialType);
  const rejected = query.isError && query.error?.status === 400;

  const columns =
    view === 'expiring'
      ? [
          {
            key: 'name',
            header: 'Credential',
            primary: true,
            cell: (row) => <CellStack title={row.name || row.id} meta={credentialTypeLabel(row.credential_type)} mono />,
          },
          {
            key: 'days_until_expiry',
            header: 'Expires in',
            width: '18%',
            cell: (row) => <DaysLeft days={row.days_until_expiry} />,
          },
          {
            key: 'expires_at',
            header: 'Expiry date',
            width: '22%',
            cell: (row) => <span title={formatDateTime(row.expires_at)}>{formatDate(row.expires_at)}</span>,
          },
        ]
      : [
          {
            key: 'name',
            header: 'Credential',
            primary: true,
            cell: (row) => <CellStack title={row.name || row.id} meta={credentialTypeLabel(row.credential_type)} mono />,
          },
          {
            key: 'days_unused',
            header: 'Unused for',
            width: '14%',
            cell: (row) => (
              <span data-numeric="" className="font-semibold text-ink">
                {formatNumber(row.days_unused)} days
              </span>
            ),
          },
          {
            key: 'last_used_at',
            header: 'Last used',
            width: '14%',
            cell: (row) => <span title={formatDateTime(row.last_used_at)}>{formatRelativeShort(row.last_used_at)}</span>,
          },
          {
            key: 'owner_principal_arn',
            header: 'Owner principal',
            width: '34%',
            priority: 'wide',
            cell: (row) =>
              row.owner_principal_arn ? (
                <span className="block truncate font-mono text-[12px]" title={row.owner_principal_arn}>
                  {row.owner_principal_arn}
                </span>
              ) : (
                <span className="text-ink-3">None recorded</span>
              ),
          },
        ];

  const headline =
    view === 'expiring'
      ? `${total === 1 ? 'credential expires' : 'credentials expire'} within ${days} days`
      : `active ${total === 1 ? 'credential has' : 'credentials have'} not been used for ${days} days or more`;

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Credential hygiene"
          lede="Credentials on a clock: those about to expire, and active ones nobody has used. Renew what is needed; disable what is not."
          tabs={
            <Tabs
              size="sm"
              tabs={TABS}
              value={view}
              onChange={(value) => update({ view: value === 'expiring' ? '' : value, days: '' })}
            />
          }
        />
      </Reveal>

      <Reveal>
        <Panel className="flex flex-wrap items-center gap-x-6 gap-y-3">
          <span
            className={cn(
              'grid size-11 shrink-0 place-items-center rounded-full border',
              view === 'expiring' ? 'border-high/25 bg-high-soft text-high' : 'border-medium/25 bg-medium-soft text-medium',
            )}
          >
            {view === 'expiring' ? <TimerReset aria-hidden="true" className="size-5" /> : <Hourglass aria-hidden="true" className="size-5" />}
          </span>
          <p className="min-w-0 flex-1 text-[13.5px] text-ink-2">
            <AnimatedNumber value={current ? total : null} className="font-display text-[28px] leading-none font-bold text-ink" />{' '}
            {headline}
            {filtered && <span className="text-ink-3"> (filtered)</span>}.
          </p>
          <p className="max-w-md text-[12px] text-ink-3">
            {view === 'expiring'
              ? 'Counts credentials with an expiry date in the window that are not already marked expired.'
              : 'Counts credentials with status active and a recorded last use. Never-used credentials are not included.'}
          </p>
        </Panel>
      </Reveal>

      <Reveal>
        <Panel flush className="overflow-hidden">
          <RecordBar
            trailing={
              <TableToolbar>
                <RefreshButton onRefresh={query.refetch} refreshing={query.isRefreshing} />
              </TableToolbar>
            }
          >
            <SegmentedControl
              label={view === 'expiring' ? 'Expires within' : 'Unused for at least'}
              value={String(days)}
              onChange={(value) => update({ days: Number(value) === config.fallback ? '' : value }, false)}
              options={presetOptions.map((value) => ({ value: String(value), label: `${value}d`, title: `${value} days` }))}
            />
            <Select
              size="sm"
              value={credentialType}
              onChange={(event) => update({ credential_type: event.target.value })}
              options={typeOptions}
              aria-label="Credential type"
              className="w-48"
            />
            <Select
              size="sm"
              value={accountId}
              onChange={(event) => update({ account_id: event.target.value })}
              options={accountOptions}
              aria-label="AWS account"
              className="w-44"
            />
            <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'credential' : 'credentials'} loading={!current} />
          </RecordBar>

          {query.isError && !current ? (
            rejected ? (
              <ErrorState error={query.error} title="These filters were not accepted" />
            ) : (
              <ErrorState error={query.error} onRetry={query.refetch} />
            )
          ) : (
            <>
              <DataGrid
                caption={view === 'expiring' ? `Credentials expiring within ${days} days` : `Credentials unused for ${days} days or more`}
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                loading={!current}
                refreshing={query.isRefreshing || (query.isLoading && Boolean(current))}
                onRowClick={(row, event) => {
                  if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                  else setPeek(rows.indexOf(row));
                }}
                selectedKey={peek !== null ? rows[peek]?.id : undefined}
                rowLabel={(row) => `Preview ${row.name || row.id}`}
                skeletonRows={8}
                emptyState={
                  filtered ? (
                    <EmptyState icon={SearchX} title="Nothing matches these filters" description="Choose another type or account, or a longer window." />
                  ) : view === 'expiring' ? (
                    <EmptyState icon={CalendarClock} title={`Nothing expires within ${days} days`} description="No credential with an expiry date falls inside this window." />
                  ) : (
                    <EmptyState icon={Hourglass} title={`Nothing unused for ${days} days`} description="Every active credential with recorded use has been used within this period." />
                  )
                }
              />
              {total > 0 && (
                <Pagination
                  page={page}
                  pageSize={limit}
                  total={total}
                  pageSizes={PAGE_SIZES}
                  unit="credentials"
                  onPageChange={(next) => update({ page: next > 1 ? next : '' }, true)}
                  onPageSizeChange={(size) => update({ limit: size })}
                />
              )}
            </>
          )}
        </Panel>
      </Reveal>
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

function DaysLeft({ days }) {
  const n = Number(days);
  if (!Number.isFinite(n)) return <span className="text-ink-3">-</span>;
  const tone = n < 7 ? 'text-critical' : n < 30 ? 'text-high' : 'text-ink';
  const width = Math.max(4, Math.min(100, 100 - (n / 90) * 100));
  return (
    <span className="flex items-center gap-2">
      <span data-numeric="" className={cn('w-16 shrink-0 font-semibold', tone)}>
        {n === 0 ? 'Today' : `${formatNumber(n)} day${n === 1 ? '' : 's'}`}
      </span>
      <span aria-hidden="true" className="hidden h-1.5 w-16 overflow-hidden rounded-full bg-track lg:block">
        <span className={cn('block h-full rounded-full', n < 7 ? 'bg-critical' : n < 30 ? 'bg-high' : 'bg-ink-3')} style={{ width: `${width}%` }} />
      </span>
    </span>
  );
}
