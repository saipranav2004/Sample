import { useId } from 'react';
import { LayoutGroup, motion } from 'motion/react';
import { SPRING } from '../lib/motion';
import { cn } from './cn';

/**
 * Underlined tab set. The underline is one shared-layout element that slides
 * between tabs (Motion `layoutId`), which is what tells the reader which
 * sibling view they moved to. Keyboard support follows the WAI-ARIA tabs
 * pattern: arrow keys, Home and End move between tabs.
 */
export function Tabs({ tabs, value, onChange, className, size = 'md' }) {
  const baseId = useId();

  const onKeyDown = (event) => {
    const currentIndex = tabs.findIndex((tab) => tab.value === value);
    if (currentIndex === -1) return;
    let nextIndex = null;
    if (event.key === 'ArrowRight') nextIndex = (currentIndex + 1) % tabs.length;
    if (event.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
    if (event.key === 'Home') nextIndex = 0;
    if (event.key === 'End') nextIndex = tabs.length - 1;
    if (nextIndex === null) return;
    event.preventDefault();
    onChange(tabs[nextIndex].value);
    document.getElementById(`${baseId}-tab-${tabs[nextIndex].value}`)?.focus();
  };

  return (
    <LayoutGroup id={baseId}>
      <div
        role="tablist"
        onKeyDown={onKeyDown}
        className={cn('relative flex min-w-0 items-stretch gap-1 overflow-x-auto', className)}
      >
        {tabs.map((tab) => {
          const active = tab.value === value;
          return (
            <button
              key={tab.value}
              id={`${baseId}-tab-${tab.value}`}
              role="tab"
              type="button"
              aria-selected={active}
              tabIndex={active ? 0 : -1}
              onClick={() => onChange(tab.value)}
              className={cn(
                'relative inline-flex shrink-0 items-center gap-2 px-3 font-medium transition-colors duration-150',
                size === 'sm' ? 'h-9 text-[12.5px]' : 'h-11 text-[13.5px]',
                active ? 'text-ink' : 'text-ink-3 hover:text-ink-2',
              )}
            >
              {tab.icon && <tab.icon aria-hidden="true" className="size-4" />}
              {tab.label}
              {tab.count !== undefined && tab.count !== null && (
                <span
                  data-numeric=""
                  className={cn(
                    'rounded-full px-1.5 py-0.5 text-[11px] font-semibold',
                    active ? 'bg-info-soft text-brand' : 'bg-surface-3 text-ink-3',
                  )}
                >
                  {tab.count}
                </span>
              )}
              {active && (
                <motion.span
                  layoutId="tab-underline"
                  aria-hidden="true"
                  transition={SPRING}
                  className="absolute inset-x-1 bottom-0 h-[2px] rounded-full bg-brand"
                />
              )}
            </button>
          );
        })}
      </div>
    </LayoutGroup>
  );
}

/** Segmented control for mutually exclusive view modes; the thumb slides. */
export function SegmentedControl({ options, value, onChange, label, className }) {
  const baseId = useId();
  return (
    <LayoutGroup id={baseId}>
      <div
        role="group"
        aria-label={label}
        className={cn(
          'inline-flex items-center gap-0.5 rounded-[var(--radius-control)] border border-line bg-surface-2 p-0.5',
          className,
        )}
      >
        {options.map((option) => {
          const active = option.value === value;
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={active}
              onClick={() => onChange(option.value)}
              title={option.title || option.label}
              className={cn(
                'relative inline-flex h-7.5 shrink-0 items-center gap-1.5 rounded-[7px] px-2.5 text-[12.5px] font-medium whitespace-nowrap transition-colors duration-150',
                active ? 'text-ink' : 'text-ink-3 hover:text-ink-2',
              )}
            >
              {active && (
                <motion.span
                  layoutId="segment-thumb"
                  aria-hidden="true"
                  transition={SPRING}
                  className="absolute inset-0 rounded-[7px] bg-surface shadow-sm ring-1 ring-line"
                />
              )}
              <span className="relative inline-flex items-center gap-1.5">
                {option.icon && <option.icon aria-hidden="true" className="size-3.5" />}
                {option.label}
              </span>
            </button>
          );
        })}
      </div>
    </LayoutGroup>
  );
}
