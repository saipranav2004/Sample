import { ArrowDown, ArrowUp, ChevronRight } from 'lucide-react';
import { useMediaQuery } from '../lib/hooks';
import { cn } from './cn';
import { GridSkeleton, LoadingAnnouncement } from './Skeleton';

/**
 * Data grid for dense, wide records.
 *
 * Columns: { key, header, width, align, sortable, cell(row), primary,
 *            priority: 'always' | 'wide' | 'xl', mobile }
 *
 *   priority 'wide' hides a column below 768px, 'xl' below 1536px - the
 *   columns that help but are not needed to pick a row.
 *   mobile: true puts the column on the one-line summary of a phone card.
 *
 * `selectedKey` marks the row whose preview is open, so the reader keeps
 * their place in the list while a drawer covers part of it.
 *
 * `sortable` columns call `onSortChange`; the list screens pass the sort to
 * the API (`sort_by`, `sort_order`), so a header never sorts just one page.
 *
 * Below the `md` breakpoint the same columns are re-composed as record cards
 * rather than being pushed into a horizontal scroll.
 */
export function DataGrid({
  columns,
  rows,
  rowKey,
  loading = false,
  refreshing = false,
  onRowClick,
  sort,
  onSortChange,
  emptyState,
  caption,
  skeletonRows = 8,
  rowActions,
  /** 'compact' | 'comfortable' - client-side only, a table-reading preference. */
  density = 'comfortable',
  /** Per-row accent colour, e.g. the identity's classification hue. */
  rowAccent,
  selectedKey,
  rowLabel,
  className,
}) {
  const isWide = useMediaQuery('(min-width: 768px)');
  const isXl = useMediaQuery('(min-width: 1536px)');
  const visibleColumns = columns.filter(
    (column) => (column.priority !== 'wide' || isWide) && (column.priority !== 'xl' || isXl),
  );

  if (loading) {
    return (
      <div className={className}>
        <LoadingAnnouncement label={caption ? `Loading ${caption}` : 'Loading records'} />
        <GridSkeleton columns={Math.min(visibleColumns.length, 6)} rows={skeletonRows} />
      </div>
    );
  }

  if (!rows || rows.length === 0) return <div className={className}>{emptyState}</div>;

  const cellPadding = density === 'compact' ? 'px-3 py-2' : 'px-3.5 py-3';

  const toggleSort = (column) => {
    if (!column.sortable || !onSortChange) return;
    const active = sort?.key === column.key;
    onSortChange({
      key: column.key,
      direction: active && sort.direction === 'desc' ? 'asc' : 'desc',
    });
  };

  if (!isWide) {
    const primary = columns.find((column) => column.primary) || columns[0];
    const rest = visibleColumns.filter((column) => column !== primary);
    /* A phone card is a summary: the name, then one line of the columns
       marked `mobile`. Grids that mark none fall back to every column. */
    const summary = columns.filter((column) => column.mobile && column !== primary);

    return (
      <ul
        className={cn(
          'divide-y divide-line transition-opacity duration-200',
          refreshing && 'opacity-55',
          className,
        )}
      >
        {rows.map((row, index) => {
          const interactive = Boolean(onRowClick);
          const selected = selectedKey !== undefined && selectedKey === rowKey(row, index);
          return (
            <li key={rowKey(row, index)} style={{ '--i': Math.min(index, 12) }} className={cn('row-enter px-4 py-3', selected && 'bg-info-soft/60')}>
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <button
                    type="button"
                    disabled={!interactive}
                    onClick={interactive ? (event) => onRowClick(row, event) : undefined}
                    className={cn(
                      'block w-full text-left',
                      interactive && 'cursor-pointer',
                    )}
                  >
                    <div className="min-w-0">{primary.cell(row)}</div>
                  </button>
                  {summary.length > 0 ? (
                    <div className="mt-1.5 flex min-w-0 flex-wrap items-center gap-x-2.5 gap-y-1 text-[12px] text-ink-2">
                      {summary.map((column) => (
                        <span key={column.key} className="min-w-0 max-w-full [&_*]:max-w-full">
                          {column.cell(row)}
                        </span>
                      ))}
                    </div>
                  ) : (
                  <dl className="mt-2.5 grid grid-cols-2 gap-x-3 gap-y-2">
                    {rest.map((column) => (
                      <div key={column.key} className="min-w-0">
                        <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
                          {column.header}
                        </dt>
                        <dd className="mt-0.5 min-w-0 text-[12.5px] text-ink-2">{column.cell(row)}</dd>
                      </div>
                    ))}
                  </dl>
                  )}
                </div>
                {rowActions && <div className="shrink-0">{rowActions(row)}</div>}
                {!rowActions && interactive && (
                  <ChevronRight aria-hidden="true" className="mt-1 size-4 shrink-0 text-ink-3" />
                )}
              </div>
            </li>
          );
        })}
      </ul>
    );
  }

  return (
    <div className={cn('w-full overflow-x-auto', className)}>
      <table className="w-full min-w-full border-collapse text-left">
        {caption && <caption className="sr-only">{caption}</caption>}
        <thead className="grid-sticky-head">
          <tr className="border-b border-line">
            {visibleColumns.map((column) => {
              const active = sort?.key === column.key;
              const SortIcon = active && sort.direction === 'asc' ? ArrowUp : ArrowDown;
              return (
                <th
                  key={column.key}
                  scope="col"
                  style={column.width ? { width: column.width } : undefined}
                  aria-sort={active ? (sort.direction === 'asc' ? 'ascending' : 'descending') : undefined}
                  className={cn(
                    'px-3.5 py-2.5 text-[11px] font-semibold tracking-[0.07em] whitespace-nowrap text-ink-3 uppercase',
                    column.align === 'right' && 'text-right',
                    column.align === 'center' && 'text-center',
                  )}
                >
                  {column.sortable && onSortChange ? (
                    <button
                      type="button"
                      onClick={() => toggleSort(column)}
                      className={cn(
                        /* Buttons get `text-transform: none` from the UA
                           stylesheet, so the header casing has to be restated. */
                        'inline-flex items-center gap-1.5 rounded uppercase tracking-[0.07em] transition-colors hover:text-ink',
                        active && 'text-ink',
                      )}
                    >
                      {column.header}
                      <SortIcon
                        aria-hidden="true"
                        className={cn('size-3', active ? 'opacity-100' : 'opacity-25')}
                      />
                    </button>
                  ) : (
                    column.header
                  )}
                </th>
              );
            })}
            {rowActions && (
              <th scope="col" className="w-12 px-2 py-2.5">
                <span className="sr-only">Actions</span>
              </th>
            )}
          </tr>
        </thead>
        <tbody className={cn('transition-opacity duration-200', refreshing && 'opacity-55')}>
          {rows.map((row, index) => {
            const interactive = Boolean(onRowClick);
            const selected = selectedKey !== undefined && selectedKey === rowKey(row, index);
            return (
              <tr
                key={rowKey(row, index)}
                aria-selected={selectedKey !== undefined ? selected : undefined}
                data-selected={selected || undefined}
                onClick={interactive ? (event) => onRowClick(row, event) : undefined}
                onKeyDown={
                  interactive
                    ? (event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          onRowClick(row, event);
                        }
                      }
                    : undefined
                }
                tabIndex={interactive ? 0 : undefined}
                aria-label={interactive ? (rowLabel ? rowLabel(row) : 'Open record detail') : undefined}
                className={cn(
                  'grid-row row-enter border-b border-line/80 transition-colors duration-100 last:border-b-0',
                  interactive && 'cursor-pointer hover:bg-surface-2 focus-visible:bg-surface-2',
                  selected && 'bg-info-soft/60 hover:bg-info-soft/80',
                )}
                style={{ '--i': Math.min(index, 12), ...(rowAccent ? { '--t-brand': rowAccent(row) } : null) }}
              >
                {visibleColumns.map((column) => (
                  <td
                    key={column.key}
                    className={cn(
                      'max-w-0 align-middle text-[13px] text-ink-2',
                      cellPadding,
                      column.align === 'right' && 'text-right',
                      column.align === 'center' && 'text-center',
                    )}
                  >
                    {column.cell(row)}
                  </td>
                ))}
                {rowActions && (
                  <td className={cn('text-right align-middle', density === 'compact' ? 'px-2 py-2' : 'px-2 py-3')}>
                    <span className="row-actions inline-flex justify-end">{rowActions(row)}</span>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/** Primary cell composition: strong title over a muted, monospaced locator. */
export function CellStack({ title, meta, mono = false, icon: Icon, tone }) {
  return (
    <div className="flex min-w-0 items-center gap-2.5">
      {Icon && (
        <span
          className={cn(
            'grid size-7 shrink-0 place-items-center rounded-md border border-line bg-surface-2',
            tone,
          )}
        >
          <Icon aria-hidden="true" className="size-3.5" />
        </span>
      )}
      <span className="min-w-0">
        <span className="block truncate text-[13px] font-medium text-ink" title={title}>
          {title}
        </span>
        {meta && (
          <span
            className={cn('mt-0.5 block truncate text-[11.5px] text-ink-3', mono && 'font-mono')}
            title={typeof meta === 'string' ? meta : undefined}
          >
            {meta}
          </span>
        )}
      </span>
    </div>
  );
}
