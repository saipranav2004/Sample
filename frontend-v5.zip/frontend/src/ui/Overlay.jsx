import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { useFocusTrap, useScrollLock } from '../lib/hooks';
import { SPRING } from '../lib/motion';
import { IconButton } from './Button';
import { cn } from './cn';

function useEscape(active, onClose) {
  useEffect(() => {
    if (!active) return undefined;
    const onKeyDown = (event) => {
      if (event.key === 'Escape') onClose?.();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [active, onClose]);
}

function Backdrop({ onClose, label }) {
  return (
    <motion.button
      type="button"
      aria-label={label}
      onClick={onClose}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="absolute inset-0 bg-[var(--t-overlay)] backdrop-blur-[2px]"
    />
  );
}

/**
 * Right-hand drawer for record detail, so the operator keeps their place in
 * the list behind it. Slides in on a spring and out again on close.
 */
export function Drawer({ open, ...props }) {
  useScrollLock(open);
  return createPortal(<AnimatePresence>{open && <DrawerPanel {...props} />}</AnimatePresence>, document.body);
}

function DrawerPanel({ onClose, title, subtitle, eyebrow, width = 'lg', header, children, footer }) {
  const panelRef = useRef(null);
  useFocusTrap(panelRef, true);
  useEscape(true, onClose);
  const widths = { md: 'sm:max-w-xl', lg: 'sm:max-w-2xl', xl: 'sm:max-w-4xl' };

  return (
    <div className="fixed inset-0 z-[70] flex justify-end">
      <Backdrop onClose={onClose} label="Close panel" />
      <motion.div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={SPRING}
        className={cn('relative flex h-full w-full flex-col border-l border-line bg-surface shadow-lg', widths[width])}
      >
        <header className="flex items-start gap-3 border-b border-line bg-surface-2 px-4 py-3.5 sm:px-5">
          <div className="min-w-0 flex-1">
            {eyebrow && (
              <p className="text-[10.5px] font-semibold tracking-[0.13em] text-ink-3 uppercase">{eyebrow}</p>
            )}
            <h2 className="mt-0.5 truncate text-[16px] font-semibold text-ink" title={title}>
              {title}
            </h2>
            {subtitle && <div className="mt-1 min-w-0 text-[12.5px] text-ink-3">{subtitle}</div>}
            {header}
          </div>
          <IconButton icon={X} label="Close panel" onClick={onClose} />
        </header>
        <div className="@container min-h-0 flex-1 overflow-y-auto overscroll-contain">{children}</div>
        {footer && (
          <footer className="flex flex-wrap items-center justify-end gap-2 border-t border-line bg-surface-2 px-4 py-3 sm:px-5">
            {footer}
          </footer>
        )}
      </motion.div>
    </div>
  );
}

/** Centre-stage modal, reserved for decisions that must be answered now. */
export function Modal({ open, ...props }) {
  useScrollLock(open);
  return createPortal(<AnimatePresence>{open && <ModalPanel {...props} />}</AnimatePresence>, document.body);
}

const MODAL_TONES = {
  brand: 'border-brand/25 bg-info-soft text-brand',
  critical: 'border-critical/25 bg-critical-soft text-critical',
  medium: 'border-medium/25 bg-medium-soft text-medium',
};

function ModalPanel({ onClose, title, description, icon: Icon, tone = 'brand', children, footer }) {
  const panelRef = useRef(null);
  useFocusTrap(panelRef, true);
  useEscape(true, onClose);

  return (
    <div className="fixed inset-0 z-[75] grid place-items-end p-0 sm:place-items-center sm:p-6">
      <Backdrop onClose={onClose} label="Close dialog" />
      <motion.div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 16, scale: 0.98 }}
        transition={SPRING}
        className="relative flex max-h-[calc(100dvh-1rem)] w-full max-w-lg flex-col rounded-t-[18px] border border-line bg-surface shadow-lg sm:max-h-[calc(100dvh-3rem)] sm:rounded-[18px]"
      >
        <div className="flex shrink-0 items-start gap-3 p-5 pb-3">
          {Icon && (
            <span className={cn('grid size-9 shrink-0 place-items-center rounded-full border', MODAL_TONES[tone])}>
              <Icon aria-hidden="true" className="size-4.5" />
            </span>
          )}
          <div className="min-w-0 flex-1">
            <h2 className="text-[15.5px] font-semibold text-ink">{title}</h2>
            {description && <p className="mt-1 text-[12.5px] leading-relaxed text-ink-3">{description}</p>}
          </div>
          <IconButton icon={X} label="Close dialog" size="sm" onClick={onClose} />
        </div>
        {children && <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-4">{children}</div>}
        {footer && (
          <div className="flex shrink-0 flex-wrap items-center justify-end gap-2 border-t border-line bg-surface-2 px-5 py-3.5 sm:rounded-b-[18px]">
            {footer}
          </div>
        )}
      </motion.div>
    </div>
  );
}
