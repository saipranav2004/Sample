import { Fingerprint, Gauge, History, KeyRound, Moon, TimerReset } from 'lucide-react';

/**
 * Information architecture. Every item is a screen backed by the NHI API
 * (see docs/WIREFRAMES.md for the endpoint behind each one).
 */
export const NAV_GROUPS = [
  {
    key: 'overview',
    label: 'Overview',
    items: [{ to: '/overview', label: 'Dashboard', icon: Gauge, end: true }],
  },
  {
    key: 'inventory',
    label: 'Inventory',
    items: [
      { to: '/identities', label: 'Identities', icon: Fingerprint },
      { to: '/credentials', label: 'Credentials', icon: KeyRound },
    ],
  },
  {
    key: 'risk',
    label: 'Risk',
    items: [
      { to: '/hygiene', label: 'Credential hygiene', icon: TimerReset },
      { to: '/dormant', label: 'Dormant identities', icon: Moon },
    ],
  },
  {
    key: 'activity',
    label: 'Activity',
    items: [{ to: '/discoveries', label: 'Recent discoveries', icon: History }],
  },
];

/** The navigation a role can use; groups left empty are removed. */
export function navGroupsFor(can) {
  return NAV_GROUPS.map((group) => ({
    ...group,
    items: group.items.filter((item) => !item.permission || can(item.permission)),
  })).filter((group) => group.items.length > 0);
}

export const ALL_NAV_ITEMS = NAV_GROUPS.flatMap((group) =>
  group.items.map((item) => ({ ...item, group: group.label })),
);

/** Breadcrumb trail per route, kept as data so labels match the navigation. */
export const BREADCRUMBS = {
  '/overview': ['Overview', 'Dashboard'],
  '/identities': ['Inventory', 'Identities'],
  '/credentials': ['Inventory', 'Credentials'],
  '/hygiene': ['Risk', 'Credential hygiene'],
  '/dormant': ['Risk', 'Dormant identities'],
  '/discoveries': ['Activity', 'Recent discoveries'],
};

/** Breadcrumbs for routes with a parameter, matched by prefix. */
export const BREADCRUMB_PREFIXES = [
  { prefix: '/identities/', trail: ['Inventory', 'Identities', 'Identity'] },
  { prefix: '/credentials/', trail: ['Inventory', 'Credentials', 'Credential'] },
];
