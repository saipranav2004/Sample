-- Run this as nhi_scanner user in Oracle

CREATE TABLE nhi_scanner.nhi_users (
    id          NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email       VARCHAR2(200) NOT NULL UNIQUE,
    password    VARCHAR2(500) NOT NULL,
    full_name   VARCHAR2(200),
    team        VARCHAR2(100),
    role        VARCHAR2(50) DEFAULT 'developer',
    created_at  TIMESTAMP DEFAULT SYSTIMESTAMP
);

CREATE INDEX idx_users_email ON nhi_scanner.nhi_users(email);