-- Default admin user (password: admin123 — hashed with bcrypt)
-- In production, hash this properly. This is a placeholder.

INSERT INTO nhi_scanner.nhi_users (email, password, full_name, team, role)
VALUES ('abhishek.tiwari@example.com', 'admin123', 'Abhishek Tiwari', 'platform-engineering', 'admin');

COMMIT;