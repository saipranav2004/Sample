package jwt

import (
	"errors"
	"time"

	jwtGo "github.com/golang-jwt/jwt/v5"
)

type CustomClaims struct {
	UserID int    `json:"user_id"`
	Email  string `json:"email"`
	Role   string `json:"role"`
	Team   string `json:"team"`
	jwtGo.RegisteredClaims
}

// GenerateToken creates a signed JWT token
func GenerateToken(userID int, email, role, team, secret string, expiryHours int) (string, error) {
	claims := CustomClaims{
		UserID: userID,
		Email:  email,
		Role:   role,
		Team:   team,
		RegisteredClaims: jwtGo.RegisteredClaims{
			ExpiresAt: jwtGo.NewNumericDate(time.Now().Add(time.Duration(expiryHours) * time.Hour)),
			IssuedAt:  jwtGo.NewNumericDate(time.Now()),
			Subject:   email,
		},
	}

	token := jwtGo.NewWithClaims(jwtGo.SigningMethodHS256, claims)
	return token.SignedString([]byte(secret))
}

// ValidateToken parses and validates a JWT token
func ValidateToken(tokenString, secret string) (*CustomClaims, error) {
	token, err := jwtGo.ParseWithClaims(tokenString, &CustomClaims{}, func(token *jwtGo.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwtGo.SigningMethodHMAC); !ok {
			return nil, errors.New("unexpected signing method")
		}
		return []byte(secret), nil
	})

	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(*CustomClaims)
	if !ok || !token.Valid {
		return nil, errors.New("invalid token")
	}

	return claims, nil
}
