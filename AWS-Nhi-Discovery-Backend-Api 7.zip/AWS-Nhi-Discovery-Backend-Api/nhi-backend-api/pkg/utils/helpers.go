package utils

import (
	"net/http"
	"strconv"
)

// GetPaginationParams extracts page and pageSize from URL query parameters
func GetPaginationParams(r *http.Request) (page, pageSize int) {
	pageStr := r.URL.Query().Get("page")
	pageSizeStr := r.URL.Query().Get("page_size")

	page = 1
	pageSize = 20

	if p, err := strconv.Atoi(pageStr); err == nil && p > 0 {
		page = p
	}
	if ps, err := strconv.Atoi(pageSizeStr); err == nil && ps > 0 && ps <= 100 {
		pageSize = ps
	}

	return page, pageSize
}

// CalculateOffset returns the SQL offset for pagination
func CalculateOffset(page, pageSize int) int {
	return (page - 1) * pageSize
}
