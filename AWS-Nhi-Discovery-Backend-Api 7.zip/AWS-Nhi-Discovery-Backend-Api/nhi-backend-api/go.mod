module nhi-backend-api

go 1.26.5

require (
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/sijms/go-ora/v2 v2.9.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/gorilla/mux v1.8.1
	github.com/rs/cors v1.11.1
	golang.org/x/crypto v0.57.0
)
