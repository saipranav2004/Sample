// internal/handlers/lineage.go
package handlers

import (
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type LineageHandler struct {
	lineageService *services.LineageService
}

func NewLineageHandler(lineageService *services.LineageService) *LineageHandler {
	return &LineageHandler{lineageService: lineageService}
}

// GetServiceAccess handles GET /api/identities/lineage?arn=xxx&scan_id=xxx&page=1&page_size=10
func (h *LineageHandler) GetServiceAccess(w http.ResponseWriter, r *http.Request) {
	arn := r.URL.Query().Get("arn")
	scanID := r.URL.Query().Get("scan_id")

	if arn == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "Missing required query parameter: arn",
		})
		return
	}

	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	filter := repository.LineageFilter{
		SourceARN: arn,
		ScanID:    scanID,
		Offset:    offset,
		Limit:     pageSize,
	}

	edges, totalCount, err := h.lineageService.GetServiceAccess(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to retrieve service access lineage",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Service access lineage retrieved",
		Data:       edges,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
