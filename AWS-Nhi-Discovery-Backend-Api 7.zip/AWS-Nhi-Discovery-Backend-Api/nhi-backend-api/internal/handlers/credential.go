package handlers

import (
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type CredentialHandler struct {
	service *services.CredentialService
}

func NewCredentialHandler(service *services.CredentialService) *CredentialHandler {
	return &CredentialHandler{service: service}
}

// List handles GET /api/credentials
func (h *CredentialHandler) List(w http.ResponseWriter, r *http.Request) {
	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	query := r.URL.Query()
	filter := repository.CredentialFilter{
		Search:   query.Get("search"),
		Type:     query.Get("type"),
		Severity: query.Get("severity"),
		ScanID:   query.Get("scan_id"),
		Offset:   offset,
		Limit:    pageSize,
	}

	list, totalCount, err := h.service.ListCredentials(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to fetch credentials list",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Credentials list fetched successfully",
		Data:       list,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
