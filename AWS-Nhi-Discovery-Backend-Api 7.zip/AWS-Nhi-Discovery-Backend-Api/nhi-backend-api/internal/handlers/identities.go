// internal/handlers/identity.go
package handlers

import (
	"log"
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type IdentityHandler struct {
	identityService *services.IdentityService
	consumerService *services.ConsumerService
}

func NewIdentityHandler(identityService *services.IdentityService, consumerService *services.ConsumerService) *IdentityHandler {
	return &IdentityHandler{
		identityService: identityService,
		consumerService: consumerService,
	}
}

func (h *IdentityHandler) List(w http.ResponseWriter, r *http.Request) {
	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	filter := repository.IdentityFilter{
		Search:         r.URL.Query().Get("search"),
		Classification: r.URL.Query().Get("classification"),
		IdentityType:   r.URL.Query().Get("identity_type"),
		OwnerName:      r.URL.Query().Get("owner_name"),
		OwnerType:      r.URL.Query().Get("owner_type"),
		ScanID:         r.URL.Query().Get("scan_id"),
		Offset:         offset,
		Limit:          pageSize,
	}

	if isSecretStr := r.URL.Query().Get("is_secret"); isSecretStr != "" {
		isSecret := isSecretStr == "true" || isSecretStr == "1"
		filter.IsSecret = &isSecret
	}
	if hasCredsStr := r.URL.Query().Get("has_credentials"); hasCredsStr != "" {
		hasCreds := hasCredsStr == "true" || hasCredsStr == "1"
		filter.HasCredentials = &hasCreds
	}
	if withoutMFAStr := r.URL.Query().Get("without_mfa"); withoutMFAStr != "" {
		withoutMFA := withoutMFAStr == "true" || withoutMFAStr == "1"
		filter.WithoutMFA = &withoutMFA
	}
	if isFederatedStr := r.URL.Query().Get("is_federated"); isFederatedStr != "" {
		isFederated := isFederatedStr == "true" || isFederatedStr == "1"
		filter.IsFederated = &isFederated
	}
	if isAdminStr := r.URL.Query().Get("is_admin"); isAdminStr != "" {
		isAdmin := isAdminStr == "true" || isAdminStr == "1"
		filter.IsAdmin = &isAdmin
	}
	if isStaleStr := r.URL.Query().Get("is_stale"); isStaleStr != "" {
		isStale := isStaleStr == "true" || isStaleStr == "1"
		filter.IsStale = &isStale
	}
	if isInactiveStr := r.URL.Query().Get("is_inactive"); isInactiveStr != "" {
		isInactive := isInactiveStr == "true" || isInactiveStr == "1"
		filter.IsInactive = &isInactive
	}

	identities, totalCount, err := h.identityService.ListIdentities(r.Context(), filter)
	if err != nil {
		log.Printf("[API ERROR] ListIdentities: %v", err)
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to retrieve identities",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Identities retrieved",
		Data:       identities,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}

func (h *IdentityHandler) Consumers(w http.ResponseWriter, r *http.Request) {
	arn := r.URL.Query().Get("arn")
	scanID := r.URL.Query().Get("scan_id")

	if arn == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "arn query parameter is required",
		})
		return
	}

	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	consumers, totalCount, err := h.consumerService.GetRoleConsumers(r.Context(), arn, scanID, offset, pageSize)
	if err != nil {
		log.Printf("[API ERROR] GetRoleConsumers: %v", err)
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to retrieve role consumers",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Role consumers retrieved",
		Data:       consumers,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
