package handlers

import (
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type SecretHandler struct {
	identityService *services.IdentityService
}

func NewSecretHandler(identityService *services.IdentityService) *SecretHandler {
	return &SecretHandler{identityService: identityService}
}

// List handles GET /api/secrets
func (h *SecretHandler) List(w http.ResponseWriter, r *http.Request) {
	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)
	search := r.URL.Query().Get("search")
	scanID := r.URL.Query().Get("scan_id") // <--- ADD THIS

	isSecret := true
	filter := repository.IdentityFilter{
		Search:   search,
		IsSecret: &isSecret,
		ScanID:   scanID, // <--- ADD THIS
		Offset:   offset,
		Limit:    pageSize,
	}

	secrets, totalCount, err := h.identityService.ListIdentities(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false, Message: "Failed to fetch secrets", Error: err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success: true, Message: "Secrets retrieved", Data: secrets,
		TotalCount: totalCount, Page: page, PageSize: pageSize,
	})
}
