// internal/handlers/dashboard.go
package handlers

import (
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type DashboardHandler struct {
	dashboardService *services.DashboardService
}

func NewDashboardHandler(dashboardService *services.DashboardService) *DashboardHandler {
	return &DashboardHandler{dashboardService: dashboardService}
}

// Summary handles GET /api/dashboard/summary
func (h *DashboardHandler) Summary(w http.ResponseWriter, r *http.Request) {
	scanID := r.URL.Query().Get("scan_id")

	summary, err := h.dashboardService.GetSummary(r.Context(), scanID)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load dashboard summary",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.APIResponse{
		Success: true,
		Message: "Dashboard summary retrieved",
		Data:    summary,
	})
}

// MyResources handles GET /api/dashboard/my-resources
func (h *DashboardHandler) MyResources(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		sendJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false,
			Message: "Unauthorized",
		})
		return
	}

	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)
	scanID := r.URL.Query().Get("scan_id")

	resources, totalCount, err := h.dashboardService.GetMyResources(r.Context(), claims.Email, offset, pageSize, scanID)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to retrieve user resources",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "User resources retrieved",
		Data:       resources,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
