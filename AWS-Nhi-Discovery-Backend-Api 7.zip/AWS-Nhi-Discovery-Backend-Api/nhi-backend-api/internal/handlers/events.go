package handlers

import (
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/pkg/utils"
)

type EventHandler struct {
	eventRepo *repository.EventRepository
}

func NewEventHandler(eventRepo *repository.EventRepository) *EventHandler {
	return &EventHandler{eventRepo: eventRepo}
}

// List handles GET /api/events
func (h *EventHandler) List(w http.ResponseWriter, r *http.Request) {
	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	identityARN := r.URL.Query().Get("identity_arn")
	scanID := r.URL.Query().Get("scan_id")

	events, totalCount, err := h.eventRepo.ListByIdentity(r.Context(), identityARN, scanID, offset, pageSize)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to retrieve events",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Events retrieved successfully",
		Data:       events,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
