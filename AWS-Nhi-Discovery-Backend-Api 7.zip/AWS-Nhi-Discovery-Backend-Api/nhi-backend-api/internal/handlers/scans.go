package handlers

import (
	"net/http"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/services"
	"nhi-backend-api/pkg/utils"
)

type ScanHandler struct {
	scanService *services.ScanService
}

func NewScanHandler(scanService *services.ScanService) *ScanHandler {
	return &ScanHandler{scanService: scanService}
}

// List handles GET /api/scans
func (h *ScanHandler) List(w http.ResponseWriter, r *http.Request) {
	page, pageSize := utils.GetPaginationParams(r)
	offset := utils.CalculateOffset(page, pageSize)

	scans, totalCount, err := h.scanService.ListScans(r.Context(), offset, pageSize)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to fetch scan history",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, models.PaginatedResponse{
		Success:    true,
		Message:    "Scan history retrieved successfully",
		Data:       scans,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	})
}
