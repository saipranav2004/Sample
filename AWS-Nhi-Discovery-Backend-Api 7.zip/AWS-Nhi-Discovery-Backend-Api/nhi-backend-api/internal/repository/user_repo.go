package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"nhi-backend-api/internal/models"
)

type UserRepository struct {
	db *OracleDB
}

func NewUserRepository(db *OracleDB) *UserRepository {
	return &UserRepository{db: db}
}

// GetByEmail retrieves a user record by email
func (r *UserRepository) GetByEmail(ctx context.Context, email string) (*models.User, error) {
	query := `
		SELECT id, email, password, full_name, team, role, created_at
		FROM nhi_scanner.nhi_users
		WHERE LOWER(TRIM(email)) = LOWER(TRIM(:1))`

	row := r.db.DB.QueryRowContext(ctx, query, email)

	var u models.User
	err := row.Scan(&u.ID, &u.Email, &u.Password, &u.FullName, &u.Team, &u.Role, &u.CreatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil // No row matched
		}
		return nil, fmt.Errorf("query user by email: %w", err)
	}

	return &u, nil
}

// GetByID retrieves a user record by ID
func (r *UserRepository) GetByID(ctx context.Context, id int) (*models.User, error) {
	query := `
		SELECT id, email, password, full_name, team, role, created_at
		FROM nhi_scanner.nhi_users
		WHERE id = :1`

	row := r.db.DB.QueryRowContext(ctx, query, id)

	var u models.User
	err := row.Scan(&u.ID, &u.Email, &u.Password, &u.FullName, &u.Team, &u.Role, &u.CreatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("query user by id: %w", err)
	}

	return &u, nil
}
