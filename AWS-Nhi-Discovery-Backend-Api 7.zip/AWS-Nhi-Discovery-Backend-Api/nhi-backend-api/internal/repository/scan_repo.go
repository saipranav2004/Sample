package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type ScanRepository struct {
	db *OracleDB
}

func NewScanRepository(db *OracleDB) *ScanRepository {
	return &ScanRepository{db: db}
}

// List returns historical scans paginated
func (r *ScanRepository) List(ctx context.Context, offset, limit int) ([]models.Scan, int, error) {
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, "SELECT COUNT(*) FROM nhi_scanner.nhi_scans_aws").Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count scans: %w", err)
	}

	query := `
		SELECT scan_id, account_id, target_name, total_identities,
		       total_events, total_secrets, status, scan_start, scan_end
		FROM nhi_scanner.nhi_scans_aws
		ORDER BY scan_start DESC
		OFFSET :1 ROWS FETCH NEXT :2 ROWS ONLY`

	rows, err := r.db.DB.QueryContext(ctx, query, offset, limit)
	if err != nil {
		return nil, 0, fmt.Errorf("query scans: %w", err)
	}
	defer rows.Close()

	var scans []models.Scan
	for rows.Next() {
		var s models.Scan
		var scanEnd sql.NullTime

		err := rows.Scan(
			&s.ScanID, &s.AccountID, &s.TargetName, &s.TotalIdentities,
			&s.TotalEvents, &s.TotalSecrets, &s.Status, &s.ScanStart, &scanEnd,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan row: %w", err)
		}

		if scanEnd.Valid {
			s.ScanEnd = &scanEnd.Time
		}

		scans = append(scans, s)
	}

	return scans, totalCount, nil
}
