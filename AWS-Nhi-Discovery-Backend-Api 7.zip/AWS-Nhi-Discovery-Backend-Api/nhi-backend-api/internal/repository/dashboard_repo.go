package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type DashboardRepository struct {
	db *OracleDB
}

func NewDashboardRepository(db *OracleDB) *DashboardRepository {
	return &DashboardRepository{db: db}
}

// GetSummary calculates top-level metrics for the latest scan (supporting scan isolation)
func (r *DashboardRepository) GetSummary(ctx context.Context, scanID string) (*models.DashboardSummary, error) {
	scanFilter := "scan_id = (SELECT scan_id FROM (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_start DESC) WHERE ROWNUM = 1)"
	var args []interface{}

	if scanID != "" {
		scanFilter = "scan_id = :1"
		args = append(args, scanID)
	}

	countsQuery := fmt.Sprintf(`
		SELECT
			COUNT(*) AS total_identities,
			NVL(SUM(CASE WHEN is_secret = 1 THEN 1 ELSE 0 END), 0) AS total_secrets,
			NVL(SUM(CASE WHEN owner_type = 'ORPHANED' THEN 1 ELSE 0 END), 0) AS total_orphaned,
			NVL(SUM(CASE WHEN classification = 'HUMAN' THEN 1 ELSE 0 END), 0) AS total_humans,
			NVL(SUM(CASE WHEN classification != 'HUMAN' THEN 1 ELSE 0 END), 0) AS total_nhis,
			NVL(SUM(CASE WHEN classification = 'HUMAN' AND (mfa_enabled = 0 OR mfa_enabled IS NULL) THEN 1 ELSE 0 END), 0) AS total_humans_without_mfa,
			NVL(SUM(REGEXP_COUNT(owned_credentials, '"type"')), 0) AS total_credentials,
			
			-- ── POSTURE METRICS ──
			NVL(SUM(CASE WHEN classification = 'NHI_AGENT' THEN 1 ELSE 0 END), 0) AS total_nhi_agents,
			NVL(SUM(CASE WHEN classification = 'NHI_CICD' THEN 1 ELSE 0 END), 0) AS total_nhi_cicd,
			NVL(SUM(CASE WHEN trust_type = 'FEDERATED' THEN 1 ELSE 0 END), 0) AS total_federated,
			NVL(SUM(CASE WHEN is_admin = 1 THEN 1 ELSE 0 END), 0) AS total_admin,
			
			-- ── STALE / INACTIVE METRICS ──
			NVL(SUM(CASE WHEN last_active <= SYSDATE - 90 THEN 1 ELSE 0 END), 0) AS total_stale_90plus,
			NVL(SUM(CASE WHEN last_active <= SYSDATE - 30 AND last_active > SYSDATE - 90 THEN 1 ELSE 0 END), 0) AS total_inactive_30plus
		FROM nhi_scanner.nhi_identities_aws
		WHERE %s`, scanFilter)

	var summary models.DashboardSummary
	var totalCreds sql.NullInt64

	err := r.db.DB.QueryRowContext(ctx, countsQuery, args...).Scan(
		&summary.TotalIdentities,
		&summary.TotalSecrets,
		&summary.TotalOrphaned,
		&summary.TotalHumans,
		&summary.TotalNHIs,
		&summary.TotalHumansWithoutMFA,
		&totalCreds,
		&summary.TotalNhiAgents,
		&summary.TotalNhiCicd,
		&summary.TotalFederated,
		&summary.TotalAdmin,
		&summary.TotalStale90Plus,
		&summary.TotalInactive30Plus,
	)
	if err != nil {
		return nil, fmt.Errorf("get dashboard counts: %w", err)
	}
	if totalCreds.Valid {
		summary.TotalCredentials = int(totalCreds.Int64)
	}

	// Fetch classification breakdown
	breakdownQuery := fmt.Sprintf(`
		SELECT classification, COUNT(*)
		FROM nhi_scanner.nhi_identities_aws
		WHERE %s
		GROUP BY classification`, scanFilter)

	rows, err := r.db.DB.QueryContext(ctx, breakdownQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("get classification breakdown: %w", err)
	}
	defer rows.Close()

	summary.ClassificationBreakdown = make(map[string]int)
	for rows.Next() {
		var class string
		var count int
		if err := rows.Scan(&class, &count); err == nil {
			summary.ClassificationBreakdown[class] = count
		}
	}

	// Fetch credentials category breakdown using Oracle JSON_TABLE
	credsBreakdownQuery := fmt.Sprintf(`
		SELECT jt.credential_type, COUNT(*)
		FROM nhi_scanner.nhi_identities_aws t,
		     JSON_TABLE(t.owned_credentials, '$[*]'
		         COLUMNS (
		             credential_type VARCHAR2(100) PATH '$.type'
		         )
		     ) jt
		WHERE t.%s
		GROUP BY jt.credential_type`, scanFilter)

	credRows, err := r.db.DB.QueryContext(ctx, credsBreakdownQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("get credentials breakdown: %w", err)
	}
	defer credRows.Close()

	summary.CredentialsBreakdown = make(map[string]int)
	for credRows.Next() {
		var credType string
		var count int
		if err := credRows.Scan(&credType, &count); err == nil && credType != "" {
			summary.CredentialsBreakdown[credType] = count
		}
	}

	return &summary, nil
}
