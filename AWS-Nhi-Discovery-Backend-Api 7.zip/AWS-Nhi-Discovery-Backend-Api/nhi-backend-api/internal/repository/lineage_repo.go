// internal/repository/lineage_repo.go
package repository

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
)

type LineageRepository struct {
	db *OracleDB
}

type LineageFilter struct {
	SourceARN string
	ScanID    string
	Offset    int
	Limit     int
}

func NewLineageRepository(db *OracleDB) *LineageRepository {
	return &LineageRepository{db: db}
}

// GetServiceAccess retrieves a paginated slice of accessed services for an identity
func (r *LineageRepository) GetServiceAccess(ctx context.Context, filter LineageFilter) ([]models.LineageEdge, int, error) {
	// Build scan dynamic query filter
	scanFilter := "scan_id = (SELECT scan_id FROM (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_start DESC) WHERE ROWNUM = 1)"

	var countArgs []interface{}
	countArgs = append(countArgs, filter.SourceARN)

	if filter.ScanID != "" {
		scanFilter = "scan_id = :2"
		countArgs = append(countArgs, filter.ScanID)
	}

	// 1. Fetch total count of access lineage records
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM nhi_scanner.nhi_lineage_aws
		WHERE source_arn = :1 AND %s`, scanFilter)

	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, countArgs...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count lineage edges: %w", err)
	}

	if totalCount == 0 {
		return []models.LineageEdge{}, 0, nil
	}

	// 2. Fetch paginated records
	offsetPlaceholder := ":2"
	limitPlaceholder := ":3"
	var selectArgs []interface{}
	selectArgs = append(selectArgs, filter.SourceARN)

	if filter.ScanID != "" {
		offsetPlaceholder = ":3"
		limitPlaceholder = ":4"
		selectArgs = append(selectArgs, filter.ScanID)
	}
	selectArgs = append(selectArgs, filter.Offset, filter.Limit)

	selectQuery := fmt.Sprintf(`
		SELECT 
			NVL(target_name, '—') AS target_name,
			NVL(target_type, '—') AS target_type,
			NVL(rel_type, '—') AS rel_type,
			NVL(direction, '—') AS direction,
			NVL(via, '—') AS via,
			NVL(is_external, 0) AS is_external,
			NVL(detail, '') AS detail
		FROM nhi_scanner.nhi_lineage_aws
		WHERE source_arn = :1 AND %s
		ORDER BY target_name
		OFFSET %s ROWS FETCH NEXT %s ROWS ONLY`, scanFilter, offsetPlaceholder, limitPlaceholder)

	rows, err := r.db.DB.QueryContext(ctx, selectQuery, selectArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("query lineage edges: %w", err)
	}
	defer rows.Close()

	var edges []models.LineageEdge
	for rows.Next() {
		var edge models.LineageEdge
		if err := rows.Scan(
			&edge.TargetName,
			&edge.TargetType,
			&edge.RelType,
			&edge.Direction,
			&edge.Via,
			&edge.IsExternal,
			&edge.Detail,
		); err != nil {
			continue
		}
		edges = append(edges, edge)
	}

	if edges == nil {
		edges = []models.LineageEdge{}
	}

	return edges, totalCount, nil
}
