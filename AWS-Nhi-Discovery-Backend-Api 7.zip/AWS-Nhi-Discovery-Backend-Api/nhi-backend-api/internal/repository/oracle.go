package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	_ "github.com/sijms/go-ora/v2"

	"nhi-backend-api/internal/config"
)

type OracleDB struct {
	DB *sql.DB
}

func NewOracleDB(cfg *config.DatabaseConfig) (*OracleDB, error) {
	connStr := cfg.GetConnectionString()

	db, err := sql.Open("oracle", connStr)
	if err != nil {
		return nil, fmt.Errorf("open oracle: %w", err)
	}

	db.SetMaxOpenConns(20)
	db.SetMaxIdleConns(10)
	db.SetConnMaxLifetime(30 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("ping oracle: %w", err)
	}

	fmt.Println("✅ Oracle DB connected successfully")
	return &OracleDB{DB: db}, nil
}

func (o *OracleDB) Close() {
	if o.DB != nil {
		o.DB.Close()
	}
}
