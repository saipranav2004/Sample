package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
)

type CredentialRepository struct {
	db *OracleDB
}

func NewCredentialRepository(db *OracleDB) *CredentialRepository {
	return &CredentialRepository{db: db}
}

type CredentialFilter struct {
	Search   string
	Type     string
	Severity string
	ScanID   string
	Offset   int
	Limit    int
}

func (r *CredentialRepository) List(ctx context.Context, filter CredentialFilter) ([]models.FlattenedCredential, int, error) {
	whereClauses := []string{"1=1"}
	var args []interface{}
	argIdx := 1

	if filter.ScanID != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("scan_id = :%d", argIdx))
		args = append(args, filter.ScanID)
		argIdx++
	} else {
		whereClauses = append(whereClauses, "scan_id = (SELECT scan_id FROM (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_start DESC) WHERE ROWNUM = 1)")
	}

	if filter.Type != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_type = :%d", argIdx))
		args = append(args, filter.Type)
		argIdx++
	}

	if filter.Severity != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_severity = :%d", argIdx))
		args = append(args, filter.Severity)
		argIdx++
	}

	if filter.Search != "" {
		searchTerm := "%" + strings.ToLower(filter.Search) + "%"
		whereClauses = append(whereClauses, fmt.Sprintf("(LOWER(identity_name) LIKE :%d OR LOWER(identity_arn) LIKE :%d OR LOWER(cred_id) LIKE :%d)", argIdx, argIdx+1, argIdx+2))
		args = append(args, searchTerm, searchTerm, searchTerm)
		argIdx += 3
	}

	whereSection := "WHERE " + strings.Join(whereClauses, " AND ")

	// 1. Dynamic CTE to flatten credentials using Oracle JSON_TABLE
	baseCTE := `
		WITH flattened_creds AS (
			SELECT
				i.id AS identity_id,
				i.arn AS identity_arn,
				i.name AS identity_name,
				i.identity_type,
				i.scan_id,
				jt.type AS cred_type,
				jt.id AS cred_id,
				jt.status AS cred_status,
				jt.severity AS cred_severity,
				jt.created_at,
				jt.expires_at,
				jt.last_used_date,
				jt.last_used_service,
				jt.description
			FROM nhi_scanner.nhi_identities_aws i,
			JSON_TABLE(i.owned_credentials, '$[*]'
				COLUMNS (
					type VARCHAR2(100) PATH '$.type',
					id VARCHAR2(200) PATH '$.id',
					status VARCHAR2(100) PATH '$.status',
					severity VARCHAR2(50) PATH '$.severity',
					created_at VARCHAR2(100) PATH '$.created_at',
					expires_at VARCHAR2(100) PATH '$.expires_at',
					last_used_date VARCHAR2(100) PATH '$.last_used_date',
					last_used_service VARCHAR2(100) PATH '$.last_used_service',
					description VARCHAR2(500) PATH '$.description'
				)
			) jt
		)`

	// 2. Count Total Matches
	countQuery := fmt.Sprintf("%s SELECT COUNT(*) FROM flattened_creds %s", baseCTE, whereSection)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count flattened credentials: %w", err)
	}

	// 3. Paginated Fetch
	dataQuery := fmt.Sprintf(`
		%s
		SELECT identity_id, identity_arn, identity_name, identity_type, scan_id,
		       cred_type, cred_id, cred_status, cred_severity,
		       created_at, expires_at, last_used_date, last_used_service, description
		FROM flattened_creds
		%s
		ORDER BY cred_severity DESC, identity_id DESC
		OFFSET :%d ROWS FETCH NEXT :%d ROWS ONLY`, baseCTE, whereSection, argIdx, argIdx+1)

	args = append(args, filter.Offset, filter.Limit)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query flattened credentials: %w", err)
	}
	defer rows.Close()

	var list []models.FlattenedCredential
	for rows.Next() {
		var c models.FlattenedCredential
		var idName, idARN, idType, scanID sql.NullString
		var cType, cID, cStatus, cSeverity sql.NullString
		var cCreated, cExpires, cLastUsed, cLastUsedSvc, cDesc sql.NullString

		err := rows.Scan(
			&c.IdentityID, &idARN, &idName, &idType, &scanID,
			&cType, &cID, &cStatus, &cSeverity,
			&cCreated, &cExpires, &cLastUsed, &cLastUsedSvc, &cDesc,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan credential row: %w", err)
		}

		c.IdentityARN = idARN.String
		c.IdentityName = idName.String
		c.IdentityType = idType.String
		c.ScanID = scanID.String
		c.Type = cType.String
		c.CredID = cID.String
		c.Status = cStatus.String
		c.Severity = cSeverity.String
		c.CreatedAt = cCreated.String
		c.ExpiresAt = cExpires.String
		c.LastUsedDate = cLastUsed.String
		c.LastUsedService = cLastUsedSvc.String
		c.Description = cDesc.String

		list = append(list, c)
	}

	return list, totalCount, nil
}
