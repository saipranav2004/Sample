// internal/repository/identity_repo.go
package repository

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"nhi-backend-api/internal/models"
)

type IdentityRepository struct {
	db *OracleDB
}

func NewIdentityRepository(db *OracleDB) *IdentityRepository {
	return &IdentityRepository{db: db}
}

type IdentityFilter struct {
	Search         string
	Classification string
	IdentityType   string
	OwnerName      string
	OwnerType      string
	IsSecret       *bool
	HasCredentials *bool
	WithoutMFA     *bool
	IsFederated    *bool
	IsAdmin        *bool
	IsStale        *bool
	IsInactive     *bool
	ScanID         string
	Offset         int
	Limit          int
}

func (r *IdentityRepository) List(ctx context.Context, filter IdentityFilter) ([]models.Identity, int, error) {
	var conditions []string
	var args []interface{}
	argIdx := 1

	if filter.ScanID != "" {
		conditions = append(conditions, fmt.Sprintf("scan_id = :%d", argIdx))
		args = append(args, filter.ScanID)
		argIdx++
	} else {
		conditions = append(conditions, "scan_id = (SELECT scan_id FROM (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_start DESC) WHERE ROWNUM = 1)")
	}

	if filter.Search != "" {
		searchTerm := "%" + strings.ToLower(filter.Search) + "%"
		conditions = append(conditions, fmt.Sprintf("(LOWER(name) LIKE :%d OR LOWER(arn) LIKE :%d OR LOWER(evidence) LIKE :%d)", argIdx, argIdx+1, argIdx+2))
		args = append(args, searchTerm, searchTerm, searchTerm)
		argIdx += 3
	}

	if filter.Classification != "" {
		conditions = append(conditions, fmt.Sprintf("classification = :%d", argIdx))
		args = append(args, filter.Classification)
		argIdx++
	}

	if filter.IdentityType != "" {
		conditions = append(conditions, fmt.Sprintf("identity_type = :%d", argIdx))
		args = append(args, filter.IdentityType)
		argIdx++
	}

	if filter.OwnerName != "" {
		conditions = append(conditions, fmt.Sprintf("(LOWER(owner_name) = LOWER(:%d) OR LOWER(primary_owner) LIKE LOWER(:%d) OR LOWER(created_by_name) = LOWER(:%d))", argIdx, argIdx+1, argIdx+2))
		args = append(args, filter.OwnerName, "%"+filter.OwnerName+"%", filter.OwnerName)
		argIdx += 3
	}

	if filter.OwnerType != "" {
		conditions = append(conditions, fmt.Sprintf("owner_type = :%d", argIdx))
		args = append(args, filter.OwnerType)
		argIdx++
	}

	if filter.IsSecret != nil {
		secretVal := 0
		if *filter.IsSecret {
			secretVal = 1
		}
		conditions = append(conditions, fmt.Sprintf("is_secret = :%d", argIdx))
		args = append(args, secretVal)
		argIdx++
	}

	if filter.HasCredentials != nil {
		if *filter.HasCredentials {
			conditions = append(conditions, "owned_credentials IS NOT NULL AND DBMS_LOB.GETLENGTH(owned_credentials) > 2")
		} else {
			conditions = append(conditions, "(owned_credentials IS NULL OR DBMS_LOB.GETLENGTH(owned_credentials) <= 2)")
		}
	}

	if filter.WithoutMFA != nil && *filter.WithoutMFA {
		conditions = append(conditions, "(mfa_enabled = 0 OR mfa_enabled IS NULL)")
	}

	if filter.IsFederated != nil && *filter.IsFederated {
		conditions = append(conditions, "trust_type = 'FEDERATED'")
	}

	if filter.IsAdmin != nil && *filter.IsAdmin {
		conditions = append(conditions, "is_admin = 1")
	}

	if filter.IsStale != nil && *filter.IsStale {
		conditions = append(conditions, "last_active IS NOT NULL AND last_active <= SYSDATE - 90")
	}

	if filter.IsInactive != nil && *filter.IsInactive {
		conditions = append(conditions, "last_active IS NOT NULL AND last_active <= SYSDATE - 30 AND last_active > SYSDATE - 90")
	}

	whereClause := ""
	if len(conditions) > 0 {
		whereClause = "WHERE " + strings.Join(conditions, " AND ")
	}

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM nhi_scanner.nhi_identities_aws %s", whereClause)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		log.Printf("[DB ERROR] Count Query failed: %v", err)
		return nil, 0, fmt.Errorf("count identities: %w", err)
	}

	dataQuery := fmt.Sprintf(`
		SELECT id, scan_id, arn, name, identity_type, classification,
		       trust_type, trust_service, evidence, matched_rules,
		       total_events,
		       TO_CHAR(last_active, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as last_active_str,
		       owner_name, owner_type, primary_owner, created_by_name,
		       attached_policies, is_admin, TO_CHAR(owned_credentials), is_secret,
		       TO_CHAR(created_at, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at_str,
		       discovered_at,
		       groups_list, mfa_enabled, password_age_days, console_access,
		       TO_CHAR(password_last_used, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as pwd_last_used_str,
		       access_key_1_id, access_key_1_age_days,
		       TO_CHAR(access_key_1_last_used, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as key_last_used_str,
		       CASE 
		         WHEN i.identity_type = 'IAM_ROLE' THEN
		           NVL((SELECT COUNT(DISTINCT e.source_ip) 
		                FROM nhi_scanner.nhi_events_aws e 
		                WHERE e.identity_arn = i.arn 
		                  AND e.event_name = 'AssumeRole' 
		                  AND e.scan_id = i.scan_id), 0)
		         ELSE 0
		       END as consumer_count
		FROM nhi_scanner.nhi_identities_aws i
		%s
		ORDER BY id DESC
		OFFSET :%d ROWS FETCH NEXT :%d ROWS ONLY`, whereClause, argIdx, argIdx+1)

	args = append(args, filter.Offset, filter.Limit)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		log.Printf("[DB ERROR] Data Query failed: %v", err)
		return nil, 0, fmt.Errorf("query identities: %w", err)
	}
	defer rows.Close()

	var identities []models.Identity
	for rows.Next() {
		var id models.Identity
		var isSecretInt sql.NullInt64
		var isAdminInt sql.NullInt64
		var totalEvents sql.NullInt64

		var arn, name, identityType, classification sql.NullString
		var trustType, trustService, evidence, matchedRules sql.NullString
		var ownerName, ownerType, primaryOwner, createdByName sql.NullString
		var attachedPolicies, ownedCredentialsStr sql.NullString
		var lastActiveStr, createdAtStr sql.NullString

		var groupsList sql.NullString
		var mfaInt sql.NullInt64
		var pwdAgeDays sql.NullInt64
		var consoleAccess sql.NullString
		var pwdLastUsedStr sql.NullString
		var accessKey1ID sql.NullString
		var keyAgeDays sql.NullInt64
		var keyLastUsedStr sql.NullString
		var consumerCount sql.NullInt64

		err := rows.Scan(
			&id.ID, &id.ScanID, &arn, &name, &identityType, &classification,
			&trustType, &trustService, &evidence, &matchedRules,
			&totalEvents, &lastActiveStr, &ownerName, &ownerType,
			&primaryOwner, &createdByName, &attachedPolicies, &isAdminInt,
			&ownedCredentialsStr, &isSecretInt, &createdAtStr, &id.DiscoveredAt,
			&groupsList, &mfaInt, &pwdAgeDays, &consoleAccess,
			&pwdLastUsedStr, &accessKey1ID, &keyAgeDays, &keyLastUsedStr,
			&consumerCount,
		)
		if err != nil {
			log.Printf("[DB ERROR] Scan row failed: %v", err)
			return nil, 0, fmt.Errorf("scan identity row: %w", err)
		}

		id.ARN = arn.String
		id.Name = name.String
		id.IdentityType = identityType.String
		id.Classification = classification.String
		id.TrustType = trustType.String
		id.TrustService = trustService.String
		id.Evidence = evidence.String
		id.MatchedRules = matchedRules.String
		id.OwnerName = ownerName.String
		id.OwnerType = ownerType.String
		id.PrimaryOwner = primaryOwner.String
		id.CreatedByName = createdByName.String

		if attachedPolicies.Valid && attachedPolicies.String != "" {
			parts := strings.Split(attachedPolicies.String, ",")
			seen := make(map[string]bool)
			for _, p := range parts {
				trimmed := strings.TrimSpace(p)
				if trimmed != "" && !seen[trimmed] {
					seen[trimmed] = true
					id.AttachedPolicies = append(id.AttachedPolicies, trimmed)
				}
			}
		}

		if ownedCredentialsStr.Valid && strings.TrimSpace(ownedCredentialsStr.String) != "" {
			var creds []models.OwnedCredential
			if err := json.Unmarshal([]byte(ownedCredentialsStr.String), &creds); err == nil {
				id.OwnedCredentials = creds
			}
		}
		if id.OwnedCredentials == nil {
			id.OwnedCredentials = []models.OwnedCredential{}
		}

		if totalEvents.Valid {
			id.TotalEvents = int(totalEvents.Int64)
		}
		if isSecretInt.Valid {
			id.IsSecret = isSecretInt.Int64 == 1
		}
		if isAdminInt.Valid {
			id.IsAdmin = isAdminInt.Int64 == 1
		}

		if lastActiveStr.Valid && lastActiveStr.String != "" {
			if t, err := time.Parse(time.RFC3339, lastActiveStr.String); err == nil {
				id.LastActive = &t
			}
		}
		if createdAtStr.Valid && createdAtStr.String != "" {
			if t, err := time.Parse(time.RFC3339, createdAtStr.String); err == nil {
				id.CreatedAt = &t
			}
		}

		id.Groups = groupsList.String
		if mfaInt.Valid {
			id.MFAEnabled = mfaInt.Int64 == 1
		}
		if pwdAgeDays.Valid {
			age := int(pwdAgeDays.Int64)
			id.PasswordAgeDays = &age
		}
		id.ConsoleAccess = consoleAccess.String
		if pwdLastUsedStr.Valid && pwdLastUsedStr.String != "" {
			if t, err := time.Parse(time.RFC3339, pwdLastUsedStr.String); err == nil {
				id.ConsoleLastSignIn = &t
			}
		}
		id.AccessKey1ID = accessKey1ID.String
		if keyAgeDays.Valid {
			age := int(keyAgeDays.Int64)
			id.AccessKey1AgeDays = &age
		}
		if keyLastUsedStr.Valid && keyLastUsedStr.String != "" {
			if t, err := time.Parse(time.RFC3339, keyLastUsedStr.String); err == nil {
				id.AccessKey1LastUsed = &t
			}
		}
		if consumerCount.Valid {
			id.ConsumerCount = int(consumerCount.Int64)
		}

		identities = append(identities, id)
	}

	return identities, totalCount, nil
}
