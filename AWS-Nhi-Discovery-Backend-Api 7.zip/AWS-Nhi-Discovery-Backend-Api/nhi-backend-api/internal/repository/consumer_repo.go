package repository

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"time"
)

type RoleConsumer struct {
	CallerARN    string    `json:"caller_arn"`
	CallerType   string    `json:"caller_type"`
	SourceIP     string    `json:"source_ip"`
	UserAgent    string    `json:"user_agent"`
	Region       string    `json:"region"`
	SessionCount int       `json:"session_count"`
	FirstAssumed time.Time `json:"first_assumed"`
	LastAssumed  time.Time `json:"last_assumed"`
}

type ConsumerRepository struct {
	db *OracleDB
}

func NewConsumerRepository(db *OracleDB) *ConsumerRepository {
	return &ConsumerRepository{db: db}
}

func (r *ConsumerRepository) GetRoleConsumers(ctx context.Context, roleARN, scanID string, offset, limit int) ([]RoleConsumer, int, error) {
	consumers := make([]RoleConsumer, 0)
	var totalCount int

	// 1. Total Distinct Consumers Count Query
	countQuery := `
		SELECT COUNT(*) FROM (
			SELECT NVL(caller_arn, 'Unknown Principal'),
			       NVL(caller_type, 'Unknown'),
			       NVL(source_ip, 'N/A'),
			       NVL(user_agent, 'AWS SDK'),
			       NVL(region, 'N/A')
			FROM nhi_scanner.nhi_events_aws
			WHERE identity_arn = :1
			  AND event_name LIKE 'AssumeRole%'
	`
	countArgs := []interface{}{roleARN}
	if scanID != "" {
		countQuery += ` AND scan_id = :2`
		countArgs = append(countArgs, scanID)
	}
	countQuery += ` GROUP BY NVL(caller_arn, 'Unknown Principal'), NVL(caller_type, 'Unknown'), NVL(source_ip, 'N/A'), NVL(user_agent, 'AWS SDK'), NVL(region, 'N/A'))`

	err := r.db.DB.QueryRowContext(ctx, countQuery, countArgs...).Scan(&totalCount)
	if err != nil {
		log.Printf("[DB ERROR] Count consumers: %v", err)
		return consumers, 0, fmt.Errorf("count role consumers: %w", err)
	}

	if totalCount == 0 {
		return consumers, 0, nil
	}

	// 2. Fetch Grouped Consumers with safe Oracle pagination
	var query string
	var queryArgs []interface{}
	if scanID != "" {
		query = `
			SELECT * FROM (
				SELECT a.*, ROWNUM rnum FROM (
					SELECT
						NVL(caller_arn, 'Unknown Principal') AS caller_arn,
						NVL(caller_type, 'Unknown') AS caller_type,
						NVL(source_ip, 'N/A') AS source_ip,
						NVL(user_agent, 'AWS SDK') AS user_agent,
						NVL(region, 'N/A') AS region,
						COUNT(*) AS session_count,
						NVL(TO_CHAR(MIN(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS first_str,
						NVL(TO_CHAR(MAX(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS last_str
					FROM nhi_scanner.nhi_events_aws
					WHERE identity_arn = :1 
					  AND event_name LIKE 'AssumeRole%' 
					  AND scan_id = :2
					GROUP BY NVL(caller_arn, 'Unknown Principal'), NVL(caller_type, 'Unknown'), NVL(source_ip, 'N/A'), NVL(user_agent, 'AWS SDK'), NVL(region, 'N/A')
					ORDER BY MAX(event_time) DESC
				) a WHERE ROWNUM <= :3
			) WHERE rnum > :4
		`
		queryArgs = []interface{}{roleARN, scanID, offset + limit, offset}
	} else {
		query = `
			SELECT * FROM (
				SELECT a.*, ROWNUM rnum FROM (
					SELECT
						NVL(caller_arn, 'Unknown Principal') AS caller_arn,
						NVL(caller_type, 'Unknown') AS caller_type,
						NVL(source_ip, 'N/A') AS source_ip,
						NVL(user_agent, 'AWS SDK') AS user_agent,
						NVL(region, 'N/A') AS region,
						COUNT(*) AS session_count,
						NVL(TO_CHAR(MIN(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS first_str,
						NVL(TO_CHAR(MAX(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS last_str
					FROM nhi_scanner.nhi_events_aws
					WHERE identity_arn = :1 
					  AND event_name LIKE 'AssumeRole%'
					GROUP BY NVL(caller_arn, 'Unknown Principal'), NVL(caller_type, 'Unknown'), NVL(source_ip, 'N/A'), NVL(user_agent, 'AWS SDK'), NVL(region, 'N/A')
					ORDER BY MAX(event_time) DESC
				) a WHERE ROWNUM <= :2
			) WHERE rnum > :3
		`
		queryArgs = []interface{}{roleARN, offset + limit, offset}
	}

	rows, err := r.db.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		log.Printf("[DB ERROR] Query consumers: %v", err)
		return consumers, totalCount, fmt.Errorf("query role consumers: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var c RoleConsumer
		var firstStr, lastStr sql.NullString
		var rnum sql.NullInt64

		if err := rows.Scan(
			&c.CallerARN,
			&c.CallerType,
			&c.SourceIP,
			&c.UserAgent,
			&c.Region,
			&c.SessionCount,
			&firstStr,
			&lastStr,
			&rnum,
		); err != nil {
			log.Printf("[DB ERROR] Scan consumer row: %v", err)
			continue
		}

		if firstStr.Valid && firstStr.String != "" {
			if t, err := time.Parse(time.RFC3339, firstStr.String); err == nil {
				c.FirstAssumed = t
			}
		}
		if lastStr.Valid && lastStr.String != "" {
			if t, err := time.Parse(time.RFC3339, lastStr.String); err == nil {
				c.LastAssumed = t
			}
		}

		consumers = append(consumers, c)
	}

	return consumers, totalCount, nil
}
