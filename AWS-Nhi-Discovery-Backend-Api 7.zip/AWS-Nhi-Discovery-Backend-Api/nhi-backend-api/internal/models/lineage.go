// internal/models/lineage.go
package models

type LineageEdge struct {
	TargetName string `json:"target_name"`
	TargetType string `json:"target_type"`
	RelType    string `json:"rel_type"`
	Direction  string `json:"direction"`
	Via        string `json:"via"`
	IsExternal int    `json:"is_external"`
	Detail     string `json:"detail"`
}
