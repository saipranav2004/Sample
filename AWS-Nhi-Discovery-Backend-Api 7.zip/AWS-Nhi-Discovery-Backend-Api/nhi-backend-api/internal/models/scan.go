package models

import "time"

type Scan struct {
	ScanID          string     `json:"scan_id"`
	AccountID       string     `json:"account_id"`
	TargetName      string     `json:"target_name"`
	TotalIdentities int        `json:"total_identities"`
	TotalEvents     int        `json:"total_events"`
	TotalSecrets    int        `json:"total_secrets"`
	Status          string     `json:"status"`
	ScanStart       time.Time  `json:"scan_start"`
	ScanEnd         *time.Time `json:"scan_end"`
}
