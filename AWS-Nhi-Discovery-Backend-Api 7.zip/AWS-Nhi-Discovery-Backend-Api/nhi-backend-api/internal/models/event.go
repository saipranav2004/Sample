package models

import "time"

type Event struct {
	ID           int        `json:"id"`
	ScanID       string     `json:"scan_id"`
	IdentityName string     `json:"identity_name"`
	IdentityARN  string     `json:"identity_arn"`
	IdentityType string     `json:"identity_type"`
	EventTime    *time.Time `json:"event_time"`
	EventName    string     `json:"event_name"`
	EventSource  string     `json:"event_source"`
	SourceIP     string     `json:"source_ip"`
	UserAgent    string     `json:"user_agent"`
	ReadOnly     string     `json:"read_only"`
	Region       string     `json:"region"`
	DiscoveredAt time.Time  `json:"discovered_at"`
}
