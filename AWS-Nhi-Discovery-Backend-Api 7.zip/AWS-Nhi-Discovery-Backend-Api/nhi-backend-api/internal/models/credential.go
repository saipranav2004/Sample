package models

type FlattenedCredential struct {
	ID              int    `json:"id"`
	IdentityID      int    `json:"identity_id"`
	IdentityARN     string `json:"identity_arn"`
	IdentityName    string `json:"identity_name"`
	IdentityType    string `json:"identity_type"`
	ScanID          string `json:"scan_id"`
	Type            string `json:"type"`
	CredID          string `json:"cred_id"`
	Status          string `json:"status"`
	Severity        string `json:"severity"`
	CreatedAt       string `json:"created_at"`
	ExpiresAt       string `json:"expires_at"`
	LastUsedDate    string `json:"last_used_date"`
	LastUsedService string `json:"last_used_service"`
	Description     string `json:"description"`
}
