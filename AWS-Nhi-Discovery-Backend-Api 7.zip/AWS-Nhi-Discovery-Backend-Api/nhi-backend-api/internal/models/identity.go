// internal/models/identity.go
package models

import "time"

type OwnedCredential struct {
	Type            string `json:"type"`
	ID              string `json:"id,omitempty"`
	Status          string `json:"status"`
	Severity        string `json:"severity,omitempty"`
	CreatedAt       string `json:"created_at,omitempty"`
	LastUsedDate    string `json:"last_used_date,omitempty"`
	LastUsedService string `json:"last_used_service,omitempty"`
	Description     string `json:"description,omitempty"`
}

type Identity struct {
	ID               int               `json:"id"`
	ScanID           string            `json:"scan_id"`
	ARN              string            `json:"arn"`
	Name             string            `json:"name"`
	IdentityType     string            `json:"identity_type"`
	Classification   string            `json:"classification"`
	TrustType        string            `json:"trust_type"`
	TrustService     string            `json:"trust_service"`
	Evidence         string            `json:"evidence"`
	MatchedRules     string            `json:"matched_rules"`
	TotalEvents      int               `json:"total_events"`
	LastActive       *time.Time        `json:"last_active"`
	OwnerName        string            `json:"owner_name"`
	OwnerType        string            `json:"owner_type"`
	PrimaryOwner     string            `json:"primary_owner"`
	CreatedByName    string            `json:"created_by_name"`
	AttachedPolicies []string          `json:"attached_policies"`
	IsAdmin          bool              `json:"is_admin"`
	OwnedCredentials []OwnedCredential `json:"owned_credentials"`
	IsSecret         bool              `json:"is_secret"`
	CreatedAt        *time.Time        `json:"created_at"`
	DiscoveredAt     time.Time         `json:"discovered_at"`

	// ── NHI Posture Fields ──
	Groups             string     `json:"groups"`
	MFAEnabled         bool       `json:"mfa_enabled"`
	PasswordAgeDays    *int       `json:"password_age_days"`
	ConsoleAccess      string     `json:"console_access"`
	ConsoleLastSignIn  *time.Time `json:"console_last_signin"`
	AccessKey1ID       string     `json:"access_key_1_id"`
	AccessKey1AgeDays  *int       `json:"access_key_1_age_days"`
	AccessKey1LastUsed *time.Time `json:"access_key_1_last_used"`

	// ── Role Consumers Count (NEW) ──
	ConsumerCount int `json:"consumer_count"`
}

type DashboardSummary struct {
	TotalIdentities         int            `json:"total_identities"`
	TotalSecrets            int            `json:"total_secrets"`
	TotalOrphaned           int            `json:"total_orphaned"`
	TotalHumans             int            `json:"total_humans"`
	TotalNHIs               int            `json:"total_nhis"`
	TotalHumansWithoutMFA   int            `json:"total_humans_without_mfa"`
	TotalCredentials        int            `json:"total_credentials"`
	ClassificationBreakdown map[string]int `json:"classification_breakdown"`
	CredentialsBreakdown    map[string]int `json:"credentials_breakdown"`

	// ── POSTURE METRICS ──
	TotalNhiAgents      int `json:"total_nhi_agents"`
	TotalNhiCicd        int `json:"total_nhi_cicd"`
	TotalFederated      int `json:"total_federated"`
	TotalAdmin          int `json:"total_admin"`
	TotalStale90Plus    int `json:"total_stale_90plus"`
	TotalInactive30Plus int `json:"total_inactive_30plus"`
}
