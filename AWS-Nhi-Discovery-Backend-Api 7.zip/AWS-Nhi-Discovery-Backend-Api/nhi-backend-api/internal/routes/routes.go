// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler       *handlers.AuthHandler
	DashboardHandler  *handlers.DashboardHandler
	IdentityHandler   *handlers.IdentityHandler
	SecretHandler     *handlers.SecretHandler
	ScanHandler       *handlers.ScanHandler
	EventHandler      *handlers.EventHandler
	CredentialHandler *handlers.CredentialHandler
	LineageHandler    *handlers.LineageHandler
	AuthMiddleware    *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
