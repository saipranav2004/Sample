package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type CredentialService struct {
	repo *repository.CredentialRepository
}

func NewCredentialService(repo *repository.CredentialRepository) *CredentialService {
	return &CredentialService{repo: repo}
}

func (s *CredentialService) ListCredentials(ctx context.Context, filter repository.CredentialFilter) ([]models.FlattenedCredential, int, error) {
	return s.repo.List(ctx, filter)
}
