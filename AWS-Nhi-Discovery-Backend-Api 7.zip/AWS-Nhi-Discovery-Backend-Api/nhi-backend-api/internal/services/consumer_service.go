// internal/services/consumer_service.go

package services

import (
	"context"

	"nhi-backend-api/internal/repository"
)

type ConsumerService struct {
	repo *repository.ConsumerRepository
}

func NewConsumerService(repo *repository.ConsumerRepository) *ConsumerService {
	return &ConsumerService{repo: repo}
}

func (s *ConsumerService) GetRoleConsumers(ctx context.Context, roleARN, scanID string, offset, limit int) ([]repository.RoleConsumer, int, error) {
	return s.repo.GetRoleConsumers(ctx, roleARN, scanID, offset, limit)
}
