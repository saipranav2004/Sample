// internal/services/lineage_service.go
package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type LineageService struct {
	lineageRepo *repository.LineageRepository
}

func NewLineageService(lineageRepo *repository.LineageRepository) *LineageService {
	return &LineageService{lineageRepo: lineageRepo}
}

func (s *LineageService) GetServiceAccess(ctx context.Context, filter repository.LineageFilter) ([]models.LineageEdge, int, error) {
	return s.lineageRepo.GetServiceAccess(ctx, filter)
}
