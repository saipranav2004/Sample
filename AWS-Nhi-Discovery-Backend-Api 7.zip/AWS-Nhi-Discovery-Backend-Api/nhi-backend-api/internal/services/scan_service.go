package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type ScanService struct {
	scanRepo *repository.ScanRepository
}

func NewScanService(scanRepo *repository.ScanRepository) *ScanService {
	return &ScanService{scanRepo: scanRepo}
}

func (s *ScanService) ListScans(ctx context.Context, offset, limit int) ([]models.Scan, int, error) {
	return s.scanRepo.List(ctx, offset, limit)
}
