package services

import (
	"context"
	"errors"
	"fmt"

	"golang.org/x/crypto/bcrypt"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/pkg/jwt"
)

type AuthService struct {
	userRepo *repository.UserRepository
	jwtCfg   config.JWTConfig
}

func NewAuthService(userRepo *repository.UserRepository, jwtCfg config.JWTConfig) *AuthService {
	return &AuthService{
		userRepo: userRepo,
		jwtCfg:   jwtCfg,
	}
}

// Login validates user credentials and issues a JWT token
func (s *AuthService) Login(ctx context.Context, req models.LoginRequest) (*models.LoginResponse, error) {
	user, err := s.userRepo.GetByEmail(ctx, req.Email)
	if err != nil {
		return nil, fmt.Errorf("auth error: %w", err)
	}
	if user == nil {
		return nil, errors.New("please provide email and password")
	}

	// Verify hashed password
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return nil, errors.New("invalid email or password")
	}

	// Generate JWT Token
	token, err := jwt.GenerateToken(
		user.ID,
		user.Email,
		user.Role,
		user.Team,
		s.jwtCfg.Secret,
		s.jwtCfg.ExpiryHours,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to generate token: %w", err)
	}

	return &models.LoginResponse{
		Token:     token,
		User:      *user,
		ExpiresIn: s.jwtCfg.ExpiryHours * 3600,
	}, nil
}

// GetUserByID fetches profile details for /api/auth/me
func (s *AuthService) GetUserByID(ctx context.Context, id int) (*models.User, error) {
	return s.userRepo.GetByID(ctx, id)
}
