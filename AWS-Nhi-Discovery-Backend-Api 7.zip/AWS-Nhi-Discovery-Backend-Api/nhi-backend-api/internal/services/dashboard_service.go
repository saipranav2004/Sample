// internal/services/dashboard_service.go
package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type DashboardService struct {
	dashboardRepo *repository.DashboardRepository
	identityRepo  *repository.IdentityRepository
}

func NewDashboardService(dashboardRepo *repository.DashboardRepository, identityRepo *repository.IdentityRepository) *DashboardService {
	return &DashboardService{
		dashboardRepo: dashboardRepo,
		identityRepo:  identityRepo,
	}
}

// GetSummary now accepts an optional scanID
func (s *DashboardService) GetSummary(ctx context.Context, scanID string) (*models.DashboardSummary, error) {
	return s.dashboardRepo.GetSummary(ctx, scanID)
}

// GetMyResources retrieves resources scoped dynamically to user email and optionally scanID
func (s *DashboardService) GetMyResources(ctx context.Context, userEmail string, offset, limit int, scanID string) ([]models.Identity, int, error) {
	filter := repository.IdentityFilter{
		OwnerName: userEmail,
		Offset:    offset,
		Limit:     limit,
		ScanID:    scanID,
	}
	return s.identityRepo.List(ctx, filter)
}
