package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentityService struct {
	identityRepo *repository.IdentityRepository
}

func NewIdentityService(identityRepo *repository.IdentityRepository) *IdentityService {
	return &IdentityService{identityRepo: identityRepo}
}

func (s *IdentityService) ListIdentities(ctx context.Context, filter repository.IdentityFilter) ([]models.Identity, int, error) {
	return s.identityRepo.List(ctx, filter)
}

func (s *IdentityService) ListSecrets(ctx context.Context, search string, offset, limit int) ([]models.Identity, int, error) {
	isSecret := true
	filter := repository.IdentityFilter{
		Search:   search,
		IsSecret: &isSecret,
		Offset:   offset,
		Limit:    limit,
	}
	return s.identityRepo.List(ctx, filter)
}
