package middleware

import (
	"net/http"

	"github.com/rs/cors"

	"nhi-backend-api/internal/config"
)

// SetupCORS configures cross-origin resource sharing for the React frontend
func SetupCORS(cfg config.CORSConfig) func(http.Handler) http.Handler {
	origins := cfg.AllowedOrigins
	if len(origins) == 0 {
		origins = []string{"http://localhost:3000", "http://localhost:5173"}
	}

	c := cors.New(cors.Options{
		AllowedOrigins:   origins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Authorization", "Content-Type", "Accept"},
		AllowCredentials: true,
	})

	return c.Handler
}
