package middleware

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/pkg/jwt"
)

type contextKey string

const UserClaimsKey contextKey = "userClaims"

type AuthMiddleware struct {
	jwtCfg config.JWTConfig
}

func NewAuthMiddleware(jwtCfg config.JWTConfig) *AuthMiddleware {
	return &AuthMiddleware{jwtCfg: jwtCfg}
}

// Authenticate verifies the incoming Bearer JWT token
func (m *AuthMiddleware) Authenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			respondUnauthorized(w, "Missing Authorization header")
			return
		}

		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			respondUnauthorized(w, "Invalid Authorization format. Expected 'Bearer <token>'")
			return
		}

		tokenString := parts[1]
		claims, err := jwt.ValidateToken(tokenString, m.jwtCfg.Secret)
		if err != nil {
			respondUnauthorized(w, "Invalid or expired token")
			return
		}

		// Inject authenticated claims into request context
		ctx := context.WithValue(r.Context(), UserClaimsKey, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func respondUnauthorized(w http.ResponseWriter, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusUnauthorized)
	json.NewEncoder(w).Encode(models.APIResponse{
		Success: false,
		Message: msg,
		Error:   "UNAUTHORIZED",
	})
}

// GetClaims retrieves user claims from context
func GetClaims(r *http.Request) *jwt.CustomClaims {
	claims, ok := r.Context().Value(UserClaimsKey).(*jwt.CustomClaims)
	if !ok {
		return nil
	}
	return claims
}
