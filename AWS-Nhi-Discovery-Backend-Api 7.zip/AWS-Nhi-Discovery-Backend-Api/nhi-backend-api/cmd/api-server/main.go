package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize Oracle Database
	db, err := repository.NewOracleDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:       authHandler,
		DashboardHandler:  dashboardHandler,
		IdentityHandler:   identityHandler,
		SecretHandler:     secretHandler,
		ScanHandler:       scanHandler,
		AuthMiddleware:    authMiddleware,
		EventHandler:      eventHandler,
		LineageHandler:    lineageHandler,
		CredentialHandler: credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
