package routes

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	handlerdashboard "nhi-backend-api/internal/handlers/dashboard"
	handlerinventory "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	// Auth
	AuthHandler    *handlers.AuthHandler
	AuthMiddleware *middleware.AuthMiddleware

	// Dashboard
	DashboardHandler                *handlers.DashboardHandler
	DiscoveryHandler                *handlerdashboard.DiscoveryHandler
	PrivilegeDistributionHandler    *handlerdashboard.PrivilegeDistributionHandler
	OwnershipCoverageHandler        *handlerdashboard.OwnershipCoverageHandler
	FiltersHandler                  *handlerdashboard.FiltersHandler
	DashboardSummaryHandler         *handlerdashboard.SummaryHandler
	IdentitiesByTypeHandler         *handlerdashboard.IdentitiesByTypeHandler
	IdentitiesByClassHandler        *handlerdashboard.IdentitiesByClassHandler
	IdentitiesByAccountHandler      *handlerdashboard.IdentitiesByAccountHandler
	IdentitiesByRegionHandler       *handlerdashboard.IdentitiesByRegionHandler
	CredentialsByTypeHandler        *handlerdashboard.CredentialsByTypeHandler
	CredentialHygieneSummaryHandler *handlerdashboard.CredentialHygieneSummaryHandler
	IdentitiesExposureHandler 		*handlerdashboard.IdentitiesExposureHandler 
	// Identities
	LineageHandler *handlers.LineageHandler

	// Legacy
	// SecretHandler     *handlers.SecretHandler
	ScanHandler       *handlers.ScanHandler
	EventHandler      *handlers.EventHandler
	CredentialHandler *handlers.CredentialHandler

	// Inventory — Credentials
	InventoryCredentialHandler         *handlerinventory.CredentialHandler
	InventoryCredentialDetailsHandler  *handlerinventory.CredentialDetailsHandler
	InventoryCredentialCountHandler    *handlerinventory.CredentialCountHandler
	InventoryCredentialHygieneHandler  *handlerinventory.CredentialHygieneHandler
	InventoryTrustPolicyHandler        *handlerinventory.TrustPolicyHandler
	InventoryAttachedPoliciesHandler   *handlerinventory.AttachedPoliciesHandler
	InventoryCredentialExpiringHandler *handlerinventory.CredentialExpiringHandler
	InventoryCredentialStaleHandler    *handlerinventory.CredentialStaleHandler
	InventoryCredentialExportHandler   *handlerinventory.CredentialExportHandler
	InventoryCredentialUpdateHandler   *handlerinventory.UpdateCredentialHandler

	IdentityListHandler           *handlerinventory.IdentityListHandler
	IdentityDetailHandler         *handlerinventory.IdentityDetailHandler
	IdentityAttributesHandler     *handlerinventory.IdentityAttributesHandler
	IdentityTimelineHandler       *handlerinventory.IdentityTimelineHandler
	IdentityGroupedByClassHandler *handlerinventory.IdentityGroupedByClassHandler
	IdentityDormantHandler        *handlerinventory.IdentityDormantHandler
	IdentityExportHandler         *handlerinventory.IdentityExportHandler
	UpdateIdentityHandler         *handlerinventory.UpdateIdentityHandler
	IdentityCountsHandler         *handlerinventory.IdentityCountsHandler
	IdentitySearchHandler         *handlerinventory.SearchHandler
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// ── Global middleware ─────────────────────────────────────────────────
	r.Use(middleware.RequestLogger)

	// ── Custom 404 & 405 — always return JSON, never plain text ──────────
	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusNotFound)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "route not found: " + r.Method + " " + r.URL.Path,
		})
	})

	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusMethodNotAllowed)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "method not allowed: " + r.Method + " " + r.URL.Path,
		})
	})

	// ── Health check ──────────────────────────────────────────────────────
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	// ─────────────────────────────────────────────────────────────────────
	// /api/v1 — versioned subrouter (auth protected)
	// ─────────────────────────────────────────────────────────────────────
	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.AuthMiddleware.Authenticate)

	// Dashboard
	v1.HandleFunc("/dashboard/summary", h.DashboardSummaryHandler.Summary).Methods("GET")
	v1.HandleFunc("/dashboard/identities/by-type", h.IdentitiesByTypeHandler.ByType).Methods("GET")
	v1.HandleFunc("/dashboard/identities/by-class", h.IdentitiesByClassHandler.ByClass).Methods("GET")
	v1.HandleFunc("/dashboard/identities/by-account", h.IdentitiesByAccountHandler.ByAccount).Methods("GET")
	v1.HandleFunc("/dashboard/identities/by-region", h.IdentitiesByRegionHandler.ByRegion).Methods("GET")
	v1.HandleFunc("/dashboard/credentials/by-type", h.CredentialsByTypeHandler.ByType).Methods("GET")
	v1.HandleFunc("/dashboard/credentials/hygiene", h.CredentialHygieneSummaryHandler.Hygiene).Methods("GET")
	v1.HandleFunc("/dashboard/identities/exposure", h.IdentitiesExposureHandler.Exposure).Methods("GET") // TODO: not built yet
	v1.HandleFunc("/dashboard/recent-discoveries",
		h.DiscoveryHandler.RecentDiscoveries).Methods("GET")
	v1.HandleFunc("/dashboard/credentials/privilege-distribution",
		h.PrivilegeDistributionHandler.PrivilegeDistribution).Methods("GET")
	v1.HandleFunc("/dashboard/ownership-coverage",
		h.OwnershipCoverageHandler.OwnershipCoverage).Methods("GET")
	v1.HandleFunc("/dashboard/filters",
		h.FiltersHandler.Filters).Methods("GET")

	// ── Inventory — Credentials ───────────────────────────────────────────
	// ⚠️ ORDER MATTERS: static routes first, dynamic {id} routes last

	v1.HandleFunc("/inventory/credentials/counts",
		h.InventoryCredentialCountHandler.Counts).Methods("GET")
	v1.HandleFunc("/inventory/credentials/expiring",
		h.InventoryCredentialExpiringHandler.Expiring).Methods("GET")
	v1.HandleFunc("/inventory/credentials/stale",
		h.InventoryCredentialStaleHandler.Stale).Methods("GET")
	v1.HandleFunc("/inventory/credentials/export",
		h.InventoryCredentialExportHandler.Export).Methods("GET")
	v1.HandleFunc("/inventory/credentials/{id}",
		h.InventoryCredentialUpdateHandler.UpdateCredential).Methods("PATCH")

	v1.HandleFunc("/inventory/identities/counts", h.IdentityCountsHandler.Counts).Methods("GET")
	v1.HandleFunc("/inventory/identities/export", h.IdentityExportHandler.Export).Methods("GET")
	v1.HandleFunc("/inventory/identities/dormant", h.IdentityDormantHandler.Dormant).Methods("GET")
	v1.HandleFunc("/inventory/identities/grouped-by-class", h.IdentityGroupedByClassHandler.GroupedByClass).Methods("GET")
	v1.HandleFunc("/inventory/identities", h.IdentityListHandler.List).Methods("GET")
	v1.HandleFunc("/inventory/identities/{id}", h.IdentityDetailHandler.Detail).Methods("GET")
	v1.HandleFunc("/inventory/identities/{id}", h.UpdateIdentityHandler.UpdateIdentity).Methods("PATCH")
	v1.HandleFunc("/inventory/identities/{id}/attributes", h.IdentityAttributesHandler.Attributes).Methods("GET")
	v1.HandleFunc("/inventory/identities/{id}/timeline", h.IdentityTimelineHandler.Timeline).Methods("GET")
	v1.HandleFunc("/inventory/search", h.IdentitySearchHandler.Search).Methods("GET")

	// 2. Sub-resource routes — /{id}/something (before plain /{id})
	v1.HandleFunc("/inventory/credentials/{id}/hygiene",
		h.InventoryCredentialHygieneHandler.Hygiene).Methods("GET")
	v1.HandleFunc("/inventory/credentials/{id}/trust-policy",
		h.InventoryTrustPolicyHandler.TrustPolicy).Methods("GET")
	v1.HandleFunc("/inventory/credentials/{id}/policies",
		h.InventoryAttachedPoliciesHandler.Policies).Methods("GET")

	// 3. Single resource — /{id}
	v1.HandleFunc("/inventory/credentials/{id}",
		h.InventoryCredentialDetailsHandler.Detail).Methods("GET")

	// 4. Collection — /
	v1.HandleFunc("/inventory/credentials",
		h.InventoryCredentialHandler.List).Methods("GET")

	// ─────────────────────────────────────────────────────────────────────
	// /api — unversioned subrouter
	// ─────────────────────────────────────────────────────────────────────
	api := r.PathPrefix("/api").Subrouter()
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// Dashboard
	protected.HandleFunc("/dashboard/summary",
		h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/identities/by-type",
		h.IdentitiesByTypeHandler.ByType).Methods("GET")
	protected.HandleFunc("/dashboard/identities/by-class",
		h.IdentitiesByClassHandler.ByClass).Methods("GET")
	protected.HandleFunc("/dashboard/identities/by-account",
		h.IdentitiesByAccountHandler.ByAccount).Methods("GET")
	protected.HandleFunc("/dashboard/identities/by-region",
		h.IdentitiesByRegionHandler.ByRegion).Methods("GET")
	protected.HandleFunc("/dashboard/credentials/by-type",
		h.CredentialsByTypeHandler.ByType).Methods("GET")
	protected.HandleFunc("/dashboard/credentials/hygiene",
		h.CredentialHygieneSummaryHandler.Hygiene).Methods("GET")
 	protected.HandleFunc("/dashboard/identities/exposure", h.IdentitiesExposureHandler.Exposure).Methods("GET") // TODO: not built yet
	protected.HandleFunc("/dashboard/my-resources",
		h.DashboardHandler.MyResources).Methods("GET")
	protected.HandleFunc("/dashboard/recent-discoveries",
		h.DiscoveryHandler.RecentDiscoveries).Methods("GET")
	protected.HandleFunc("/dashboard/credentials/privilege-distribution",
		h.PrivilegeDistributionHandler.PrivilegeDistribution).Methods("GET")
	protected.HandleFunc("/dashboard/ownership-coverage",
		h.OwnershipCoverageHandler.OwnershipCoverage).Methods("GET")
	protected.HandleFunc("/dashboard/filters",
		h.FiltersHandler.Filters).Methods("GET")

	// ── Inventory — Credentials ───────────────────────────────────────────
	// ⚠️ Same order rule: static → sub-resource → single → collection

	// 1. Static
	protected.HandleFunc("/inventory/credentials/counts",
		h.InventoryCredentialCountHandler.Counts).Methods("GET")
	protected.HandleFunc("/inventory/credentials/expiring",
		h.InventoryCredentialExpiringHandler.Expiring).Methods("GET")
	protected.HandleFunc("/inventory/credentials/stale",
		h.InventoryCredentialStaleHandler.Stale).Methods("GET")
	protected.HandleFunc("/inventory/credentials/export",
		h.InventoryCredentialExportHandler.Export).Methods("GET")
	protected.HandleFunc("/inventory/credentials/{id}",
		h.InventoryCredentialUpdateHandler.UpdateCredential).Methods("PATCH")

	protected.HandleFunc("/inventory/identities/counts", h.IdentityCountsHandler.Counts).Methods("GET")
	protected.HandleFunc("/inventory/identities/export", h.IdentityExportHandler.Export).Methods("GET")
	protected.HandleFunc("/inventory/identities/dormant", h.IdentityDormantHandler.Dormant).Methods("GET")
	protected.HandleFunc("/inventory/identities/grouped-by-class", h.IdentityGroupedByClassHandler.GroupedByClass).Methods("GET")
	protected.HandleFunc("/inventory/identities", h.IdentityListHandler.List).Methods("GET")
	protected.HandleFunc("/inventory/identities/{id}", h.IdentityDetailHandler.Detail).Methods("GET")
	protected.HandleFunc("/inventory/identities/{id}", h.UpdateIdentityHandler.UpdateIdentity).Methods("PATCH")
	protected.HandleFunc("/inventory/identities/{id}/attributes", h.IdentityAttributesHandler.Attributes).Methods("GET")
	protected.HandleFunc("/inventory/identities/{id}/timeline", h.IdentityTimelineHandler.Timeline).Methods("GET")
	protected.HandleFunc("/inventory/search", h.IdentitySearchHandler.Search).Methods("GET")

	// 2. Sub-resource
	protected.HandleFunc("/inventory/credentials/{id}/hygiene",
		h.InventoryCredentialHygieneHandler.Hygiene).Methods("GET")
	protected.HandleFunc("/inventory/credentials/{id}/trust-policy",
		h.InventoryTrustPolicyHandler.TrustPolicy).Methods("GET")
	protected.HandleFunc("/inventory/credentials/{id}/policies",
		h.InventoryAttachedPoliciesHandler.Policies).Methods("GET")

	// 3. Single resource
	protected.HandleFunc("/inventory/credentials/{id}",
		h.InventoryCredentialDetailsHandler.Detail).Methods("GET")

	// 4. Collection
	protected.HandleFunc("/inventory/credentials",
		h.InventoryCredentialHandler.List).Methods("GET")

	// Legacy
	// protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}