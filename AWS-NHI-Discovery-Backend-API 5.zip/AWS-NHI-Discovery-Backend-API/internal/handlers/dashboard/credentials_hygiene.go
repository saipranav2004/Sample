package dashboard

import (
	"net/http"

	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type CredentialHygieneSummaryHandler struct {
	service *svcdashboard.CredentialHygieneSummaryService
}

func NewCredentialHygieneSummaryHandler(service *svcdashboard.CredentialHygieneSummaryService) *CredentialHygieneSummaryHandler {
	return &CredentialHygieneSummaryHandler{service: service}
}

// Hygiene handles GET /dashboard/credentials/hygiene?account_id=...
func (h *CredentialHygieneSummaryHandler) Hygiene(w http.ResponseWriter, r *http.Request) {
	accountID := r.URL.Query().Get("account_id")

	resp, err := h.service.GetHygieneSummary(r.Context(), accountID)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "failed to fetch credential hygiene summary: " + err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, resp)
}