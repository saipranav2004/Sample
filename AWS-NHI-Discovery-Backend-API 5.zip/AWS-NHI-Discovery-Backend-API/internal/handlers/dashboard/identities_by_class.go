package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	modelsdashboard "nhi-backend-api/internal/models"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type IdentitiesByClassHandler struct {
	service *svcdashboard.IdentitiesByClassService
}

func NewIdentitiesByClassHandler(service *svcdashboard.IdentitiesByClassService) *IdentitiesByClassHandler {
	return &IdentitiesByClassHandler{service: service}
}

func (h *IdentitiesByClassHandler) ByClass(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	filter := modelsdashboard.IdentityByClassFilter{
		AccountID: q.Get("account_id"),
		Region:    q.Get("region"),
	}

	if filter.AccountID != "" {
		ok, err := h.service.AccountIDExists(ctx, filter.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}

	if filter.Region != "" {
		ok, err := h.service.RegionExists(ctx, filter.Region)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid region", Error: "region does not exist"})
			return
		}
	}

	result, err := h.service.ByClass(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load identities by class", Error: err.Error()})
		return
	}

	sendJSON(w, http.StatusOK, result)
}