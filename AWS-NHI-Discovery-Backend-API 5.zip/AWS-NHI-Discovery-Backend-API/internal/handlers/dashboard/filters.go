package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type FiltersHandler struct {
	service *svcdashboard.FiltersService
}

func NewFiltersHandler(service *svcdashboard.FiltersService) *FiltersHandler {
	return &FiltersHandler{service: service}
}

// Filters handles GET /dashboard/filters
// No query parameters.
func (h *FiltersHandler) Filters(w http.ResponseWriter, r *http.Request) {
	result, err := h.service.GetFilters(r.Context())
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load dashboard filters",
			Error:   err.Error(),
		})
		return
	}

	// Returned without the success/data envelope, exactly as in the API document.
	sendJSON(w, http.StatusOK, result)
}