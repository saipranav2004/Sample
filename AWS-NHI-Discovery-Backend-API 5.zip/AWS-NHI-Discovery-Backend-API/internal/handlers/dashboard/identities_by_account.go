package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type IdentitiesByAccountHandler struct {
	service *svcdashboard.IdentitiesByAccountService
}

func NewIdentitiesByAccountHandler(service *svcdashboard.IdentitiesByAccountService) *IdentitiesByAccountHandler {
	return &IdentitiesByAccountHandler{service: service}
}

func (h *IdentitiesByAccountHandler) ByAccount(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	filter := repodashboard.IdentitiesByAccountFilter{
		Region:       query.Get("region"),
		IdentityType: query.Get("identity_type"),
	}

	result, err := h.service.Breakdown(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity breakdown by account",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}