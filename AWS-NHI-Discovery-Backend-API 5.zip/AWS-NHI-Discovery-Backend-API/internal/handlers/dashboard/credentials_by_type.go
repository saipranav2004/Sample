package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type CredentialsByTypeHandler struct {
	service *svcdashboard.CredentialsByTypeService
}

func NewCredentialsByTypeHandler(service *svcdashboard.CredentialsByTypeService) *CredentialsByTypeHandler {
	return &CredentialsByTypeHandler{service: service}
}

func (h *CredentialsByTypeHandler) ByType(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	filter := repodashboard.CredentialsByTypeFilter{
		AccountID: query.Get("account_id"),
		Region:    query.Get("region"),
		Status:    query.Get("status"),
	}

	result, err := h.service.Breakdown(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load credential breakdown by type",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}