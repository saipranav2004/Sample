package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	modelsdashboard "nhi-backend-api/internal/models"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type IdentitiesByTypeHandler struct {
	service *svcdashboard.IdentitiesByTypeService
}

func NewIdentitiesByTypeHandler(service *svcdashboard.IdentitiesByTypeService) *IdentitiesByTypeHandler {
	return &IdentitiesByTypeHandler{service: service}
}

func (h *IdentitiesByTypeHandler) ByType(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	filter := modelsdashboard.IdentityByTypeFilter{
		AccountID:       q.Get("account_id"),
		Region:          q.Get("region"),
		Status:          q.Get("status"),
		FunctionalClass: q.Get("functional_class"),
	}

	if filter.AccountID != "" {
		ok, err := h.service.AccountIDExists(ctx, filter.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}

	if filter.Region != "" {
		ok, err := h.service.RegionExists(ctx, filter.Region)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid region", Error: "region does not exist"})
			return
		}
	}

	if filter.Status != "" {
		ok, err := h.service.StatusExists(ctx, filter.Status)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate status", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid status", Error: "status does not exist"})
			return
		}
	}

	if filter.FunctionalClass != "" {
		ok, err := h.service.FunctionalClassExists(ctx, filter.FunctionalClass)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate functional_class", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid functional_class", Error: "functional_class does not exist"})
			return
		}
	}

	result, err := h.service.ByType(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load identities by type", Error: err.Error()})
		return
	}

	sendJSON(w, http.StatusOK, result)
}