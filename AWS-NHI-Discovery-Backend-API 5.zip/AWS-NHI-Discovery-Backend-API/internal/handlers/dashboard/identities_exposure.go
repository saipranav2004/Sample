package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	modelsdashboard "nhi-backend-api/internal/models"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type IdentitiesExposureHandler struct {
	service *svcdashboard.IdentitiesExposureService
}

func NewIdentitiesExposureHandler(service *svcdashboard.IdentitiesExposureService) *IdentitiesExposureHandler {
	return &IdentitiesExposureHandler{service: service}
}

func (h *IdentitiesExposureHandler) Exposure(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	filter := modelsdashboard.IdentityExposureFilter{
		AccountID: q.Get("account_id"),
	}

	if filter.AccountID != "" {
		ok, err := h.service.AccountIDExists(ctx, filter.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}

	result, err := h.service.Exposure(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load exposure summary", Error: err.Error()})
		return
	}

	sendJSON(w, http.StatusOK, result)
}