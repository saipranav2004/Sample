package dashboard

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

const (
	defaultDiscoveryHours = 24
	maxDiscoveryHours     = 24 * 365
	defaultDiscoveryLimit = 50
	maxDiscoveryLimit     = 500
)

type DiscoveryHandler struct {
	discoveryService *svcdashboard.DiscoveryService
}

func NewDiscoveryHandler(discoveryService *svcdashboard.DiscoveryService) *DiscoveryHandler {
	return &DiscoveryHandler{discoveryService: discoveryService}
}

func (h *DiscoveryHandler) RecentDiscoveries(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	filter := repodashboard.DiscoveryFilter{
		Hours: defaultDiscoveryHours,
		Type:  repodashboard.DiscoveryTypeBoth,
		Event: repodashboard.DiscoveryEventBoth,
		Limit: defaultDiscoveryLimit,
	}

	if v := strings.TrimSpace(q.Get("hours")); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > maxDiscoveryHours {
			badRequest(w, fmt.Sprintf("hours must be a number between 1 and %d", maxDiscoveryHours))
			return
		}
		filter.Hours = n
	}

	if v := strings.TrimSpace(q.Get("limit")); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > maxDiscoveryLimit {
			badRequest(w, fmt.Sprintf("limit must be a number between 1 and %d", maxDiscoveryLimit))
			return
		}
		filter.Limit = n
	}

	if v := strings.ToLower(strings.TrimSpace(q.Get("type"))); v != "" {
		switch v {
		case repodashboard.DiscoveryTypeIdentities, repodashboard.DiscoveryTypeCredentials, repodashboard.DiscoveryTypeBoth:
			filter.Type = v
		default:
			badRequest(w, "type must be one of: identities, credentials, both")
			return
		}
	}

	if v := strings.ToLower(strings.TrimSpace(q.Get("event"))); v != "" {
		switch v {
		case repodashboard.DiscoveryEventNew, repodashboard.DiscoveryEventRemoved, repodashboard.DiscoveryEventBoth:
			filter.Event = v
		default:
			badRequest(w, "event must be one of: new, removed, both")
			return
		}
	}

	result, err := h.discoveryService.GetRecentDiscoveries(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load recent discoveries",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}

func badRequest(w http.ResponseWriter, msg string) {
	sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: msg})
}

func sendJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}