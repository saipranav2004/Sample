package inventory

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityCountsHandler struct {
	service *svcinventory.IdentityCountsService
}

func NewIdentityCountsHandler(service *svcinventory.IdentityCountsService) *IdentityCountsHandler {
	return &IdentityCountsHandler{service: service}
}

func (h *IdentityCountsHandler) Counts(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	filter := repoinventory.IdentityCountsFilter{
		AccountID:       query.Get("account_id"),
		Region:          query.Get("region"),
		FunctionalClass: query.Get("functional_class"),
	}

	result, err := h.service.Counts(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity counts",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}