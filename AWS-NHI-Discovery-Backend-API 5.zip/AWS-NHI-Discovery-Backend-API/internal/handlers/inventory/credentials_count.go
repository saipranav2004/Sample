package inventory

import (
	"net/http"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

// CredentialCountHandler handles GET /api/v1/inventory/credentials/counts
type CredentialCountHandler struct {
	service *svcinventory.CredentialCountService
}

func NewCredentialCountHandler(
	service *svcinventory.CredentialCountService,
) *CredentialCountHandler {
	return &CredentialCountHandler{service: service}
}

// Counts handles GET /api/v1/inventory/credentials/counts
func (h *CredentialCountHandler) Counts(
	w http.ResponseWriter,
	r *http.Request,
) {
	q := r.URL.Query()

	filter := inventorymodels.CredentialCountFilter{
		AccountID: strings.TrimSpace(q.Get("account_id")),
		Region:    strings.TrimSpace(q.Get("region")),
	}

	result, err := h.service.GetCounts(r.Context(), filter)
	if err != nil {
		// Validation errors → 400 Bad Request
		if strings.Contains(err.Error(), "validation:") {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": strings.Replace(err.Error(), "validation: ", "", 1),
			})
			return
		}
		// DB/server errors → 500
		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Failed to fetch credential counts",
			"error":   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}