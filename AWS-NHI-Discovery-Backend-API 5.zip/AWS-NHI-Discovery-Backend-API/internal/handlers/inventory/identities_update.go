package inventory

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/models"
	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type UpdateIdentityHandler struct {
	service *svcinventory.UpdateIdentityService
}

func NewUpdateIdentityHandler(service *svcinventory.UpdateIdentityService) *UpdateIdentityHandler {
	return &UpdateIdentityHandler{service: service}
}

func (h *UpdateIdentityHandler) UpdateIdentity(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]

	if !isValidIdentityUUID(id) {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid id",
			Error:   "id must be a valid UUID",
		})
		return
	}

	var req modelsinventory.UpdateIdentityRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request body",
			Error:   err.Error(),
		})
		return
	}

	result, err := h.service.Update(r.Context(), id, req)
	if err != nil {
		switch {
		case errors.Is(err, repoinventory.ErrIdentityNotFound):
			sendJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false,
				Message: "identity not found",
				Error:   "no identity exists with the given id",
			})
		case errors.Is(err, repoinventory.ErrNoFieldsToUpdate):
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid request",
				Error:   "at least one field must be provided to update",
			})
		default:
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{
				Success: false,
				Message: "failed to update identity",
				Error:   err.Error(),
			})
		}
		return
	}

	sendJSON(w, http.StatusOK, result)
}