package inventory

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/models"
	modelsinventory "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

const (
	maxIdentityListLimit = 200
	maxIdentityListPage  = 1_000_000
)

var identitySortFields = map[string]bool{
	"id": true, "name": true, "identity_type": true, "functional_class": true,
	"account_id": true, "region": true, "status": true,
	"created_at_aws": true, "last_seen_at": true, "last_activity_at": true,
}

type IdentityListHandler struct {
	service *svcinventory.IdentityListService
}

func NewIdentityListHandler(service *svcinventory.IdentityListService) *IdentityListHandler {
	return &IdentityListHandler{service: service}
}

func (h *IdentityListHandler) List(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	page := 1
	if v := q.Get("page"); v != "" {
		p, err := strconv.Atoi(v)
		if err != nil || p < 1 || p > maxIdentityListPage {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid page",
				Error:   "page must be a positive integer",
			})
			return
		}
		page = p
	}

	limit := 20
	if v := q.Get("limit"); v != "" {
		l, err := strconv.Atoi(v)
		if err != nil || l < 1 || l > maxIdentityListLimit {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid limit",
				Error:   fmt.Sprintf("limit must be between 1 and %d", maxIdentityListLimit),
			})
			return
		}
		limit = l
	}

	sortBy := q.Get("sort_by")
	if sortBy != "" && !identitySortFields[sortBy] {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid sort_by",
			Error:   "unsupported sort_by field",
		})
		return
	}

	sortOrder := strings.ToLower(q.Get("sort_order"))
	if sortOrder != "" && sortOrder != "asc" && sortOrder != "desc" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid sort_order",
			Error:   "sort_order must be asc or desc",
		})
		return
	}

	var isPublic *bool
	if v := q.Get("is_public"); v != "" {
		b, err := strconv.ParseBool(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid is_public",
				Error:   "is_public must be true or false",
			})
			return
		}
		isPublic = &b
	}

	var lastActiveBefore *time.Time
	if v := q.Get("last_active_before"); v != "" {
		t, err := parseIdentityDate(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid last_active_before",
				Error:   "last_active_before must be RFC3339 or YYYY-MM-DD",
			})
			return
		}
		lastActiveBefore = &t
	}

	filter := modelsinventory.IdentityListFilter{
		Page:             page,
		Limit:            limit,
		SortBy:           sortBy,
		SortOrder:        sortOrder,
		Search:           q.Get("search"),
		IdentityType:     q.Get("identity_type"),
		FunctionalClass:  q.Get("functional_class"),
		AccountID:        q.Get("account_id"),
		Region:           q.Get("region"),
		Status:           q.Get("status"),
		Owner:            q.Get("owner"),
		Environment:      q.Get("environment"),
		IsPublic:         isPublic,
		LastActiveBefore: lastActiveBefore,
	}

	if filter.IdentityType != "" {
		exists, err := h.service.IdentityTypeExists(ctx, filter.IdentityType)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate identity_type", Error: err.Error()})
			return
		}
		if !exists {
			values, _ := h.service.ListIdentityTypes(ctx)
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false, "message": "invalid identity_type", "error": "identity_type does not exist", "valid_values": values,
			})
			return
		}
	}

	if filter.AccountID != "" {
		exists, err := h.service.AccountIDExists(ctx, filter.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !exists {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}

	if filter.Region != "" {
		exists, err := h.service.RegionExists(ctx, filter.Region)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
			return
		}
		if !exists {
			values, _ := h.service.ListRegions(ctx)
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false, "message": "invalid region", "error": "region does not exist", "valid_values": values,
			})
			return
		}
	}

	if filter.Status != "" {
		exists, err := h.service.StatusExists(ctx, filter.Status)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate status", Error: err.Error()})
			return
		}
		if !exists {
			values, _ := h.service.ListStatuses(ctx)
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false, "message": "invalid status", "error": "status does not exist", "valid_values": values,
			})
			return
		}
	}

	result, err := h.service.List(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to list identities", Error: err.Error()})
		return
	}

	sendJSON(w, http.StatusOK, result)
}

func parseIdentityDate(v string) (time.Time, error) {
	if t, err := time.Parse(time.RFC3339, v); err == nil {
		return t, nil
	}
	return time.Parse("2006-01-02", v)
}