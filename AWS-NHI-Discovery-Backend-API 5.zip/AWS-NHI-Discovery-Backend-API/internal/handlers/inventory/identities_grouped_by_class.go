package inventory

import (
	"net/http"
	"strconv"

	"nhi-backend-api/internal/models"
	modelsinventory "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

const (
	defaultLimitPerClass = 5
	maxLimitPerClass     = 100
)

type IdentityGroupedByClassHandler struct {
	service *svcinventory.IdentityGroupedByClassService
}

func NewIdentityGroupedByClassHandler(service *svcinventory.IdentityGroupedByClassService) *IdentityGroupedByClassHandler {
	return &IdentityGroupedByClassHandler{service: service}
}

func (h *IdentityGroupedByClassHandler) GroupedByClass(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	limitPerClass := defaultLimitPerClass
	if v := q.Get("limit_per_class"); v != "" {
		l, err := strconv.Atoi(v)
		if err != nil || l < 1 || l > maxLimitPerClass {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid limit_per_class",
				Error:   "limit_per_class must be between 1 and 100",
			})
			return
		}
		limitPerClass = l
	}

	accountID := q.Get("account_id")
	region := q.Get("region")

	if accountID != "" {
		exists, err := h.service.AccountIDExists(ctx, accountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !exists {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}

	if region != "" {
		exists, err := h.service.RegionExists(ctx, region)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
			return
		}
		if !exists {
			values, _ := h.service.ListRegions(ctx)
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false, "message": "invalid region", "error": "region does not exist", "valid_values": values,
			})
			return
		}
	}

	filter := modelsinventory.GroupedByClassFilter{
		AccountID:     accountID,
		Region:        region,
		LimitPerClass: limitPerClass,
	}

	result, err := h.service.GroupedByClass(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to group identities by class", Error: err.Error()})
		return
	}

	sendJSON(w, http.StatusOK, result)
}