package inventory

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gorilla/mux"

	svcinventory "nhi-backend-api/internal/services/inventory"
)

// AttachedPoliciesHandler handles GET /api/v1/inventory/credentials/{id}/policies
type AttachedPoliciesHandler struct {
	service *svcinventory.AttachedPoliciesService
}

func NewAttachedPoliciesHandler(
	service *svcinventory.AttachedPoliciesService,
) *AttachedPoliciesHandler {
	return &AttachedPoliciesHandler{service: service}
}

// Policies handles GET /api/v1/inventory/credentials/{id}/policies
func (h *AttachedPoliciesHandler) Policies(
	w http.ResponseWriter,
	r *http.Request,
) {
	vars := mux.Vars(r)
	id := strings.TrimSpace(vars["id"])

	if id == "" {
		sendJSON(w, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"message": "credential id is required",
		})
		return
	}

	result, err := h.service.GetPolicies(r.Context(), id)
	if err != nil {
		// Not found
		if strings.Contains(err.Error(), "not found") {
			sendJSON(w, http.StatusNotFound, map[string]interface{}{
				"success": false,
				"message": fmt.Sprintf("credential '%s' not found", id),
			})
			return
		}
		// Server error
		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Failed to fetch attached policies",
			"error":   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}