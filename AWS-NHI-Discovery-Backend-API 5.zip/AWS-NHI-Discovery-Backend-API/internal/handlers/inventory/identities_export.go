package inventory

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/models"
	modelsinventory "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityExportHandler struct {
	service *svcinventory.IdentityExportService
}

func NewIdentityExportHandler(service *svcinventory.IdentityExportService) *IdentityExportHandler {
	return &IdentityExportHandler{service: service}
}

func (h *IdentityExportHandler) Export(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	format := strings.ToLower(strings.TrimSpace(q.Get("format")))
	if format == "" {
		format = "csv"
	}
	if format != "csv" && format != "json" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid format",
			Error:   "format must be one of: csv, json",
		})
		return
	}

	page := 1
	if v := q.Get("page"); v != "" {
		p, err := strconv.Atoi(v)
		if err != nil || p < 1 || p > maxIdentityListPage {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid page", Error: "page must be a positive integer"})
			return
		}
		page = p
	}

	limit := 50
	if v := q.Get("limit"); v != "" {
		l, err := strconv.Atoi(v)
		if err != nil || l < 1 || l > maxIdentityListLimit {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid limit", Error: fmt.Sprintf("limit must be between 1 and %d", maxIdentityListLimit)})
			return
		}
		limit = l
	}

	sortBy := q.Get("sort_by")
	if sortBy != "" {
		if _, ok := identitySortFields[sortBy]; !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid sort_by", Error: "unsupported sort_by field"})
			return
		}
	}

	sortOrder := strings.ToLower(q.Get("sort_order"))
	if sortOrder != "" && sortOrder != "asc" && sortOrder != "desc" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid sort_order", Error: "sort_order must be asc or desc"})
		return
	}

	filter := modelsinventory.IdentityExportFilter{
		Page:            page,
		Limit:           limit,
		SortBy:          sortBy,
		SortOrder:       sortOrder,
		Search:          q.Get("search"),
		IdentityType:    q.Get("identity_type"),
		FunctionalClass: q.Get("functional_class"),
		AccountID:       q.Get("account_id"),
		Region:          q.Get("region"),
		Status:          q.Get("status"),
		Owner:           q.Get("owner"),
		Environment:     q.Get("environment"),
		Format:          format,
	}

	if v := q.Get("is_public"); v != "" {
		b, err := strconv.ParseBool(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid is_public", Error: "is_public must be true or false"})
			return
		}
		filter.IsPublic = &b
	}

	if v := q.Get("last_active_before"); v != "" {
		t, err := time.Parse(time.RFC3339, v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid last_active_before", Error: "last_active_before must be an RFC3339 timestamp"})
			return
		}
		filter.LastActiveBefore = &t
	}

	if filter.IdentityType != "" {
		ok, err := h.service.IdentityTypeExists(ctx, filter.IdentityType)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate identity_type", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid identity_type", Error: "identity_type does not exist"})
			return
		}
	}
	if filter.AccountID != "" {
		ok, err := h.service.AccountIDExists(ctx, filter.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
			return
		}
	}
	if filter.Region != "" {
		ok, err := h.service.RegionExists(ctx, filter.Region)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid region", Error: "region does not exist"})
			return
		}
	}
	if filter.Status != "" {
		ok, err := h.service.StatusExists(ctx, filter.Status)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate status", Error: err.Error()})
			return
		}
		if !ok {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid status", Error: "status does not exist"})
			return
		}
	}

	total, err := h.service.Count(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to count identities", Error: err.Error()})
		return
	}

	if total == 0 {
		sendJSON(w, http.StatusOK, map[string]interface{}{
			"success": true,
			"message": "no identities matched the given filters",
			"data":    []interface{}{},
		})
		return
	}

	rows, err := h.service.Export(ctx, filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to export identities", Error: err.Error()})
		return
	}

	w.Header().Set("X-Total-Count", strconv.Itoa(total))

	if format == "json" {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Content-Disposition", `attachment; filename="identities_export.json"`)
		w.WriteHeader(http.StatusOK)
		_ = json.NewEncoder(w).Encode(rows)
		return
	}

	w.Header().Set("Content-Type", "text/csv")
	w.Header().Set("Content-Disposition", `attachment; filename="identities_export.csv"`)
	w.WriteHeader(http.StatusOK)

	writer := csv.NewWriter(w)
	defer writer.Flush()

	header := []string{
		"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
		"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "deleted_at",
		"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible",
		"tags", "owner", "environment", "parent_arn", "cloudtrail_creator_arn",
		"discovery_source", "scan_id", "type_attributes", "raw_api_response",
	}
	_ = writer.Write(header)

	for _, row := range rows {
		record := []string{
			row.ID, row.ARN, row.Name, row.IdentityType, row.FunctionalClass, row.AccountID, row.Region, row.Status,
			row.CreatedAtAWS, row.FirstSeenAt, row.LastSeenAt, row.LastActivityAt, row.DeletedAt,
			row.VPCID, row.SubnetID, string(row.SecurityGroupIDs), strconv.FormatBool(row.IsPubliclyAccessible),
			string(row.Tags), row.Owner, row.Environment, row.ParentARN, row.CloudTrailCreatorARN,
			row.DiscoverySource, row.ScanID, string(row.TypeAttributes), string(row.RawAPIResponse),
		}
		_ = writer.Write(record)
	}
}