package inventory

import (
	"net/http"
	"strconv"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	inventorysvc "nhi-backend-api/internal/services/inventory"
)

const maxStaleDays = 3650
const maxStaleLimit = 200

type CredentialStaleHandler struct {
	service *inventorysvc.CredentialStaleService
}

func NewCredentialStaleHandler(service *inventorysvc.CredentialStaleService) *CredentialStaleHandler {
	return &CredentialStaleHandler{service: service}
}

// Stale handles GET /api/v1/inventory/credentials/stale
func (h *CredentialStaleHandler) Stale(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	// days — required
	daysStr := strings.TrimSpace(q.Get("days"))
	if daysStr == "" {
		sendJSON(w, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"message": "days is required",
		})
		return
	}
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 1 || days > maxStaleDays {
		sendJSON(w, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"message": "days must be an integer between 1 and " + strconv.Itoa(maxStaleDays),
		})
		return
	}

	limit := parseIntDefault(q.Get("limit"), 50)
	if limit > maxStaleLimit {
		limit = maxStaleLimit
	}

	f := inventorymodels.StaleCredentialFilter{
		Days:           days,
		CredentialType: strings.TrimSpace(q.Get("credential_type")),
		AccountID:      strings.TrimSpace(q.Get("account_id")),
		Page:           parseIntDefault(q.Get("page"), 1),
		Limit:          limit,
	}

	// credential_type — validated against the DB
	if f.CredentialType != "" {
		exists, err := h.service.CredentialTypeExists(r.Context(), f.CredentialType)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
				"success": false,
				"message": "Failed to validate credential_type",
				"error":   err.Error(),
			})
			return
		}
		if !exists {
			validTypes, _ := h.service.ListCredentialTypes(r.Context())
			if validTypes == nil {
				validTypes = []string{}
			}
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success":      false,
				"message":      "invalid credential_type: " + f.CredentialType,
				"valid_values": validTypes,
			})
			return
		}
	}

	// account_id — validated against the DB
	if f.AccountID != "" {
		exists, err := h.service.AccountIDExists(r.Context(), f.AccountID)
		if err != nil {
			sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
				"success": false,
				"message": "Failed to validate account_id",
				"error":   err.Error(),
			})
			return
		}
		if !exists {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "unknown account_id: " + f.AccountID,
			})
			return
		}
	}

	result, err := h.service.List(r.Context(), f)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Failed to fetch stale credentials",
			"error":   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}