package inventory

import (
	"errors"
	"net/http"
	"regexp"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

var identityUUIDRegex = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

func isValidIdentityUUID(id string) bool {
	return identityUUIDRegex.MatchString(id)
}

type IdentityDetailHandler struct {
	service *svcinventory.IdentityDetailService
}

func NewIdentityDetailHandler(service *svcinventory.IdentityDetailService) *IdentityDetailHandler {
	return &IdentityDetailHandler{service: service}
}

func (h *IdentityDetailHandler) Detail(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]

	if !isValidIdentityUUID(id) {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid id",
			Error:   "id must be a valid UUID",
		})
		return
	}

	result, err := h.service.Detail(r.Context(), id)
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityNotFound) {
			sendJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false,
				Message: "identity not found",
				Error:   "no identity exists with the given id",
			})
			return
		}
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity detail",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}