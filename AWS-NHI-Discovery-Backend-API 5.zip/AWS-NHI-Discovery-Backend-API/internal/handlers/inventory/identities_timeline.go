package inventory

import (
	"errors"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityTimelineHandler struct {
	service *svcinventory.IdentityTimelineService
}

func NewIdentityTimelineHandler(service *svcinventory.IdentityTimelineService) *IdentityTimelineHandler {
	return &IdentityTimelineHandler{service: service}
}

func (h *IdentityTimelineHandler) Timeline(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]

	if !isValidIdentityUUID(id) {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid id",
			Error:   "id must be a valid UUID",
		})
		return
	}

	result, err := h.service.Timeline(r.Context(), id)
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityNotFound) {
			sendJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false,
				Message: "identity not found",
				Error:   "no identity exists with the given id",
			})
			return
		}
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity timeline",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}