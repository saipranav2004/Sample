package inventory

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gorilla/mux"

	svcinventory "nhi-backend-api/internal/services/inventory"
)

// CredentialDetailsHandler handles GET /api/v1/inventory/credentials/{id}
type CredentialDetailsHandler struct {
	service *svcinventory.CredentialDetailsService
}

func NewCredentialDetailsHandler(
	service *svcinventory.CredentialDetailsService,
) *CredentialDetailsHandler {
	return &CredentialDetailsHandler{service: service}
}

// Detail handles GET /api/v1/inventory/credentials/{id}
func (h *CredentialDetailsHandler) Detail(
	w http.ResponseWriter,
	r *http.Request,
) {
	vars := mux.Vars(r)
	id := strings.TrimSpace(vars["id"])

	if id == "" {
		sendJSON(w, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"message": "credential id is required",
		})
		return
	}

	result, err := h.service.GetByID(r.Context(), id)
	if err != nil {
		// Check if not found
		if strings.Contains(err.Error(), "no rows") {
			sendJSON(w, http.StatusNotFound, map[string]interface{}{
				"success": false,
				"message": fmt.Sprintf("credential with id '%s' not found", id),
			})
			return
		}

		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Failed to fetch credential detail",
			"error":   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}