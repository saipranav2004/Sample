package inventory

import (
	"context"
	"fmt"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// CredentialStaleRepository handles DB queries for stale credentials.
type CredentialStaleRepository struct {
	db *repository.PostgresDB
}

func NewCredentialStaleRepository(db *repository.PostgresDB) *CredentialStaleRepository {
	return &CredentialStaleRepository{db: db}
}

// AccountIDExists checks the DB for the given account_id.
func (r *CredentialStaleRepository) AccountIDExists(
	ctx context.Context,
	accountID string,
) (bool, error) {
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1
			FROM %s.credentials
			WHERE account_id = $1
			  AND deleted_at IS NULL
		)
	`, repository.Schema)

	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, accountID).Scan(&exists); err != nil {
		return false, fmt.Errorf("check account_id exists: %w", err)
	}
	return exists, nil
}

// CredentialTypeExists checks the DB for the given credential_type (case-insensitive).
func (r *CredentialStaleRepository) CredentialTypeExists(
	ctx context.Context,
	credentialType string,
) (bool, error) {
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1
			FROM %s.credentials
			WHERE LOWER(credential_type) = LOWER($1)
			  AND deleted_at IS NULL
		)
	`, repository.Schema)

	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, credentialType).Scan(&exists); err != nil {
		return false, fmt.Errorf("check credential_type exists: %w", err)
	}
	return exists, nil
}

// ListCredentialTypes returns the distinct credential types present in the DB.
func (r *CredentialStaleRepository) ListCredentialTypes(
	ctx context.Context,
) ([]string, error) {
	query := fmt.Sprintf(`
		SELECT DISTINCT credential_type
		FROM %s.credentials
		WHERE deleted_at IS NULL
		  AND credential_type IS NOT NULL
		  AND credential_type <> ''
		ORDER BY credential_type
	`, repository.Schema)

	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("list credential types: %w", err)
	}
	defer rows.Close()

	types := make([]string, 0)
	for rows.Next() {
		var t string
		if err := rows.Scan(&t); err != nil {
			return nil, fmt.Errorf("scan credential type: %w", err)
		}
		types = append(types, t)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential types: %w", err)
	}
	return types, nil
}

// List returns active credentials not used for more than Days days,
// most stale (oldest last_used_at) first.
func (r *CredentialStaleRepository) List(
	ctx context.Context,
	f inventorymodels.StaleCredentialFilter,
) (*inventorymodels.StaleCredentialsResponse, error) {

	args := []interface{}{}
	addArg := func(v interface{}) string {
		args = append(args, v)
		return fmt.Sprintf("$%d", len(args))
	}

	daysPH := addArg(f.Days)

	where := []string{
		"deleted_at IS NULL",
		"last_used_at IS NOT NULL",
		fmt.Sprintf("last_used_at < NOW() - make_interval(days => %s::int)", daysPH),
		"LOWER(COALESCE(status, '')) = 'active'",
	}

	if f.CredentialType != "" {
		where = append(where,
			fmt.Sprintf("LOWER(credential_type) = LOWER(%s)", addArg(f.CredentialType)))
	}
	if f.AccountID != "" {
		where = append(where,
			fmt.Sprintf("account_id = %s", addArg(f.AccountID)))
	}

	whereClause := "WHERE " + strings.Join(where, " AND ")

	// ── total ────────────────────────────────────────────────────────────
	countQuery := fmt.Sprintf(
		`SELECT COUNT(*) FROM %s.credentials %s`,
		repository.Schema, whereClause,
	)

	var total int
	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count stale credentials: %w", err)
	}

	// ── pagination ───────────────────────────────────────────────────────
	page := f.Page
	if page < 1 {
		page = 1
	}
	limit := f.Limit
	if limit < 1 {
		limit = 50
	}
	offset := (page - 1) * limit

	offsetPH := addArg(offset)
	limitPH := addArg(limit)

	// ── data ─────────────────────────────────────────────────────────────
	dataQuery := fmt.Sprintf(`
		SELECT
			id::text,
			COALESCE(name, '')            AS name,
			COALESCE(credential_type, '') AS credential_type,
			last_used_at,
			FLOOR(EXTRACT(EPOCH FROM (NOW() - last_used_at)) / 86400)::int AS days_unused,
			owner_principal_arn
		FROM %s.credentials
		%s
		ORDER BY last_used_at ASC, name ASC
		OFFSET %s LIMIT %s
	`, repository.Schema, whereClause, offsetPH, limitPH)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("query stale credentials: %w", err)
	}
	defer rows.Close()

	data := make([]inventorymodels.StaleCredential, 0)

	for rows.Next() {
		var c inventorymodels.StaleCredential
		if err := rows.Scan(
			&c.ID,
			&c.Name,
			&c.CredentialType,
			&c.LastUsedAt,
			&c.DaysUnused,
			&c.OwnerPrincipalARN,
		); err != nil {
			return nil, fmt.Errorf("scan stale credential row: %w", err)
		}
		data = append(data, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate stale credential rows: %w", err)
	}

	return &inventorymodels.StaleCredentialsResponse{
		ThresholdDays: f.Days,
		TotalStale:    total,
		Data:          data,
	}, nil
}