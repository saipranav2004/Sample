package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type UpdateCredentialRepository struct {
	db *repository.PostgresDB
}

func NewUpdateCredentialRepository(db *repository.PostgresDB) *UpdateCredentialRepository {
	return &UpdateCredentialRepository{db: db}
}

func (r *UpdateCredentialRepository) UpdateCredential(
	ctx context.Context,
	id string,
	req modelsinventory.UpdateCredentialRequest,
) (*modelsinventory.UpdateCredentialResponse, error) {

	// ── Build SET clauses dynamically ─────────────────────────────────────────
	args := []interface{}{}
	setClauses := []string{}
	updatedFields := []string{}
	argIdx := 1

	if req.OwnerPrincipalARN != nil {
		args = append(args, *req.OwnerPrincipalARN)
		setClauses = append(setClauses,
			fmt.Sprintf("owner_principal_arn = $%d", argIdx),
		)
		updatedFields = append(updatedFields, "owner_principal_arn")
		argIdx++
	}

	if req.Tags != nil {
		tagsJSON, err := json.Marshal(req.Tags)
		if err != nil {
			return nil, fmt.Errorf("marshal tags: %w", err)
		}
		args = append(args, string(tagsJSON))
		setClauses = append(setClauses,
			fmt.Sprintf("tags = $%d::jsonb", argIdx),
		)
		updatedFields = append(updatedFields, "tags")
		argIdx++
	}

	// ── Nothing to update ─────────────────────────────────────────────────────
	if len(setClauses) == 0 {
		return nil, fmt.Errorf("no fields to update")
	}

	// ── Add updated_at ────────────────────────────────────────────────────────
	setClauses = append(setClauses, "updated_at = NOW()")

	// ── Add id as last arg ────────────────────────────────────────────────────
	args = append(args, id)
	idArg := argIdx

	query := fmt.Sprintf(`
		UPDATE nhi_scanner.credentials
		SET %s
		WHERE id = $%d::uuid
		AND deleted_at IS NULL
		RETURNING id::text
	`, strings.Join(setClauses, ", "), idArg)

	var returnedID string
	if err := r.db.DB.QueryRowContext(ctx, query, args...).
		Scan(&returnedID); err != nil {
		return nil, fmt.Errorf("update credential: %w", err)
	}

	return &modelsinventory.UpdateCredentialResponse{
		ID:            returnedID,
		Message:       "Updated",
		UpdatedFields: updatedFields,
	}, nil
}