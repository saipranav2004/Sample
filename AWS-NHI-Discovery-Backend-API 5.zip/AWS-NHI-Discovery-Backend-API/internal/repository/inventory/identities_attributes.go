// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentityAttributesRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentityAttributesRepository(db *repository.PostgresDB) *IdentityAttributesRepository {
// 	return &IdentityAttributesRepository{db: db}
// }

// func (r *IdentityAttributesRepository) Attributes(ctx context.Context, id int64) (*modelsinventory.IdentityAttributesResponse, error) {
// 	query := fmt.Sprintf(`
// 		SELECT identity_type, type_attributes
// 		FROM %s.identities
// 		WHERE id = $1
// 	`, repository.Schema)

// 	var identityType sql.NullString
// 	var typeAttributes []byte

// 	err := r.db.DB.QueryRowContext(ctx, query, id).Scan(&identityType, &typeAttributes)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, ErrIdentityNotFound
// 		}
// 		return nil, fmt.Errorf("load identity attributes: %w", err)
// 	}

// 	out := &modelsinventory.IdentityAttributesResponse{
// 		IdentityType:   identityType.String,
// 		TypeAttributes: identityNullRawOrEmptyObject(typeAttributes),
// 	}

// 	return out, nil
// }













package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityAttributesRepository struct {
	db *repository.PostgresDB
}

func NewIdentityAttributesRepository(db *repository.PostgresDB) *IdentityAttributesRepository {
	return &IdentityAttributesRepository{db: db}
}

func (r *IdentityAttributesRepository) Attributes(ctx context.Context, id string) (*modelsinventory.IdentityAttributesResponse, error) {
	query := fmt.Sprintf(`
		SELECT identity_type, type_attributes
		FROM %s.identities
		WHERE id = $1::uuid AND deleted_at IS NULL
	`, repository.Schema)

	var identityType sql.NullString
	var typeAttributes []byte

	err := r.db.DB.QueryRowContext(ctx, query, id).Scan(&identityType, &typeAttributes)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrIdentityNotFound
		}
		return nil, fmt.Errorf("load identity attributes: %w", err)
	}

	return &modelsinventory.IdentityAttributesResponse{
		IdentityType:   identityType.String,
		TypeAttributes: identityNullRawOrEmptyObject(typeAttributes),
	}, nil
}