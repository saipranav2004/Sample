package inventory

import (
	"context"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityListRepository struct {
	db *repository.PostgresDB
}

func NewIdentityListRepository(db *repository.PostgresDB) *IdentityListRepository {
	return &IdentityListRepository{db: db}
}

var identitySortColumns = map[string]string{
	"id":               "id",
	"name":             "name",
	"identity_type":    "identity_type",
	"functional_class": "functional_class",
	"account_id":       "account_id",
	"region":           "region",
	"status":           "status",
	"created_at_aws":   "created_at_aws",
	"last_seen_at":     "last_seen_at",
	"last_activity_at": "last_activity_at",
}

func (r *IdentityListRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return r.existsIn(ctx, "account_id", accountID)
}

func (r *IdentityListRepository) IdentityTypeExists(ctx context.Context, identityType string) (bool, error) {
	return r.existsIn(ctx, "identity_type", identityType)
}

func (r *IdentityListRepository) RegionExists(ctx context.Context, region string) (bool, error) {
	return r.existsIn(ctx, "region", region)
}

func (r *IdentityListRepository) StatusExists(ctx context.Context, status string) (bool, error) {
	return r.existsIn(ctx, "status", status)
}

func (r *IdentityListRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL)`, repository.Schema, column)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
		return false, fmt.Errorf("check %s exists: %w", column, err)
	}
	return exists, nil
}

func (r *IdentityListRepository) ListIdentityTypes(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "identity_type")
}

func (r *IdentityListRepository) ListRegions(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "region")
}

func (r *IdentityListRepository) ListStatuses(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "status")
}

func (r *IdentityListRepository) listDistinct(ctx context.Context, column string) ([]string, error) {
	query := fmt.Sprintf(`SELECT DISTINCT %s FROM %s.identities WHERE %s IS NOT NULL AND deleted_at IS NULL ORDER BY %s`, column, repository.Schema, column, column)
	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("list %s: %w", column, err)
	}
	defer rows.Close()

	values := make([]string, 0)
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			return nil, fmt.Errorf("scan %s: %w", column, err)
		}
		values = append(values, v)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return values, nil
}

func (r *IdentityListRepository) buildWhere(f modelsinventory.IdentityListFilter) (string, []interface{}) {
	clauses := []string{"deleted_at IS NULL"}
	args := []interface{}{}
	idx := 1

	add := func(clause string, val interface{}) {
		clauses = append(clauses, fmt.Sprintf(clause, idx))
		args = append(args, val)
		idx++
	}

	if f.Search != "" {
		clauses = append(clauses, fmt.Sprintf("(name ILIKE $%d OR arn ILIKE $%d)", idx, idx+1))
		args = append(args, "%"+f.Search+"%", "%"+f.Search+"%")
		idx += 2
	}
	if f.IdentityType != "" {
		add("identity_type = $%d", f.IdentityType)
	}
	if f.FunctionalClass != "" {
		add("functional_class = $%d", f.FunctionalClass)
	}
	if f.AccountID != "" {
		add("account_id = $%d", f.AccountID)
	}
	if f.Region != "" {
		add("region = $%d", f.Region)
	}
	if f.Status != "" {
		add("status = $%d", f.Status)
	}
	if f.Owner != "" {
		add("owner = $%d", f.Owner)
	}
	if f.Environment != "" {
		add("environment = $%d", f.Environment)
	}
	if f.IsPublic != nil {
		add("is_publicly_accessible = $%d", *f.IsPublic)
	}
	if f.LastActiveBefore != nil {
		add("last_activity_at < $%d", *f.LastActiveBefore)
	}

	return strings.Join(clauses, " AND "), args
}

func (r *IdentityListRepository) Count(ctx context.Context, f modelsinventory.IdentityListFilter) (int, error) {
	where, args := r.buildWhere(f)
	query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE %s`, repository.Schema, where)

	var total int
	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&total); err != nil {
		return 0, fmt.Errorf("count identities: %w", err)
	}
	return total, nil
}

func (r *IdentityListRepository) List(ctx context.Context, f modelsinventory.IdentityListFilter) ([]modelsinventory.Identity, error) {
	where, args := r.buildWhere(f)

	sortBy := "last_seen_at"
	if f.SortBy != "" {
		if col, ok := identitySortColumns[f.SortBy]; ok {
			sortBy = col
		}
	}
	sortOrder := "DESC"
	if strings.EqualFold(f.SortOrder, "asc") {
		sortOrder = "ASC"
	}
	orderBy := fmt.Sprintf("%s %s NULLS LAST, id ASC", sortBy, sortOrder)

	limitIdx := len(args) + 1
	offsetIdx := len(args) + 2
	args = append(args, f.Limit, (f.Page-1)*f.Limit)

	query := fmt.Sprintf(`
		SELECT
			id::text, arn, name, identity_type, functional_class,
			account_id, region, status, created_at_aws, last_seen_at,
			last_activity_at, owner, environment, is_publicly_accessible,
			COALESCE(tags::text, '{}')
		FROM %s.identities
		WHERE %s
		ORDER BY %s
		LIMIT $%d OFFSET $%d
	`, repository.Schema, where, orderBy, limitIdx, offsetIdx)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("list identities: %w", err)
	}
	defer rows.Close()

	result := make([]modelsinventory.Identity, 0)
	for rows.Next() {
		var ident modelsinventory.Identity
		var tagsRaw string
		if err := rows.Scan(
			&ident.ID, &ident.ARN, &ident.Name, &ident.IdentityType, &ident.FunctionalClass,
			&ident.AccountID, &ident.Region, &ident.Status, &ident.CreatedAtAWS, &ident.LastSeenAt,
			&ident.LastActivityAt, &ident.Owner, &ident.Environment, &ident.IsPubliclyAccessible,
			&tagsRaw,
		); err != nil {
			return nil, fmt.Errorf("scan identity: %w", err)
		}
		ident.Tags = []byte(tagsRaw)
		result = append(result, ident)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return result, nil
}