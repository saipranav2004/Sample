package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// ── Validator ─────────────────────────────────────────────────────────────────

// ValidatorRepository provides DB-driven validation.
type ValidatorRepository struct {
	db *repository.PostgresDB
}

func NewValidatorRepository(db *repository.PostgresDB) *ValidatorRepository {
	return &ValidatorRepository{db: db}
}

// RegionExists checks region against nhi_scanner.credentials table.
func (v *ValidatorRepository) RegionExists(ctx context.Context, region string) error {
	if strings.TrimSpace(region) == "" {
		return nil
	}
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1 FROM %s.credentials
			WHERE region = $1 AND deleted_at IS NULL LIMIT 1
		)`, repository.Schema)

	var exists bool
	if err := v.db.DB.QueryRowContext(ctx, query, region).Scan(&exists); err != nil {
		return fmt.Errorf("failed to validate region: %w", err)
	}
	if !exists {
		return fmt.Errorf("region '%s' not found", region)
	}
	return nil
}

// AccountIDExists checks account_id against nhi_scanner.credentials table.
func (v *ValidatorRepository) AccountIDExists(ctx context.Context, accountID string) error {
	if strings.TrimSpace(accountID) == "" {
		return nil
	}
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1 FROM %s.credentials
			WHERE account_id = $1 AND deleted_at IS NULL LIMIT 1
		)`, repository.Schema)

	var exists bool
	if err := v.db.DB.QueryRowContext(ctx, query, accountID).Scan(&exists); err != nil {
		return fmt.Errorf("failed to validate account_id: %w", err)
	}
	if !exists {
		return fmt.Errorf("account_id '%s' not found", accountID)
	}
	return nil
}

// ── IAM Role Details Builder ──────────────────────────────────────────────────

// buildIAMRoleDetails extracts IAM role specific fields from type_attributes JSONB.
// Used by credetials_details.go
func buildIAMRoleDetails(
	attrs map[string]interface{},
) *inventorymodels.IAMRoleDetails {

	details := &inventorymodels.IAMRoleDetails{
		AttachedPolicies:  []inventorymodels.IAMRolePolicy{},
		InlinePolicies:    []string{},
		AssumableRoleARNs: []string{},
	}

	// trust_policy
	if v, ok := attrs["trust_policy"].(map[string]interface{}); ok {
		details.TrustPolicy = v
	}

	// permission_boundary_arn
	if v, ok := attrs["permission_boundary_arn"].(string); ok && v != "" {
		details.PermissionBoundaryARN = &v
	}

	// max_session_duration
	if v, ok := attrs["max_session_duration"]; ok {
		switch val := v.(type) {
		case float64:
			details.MaxSessionDuration = int(val)
		case int:
			details.MaxSessionDuration = val
		}
	}

	// privilege_level
	if v, ok := attrs["privilege_level"]; ok {
		switch val := v.(type) {
		case float64:
			details.PrivilegeLevel = int(val)
		case int:
			details.PrivilegeLevel = val
		}
	}

	// attached_policies
	if v, ok := attrs["attached_policies"].([]interface{}); ok {
		for _, p := range v {
			if pm, ok := p.(map[string]interface{}); ok {
				policy := inventorymodels.IAMRolePolicy{}
				if arn, ok := pm["arn"].(string); ok {
					policy.ARN = arn
				}
				if name, ok := pm["name"].(string); ok {
					policy.Name = name
				}
				if doc, ok := pm["document"].(map[string]interface{}); ok {
					policy.Document = doc
				}
				details.AttachedPolicies = append(details.AttachedPolicies, policy)
			}
		}
	}

	// inline_policies
	if v, ok := attrs["inline_policies"].([]interface{}); ok {
		for _, p := range v {
			if s, ok := p.(string); ok {
				details.InlinePolicies = append(details.InlinePolicies, s)
			}
		}
	}

	// assumable_role_arns
	if v, ok := attrs["assumable_role_arns"].([]interface{}); ok {
		for _, a := range v {
			if s, ok := a.(string); ok {
				details.AssumableRoleARNs = append(details.AssumableRoleARNs, s)
			}
		}
	}

	return details
}

// ── Policy Parsers ────────────────────────────────────────────────────────────

// parseManagedPolicies parses the attached_policies JSONB array.
// Used by attached_policies.go
func parseManagedPolicies(raw []byte) []inventorymodels.ManagedPolicy {
	policies := []inventorymodels.ManagedPolicy{}

	if len(raw) == 0 || string(raw) == "null" || string(raw) == "[]" {
		return policies
	}

	var rawPolicies []map[string]interface{}
	if err := json.Unmarshal(raw, &rawPolicies); err != nil {
		return policies
	}

	for _, p := range rawPolicies {
		policy := inventorymodels.ManagedPolicy{
			RiskyStatements: []map[string]interface{}{},
		}

		if v, ok := p["arn"].(string); ok {
			policy.ARN = v
		}
		if v, ok := p["name"].(string); ok {
			policy.Name = v
		}

		// Parse document for statement count and risky statements
		if doc, ok := p["document"].(map[string]interface{}); ok {
			count, risky := parseDocumentStatements(doc)
			policy.StatementCount = count
			policy.RiskyStatements = risky
		}

		policies = append(policies, policy)
	}

	return policies
}

// parseInlinePolicies parses the inline_policies JSONB field.
// Used by attached_policies.go
func parseInlinePolicies(raw []byte) []string {
	result := []string{}

	if len(raw) == 0 || string(raw) == "null" || string(raw) == "[]" {
		return result
	}

	// Try []string first
	var strSlice []string
	if err := json.Unmarshal(raw, &strSlice); err == nil {
		return strSlice
	}

	// Try []map — extract "name"
	var mapSlice []map[string]interface{}
	if err := json.Unmarshal(raw, &mapSlice); err == nil {
		for _, m := range mapSlice {
			if name, ok := m["name"].(string); ok {
				result = append(result, name)
			}
		}
	}

	return result
}

// parseDocumentStatements counts statements and finds risky ones.
func parseDocumentStatements(
	doc map[string]interface{},
) (int, []map[string]interface{}) {

	risky := []map[string]interface{}{}

	rawStmts, ok := doc["Statement"].([]interface{})
	if !ok {
		return 0, risky
	}

	for _, s := range rawStmts {
		stmtMap, ok := s.(map[string]interface{})
		if !ok {
			continue
		}

		effect, _ := stmtMap["Effect"].(string)
		if effect != "Allow" {
			continue
		}

		actionWild := false
		switch action := stmtMap["Action"].(type) {
		case string:
			actionWild = isWildcardStr(action)
		case []interface{}:
			for _, a := range action {
				if s, ok := a.(string); ok && isWildcardStr(s) {
					actionWild = true
					break
				}
			}
		}

		resourceWild := false
		switch res := stmtMap["Resource"].(type) {
		case string:
			resourceWild = res == "*"
		case []interface{}:
			for _, rv := range res {
				if s, ok := rv.(string); ok && s == "*" {
					resourceWild = true
					break
				}
			}
		}

		if actionWild || resourceWild {
			risky = append(risky, stmtMap)
		}
	}

	return len(rawStmts), risky
}

// ── Trust Policy Helpers ──────────────────────────────────────────────────────

// hasWildcardAction checks trust_policy statements for wildcard actions.
// Used by credentials_hygiene_flags.go
func hasWildcardAction(trustPolicy map[string]interface{}) bool {
	statements, ok := trustPolicy["Statement"].([]interface{})
	if !ok {
		return false
	}
	for _, s := range statements {
		stmtMap, ok := s.(map[string]interface{})
		if !ok {
			continue
		}
		if effect, _ := stmtMap["Effect"].(string); effect != "Allow" {
			continue
		}
		switch action := stmtMap["Action"].(type) {
		case string:
			if isWildcardStr(action) {
				return true
			}
		case []interface{}:
			for _, a := range action {
				if s, ok := a.(string); ok && isWildcardStr(s) {
					return true
				}
			}
		}
	}
	return false
}

// isWildcardStr checks if an action string contains a wildcard.
func isWildcardStr(s string) bool {
	return s == "*" || (len(s) > 1 && s[len(s)-2:] == ":*")
}