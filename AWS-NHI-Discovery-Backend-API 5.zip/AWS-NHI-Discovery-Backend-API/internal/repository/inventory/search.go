package inventory

import (
	"context"
	"fmt"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type GlobalSearchFilter struct {
	Query      string
	EntityType string // "identities" | "credentials" | "both" (default)
	Limit      int
}

type SearchRepository struct {
	db *repository.PostgresDB
}

func NewSearchRepository(db *repository.PostgresDB) *SearchRepository {
	return &SearchRepository{db: db}
}

func (r *SearchRepository) SearchIdentities(ctx context.Context, query string, limit int) ([]modelsinventory.SearchIdentityResult, error) {
	sqlQuery := fmt.Sprintf(`
		SELECT id::text, name, identity_type
		FROM %s.identities
		WHERE deleted_at IS NULL
		  AND (name ILIKE $1 OR arn ILIKE $1 OR tags::text ILIKE $1)
		ORDER BY name ASC
		LIMIT $2
	`, repository.Schema)

	rows, err := r.db.DB.QueryContext(ctx, sqlQuery, "%"+query+"%", limit)
	if err != nil {
		return nil, fmt.Errorf("search identities: %w", err)
	}
	defer rows.Close()

	results := make([]modelsinventory.SearchIdentityResult, 0)
	for rows.Next() {
		var item modelsinventory.SearchIdentityResult
		if err := rows.Scan(&item.ID, &item.Name, &item.IdentityType); err != nil {
			return nil, fmt.Errorf("scan identity search result: %w", err)
		}
		results = append(results, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identity search results: %w", err)
	}

	return results, nil
}

func (r *SearchRepository) SearchCredentials(ctx context.Context, query string, limit int) ([]modelsinventory.SearchCredentialResult, error) {
	sqlQuery := fmt.Sprintf(`
		SELECT id::text, name, credential_type
		FROM %s.credentials
		WHERE deleted_at IS NULL
		  AND (name ILIKE $1 OR arn ILIKE $1 OR tags::text ILIKE $1)
		ORDER BY name ASC
		LIMIT $2
	`, repository.Schema)

	rows, err := r.db.DB.QueryContext(ctx, sqlQuery, "%"+query+"%", limit)
	if err != nil {
		return nil, fmt.Errorf("search credentials: %w", err)
	}
	defer rows.Close()

	results := make([]modelsinventory.SearchCredentialResult, 0)
	for rows.Next() {
		var item modelsinventory.SearchCredentialResult
		if err := rows.Scan(&item.ID, &item.Name, &item.CredentialType); err != nil {
			return nil, fmt.Errorf("scan credential search result: %w", err)
		}
		results = append(results, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential search results: %w", err)
	}

	return results, nil
}