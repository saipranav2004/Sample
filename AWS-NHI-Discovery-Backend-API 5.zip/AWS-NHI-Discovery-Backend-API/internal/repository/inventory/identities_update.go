package inventory

import (
	"context"
	"errors"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

var ErrNoFieldsToUpdate = errors.New("no fields provided to update")

type UpdateIdentityRepository struct {
	db *repository.PostgresDB
}

func NewUpdateIdentityRepository(db *repository.PostgresDB) *UpdateIdentityRepository {
	return &UpdateIdentityRepository{db: db}
}

func (r *UpdateIdentityRepository) Update(ctx context.Context, id string, req modelsinventory.UpdateIdentityRequest) ([]string, error) {
	var (
		setClauses    []string
		args          []interface{}
		updatedFields []string
		argIdx        = 1
	)

	if req.FunctionalClass != nil {
		setClauses = append(setClauses, fmt.Sprintf("functional_class = $%d", argIdx))
		args = append(args, *req.FunctionalClass)
		updatedFields = append(updatedFields, "functional_class")
		argIdx++
	}

	if req.Owner != nil {
		setClauses = append(setClauses, fmt.Sprintf("owner = $%d", argIdx))
		args = append(args, *req.Owner)
		updatedFields = append(updatedFields, "owner")
		argIdx++
	}

	if req.Environment != nil {
		setClauses = append(setClauses, fmt.Sprintf("environment = $%d", argIdx))
		args = append(args, *req.Environment)
		updatedFields = append(updatedFields, "environment")
		argIdx++
	}

	if len(setClauses) == 0 {
		return nil, ErrNoFieldsToUpdate
	}

	// always bump updated_at
	setClauses = append(setClauses, "updated_at = NOW()")

	query := fmt.Sprintf(`
		UPDATE %s.identities
		SET %s
		WHERE id = $%d::uuid AND deleted_at IS NULL
	`, repository.Schema, strings.Join(setClauses, ", "), argIdx)

	args = append(args, id)

	result, err := r.db.DB.ExecContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("update identity: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return nil, fmt.Errorf("check rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return nil, ErrIdentityNotFound
	}

	return updatedFields, nil
}