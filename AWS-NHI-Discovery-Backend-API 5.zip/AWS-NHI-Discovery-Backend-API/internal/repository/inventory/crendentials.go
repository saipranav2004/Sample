package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// CredentialRepository handles DB queries for the credentials inventory.
type CredentialRepository struct {
	db *repository.PostgresDB
}

func NewCredentialRepository(db *repository.PostgresDB) *CredentialRepository {
	return &CredentialRepository{db: db}
}

// List returns a paginated, filtered list from nhi_scanner.credentials.
func (r *CredentialRepository) List(
	ctx context.Context,
	f inventorymodels.CredentialFilter,
) (*inventorymodels.CredentialListResponse, error) {

	args := []interface{}{}
	argIdx := 1

	addArg := func(v interface{}) string {
		args = append(args, v)
		ph := fmt.Sprintf("$%d", argIdx)
		argIdx++
		return ph
	}

	// ── base WHERE ────────────────────────────────────────────────────────
	where := []string{"deleted_at IS NULL"}

	if f.Search != "" {
		ph1 := addArg("%" + f.Search + "%")
		ph2 := addArg("%" + f.Search + "%")
		where = append(where,
			fmt.Sprintf("(name ILIKE %s OR arn ILIKE %s)", ph1, ph2))
	}

	if f.CredentialType != "" {
		where = append(where,
			fmt.Sprintf("LOWER(credential_type) = LOWER(%s)", addArg(f.CredentialType)))
	}

	if f.AccountID != "" {
		where = append(where,
			fmt.Sprintf("account_id = %s", addArg(f.AccountID)))
	}

	if f.Region != "" {
		where = append(where,
			fmt.Sprintf("region = %s", addArg(f.Region)))
	}

	if f.Status != "" {
		where = append(where,
			fmt.Sprintf("LOWER(status) = LOWER(%s)", addArg(f.Status)))
	}

	if f.RotationEnabled != nil {
		where = append(where,
			fmt.Sprintf("rotation_enabled = %s", addArg(*f.RotationEnabled)))
	}

	if f.ExpiringWithinDays != nil {
		where = append(where,
			fmt.Sprintf(
				"expires_at BETWEEN NOW() AND NOW() + INTERVAL '%d days'",
				*f.ExpiringWithinDays,
			))
	}

	if f.StaleDays != nil {
		where = append(where,
			fmt.Sprintf(
				"last_used_at < NOW() - INTERVAL '%d days'",
				*f.StaleDays,
			))
	}

	if f.PrivilegeLevelMin != nil {
		where = append(where,
			fmt.Sprintf("privilege_level >= %s", addArg(*f.PrivilegeLevelMin)))
	}

	if f.PrivilegeLevelMax != nil {
		where = append(where,
			fmt.Sprintf("privilege_level <= %s", addArg(*f.PrivilegeLevelMax)))
	}

	if f.OwnerPrincipalARN != "" {
		where = append(where,
			fmt.Sprintf("owner_principal_arn = %s", addArg(f.OwnerPrincipalARN)))
	}

	whereClause := "WHERE " + strings.Join(where, " AND ")

	// ── total count ───────────────────────────────────────────────────────
	countQuery := fmt.Sprintf(
		`SELECT COUNT(*) FROM %s.credentials %s`,
		repository.Schema, whereClause,
	)

	var total int
	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count credentials: %w", err)
	}

	// ── sort ──────────────────────────────────────────────────────────────
	allowedSort := map[string]string{
		"name":            "name",
		"credential_type": "credential_type",
		"account_id":      "account_id",
		"region":          "region",
		"status":          "status",
		"created_at_aws":  "created_at_aws",
		"last_used_at":    "last_used_at",
		"last_rotated_at": "last_rotated_at",
		"expires_at":      "expires_at",
		"privilege_level": "privilege_level",
	}

	sortCol, ok := allowedSort[f.SortBy]
	if !ok {
		sortCol = "created_at_aws"
	}

	sortDir := "DESC"
	if strings.ToUpper(f.SortOrder) == "ASC" {
		sortDir = "ASC"
	}

	// ── pagination ────────────────────────────────────────────────────────
	page := f.Page
	if page < 1 {
		page = 1
	}
	limit := f.Limit
	if limit < 1 {
		limit = 50
	}
	offset := (page - 1) * limit

	offsetPH := addArg(offset)
	limitPH := addArg(limit)

	// ── data query ────────────────────────────────────────────────────────
	dataQuery := fmt.Sprintf(`
		SELECT
			id,
			COALESCE(arn, '')                 AS arn,
			COALESCE(name, '')                AS name,
			COALESCE(credential_type, '')     AS credential_type,
			COALESCE(account_id, '')          AS account_id,
			COALESCE(region, '')              AS region,
			COALESCE(status, '')              AS status,
			created_at_aws,
			last_used_at,
			last_rotated_at,
			expires_at,
			rotation_enabled,
			COALESCE(privilege_level, 0)      AS privilege_level,
			owner_principal_arn,
			COALESCE(tags, '{}'::jsonb)       AS tags
		FROM %s.credentials
		%s
		ORDER BY %s %s
		OFFSET %s LIMIT %s
	`,
		repository.Schema,
		whereClause,
		sortCol, sortDir,
		offsetPH, limitPH,
	)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("query credentials: %w", err)
	}
	defer rows.Close()

	creds := make([]inventorymodels.Credential, 0)

	for rows.Next() {
		var c inventorymodels.Credential
		var lastRotatedAt *time.Time // Local variable to receive last_rotated_at column
		var ownerArn sql.NullString
		var tagsRaw []byte

		if err := rows.Scan(
			&c.ID,
			&c.ARN,
			&c.Name,
			&c.CredentialType,
			&c.AccountID,
			&c.Region,
			&c.Status,
			&c.CreatedAtAWS,
			&c.LastUsedAt,
			&lastRotatedAt, // <-- FIXED: Scanned into local variable
			&c.ExpiresAt,
			&c.RotationEnabled,
			&c.PrivilegeLevel,
			&ownerArn,
			&tagsRaw,
		); err != nil {
			return nil, fmt.Errorf("scan credential row: %w", err)
		}

		if ownerArn.Valid && ownerArn.String != "" {
			c.OwnerPrincipalARN = &ownerArn.String
		}

		if len(tagsRaw) > 0 {
			if err := json.Unmarshal(tagsRaw, &c.Tags); err != nil {
				c.Tags = make(map[string]interface{})
			}
		} else {
			c.Tags = make(map[string]interface{})
		}

		creds = append(creds, c)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential rows: %w", err)
	}

	return &inventorymodels.CredentialListResponse{
		Total: total,
		Page:  page,
		Limit: limit,
		Data:  creds,
	}, nil
}