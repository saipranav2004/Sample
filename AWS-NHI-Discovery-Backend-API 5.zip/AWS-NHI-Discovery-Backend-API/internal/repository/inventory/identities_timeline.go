package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityTimelineRepository struct {
	db *repository.PostgresDB
}

func NewIdentityTimelineRepository(db *repository.PostgresDB) *IdentityTimelineRepository {
	return &IdentityTimelineRepository{db: db}
}

func (r *IdentityTimelineRepository) Timeline(ctx context.Context, id string, now func() time.Time) (*modelsinventory.IdentityTimelineResponse, error) {
	query := fmt.Sprintf(`
		SELECT arn, first_seen_at, last_seen_at, last_activity_at, scan_id
		FROM %s.identities
		WHERE id = $1::uuid AND deleted_at IS NULL
	`, repository.Schema)

	var (
		arn                                      sql.NullString
		firstSeenAt, lastSeenAt, lastActivityAt sql.NullTime
		scanID                                   sql.NullString
	)

	err := r.db.DB.QueryRowContext(ctx, query, id).Scan(&arn, &firstSeenAt, &lastSeenAt, &lastActivityAt, &scanID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrIdentityNotFound
		}
		return nil, fmt.Errorf("load identity timeline: %w", err)
	}

	events := make([]modelsinventory.IdentityTimelineEvent, 0)

	if firstSeenAt.Valid {
		events = append(events, modelsinventory.IdentityTimelineEvent{
			Event:     "first_discovered",
			Timestamp: firstSeenAt.Time.UTC().Format(time.RFC3339),
		})
	}
	if lastActivityAt.Valid {
		events = append(events, modelsinventory.IdentityTimelineEvent{
			Event:     "last_activity",
			Timestamp: lastActivityAt.Time.UTC().Format(time.RFC3339),
		})
	}
	if lastSeenAt.Valid {
		events = append(events, modelsinventory.IdentityTimelineEvent{
			Event:     "last_confirmed",
			Timestamp: lastSeenAt.Time.UTC().Format(time.RFC3339),
		})
	}

	ref := now().UTC()

	ageDays := 0
	if firstSeenAt.Valid {
		ageDays = int(ref.Sub(firstSeenAt.Time.UTC()).Hours() / 24)
	}

	daysSinceLastActivity := 0
	if lastActivityAt.Valid {
		daysSinceLastActivity = int(ref.Sub(lastActivityAt.Time.UTC()).Hours() / 24)
	}

	return &modelsinventory.IdentityTimelineResponse{
		IdentityARN:           arn.String,
		Events:                events,
		AgeDays:               ageDays,
		DaysSinceLastActivity: daysSinceLastActivity,
	}, nil
}