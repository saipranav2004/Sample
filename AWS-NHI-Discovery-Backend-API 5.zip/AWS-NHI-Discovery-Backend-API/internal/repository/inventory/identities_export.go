package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityExportRepository struct {
	db *repository.PostgresDB
}

func NewIdentityExportRepository(db *repository.PostgresDB) *IdentityExportRepository {
	return &IdentityExportRepository{db: db}
}

func (r *IdentityExportRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return r.existsIn(ctx, "account_id", accountID)
}
func (r *IdentityExportRepository) IdentityTypeExists(ctx context.Context, identityType string) (bool, error) {
	return r.existsIn(ctx, "identity_type", identityType)
}
func (r *IdentityExportRepository) RegionExists(ctx context.Context, region string) (bool, error) {
	return r.existsIn(ctx, "region", region)
}
func (r *IdentityExportRepository) StatusExists(ctx context.Context, status string) (bool, error) {
	return r.existsIn(ctx, "status", status)
}
func (r *IdentityExportRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL)`, repository.Schema, column)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
		return false, fmt.Errorf("check %s exists: %w", column, err)
	}
	return exists, nil
}

func (r *IdentityExportRepository) buildWhere(f modelsinventory.IdentityExportFilter) (string, []interface{}) {
	clauses := []string{"deleted_at IS NULL"}
	args := []interface{}{}
	idx := 1
	add := func(clause string, val interface{}) {
		clauses = append(clauses, fmt.Sprintf(clause, idx))
		args = append(args, val)
		idx++
	}
	if f.Search != "" {
		clauses = append(clauses, fmt.Sprintf("(name ILIKE $%d OR arn ILIKE $%d)", idx, idx+1))
		args = append(args, "%"+f.Search+"%", "%"+f.Search+"%")
		idx += 2
	}
	if f.IdentityType != "" {
		add("identity_type = $%d", f.IdentityType)
	}
	if f.FunctionalClass != "" {
		add("functional_class = $%d", f.FunctionalClass)
	}
	if f.AccountID != "" {
		add("account_id = $%d", f.AccountID)
	}
	if f.Region != "" {
		add("region = $%d", f.Region)
	}
	if f.Status != "" {
		add("status = $%d", f.Status)
	}
	if f.Owner != "" {
		add("owner = $%d", f.Owner)
	}
	if f.Environment != "" {
		add("environment = $%d", f.Environment)
	}
	if f.IsPublic != nil {
		add("is_publicly_accessible = $%d", *f.IsPublic)
	}
	if f.LastActiveBefore != nil {
		add("last_activity_at < $%d", *f.LastActiveBefore)
	}
	return strings.Join(clauses, " AND "), args
}

func (r *IdentityExportRepository) Count(ctx context.Context, f modelsinventory.IdentityExportFilter) (int, error) {
	where, args := r.buildWhere(f)
	query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE %s`, repository.Schema, where)
	var total int
	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&total); err != nil {
		return 0, fmt.Errorf("count identities for export: %w", err)
	}
	return total, nil
}

func (r *IdentityExportRepository) Export(ctx context.Context, f modelsinventory.IdentityExportFilter) ([]modelsinventory.IdentityExportRow, error) {
	where, args := r.buildWhere(f)

	sortBy := "last_seen_at"
	if f.SortBy != "" {
		if col, ok := identitySortColumns[f.SortBy]; ok {
			sortBy = col
		}
	}
	sortOrder := "DESC"
	if strings.EqualFold(f.SortOrder, "asc") {
		sortOrder = "ASC"
	}
	orderBy := fmt.Sprintf("%s %s NULLS LAST, id ASC", sortBy, sortOrder)

	limitIdx := len(args) + 1
	offsetIdx := len(args) + 2
	args = append(args, f.Limit, (f.Page-1)*f.Limit)

	query := fmt.Sprintf(`
		SELECT id::text, arn, name, identity_type, functional_class,
			account_id, region, status,
			created_at_aws, first_seen_at, last_seen_at, last_activity_at, deleted_at,
			vpc_id, subnet_id, security_group_ids, is_publicly_accessible,
			tags, owner, environment,
			parent_arn, cloudtrail_creator_arn,
			discovery_source, scan_id,
			type_attributes, raw_api_response
		FROM %s.identities
		WHERE %s
		ORDER BY %s
		LIMIT $%d OFFSET $%d
	`, repository.Schema, where, orderBy, limitIdx, offsetIdx)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("export identities: %w", err)
	}
	defer rows.Close()

	result := make([]modelsinventory.IdentityExportRow, 0)
	for rows.Next() {
		var (
			id, arn, name, identityType, functionalClass sql.NullString
			accountID, region, status                     sql.NullString
			createdAtAWS, firstSeenAt, lastSeenAt          sql.NullTime
			lastActivityAt, deletedAt                      sql.NullTime
			vpcID, subnetID                                sql.NullString
			securityGroupIDs                               []byte
			isPubliclyAccessible                           sql.NullBool
			tags                                           []byte
			owner, environment                             sql.NullString
			parentARN, cloudtrailCreatorARN                sql.NullString
			discoverySource, scanID                        sql.NullString
			typeAttributes, rawAPIResponse                 []byte
		)
		if err := rows.Scan(
			&id, &arn, &name, &identityType, &functionalClass,
			&accountID, &region, &status,
			&createdAtAWS, &firstSeenAt, &lastSeenAt, &lastActivityAt, &deletedAt,
			&vpcID, &subnetID, &securityGroupIDs, &isPubliclyAccessible,
			&tags, &owner, &environment,
			&parentARN, &cloudtrailCreatorARN,
			&discoverySource, &scanID,
			&typeAttributes, &rawAPIResponse,
		); err != nil {
			return nil, fmt.Errorf("scan export row: %w", err)
		}

		row := modelsinventory.IdentityExportRow{
			ID: id.String, ARN: arn.String, Name: name.String, IdentityType: identityType.String,
			FunctionalClass: functionalClass.String, AccountID: accountID.String, Region: region.String,
			Status:               status.String,
			CreatedAtAWS:         formatExportTime(createdAtAWS),
			FirstSeenAt:          formatExportTime(firstSeenAt),
			LastSeenAt:           formatExportTime(lastSeenAt),
			LastActivityAt:       formatExportTime(lastActivityAt),
			DeletedAt:            formatExportTime(deletedAt),
			VPCID:                vpcID.String,
			SubnetID:             subnetID.String,
			SecurityGroupIDs:     identityNullRawOrEmptyArray(securityGroupIDs),
			IsPubliclyAccessible: isPubliclyAccessible.Valid && isPubliclyAccessible.Bool,
			Tags:                 identityNullRawOrEmptyObject(tags),
			Owner:                owner.String,
			Environment:          environment.String,
			ParentARN:            parentARN.String,
			CloudTrailCreatorARN: cloudtrailCreatorARN.String,
			DiscoverySource:      discoverySource.String,
			ScanID:               scanID.String,
			TypeAttributes:       identityNullRawOrEmptyObject(typeAttributes),
			RawAPIResponse:       identityNullRawOrEmptyObject(rawAPIResponse),
		}
		result = append(result, row)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return result, nil
}

func formatExportTime(v sql.NullTime) string {
	if !v.Valid {
		return ""
	}
	return v.Time.UTC().Format("2006-01-02T15:04:05Z07:00")
}