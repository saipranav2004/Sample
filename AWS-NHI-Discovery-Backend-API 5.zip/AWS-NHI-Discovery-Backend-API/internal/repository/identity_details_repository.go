package repository

type IdentityDetailsRepository struct {
	db *PostgresDB
}

func NewIdentityDetailsRepository(db *PostgresDB) *IdentityDetailsRepository {
	return &IdentityDetailsRepository{db: db}
}
