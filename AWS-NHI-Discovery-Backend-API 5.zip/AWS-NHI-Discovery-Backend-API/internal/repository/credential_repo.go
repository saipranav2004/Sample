package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
)

type CredentialRepository struct {
	db *PostgresDB
}

func NewCredentialRepository(db *PostgresDB) *CredentialRepository {
	return &CredentialRepository{db: db}
}

type CredentialFilter struct {
	Search   string
	Type     string
	Severity string
	ScanID   string
	Offset   int
	Limit    int
}

func (r *CredentialRepository) List(ctx context.Context, filter CredentialFilter) ([]models.FlattenedCredential, int, error) {
	whereClauses := []string{"1=1"}
	var args []interface{}
	argIdx := 1

	// ── Oracle :N → PostgreSQL $N ──
	if filter.ScanID != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("scan_id = $%d", argIdx))
		args = append(args, filter.ScanID)
		argIdx++
	} else {
		// Oracle used a nested SELECT with ROWNUM = 1; PostgreSQL uses LIMIT 1.
		whereClauses = append(whereClauses, "scan_id = "+latestCompletedScanSQL)
	}

	if filter.Type != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_type = $%d", argIdx))
		args = append(args, filter.Type)
		argIdx++
	}

	if filter.Severity != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_severity = $%d", argIdx))
		args = append(args, filter.Severity)
		argIdx++
	}

	if filter.Search != "" {
		searchTerm := "%" + strings.ToLower(filter.Search) + "%"
		// Oracle reused a single :1 three times; PostgreSQL has no such reuse,
		// so the same value is bound three times under three positions.
		whereClauses = append(whereClauses, fmt.Sprintf(
			"(LOWER(identity_name) LIKE $%d OR LOWER(identity_arn) LIKE $%d OR LOWER(cred_id) LIKE $%d)",
			argIdx, argIdx+1, argIdx+2))
		args = append(args, searchTerm, searchTerm, searchTerm)
		argIdx += 3
	}

	whereSection := "WHERE " + strings.Join(whereClauses, " AND ")

	// ── Oracle JSON_TABLE → PostgreSQL jsonb_array_elements ─────────────
	//
	//	JSON_TABLE(i.owned_credentials, '$[*]'
	//	    COLUMNS (type VARCHAR2(100) PATH '$.type', ...))
	//
	// → jsonb_array_elements(...) with ->> for each PATH. Because
	// owned_credentials is jsonb, PostgreSQL guarantees valid JSON at insert
	// time, so no text-shape guard is needed here.
	baseCTE := fmt.Sprintf(`
		WITH flattened_creds AS (
			-- PART 1: Traditional credentials extracted from owned_credentials JSON
			SELECT
				i.id AS identity_id,
				i.arn AS identity_arn,
				i.name AS identity_name,
				i.identity_type,
				i.scan_id,
				elem ->> 'type'             AS cred_type,
				elem ->> 'id'               AS cred_id,
				elem ->> 'status'           AS cred_status,
				elem ->> 'severity'         AS cred_severity,
				elem ->> 'created_at'       AS created_at,
				elem ->> 'expires_at'       AS expires_at,
				elem ->> 'last_used_date'   AS last_used_date,
				elem ->> 'last_used_service' AS last_used_service,
				elem ->> 'description'      AS description
			FROM %[1]s.nhi_identities_aws i,
			     jsonb_array_elements(COALESCE(i.owned_credentials, '[]'::jsonb)) AS elem
			WHERE i.owned_credentials IS NOT NULL
			  AND i.owned_credentials <> '[]'::jsonb
			  AND i.owned_credentials <> 'null'::jsonb

			UNION ALL

			-- PART 2: IAM Roles surfaced as first-class credential entries
			SELECT
				i.id AS identity_id,
				i.arn AS identity_arn,
				i.name AS identity_name,
				i.identity_type,
				i.scan_id,
				'IAM_ROLE' AS cred_type,
				i.arn AS cred_id,
				'Active' AS cred_status,
				CASE 
					WHEN i.is_admin IS TRUE         THEN 'CRITICAL'
					WHEN i.classification = 'HUMAN' THEN 'HIGH'
					WHEN i.classification = 'NHI_CICD' THEN 'MEDIUM'
					ELSE 'LOW'
				END AS cred_severity,
				to_char(i.created_at, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at,
				NULL::text AS expires_at,
				to_char(i.last_active, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS last_used_date,
				COALESCE(i.trust_service, 'AWS STS') AS last_used_service,
				'IAM Role (' || COALESCE(i.classification, 'UNCLASSIFIED') || ') — Trust: ' || COALESCE(i.trust_type, 'N/A') AS description
			FROM %[1]s.nhi_identities_aws i
			WHERE i.identity_type = 'IAM_ROLE'
		)`, Schema)

	// 2. Count Total Matches
	countQuery := fmt.Sprintf("%s SELECT COUNT(*) FROM flattened_creds %s", baseCTE, whereSection)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count flattened credentials: %w", err)
	}

	// 3. Paginated Fetch — Oracle OFFSET/FETCH replaced with LIMIT/OFFSET.
	dataQuery := fmt.Sprintf(`
		%s
		SELECT identity_id, identity_arn, identity_name, identity_type, scan_id,
		       cred_type, cred_id, cred_status, cred_severity,
		       created_at, expires_at, last_used_date, last_used_service, description
		FROM flattened_creds
		%s
		ORDER BY 
			CASE cred_severity 
				WHEN 'CRITICAL' THEN 1
				WHEN 'HIGH' THEN 2
				WHEN 'MEDIUM' THEN 3
				WHEN 'LOW' THEN 4
				ELSE 5
			END,
			identity_name ASC
		LIMIT $%d OFFSET $%d`, baseCTE, whereSection, argIdx+1, argIdx)

	args = append(args, filter.Offset, filter.Limit)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query flattened credentials: %w", err)
	}
	defer rows.Close()

	var list []models.FlattenedCredential
	for rows.Next() {
		var c models.FlattenedCredential
		var idName, idARN, idType, scanID sql.NullString
		var cType, cID, cStatus, cSeverity sql.NullString
		var cCreated, cExpires, cLastUsed, cLastUsedSvc, cDesc sql.NullString

		err := rows.Scan(
			&c.IdentityID, &idARN, &idName, &idType, &scanID,
			&cType, &cID, &cStatus, &cSeverity,
			&cCreated, &cExpires, &cLastUsed, &cLastUsedSvc, &cDesc,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan credential row: %w", err)
		}

		c.IdentityARN = idARN.String
		c.IdentityName = idName.String
		c.IdentityType = idType.String
		c.ScanID = scanID.String
		c.Type = cType.String
		c.CredID = cID.String
		c.Status = cStatus.String
		c.Severity = cSeverity.String
		c.CreatedAt = cCreated.String
		c.ExpiresAt = cExpires.String
		c.LastUsedDate = cLastUsed.String
		c.LastUsedService = cLastUsedSvc.String
		c.Description = cDesc.String

		list = append(list, c)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate credential rows: %w", err)
	}

	return list, totalCount, nil
}
