package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"nhi-backend-api/internal/models"
)

const identityDetailColumns = `
			id, scan_id, arn, account_id, name, identity_type,
			classification, matched_rules, evidence, trust_type, trust_service,
			total_events, last_active, owner_name, owner_type, created_at,
			primary_owner, created_by_name, is_secret, owned_credentials, attached_policies,
			is_admin, groups_list, console_access, console_last_signin, mfa_enabled,
			password_age_days, access_key_1_id, access_key_1_age_days, access_key_last_used, relationships,
			bound_cred_type, bound_cred_assumed_via, bound_cred_policies, overview_bound_cred, overview_permissions,
			overview_discovery, overview_tags, overview_risk_factors, full_profile_json, discovered_at`

func (r *IdentityDetailsRepository) GetByID(ctx context.Context, id int) (*models.IdentityDetail, error) {
	// Oracle: WHERE id = :1  →  PostgreSQL: WHERE id = $1
	query := `SELECT ` + identityDetailColumns + `
		FROM ` + Schema + `.nhi_identity_details
		WHERE id = $1`

	row := r.db.DB.QueryRowContext(ctx, query, id)

	var item models.IdentityDetail
	var (
		scanID, arn, accountID, name, identityType, classification   sql.NullString
		matchedRules, evidence, trustType, trustService              sql.NullString
		ownerName, ownerType, primaryOwner, createdByName            sql.NullString
		ownedCreds, attachedPolicies, groupsList                     sql.NullString
		consoleAccess, accessKey1ID, relationships                   sql.NullString
		boundCredType, boundCredAssumedVia, boundCredPolicies        sql.NullString
		overviewBoundCred, overviewPerms, overviewDisc, overviewTags sql.NullString
		overviewRiskFactors, fullProfileJSON                         sql.NullString
	)

	// NUMBER(1) 0/1 flags → PostgreSQL booleans, so NullBool not NullInt64.
	var (
		totalEvents                       sql.NullInt64
		isSecret, isAdmin, mfaEnabled     sql.NullBool
		pwdAge, accKeyAge                 sql.NullInt64
		lastActive, createdAt             sql.NullTime
		consoleLastSignin, accKeyLastUsed sql.NullTime
		discAt                            sql.NullTime
	)

	// owned_credentials and full_profile_json are jsonb. Both drivers return
	// jsonb as []byte and sql.NullString.Scan converts []byte to string, so
	// the model keeps receiving plain strings.
	err := row.Scan(
		&item.ID, &scanID, &arn, &accountID, &name, &identityType,
		&classification, &matchedRules, &evidence, &trustType, &trustService,
		&totalEvents, &lastActive, &ownerName, &ownerType, &createdAt,
		&primaryOwner, &createdByName, &isSecret, &ownedCreds, &attachedPolicies,
		&isAdmin, &groupsList, &consoleAccess, &consoleLastSignin, &mfaEnabled,
		&pwdAge, &accessKey1ID, &accKeyAge, &accKeyLastUsed, &relationships,
		&boundCredType, &boundCredAssumedVia, &boundCredPolicies, &overviewBoundCred, &overviewPerms,
		&overviewDisc, &overviewTags, &overviewRiskFactors, &fullProfileJSON, &discAt,
	)
	// Oracle used a bare ==; errors.Is also catches driver-wrapped values.
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get identity detail by id: %w", err)
	}

	item.ScanID = scanID.String
	item.ARN = arn.String
	item.AccountID = accountID.String
	item.Name = name.String
	item.IdentityType = identityType.String
	item.Classification = classification.String
	item.MatchedRules = matchedRules.String
	item.Evidence = evidence.String
	item.TrustType = trustType.String
	item.TrustService = trustService.String
	item.OwnerName = ownerName.String
	item.OwnerType = ownerType.String
	item.PrimaryOwner = primaryOwner.String
	item.CreatedByName = createdByName.String
	item.OwnedCredentials = ownedCreds.String
	item.AttachedPolicies = attachedPolicies.String
	item.GroupsList = groupsList.String
	item.ConsoleAccess = consoleAccess.String
	item.AccessKey1ID = accessKey1ID.String
	item.Relationships = relationships.String
	item.BoundCredType = boundCredType.String
	item.BoundCredAssumedVia = boundCredAssumedVia.String
	item.BoundCredPolicies = boundCredPolicies.String
	item.OverviewBoundCred = overviewBoundCred.String
	item.OverviewPermissions = overviewPerms.String
	item.OverviewDiscovery = overviewDisc.String
	item.OverviewTags = overviewTags.String
	item.OverviewRiskFactors = overviewRiskFactors.String
	item.FullProfileJSON = fullProfileJSON.String

	if totalEvents.Valid {
		item.TotalEvents = int(totalEvents.Int64)
	}
	if isSecret.Valid {
		item.IsSecret = isSecret.Bool
	}
	if isAdmin.Valid {
		item.IsAdmin = isAdmin.Bool
	}
	if mfaEnabled.Valid {
		item.MFAEnabled = mfaEnabled.Bool
	}
	if pwdAge.Valid {
		item.PasswordAgeDays = int(pwdAge.Int64)
	}
	if accKeyAge.Valid {
		item.AccessKey1AgeDays = int(accKeyAge.Int64)
	}

	if lastActive.Valid {
		item.LastActive = &lastActive.Time
	}
	if createdAt.Valid {
		item.CreatedAt = &createdAt.Time
	}
	if consoleLastSignin.Valid {
		item.ConsoleLastSignin = &consoleLastSignin.Time
	}
	if accKeyLastUsed.Valid {
		item.AccessKeyLastUsed = &accKeyLastUsed.Time
	}
	if discAt.Valid {
		item.DiscoveredAt = &discAt.Time
	}

	return &item, nil
}
