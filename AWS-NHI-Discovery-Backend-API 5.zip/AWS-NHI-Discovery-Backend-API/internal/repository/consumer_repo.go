package repository

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"time"
)

type RoleConsumer struct {
	CallerARN    string    `json:"caller_arn"`
	CallerType   string    `json:"caller_type"`
	SourceIP     string    `json:"source_ip"`
	UserAgent    string    `json:"user_agent"`
	Region       string    `json:"region"`
	SessionCount int       `json:"session_count"`
	FirstAssumed time.Time `json:"first_assumed"`
	LastAssumed  time.Time `json:"last_assumed"`
}

type ConsumerRepository struct {
	db *PostgresDB
}

func NewConsumerRepository(db *PostgresDB) *ConsumerRepository {
	return &ConsumerRepository{db: db}
}

func (r *ConsumerRepository) GetRoleConsumers(ctx context.Context, roleARN, scanID string, offset, limit int) ([]RoleConsumer, int, error) {
	consumers := make([]RoleConsumer, 0)
	var totalCount int

	// 1. Total Distinct Consumers Count Query
	//    NVL → COALESCE throughout. The GROUP BY expression must match the
	//    SELECT expression exactly in PostgreSQL, so both use COALESCE.
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*) FROM (
			SELECT COALESCE(caller_arn, 'Unknown Principal'),
			       COALESCE(caller_type, 'Unknown'),
			       COALESCE(source_ip, 'N/A'),
			       COALESCE(user_agent, 'AWS SDK'),
			       COALESCE(region, 'N/A')
			FROM %s.nhi_events_aws
			WHERE identity_arn = $1
			  AND event_name LIKE 'AssumeRole%%'
	`, Schema)
	countArgs := []interface{}{roleARN}
	if scanID != "" {
		countQuery += ` AND scan_id = $2`
		countArgs = append(countArgs, scanID)
	}
	countQuery += ` GROUP BY COALESCE(caller_arn, 'Unknown Principal'), COALESCE(caller_type, 'Unknown'), COALESCE(source_ip, 'N/A'), COALESCE(user_agent, 'AWS SDK'), COALESCE(region, 'N/A')) AS consumers`

	err := r.db.DB.QueryRowContext(ctx, countQuery, countArgs...).Scan(&totalCount)
	if err != nil {
		log.Printf("[DB ERROR] Count consumers: %v", err)
		return consumers, 0, fmt.Errorf("count role consumers: %w", err)
	}

	if totalCount == 0 {
		return consumers, 0, nil
	}

	// 2. Fetch Grouped Consumers with PostgreSQL pagination
	//
	// ── The Oracle ROWNUM dance ────────────────────────────────────────
	//	SELECT * FROM (
	//	    SELECT a.*, ROWNUM rnum FROM (
	//	        SELECT … ORDER BY MAX(event_time) DESC
	//	    ) a WHERE ROWNUM <= :n
	//	) WHERE rnum > :m
	//
	// ── The PostgreSQL equivalent ──────────────────────────────────────
	//	SELECT … ORDER BY MAX(event_time) DESC LIMIT $n OFFSET $m
	//
	// LIMIT/OFFSET is not just shorter: the ROWNUM version applied ROWNUM
	// *before* the ordering was meaningful in some Oracle versions and
	// forced a stray rnum column into the scan. LIMIT/OFFSET applies the
	// ORDER BY first, which is what was actually intended, and removes the
	// rnum column from the result set entirely.
	var query string
	var queryArgs []interface{}
	if scanID != "" {
		query = fmt.Sprintf(`
			SELECT
				COALESCE(caller_arn, 'Unknown Principal') AS caller_arn,
				COALESCE(caller_type, 'Unknown') AS caller_type,
				COALESCE(source_ip, 'N/A') AS source_ip,
				COALESCE(user_agent, 'AWS SDK') AS user_agent,
				COALESCE(region, 'N/A') AS region,
				COUNT(*) AS session_count,
				COALESCE(to_char(MIN(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS first_str,
				COALESCE(to_char(MAX(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS last_str
			FROM %s.nhi_events_aws
			WHERE identity_arn = $1 
			  AND event_name LIKE 'AssumeRole%%' 
			  AND scan_id = $2
			GROUP BY COALESCE(caller_arn, 'Unknown Principal'), COALESCE(caller_type, 'Unknown'), COALESCE(source_ip, 'N/A'), COALESCE(user_agent, 'AWS SDK'), COALESCE(region, 'N/A')
			ORDER BY MAX(event_time) DESC
			LIMIT $3 OFFSET $4
		`, Schema)
		queryArgs = []interface{}{roleARN, scanID, limit, offset}
	} else {
		query = fmt.Sprintf(`
			SELECT
				COALESCE(caller_arn, 'Unknown Principal') AS caller_arn,
				COALESCE(caller_type, 'Unknown') AS caller_type,
				COALESCE(source_ip, 'N/A') AS source_ip,
				COALESCE(user_agent, 'AWS SDK') AS user_agent,
				COALESCE(region, 'N/A') AS region,
				COUNT(*) AS session_count,
				COALESCE(to_char(MIN(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS first_str,
				COALESCE(to_char(MAX(event_time), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), '') AS last_str
			FROM %s.nhi_events_aws
			WHERE identity_arn = $1 
			  AND event_name LIKE 'AssumeRole%%'
			GROUP BY COALESCE(caller_arn, 'Unknown Principal'), COALESCE(caller_type, 'Unknown'), COALESCE(source_ip, 'N/A'), COALESCE(user_agent, 'AWS SDK'), COALESCE(region, 'N/A')
			ORDER BY MAX(event_time) DESC
			LIMIT $2 OFFSET $3
		`, Schema)
		queryArgs = []interface{}{roleARN, limit, offset}
	}

	rows, err := r.db.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		log.Printf("[DB ERROR] Query consumers: %v", err)
		return consumers, totalCount, fmt.Errorf("query role consumers: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var c RoleConsumer
		var firstStr, lastStr sql.NullString
		// The Oracle version scanned an rnum column; LIMIT/OFFSET removes it.

		if err := rows.Scan(
			&c.CallerARN,
			&c.CallerType,
			&c.SourceIP,
			&c.UserAgent,
			&c.Region,
			&c.SessionCount,
			&firstStr,
			&lastStr,
		); err != nil {
			log.Printf("[DB ERROR] Scan consumer row: %v", err)
			continue
		}

		if firstStr.Valid && firstStr.String != "" {
			if t, err := time.Parse(time.RFC3339, firstStr.String); err == nil {
				c.FirstAssumed = t
			}
		}
		if lastStr.Valid && lastStr.String != "" {
			if t, err := time.Parse(time.RFC3339, lastStr.String); err == nil {
				c.LastAssumed = t
			}
		}

		consumers = append(consumers, c)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB ERROR] Iterate consumer rows: %v", err)
		return consumers, totalCount, fmt.Errorf("iterate role consumers: %w", err)
	}

	return consumers, totalCount, nil
}
