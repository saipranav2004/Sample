package dashboard

import (
	"context"
	"fmt"
	"strings"

	modelsdashboard "nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesByClassRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesByClassRepository(db *repository.PostgresDB) *IdentitiesByClassRepository {
	return &IdentitiesByClassRepository{db: db}
}

func (r *IdentitiesByClassRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return r.existsIn(ctx, "account_id", accountID)
}
func (r *IdentitiesByClassRepository) RegionExists(ctx context.Context, region string) (bool, error) {
	return r.existsIn(ctx, "region", region)
}

func (r *IdentitiesByClassRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL)`, repository.Schema, column)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
		return false, fmt.Errorf("check %s exists: %w", column, err)
	}
	return exists, nil
}

func (r *IdentitiesByClassRepository) buildWhere(f modelsdashboard.IdentityByClassFilter) (string, []interface{}) {
	clauses := []string{"deleted_at IS NULL"}
	args := []interface{}{}
	idx := 1
	if f.AccountID != "" {
		clauses = append(clauses, fmt.Sprintf("account_id = $%d", idx))
		args = append(args, f.AccountID)
		idx++
	}
	if f.Region != "" {
		clauses = append(clauses, fmt.Sprintf("region = $%d", idx))
		args = append(args, f.Region)
		idx++
	}
	return strings.Join(clauses, " AND "), args
}

func (r *IdentitiesByClassRepository) ByClass(ctx context.Context, f modelsdashboard.IdentityByClassFilter) (*modelsdashboard.IdentitiesByClassResponse, error) {
	where, args := r.buildWhere(f)

	query := fmt.Sprintf(`
		SELECT COALESCE(functional_class, 'unclassified') AS functional_class, COUNT(*) AS cnt
		FROM %s.identities
		WHERE %s
		GROUP BY functional_class
		ORDER BY cnt DESC, functional_class ASC
	`, repository.Schema, where)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("identities by class: %w", err)
	}
	defer rows.Close()

	breakdown := make([]modelsdashboard.IdentityClassCount, 0)
	total := 0
	for rows.Next() {
		var row modelsdashboard.IdentityClassCount
		if err := rows.Scan(&row.FunctionalClass, &row.Count); err != nil {
			return nil, fmt.Errorf("scan identity class count: %w", err)
		}
		total += row.Count
		breakdown = append(breakdown, row)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return &modelsdashboard.IdentitiesByClassResponse{
		Total:     total,
		Breakdown: breakdown,
	}, nil
}