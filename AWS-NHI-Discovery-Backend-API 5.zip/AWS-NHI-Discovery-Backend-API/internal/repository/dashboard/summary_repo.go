package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type SummaryFilter struct {
	AccountID string
	Region    string
}

type SummaryRepository struct {
	db *repository.PostgresDB
}

func NewSummaryRepository(db *repository.PostgresDB) *SummaryRepository {
	return &SummaryRepository{db: db}
}

// buildFilter returns an " AND ..." clause (empty if no filters), its args,
// and the next available placeholder index — useful for chaining into UNION queries.
func (r *SummaryRepository) buildFilter(f SummaryFilter, startIdx int) (string, []interface{}, int) {
	var conditions []string
	var args []interface{}
	idx := startIdx

	if f.AccountID != "" {
		conditions = append(conditions, fmt.Sprintf("account_id = $%d", idx))
		args = append(args, f.AccountID)
		idx++
	}

	if f.Region != "" {
		conditions = append(conditions, fmt.Sprintf("region = $%d", idx))
		args = append(args, f.Region)
		idx++
	}

	if len(conditions) == 0 {
		return "", nil, idx
	}

	return " AND " + strings.Join(conditions, " AND "), args, idx
}

func (r *SummaryRepository) Summary(ctx context.Context, f SummaryFilter) (*models.DashboardSummaryResponse, error) {
	resp := &models.DashboardSummaryResponse{}

	// --- total_identities ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL%s`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.TotalIdentities); err != nil {
			return nil, fmt.Errorf("count total identities: %w", err)
		}
	}

	// --- total_credentials ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.credentials WHERE deleted_at IS NULL%s`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.TotalCredentials); err != nil {
			return nil, fmt.Errorf("count total credentials: %w", err)
		}
	}

	// --- total_accounts_scanned & total_regions_scanned (union of both tables) ---
	{
		clauseI, argsI, nextIdx := r.buildFilter(f, 1)
		clauseC, argsC, _ := r.buildFilter(f, nextIdx)

		query := fmt.Sprintf(`
			SELECT COUNT(DISTINCT account_id), COUNT(DISTINCT region)
			FROM (
				SELECT account_id, region FROM %s.identities WHERE deleted_at IS NULL%s
				UNION
				SELECT account_id, region FROM %s.credentials WHERE deleted_at IS NULL%s
			) combined
		`, repository.Schema, clauseI, repository.Schema, clauseC)

		args := append(argsI, argsC...)

		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.TotalAccountsScanned, &resp.TotalRegionsScanned); err != nil {
			return nil, fmt.Errorf("count accounts/regions scanned: %w", err)
		}
	}

	// // --- identities_by_status ---
	// {
	// 	clause, args, _ := r.buildFilter(f, 1)
	// 	query := fmt.Sprintf(`
	// 		SELECT status, COUNT(*)
	// 		FROM %s.identities
	// 		WHERE deleted_at IS NULL%s
	// 		GROUP BY status
	// 	`, repository.Schema, clause)

	// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	// 	if err != nil {
	// 		return nil, fmt.Errorf("count identities by status: %w", err)
	// 	}
	// 	defer rows.Close()

	// 	for rows.Next() {
	// 		var status string
	// 		var count int
	// 		if err := rows.Scan(&status, &count); err != nil {
	// 			return nil, fmt.Errorf("scan identity status count: %w", err)
	// 		}
	// 		switch strings.ToLower(status) {
	// 		case "active":
	// 			resp.IdentitiesByStatus.Active = count
	// 		case "stopped":
	// 			resp.IdentitiesByStatus.Stopped = count
	// 		case "terminated":
	// 			resp.IdentitiesByStatus.Terminated = count
	// 		}
	// 	}
	// 	if err := rows.Err(); err != nil {
	// 		return nil, fmt.Errorf("iterate identity status counts: %w", err)
	// 	}
	// }



	// --- identities_by_status ---
{
	clause, args, _ := r.buildFilter(f, 1)
	query := fmt.Sprintf(`
		SELECT COALESCE(status, 'unknown'), COUNT(*)
		FROM %s.identities
		WHERE deleted_at IS NULL%s
		GROUP BY status
	`, repository.Schema, clause)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("count identities by status: %w", err)
	}
	defer rows.Close()

	resp.IdentitiesByStatus = make(map[string]int)
	for rows.Next() {
		var status string
		var count int
		if err := rows.Scan(&status, &count); err != nil {
			return nil, fmt.Errorf("scan identity status count: %w", err)
		}
		resp.IdentitiesByStatus[strings.ToLower(status)] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identity status counts: %w", err)
	}
}

	// // --- credentials_by_status ---
	// {
	// 	clause, args, _ := r.buildFilter(f, 1)
	// 	query := fmt.Sprintf(`
	// 		SELECT status, COUNT(*)
	// 		FROM %s.credentials
	// 		WHERE deleted_at IS NULL%s
	// 		GROUP BY status
	// 	`, repository.Schema, clause)

	// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	// 	if err != nil {
	// 		return nil, fmt.Errorf("count credentials by status: %w", err)
	// 	}
	// 	defer rows.Close()

	// 	for rows.Next() {
	// 		var status string
	// 		var count int
	// 		if err := rows.Scan(&status, &count); err != nil {
	// 			return nil, fmt.Errorf("scan credential status count: %w", err)
	// 		}
	// 		switch strings.ToLower(status) {
	// 		case "active":
	// 			resp.CredentialsByStatus.Active = count
	// 		case "inactive":
	// 			resp.CredentialsByStatus.Inactive = count
	// 		case "expired":
	// 			resp.CredentialsByStatus.Expired = count
	// 		case "unknown":
	// 			resp.CredentialsByStatus.Unknown = count
	// 		}
	// 	}
	// 	if err := rows.Err(); err != nil {
	// 		return nil, fmt.Errorf("iterate credential status counts: %w", err)
	// 	}
	// }





	// --- credentials_by_status ---
{
	clause, args, _ := r.buildFilter(f, 1)
	query := fmt.Sprintf(`
		SELECT COALESCE(status, 'unknown'), COUNT(*)
		FROM %s.credentials
		WHERE deleted_at IS NULL%s
		GROUP BY status
	`, repository.Schema, clause)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("count credentials by status: %w", err)
	}
	defer rows.Close()

	resp.CredentialsByStatus = make(map[string]int)
	for rows.Next() {
		var status string
		var count int
		if err := rows.Scan(&status, &count); err != nil {
			return nil, fmt.Errorf("scan credential status count: %w", err)
		}
		resp.CredentialsByStatus[strings.ToLower(status)] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential status counts: %w", err)
	}
}

	// --- new_identities_last_24h ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`
			SELECT COUNT(*) FROM %s.identities
			WHERE deleted_at IS NULL AND first_seen_at >= NOW() - INTERVAL '24 hours'%s
		`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.NewIdentitiesLast24h); err != nil {
			return nil, fmt.Errorf("count new identities last 24h: %w", err)
		}
	}

	// --- removed_identities_last_24h ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`
			SELECT COUNT(*) FROM %s.identities
			WHERE deleted_at IS NOT NULL AND deleted_at >= NOW() - INTERVAL '24 hours'%s
		`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.RemovedIdentitiesLast24h); err != nil {
			return nil, fmt.Errorf("count removed identities last 24h: %w", err)
		}
	}

	// --- new_credentials_last_24h ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`
			SELECT COUNT(*) FROM %s.credentials
			WHERE deleted_at IS NULL AND first_seen_at >= NOW() - INTERVAL '24 hours'%s
		`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.NewCredentialsLast24h); err != nil {
			return nil, fmt.Errorf("count new credentials last 24h: %w", err)
		}
	}

	// --- expiring_credentials_30d ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`
			SELECT COUNT(*) FROM %s.credentials
			WHERE deleted_at IS NULL AND expires_at IS NOT NULL
			  AND expires_at BETWEEN NOW() AND NOW() + INTERVAL '30 days'%s
		`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.ExpiringCredentials30d); err != nil {
			return nil, fmt.Errorf("count expiring credentials 30d: %w", err)
		}
	}

	// // --- stale_credentials_90d ---
	// {
	// 	clause, args, _ := r.buildFilter(f, 1)
	// 	query := fmt.Sprintf(`
	// 		SELECT COUNT(*) FROM %s.credentials
	// 		WHERE deleted_at IS NULL
	// 		  AND (last_used_at IS NULL OR last_used_at < NOW() - INTERVAL '90 days')%s
	// 	`, repository.Schema, clause)
	// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.StaleCredentials90d); err != nil {
	// 		return nil, fmt.Errorf("count stale credentials 90d: %w", err)
	// 	}
	// }




	// --- stale_credentials_90d ---
{
	clause, args, _ := r.buildFilter(f, 1)
	query := fmt.Sprintf(`
		SELECT COUNT(*) FROM %s.credentials
		WHERE deleted_at IS NULL
		  AND last_used_at IS NOT NULL
		  AND last_used_at < NOW() - INTERVAL '90 days'
		  AND LOWER(COALESCE(status, '')) = 'active'%s
	`, repository.Schema, clause)
	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.StaleCredentials90d); err != nil {
		return nil, fmt.Errorf("count stale credentials 90d: %w", err)
	}
}

	// // --- unrotated_credentials ---
	// {
	// 	clause, args, _ := r.buildFilter(f, 1)
	// 	query := fmt.Sprintf(`
	// 		SELECT COUNT(*) FROM %s.credentials
	// 		WHERE deleted_at IS NULL AND rotation_enabled = false%s
	// 	`, repository.Schema, clause)
	// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.UnrotatedCredentials); err != nil {
	// 		return nil, fmt.Errorf("count unrotated credentials: %w", err)
	// 	}
	// }




		// --- unrotated_credentials ---
	{
		clause, args, _ := r.buildFilter(f, 1)
		query := fmt.Sprintf(`
			SELECT COUNT(*) FROM %s.credentials
			WHERE deleted_at IS NULL
			AND (last_rotated_at IS NULL OR last_rotated_at < NOW() - INTERVAL '90 days')%s
		`, repository.Schema, clause)
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&resp.UnrotatedCredentials); err != nil {
			return nil, fmt.Errorf("count unrotated credentials: %w", err)
		}
	}

	// --- last_scan_at (derived: most recent last_seen_at across both tables) ---
	{
		clauseI, argsI, nextIdx := r.buildFilter(f, 1)
		clauseC, argsC, _ := r.buildFilter(f, nextIdx)

		query := fmt.Sprintf(`
			SELECT MAX(last_seen_at) FROM (
				SELECT last_seen_at FROM %s.identities WHERE deleted_at IS NULL%s
				UNION ALL
				SELECT last_seen_at FROM %s.credentials WHERE deleted_at IS NULL%s
			) combined
		`, repository.Schema, clauseI, repository.Schema, clauseC)

		args := append(argsI, argsC...)

		var lastScanAt sql.NullTime
		if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&lastScanAt); err != nil {
			return nil, fmt.Errorf("fetch last scan at: %w", err)
		}
		if lastScanAt.Valid {
			resp.LastScanAt = &lastScanAt.Time
		}
	}

	// NOTE: scan_duration_seconds / scan_status cannot be derived from the
	// identities/credentials tables alone (no dedicated scans table used here).
	// Defaulted for now — wire up a real scans table/service later if needed.
	resp.ScanDurationSeconds = 0
	resp.ScanStatus = "completed"

	return resp, nil
}