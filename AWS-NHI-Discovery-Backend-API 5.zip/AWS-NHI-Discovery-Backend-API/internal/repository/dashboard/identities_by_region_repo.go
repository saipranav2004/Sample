// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByRegionFilter struct {
// 	AccountID    string
// 	IdentityType string
// }

// type IdentitiesByRegionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
// 	return &IdentitiesByRegionRepository{db: db}
// }

// func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
// 	identityCounts := make(map[string]int)
// 	credentialCounts := make(map[string]int)

// 	// --- identity_count per region (filters: account_id, identity_type) ---
// 	{
// 		conditions := "deleted_at IS NULL"
// 		var args []interface{}
// 		argIdx := 1

// 		if f.AccountID != "" {
// 			conditions += fmt.Sprintf(" AND account_id = $%d", argIdx)
// 			args = append(args, f.AccountID)
// 			argIdx++
// 		}

// 		if f.IdentityType != "" {
// 			conditions += fmt.Sprintf(" AND identity_type = $%d", argIdx)
// 			args = append(args, f.IdentityType)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT region, COUNT(*)
// 			FROM %s.identities
// 			WHERE %s
// 			GROUP BY region
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count identities by region: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var region string
// 			var count int
// 			if err := rows.Scan(&region, &count); err != nil {
// 				return nil, fmt.Errorf("scan identity region count: %w", err)
// 			}
// 			identityCounts[region] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate identity region counts: %w", err)
// 		}
// 	}

// 	// --- credential_count per region (filter: account_id only — credentials table has no identity_type) ---
// 	{
// 		conditions := "deleted_at IS NULL"
// 		var args []interface{}
// 		argIdx := 1

// 		if f.AccountID != "" {
// 			conditions += fmt.Sprintf(" AND account_id = $%d", argIdx)
// 			args = append(args, f.AccountID)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT region, COUNT(*)
// 			FROM %s.credentials
// 			WHERE %s
// 			GROUP BY region
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count credentials by region: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var region string
// 			var count int
// 			if err := rows.Scan(&region, &count); err != nil {
// 				return nil, fmt.Errorf("scan credential region count: %w", err)
// 			}
// 			credentialCounts[region] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate credential region counts: %w", err)
// 		}
// 	}

// 	// --- merge both maps into a unified set of regions ---
// 	regionSet := make(map[string]struct{})
// 	for region := range identityCounts {
// 		regionSet[region] = struct{}{}
// 	}
// 	for region := range credentialCounts {
// 		regionSet[region] = struct{}{}
// 	}

// 	breakdown := make([]models.RegionIdentityBreakdown, 0, len(regionSet))
// 	for region := range regionSet {
// 		breakdown = append(breakdown, models.RegionIdentityBreakdown{
// 			Region:          region,
// 			IdentityCount:   identityCounts[region],
// 			CredentialCount: credentialCounts[region],
// 		})
// 	}

// 	return &models.IdentitiesByRegionResponse{
// 		TotalRegions: len(breakdown),
// 		Breakdown:    breakdown,
// 	}, nil
// }



















// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByRegionFilter struct {
// 	AccountID    string
// 	IdentityType string
// }

// type IdentitiesByRegionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
// 	return &IdentitiesByRegionRepository{db: db}
// }

// // Breakdown returns identity_count and credential_count grouped by region.
// // Uses a single SQL query (UNION ALL + outer GROUP BY) instead of merging two
// // separate Go-side maps, so filters apply consistently and NULL regions are
// // handled by the database itself via COALESCE — no fabricated/default values.
// func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
// 	query := fmt.Sprintf(`
// 		SELECT
// 			combined.region,
// 			SUM(combined.identity_count)::int   AS identity_count,
// 			SUM(combined.credential_count)::int AS credential_count
// 		FROM (
// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				COUNT(*) AS identity_count,
// 				0        AS credential_count
// 			FROM %s.identities
// 			WHERE deleted_at IS NULL
// 			  AND ($1 = '' OR account_id = $1)
// 			  AND ($2 = '' OR identity_type = $2)
// 			GROUP BY COALESCE(region, 'unknown')

// 			UNION ALL

// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				0 AS identity_count,
// 				COUNT(*) AS credential_count
// 			FROM %s.credentials
// 			WHERE deleted_at IS NULL
// 			  AND ($1 = '' OR account_id = $1)
// 			GROUP BY COALESCE(region, 'unknown')
// 		) combined
// 		GROUP BY combined.region
// 		ORDER BY combined.region`,
// 		repository.Schema, repository.Schema)

// 	rows, err := r.db.DB.QueryContext(ctx, query, f.AccountID, f.IdentityType)
// 	if err != nil {
// 		return nil, fmt.Errorf("identities by region breakdown: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]models.RegionIdentityBreakdown, 0)
// 	for rows.Next() {
// 		var row models.RegionIdentityBreakdown
// 		if err := rows.Scan(&row.Region, &row.IdentityCount, &row.CredentialCount); err != nil {
// 			return nil, fmt.Errorf("scan region breakdown row: %w", err)
// 		}
// 		breakdown = append(breakdown, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate region breakdown rows: %w", err)
// 	}

// 	return &models.IdentitiesByRegionResponse{
// 		TotalRegions: len(breakdown),
// 		Breakdown:    breakdown,
// 	}, nil
// }














package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesByRegionFilter struct {
	AccountID    string
	IdentityType string
}

type IdentitiesByRegionRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
	return &IdentitiesByRegionRepository{db: db}
}

// ValidIdentityType checks whether the given identity_type value actually
// exists in the identities table — queried live, not hardcoded.
func (r *IdentitiesByRegionRepository) ValidIdentityType(ctx context.Context, identityType string) (bool, error) {
	if identityType == "" {
		return true, nil // empty = no filter, always valid
	}
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1 FROM %s.identities WHERE identity_type = $1
		)`, repository.Schema)

	var exists bool
	err := r.db.DB.QueryRowContext(ctx, query, identityType).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("validate identity_type: %w", err)
	}
	return exists, nil
}

func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
	query := fmt.Sprintf(`
		SELECT
			combined.region,
			SUM(combined.identity_count)::int   AS identity_count,
			SUM(combined.credential_count)::int AS credential_count
		FROM (
			SELECT
				COALESCE(region, 'unknown') AS region,
				COUNT(*) AS identity_count,
				0        AS credential_count
			FROM %s.identities
			WHERE deleted_at IS NULL
			  AND ($1 = '' OR account_id = $1)
			  AND ($2 = '' OR identity_type = $2)
			GROUP BY COALESCE(region, 'unknown')

			UNION ALL

			SELECT
				COALESCE(region, 'unknown') AS region,
				0 AS identity_count,
				COUNT(*) AS credential_count
			FROM %s.credentials
			WHERE deleted_at IS NULL
			  AND ($1 = '' OR account_id = $1)
			GROUP BY COALESCE(region, 'unknown')
		) combined
		GROUP BY combined.region
		ORDER BY combined.region`,
		repository.Schema, repository.Schema)

	rows, err := r.db.DB.QueryContext(ctx, query, f.AccountID, f.IdentityType)
	if err != nil {
		return nil, fmt.Errorf("identities by region breakdown: %w", err)
	}
	defer rows.Close()

	breakdown := make([]models.RegionIdentityBreakdown, 0)
	for rows.Next() {
		var row models.RegionIdentityBreakdown
		if err := rows.Scan(&row.Region, &row.IdentityCount, &row.CredentialCount); err != nil {
			return nil, fmt.Errorf("scan region breakdown row: %w", err)
		}
		breakdown = append(breakdown, row)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate region breakdown rows: %w", err)
	}

	return &models.IdentitiesByRegionResponse{
		TotalRegions: len(breakdown),
		Breakdown:    breakdown,
	}, nil
}