package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type FiltersRepository struct {
	db *repository.PostgresDB
}

func NewFiltersRepository(db *repository.PostgresDB) *FiltersRepository {
	return &FiltersRepository{db: db}
}

// distinctFromTable returns all distinct non-empty values for a given column
// in a given table. Only ever call with fixed, hardcoded literals (never
// user input) to avoid SQL injection.
func (r *FiltersRepository) distinctFromTable(ctx context.Context, table, column string) ([]string, error) {
	query := fmt.Sprintf(`
		SELECT %[3]s
		FROM %[1]s.%[2]s
		WHERE %[3]s IS NOT NULL AND TRIM(%[3]s) <> ''
		GROUP BY %[3]s
		ORDER BY %[3]s ASC
	`, repository.Schema, table, column)

	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	values := make([]string, 0)
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			return nil, err
		}
		values = append(values, v)
	}
	return values, rows.Err()
}

// distinctUnion merges distinct non-empty values of the same column name
// across two tables (e.g. account_id/region/status exist on both
// identities and credentials).
func (r *FiltersRepository) distinctUnion(ctx context.Context, column, tableA, tableB string) ([]string, error) {
	query := fmt.Sprintf(`
		SELECT %[2]s FROM %[1]s.%[3]s WHERE %[2]s IS NOT NULL AND TRIM(%[2]s) <> ''
		UNION
		SELECT %[2]s FROM %[1]s.%[4]s WHERE %[2]s IS NOT NULL AND TRIM(%[2]s) <> ''
		ORDER BY %[2]s ASC
	`, repository.Schema, column, tableA, tableB)

	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	values := make([]string, 0)
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			return nil, err
		}
		values = append(values, v)
	}
	return values, rows.Err()
}

func (r *FiltersRepository) GetFilters(ctx context.Context) (*models.DashboardFiltersResponse, error) {
	accounts, err := r.distinctUnion(ctx, "account_id", "identities", "credentials")
	if err != nil {
		return nil, err
	}

	regions, err := r.distinctUnion(ctx, "region", "identities", "credentials")
	if err != nil {
		return nil, err
	}

	statuses, err := r.distinctUnion(ctx, "status", "identities", "credentials")
	if err != nil {
		return nil, err
	}

	functionalClasses, err := r.distinctFromTable(ctx, "identities", "functional_class")
	if err != nil {
		return nil, err
	}

	identityTypes, err := r.distinctFromTable(ctx, "identities", "identity_type")
	if err != nil {
		return nil, err
	}

	credentialTypes, err := r.distinctFromTable(ctx, "credentials", "credential_type")
	if err != nil {
		return nil, err
	}

	return &models.DashboardFiltersResponse{
		Accounts:          accounts,
		Regions:           regions,
		IdentityTypes:     identityTypes,
		CredentialTypes:   credentialTypes,
		FunctionalClasses: functionalClasses,
		Statuses:          statuses,
	}, nil
}