package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type ScanRepository struct {
	db *PostgresDB
}

func NewScanRepository(db *PostgresDB) *ScanRepository {
	return &ScanRepository{db: db}
}

// List returns historical scans paginated
func (r *ScanRepository) List(ctx context.Context, offset, limit int) ([]models.Scan, int, error) {
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx,
		"SELECT COUNT(*) FROM "+Schema+".nhi_scans_aws").Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count scans: %w", err)
	}

	// Oracle: OFFSET :1 ROWS FETCH NEXT :2 ROWS ONLY
	// PostgreSQL: the SQL-standard OFFSET/FETCH syntax needs PG 13+, so LIMIT
	// and OFFSET are used instead — they work on every supported version.
	query := `
		SELECT scan_id, account_id, target_name, total_identities,
		       total_events, total_secrets, status, scan_start, scan_end
		FROM ` + Schema + `.nhi_scans_aws
		ORDER BY scan_start DESC
		LIMIT $2 OFFSET $1`

	rows, err := r.db.DB.QueryContext(ctx, query, offset, limit)
	if err != nil {
		return nil, 0, fmt.Errorf("query scans: %w", err)
	}
	defer rows.Close()

	var scans []models.Scan
	for rows.Next() {
		var s models.Scan
		// scan_start is scanned through a NullTime as well, so a NULL start
		// timestamp degrades to the zero value instead of erroring out.
		var scanStart, scanEnd sql.NullTime

		err := rows.Scan(
			&s.ScanID, &s.AccountID, &s.TargetName, &s.TotalIdentities,
			&s.TotalEvents, &s.TotalSecrets, &s.Status, &scanStart, &scanEnd,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan row: %w", err)
		}

		if scanStart.Valid {
			s.ScanStart = scanStart.Time
		}
		if scanEnd.Valid {
			s.ScanEnd = &scanEnd.Time
		}

		scans = append(scans, s)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate scan rows: %w", err)
	}

	return scans, totalCount, nil
}
