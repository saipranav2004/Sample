package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type LineageRepository struct {
	db *PostgresDB
}

type LineageFilter struct {
	SourceARN string
	ScanID    string
	Offset    int
	Limit     int
}

func NewLineageRepository(db *PostgresDB) *LineageRepository {
	return &LineageRepository{db: db}
}

// GetServiceAccess retrieves a paginated slice of accessed services for an identity
func (r *LineageRepository) GetServiceAccess(ctx context.Context, filter LineageFilter) ([]models.LineageEdge, int, error) {
	scanFilter := "scan_id = " + latestCompletedScanSQL

	var countArgs []interface{}
	countArgs = append(countArgs, filter.SourceARN)

	if filter.ScanID != "" {
		scanFilter = "scan_id = $2"
		countArgs = append(countArgs, filter.ScanID)
	}

	// 1. Fetch total count of access lineage records
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM %s.nhi_lineage_aws
		WHERE source_arn = $1 AND %s`, Schema, scanFilter)

	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, countArgs...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count lineage edges: %w", err)
	}

	if totalCount == 0 {
		return []models.LineageEdge{}, 0, nil
	}

	// 2. Fetch paginated records
	offsetPos, limitPos := 2, 3
	var selectArgs []interface{}
	selectArgs = append(selectArgs, filter.SourceARN)

	if filter.ScanID != "" {
		offsetPos, limitPos = 3, 4
		selectArgs = append(selectArgs, filter.ScanID)
	}
	selectArgs = append(selectArgs, filter.Offset, filter.Limit)

	// is_external is selected as-is (no COALESCE) so the query works whether the
	// column is boolean or integer; NULL is handled in Go below.
	selectQuery := fmt.Sprintf(`
		SELECT 
			COALESCE(target_name, '—') AS target_name,
			COALESCE(target_type, '—') AS target_type,
			COALESCE(rel_type, '—') AS rel_type,
			COALESCE(direction, '—') AS direction,
			COALESCE(via, '—') AS via,
			is_external,
			COALESCE(detail, '') AS detail
		FROM %s.nhi_lineage_aws
		WHERE source_arn = $1 AND %s
		ORDER BY target_name
		LIMIT $%d OFFSET $%d`, Schema, scanFilter, limitPos, offsetPos)

	rows, err := r.db.DB.QueryContext(ctx, selectQuery, selectArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("query lineage edges: %w", err)
	}
	defer rows.Close()

	var edges []models.LineageEdge
	for rows.Next() {
		var edge models.LineageEdge
		var isExternal sql.NullBool

		if err := rows.Scan(
			&edge.TargetName,
			&edge.TargetType,
			&edge.RelType,
			&edge.Direction,
			&edge.Via,
			&isExternal,
			&edge.Detail,
		); err != nil {
			continue
		}

		// models.LineageEdge.IsExternal is an int (0/1), so convert the bool.
		if isExternal.Valid && isExternal.Bool {
			edge.IsExternal = 1
		}
		edges = append(edges, edge)
	}

	if edges == nil {
		edges = []models.LineageEdge{}
	}

	return edges, totalCount, nil
}
