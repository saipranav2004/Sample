package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type PrivilegeDistributionService struct {
	repo *repodashboard.PrivilegeDistributionRepository
}

func NewPrivilegeDistributionService(repo *repodashboard.PrivilegeDistributionRepository) *PrivilegeDistributionService {
	return &PrivilegeDistributionService{repo: repo}
}

func (s *PrivilegeDistributionService) GetPrivilegeDistribution(ctx context.Context, f repodashboard.PrivilegeDistributionFilter) (*models.PrivilegeDistributionResponse, error) {
	return s.repo.GetPrivilegeDistribution(ctx, f)
}