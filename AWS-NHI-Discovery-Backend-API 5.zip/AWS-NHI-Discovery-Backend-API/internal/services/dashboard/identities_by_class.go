package dashboard

import (
	"context"

	modelsdashboard "nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type IdentitiesByClassService struct {
	repo *repodashboard.IdentitiesByClassRepository
}

func NewIdentitiesByClassService(repo *repodashboard.IdentitiesByClassRepository) *IdentitiesByClassService {
	return &IdentitiesByClassService{repo: repo}
}

func (s *IdentitiesByClassService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}
func (s *IdentitiesByClassService) RegionExists(ctx context.Context, region string) (bool, error) {
	return s.repo.RegionExists(ctx, region)
}
func (s *IdentitiesByClassService) ByClass(ctx context.Context, f modelsdashboard.IdentityByClassFilter) (*modelsdashboard.IdentitiesByClassResponse, error) {
	return s.repo.ByClass(ctx, f)
}