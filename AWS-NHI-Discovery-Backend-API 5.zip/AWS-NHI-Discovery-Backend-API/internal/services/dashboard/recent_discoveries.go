package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type DiscoveryService struct {
	discoveryRepo *repodashboard.DiscoveryRepository
}

func NewDiscoveryService(discoveryRepo *repodashboard.DiscoveryRepository) *DiscoveryService {
	return &DiscoveryService{discoveryRepo: discoveryRepo}
}

func (s *DiscoveryService) GetRecentDiscoveries(ctx context.Context, f repodashboard.DiscoveryFilter) (*models.RecentDiscoveriesResponse, error) {
	return s.discoveryRepo.GetRecentDiscoveries(ctx, f)
}