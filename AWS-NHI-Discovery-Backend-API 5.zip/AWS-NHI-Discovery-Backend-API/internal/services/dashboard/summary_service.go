package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type SummaryService struct {
	repo *repodashboard.SummaryRepository
}

func NewSummaryService(repo *repodashboard.SummaryRepository) *SummaryService {
	return &SummaryService{repo: repo}
}

func (s *SummaryService) Summary(ctx context.Context, filter repodashboard.SummaryFilter) (*models.DashboardSummaryResponse, error) {
	return s.repo.Summary(ctx, filter)
}