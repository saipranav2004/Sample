package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type CredentialsByTypeService struct {
	repo *repodashboard.CredentialsByTypeRepository
}

func NewCredentialsByTypeService(repo *repodashboard.CredentialsByTypeRepository) *CredentialsByTypeService {
	return &CredentialsByTypeService{repo: repo}
}

func (s *CredentialsByTypeService) Breakdown(ctx context.Context, filter repodashboard.CredentialsByTypeFilter) (*models.CredentialsByTypeResponse, error) {
	return s.repo.Breakdown(ctx, filter)
}