package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type IdentitiesByAccountService struct {
	repo *repodashboard.IdentitiesByAccountRepository
}

func NewIdentitiesByAccountService(repo *repodashboard.IdentitiesByAccountRepository) *IdentitiesByAccountService {
	return &IdentitiesByAccountService{repo: repo}
}

func (s *IdentitiesByAccountService) Breakdown(ctx context.Context, filter repodashboard.IdentitiesByAccountFilter) (*models.IdentitiesByAccountResponse, error) {
	return s.repo.Breakdown(ctx, filter)
}