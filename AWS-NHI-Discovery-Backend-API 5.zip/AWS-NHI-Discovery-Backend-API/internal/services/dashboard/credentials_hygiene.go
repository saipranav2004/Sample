package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type CredentialHygieneSummaryService struct {
	repo *repodashboard.CredentialHygieneSummaryRepository
}

func NewCredentialHygieneSummaryService(repo *repodashboard.CredentialHygieneSummaryRepository) *CredentialHygieneSummaryService {
	return &CredentialHygieneSummaryService{repo: repo}
}

func (s *CredentialHygieneSummaryService) GetHygieneSummary(ctx context.Context, accountID string) (*models.CredentialHygieneSummaryResponse, error) {
	return s.repo.GetHygieneSummary(ctx, accountID)
}