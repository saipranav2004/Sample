package inventory

import (
	"context"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

// CredentialHygieneService sits between handler and repository.
type CredentialHygieneService struct {
	repo *repoinventory.CredentialHygieneRepository
}

func NewCredentialHygieneService(
	repo *repoinventory.CredentialHygieneRepository,
) *CredentialHygieneService {
	return &CredentialHygieneService{repo: repo}
}

func (s *CredentialHygieneService) GetHygieneFlags(
	ctx context.Context,
	id string,
) (*inventorymodels.CredentialHygieneResponse, error) {
	if id == "" {
		return nil, fmt.Errorf("credential id is required")
	}
	return s.repo.GetHygieneFlags(ctx, id)
}