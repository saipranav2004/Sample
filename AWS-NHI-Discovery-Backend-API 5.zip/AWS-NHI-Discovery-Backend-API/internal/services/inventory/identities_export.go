package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityExportService struct {
	repo *repoinventory.IdentityExportRepository
}

func NewIdentityExportService(repo *repoinventory.IdentityExportRepository) *IdentityExportService {
	return &IdentityExportService{repo: repo}
}

func (s *IdentityExportService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}
func (s *IdentityExportService) IdentityTypeExists(ctx context.Context, identityType string) (bool, error) {
	return s.repo.IdentityTypeExists(ctx, identityType)
}
func (s *IdentityExportService) RegionExists(ctx context.Context, region string) (bool, error) {
	return s.repo.RegionExists(ctx, region)
}
func (s *IdentityExportService) StatusExists(ctx context.Context, status string) (bool, error) {
	return s.repo.StatusExists(ctx, status)
}
func (s *IdentityExportService) Count(ctx context.Context, f modelsinventory.IdentityExportFilter) (int, error) {
	return s.repo.Count(ctx, f)
}
func (s *IdentityExportService) Export(ctx context.Context, f modelsinventory.IdentityExportFilter) ([]modelsinventory.IdentityExportRow, error) {
	return s.repo.Export(ctx, f)
}