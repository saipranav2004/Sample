package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityListService struct {
	repo *repoinventory.IdentityListRepository
}

func NewIdentityListService(repo *repoinventory.IdentityListRepository) *IdentityListService {
	return &IdentityListService{repo: repo}
}

func (s *IdentityListService) List(ctx context.Context, f modelsinventory.IdentityListFilter) (modelsinventory.IdentityListResponse, error) {
	total, err := s.repo.Count(ctx, f)
	if err != nil {
		return modelsinventory.IdentityListResponse{}, err
	}

	data, err := s.repo.List(ctx, f)
	if err != nil {
		return modelsinventory.IdentityListResponse{}, err
	}

	return modelsinventory.IdentityListResponse{
		Total: total,
		Page:  f.Page,
		Limit: f.Limit,
		Data:  data,
	}, nil
}

func (s *IdentityListService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}

func (s *IdentityListService) IdentityTypeExists(ctx context.Context, identityType string) (bool, error) {
	return s.repo.IdentityTypeExists(ctx, identityType)
}

func (s *IdentityListService) RegionExists(ctx context.Context, region string) (bool, error) {
	return s.repo.RegionExists(ctx, region)
}

func (s *IdentityListService) StatusExists(ctx context.Context, status string) (bool, error) {
	return s.repo.StatusExists(ctx, status)
}

func (s *IdentityListService) ListIdentityTypes(ctx context.Context) ([]string, error) {
	return s.repo.ListIdentityTypes(ctx)
}

func (s *IdentityListService) ListRegions(ctx context.Context) ([]string, error) {
	return s.repo.ListRegions(ctx)
}

func (s *IdentityListService) ListStatuses(ctx context.Context) ([]string, error) {
	return s.repo.ListStatuses(ctx)
}