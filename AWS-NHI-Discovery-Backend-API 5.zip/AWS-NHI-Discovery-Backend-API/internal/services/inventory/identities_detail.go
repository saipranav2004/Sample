package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityDetailService struct {
	repo *repoinventory.IdentityDetailRepository
}

func NewIdentityDetailService(repo *repoinventory.IdentityDetailRepository) *IdentityDetailService {
	return &IdentityDetailService{repo: repo}
}

func (s *IdentityDetailService) Detail(ctx context.Context, id string) (*modelsinventory.IdentityDetail, error) {
	return s.repo.Detail(ctx, id)
}