package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type SearchService struct {
	repo *repoinventory.SearchRepository
}

func NewSearchService(repo *repoinventory.SearchRepository) *SearchService {
	return &SearchService{repo: repo}
}

func (s *SearchService) Search(ctx context.Context, filter repoinventory.GlobalSearchFilter) (*modelsinventory.GlobalSearchResponse, error) {
	resp := &modelsinventory.GlobalSearchResponse{
		Query:       filter.Query,
		Identities:  []modelsinventory.SearchIdentityResult{},
		Credentials: []modelsinventory.SearchCredentialResult{},
	}

	entityType := filter.EntityType
	if entityType == "" {
		entityType = "both"
	}

	if entityType == "identities" || entityType == "both" {
		identities, err := s.repo.SearchIdentities(ctx, filter.Query, filter.Limit)
		if err != nil {
			return nil, err
		}
		resp.Identities = identities
	}

	if entityType == "credentials" || entityType == "both" {
		credentials, err := s.repo.SearchCredentials(ctx, filter.Query, filter.Limit)
		if err != nil {
			return nil, err
		}
		resp.Credentials = credentials
	}

	resp.TotalResults = len(resp.Identities) + len(resp.Credentials)

	return resp, nil
}