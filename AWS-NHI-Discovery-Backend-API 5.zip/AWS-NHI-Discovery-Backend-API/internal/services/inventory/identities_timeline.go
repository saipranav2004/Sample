package inventory

import (
	"context"
	"time"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityTimelineService struct {
	repo *repoinventory.IdentityTimelineRepository
}

func NewIdentityTimelineService(repo *repoinventory.IdentityTimelineRepository) *IdentityTimelineService {
	return &IdentityTimelineService{repo: repo}
}

func (s *IdentityTimelineService) Timeline(ctx context.Context, id string) (*modelsinventory.IdentityTimelineResponse, error) {
	return s.repo.Timeline(ctx, id, time.Now)
}