package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityAttributesService struct {
	repo *repoinventory.IdentityAttributesRepository
}

func NewIdentityAttributesService(repo *repoinventory.IdentityAttributesRepository) *IdentityAttributesService {
	return &IdentityAttributesService{repo: repo}
}

func (s *IdentityAttributesService) Attributes(ctx context.Context, id string) (*modelsinventory.IdentityAttributesResponse, error) {
	return s.repo.Attributes(ctx, id)
}