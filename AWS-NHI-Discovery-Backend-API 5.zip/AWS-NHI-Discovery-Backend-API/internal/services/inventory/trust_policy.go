package inventory

import (
	"context"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

// TrustPolicyService sits between handler and repository.
type TrustPolicyService struct {
	repo *repoinventory.TrustPolicyRepository
}

func NewTrustPolicyService(
	repo *repoinventory.TrustPolicyRepository,
) *TrustPolicyService {
	return &TrustPolicyService{repo: repo}
}

func (s *TrustPolicyService) GetTrustPolicy(
	ctx context.Context,
	id string,
) (*inventorymodels.TrustPolicyResponse, error) {
	if id == "" {
		return nil, fmt.Errorf("credential id is required")
	}
	return s.repo.GetTrustPolicy(ctx, id)
}