package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityDormantService struct {
	repo *repoinventory.IdentityDormantRepository
}

func NewIdentityDormantService(repo *repoinventory.IdentityDormantRepository) *IdentityDormantService {
	return &IdentityDormantService{repo: repo}
}

func (s *IdentityDormantService) List(ctx context.Context, filter repoinventory.DormantIdentitiesFilter) (*modelsinventory.DormantIdentitiesResponse, error) {
	data, total, err := s.repo.List(ctx, filter)
	if err != nil {
		return nil, err
	}

	return &modelsinventory.DormantIdentitiesResponse{
		ThresholdDays: filter.Days,
		TotalDormant:  total,
		Data:          data,
	}, nil
}