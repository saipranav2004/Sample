package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type UpdateCredentialService struct {
	repo *repoinventory.UpdateCredentialRepository
}

func NewUpdateCredentialService(
	repo *repoinventory.UpdateCredentialRepository,
) *UpdateCredentialService {
	return &UpdateCredentialService{repo: repo}
}

func (s *UpdateCredentialService) UpdateCredential(
	ctx context.Context,
	id string,
	req modelsinventory.UpdateCredentialRequest,
) (*modelsinventory.UpdateCredentialResponse, error) {
	return s.repo.UpdateCredential(ctx, id, req)
}