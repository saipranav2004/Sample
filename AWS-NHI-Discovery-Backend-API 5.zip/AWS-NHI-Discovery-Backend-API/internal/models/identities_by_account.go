// package models

// type AccountIdentityBreakdown struct {
// 	AccountID      string `json:"account_id"`
// 	AccountName    string `json:"account_name"`
// 	IdentityCount  int    `json:"identity_count"`
// 	CredentialCount int   `json:"credential_count"`
// }

// type IdentitiesByAccountResponse struct {
// 	TotalAccounts int                         `json:"total_accounts"`
// 	Breakdown     []AccountIdentityBreakdown  `json:"breakdown"`
// }



package models

type AccountIdentityBreakdown struct {
	AccountID       string  `json:"account_id"`
	AccountName     *string `json:"account_name"` // null until an accounts reference table is wired up
	IdentityCount   int     `json:"identity_count"`
	CredentialCount int     `json:"credential_count"`
}

type IdentitiesByAccountResponse struct {
	TotalAccounts int                        `json:"total_accounts"`
	Breakdown     []AccountIdentityBreakdown `json:"breakdown"`
}
