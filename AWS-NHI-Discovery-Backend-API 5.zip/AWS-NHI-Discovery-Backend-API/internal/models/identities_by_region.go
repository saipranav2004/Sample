package models

type RegionIdentityBreakdown struct {
	Region          string `json:"region"`
	IdentityCount   int    `json:"identity_count"`
	CredentialCount int    `json:"credential_count"`
}

type IdentitiesByRegionResponse struct {
	TotalRegions int                       `json:"total_regions"`
	Breakdown    []RegionIdentityBreakdown `json:"breakdown"`
}