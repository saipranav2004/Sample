package models

// Discovery is one row of the "Recent Discoveries" feed.
// Pointer fields are used so a column with no data is returned as JSON null.
type Discovery struct {
	Event        string  `json:"event"`  // "new" | "removed"
	Entity       string  `json:"entity"` // "identity" | "credential"
	ARN          *string `json:"arn"`
	Name         *string `json:"name"`
	Type         *string `json:"type"`
	AccountID    *string `json:"account_id"`
	Region       *string `json:"region"`
	DiscoveredAt string  `json:"discovered_at"` // RFC3339 UTC, e.g. 2025-06-14T02:45:00Z
}

// RecentDiscoveriesResponse is returned as-is (no success/data envelope) so it
// matches the API document for GET /dashboard/recent-discoveries.
type RecentDiscoveriesResponse struct {
	Discoveries  []Discovery `json:"discoveries"`
	TotalNew     int         `json:"total_new"`
	TotalRemoved int         `json:"total_removed"`
}
