package models

type IdentityByClassFilter struct {
	AccountID string
	Region    string
}

type IdentityClassCount struct {
	FunctionalClass string `json:"functional_class"`
	Count           int    `json:"count"`
}

type IdentitiesByClassResponse struct {
	Total     int                   `json:"total"`
	Breakdown []IdentityClassCount  `json:"breakdown"`
}