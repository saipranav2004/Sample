package models

type CredentialTypeBreakdown struct {
	CredentialType string `json:"credential_type"`
	Count          int    `json:"count"`
}

type CredentialsByTypeResponse struct {
	Total     int                       `json:"total"`
	Breakdown []CredentialTypeBreakdown `json:"breakdown"`
}