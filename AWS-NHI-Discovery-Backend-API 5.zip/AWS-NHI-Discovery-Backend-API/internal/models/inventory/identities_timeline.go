package inventory

type IdentityTimelineEvent struct {
	Event     string `json:"event"`
	Timestamp string `json:"timestamp"`
}

type IdentityTimelineResponse struct {
	IdentityARN           string                   `json:"identity_arn"`
	Events                []IdentityTimelineEvent  `json:"events"`
	AgeDays               int                      `json:"age_days"`
	DaysSinceLastActivity int                      `json:"days_since_last_activity"`
}