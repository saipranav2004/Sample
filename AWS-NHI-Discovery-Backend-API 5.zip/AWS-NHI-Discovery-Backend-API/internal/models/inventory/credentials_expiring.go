package inventory

import "time"

// ExpiringCredentialFilter holds the query params for B7.
type ExpiringCredentialFilter struct {
	Days           int // required, > 0
	CredentialType string
	AccountID      string
	Page           int
	Limit          int
}

// ExpiringCredential is one row in the B7 response.
type ExpiringCredential struct {
	ID              string    `json:"id"`
	Name            string    `json:"name"`
	CredentialType  string    `json:"credential_type"`
	ExpiresAt       time.Time `json:"expires_at"`
	DaysUntilExpiry int       `json:"days_until_expiry"`
}

// ExpiringCredentialsResponse matches the spec:
// { "threshold_days": 30, "total_expiring": 34, "data": [...] }
type ExpiringCredentialsResponse struct {
	ThresholdDays int                  `json:"threshold_days"`
	TotalExpiring int                  `json:"total_expiring"`
	Data          []ExpiringCredential `json:"data"`
}