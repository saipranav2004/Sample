package inventory

import "time"

type DormantIdentity struct {
	ID             string     `json:"id"`
	Name           string     `json:"name"`
	IdentityType   string     `json:"identity_type"`
	LastActivityAt *time.Time `json:"last_activity_at"`
	DaysInactive   int        `json:"days_inactive"`
	Owner          *string    `json:"owner"`
	Environment    *string    `json:"environment"`
}

type DormantIdentitiesResponse struct {
	ThresholdDays int                `json:"threshold_days"`
	TotalDormant  int                `json:"total_dormant"`
	Data          []DormantIdentity  `json:"data"`
}