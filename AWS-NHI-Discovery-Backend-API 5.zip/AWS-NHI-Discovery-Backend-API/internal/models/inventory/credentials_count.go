package inventory

// CredentialCountByType holds per-type counts as a dynamic map.
// e.g. {"iam_role": 1245, "access_key": 312}
type CredentialCountByType map[string]int

// CredentialCountResponse is the full response for
// GET /api/v1/inventory/credentials/counts
type CredentialCountResponse struct {
	Total             int                   `json:"total"`
	Active            int                   `json:"active"`
	Inactive          int                   `json:"inactive"`
	Expired           int                   `json:"expired"`
	ByType            CredentialCountByType `json:"by_type"`
	ExpiringWithin30d int                   `json:"expiring_within_30d"`
	Stale90d          int                   `json:"stale_90d"`
	HighPrivilege     int                   `json:"high_privilege"`
}

// CredentialCountFilter holds optional query parameters.
type CredentialCountFilter struct {
	AccountID string // optional
	Region    string // optional
}