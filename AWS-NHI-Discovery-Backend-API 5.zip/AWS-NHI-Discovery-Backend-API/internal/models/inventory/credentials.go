package inventory

import "time"

// Credential represents a single credential item matching the exact spec JSON output
type Credential struct {
	ID                string                 `json:"id"`
	ARN               string                 `json:"arn"`
	Name              string                 `json:"name"`
	CredentialType    string                 `json:"credential_type"`
	AccountID         string                 `json:"account_id"`
	Region            string                 `json:"region"`
	Status            string                 `json:"status"`
	CreatedAtAWS      *time.Time             `json:"created_at_aws"`
	LastUsedAt        *time.Time             `json:"last_used_at"`
	ExpiresAt         *time.Time             `json:"expires_at"`
	RotationEnabled   *bool                  `json:"rotation_enabled"`
	PrivilegeLevel    int                    `json:"privilege_level"`
	OwnerPrincipalARN *string                `json:"owner_principal_arn"`
	Tags              map[string]interface{} `json:"tags"`
}

// CredentialFilter holds query parameters for filtering and paginating credentials
type CredentialFilter struct {
	Page               int
	Limit              int
	SortBy             string
	SortOrder          string
	Search             string
	CredentialType     string
	AccountID          string
	Region             string
	Status             string
	OwnerPrincipalARN  string
	RotationEnabled    *bool
	ExpiringWithinDays *int
	StaleDays          *int
	PrivilegeLevelMin  *int
	PrivilegeLevelMax  *int
}

// CredentialListResponse matches the exact envelope structure: total, page, limit, data
type CredentialListResponse struct {
	Total int          `json:"total"`
	Page  int          `json:"page"`
	Limit int          `json:"limit"`
	Data  []Credential `json:"data"`
}