package inventory

type UpdateCredentialRequest struct {
	OwnerPrincipalARN *string           `json:"owner_principal_arn"`
	Tags              map[string]string `json:"tags"`
}

// UpdateCredentialResponse is the B10 response.
type UpdateCredentialResponse struct {
	ID            string   `json:"id"`
	Message       string   `json:"message"`
	UpdatedFields []string `json:"updated_fields"`
}