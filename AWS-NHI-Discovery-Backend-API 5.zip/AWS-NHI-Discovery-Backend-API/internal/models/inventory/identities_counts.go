package inventory

type IdentityCountsResponse struct {
	Total      int            `json:"total"`
	Active     int            `json:"active"`
	Stopped    int            `json:"stopped"`
	Terminated int            `json:"terminated"`
	ByType     map[string]int `json:"by_type"`
	ByClass    map[string]int `json:"by_class"`
}