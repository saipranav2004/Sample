package inventory

import (
	"encoding/json"
	"time"
)

// IdentityExportFilter reuses the same filters as A1 List Identities, plus format.
type IdentityExportFilter struct {
	Page             int
	Limit            int
	SortBy           string
	SortOrder        string
	Search           string
	IdentityType     string
	FunctionalClass  string
	AccountID        string
	Region           string
	Status           string
	Owner            string
	Environment      string
	IsPublic         *bool
	LastActiveBefore *time.Time
	Format           string
}

// IdentityExportRow represents all columns of nhi_scanner.identities for export.
type IdentityExportRow struct {
	ID                   string          `json:"id"`
	ARN                  string          `json:"arn"`
	Name                 string          `json:"name"`
	IdentityType         string          `json:"identity_type"`
	FunctionalClass      string          `json:"functional_class"`
	AccountID            string          `json:"account_id"`
	Region               string          `json:"region"`
	Status               string          `json:"status"`
	CreatedAtAWS         string          `json:"created_at_aws"`
	FirstSeenAt          string          `json:"first_seen_at"`
	LastSeenAt           string          `json:"last_seen_at"`
	LastActivityAt       string          `json:"last_activity_at"`
	DeletedAt            string          `json:"deleted_at"`
	VPCID                string          `json:"vpc_id"`
	SubnetID             string          `json:"subnet_id"`
	SecurityGroupIDs     json.RawMessage `json:"security_group_ids"`
	IsPubliclyAccessible bool            `json:"is_publicly_accessible"`
	Tags                 json.RawMessage `json:"tags"`
	Owner                string          `json:"owner"`
	Environment          string          `json:"environment"`
	ParentARN            string          `json:"parent_arn"`
	CloudTrailCreatorARN string          `json:"cloudtrail_creator_arn"`
	DiscoverySource      string          `json:"discovery_source"`
	ScanID               string          `json:"scan_id"`
	TypeAttributes       json.RawMessage `json:"type_attributes"`
	RawAPIResponse       json.RawMessage `json:"raw_api_response"`
}