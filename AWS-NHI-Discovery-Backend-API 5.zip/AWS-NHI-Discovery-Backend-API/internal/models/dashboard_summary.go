// package models

// import "time"

// type IdentitiesByStatus struct {
// 	Active     int `json:"active"`
// 	Stopped    int `json:"stopped"`
// 	Terminated int `json:"terminated"`
// }

// // type CredentialsByStatus struct {
// // 	Active          int `json:"active"`
// // 	Inactive        int `json:"inactive"`
// // 	Expired         int `json:"expired"`
// // 	PendingDeletion int `json:"pending_deletion"`
// // }

// type CredentialsByStatus struct {
//     Active   int `json:"active"`
//     Inactive int `json:"inactive"`
//     Expired  int `json:"expired"`
//     Unknown  int `json:"unknown"`
// }

// type DashboardSummaryResponse struct {
// 	TotalIdentities          int                 `json:"total_identities"`
// 	TotalCredentials         int                 `json:"total_credentials"`
// 	TotalAccountsScanned     int                 `json:"total_accounts_scanned"`
// 	TotalRegionsScanned      int                 `json:"total_regions_scanned"`
// 	IdentitiesByStatus       IdentitiesByStatus  `json:"identities_by_status"`
// 	CredentialsByStatus      CredentialsByStatus `json:"credentials_by_status"`
// 	NewIdentitiesLast24h     int                 `json:"new_identities_last_24h"`
// 	RemovedIdentitiesLast24h int                 `json:"removed_identities_last_24h"`
// 	NewCredentialsLast24h    int                 `json:"new_credentials_last_24h"`
// 	ExpiringCredentials30d   int                 `json:"expiring_credentials_30d"`
// 	StaleCredentials90d      int                 `json:"stale_credentials_90d"`
// 	UnrotatedCredentials     int                 `json:"unrotated_credentials"`
// 	LastScanAt               *time.Time          `json:"last_scan_at"`
// 	ScanDurationSeconds      int                 `json:"scan_duration_seconds"`
// 	ScanStatus               string              `json:"scan_status"`
// }






package models

import "time"

type DashboardSummaryResponse struct {
	TotalIdentities          int            `json:"total_identities"`
	TotalCredentials         int            `json:"total_credentials"`
	TotalAccountsScanned     int            `json:"total_accounts_scanned"`
	TotalRegionsScanned      int            `json:"total_regions_scanned"`
	IdentitiesByStatus       map[string]int `json:"identities_by_status"`
	CredentialsByStatus      map[string]int `json:"credentials_by_status"`
	NewIdentitiesLast24h     int            `json:"new_identities_last_24h"`
	RemovedIdentitiesLast24h int            `json:"removed_identities_last_24h"`
	NewCredentialsLast24h    int            `json:"new_credentials_last_24h"`
	ExpiringCredentials30d   int            `json:"expiring_credentials_30d"`
	StaleCredentials90d      int            `json:"stale_credentials_90d"`
	UnrotatedCredentials     int            `json:"unrotated_credentials"`
	LastScanAt               *time.Time     `json:"last_scan_at"`
	ScanDurationSeconds      int            `json:"scan_duration_seconds"`
	ScanStatus               string         `json:"scan_status"`
}