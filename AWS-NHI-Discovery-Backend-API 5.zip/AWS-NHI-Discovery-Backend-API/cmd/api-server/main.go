package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	handlerdashboard "nhi-backend-api/internal/handlers/dashboard"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	svcdashboard "nhi-backend-api/internal/services/dashboard"

	handlerinventory "nhi-backend-api/internal/handlers/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Config
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}

	// 2. Connect DB
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Repositories
	validatorRepo := repoinventory.NewValidatorRepository(db)

	userRepo := repository.NewUserRepository(db)
	identityDetailsRepo := repository.NewIdentityDetailsRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	discoveryRepo := repodashboard.NewDiscoveryRepository(db)
	privilegeDistributionRepo := repodashboard.NewPrivilegeDistributionRepository(db)
	ownershipCoverageRepo := repodashboard.NewOwnershipCoverageRepository(db)
	filtersRepo := repodashboard.NewFiltersRepository(db)
	dashboardSummaryRepo := repodashboard.NewSummaryRepository(db)
	identitiesByTypeRepo := repodashboard.NewIdentitiesByTypeRepository(db)
	identitiesByClassRepo := repodashboard.NewIdentitiesByClassRepository(db)
	identitiesByAccountRepo := repodashboard.NewIdentitiesByAccountRepository(db)
	identitiesByRegionRepo := repodashboard.NewIdentitiesByRegionRepository(db)
	credentialsByTypeRepo := repodashboard.NewCredentialsByTypeRepository(db)
	credentialHygieneSummaryRepo := repodashboard.NewCredentialHygieneSummaryRepository(db)
	identitiesExposureRepo := repodashboard.NewIdentitiesExposureRepository(db)

	inventoryCredRepo := repoinventory.NewCredentialRepository(db)
	inventoryCredDetailsRepo := repoinventory.NewCredentialDetailsRepository(db)
	inventoryCredCountRepo := repoinventory.NewCredentialCountRepository(db)
	inventoryCredHygieneRepo := repoinventory.NewCredentialHygieneRepository(db)
	trustPolicyRepo := repoinventory.NewTrustPolicyRepository(db)
	attachedPoliciesRepo := repoinventory.NewAttachedPoliciesRepository(db)
	inventoryCredExpiringRepo := repoinventory.NewCredentialExpiringRepository(db)
	inventoryCredStaleRepo := repoinventory.NewCredentialStaleRepository(db)
	inventoryCredExportRepo := repoinventory.NewCredentialExportRepository(db)
	inventoryCredUpdateRepo := repoinventory.NewUpdateCredentialRepository(db)

	identityListRepo := repoinventory.NewIdentityListRepository(db)
	identityDetailRepo := repoinventory.NewIdentityDetailRepository(db)
	identityAttributesRepo := repoinventory.NewIdentityAttributesRepository(db)
	identityTimelineRepo := repoinventory.NewIdentityTimelineRepository(db)
	identityGroupedByClassRepo := repoinventory.NewIdentityGroupedByClassRepository(db)
	identityDormantRepo := repoinventory.NewIdentityDormantRepository(db)
	identityExportRepo := repoinventory.NewIdentityExportRepository(db)
	updateIdentityRepo := repoinventory.NewUpdateIdentityRepository(db)
	identityCountsRepo := repoinventory.NewIdentityCountsRepository(db)
	searchRepo := repoinventory.NewSearchRepository(db)

	// 4. Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	dashboardService := services.NewDashboardService(dashboardRepo, identityDetailsRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)
	lineageService := services.NewLineageService(lineageRepo)

	discoveryService := svcdashboard.NewDiscoveryService(discoveryRepo)
	privilegeDistributionService := svcdashboard.NewPrivilegeDistributionService(privilegeDistributionRepo)
	ownershipCoverageService := svcdashboard.NewOwnershipCoverageService(ownershipCoverageRepo)
	filtersService := svcdashboard.NewFiltersService(filtersRepo)
	dashboardSummaryService := svcdashboard.NewSummaryService(dashboardSummaryRepo)
	identitiesByTypeService := svcdashboard.NewIdentitiesByTypeService(identitiesByTypeRepo)
	identitiesByClassService := svcdashboard.NewIdentitiesByClassService(identitiesByClassRepo)
	identitiesByAccountService := svcdashboard.NewIdentitiesByAccountService(identitiesByAccountRepo)
	identitiesByRegionService := svcdashboard.NewIdentitiesByRegionService(identitiesByRegionRepo)
	credentialsByTypeService := svcdashboard.NewCredentialsByTypeService(credentialsByTypeRepo)
	credentialHygieneSummaryService := svcdashboard.NewCredentialHygieneSummaryService(credentialHygieneSummaryRepo)
	identitiesExposureService := svcdashboard.NewIdentitiesExposureService(identitiesExposureRepo)

	inventoryCredService := svcinventory.NewCredentialService(inventoryCredRepo)
	inventoryCredDetailsService := svcinventory.NewCredentialDetailsService(inventoryCredDetailsRepo)
	inventoryCredCountService := svcinventory.NewCredentialCountService(inventoryCredCountRepo, validatorRepo)
	inventoryCredHygieneService := svcinventory.NewCredentialHygieneService(inventoryCredHygieneRepo)
	trustPolicyService := svcinventory.NewTrustPolicyService(trustPolicyRepo)
	attachedPoliciesService := svcinventory.NewAttachedPoliciesService(attachedPoliciesRepo)
	inventoryCredExpiringService := svcinventory.NewCredentialExpiringService(inventoryCredExpiringRepo)
	inventoryCredStaleService := svcinventory.NewCredentialStaleService(inventoryCredStaleRepo)
	inventoryCredExportService := svcinventory.NewCredentialExportService(inventoryCredExportRepo)
	inventoryCredUpdateService := svcinventory.NewUpdateCredentialService(inventoryCredUpdateRepo)

	identityListService := svcinventory.NewIdentityListService(identityListRepo)
	identityDetailService := svcinventory.NewIdentityDetailService(identityDetailRepo)
	identityAttributesService := svcinventory.NewIdentityAttributesService(identityAttributesRepo)
	identityTimelineService := svcinventory.NewIdentityTimelineService(identityTimelineRepo)
	identityGroupedByClassService := svcinventory.NewIdentityGroupedByClassService(identityGroupedByClassRepo)
	identityDormantService := svcinventory.NewIdentityDormantService(identityDormantRepo)
	identityExportService := svcinventory.NewIdentityExportService(identityExportRepo)
	updateIdentityService := svcinventory.NewUpdateIdentityService(updateIdentityRepo)
	identityCountsService := svcinventory.NewIdentityCountsService(identityCountsRepo)
	searchService := svcinventory.NewSearchService(searchRepo)

	// 5. Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)
	scanHandler := handlers.NewScanHandler(scanService)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)
	lineageHandler := handlers.NewLineageHandler(lineageService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)

	discoveryHandler := handlerdashboard.NewDiscoveryHandler(discoveryService)
	privilegeDistributionHandler := handlerdashboard.NewPrivilegeDistributionHandler(privilegeDistributionService)
	ownershipCoverageHandler := handlerdashboard.NewOwnershipCoverageHandler(ownershipCoverageService)
	filtersHandler := handlerdashboard.NewFiltersHandler(filtersService)
	dashboardSummaryHandler := handlerdashboard.NewSummaryHandler(dashboardSummaryService)
	identitiesByTypeHandler := handlerdashboard.NewIdentitiesByTypeHandler(identitiesByTypeService)
	identitiesByClassHandler := handlerdashboard.NewIdentitiesByClassHandler(identitiesByClassService)
	identitiesByAccountHandler := handlerdashboard.NewIdentitiesByAccountHandler(identitiesByAccountService)
	identitiesByRegionHandler := handlerdashboard.NewIdentitiesByRegionHandler(identitiesByRegionService)
	credentialsByTypeHandler := handlerdashboard.NewCredentialsByTypeHandler(credentialsByTypeService)
	credentialHygieneSummaryHandler := handlerdashboard.NewCredentialHygieneSummaryHandler(credentialHygieneSummaryService)
	identitiesExposureHandler := handlerdashboard.NewIdentitiesExposureHandler(identitiesExposureService)

	inventoryCredHandler := handlerinventory.NewCredentialHandler(inventoryCredService)
	inventoryCredDetailsHandler := handlerinventory.NewCredentialDetailsHandler(inventoryCredDetailsService)
	inventoryCredCountHandler := handlerinventory.NewCredentialCountHandler(inventoryCredCountService)
	inventoryCredHygieneHandler := handlerinventory.NewCredentialHygieneHandler(inventoryCredHygieneService)
	trustPolicyHandler := handlerinventory.NewTrustPolicyHandler(trustPolicyService)
	attachedPoliciesHandler := handlerinventory.NewAttachedPoliciesHandler(attachedPoliciesService)
	inventoryCredExpiringHandler := handlerinventory.NewCredentialExpiringHandler(inventoryCredExpiringService)
	inventoryCredStaleHandler := handlerinventory.NewCredentialStaleHandler(inventoryCredStaleService)
	inventoryCredExportHandler := handlerinventory.NewCredentialExportHandler(inventoryCredExportService)
	inventoryCredUpdateHandler := handlerinventory.NewUpdateCredentialHandler(inventoryCredUpdateService)

	identityListHandler := handlerinventory.NewIdentityListHandler(identityListService)
	identityDetailHandler := handlerinventory.NewIdentityDetailHandler(identityDetailService)
	identityAttributesHandler := handlerinventory.NewIdentityAttributesHandler(identityAttributesService)
	identityTimelineHandler := handlerinventory.NewIdentityTimelineHandler(identityTimelineService)
	identityGroupedByClassHandler := handlerinventory.NewIdentityGroupedByClassHandler(identityGroupedByClassService)
	identityDormantHandler := handlerinventory.NewIdentityDormantHandler(identityDormantService)
	identityExportHandler := handlerinventory.NewIdentityExportHandler(identityExportService)
	updateIdentityHandler := handlerinventory.NewUpdateIdentityHandler(updateIdentityService)
	identityCountsHandler := handlerinventory.NewIdentityCountsHandler(identityCountsService)
	searchHandler := handlerinventory.NewSearchHandler(searchService)

	// 6. Router
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:     authHandler,
		DashboardHandler: dashboardHandler,
		ScanHandler:     scanHandler,
		AuthMiddleware:  authMiddleware,
		EventHandler:    eventHandler,
		LineageHandler:  lineageHandler,
		CredentialHandler: credentialHandler,

		DiscoveryHandler:             discoveryHandler,
		PrivilegeDistributionHandler: privilegeDistributionHandler,
		OwnershipCoverageHandler:     ownershipCoverageHandler,
		FiltersHandler:               filtersHandler,
		DashboardSummaryHandler:      dashboardSummaryHandler,
		IdentitiesByTypeHandler:      identitiesByTypeHandler,
		IdentitiesByClassHandler:     identitiesByClassHandler,
		IdentitiesByAccountHandler:   identitiesByAccountHandler,
		IdentitiesByRegionHandler:    identitiesByRegionHandler,
		CredentialsByTypeHandler:     credentialsByTypeHandler,
		CredentialHygieneSummaryHandler: credentialHygieneSummaryHandler,
		IdentitiesExposureHandler: identitiesExposureHandler,

		InventoryCredentialHandler:          inventoryCredHandler,
		InventoryCredentialDetailsHandler:   inventoryCredDetailsHandler,
		InventoryCredentialCountHandler:     inventoryCredCountHandler,
		InventoryCredentialHygieneHandler:   inventoryCredHygieneHandler,
		InventoryTrustPolicyHandler:         trustPolicyHandler,
		InventoryAttachedPoliciesHandler:    attachedPoliciesHandler,
		InventoryCredentialExpiringHandler:  inventoryCredExpiringHandler,
		InventoryCredentialStaleHandler:     inventoryCredStaleHandler,
		InventoryCredentialExportHandler:    inventoryCredExportHandler,
		InventoryCredentialUpdateHandler:    inventoryCredUpdateHandler,

		IdentityListHandler:           identityListHandler,
		IdentityDetailHandler:         identityDetailHandler,
		IdentityAttributesHandler:     identityAttributesHandler,
		IdentityTimelineHandler:       identityTimelineHandler,
		IdentityGroupedByClassHandler: identityGroupedByClassHandler,
		IdentityDormantHandler:        identityDormantHandler,
		IdentityExportHandler:         identityExportHandler,
		UpdateIdentityHandler:         updateIdentityHandler,
		IdentityCountsHandler:         identityCountsHandler,
		IdentitySearchHandler:         searchHandler,
	})

	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 7. Server Setup
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}