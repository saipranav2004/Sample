package utils

import (
	"fmt"
	"strings"
	"time"
)

// ExtractRegionFromARN pulls the AWS region out of a standard ARN.
// Format: arn:partition:service:region:account-id:resource
// Some resource types (e.g. IAM, S3) legitimately omit the region segment,
// so this returns "global" when that segment is empty, and "" when the
// ARN doesn't look like an ARN at all.
func ExtractRegionFromARN(arn string) string {
	parts := strings.Split(arn, ":")
	if len(parts) < 4 {
		return ""
	}
	region := parts[3]
	if region == "" {
		return "global"
	}
	return region
}

// FormatCredType turns a raw value like "IAM_ROLE" or "iam_role" into
// "IAM Role" for display, keeping common acronyms upper-cased.
func FormatCredType(raw string) string {
	if raw == "" {
		return ""
	}
	words := strings.FieldsFunc(raw, func(r rune) bool {
		return r == '_' || r == '-' || r == ' '
	})
	for i, w := range words {
		upper := strings.ToUpper(w)
		switch upper {
		case "IAM", "SSO", "SAML", "OIDC", "ARN", "API", "EC2", "ECS", "EKS":
			words[i] = upper
		default:
			if len(w) > 0 {
				words[i] = strings.ToUpper(w[:1]) + strings.ToLower(w[1:])
			}
		}
	}
	return strings.Join(words, " ")
}

// DeterminePermissionLevel classifies an identity as BROAD or SCOPED.
// There's no dedicated column for this, so it's inferred from the admin
// flag, the free-text overview_permissions summary, and wildcard policies.
func DeterminePermissionLevel(isAdmin bool, overviewPermissions, attachedPolicies string) string {
	if isAdmin {
		return "BROAD"
	}

	lowerPerms := strings.ToLower(overviewPermissions)
	if strings.Contains(lowerPerms, "broad") ||
		strings.Contains(lowerPerms, "wildcard") ||
		strings.Contains(lowerPerms, "*:*") ||
		strings.Contains(lowerPerms, "full access") ||
		strings.Contains(lowerPerms, "administrator") {
		return "BROAD"
	}

	if strings.Contains(attachedPolicies, "*") {
		return "BROAD"
	}

	if overviewPermissions == "" && attachedPolicies == "" {
		return ""
	}
	return "SCOPED"
}

// DetermineRiskLevel gives a HIGH/MEDIUM/LOW rating from the signals
// available on the row, since there's no dedicated risk-score column.
func DetermineRiskLevel(isAdmin bool, permissionLevel, riskFactors string, mfaEnabled bool, consoleAccess string) string {
	riskFactors = strings.TrimSpace(riskFactors)
	hasFactors := riskFactors != "" && riskFactors != "[]" && riskFactors != "{}" && riskFactors != "null"
	consoleEnabled := strings.EqualFold(consoleAccess, "true") || strings.EqualFold(consoleAccess, "enabled") || strings.EqualFold(consoleAccess, "yes")

	switch {
	case isAdmin && permissionLevel == "BROAD":
		return "HIGH"
	case permissionLevel == "BROAD" && hasFactors:
		return "HIGH"
	case consoleEnabled && !mfaEnabled:
		return "HIGH"
	case permissionLevel == "BROAD" || hasFactors:
		return "MEDIUM"
	case permissionLevel == "SCOPED":
		return "LOW"
	default:
		return ""
	}
}

// FormatRelativeTime renders a timestamp the way the UI's "Last Activity"
// column shows it, e.g. "2 min ago", "5 hr ago", "3 days ago".
// Returns "—" for nil/zero timestamps.
func FormatRelativeTime(t *time.Time) string {
	if t == nil || t.IsZero() {
		return "—"
	}

	d := time.Since(*t)
	switch {
	case d < 0:
		return "just now"
	case d < time.Minute:
		return "just now"
	case d < time.Hour:
		return fmt.Sprintf("%d min ago", int(d.Minutes()))
	case d < 24*time.Hour:
		return fmt.Sprintf("%d hr ago", int(d.Hours()))
	default:
		return fmt.Sprintf("%d days ago", int(d.Hours()/24))
	}
}