import { fileURLToPath } from 'node:url';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

/**
 * One upstream: the Go NHI API. It serves every screen, including credential
 * exposure (the secret-scanner tables are read by the Go service itself), so
 * there is no second proxy and no scanner key anywhere in this app.
 *
 * In development `/api/*` is proxied to API_UPSTREAM so the browser stays
 * same-origin and the bearer token is the only credential it ever sends.
 */
const ROOT = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ROOT, '');
  return {
    envDir: ROOT,
    plugins: [react(), tailwindcss()],
    server: {
      port: 3000,
      proxy: {
        '/api': {
          target: (env.API_UPSTREAM || 'http://localhost:8080').trim(),
          changeOrigin: true,
        },
      },
    },
    build: { outDir: 'dist', sourcemap: false },
  };
});
