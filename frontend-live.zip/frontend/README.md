# NHI Console - Deep Algorithms

Operator console for non-human identity discovery and credential exposure
across AWS. This directory is **only the frontend**. Every screen reads the Go
NHI API (`nhi-backend-api`); there is no sample data and no second backend.

---

## What it talks to

One upstream, the NHI API, with the JWT from `POST /api/auth/login` as a bearer
token. The credential exposure screens use the same API: the Go service reads
the secret scanner's tables itself, so there is no scanner proxy, no
`X-Dashboard-Key` and no scanner key anywhere in this app.

| Screen | Endpoints |
|---|---|
| Sign in | `POST /api/auth/login`, `GET /api/auth/me` |
| Dashboard | `GET /api/v1/dashboard/summary`, `.../identities/by-type`, `by-class`, `by-account`, `by-region`, `exposure`, `.../credentials/by-type`, `GET /api/findings` |
| Identities | `GET /api/v1/inventory/identities` (filters, sort, paging), `.../counts`, `.../export` (CSV and JSON) |
| Identity | `GET /api/v1/inventory/identities/{id}`, `.../attributes`, `.../timeline`, `PATCH .../{id}` |
| Dormant identities | `GET /api/v1/inventory/identities/dormant` |
| Exposed credentials | `GET /api/findings`, `POST /api/allowlist`, `POST /api/findings/decision`, `GET /api/deep-scan-status` |
| Marked safe | `GET /api/allowlist`, `DELETE /api/allowlist` |

Not used, on purpose:

- `GET /api/v1/dashboard/credentials/hygiene` answers 503 until its data source
  exists, so the dashboard shows the summary's credential counts instead.
- `POST /api/deep-scan` answers 501 until the scanner's job contract is
  available to the API, so the deep-scan drawer shows status only.
- The legacy routes (`/api/identities`, `/api/credentials`, `/api/events`,
  `/api/scans`, `/api/dashboard/*`) read older tables and would not agree with
  the v1 numbers on the same screen.

## Running it

```bash
cp .env.example .env     # optional: only if the API is not on localhost:8080
npm install
npm run dev              # http://localhost:3000
```

Start the Go API first. The dev server proxies `/api/*` to `API_UPSTREAM`.

`npm run build` emits `dist/`. `npm run lint` runs oxlint.

| Variable | Side | Meaning |
|---|---|---|
| `VITE_API_URL` | client | Base URL of the API. Leave empty so the browser calls same-origin `/api`. Set it only when the API is on another origin, and allow that origin in the API's CORS settings. |
| `API_UPSTREAM` | dev server | Where `npm run dev` proxies `/api/*`. Default `http://localhost:8080`. |

## Roles

The roles are the API's own (`users.role`). The API enforces them; the console
only avoids offering controls the API would refuse.

| Role | Can |
|---|---|
| `admin`, `team_lead` | read everything; mark exposed credentials safe, restore them, record a verdict; edit an identity's functional class, owner and environment |
| `developer`, `auditor` | read everything, export the inventory |

Note: the API currently accepts identity edits (`PATCH`) from any signed-in
user. The console offers editing to admins and team leads only; enforce the
same rule on the server before relying on it.

## Deploying it

```bash
docker build -t nhi-console:latest .
docker run --rm -p 8080:8080 -e API_UPSTREAM=http://nhi-api:8080 nhi-console:latest
```

The image is nginx serving the built files. nginx proxies `/api/*` to
`API_UPSTREAM` (resolved at container start, so one image serves every
environment), sets security headers including a CSP with `connect-src 'self'`,
and answers `/healthz` itself. See `Dockerfile` and `nginx/`.

## Behaviour worth knowing

- **Filters live in the URL.** A dashboard drill-down, a bookmark and a shared
  link open the same list. Values the API would reject (a malformed account
  id, an unknown sort column) are dropped when the URL is read, so a stale link
  never turns a screen into an error.
- **Each panel fails on its own.** One unavailable data source shows an inline
  error with Retry in its panel; the rest of the screen still loads.
- **Null is not zero.** Summary fields the API returns as `null` read "Not
  reported", never `0`.
- **Errors are read from both API envelopes** (`{error:{code,message}}` on v1
  routes, `{success:false,message}` on auth) and shown in plain words. A 401
  ends the session; a wrong password on the sign-in form does not.
- **Exports go through the API** with the bearer token and download as files;
  a too-large export says to narrow the filters.

## Structure

```
src/
  app/        providers, auth, route guard, role checks
  shell/      top bar, sidebar, breadcrumbs, command palette
  features/   overview, identities, exposure, auth
  lib/api/    the HTTP client, session storage and every endpoint call
  lib/        labels, formatting, roles, hooks
  ui/         design-system primitives (panels, grids, drawers, fields)
  charts/     bar list
```

`docs/UX-DECISIONS.md` is the design rationale carried over from the earlier
build; sections about screens that are not in this build no longer apply.
