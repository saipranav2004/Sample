import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import { homeFor } from '../lib/roles';
import { ThemeProvider } from './ThemeContext';
import { RequireAuth } from './RequireAuth';
import { ToastProvider } from '../ui/Toast';
import { AppShell } from '../shell/AppShell';
import { RouteFallback } from '../shell/RouteFallback';
import LoginPage from '../features/auth/LoginPage';

/* Routes are split per screen. The charting library only ships with the
   screens that draw charts, so first paint after sign-in stays small. */
const OverviewPage = lazy(() => import('../features/overview/OverviewPage'));
const IdentitiesPage = lazy(() => import('../features/identities/IdentitiesPage'));
const IdentityPage = lazy(() => import('../features/identities/IdentityPage'));
const DormantPage = lazy(() => import('../features/identities/DormantPage'));
const FindingsPage = lazy(() => import('../features/exposure/FindingsPage'));
const DismissedPage = lazy(() => import('../features/exposure/DismissedPage'));
const NotFoundPage = lazy(() => import('../features/NotFoundPage'));

function screen(Page) {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Page />
    </Suspense>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <BrowserRouter>
          <AuthProvider>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route
                element={
                  <RequireAuth>
                    <AppShell />
                  </RequireAuth>
                }
              >
                <Route index element={<Navigate to={homeFor()} replace />} />
                <Route path="/overview" element={screen(OverviewPage)} />
                <Route path="/identities" element={screen(IdentitiesPage)} />
                <Route path="/identities/:id" element={screen(IdentityPage)} />
                <Route path="/dormant" element={screen(DormantPage)} />
                <Route path="/exposure" element={screen(FindingsPage)} />
                <Route path="/exposure/dismissed" element={screen(DismissedPage)} />
                <Route path="*" element={screen(NotFoundPage)} />
              </Route>
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </ToastProvider>
    </ThemeProvider>
  );
}
