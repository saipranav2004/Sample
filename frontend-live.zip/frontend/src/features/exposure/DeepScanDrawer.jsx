import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, GitBranch, Info, Radar, RefreshCw } from 'lucide-react';
import { fetchDeepScanStatus } from '../../lib/api/endpoints';
import { normalisePlatform, platformMeta } from '../../lib/domain';
import { formatDateTime, formatNumber, formatRelative } from '../../lib/format';
import { Button } from '../../ui/Button';
import { Field, Input, SearchInput } from '../../ui/Field';
import { Drawer } from '../../ui/Overlay';
import { SectionLabel } from '../../ui/Panel';
import { ClearState, EmptyState } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import {
  DEEP_SCAN_POLL_MS,
  deepScanStateMeta,
  describeDeepScanFailure,
} from './scannerState';

/**
 * Deep scan status.
 *
 * A deep scan walks a repository's whole history, which is the only way to
 * find a secret that was committed and later deleted. This drawer shows the
 * state of each repository's scan from `GET /api/deep-scan-status`.
 *
 * Starting a scan is not offered: the NHI API answers `POST /api/deep-scan`
 * with 501 until the scanner's job contract is available to it, and a button
 * that always fails would be worse than an honest note.
 *
 * The repository list is built from the findings the screen behind this has
 * already loaded - distinct (client_id, repository) pairs, which is how the
 * API identifies a scan. Only running scans are polled, at the five-second
 * interval the scanner's own dashboard uses.
 */
export function DeepScanDrawer({ open, onClose, findings = [] }) {
  const [search, setSearch] = useState('');
  const [manualClient, setManualClient] = useState('');
  const [manualRepo, setManualRepo] = useState('');
  const [manualError, setManualError] = useState('');
  /* Repositories the operator named by hand, so a repository with no findings
     yet - which is exactly the case a deep scan is for - can still be asked
     for. Kept beside the discovered list rather than merged into it, because
     the two have different provenance and the reader should be able to tell. */
  const [manualTargets, setManualTargets] = useState([]);

  /* One row per repository the service has ever reported a finding against.
     Distinct (client_id, repository), which is the pair the two deep-scan
     endpoints identify a scan by - not the repository alone, because the same
     repository name can exist under two clients. */
  const discovered = useMemo(() => {
    const rows = new Map();
    for (const finding of findings) {
      if (!finding.client_id || !finding.repository) continue;
      const key = `${finding.client_id}␟${finding.repository}`;
      const existing = rows.get(key);
      if (existing) {
        existing.findings += 1;
        continue;
      }
      rows.set(key, {
        key,
        clientId: finding.client_id,
        repository: finding.repository,
        platform: normalisePlatform(finding.platform),
        findings: 1,
        source: 'findings',
      });
    }
    return [...rows.values()].sort(
      (a, b) => b.findings - a.findings || a.repository.localeCompare(b.repository),
    );
  }, [findings]);

  const targets = useMemo(() => {
    const seen = new Set(discovered.map((row) => row.key));
    return [...discovered, ...manualTargets.filter((row) => !seen.has(row.key))];
  }, [discovered, manualTargets]);

  const visible = useMemo(() => {
    const needle = search.trim().toLowerCase();
    if (!needle) return targets;
    return targets.filter((row) =>
      `${row.repository} ${row.clientId}`.toLowerCase().includes(needle),
    );
  }, [targets, search]);

  const { statuses, refresh } = useDeepScanStatuses(targets, open);

  const onAddManual = useCallback(
    (event) => {
      event.preventDefault();
      const clientId = manualClient.trim();
      const repository = manualRepo.trim();
      if (!clientId || !repository) {
        setManualError('Both a client id and a repository are required.');
        return;
      }
      const key = `${clientId}␟${repository}`;
      if (targets.some((row) => row.key === key)) {
        setManualError('That repository is already on the list below.');
        return;
      }
      setManualError('');
      /* No platform is claimed for a hand-entered row: the status answer
         reports it, and guessing from the presence of a slash could be wrong. */
      setManualTargets((current) => [
        ...current,
        { key, clientId, repository, platform: null, findings: 0, source: 'manual' },
      ]);
      setManualClient('');
      setManualRepo('');
    },
    [manualClient, manualRepo, targets],
  );

  const counts = useMemo(() => {
    const out = { running: 0, complete: 0, failed: 0, not_started: 0 };
    for (const row of targets) {
      const state = String(statuses[row.key]?.data?.status || 'not_started').toLowerCase();
      if (state in out) out[state] += 1;
    }
    return out;
  }, [targets, statuses]);

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="xl"
      eyebrow="Credential exposure"
      title="Deep scan status"
      subtitle="Whether each repository's whole history has been read, not just its files as they are now."
      footer={
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-[11.5px] text-ink-3">
            {counts.running > 0
              ? `Polling every ${DEEP_SCAN_POLL_MS / 1000} seconds while a walk is running.`
              : 'Nothing is running, so nothing is being polled.'}
          </p>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </div>
      }
    >
      <div className="flex flex-col gap-4">
        <p className="flex items-start gap-2 rounded-[var(--radius-control)] border border-info/25 bg-info-soft px-3.5 py-2.5 text-[12.5px] leading-relaxed text-ink-2">
          <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-info" />
          <span>
            Deep scans are requested through the scanner service. This console shows their progress
            and results; starting one from here is not available yet.
          </span>
        </p>
        <div className="grid gap-3 @min-[34rem]:grid-cols-2">
          <div className="rounded-[var(--radius-control)] border border-line bg-surface-2 p-3.5">
            <SectionLabel>The scan that already runs</SectionLabel>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">
              Reads the files as they exist at HEAD. It catches a secret that is in the code now,
              which is most of them, and it is cheap enough to run on every push.
            </p>
          </div>
          <div className="rounded-[var(--radius-control)] border border-line bg-surface-2 p-3.5">
            <SectionLabel>What a deep scan adds</SectionLabel>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">
              Reads every commit from the first one to HEAD. It catches the secret somebody
              committed and then deleted in the next commit - still present in every clone and
              every fork, and the one people believe they have already fixed.
            </p>
          </div>
        </div>

        {/* Four counts rather than four tiles: inside a drawer the tile
            treatment competes with the list that matters. */}
        <dl className="flex flex-wrap gap-x-6 gap-y-2 rounded-[var(--radius-control)] border border-line bg-inset px-3.5 py-2.5 text-[12px]">
          <Fact label="Repositories" value={formatNumber(targets.length)} />
          <Fact label="Running" value={formatNumber(counts.running)} />
          <Fact label="History fully read" value={formatNumber(counts.complete)} />
          <Fact label="Failed" value={formatNumber(counts.failed)} />
        </dl>

        <div className="overflow-hidden rounded-[var(--radius-panel)] border border-line">
          <div className="flex flex-wrap items-center gap-3 border-b border-line bg-surface-2 px-3.5 py-2.5">
            <SearchInput
              size="sm"
              value={search}
              onChange={setSearch}
              placeholder="Search repository or client id…"
              className="w-full min-w-0 sm:max-w-xs"
            />
            <p className="text-[12px] text-ink-3" data-numeric="">
              {formatNumber(visible.length)} of {formatNumber(targets.length)}
            </p>
          </div>

          {visible.length === 0 ? (
            targets.length === 0 ? (
              <ClearState
                compact
                title="No repositories to scan"
                description="The scanner has not reported a finding against any repository yet. A repository can still be checked by name below."
              />
            ) : (
              <EmptyState
                compact
                icon={Radar}
                title="No repository matches that search"
                description="Clear the search to see every repository the scanner knows about."
              />
            )
          ) : (
            <ul className="divide-y divide-line">
              {visible.map((row) => (
                <TargetRow
                  key={row.key}
                  row={row}
                  state={statuses[row.key]}
                  onRefresh={() => refresh(row)}
                />
              ))}
            </ul>
          )}
        </div>

        {/* A repository with zero findings never appears above - and that is
            exactly the repository somebody wants to deep scan, because a clean
            snapshot says nothing about the history behind it. */}
        <div className="rounded-[var(--radius-panel)] border border-line bg-surface-2 p-3.5">
          <SectionLabel>Check a repository that has no findings yet</SectionLabel>
          <p className="mt-1 text-[12px] leading-relaxed text-ink-3">
            The list above is built from findings, so a repository the scanner has never flagged is
            not on it.
          </p>
          <form className="mt-3 flex flex-wrap items-end gap-3" onSubmit={onAddManual}>
            <Field label="Client id" htmlFor="deep-client" className="min-w-[12rem] flex-1">
              <Input
                id="deep-client"
                value={manualClient}
                onChange={(event) => setManualClient(event.target.value)}
                placeholder="e.g. test-sample-client"
              />
            </Field>
            <Field
              label="Repository"
              htmlFor="deep-repo"
              className="min-w-[13rem] flex-1"
              hint="A bare name for CodeCommit, owner/repo for GitHub."
            >
              <Input
                id="deep-repo"
                value={manualRepo}
                onChange={(event) => setManualRepo(event.target.value)}
                placeholder="e.g. test-sample"
              />
            </Field>
            <Button type="submit" variant="secondary">
              Check status
            </Button>
          </form>
          {manualError && <p className="mt-2 text-[12.5px] text-critical">{manualError}</p>}
          <p className="mt-2 text-[11.5px] leading-relaxed text-ink-3">
            The name has to match exactly how the scanner recorded it, or the answer is
            &ldquo;Not started&rdquo;.
          </p>
        </div>
      </div>
    </Drawer>
  );
}

/** One repository and its deep-scan state. */
function TargetRow({ row, state, onRefresh }) {
  const status = state?.data;
  const meta = deepScanStateMeta(status?.status);
  const running = String(status?.status).toLowerCase() === 'running';
  const failed = String(status?.status).toLowerCase() === 'failed';
  const platform = row.platform ? platformMeta(row.platform) : null;
  /* The service reports which platform it holds this client under, which is
     better than anything the dashboard could infer - so once a status has come
     back it overrides the label derived from the findings. */
  const reported = status?.platform ? platformMeta(status.platform) : null;

  return (
    <li className="px-4 py-3.5">
      <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2.5">
        <div className="min-w-0">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <GitBranch aria-hidden="true" className="size-4 shrink-0 text-ink-3" />
            <p className="min-w-0 truncate text-[13px] font-semibold text-ink" title={row.repository}>
              {row.repository}
            </p>
            {(reported ?? platform) && (
              <Tag tone={(reported ?? platform).tone} size="sm">
                {(reported ?? platform).label}
              </Tag>
            )}
            {row.source === 'manual' && (
              <Tag tone="neutral" size="sm">
                Added by hand
              </Tag>
            )}
          </div>
          <p className="mt-1 truncate font-mono text-[11.5px] text-ink-3">{row.clientId}</p>
          <p className="mt-1 text-[11.5px] leading-relaxed text-ink-3">
            {row.findings > 0
              ? `${formatNumber(row.findings)} live finding${row.findings === 1 ? '' : 's'} from the snapshot scan.`
              : 'No findings from the snapshot scan.'}{' '}
            {meta.description}
          </p>
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <Tag tone={meta.tone} size="sm" dot={meta.tone !== 'neutral'}>
            {running ? (
              <span className="flex items-center gap-1.5">
                <span aria-hidden="true" className="deep-scan-pulse" />
                {meta.label}
              </span>
            ) : (
              meta.label
            )}
          </Tag>
          {/* A labelled button: "re-check" is not a glyph anybody recognises. */}
          <Button
            variant="ghost"
            size="sm"
            icon={RefreshCw}
            onClick={onRefresh}
            loading={state?.loading}
            aria-label={`Re-check the deep scan status for ${row.repository}`}
          >
            Re-check
          </Button>
        </div>
      </div>

      {/* The numbers only exist once a walk has finished, so the row stays one
          line until there is something true to put on the second. */}
      {status && status.status !== 'not_started' && (
        <dl className="mt-2.5 flex flex-wrap gap-x-6 gap-y-1.5 rounded-[var(--radius-control)] bg-surface-2 px-3 py-2 text-[11.5px]">
          <Fact label="Requested" value={status.requested_at ? formatRelative(status.requested_at) : '-'} title={status.requested_at ? formatDateTime(status.requested_at) : undefined} />
          {status.completed_at && (
            <Fact label="Finished" value={formatRelative(status.completed_at)} title={formatDateTime(status.completed_at)} />
          )}
          {Number.isFinite(status.commits_scanned) && (
            <Fact label="Commits read" value={formatNumber(status.commits_scanned)} />
          )}
          {Number.isFinite(status.findings) && (
            <Fact label="Secrets found" value={formatNumber(status.findings)} />
          )}
        </dl>
      )}

      {status?.status === 'complete' && Number.isFinite(status.findings) && (
        <p className="mt-2 flex items-start gap-2 text-[12px] leading-relaxed text-ink-2">
          <CheckCircle2 aria-hidden="true" className="mt-px size-3.5 shrink-0 text-low" />
          {status.findings > 0 ? (
            <span>
              The history walk added {formatNumber(status.findings)} finding
              {status.findings === 1 ? '' : 's'}, which are in the live set on{' '}
              <Link to="/exposure" className="text-brand hover:underline">
                Exposed credentials
              </Link>
              .
            </span>
          ) : (
            <span>The whole history was read and no secret was found anywhere in it.</span>
          )}
        </p>
      )}

      {failed && <FailureNote status={status} />}

      {state?.error && !status && (
        <p className="mt-2 text-[12px] text-ink-3">
          The status for this repository could not be read. It has not necessarily failed - only
          the check did.
        </p>
      )}
    </li>
  );
}

function Fact({ label, value, title }) {
  return (
    <div className="flex items-baseline gap-1.5">
      <dt className="text-ink-3">{label}</dt>
      <dd className="font-medium text-ink-2" data-numeric="" title={title}>
        {value}
      </dd>
    </div>
  );
}

/**
 * A failed walk, explained before it is quoted.
 *
 * `error` is the raw exception the scanner caught; the API sends it to admins
 * only and a fixed sentence to everyone else. It is put under a heading that
 * says what it is, with the likely cause named above it.
 */
function FailureNote({ status }) {
  const failure = describeDeepScanFailure(status);
  return (
    <div className="mt-2.5 rounded-[var(--radius-control)] border border-critical/30 bg-critical-soft p-3">
      <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-ink">
        <AlertTriangle aria-hidden="true" className="mt-px size-3.5 shrink-0 text-critical" />
        <span>
          <span className="font-semibold">{failure.cause}</span> {failure.fix}
        </span>
      </p>
      {status.failed_at && (
        <p className="mt-1.5 pl-5.5 text-[11.5px] text-ink-3">
          Failed {formatRelative(status.failed_at)} ({formatDateTime(status.failed_at)}).
        </p>
      )}
      {failure.raw && (
        <details className="mt-2 pl-5.5">
          <summary className="cursor-pointer text-[11.5px] font-medium text-ink-2">
            What the scanner reported
          </summary>
          <pre className="mt-1.5 overflow-x-auto rounded-[var(--radius-control)] border border-line bg-inset p-2.5 font-mono text-[11px] leading-relaxed whitespace-pre-wrap text-ink-3">
            {failure.raw}
          </pre>
        </details>
      )}
    </div>
  );
}

/**
 * Statuses for every listed repository, polled while any of them is running.
 *
 * One interval for the whole page rather than one per row: a dozen timers
 * firing at slightly different moments produces a dozen requests a second
 * apart instead of one burst every five, and each row then re-renders on its
 * own schedule. The interval is torn down the moment nothing is running, so an
 * idle page makes no requests at all.
 *
 * Nothing happens while the drawer is closed. It is mounted all the time on the
 * findings screen, and an earlier version read a status for every repository
 * the moment that screen loaded - and kept polling any running scan in the
 * background - whether or not anybody ever opened the drawer. Every opening
 * re-reads every row, because a scan requested elsewhere, or one that finished
 * while the drawer was shut, would otherwise show its old state. The first
 * read is done a few rows at a time so a long list does not fire every
 * request at once.
 */
const CONCURRENT_READS = 4;

function useDeepScanStatuses(targets, open) {
  const [statuses, setStatuses] = useState({});
  const targetsRef = useRef(targets);
  targetsRef.current = targets;

  const load = useCallback(async (row) => {
    setStatuses((current) => ({
      ...current,
      [row.key]: { ...current[row.key], loading: true },
    }));
    try {
      const data = await fetchDeepScanStatus({ clientId: row.clientId, repository: row.repository });
      setStatuses((current) => ({ ...current, [row.key]: { data, loading: false, error: null } }));
      return data;
    } catch (error) {
      if (error?.code === 'CANCELLED') return null;
      setStatuses((current) => ({
        ...current,
        [row.key]: { data: current[row.key]?.data, loading: false, error },
      }));
      return null;
    }
  }, []);

  /* Every listed repository is read once, so the list arrives with real states
     rather than a column of "not started" that turns out to be wrong. */
  const loadedRef = useRef(new Set());
  useEffect(() => {
    if (!open) {
      loadedRef.current = new Set();
      return undefined;
    }
    /* A row is marked read when a worker takes it, so rows still queued when
       this effect is superseded are picked up by the next run. */
    const queue = targets.filter((row) => !loadedRef.current.has(row.key));
    let cancelled = false;
    const worker = async () => {
      while (!cancelled && queue.length > 0) {
        const row = queue.shift();
        if (loadedRef.current.has(row.key)) continue;
        loadedRef.current.add(row.key);
        await load(row);
      }
    };
    for (let index = 0; index < Math.min(CONCURRENT_READS, queue.length); index += 1) worker();
    return () => {
      cancelled = true;
    };
  }, [targets, load, open]);

  const runningKeys = targets
    .filter((row) => String(statuses[row.key]?.data?.status).toLowerCase() === 'running')
    .map((row) => row.key)
    .join(',');

  useEffect(() => {
    if (!open || !runningKeys) return undefined;
    const interval = setInterval(() => {
      const keys = new Set(runningKeys.split(','));
      for (const row of targetsRef.current) {
        if (keys.has(row.key)) load(row);
      }
    }, DEEP_SCAN_POLL_MS);
    return () => clearInterval(interval);
  }, [runningKeys, load, open]);

  return { statuses, refresh: load };
}

