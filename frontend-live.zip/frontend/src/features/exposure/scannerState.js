/**
 * A finding's identity.
 *
 * `finding_id` is the service's own unique id and the guide names it as the
 * React list key, so it is used first. The four-field composite behind it is
 * the fallback, and it is not arbitrary: those are exactly the four fields the
 * allowlist endpoints require to identify a finding, which is the service
 * telling us what a finding's identity is. It covers a row recorded before
 * `finding_id` existed - without it those rows all key on `undefined`, React
 * sees one duplicated key for the whole list, reconciliation falls back to
 * index order, and selecting a row after a dismiss opens its neighbour.
 *
 * Allowlist writes still send the four fields (see `toAllowlistPayload`);
 * `finding_id` is a read-side key, not an accepted request parameter.
 */
export function findingKey(finding) {
  if (finding?.finding_id !== undefined && finding?.finding_id !== null) {
    return `id:${finding.finding_id}`;
  }
  return [finding?.client_id, finding?.file_path, finding?.detector, finding?.redacted].join('|');
}

/**
 * What went wrong loading credential exposure data, in terms of what to do.
 *
 * The NHI API reads the scanner's tables itself, so the failures that matter
 * are on that side: the tables missing or unreadable (503), the API down or
 * slow, or a response that is not the API's at all.
 */
export function describeScannerError(error) {
  if (error?.code === 'DATA_SOURCE_UNAVAILABLE' || error?.status === 503) {
    return {
      title: 'Credential exposure data is not available',
      message:
        'The API is running but cannot read the secret scanner tables. They are missing from the database, or the API\'s database role has not been granted access to them. An administrator can fix this; nothing on this screen will.',
      configuration: true,
    };
  }
  if (error?.code === 'BAD_RESPONSE') {
    return {
      title: 'The API path is not reaching the NHI API',
      message:
        'Something other than the NHI API answered /api. Run the app with `npm run dev` (which proxies it) or behind the provided nginx configuration.',
      configuration: true,
    };
  }
  if (error?.status === 504 || error?.code === 'TIMEOUT' || error?.code === 'ECONNABORTED') {
    return {
      title: 'The API took too long to answer',
      message: 'Reading the findings did not finish in time. Try again; if it keeps happening the database is under load.',
      configuration: false,
    };
  }
  if (error?.code === 'NETWORK' || error?.status === 502) {
    return {
      title: 'Cannot reach the API',
      message: 'The NHI API did not answer. Check that it is running and reachable, then try again.',
      configuration: true,
    };
  }
  return {
    title: 'Credential exposure data failed to load',
    message: error?.message || 'The API returned an unexpected error.',
    configuration: false,
  };
}

/**
 * Counts by risk tier, platform and repository - the guide's own recipe.
 *
 * `CRITICAL` is counted but the screens do not give it a tile of its own: the
 * service cannot currently emit it, so a tile for it would be a permanent
 * zero. Counted anyway, because the day it starts emitting one the number has
 * to appear somewhere rather than be silently dropped.
 */
export function summariseFindings(findings = []) {
  const byTier = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  const byPlatform = { github: 0, codecommit: 0 };
  const repositories = new Set();
  const detectors = new Map();

  for (const finding of findings) {
    const tier = String(finding.risk_tier || '').toUpperCase();
    if (tier in byTier) byTier[tier] += 1;

    // A finding recorded before platform tracking existed reports null and is
    // always CodeCommit, so anything that is not explicitly GitHub counts there.
    if (String(finding.platform || '').toLowerCase() === 'github') byPlatform.github += 1;
    else byPlatform.codecommit += 1;

    if (finding.repository) repositories.add(finding.repository);
    if (finding.detector) detectors.set(finding.detector, (detectors.get(finding.detector) || 0) + 1);
  }

  return {
    total: findings.length,
    byTier,
    byPlatform,
    repositoryCount: repositories.size,
    detectors: [...detectors.entries()]
      .map(([key, value]) => ({ key, value }))
      .sort((a, b) => b.value - a.value),
  };
}

/** Groups findings by (repository, commit_id) so one push reads as one push. */
export function groupByPush(findings = []) {
  const groups = new Map();
  for (const finding of findings) {
    const key = `${finding.repository || '?'}@${finding.commit_id || '?'}`;
    if (!groups.has(key)) {
      groups.set(key, {
        key,
        repository: finding.repository,
        commitId: finding.commit_id,
        branch: finding.branch,
        author: finding.author,
        createdAt: finding.created_at,
        platform: finding.platform,
        findings: [],
      });
    }
    groups.get(key).findings.push(finding);
  }
  return [...groups.values()];
}

/* ── Deep scan status ─────────────────────────────────────────────────────── */

/**
 * How often to poll `GET /api/deep-scan-status`.
 *
 * Five seconds, the interval the scanner's own dashboard uses. There is no
 * push notification for a deep scan, so polling is the only mechanism.
 */
export const DEEP_SCAN_POLL_MS = 5000;

export const DEEP_SCAN_STATES = {
  not_started: {
    label: 'Not started',
    tone: 'neutral',
    description: 'No deep scan has ever been requested for this repository.',
  },
  running: {
    label: 'Running',
    tone: 'info',
    description: 'Walking every commit from the first one to HEAD.',
  },
  complete: {
    label: 'Complete',
    tone: 'low',
    description: 'The whole history has been read. Any secret it found is in the live set.',
  },
  failed: {
    label: 'Failed',
    tone: 'critical',
    description: 'The history walk stopped with an error before it finished.',
  },
};

export function deepScanStateMeta(value) {
  const key = String(value || 'not_started').toLowerCase();
  return (
    DEEP_SCAN_STATES[key] ?? {
      label: value ? String(value) : 'Unknown',
      tone: 'neutral',
      description: 'The service reported a state this dashboard does not recognise.',
    }
  );
}

/**
 * What went wrong with a deep scan, in words an operator can act on.
 *
 * `error` is the scanner's raw exception message. The API returns it to
 * admins only; other roles receive a fixed sentence instead. It is shown under
 * a heading that says what it is, and the two commonest causes are named
 * because the raw string does not say what to do about either.
 */
export function describeDeepScanFailure(status) {
  const raw = String(status?.error || '');
  if (/AccessDenied|UnauthorizedOperation|not authorized/i.test(raw)) {
    return {
      cause: 'The scanner is missing an IAM permission on this repository.',
      fix: 'Re-check the read permissions granted to the scanner role, then have the scan requested again.',
      raw,
    };
  }
  if (/installation|revoked|404|Not Found|credentials/i.test(raw)) {
    return {
      cause: 'The GitHub installation for this client looks revoked or removed.',
      fix: 'Re-install the app for this organisation, then have the scan requested again.',
      raw,
    };
  }
  return {
    cause: 'The history walk raised before it finished.',
    fix: 'A new request for this repository starts a fresh attempt and clears this error.',
    raw,
  };
}
