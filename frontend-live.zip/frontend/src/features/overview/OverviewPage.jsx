import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Clock,
  FileWarning,
  GitBranch,
  Fingerprint,
  Globe2,
  KeyRound,
  RotateCw,
  Server,
} from 'lucide-react';
import {
  fetchCredentialsByType,
  fetchDashboardSummary,
  fetchExposureSummary,
  fetchFindings,
  fetchIdentitiesByAccount,
  fetchIdentitiesByClass,
  fetchIdentitiesByRegion,
  fetchIdentitiesByType,
} from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative, percentValue } from '../../lib/format';
import { credentialTypeLabel, functionalClassLabel, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { BarList } from '../../charts/BarList';
import { Button } from '../../ui/Button';
import { ProportionBar } from '../../ui/Meter';
import { Panel, PanelHeader } from '../../ui/Panel';
import { MetricTile } from '../../ui/Stat';
import { Tag } from '../../ui/Tag';
import { ChartSkeleton, LoadingAnnouncement, Skeleton, StatStripSkeleton } from '../../ui/Skeleton';
import { ClearState, EmptyState, ErrorState, InlineError } from '../../ui/States';
import { TONE_VAR } from '../../ui/cn';
import { describeScannerError, summariseFindings } from '../exposure/scannerState';

/**
 * Dashboard. Every number on it comes from one of the API's v1 dashboard
 * endpoints or from the credential exposure findings; each panel loads and
 * fails on its own, so one unavailable source never blanks the screen.
 *
 * Nullable fields in the summary mean "this source is not available yet", not
 * zero, and are shown as "Not reported".
 */
export default function OverviewPage() {
  const summary = useQuery((signal) => fetchDashboardSummary({}, signal), []);
  const byType = useQuery((signal) => fetchIdentitiesByType({}, signal), []);
  const byClass = useQuery((signal) => fetchIdentitiesByClass({}, signal), []);
  const byAccount = useQuery((signal) => fetchIdentitiesByAccount({}, signal), []);
  const byRegion = useQuery((signal) => fetchIdentitiesByRegion({}, signal), []);
  const exposure = useQuery((signal) => fetchExposureSummary({}, signal), []);
  const credentials = useQuery((signal) => fetchCredentialsByType({}, signal), []);
  const findings = useQuery((signal) => fetchFindings(signal), []);

  const queries = [summary, byType, byClass, byAccount, byRegion, exposure, credentials, findings];
  const refreshing = queries.some((query) => query.isRefreshing || (query.isLoading && query.data));
  const refreshAll = () => queries.forEach((query) => query.refetch());

  /* The summary is the spine of the screen. If it cannot load at all there is
     nothing honest to show around it. */
  if (summary.isError && !summary.data) {
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Dashboard" lede="Discovery results could not be loaded." />
        <Panel>
          <ErrorState error={summary.error} onRetry={refreshAll} />
        </Panel>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Dashboard"
        lede="Non-human identities discovered across your AWS accounts, and the credentials exposed in code."
        actions={
          <Button variant="secondary" icon={RotateCw} onClick={refreshAll} loading={refreshing}>
            Refresh
          </Button>
        }
        meta={<ScanStrip query={summary} />}
      />

      <HeadlineTiles summary={summary} findings={findings} />

      <div className="grid gap-4 @min-[52rem]:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <ExposurePanel query={exposure} total={summary.data?.total_identities} />
        <StatusPanel query={summary} />
      </div>

      <div className="grid gap-4 @min-[52rem]:grid-cols-2">
        <BreakdownPanel
          title="Identities by type"
          query={byType}
          items={(data) =>
            data.breakdown.map((row) => ({
              key: row.identity_type,
              label: identityTypeLabel(row.identity_type),
              value: row.count,
              to: `/identities?identity_type=${encodeURIComponent(row.identity_type)}`,
            }))
          }
          emptyTitle="No identities discovered"
          emptyText="Discovery has not recorded any identity yet."
        />
        <BreakdownPanel
          title="Identities by functional class"
          query={byClass}
          items={(data) =>
            data.breakdown.map((row) => ({
              key: row.functional_class,
              label: functionalClassLabel(row.functional_class),
              value: row.count,
              to: `/identities?functional_class=${encodeURIComponent(row.functional_class)}`,
            }))
          }
          emptyTitle="No identities to classify"
          emptyText="Functional classes appear once identities are discovered."
        />
      </div>

      <div className="grid gap-4 @min-[52rem]:grid-cols-2">
        <AccountsPanel query={byAccount} />
        <BreakdownPanel
          title="Identities by region"
          query={byRegion}
          subtitle={(data) => `${formatNumber(data.total_regions)} region${data.total_regions === 1 ? '' : 's'}`}
          items={(data) =>
            data.breakdown.map((row) => ({
              key: row.region,
              label: regionLabel(row.region),
              value: row.identity_count,
              to: `/identities?region=${encodeURIComponent(row.region)}`,
            }))
          }
          emptyTitle="No regions yet"
          emptyText="Regions appear once identities are discovered."
        />
      </div>

      <div className="grid gap-4 @min-[52rem]:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]">
        <CredentialsPanel query={credentials} summary={summary.data} />
        <FindingsPanel query={findings} />
      </div>
    </div>
  );
}

/* ── Scan strip ──────────────────────────────────────────────────────────── */

function ScanStrip({ query }) {
  if (query.isLoading && !query.data) return <Skeleton className="h-5 w-72 rounded" />;
  const data = query.data;
  if (!data) return null;
  const status = data.scan_status;
  const tone = !status ? 'neutral' : /fail|error/i.test(status) ? 'critical' : /complete|success/i.test(status) ? 'low' : 'info';
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[12.5px] text-ink-3">
      <span className="inline-flex items-center gap-1.5">
        <Clock aria-hidden="true" className="size-3.5" />
        {data.last_scan_at ? (
          <>
            Last scan{' '}
            <time dateTime={data.last_scan_at} title={formatDateTime(data.last_scan_at)} className="font-medium text-ink-2">
              {formatRelative(data.last_scan_at)}
            </time>
          </>
        ) : (
          'No completed scan reported'
        )}
      </span>
      {status && (
        <Tag size="sm" tone={tone} dot>
          {tokenLabel(status)}
        </Tag>
      )}
      {Number.isFinite(data.scan_duration_seconds) && <span>Took {formatSeconds(data.scan_duration_seconds)}</span>}
      {Number.isFinite(data.total_accounts_scanned) && (
        <span>
          {formatNumber(data.total_accounts_scanned)} account{data.total_accounts_scanned === 1 ? '' : 's'}
        </span>
      )}
      {Number.isFinite(data.total_regions_scanned) && (
        <span>
          {formatNumber(data.total_regions_scanned)} region{data.total_regions_scanned === 1 ? '' : 's'}
        </span>
      )}
    </div>
  );
}

function formatSeconds(total) {
  const seconds = Math.max(0, Math.round(total));
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ${seconds % 60}s`;
  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
}

/* ── Headline tiles ──────────────────────────────────────────────────────── */

const NOT_REPORTED = 'Not reported by the API yet';

function HeadlineTiles({ summary, findings }) {
  if (summary.isLoading && !summary.data) {
    return (
      <>
        <LoadingAnnouncement label="Loading dashboard metrics" />
        <StatStripSkeleton count={4} />
      </>
    );
  }
  const data = summary.data;
  const total = Number(data.total_identities) || 0;
  const active = Number(data.identities_by_status?.active) || 0;

  return (
    <div className="grid gap-3 @min-[30rem]:grid-cols-2 @min-[54rem]:grid-cols-4">
      <MetricTile
        as={Link}
        to="/identities"
        className="animate-rise"
        data-stagger=""
        style={{ '--stagger': 0 }}
        label="Identities"
        value={total}
        icon={Fingerprint}
        tone="brand"
        caption={`${formatNumber(active)} active`}
        meter={percentValue(active, total)}
        meterLabel="Share active"
      />
      <MetricTile
        className="animate-rise"
        data-stagger=""
        style={{ '--stagger': 1 }}
        label="Changes in 24 hours"
        value={data.new_identities_last_24h}
        unit="new"
        icon={Clock}
        tone="info"
        caption={`${formatNumber(data.removed_identities_last_24h)} removed in the same period`}
      />
      <MetricTile
        className="animate-rise"
        data-stagger=""
        style={{ '--stagger': 2 }}
        label="Credentials"
        value={data.total_credentials}
        icon={KeyRound}
        tone="medium"
        caption={
          data.total_credentials === null || data.total_credentials === undefined
            ? NOT_REPORTED
            : Number.isFinite(data.new_credentials_last_24h)
              ? `${formatNumber(data.new_credentials_last_24h)} new in 24 hours`
              : 'Keys, secrets and certificates'
        }
      />
      <FindingsTile query={findings} />
    </div>
  );
}

function FindingsTile({ query }) {
  const summary = useMemo(() => summariseFindings(query.data?.findings), [query.data]);
  if (query.isLoading && !query.data) {
    return (
      <div className="rounded-[var(--radius-panel)] border border-line bg-surface p-4">
        <Skeleton className="h-3 w-28 rounded" />
        <Skeleton className="mt-3 h-8 w-16 rounded" />
        <Skeleton className="mt-3 h-1.5 w-full rounded-full" />
      </div>
    );
  }
  if (query.isError) {
    const detail = describeScannerError(query.error);
    return (
      <div className="flex flex-col justify-between rounded-[var(--radius-panel)] border border-line bg-surface p-4">
        <p className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Secrets in code</p>
        <p className="mt-2 text-[12.5px] leading-snug text-ink-2">{detail.title}</p>
        <Button variant="ghost" size="sm" icon={RotateCw} onClick={query.refetch} className="mt-2 self-start">
          Retry
        </Button>
      </div>
    );
  }
  const highish = summary.byTier.CRITICAL + summary.byTier.HIGH;
  return (
    <MetricTile
      as={Link}
      to="/exposure"
      className="animate-rise"
      data-stagger=""
      style={{ '--stagger': 3 }}
      label="Secrets in code"
      value={summary.total}
      icon={FileWarning}
      tone={highish > 0 ? 'critical' : 'low'}
      caption={`${formatNumber(highish)} high or critical · ${formatNumber(summary.repositoryCount)} repositories`}
      meter={percentValue(highish, summary.total)}
      meterLabel="Share at high or critical risk"
    />
  );
}

/* ── Exposure ────────────────────────────────────────────────────────────── */

function ExposurePanel({ query, total }) {
  const data = query.data;
  return (
    <Panel prominence="lead" className="animate-rise" data-stagger="" style={{ '--stagger': 3 }}>
      <PanelHeader
        prominence="lead"
        title="Exposure signals"
        subtitle="Identities that are reachable from the internet, unused, or missing the tags that say who owns them."
      />
      <div className="mt-4">
        {query.isLoading && !data ? (
          <ChartSkeleton height={200} bars={5} />
        ) : query.isError ? (
          <InlineError error={query.error} onRetry={query.refetch} label="Exposure signals unavailable" />
        ) : (
          <ul className="divide-y divide-line">
            <SignalRow
              label="Publicly accessible"
              hint="Reachable from outside your network"
              value={data.publicly_accessible?.total}
              total={total}
              tone="critical"
              to="/identities?is_public=true"
              breakdown={data.publicly_accessible?.by_type}
            />
            <SignalRow
              label="Dormant 90 days or more"
              hint="No recorded activity for at least 90 days"
              value={data.dormant_90d?.total}
              total={total}
              tone="high"
              to="/dormant?days=90"
              breakdown={data.dormant_90d?.by_type}
            />
            <SignalRow
              label="Missing an owner tag"
              hint="Nobody is recorded as responsible"
              value={data.missing_owner_tag}
              total={total}
              tone="medium"
            />
            <SignalRow
              label="Missing an environment tag"
              hint="Not marked as production, staging or similar"
              value={data.missing_environment_tag}
              total={total}
              tone="medium"
            />
            <SignalRow
              label="No activity tracked"
              hint="AWS records no last-used time for these"
              value={data.no_activity_tracked}
              total={total}
              tone="neutral"
            />
            <SignalRow
              label="Not defined in infrastructure as code"
              hint="Created by hand rather than by a template"
              value={data.not_in_iac}
              total={total}
              tone="neutral"
            />
          </ul>
        )}
      </div>
    </Panel>
  );
}

function SignalRow({ label, hint, value, total, tone, to, breakdown }) {
  const reported = value !== null && value !== undefined;
  const top = (breakdown ?? []).filter((row) => row.count > 0).slice(0, 3);
  const body = (
    <span className="flex items-start gap-3 py-3">
      <span aria-hidden="true" className="mt-1 size-2 shrink-0 rounded-full" style={{ background: TONE_VAR[tone] }} />
      <span className="min-w-0 flex-1">
        <span className="block text-[13px] font-medium text-ink">{label}</span>
        <span className="mt-0.5 block text-[12px] text-ink-3">
          {reported ? hint : NOT_REPORTED}
          {reported && top.length > 0 && (
            <> · {top.map((row) => `${identityTypeLabel(row.identity_type)} ${formatNumber(row.count)}`).join(', ')}</>
          )}
        </span>
      </span>
      <span className="shrink-0 text-right">
        <span data-numeric="" className="block font-display text-[17px] leading-none font-bold text-ink">
          {reported ? formatNumber(value) : '-'}
        </span>
        {reported && total > 0 && (
          <span data-numeric="" className="mt-1 block text-[11px] text-ink-3">
            {percentValue(value, total).toFixed(0)}%
          </span>
        )}
      </span>
      {to && reported && <ArrowRight aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-ink-3" />}
    </span>
  );
  return (
    <li>
      {to && reported ? (
        <Link to={to} className="block rounded-md transition-colors hover:bg-surface-2 focus-visible:bg-surface-2">
          {body}
        </Link>
      ) : (
        body
      )}
    </li>
  );
}

/* ── Lifecycle status ────────────────────────────────────────────────────── */

function StatusPanel({ query }) {
  const navigate = useNavigate();
  const data = query.data;
  const segments = useMemo(() => {
    const byStatus = data?.identities_by_status ?? {};
    return Object.entries(byStatus)
      .map(([key, value]) => ({ key, label: statusMeta(key).label, value: Number(value) || 0, color: TONE_VAR[statusMeta(key).tone] }))
      .filter((segment) => segment.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [data]);

  return (
    <Panel prominence="quiet" className="animate-rise" data-stagger="" style={{ '--stagger': 4 }}>
      <PanelHeader prominence="quiet" title="Lifecycle status" subtitle="Identities by their current AWS state." />
      <div className="mt-4">
        {query.isLoading && !data ? (
          <ChartSkeleton height={160} bars={3} />
        ) : segments.length === 0 ? (
          <EmptyState compact icon={Server} title="No identities yet" description="Statuses appear once discovery records identities." />
        ) : (
          <>
            <ProportionBar
              segments={segments}
              onSelect={(segment) => navigate(`/identities?status=${encodeURIComponent(segment.key)}`)}
              ariaLabel="Identities by status"
            />
            <ul className="mt-4 divide-y divide-line">
              {segments.map((segment) => (
                <li key={segment.key}>
                  <Link
                    to={`/identities?status=${encodeURIComponent(segment.key)}`}
                    className="flex items-center gap-3 rounded-md py-2.5 text-[13px] transition-colors hover:bg-surface-2"
                  >
                    <span aria-hidden="true" className="size-2.5 shrink-0 rounded-full" style={{ background: segment.color }} />
                    <span className="flex-1 text-ink">{segment.label}</span>
                    <span data-numeric="" className="font-semibold text-ink">
                      {formatNumber(segment.value)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </Panel>
  );
}

/* ── Breakdowns ──────────────────────────────────────────────────────────── */

function BreakdownPanel({ title, subtitle, query, items, emptyTitle, emptyText }) {
  const navigate = useNavigate();
  const data = query.data;
  const rows = useMemo(() => (data ? items(data).filter((row) => row.value > 0) : []), [data, items]);
  return (
    <Panel prominence="quiet" className="animate-rise">
      <PanelHeader prominence="quiet" title={title} subtitle={data && subtitle ? subtitle(data) : undefined} />
      <div className="mt-3">
        {query.isLoading && !data ? (
          <ChartSkeleton height={220} bars={6} />
        ) : query.isError ? (
          <InlineError error={query.error} onRetry={query.refetch} label={`${title} unavailable`} />
        ) : rows.length === 0 ? (
          <EmptyState compact title={emptyTitle} description={emptyText} />
        ) : (
          <BarList items={rows.slice(0, 10)} total={rows.reduce((sum, row) => sum + row.value, 0)} onSelect={(row) => row.to && navigate(row.to)} />
        )}
        {rows.length > 10 && (
          <p className="mt-3 text-[12px] text-ink-3">
            Showing the 10 largest of {formatNumber(rows.length)}. The Identities screen filters on every value.
          </p>
        )}
      </div>
    </Panel>
  );
}

function AccountsPanel({ query }) {
  const data = query.data;
  const rows = data?.breakdown ?? [];
  return (
    <Panel prominence="quiet" className="animate-rise">
      <PanelHeader
        prominence="quiet"
        title="AWS accounts"
        subtitle={data ? `${formatNumber(data.total_accounts)} account${data.total_accounts === 1 ? '' : 's'} with identities` : undefined}
      />
      <div className="mt-3">
        {query.isLoading && !data ? (
          <ChartSkeleton height={220} bars={5} />
        ) : query.isError ? (
          <InlineError error={query.error} onRetry={query.refetch} label="Accounts unavailable" />
        ) : rows.length === 0 ? (
          <EmptyState compact icon={Globe2} title="No accounts yet" description="Accounts appear once discovery records identities in them." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px]">
              <caption className="sr-only">Identities and credentials per AWS account</caption>
              <thead>
                <tr className="border-b border-line text-[11px] font-semibold tracking-[0.07em] text-ink-3 uppercase">
                  <th scope="col" className="py-2 pr-3">Account</th>
                  <th scope="col" className="py-2 pr-3 text-right">Identities</th>
                  <th scope="col" className="py-2 text-right">Credentials</th>
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 10).map((row) => (
                  <tr key={row.account_id} className="border-b border-line/70 last:border-b-0">
                    <td className="py-2.5 pr-3">
                      <Link
                        to={`/identities?account_id=${encodeURIComponent(row.account_id)}`}
                        className="font-mono text-[12.5px] text-brand hover:underline"
                      >
                        {row.account_id}
                      </Link>
                    </td>
                    <td data-numeric="" className="py-2.5 pr-3 text-right font-semibold text-ink">
                      {formatNumber(row.identity_count)}
                    </td>
                    <td data-numeric="" className="py-2.5 text-right text-ink-2">
                      {row.credential_count === null || row.credential_count === undefined ? (
                        <span title={NOT_REPORTED}>-</span>
                      ) : (
                        formatNumber(row.credential_count)
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length > 10 && (
              <p className="mt-3 text-[12px] text-ink-3">Showing 10 of {formatNumber(rows.length)} accounts.</p>
            )}
          </div>
        )}
      </div>
    </Panel>
  );
}

/* ── Credentials ─────────────────────────────────────────────────────────── */

function CredentialsPanel({ query, summary }) {
  const data = query.data;
  const rows = useMemo(
    () =>
      (data?.breakdown ?? [])
        .map((row) => ({ key: row.credential_type, label: credentialTypeLabel(row.credential_type), value: row.count }))
        .filter((row) => row.value > 0),
    [data],
  );
  const hygiene = [
    { label: 'Expiring in 30 days', value: summary?.expiring_credentials_30d },
    { label: 'Unused 90 days', value: summary?.stale_credentials_90d },
    { label: 'Not rotated', value: summary?.unrotated_credentials },
  ];
  return (
    <Panel prominence="quiet" className="animate-rise">
      <PanelHeader prominence="quiet" title="Credentials by type" subtitle="Access keys, secrets, certificates and other credentials the scan found." />
      <div className="mt-3">
        {query.isLoading && !data ? (
          <ChartSkeleton height={200} bars={5} />
        ) : query.isError ? (
          <InlineError error={query.error} onRetry={query.refetch} label="Credentials unavailable" />
        ) : rows.length === 0 ? (
          <ClearState compact title="No credentials recorded" description="The scan has not recorded any credential yet." />
        ) : (
          <BarList items={rows} total={data.total} />
        )}
        <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-line pt-3">
          {hygiene.map((item) => (
            <div key={item.label}>
              <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{item.label}</dt>
              <dd data-numeric="" className="mt-1 font-display text-[18px] leading-none font-bold text-ink" title={item.value == null ? NOT_REPORTED : undefined}>
                {item.value === null || item.value === undefined ? '-' : formatNumber(item.value)}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </Panel>
  );
}

/* ── Exposed credentials ─────────────────────────────────────────────────── */

const TIERS = [
  { key: 'CRITICAL', label: 'Critical', tone: 'critical' },
  { key: 'HIGH', label: 'High', tone: 'high' },
  { key: 'MEDIUM', label: 'Medium', tone: 'medium' },
  { key: 'LOW', label: 'Low', tone: 'low' },
];

function FindingsPanel({ query }) {
  const summary = useMemo(() => summariseFindings(query.data?.findings), [query.data]);
  return (
    <Panel prominence="default" className="animate-rise">
      <PanelHeader
        title="Secrets exposed in code"
        subtitle="Live findings from the secret scanner, excluding those marked safe."
        actions={
          <Button as={Link} to="/exposure" variant="secondary" size="sm" iconRight={ArrowRight}>
            Review
          </Button>
        }
      />
      <div className="mt-3">
        {query.isLoading && !query.data ? (
          <ChartSkeleton height={180} bars={4} />
        ) : query.isError ? (
          <InlineError
            error={{ message: describeScannerError(query.error).message }}
            onRetry={query.refetch}
            label={describeScannerError(query.error).title}
          />
        ) : summary.total === 0 ? (
          <ClearState compact title="No exposed secrets" description="The scanner has no live finding in any repository." />
        ) : (
          <>
            <ProportionBar
              segments={TIERS.map((tier) => ({ key: tier.key, label: tier.label, value: summary.byTier[tier.key], color: TONE_VAR[tier.tone] }))}
              ariaLabel="Findings by risk tier"
            />
            <dl className="mt-4 grid grid-cols-2 gap-3 @min-[26rem]:grid-cols-4">
              {TIERS.map((tier) => (
                <div key={tier.key}>
                  <dt className="flex items-center gap-1.5 text-[11.5px] text-ink-3">
                    <span aria-hidden="true" className="size-2 rounded-full" style={{ background: TONE_VAR[tier.tone] }} />
                    {tier.label}
                  </dt>
                  <dd data-numeric="" className="mt-1 font-display text-[18px] leading-none font-bold text-ink">
                    {formatNumber(summary.byTier[tier.key])}
                  </dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 flex items-center gap-1.5 text-[12px] text-ink-3">
              <GitBranch aria-hidden="true" className="size-3.5" />
              {formatNumber(summary.repositoryCount)} repositories · {formatNumber(summary.byPlatform.github)} on GitHub,{' '}
              {formatNumber(summary.byPlatform.codecommit)} on CodeCommit
            </p>
          </>
        )}
      </div>
    </Panel>
  );
}
