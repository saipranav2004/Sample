import { useEffect, useId, useState } from 'react';
import { Pencil } from 'lucide-react';
import { updateIdentity } from '../../lib/api/endpoints';
import { useMutation } from '../../lib/hooks';
import { Button } from '../../ui/Button';
import { Field, Input } from '../../ui/Field';
import { Modal } from '../../ui/Overlay';
import { useToast } from '../../ui/Toast';

/* The same rules `PATCH /api/v1/inventory/identities/{id}` applies. */
const CLASS_PATTERN = /^[a-z][a-z0-9_-]{0,99}$/;
const MAX = 256;

function validate(name, value) {
  const text = value.trim();
  if (!text) return null;
  if (text.length > MAX) return `Keep it to ${MAX} characters or fewer.`;
  if (name === 'functional_class' && !CLASS_PATTERN.test(text)) {
    return 'Lower-case letters, digits, "-" and "_" only, starting with a letter. For example: service, cicd, data-pipeline.';
  }
  return null;
}

/**
 * Edit the three fields the API lets a person change. Only fields that
 * changed and are non-empty are sent: the API rejects empty values, so a
 * value can be replaced here but not cleared.
 */
export function EditIdentityDialog({ open, identity, onClose, onSaved }) {
  const formId = useId();
  const { notify } = useToast();
  const initial = {
    functional_class: identity.functional_class ?? '',
    owner: identity.ownership?.owner ?? '',
    environment: identity.ownership?.environment ?? '',
  };
  const [values, setValues] = useState(initial);
  const [touched, setTouched] = useState(false);
  const save = useMutation((patch) => updateIdentity(identity.id, patch));

  useEffect(() => {
    if (open) {
      setValues({
        functional_class: identity.functional_class ?? '',
        owner: identity.ownership?.owner ?? '',
        environment: identity.ownership?.environment ?? '',
      });
      setTouched(false);
      save.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, identity.id]);

  const errors = Object.fromEntries(Object.keys(values).map((name) => [name, validate(name, values[name])]));
  const patch = Object.fromEntries(
    Object.entries(values)
      .map(([name, value]) => [name, value.trim()])
      .filter(([name, value]) => value !== '' && value !== (initial[name] ?? '').trim()),
  );
  const cleared = Object.keys(values).filter((name) => values[name].trim() === '' && (initial[name] ?? '').trim() !== '');
  const invalid = Object.values(errors).some(Boolean);
  const nothing = Object.keys(patch).length === 0;

  const submit = async (event) => {
    event.preventDefault();
    setTouched(true);
    if (invalid || nothing || cleared.length > 0) return;
    const result = await save.mutate(patch);
    if (result.ok) {
      notify({ variant: 'success', title: 'Identity updated', description: `Saved ${result.result.updated_fields.map((field) => field.replace('_', ' ')).join(', ')}.` });
      onSaved();
    }
  };

  const field = (name, label, hint, placeholder) => (
    <Field
      label={label}
      htmlFor={`${formId}-${name}`}
      hint={hint}
      error={
        (touched || values[name] !== initial[name]) && errors[name]
          ? errors[name]
          : touched && cleared.includes(name)
            ? 'The API cannot clear a value. Enter a new one, or put the current value back.'
            : null
      }
    >
      <Input
        id={`${formId}-${name}`}
        value={values[name]}
        maxLength={MAX}
        autoComplete="off"
        spellCheck={false}
        placeholder={placeholder}
        invalid={Boolean((touched || values[name] !== initial[name]) && errors[name])}
        onChange={(event) => setValues((current) => ({ ...current, [name]: event.target.value }))}
      />
    </Field>
  );

  return (
    <Modal
      open={open}
      onClose={save.pending ? () => {} : onClose}
      title="Edit ownership"
      description={`Saved to the inventory record for ${identity.name || identity.arn}.`}
      icon={Pencil}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={save.pending}>
            Cancel
          </Button>
          <Button variant="primary" type="submit" form={formId} loading={save.pending} disabled={nothing || invalid}>
            Save changes
          </Button>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="flex flex-col gap-4" noValidate>
        {field('functional_class', 'Functional class', 'What the identity is for, as one lower-case word.', 'service')}
        {field('owner', 'Owner', 'The team or person responsible.', 'platform-team')}
        {field('environment', 'Environment', 'Where it runs.', 'production')}
        {save.error && (
          <p role="alert" className="rounded-[var(--radius-control)] border border-critical/25 bg-critical-soft px-3 py-2 text-[12.5px] text-ink-2">
            <span className="font-medium text-critical">Not saved.</span> {save.error.message}
          </p>
        )}
      </form>
    </Modal>
  );
}
