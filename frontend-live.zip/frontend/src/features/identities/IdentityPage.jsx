import { useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Braces, Clock, Fingerprint, Globe2, ListTree, Pencil, ScrollText } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchIdentity, fetchIdentityAttributes, fetchIdentityTimeline } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative } from '../../lib/format';
import { functionalClassLabel, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { DetailList, DetailRow, Panel, PanelHeader } from '../../ui/Panel';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { EditIdentityDialog } from './EditIdentityDialog';
import { AttributeList, JsonBlock, tagEntries } from './JsonView';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const TABS = [
  { value: 'overview', label: 'Overview', icon: Fingerprint },
  { value: 'attributes', label: 'Attributes', icon: ListTree },
  { value: 'timeline', label: 'Timeline', icon: Clock },
  { value: 'raw', label: 'Raw record', icon: Braces },
];

/**
 * One identity: `GET /api/v1/inventory/identities/{id}`, with its
 * type-specific attributes and timeline from their own endpoints. The tab is
 * in the URL so a link can land on the part that matters.
 */
export default function IdentityPage() {
  const { id } = useParams();
  const validId = UUID.test(id ?? '');
  const [searchParams, setSearchParams] = useSearchParams();
  const { can, lock } = useAccess();
  const [editing, setEditing] = useState(false);

  const detail = useQuery((signal) => fetchIdentity(id, signal), [id], { enabled: validId });
  const requested = searchParams.get('tab') || 'overview';
  const tab = TABS.some((entry) => entry.value === requested) ? requested : 'overview';
  const attributes = useQuery((signal) => fetchIdentityAttributes(id, signal), [id], {
    enabled: validId && tab === 'attributes',
  });
  const timeline = useQuery((signal) => fetchIdentityTimeline(id, signal), [id], {
    enabled: validId && tab === 'timeline',
  });

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/identities" icon={ArrowLeft}>
      Identities
    </Button>
  );

  const identity = detail.data;

  if (!validId || (detail.isError && !identity)) {
    const missing = !validId || detail.error?.status === 404 || detail.error?.status === 400;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Identity" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={Fingerprint}
              title="No identity with that id"
              description="It may have been removed by a later discovery run, or the link is incomplete. Find it again from Identities."
              action={back}
            />
          ) : (
            <ErrorState error={detail.error} onRetry={detail.refetch} />
          )}
        </Panel>
      </div>
    );
  }

  if (!identity) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} />
        <Panel prominence="lead">
          <DetailSkeleton rows={8} />
        </Panel>
        <span role="status" className="sr-only">
          Loading identity
        </span>
      </div>
    );
  }

  const status = statusMeta(identity.status);
  const tags = tagEntries(identity.ownership?.tags);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title={<span className="block min-w-0 truncate font-mono">{identity.name || identity.arn}</span>}
        lede={`${identityTypeLabel(identity.identity_type)} · ${functionalClassLabel(identity.functional_class)} · account ${identity.account_id} · ${regionLabel(identity.region)}`}
        actions={
          <>
            {back}
            <Button
              variant="primary"
              icon={Pencil}
              onClick={() => setEditing(true)}
              locked={lock('identity.edit')}
              disabled={Boolean(identity.deleted_at)}
              title={identity.deleted_at ? 'A deleted identity cannot be edited' : undefined}
            >
              Edit ownership
            </Button>
          </>
        }
        meta={
          <div className="flex flex-wrap items-center gap-2">
            <Tag tone={status.tone} dot>
              {status.label}
            </Tag>
            {identity.network?.is_publicly_accessible === true && (
              <Tag tone="critical" icon={Globe2}>
                Publicly accessible
              </Tag>
            )}
            {identity.deleted_at && <Tag tone="neutral">Deleted {formatRelative(identity.deleted_at)}</Tag>}
            <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
              <CopyableValue value={identity.arn} />
            </span>
          </div>
        }
        tabs={<Tabs size="sm" tabs={TABS} value={tab} onChange={setTab} />}
      />

      {tab === 'overview' && <OverviewTab identity={identity} tags={tags} />}

      {tab === 'attributes' && (
        <Panel className="animate-rise">
          <PanelHeader
            title={`${identityTypeLabel(identity.identity_type)} attributes`}
            subtitle="Fields AWS reports for this kind of resource, as the scanner recorded them."
          />
          <div className="mt-3">
            {attributes.isError ? (
              <ErrorState compact error={attributes.error} onRetry={attributes.refetch} />
            ) : !attributes.data ? (
              <DetailSkeleton rows={6} />
            ) : (
              <AttributeList
                value={attributes.data.type_attributes}
                emptyTitle="No type-specific attributes"
                emptyText="The scanner recorded no extra attributes for this identity."
              />
            )}
          </div>
        </Panel>
      )}

      {tab === 'timeline' && <TimelineTab query={timeline} />}

      {tab === 'raw' && (
        <Panel className="animate-rise">
          <PanelHeader
            title="Raw AWS response"
            subtitle="Exactly what the AWS API returned when the scanner discovered this identity."
          />
          <div className="mt-3">
            {identity.raw_api_response === null || identity.raw_api_response === undefined ? (
              <EmptyState compact icon={ScrollText} title="No raw response stored" description="The scanner did not keep the AWS response for this identity." />
            ) : (
              <JsonBlock value={identity.raw_api_response} copyLabel="Copy JSON" />
            )}
          </div>
        </Panel>
      )}

      <EditIdentityDialog
        open={editing && can('identity.edit')}
        identity={identity}
        onClose={() => setEditing(false)}
        onSaved={() => {
          setEditing(false);
          detail.refetch();
        }}
      />
    </div>
  );
}

function When({ value, fallback = '-' }) {
  if (!value) return <span className="text-ink-3">{fallback}</span>;
  return (
    <span title={formatDateTime(value)}>
      {formatDateTime(value)} <span className="text-ink-3">· {formatRelative(value)}</span>
    </span>
  );
}

function Missing({ children = 'Not recorded' }) {
  return <span className="text-ink-3">{children}</span>;
}

function OverviewTab({ identity, tags }) {
  const network = identity.network ?? {};
  const ownership = identity.ownership ?? {};
  const lineage = identity.lineage ?? {};
  const discovery = identity.discovery ?? {};
  const groups = Array.isArray(network.security_group_ids) ? network.security_group_ids : [];

  return (
    <div className="grid gap-4 @min-[60rem]:grid-cols-2">
      <Panel className="animate-rise">
        <PanelHeader title="Identity" />
        <DetailList className="mt-2">
          <DetailRow label="Name">{identity.name || <Missing />}</DetailRow>
          <DetailRow label="Type">{identityTypeLabel(identity.identity_type)}</DetailRow>
          <DetailRow label="Functional class">{functionalClassLabel(identity.functional_class)}</DetailRow>
          <DetailRow label="Status">{statusMeta(identity.status).label}</DetailRow>
          <DetailRow label="AWS account" mono>
            {identity.account_id}
          </DetailRow>
          <DetailRow label="Region" mono>
            {regionLabel(identity.region)}
          </DetailRow>
          <DetailRow label="ID" mono>
            <CopyableValue value={identity.id} />
          </DetailRow>
        </DetailList>
      </Panel>

      <Panel className="animate-rise">
        <PanelHeader title="Ownership" subtitle="Who is responsible for this identity, and where it runs." />
        <DetailList className="mt-2">
          <DetailRow label="Owner">{ownership.owner || <Missing>No owner tag</Missing>}</DetailRow>
          <DetailRow label="Environment">{ownership.environment || <Missing>No environment tag</Missing>}</DetailRow>
          <DetailRow label="Tags">
            {tags.length === 0 ? (
              <Missing>No tags</Missing>
            ) : (
              <span className="flex flex-wrap gap-1.5">
                {tags.map(([key, value]) => (
                  <span key={key} className="inline-flex max-w-full items-center rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px]">
                    <span className="text-ink-3">{key}</span>
                    {value !== '' && value !== null && (
                      <span className="truncate text-ink">={typeof value === 'object' ? JSON.stringify(value) : String(value)}</span>
                    )}
                  </span>
                ))}
              </span>
            )}
          </DetailRow>
        </DetailList>
      </Panel>

      <Panel className="animate-rise">
        <PanelHeader title="Activity" />
        <DetailList className="mt-2">
          <DetailRow label="Created in AWS">
            <When value={identity.created_at_aws} fallback="Not reported by AWS" />
          </DetailRow>
          <DetailRow label="First discovered">
            <When value={identity.first_seen_at} />
          </DetailRow>
          <DetailRow label="Last active">
            <When value={identity.last_activity_at} fallback="AWS records no activity for this identity" />
          </DetailRow>
          <DetailRow label="Last confirmed">
            <When value={identity.last_seen_at} />
          </DetailRow>
          {identity.deleted_at && (
            <DetailRow label="Deleted">
              <When value={identity.deleted_at} />
            </DetailRow>
          )}
        </DetailList>
      </Panel>

      <Panel className="animate-rise">
        <PanelHeader title="Network" />
        <DetailList className="mt-2">
          <DetailRow label="Publicly accessible">
            {network.is_publicly_accessible === true ? (
              <Tag tone="critical" size="sm" icon={Globe2}>
                Yes
              </Tag>
            ) : network.is_publicly_accessible === false ? (
              'No'
            ) : (
              <Missing>Not determined</Missing>
            )}
          </DetailRow>
          <DetailRow label="VPC" mono>
            {network.vpc_id || <Missing>None</Missing>}
          </DetailRow>
          <DetailRow label="Subnet" mono>
            {network.subnet_id || <Missing>None</Missing>}
          </DetailRow>
          <DetailRow label="Security groups" mono>
            {groups.length === 0 ? <Missing>None</Missing> : groups.map(String).join(', ')}
          </DetailRow>
        </DetailList>
      </Panel>

      <Panel className="animate-rise">
        <PanelHeader title="Lineage" subtitle="What this identity belongs to, and who created it." />
        <DetailList className="mt-2">
          <DetailRow label="Parent" mono>
            {lineage.parent_arn ? <CopyableValue value={lineage.parent_arn} /> : <Missing>None</Missing>}
          </DetailRow>
          <DetailRow label="Created by" mono>
            {lineage.cloudtrail_creator_arn ? <CopyableValue value={lineage.cloudtrail_creator_arn} /> : <Missing>Not found in CloudTrail</Missing>}
          </DetailRow>
        </DetailList>
      </Panel>

      <Panel className="animate-rise">
        <PanelHeader title="Discovery" />
        <DetailList className="mt-2">
          <DetailRow label="Source">{tokenLabel(discovery.discovery_source)}</DetailRow>
          <DetailRow label="Scan" mono>
            {discovery.scan_id || <Missing />}
          </DetailRow>
        </DetailList>
      </Panel>
    </div>
  );
}

const EVENT_LABELS = {
  first_discovered: { label: 'First discovered', hint: 'The scanner saw this identity for the first time.' },
  last_activity: { label: 'Last active', hint: 'The most recent use AWS has recorded.' },
  last_confirmed: { label: 'Last confirmed', hint: 'The latest scan that still found it.' },
};

function TimelineTab({ query }) {
  if (query.isError) {
    return (
      <Panel>
        <ErrorState error={query.error} onRetry={query.refetch} />
      </Panel>
    );
  }
  if (!query.data) {
    return (
      <Panel>
        <ListSkeleton rows={3} />
      </Panel>
    );
  }
  const data = query.data;
  const events = [...(data.events ?? [])].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
  return (
    <Panel className="animate-rise">
      <PanelHeader title="Timeline" />
      <dl className="mt-3 grid grid-cols-2 gap-3 border-b border-line pb-4">
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Known for</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {formatNumber(data.age_days)} <span className="text-[12px] font-medium text-ink-3">days</span>
          </dd>
        </div>
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Since last activity</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {data.days_since_last_activity === null || data.days_since_last_activity === undefined ? (
              <span className="text-[13px] font-medium text-ink-3">Not tracked</span>
            ) : (
              <>
                {formatNumber(data.days_since_last_activity)} <span className="text-[12px] font-medium text-ink-3">days</span>
              </>
            )}
          </dd>
        </div>
      </dl>
      <ol className="mt-4 flex flex-col gap-4 border-l border-line pl-5">
        {events.map((event) => {
          const meta = EVENT_LABELS[event.event] ?? { label: tokenLabel(event.event), hint: '' };
          return (
            <li key={`${event.event}-${event.timestamp}`} className="relative">
              <span aria-hidden="true" className="absolute top-1.5 -left-[25px] size-2.5 rounded-full border-2 border-surface bg-brand" />
              <p className="text-[13px] font-medium text-ink">{meta.label}</p>
              <p className="text-[12px] text-ink-3">
                <time dateTime={event.timestamp}>{formatDateTime(event.timestamp)}</time> · {formatRelative(event.timestamp)}
              </p>
              {meta.hint && <p className="mt-0.5 text-[12px] text-ink-3">{meta.hint}</p>}
            </li>
          );
        })}
      </ol>
    </Panel>
  );
}
