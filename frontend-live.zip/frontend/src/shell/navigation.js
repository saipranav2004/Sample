import { FileWarning, Fingerprint, Gauge, Moon, ShieldOff } from 'lucide-react';

/**
 * Information architecture. Every item is a screen backed by the NHI API:
 * the v1 dashboard, the v1 identity inventory, and credential exposure.
 */
export const NAV_GROUPS = [
  {
    key: 'overview',
    label: 'Overview',
    items: [{ to: '/overview', label: 'Dashboard', icon: Gauge, end: true }],
  },
  {
    key: 'inventory',
    label: 'Inventory',
    items: [
      { to: '/identities', label: 'Identities', icon: Fingerprint, end: true },
      { to: '/dormant', label: 'Dormant identities', icon: Moon },
    ],
  },
  {
    key: 'exposure',
    label: 'Credential exposure',
    items: [
      { to: '/exposure', label: 'Exposed credentials', icon: FileWarning, end: true },
      { to: '/exposure/dismissed', label: 'Marked safe', icon: ShieldOff },
    ],
  },
];

/** The navigation a role can use: items it lacks the permission for, and groups left empty, removed. */
export function navGroupsFor(can) {
  return NAV_GROUPS.map((group) => ({
    ...group,
    items: group.items.filter((item) => !item.permission || can(item.permission)),
  })).filter((group) => group.items.length > 0);
}

export const ALL_NAV_ITEMS = NAV_GROUPS.flatMap((group) =>
  group.items.map((item) => ({ ...item, group: group.label })),
);

/** Breadcrumb trail per route, kept as data so labels match the navigation. */
export const BREADCRUMBS = {
  '/overview': ['Overview', 'Dashboard'],
  '/identities': ['Inventory', 'Identities'],
  '/dormant': ['Inventory', 'Dormant identities'],
  '/exposure': ['Credential exposure', 'Exposed credentials'],
  '/exposure/dismissed': ['Credential exposure', 'Marked safe'],
};

/** Breadcrumbs for routes with a parameter, matched by prefix. */
export const BREADCRUMB_PREFIXES = [{ prefix: '/identities/', trail: ['Inventory', 'Identities', 'Identity'] }];
