// package newapi

// import (
// 	"context"
// 	"errors"
// 	"fmt"
// 	"log"
// 	"math"
// 	"sync"
// 	"time"

// 	"nhi-backend-api/internal/database"
// 	modelnewapi "nhi-backend-api/internal/models/new_api"
// 	reponewapi "nhi-backend-api/internal/repository/new_api"
// )

// // ErrScanNotFound — the requested scan_id is not a COMPLETED scan (HTTP 404).
// var ErrScanNotFound = errors.New("scan not found or not completed")

// // OverviewParams are the optional query-string overrides. Anything left empty
// // falls back to the user's saved settings (Endpoint 1A), then to
// // "latest completed scan / all accounts / all regions".
// type OverviewParams struct {
// 	ScanID   string
// 	Accounts []string
// 	Regions  []string
// }

// type DashboardOverviewService struct {
// 	dbm      *database.Manager
// 	repo     *reponewapi.DashboardOverviewRepository
// 	scans    *reponewapi.ScanRepository
// 	settings *SettingsService
// }

// func NewDashboardOverviewService(
// 	dbm *database.Manager,
// 	repo *reponewapi.DashboardOverviewRepository,
// 	scans *reponewapi.ScanRepository,
// 	settings *SettingsService,
// ) *DashboardOverviewService {
// 	return &DashboardOverviewService{dbm: dbm, repo: repo, scans: scans, settings: settings}
// }

// // Get implements Endpoint 3 — all KPIs + all charts in one response.
// func (s *DashboardOverviewService) Get(ctx context.Context, id Identity, p OverviewParams) (*modelnewapi.DashboardOverviewResponse, error) {
// 	tenantDB, err := s.dbm.Tenant(id.DBName)
// 	if err != nil {
// 		return nil, fmt.Errorf("resolve tenant database: %w", err)
// 	}

// 	accounts, err := cleanSelection("accounts", p.Accounts, awsAccountIDRe)
// 	if err != nil {
// 		return nil, err
// 	}
// 	regions, err := cleanSelection("regions", p.Regions, awsRegionRe)
// 	if err != nil {
// 		return nil, err
// 	}

// 	// ── 1. Resolve scope: query params > saved settings > latest scan ─────
// 	scanID := p.ScanID
// 	if scanID == "" || len(accounts) == 0 || len(regions) == 0 {
// 		st, serr := s.settings.Get(ctx, id)
// 		if serr != nil {
// 			// Settings are a convenience; don't take the dashboard down with them.
// 			log.Printf("dashboard overview: settings fallback user=%s: %v", id.UserID, serr)
// 		} else {
// 			if len(accounts) == 0 {
// 				accounts = st.Settings.Accounts.Selected
// 			}
// 			if len(regions) == 0 {
// 				regions = st.Settings.Regions.Selected
// 			}
// 			if scanID == "" && st.Settings.Scan.EffectiveScanID != nil {
// 				scanID = *st.Settings.Scan.EffectiveScanID
// 			}
// 		}
// 	}

// 	var scan *reponewapi.ScanInfo
// 	if scanID != "" {
// 		if scan, err = s.scans.GetCompletedScan(ctx, tenantDB, scanID); err != nil {
// 			return nil, err
// 		}
// 		if scan == nil {
// 			return nil, ErrScanNotFound
// 		}
// 	} else {
// 		if scan, err = s.scans.GetLatestCompletedScan(ctx, tenantDB); err != nil {
// 			return nil, err
// 		}
// 		if scan != nil {
// 			scanID = scan.ScanID
// 		}
// 	}
// 	// No completed scan at all → scanID == "" matches no rows → zeros / empty lists.

// 	f := reponewapi.OverviewFilter{ScanID: scanID, Accounts: accounts, Regions: regions}

// 	// ── 2. Run every query in parallel (pool is goroutine-safe) ───────────
// 	var (
// 		idK                        reponewapi.IdentityKPIs
// 		crK                        reponewapi.CredentialKPIs
// 		granted, used              int64
// 		byType, byClass, byAccount []reponewapi.LabelCount
// 		byRegion, byEnv, byStatus  []reponewapi.LabelCount
// 		credTypes, owners          []reponewapi.LabelCount
// 		idGrowth, crGrowth         []reponewapi.DatePoint
// 		expiring                   []reponewapi.ExpiringRow
// 		history                    []reponewapi.ScanHistoryRow
// 	)

// 	ctx, cancel := context.WithCancel(ctx)
// 	defer cancel()

// 	err = runAll(cancel,
// 		func() (e error) { idK, e = s.repo.IdentityKPIs(ctx, tenantDB, f); return },
// 		func() (e error) { crK, e = s.repo.CredentialKPIs(ctx, tenantDB, f); return },
// 		func() (e error) { granted, used, e = s.repo.PermissionCounts(ctx, tenantDB, f); return },
// 		func() (e error) { byType, e = s.repo.IdentitiesByType(ctx, tenantDB, f); return },
// 		func() (e error) { byClass, e = s.repo.IdentitiesByFunctionalClass(ctx, tenantDB, f); return },
// 		func() (e error) { byAccount, e = s.repo.IdentitiesByAccount(ctx, tenantDB, f); return },
// 		func() (e error) { byRegion, e = s.repo.IdentitiesByRegion(ctx, tenantDB, f); return },
// 		func() (e error) { byEnv, e = s.repo.IdentitiesByEnvironment(ctx, tenantDB, f); return },
// 		func() (e error) { byStatus, e = s.repo.IdentitiesByStatus(ctx, tenantDB, f); return },
// 		func() (e error) { credTypes, e = s.repo.CredentialTypes(ctx, tenantDB, f); return },
// 		func() (e error) { owners, e = s.repo.TopOwners(ctx, tenantDB, f); return },
// 		func() (e error) { idGrowth, e = s.repo.Growth(ctx, tenantDB, "identities", "i", f); return },
// 		func() (e error) { crGrowth, e = s.repo.Growth(ctx, tenantDB, "credentials", "c", f); return },
// 		func() (e error) { expiring, e = s.repo.ExpiringSoon(ctx, tenantDB, f); return },
// 		func() (e error) { history, e = s.repo.ScanHistory(ctx, tenantDB); return },
// 	)
// 	if err != nil {
// 		return nil, err
// 	}

// 	// ── 3. Shape the response ─────────────────────────────────────────────
// 	resp := &modelnewapi.DashboardOverviewResponse{}

// 	resp.KPIs = modelnewapi.OverviewKPIs{
// 		TotalIdentities:       idK.Total,
// 		TotalCredentials:      crK.Total,
// 		OrphanedCredentials:   crK.Orphaned,
// 		StaleIdentities:       idK.Stale,
// 		StaleCredentials:      crK.Stale,
// 		PubliclyAccessible:    idK.PubliclyAccessible,
// 		ShadowIdentities:      idK.Shadow,
// 		AccountsScanned:       idK.Accounts,
// 		PermissionUtilization: utilizationPct(used, granted),
// 	}
// 	if scan != nil && scan.ScanEnd != nil {
// 		ts := scan.ScanEnd.UTC().Format(time.RFC3339)
// 		resp.KPIs.LastScanTime = &ts
// 	}

// 	c := &resp.Charts
// 	c.IdentitiesByType = make([]modelnewapi.TypeCount, 0, len(byType))
// 	for _, r := range byType {
// 		c.IdentitiesByType = append(c.IdentitiesByType, modelnewapi.TypeCount{Type: r.Label, Count: r.Count})
// 	}
// 	c.IdentitiesByFunctionalClass = make([]modelnewapi.ClassCount, 0, len(byClass))
// 	for _, r := range byClass {
// 		c.IdentitiesByFunctionalClass = append(c.IdentitiesByFunctionalClass, modelnewapi.ClassCount{Class: r.Label, Count: r.Count})
// 	}
// 	c.IdentitiesByAccount = make([]modelnewapi.AccountCount, 0, len(byAccount))
// 	for _, r := range byAccount {
// 		c.IdentitiesByAccount = append(c.IdentitiesByAccount, modelnewapi.AccountCount{AccountID: r.Label, Count: r.Count})
// 	}
// 	c.IdentitiesByRegion = make([]modelnewapi.RegionCount, 0, len(byRegion))
// 	for _, r := range byRegion {
// 		c.IdentitiesByRegion = append(c.IdentitiesByRegion, modelnewapi.RegionCount{Region: r.Label, Count: r.Count})
// 	}
// 	c.IdentitiesByEnvironment = make([]modelnewapi.EnvironmentCount, 0, len(byEnv))
// 	for _, r := range byEnv {
// 		c.IdentitiesByEnvironment = append(c.IdentitiesByEnvironment, modelnewapi.EnvironmentCount{Environment: r.Label, Count: r.Count})
// 	}
// 	c.IdentitiesByStatus = make([]modelnewapi.StatusCount, 0, len(byStatus))
// 	for _, r := range byStatus {
// 		c.IdentitiesByStatus = append(c.IdentitiesByStatus, modelnewapi.StatusCount{Status: r.Label, Count: r.Count})
// 	}
// 	c.CredentialTypes = make([]modelnewapi.TypeCount, 0, len(credTypes))
// 	for _, r := range credTypes {
// 		c.CredentialTypes = append(c.CredentialTypes, modelnewapi.TypeCount{Type: r.Label, Count: r.Count})
// 	}
// 	c.TopOwners = make([]modelnewapi.OwnerCount, 0, len(owners))
// 	for _, r := range owners {
// 		c.TopOwners = append(c.TopOwners, modelnewapi.OwnerCount{Owner: r.Label, Count: r.Count})
// 	}

// 	c.IdentityGrowth = toDateCounts(idGrowth)
// 	c.CredentialGrowth = toDateCounts(crGrowth)

// 	// active + stale == total identities (e.g. 395 + 34 = 429)
// 	c.StaleVsActive = modelnewapi.StaleVsActive{Active: idK.Total - idK.Stale, Stale: idK.Stale}

// 	c.CredentialsExpiringSoon = make([]modelnewapi.ExpiringCredential, 0, len(expiring))
// 	for _, e := range expiring {
// 		c.CredentialsExpiringSoon = append(c.CredentialsExpiringSoon, modelnewapi.ExpiringCredential{
// 			CredentialName: e.Name,
// 			ExpiresAt:      e.ExpiresAt.UTC().Format(time.RFC3339),
// 			DaysRemaining:  e.DaysRemaining,
// 		})
// 	}

// 	c.ScanHistory = make([]modelnewapi.ScanHistoryItem, 0, len(history))
// 	for _, h := range history {
// 		item := modelnewapi.ScanHistoryItem{
// 			ScanID:           h.ScanID,
// 			Status:           h.Status,
// 			TotalIdentities:  h.TotalIdentities,
// 			TotalCredentials: h.TotalCredentials,
// 		}
// 		if h.ScanEnd != nil {
// 			ts := h.ScanEnd.UTC().Format(time.RFC3339)
// 			item.ScanEnd = &ts
// 		}
// 		c.ScanHistory = append(c.ScanHistory, item)
// 	}

// 	return resp, nil
// }

// func toDateCounts(pts []reponewapi.DatePoint) []modelnewapi.DateCount {
// 	out := make([]modelnewapi.DateCount, 0, len(pts))
// 	for _, p := range pts {
// 		out = append(out, modelnewapi.DateCount{Date: p.Date.Format("2006-01-02"), Count: p.Count})
// 	}
// 	return out
// }

// // utilizationPct = used / granted * 100, one decimal, clamped to 0..100.
// func utilizationPct(used, granted int64) float64 {
// 	if granted <= 0 || used <= 0 {
// 		return 0
// 	}
// 	pct := math.Round(float64(used)*1000/float64(granted)) / 10
// 	if pct > 100 {
// 		return 100
// 	}
// 	return pct
// }

// // runAll runs fns concurrently and returns the first error (cancelling the rest).
// func runAll(cancel context.CancelFunc, fns ...func() error) error {
// 	var (
// 		wg       sync.WaitGroup
// 		once     sync.Once
// 		firstErr error
// 	)
// 	for _, fn := range fns {
// 		wg.Add(1)
// 		go func(fn func() error) {
// 			defer wg.Done()
// 			if err := fn(); err != nil {
// 				once.Do(func() { firstErr = err; cancel() })
// 			}
// 		}(fn)
// 	}
// 	wg.Wait()
// 	return firstErr
// }






















package newapi

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"sync"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

// ErrScanNotFound — the requested scan_id is not a COMPLETED scan (HTTP 404).
var ErrScanNotFound = errors.New("scan not found or not completed")

// OverviewParams are the optional query-string overrides.
// scan_id empty → latest COMPLETED scan.
// accounts / regions empty → user's saved settings → no filter.
type OverviewParams struct {
	ScanID   string
	Accounts []string
	Regions  []string
}

type DashboardOverviewService struct {
	dbm      *database.Manager
	repo     *reponewapi.DashboardOverviewRepository
	scans    *reponewapi.ScanRepository
	settings *SettingsService
}

func NewDashboardOverviewService(
	dbm *database.Manager,
	repo *reponewapi.DashboardOverviewRepository,
	scans *reponewapi.ScanRepository,
	settings *SettingsService,
) *DashboardOverviewService {
	return &DashboardOverviewService{dbm: dbm, repo: repo, scans: scans, settings: settings}
}

// Get implements Endpoint 3 — all KPIs + all charts in one response.
func (s *DashboardOverviewService) Get(ctx context.Context, id Identity, p OverviewParams) (*modelnewapi.DashboardOverviewResponse, error) {
	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	accounts, err := cleanSelection("accounts", p.Accounts, awsAccountIDRe)
	if err != nil {
		return nil, err
	}
	regions, err := cleanSelection("regions", p.Regions, awsRegionRe)
	if err != nil {
		return nil, err
	}

	// ── 1. Resolve scope ──────────────────────────────────────────────────
	// Scan: ?scan_id=... (explicit) > LATEST COMPLETED scan.
	// The saved user_settings scan is deliberately NOT used here — a stale
	// saved scan_id was pinning the dashboard to an old scan.
	// Accounts / regions: query params > saved settings > no filter.
	if len(accounts) == 0 || len(regions) == 0 {
		st, serr := s.settings.Get(ctx, id)
		if serr != nil {
			// Settings are a convenience; don't take the dashboard down with them.
			log.Printf("dashboard overview: settings fallback user=%s: %v", id.UserID, serr)
		} else {
			if len(accounts) == 0 {
				accounts = st.Settings.Accounts.Selected
			}
			if len(regions) == 0 {
				regions = st.Settings.Regions.Selected
			}
		}
	}

	scanID := p.ScanID
	var scan *reponewapi.ScanInfo
	if scanID != "" {
		if scan, err = s.scans.GetCompletedScan(ctx, tenantDB, scanID); err != nil {
			return nil, err
		}
		if scan == nil {
			return nil, ErrScanNotFound
		}
	} else {
		if scan, err = s.scans.GetLatestCompletedScan(ctx, tenantDB); err != nil {
			return nil, err
		}
		if scan != nil {
			scanID = scan.ScanID
		}
	}
	log.Printf("dashboard overview: user=%s using scan_id=%q accounts=%v regions=%v", id.UserID, scanID, accounts, regions)
	// No completed scan at all → scanID == "" matches no rows → zeros / empty lists.

	f := reponewapi.OverviewFilter{ScanID: scanID, Accounts: accounts, Regions: regions}

	// ── 2. Run every query in parallel (pool is goroutine-safe) ───────────
	var (
		idK                        reponewapi.IdentityKPIs
		crK                        reponewapi.CredentialKPIs
		granted, used              int64
		byType, byClass, byAccount []reponewapi.LabelCount
		byRegion, byEnv, byStatus  []reponewapi.LabelCount
		credTypes, owners          []reponewapi.LabelCount
		idGrowth, crGrowth         []reponewapi.DatePoint
		expiring                   []reponewapi.ExpiringRow
		history                    []reponewapi.ScanHistoryRow
	)

	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	err = runAll(cancel,
		func() (e error) { idK, e = s.repo.IdentityKPIs(ctx, tenantDB, f); return },
		func() (e error) { crK, e = s.repo.CredentialKPIs(ctx, tenantDB, f); return },
		func() (e error) { granted, used, e = s.repo.PermissionCounts(ctx, tenantDB, f); return },
		func() (e error) { byType, e = s.repo.IdentitiesByType(ctx, tenantDB, f); return },
		func() (e error) { byClass, e = s.repo.IdentitiesByFunctionalClass(ctx, tenantDB, f); return },
		func() (e error) { byAccount, e = s.repo.IdentitiesByAccount(ctx, tenantDB, f); return },
		func() (e error) { byRegion, e = s.repo.IdentitiesByRegion(ctx, tenantDB, f); return },
		func() (e error) { byEnv, e = s.repo.IdentitiesByEnvironment(ctx, tenantDB, f); return },
		func() (e error) { byStatus, e = s.repo.IdentitiesByStatus(ctx, tenantDB, f); return },
		func() (e error) { credTypes, e = s.repo.CredentialTypes(ctx, tenantDB, f); return },
		func() (e error) { owners, e = s.repo.TopOwners(ctx, tenantDB, f); return },
		func() (e error) { idGrowth, e = s.repo.Growth(ctx, tenantDB, "identities", "i", f); return },
		func() (e error) { crGrowth, e = s.repo.Growth(ctx, tenantDB, "credentials", "c", f); return },
		func() (e error) { expiring, e = s.repo.ExpiringSoon(ctx, tenantDB, f); return },
		func() (e error) { history, e = s.repo.ScanHistory(ctx, tenantDB); return },
	)
	if err != nil {
		return nil, err
	}

	// ── 3. Shape the response ─────────────────────────────────────────────
	resp := &modelnewapi.DashboardOverviewResponse{}

	resp.KPIs = modelnewapi.OverviewKPIs{
		TotalIdentities:       idK.Total,
		TotalCredentials:      crK.Total,
		OrphanedCredentials:   crK.Orphaned,
		StaleIdentities:       idK.Stale,
		StaleCredentials:      crK.Stale,
		PubliclyAccessible:    idK.PubliclyAccessible,
		ShadowIdentities:      idK.Shadow,
		AccountsScanned:       idK.Accounts,
		PermissionUtilization: utilizationPct(used, granted),
	}
	if scan != nil && scan.ScanEnd != nil {
		ts := scan.ScanEnd.UTC().Format(time.RFC3339)
		resp.KPIs.LastScanTime = &ts
	}

	c := &resp.Charts
	c.IdentitiesByType = make([]modelnewapi.TypeCount, 0, len(byType))
	for _, r := range byType {
		c.IdentitiesByType = append(c.IdentitiesByType, modelnewapi.TypeCount{Type: r.Label, Count: r.Count})
	}
	c.IdentitiesByFunctionalClass = make([]modelnewapi.ClassCount, 0, len(byClass))
	for _, r := range byClass {
		c.IdentitiesByFunctionalClass = append(c.IdentitiesByFunctionalClass, modelnewapi.ClassCount{Class: r.Label, Count: r.Count})
	}
	c.IdentitiesByAccount = make([]modelnewapi.AccountCount, 0, len(byAccount))
	for _, r := range byAccount {
		c.IdentitiesByAccount = append(c.IdentitiesByAccount, modelnewapi.AccountCount{AccountID: r.Label, Count: r.Count})
	}
	c.IdentitiesByRegion = make([]modelnewapi.RegionCount, 0, len(byRegion))
	for _, r := range byRegion {
		c.IdentitiesByRegion = append(c.IdentitiesByRegion, modelnewapi.RegionCount{Region: r.Label, Count: r.Count})
	}
	c.IdentitiesByEnvironment = make([]modelnewapi.EnvironmentCount, 0, len(byEnv))
	for _, r := range byEnv {
		c.IdentitiesByEnvironment = append(c.IdentitiesByEnvironment, modelnewapi.EnvironmentCount{Environment: r.Label, Count: r.Count})
	}
	c.IdentitiesByStatus = make([]modelnewapi.StatusCount, 0, len(byStatus))
	for _, r := range byStatus {
		c.IdentitiesByStatus = append(c.IdentitiesByStatus, modelnewapi.StatusCount{Status: r.Label, Count: r.Count})
	}
	c.CredentialTypes = make([]modelnewapi.TypeCount, 0, len(credTypes))
	for _, r := range credTypes {
		c.CredentialTypes = append(c.CredentialTypes, modelnewapi.TypeCount{Type: r.Label, Count: r.Count})
	}
	c.TopOwners = make([]modelnewapi.OwnerCount, 0, len(owners))
	for _, r := range owners {
		c.TopOwners = append(c.TopOwners, modelnewapi.OwnerCount{Owner: r.Label, Count: r.Count})
	}

	c.IdentityGrowth = toDateCounts(idGrowth)
	c.CredentialGrowth = toDateCounts(crGrowth)

	// active + stale == total identities (e.g. 395 + 34 = 429)
	c.StaleVsActive = modelnewapi.StaleVsActive{Active: idK.Total - idK.Stale, Stale: idK.Stale}

	c.CredentialsExpiringSoon = make([]modelnewapi.ExpiringCredential, 0, len(expiring))
	for _, e := range expiring {
		c.CredentialsExpiringSoon = append(c.CredentialsExpiringSoon, modelnewapi.ExpiringCredential{
			CredentialName: e.Name,
			ExpiresAt:      e.ExpiresAt.UTC().Format(time.RFC3339),
			DaysRemaining:  e.DaysRemaining,
		})
	}

	c.ScanHistory = make([]modelnewapi.ScanHistoryItem, 0, len(history))
	for _, h := range history {
		item := modelnewapi.ScanHistoryItem{
			ScanID:           h.ScanID,
			Status:           h.Status,
			TotalIdentities:  h.TotalIdentities,
			TotalCredentials: h.TotalCredentials,
		}
		if h.ScanEnd != nil {
			ts := h.ScanEnd.UTC().Format(time.RFC3339)
			item.ScanEnd = &ts
		}
		c.ScanHistory = append(c.ScanHistory, item)
	}

	return resp, nil
}

func toDateCounts(pts []reponewapi.DatePoint) []modelnewapi.DateCount {
	out := make([]modelnewapi.DateCount, 0, len(pts))
	for _, p := range pts {
		out = append(out, modelnewapi.DateCount{Date: p.Date.Format("2006-01-02"), Count: p.Count})
	}
	return out
}

// utilizationPct = used / granted * 100, one decimal, clamped to 0..100.
func utilizationPct(used, granted int64) float64 {
	if granted <= 0 || used <= 0 {
		return 0
	}
	pct := math.Round(float64(used)*1000/float64(granted)) / 10
	if pct > 100 {
		return 100
	}
	return pct
}

// runAll runs fns concurrently and returns the first error (cancelling the rest).
func runAll(cancel context.CancelFunc, fns ...func() error) error {
	var (
		wg       sync.WaitGroup
		once     sync.Once
		firstErr error
	)
	for _, fn := range fns {
		wg.Add(1)
		go func(fn func() error) {
			defer wg.Done()
			if err := fn(); err != nil {
				once.Do(func() { firstErr = err; cancel() })
			}
		}(fn)
	}
	wg.Wait()
	return firstErr
}