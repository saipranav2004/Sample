// package routes

// import (
// 	"encoding/json"
// 	"net/http"

// 	"github.com/gorilla/mux"

// 	"nhi-backend-api/internal/handlers"
// 	handlercredentialexposure "nhi-backend-api/internal/handlers/Credential_Exposure"
// 	handlerdashboard "nhi-backend-api/internal/handlers/dashboard"
// 	handlerinventory "nhi-backend-api/internal/handlers/inventory"
// 	"nhi-backend-api/internal/middleware"
// )

// type HandlerContainer struct {
// 	// Auth
// 	AuthHandler    *handlers.AuthHandler
// 	AuthMiddleware *middleware.AuthMiddleware

// 	// Dashboard
// 	DashboardHandler                *handlers.DashboardHandler
// 	DiscoveryHandler                *handlerdashboard.DiscoveryHandler
// 	PrivilegeDistributionHandler    *handlerdashboard.PrivilegeDistributionHandler
// 	OwnershipCoverageHandler        *handlerdashboard.OwnershipCoverageHandler
// 	FiltersHandler                  *handlerdashboard.FiltersHandler
// 	DashboardSummaryHandler         *handlerdashboard.SummaryHandler
// 	IdentitiesByTypeHandler         *handlerdashboard.IdentitiesByTypeHandler
// 	IdentitiesByClassHandler        *handlerdashboard.IdentitiesByClassHandler
// 	IdentitiesByAccountHandler      *handlerdashboard.IdentitiesByAccountHandler
// 	IdentitiesByRegionHandler       *handlerdashboard.IdentitiesByRegionHandler
// 	CredentialsByTypeHandler        *handlerdashboard.CredentialsByTypeHandler
// 	BlastRadiusHandler              *handlerdashboard.BlastRadiusHandler
// 	OverprivilegeHandler            *handlerdashboard.OverprivilegeHandler
// 	TrustRisksHandler               *handlerdashboard.TrustRisksHandler
// 	PermissionDistributionHandler   *handlerdashboard.PermissionDistributionHandler
// 	ActivityHeatmapHandler          *handlerdashboard.ActivityHeatmapHandler
// 	SharedCredentialsHandler        *handlerdashboard.SharedCredentialsHandler
// 	AttackPathsHandler              *handlers.AttackPathsHandler
// 	UnusedPermissionsHandler        *handlers.UnusedPermissionsHandler
// 	CredentialHygieneSummaryHandler *handlerdashboard.CredentialHygieneSummaryHandler
// 	IdentitiesExposureHandler       *handlerdashboard.IdentitiesExposureHandler

// 	// Identities
// 	LineageHandler *handlers.LineageHandler

// 	// Legacy
// 	ScanHandler       *handlers.ScanHandler
// 	EventHandler      *handlers.EventHandler
// 	CredentialHandler *handlers.CredentialHandler

// 	// Inventory — Credentials
// 	InventoryCredentialHandler         *handlerinventory.CredentialHandler
// 	InventoryCredentialDetailsHandler  *handlerinventory.CredentialDetailsHandler
// 	InventoryCredentialCountHandler    *handlerinventory.CredentialCountHandler
// 	InventoryCredentialHygieneHandler  *handlerinventory.CredentialHygieneHandler
// 	InventoryTrustPolicyHandler        *handlerinventory.TrustPolicyHandler
// 	InventoryAttachedPoliciesHandler   *handlerinventory.AttachedPoliciesHandler
// 	InventoryCredentialExpiringHandler *handlerinventory.CredentialExpiringHandler
// 	InventoryCredentialStaleHandler    *handlerinventory.CredentialStaleHandler
// 	InventoryCredentialExportHandler   *handlerinventory.CredentialExportHandler
// 	InventoryCredentialUpdateHandler   *handlerinventory.UpdateCredentialHandler

// 	// Inventory — Identities
// 	IdentityListHandler           *handlerinventory.IdentityListHandler
// 	IdentityDetailHandler         *handlerinventory.IdentityDetailHandler
// 	IdentityAttributesHandler     *handlerinventory.IdentityAttributesHandler
// 	IdentityTimelineHandler       *handlerinventory.IdentityTimelineHandler
// 	IdentityGroupedByClassHandler *handlerinventory.IdentityGroupedByClassHandler
// 	IdentityDormantHandler        *handlerinventory.IdentityDormantHandler
// 	ExportIdentitiesHandler       *handlerinventory.ExportIdentitiesHandler
// 	UpdateIdentityHandler         *handlerinventory.UpdateIdentityHandler
// 	IdentityCountsHandler         *handlerinventory.IdentityCountsHandler
// 	IdentitySearchHandler         *handlerinventory.SearchHandler
// 	IdentityCredentialsHandler    *handlerinventory.IdentityCredentialsHandler
// 	IdentityActivityHandler       *handlerinventory.IdentityActivityHandler
// 	IdentityBlastRadiusHandler    *handlerinventory.IdentityBlastRadiusHandler

// 	// Credential C1–C4, trust graph, orphaned credentials, impact analysis
// 	CredentialBoundIdentitiesHandler      *handlerinventory.CredentialBoundIdentitiesHandler
// 	CredentialEffectivePermissionsHandler *handlerinventory.CredentialEffectivePermissionsHandler
// 	CredentialUsageHandler                *handlerinventory.CredentialUsageHandler
// 	CredentialTrustChainHandler           *handlerinventory.CredentialTrustChainHandler
// 	TrustGraphHandler                     *handlerinventory.TrustGraphHandler
// 	OrphanedCredentialsHandler            *handlerinventory.OrphanedCredentialsHandler
// 	ImpactAnalysisHandler                 *handlerinventory.ImpactAnalysisHandler

// 	// Credential Exposure — secret scanner integration
// 	CredentialExposureFindingsHandler  *handlercredentialexposure.FindingsHandler
// 	CredentialExposureAllowlistHandler *handlercredentialexposure.AllowlistHandler
// 	CredentialExposureDecisionHandler  *handlercredentialexposure.DecisionHandler
// 	CredentialExposureDeepScanHandler  *handlercredentialexposure.DeepScanHandler
// }

// func SetupRoutes(h HandlerContainer) *mux.Router {
// 	r := mux.NewRouter()

// 	// ── Global middleware ─────────────────────────────────────────────────
// 	r.Use(middleware.RequestLogger)

// 	// ── Custom 404 & 405 — always return JSON, never plain text ──────────
// 	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
// 		w.Header().Set("Content-Type", "application/json")
// 		w.WriteHeader(http.StatusNotFound)
// 		_ = json.NewEncoder(w).Encode(map[string]interface{}{
// 			"success": false,
// 			"message": "route not found: " + r.Method + " " + r.URL.Path,
// 		})
// 	})

// 	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
// 		w.Header().Set("Content-Type", "application/json")
// 		w.WriteHeader(http.StatusMethodNotAllowed)
// 		_ = json.NewEncoder(w).Encode(map[string]interface{}{
// 			"success": false,
// 			"message": "method not allowed: " + r.Method + " " + r.URL.Path,
// 		})
// 	})

// 	// ── Health check ──────────────────────────────────────────────────────
// 	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
// 		w.Header().Set("Content-Type", "application/json")
// 		w.WriteHeader(http.StatusOK)
// 		_, _ = w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
// 	}).Methods("GET")

// 	// ─────────────────────────────────────────────────────────────────────
// 	// /api/v1 — versioned subrouter (auth protected)
// 	// ─────────────────────────────────────────────────────────────────────
// 	v1 := r.PathPrefix("/api/v1").Subrouter()
// 	v1.Use(h.AuthMiddleware.Authenticate)

// 	// Scan history; latest=true returns a single latest completed scan.
// 	v1.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

// 	// Dashboard
// 	v1.HandleFunc("/dashboard/summary", h.DashboardSummaryHandler.Summary).Methods("GET")
// 	v1.HandleFunc("/dashboard/identities/by-type", h.IdentitiesByTypeHandler.ByType).Methods("GET")
// 	v1.HandleFunc("/dashboard/identities/by-class", h.IdentitiesByClassHandler.ByClass).Methods("GET")
// 	v1.HandleFunc("/dashboard/identities/by-account", h.IdentitiesByAccountHandler.ByAccount).Methods("GET")
// 	v1.HandleFunc("/dashboard/identities/by-region", h.IdentitiesByRegionHandler.ByRegion).Methods("GET")
// 	v1.HandleFunc("/dashboard/credentials/by-type", h.CredentialsByTypeHandler.ByType).Methods("GET")
// 	v1.HandleFunc("/dashboard/blast-radius", h.BlastRadiusHandler.Summary).Methods("GET")
// 	v1.HandleFunc("/dashboard/overprivilege", h.OverprivilegeHandler.Summary).Methods("GET")
// 	v1.HandleFunc("/dashboard/trust-risks", h.TrustRisksHandler.Summary).Methods("GET")
// 	v1.HandleFunc("/dashboard/permissions/distribution", h.PermissionDistributionHandler.Distribution).Methods("GET")
// 	v1.HandleFunc("/dashboard/activity-heatmap", h.ActivityHeatmapHandler.Heatmap).Methods("GET")
// 	v1.HandleFunc("/attack-paths", h.AttackPathsHandler.List).Methods("GET")
// 	v1.HandleFunc("/unused-permissions", h.UnusedPermissionsHandler.List).Methods("GET")
// 	v1.HandleFunc("/shared-credentials", h.SharedCredentialsHandler.List).Methods("GET")
// 	v1.HandleFunc("/dashboard/credentials/hygiene", h.CredentialHygieneSummaryHandler.Hygiene).Methods("GET")
// 	v1.HandleFunc("/dashboard/identities/exposure", h.IdentitiesExposureHandler.Exposure).Methods("GET")
// 	v1.HandleFunc("/dashboard/recent-discoveries",
// 		h.DiscoveryHandler.RecentDiscoveries).Methods("GET")
// 	v1.HandleFunc("/dashboard/credentials/privilege-distribution",
// 		h.PrivilegeDistributionHandler.PrivilegeDistribution).Methods("GET")
// 	v1.HandleFunc("/dashboard/ownership-coverage",
// 		h.OwnershipCoverageHandler.OwnershipCoverage).Methods("GET")
// 	v1.HandleFunc("/dashboard/filters",
// 		h.FiltersHandler.Filters).Methods("GET")

// 	// ── Inventory — Credentials ───────────────────────────────────────────
// 	// ⚠️ ORDER MATTERS: static routes first, dynamic {id} routes last

// 	// 1. Static
// 	v1.HandleFunc("/inventory/credentials/counts",
// 		h.InventoryCredentialCountHandler.Counts).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/expiring",
// 		h.InventoryCredentialExpiringHandler.Expiring).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/stale",
// 		h.InventoryCredentialStaleHandler.Stale).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/export",
// 		h.InventoryCredentialExportHandler.Export).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}",
// 		h.InventoryCredentialUpdateHandler.UpdateCredential).Methods("PATCH")

// 	// ── Inventory — Identities ────────────────────────────────────────────
// 	v1.HandleFunc("/inventory/identities/counts", h.IdentityCountsHandler.Counts).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/export", h.ExportIdentitiesHandler.Export).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/dormant", h.IdentityDormantHandler.Dormant).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/grouped-by-class", h.IdentityGroupedByClassHandler.GroupedByClass).Methods("GET")
// 	v1.HandleFunc("/inventory/identities", h.IdentityListHandler.List).Methods("GET")
// 	// Identity sub-resources are registered before the single-identity route.
// 	v1.HandleFunc("/inventory/identities/{id}/credentials", h.IdentityCredentialsHandler.Credentials).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}/activity", h.IdentityActivityHandler.Activity).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}/blast-radius", h.IdentityBlastRadiusHandler.BlastRadius).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}/attributes", h.IdentityAttributesHandler.Attributes).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}/timeline", h.IdentityTimelineHandler.Timeline).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}", h.IdentityDetailHandler.Detail).Methods("GET")
// 	v1.HandleFunc("/inventory/identities/{id}", h.UpdateIdentityHandler.UpdateIdentity).Methods("PATCH")
// 	v1.HandleFunc("/inventory/search", h.IdentitySearchHandler.Search).Methods("GET")

// 	// 2. Sub-resource routes — /{id}/something (before plain /{id})
// 	v1.HandleFunc("/inventory/credentials/{id}/bound-identities", h.CredentialBoundIdentitiesHandler.Get).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/effective-permissions", h.CredentialEffectivePermissionsHandler.Get).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/usage", h.CredentialUsageHandler.Get).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/trust-chain", h.CredentialTrustChainHandler.Get).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/hygiene",
// 		h.InventoryCredentialHygieneHandler.Hygiene).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/trust-policy",
// 		h.InventoryTrustPolicyHandler.TrustPolicy).Methods("GET")
// 	v1.HandleFunc("/inventory/credentials/{id}/policies",
// 		h.InventoryAttachedPoliciesHandler.Policies).Methods("GET")
// 	v1.HandleFunc("/trust-graph", h.TrustGraphHandler.Get).Methods("GET")
// 	v1.HandleFunc("/orphaned-credentials", h.OrphanedCredentialsHandler.Get).Methods("GET")
// 	v1.HandleFunc("/impact/{entity_type}/{id}", h.ImpactAnalysisHandler.Get).Methods("GET")

// 	// 3. Single resource — /{id}
// 	v1.HandleFunc("/inventory/credentials/{id}",
// 		h.InventoryCredentialDetailsHandler.Detail).Methods("GET")

// 	// 4. Collection — /
// 	v1.HandleFunc("/inventory/credentials",
// 		h.InventoryCredentialHandler.List).Methods("GET")

// 	// ─────────────────────────────────────────────────────────────────────
// 	// /api — unversioned subrouter
// 	// ─────────────────────────────────────────────────────────────────────
// 	api := r.PathPrefix("/api").Subrouter()
// 	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

// 	protected := api.PathPrefix("").Subrouter()
// 	protected.Use(h.AuthMiddleware.Authenticate)

// 	// Auth
// 	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

// 	// Credential Exposure — scanner findings and analyst operations (JWT protected)
// 	protected.HandleFunc("/findings/summary", h.CredentialExposureFindingsHandler.Summary).Methods("GET")
// 	protected.HandleFunc("/findings/ml-flagged", h.CredentialExposureFindingsHandler.ListFlagged).Methods("GET")
// 	protected.HandleFunc("/findings/decision", h.CredentialExposureDecisionHandler.Save).Methods("POST")
// 	protected.HandleFunc("/findings", h.CredentialExposureFindingsHandler.List).Methods("GET")
// 	protected.HandleFunc("/allowlist", h.CredentialExposureAllowlistHandler.List).Methods("GET")
// 	protected.HandleFunc("/allowlist", h.CredentialExposureAllowlistHandler.Create).Methods("POST")
// 	protected.HandleFunc("/allowlist", h.CredentialExposureAllowlistHandler.Delete).Methods("DELETE")
// 	protected.HandleFunc("/deep-scan", h.CredentialExposureDeepScanHandler.Trigger).Methods("POST")
// 	protected.HandleFunc("/deep-scan-status", h.CredentialExposureDeepScanHandler.Status).Methods("GET")

// 	// Identity lineage — GET /api/identities/lineage?arn=...&scan_id=...&page=1&page_size=10
// 	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")

// 	// Dashboard
// 	protected.HandleFunc("/dashboard/summary",
// 		h.DashboardHandler.Summary).Methods("GET")
// 	protected.HandleFunc("/dashboard/identities/by-type",
// 		h.IdentitiesByTypeHandler.ByType).Methods("GET")
// 	protected.HandleFunc("/dashboard/identities/by-class",
// 		h.IdentitiesByClassHandler.ByClass).Methods("GET")
// 	protected.HandleFunc("/dashboard/identities/by-account",
// 		h.IdentitiesByAccountHandler.ByAccount).Methods("GET")
// 	protected.HandleFunc("/dashboard/identities/by-region",
// 		h.IdentitiesByRegionHandler.ByRegion).Methods("GET")
// 	protected.HandleFunc("/dashboard/credentials/by-type",
// 		h.CredentialsByTypeHandler.ByType).Methods("GET")
// 	protected.HandleFunc("/dashboard/blast-radius", h.BlastRadiusHandler.Summary).Methods("GET")
// 	protected.HandleFunc("/dashboard/overprivilege", h.OverprivilegeHandler.Summary).Methods("GET")
// 	protected.HandleFunc("/dashboard/trust-risks", h.TrustRisksHandler.Summary).Methods("GET")
// 	protected.HandleFunc("/dashboard/permissions/distribution", h.PermissionDistributionHandler.Distribution).Methods("GET")
// 	protected.HandleFunc("/dashboard/activity-heatmap", h.ActivityHeatmapHandler.Heatmap).Methods("GET")
// 	protected.HandleFunc("/attack-paths", h.AttackPathsHandler.List).Methods("GET")
// 	protected.HandleFunc("/unused-permissions", h.UnusedPermissionsHandler.List).Methods("GET")
// 	protected.HandleFunc("/shared-credentials", h.SharedCredentialsHandler.List).Methods("GET")
// 	protected.HandleFunc("/dashboard/credentials/hygiene",
// 		h.CredentialHygieneSummaryHandler.Hygiene).Methods("GET")
// 	protected.HandleFunc("/dashboard/identities/exposure", h.IdentitiesExposureHandler.Exposure).Methods("GET")
// 	protected.HandleFunc("/dashboard/my-resources",
// 		h.DashboardHandler.MyResources).Methods("GET")
// 	protected.HandleFunc("/dashboard/recent-discoveries",
// 		h.DiscoveryHandler.RecentDiscoveries).Methods("GET")
// 	protected.HandleFunc("/dashboard/credentials/privilege-distribution",
// 		h.PrivilegeDistributionHandler.PrivilegeDistribution).Methods("GET")
// 	protected.HandleFunc("/dashboard/ownership-coverage",
// 		h.OwnershipCoverageHandler.OwnershipCoverage).Methods("GET")
// 	protected.HandleFunc("/dashboard/filters",
// 		h.FiltersHandler.Filters).Methods("GET")

// 	// ── Inventory — Credentials ───────────────────────────────────────────
// 	// ⚠️ Same order rule: static → sub-resource → single → collection

// 	// 1. Static
// 	protected.HandleFunc("/inventory/credentials/counts",
// 		h.InventoryCredentialCountHandler.Counts).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/expiring",
// 		h.InventoryCredentialExpiringHandler.Expiring).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/stale",
// 		h.InventoryCredentialStaleHandler.Stale).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/export",
// 		h.InventoryCredentialExportHandler.Export).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}",
// 		h.InventoryCredentialUpdateHandler.UpdateCredential).Methods("PATCH")

// 	// ── Inventory — Identities ────────────────────────────────────────────
// 	protected.HandleFunc("/inventory/identities/counts", h.IdentityCountsHandler.Counts).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/export", h.ExportIdentitiesHandler.Export).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/dormant", h.IdentityDormantHandler.Dormant).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/grouped-by-class", h.IdentityGroupedByClassHandler.GroupedByClass).Methods("GET")
// 	protected.HandleFunc("/inventory/identities", h.IdentityListHandler.List).Methods("GET")
// 	// Identity sub-resources are registered before the single-identity route.
// 	protected.HandleFunc("/inventory/identities/{id}/credentials", h.IdentityCredentialsHandler.Credentials).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}/activity", h.IdentityActivityHandler.Activity).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}/blast-radius", h.IdentityBlastRadiusHandler.BlastRadius).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}/attributes", h.IdentityAttributesHandler.Attributes).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}/timeline", h.IdentityTimelineHandler.Timeline).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}", h.IdentityDetailHandler.Detail).Methods("GET")
// 	protected.HandleFunc("/inventory/identities/{id}", h.UpdateIdentityHandler.UpdateIdentity).Methods("PATCH")
// 	protected.HandleFunc("/inventory/search", h.IdentitySearchHandler.Search).Methods("GET")

// 	// 2. Sub-resource
// 	protected.HandleFunc("/inventory/credentials/{id}/bound-identities", h.CredentialBoundIdentitiesHandler.Get).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/effective-permissions", h.CredentialEffectivePermissionsHandler.Get).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/usage", h.CredentialUsageHandler.Get).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/trust-chain", h.CredentialTrustChainHandler.Get).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/hygiene",
// 		h.InventoryCredentialHygieneHandler.Hygiene).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/trust-policy",
// 		h.InventoryTrustPolicyHandler.TrustPolicy).Methods("GET")
// 	protected.HandleFunc("/inventory/credentials/{id}/policies",
// 		h.InventoryAttachedPoliciesHandler.Policies).Methods("GET")
// 	protected.HandleFunc("/trust-graph", h.TrustGraphHandler.Get).Methods("GET")
// 	protected.HandleFunc("/orphaned-credentials", h.OrphanedCredentialsHandler.Get).Methods("GET")
// 	protected.HandleFunc("/impact/{entity_type}/{id}", h.ImpactAnalysisHandler.Get).Methods("GET")

// 	// 3. Single resource
// 	protected.HandleFunc("/inventory/credentials/{id}",
// 		h.InventoryCredentialDetailsHandler.Detail).Methods("GET")

// 	// 4. Collection
// 	protected.HandleFunc("/inventory/credentials",
// 		h.InventoryCredentialHandler.List).Methods("GET")

// 	// Legacy
// 	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")
// 	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")
// 	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

// 	return r
// }













package routes

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/middleware"
	handlernewapi "nhi-backend-api/internal/handlers/new_api"
)

// HandlerContainer — ONLY auth + the new_api handlers are wired now.
// All legacy handlers (dashboard, inventory, credential exposure, ...) are
// commented out below; they are kept for reference and are NOT served.
type HandlerContainer struct {
	// Auth (global database)
	AuthHandler    *handlers.AuthHandler
	AuthMiddleware *middleware.AuthMiddleware

	SettingsHandler *handlernewapi.SettingsHandler
	UpdateSettingsHandler *handlernewapi.UpdateSettingsHandler
	FilterOptionsHandler     *handlernewapi.FilterOptionsHandler 
	DashboardOverviewHandler *handlernewapi.DashboardOverviewHandler 
	IdentitiesListHandler *handlernewapi.IdentitiesListHandler 
	IdentityDetailHandler *handlernewapi.IdentityDetailHandler
	CredentialsListHandler *handlernewapi.CredentialsListHandler
	CredentialDetailHandler *handlernewapi.CredentialDetailHandler

	
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// ── Global middleware ─────────────────────────────────────────────────
	r.Use(middleware.RequestLogger)

	// ── Custom 404 & 405 — always return JSON, never plain text ──────────
	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusNotFound)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "route not found: " + r.Method + " " + r.URL.Path,
		})
	})

	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusMethodNotAllowed)
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"message": "method not allowed: " + r.Method + " " + r.URL.Path,
		})
	})

	// ── Health check ──────────────────────────────────────────────────────
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	// ── /api/auth — login against nhi_global (name comes from config) ─────
	api := r.PathPrefix("/api").Subrouter()
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// ── /api/v1 — NEW APIs only (JWT protected, tenant DB from token) ─────
	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.AuthMiddleware.Authenticate)
	// Endpoint 1A — Get Settings
	v1.HandleFunc("/settings", h.SettingsHandler.Get).Methods("GET")
	v1.HandleFunc("/settings", h.UpdateSettingsHandler.Update).Methods("PUT")
	v1.HandleFunc("/filters", h.FilterOptionsHandler.Get).Methods("GET")
	v1.HandleFunc("/dashboard/overview", h.DashboardOverviewHandler.Get).Methods("GET")
	v1.HandleFunc("/identities", h.IdentitiesListHandler.List).Methods("GET")
	v1.HandleFunc("/identities/{id}", h.IdentityDetailHandler.Get).Methods("GET")
	v1.HandleFunc("/credentials", h.CredentialsListHandler.List).Methods("GET")
	v1.HandleFunc("/credentials/{id}", h.CredentialDetailHandler.Get).Methods("GET")




	return r
}