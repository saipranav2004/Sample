// package main

// import (
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"os"
// 	"time"

// 	"nhi-backend-api/internal/config"
// 	"nhi-backend-api/internal/handlers"
// 	handlerdashboard "nhi-backend-api/internal/handlers/dashboard"
// 	"nhi-backend-api/internal/middleware"
// 	"nhi-backend-api/internal/repository"
// 	repodashboard "nhi-backend-api/internal/repository/dashboard"
// 	"nhi-backend-api/internal/routes"
// 	"nhi-backend-api/internal/services"
// 	svcdashboard "nhi-backend-api/internal/services/dashboard"

// 	handlercredentialexposure "nhi-backend-api/internal/handlers/Credential_Exposure"
// 	handlerinventory "nhi-backend-api/internal/handlers/inventory"
// 	repocredentialexposure "nhi-backend-api/internal/repository/Credential_Exposure"
// 	repoinventory "nhi-backend-api/internal/repository/inventory"
// 	svccredentialexposure "nhi-backend-api/internal/services/Credential_Exposure"
// 	svcinventory "nhi-backend-api/internal/services/inventory"
// )

// func main() {
// 	fmt.Println("╔══════════════════════════════════════════╗")
// 	fmt.Println("║     NHI Discovery — Backend API Server   ║")
// 	fmt.Println("║     Identity Management Platform         ║")
// 	fmt.Println("╚══════════════════════════════════════════╝")
// 	fmt.Println()

// 	// 1. Load Config
// 	cfg, err := config.Load()
// 	if err != nil {
// 		log.Fatalf("❌ Failed to load config: %v", err)
// 	}

// 	// 2. Connect DB
// 	db, err := repository.NewPostgresDB(&cfg.Database)
// 	if err != nil {
// 		log.Fatalf("❌ Database connection failed: %v", err)
// 	}
// 	defer db.Close()

// 	// 3. Repositories
// 	validatorRepo := repoinventory.NewValidatorRepository(db)

// 	userRepo := repository.NewUserRepository(db)
// 	identityDetailsRepo := repository.NewIdentityDetailsRepository(db)
// 	scanRepo := repository.NewScanRepository(db)
// 	dashboardRepo := repository.NewDashboardRepository(db)
// 	eventRepo := repository.NewEventRepository(db)
// 	credentialRepo := repository.NewCredentialRepository(db)
// 	lineageRepo := repository.NewLineageRepository(db)

// 	discoveryRepo := repodashboard.NewDiscoveryRepository(db)
// 	privilegeDistributionRepo := repodashboard.NewPrivilegeDistributionRepository(db)
// 	ownershipCoverageRepo := repodashboard.NewOwnershipCoverageRepository(db)
// 	filtersRepo := repodashboard.NewFiltersRepository(db)
// 	dashboardSummaryRepo := repodashboard.NewSummaryRepository(db)
// 	identitiesByTypeRepo := repodashboard.NewIdentitiesByTypeRepository(db)
// 	identitiesByClassRepo := repodashboard.NewIdentitiesByClassRepository(db)
// 	identitiesByAccountRepo := repodashboard.NewIdentitiesByAccountRepository(db)
// 	identitiesByRegionRepo := repodashboard.NewIdentitiesByRegionRepository(db)
// 	credentialsByTypeRepo := repodashboard.NewCredentialsByTypeRepository(db)
// 	blastRadiusRepo := repodashboard.NewBlastRadiusRepository(db)
// 	overprivilegeRepo := repodashboard.NewOverprivilegeRepository(db)
// 	trustRisksRepo := repodashboard.NewTrustRisksRepository(db)
// 	permissionDistributionRepo := repodashboard.NewPermissionDistributionRepository(db)
// 	activityHeatmapRepo := repodashboard.NewActivityHeatmapRepository(db)
// 	sharedCredentialsRepo := repodashboard.NewSharedCredentialsRepository(db)
// 	attackPathsRepo := repository.NewAttackPathsRepository(db)
// 	unusedPermissionsRepo := repository.NewUnusedPermissionsRepository(db)
// 	credentialHygieneSummaryRepo := repodashboard.NewCredentialHygieneSummaryRepository(db)
// 	identitiesExposureRepo := repodashboard.NewIdentitiesExposureRepository(db)

// 	inventoryCredRepo := repoinventory.NewCredentialRepository(db)
// 	inventoryCredDetailsRepo := repoinventory.NewCredentialDetailsRepository(db)
// 	inventoryCredCountRepo := repoinventory.NewCredentialCountRepository(db)
// 	inventoryCredHygieneRepo := repoinventory.NewCredentialHygieneRepository(db)
// 	trustPolicyRepo := repoinventory.NewTrustPolicyRepository(db)
// 	attachedPoliciesRepo := repoinventory.NewAttachedPoliciesRepository(db)
// 	inventoryCredExpiringRepo := repoinventory.NewCredentialExpiringRepository(db)
// 	inventoryCredStaleRepo := repoinventory.NewCredentialStaleRepository(db)
// 	inventoryCredExportRepo := repoinventory.NewCredentialExportRepository(db)
// 	inventoryCredUpdateRepo := repoinventory.NewUpdateCredentialRepository(db)

// 	// Repositories that take a raw *sql.DB
// 	credentialC1C4Repo := repoinventory.NewCredentialAPIRepository(db.DB)
// 	trustGraphRepo := repoinventory.NewTrustGraphRepository(db.DB)
// 	orphanedCredentialsRepo := repoinventory.NewOrphanedCredentialsRepository(db.DB)
// 	impactAnalysisRepo := repoinventory.NewImpactAnalysisRepository(db.DB)

// 	credentialExposureFindingsRepo := repocredentialexposure.NewFindingsRepository(db.DB)
// 	credentialExposureAllowlistRepo := repocredentialexposure.NewAllowlistRepository(db.DB)
// 	credentialExposureDecisionRepo := repocredentialexposure.NewDecisionRepository(db.DB)
// 	credentialExposureDeepScanRepo := repocredentialexposure.NewDeepScanRepository(db.DB)

// 	identityListRepo := repoinventory.NewIdentityListRepository(db)
// 	identityDetailRepo := repoinventory.NewIdentityDetailRepository(db)
// 	identityCredentialsRepo := repoinventory.NewIdentityCredentialsRepository(db)
// 	identityActivityRepo := repoinventory.NewIdentityActivityRepository(db)
// 	identityBlastRadiusRepo := repoinventory.NewIdentityBlastRadiusRepository(db)
// 	identityAttributesRepo := repoinventory.NewIdentityAttributesRepository(db)
// 	identityTimelineRepo := repoinventory.NewIdentityTimelineRepository(db)
// 	identityGroupedByClassRepo := repoinventory.NewIdentityGroupedByClassRepository(db)
// 	identityDormantRepo := repoinventory.NewIdentityDormantRepository(db)
// 	exportIdentitiesRepo := repoinventory.NewExportIdentitiesRepository(db)

// 	updateIdentityRepo := repoinventory.NewUpdateIdentityRepository(db)
// 	identityCountsRepo := repoinventory.NewIdentityCountsRepository(db)
// 	searchRepo := repoinventory.NewSearchRepository(db)

// 	// 4. Services
// 	authService := services.NewAuthService(userRepo, cfg.JWT)
// 	dashboardService := services.NewDashboardService(dashboardRepo, identityDetailsRepo)
// 	scanService := services.NewScanService(scanRepo)
// 	credentialService := services.NewCredentialService(credentialRepo)
// 	lineageService := services.NewLineageService(lineageRepo)

// 	discoveryService := svcdashboard.NewDiscoveryService(discoveryRepo)
// 	privilegeDistributionService := svcdashboard.NewPrivilegeDistributionService(privilegeDistributionRepo)
// 	ownershipCoverageService := svcdashboard.NewOwnershipCoverageService(ownershipCoverageRepo)
// 	filtersService := svcdashboard.NewFiltersService(filtersRepo)
// 	dashboardSummaryService := svcdashboard.NewSummaryService(dashboardSummaryRepo)
// 	identitiesByTypeService := svcdashboard.NewIdentitiesByTypeService(identitiesByTypeRepo)
// 	identitiesByClassService := svcdashboard.NewIdentitiesByClassService(identitiesByClassRepo)
// 	identitiesByAccountService := svcdashboard.NewIdentitiesByAccountService(identitiesByAccountRepo)
// 	identitiesByRegionService := svcdashboard.NewIdentitiesByRegionService(identitiesByRegionRepo)
// 	credentialsByTypeService := svcdashboard.NewCredentialsByTypeService(credentialsByTypeRepo)
// 	blastRadiusService := svcdashboard.NewBlastRadiusService(blastRadiusRepo)
// 	overprivilegeService := svcdashboard.NewOverprivilegeService(overprivilegeRepo)
// 	trustRisksService := svcdashboard.NewTrustRisksService(trustRisksRepo)
// 	permissionDistributionService := svcdashboard.NewPermissionDistributionService(permissionDistributionRepo)
// 	activityHeatmapService := svcdashboard.NewActivityHeatmapService(activityHeatmapRepo)
// 	sharedCredentialsService := svcdashboard.NewSharedCredentialsService(sharedCredentialsRepo)
// 	attackPathsService := services.NewAttackPathsService(attackPathsRepo)
// 	unusedPermissionsService := services.NewUnusedPermissionsService(unusedPermissionsRepo)
// 	credentialHygieneSummaryService := svcdashboard.NewCredentialHygieneSummaryService(credentialHygieneSummaryRepo)
// 	identitiesExposureService := svcdashboard.NewIdentitiesExposureService(identitiesExposureRepo)

// 	boundIdentitiesService := svcinventory.NewCredentialBoundIdentitiesService(credentialC1C4Repo)
// 	effectivePermissionsService := svcinventory.NewCredentialEffectivePermissionsService(credentialC1C4Repo)
// 	credentialUsageService := svcinventory.NewCredentialUsageService(credentialC1C4Repo)
// 	trustChainService := svcinventory.NewCredentialTrustChainService(credentialC1C4Repo)
// 	// dashboardRepo implements AllKnownAccountIDs (internal/repository/dashboard_account_ids.go)
// 	credentialC1C4Scope := handlerinventory.NewCredentialAllAccountsScope(dashboardRepo)
// 	trustGraphService := svcinventory.NewTrustGraphService(trustGraphRepo)
// 	orphanedCredentialsService := svcinventory.NewOrphanedCredentialsService(orphanedCredentialsRepo)
// 	impactAnalysisService := svcinventory.NewImpactAnalysisService(impactAnalysisRepo)

// 	credentialExposureFindingsService := svccredentialexposure.NewFindingsService(credentialExposureFindingsRepo)
// 	credentialExposureAllowlistService := svccredentialexposure.NewAllowlistService(credentialExposureAllowlistRepo)
// 	credentialExposureDecisionService := svccredentialexposure.NewDecisionService(credentialExposureDecisionRepo)
// 	credentialExposureDeepScanService := svccredentialexposure.NewDeepScanService(
// 		credentialExposureDeepScanRepo,
// 		os.Getenv("SECRET_SCANNER_BASE_URL"),
// 		os.Getenv("SECRET_SCANNER_DASHBOARD_KEY"),
// 	)

// 	inventoryCredService := svcinventory.NewCredentialService(inventoryCredRepo)
// 	inventoryCredDetailsService := svcinventory.NewCredentialDetailsService(inventoryCredDetailsRepo)
// 	inventoryCredCountService := svcinventory.NewCredentialCountService(inventoryCredCountRepo, validatorRepo)
// 	inventoryCredHygieneService := svcinventory.NewCredentialHygieneService(inventoryCredHygieneRepo)
// 	trustPolicyService := svcinventory.NewTrustPolicyService(trustPolicyRepo)
// 	attachedPoliciesService := svcinventory.NewAttachedPoliciesService(attachedPoliciesRepo)
// 	inventoryCredExpiringService := svcinventory.NewCredentialExpiringService(inventoryCredExpiringRepo)
// 	inventoryCredStaleService := svcinventory.NewCredentialStaleService(inventoryCredStaleRepo)
// 	inventoryCredExportService := svcinventory.NewCredentialExportService(inventoryCredExportRepo)
// 	inventoryCredUpdateService := svcinventory.NewUpdateCredentialService(inventoryCredUpdateRepo)

// 	identityListService := svcinventory.NewIdentityListService(identityListRepo)
// 	identityDetailService := svcinventory.NewIdentityDetailService(identityDetailRepo)
// 	identityCredentialsService := svcinventory.NewIdentityCredentialsService(identityCredentialsRepo)
// 	identityActivityService := svcinventory.NewIdentityActivityService(identityActivityRepo)
// 	identityBlastRadiusService := svcinventory.NewIdentityBlastRadiusService(identityBlastRadiusRepo)
// 	identityAttributesService := svcinventory.NewIdentityAttributesService(identityAttributesRepo)
// 	identityTimelineService := svcinventory.NewIdentityTimelineService(identityTimelineRepo)
// 	identityGroupedByClassService := svcinventory.NewIdentityGroupedByClassService(identityGroupedByClassRepo)
// 	identityDormantService := svcinventory.NewIdentityDormantService(identityDormantRepo)
// 	exportIdentitiesSvc := svcinventory.NewExportIdentitiesService(exportIdentitiesRepo)

// 	updateIdentityService := svcinventory.NewUpdateIdentityService(updateIdentityRepo)
// 	identityCountsService := svcinventory.NewIdentityCountsService(identityCountsRepo)
// 	searchService := svcinventory.NewSearchService(searchRepo)

// 	// 5. Handlers & Middleware
// 	authHandler := handlers.NewAuthHandler(authService)
// 	dashboardHandler := handlers.NewDashboardHandler(dashboardService)
// 	scanHandler := handlers.NewScanHandler(scanService)
// 	eventHandler := handlers.NewEventHandler(eventRepo)
// 	credentialHandler := handlers.NewCredentialHandler(credentialService)
// 	lineageHandler := handlers.NewLineageHandler(lineageService)
// 	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)

// 	discoveryHandler := handlerdashboard.NewDiscoveryHandler(discoveryService)
// 	privilegeDistributionHandler := handlerdashboard.NewPrivilegeDistributionHandler(privilegeDistributionService)
// 	ownershipCoverageHandler := handlerdashboard.NewOwnershipCoverageHandler(ownershipCoverageService)
// 	filtersHandler := handlerdashboard.NewFiltersHandler(filtersService)
// 	dashboardSummaryHandler := handlerdashboard.NewSummaryHandler(dashboardSummaryService)
// 	identitiesByTypeHandler := handlerdashboard.NewIdentitiesByTypeHandler(identitiesByTypeService)
// 	identitiesByClassHandler := handlerdashboard.NewIdentitiesByClassHandler(identitiesByClassService)
// 	identitiesByAccountHandler := handlerdashboard.NewIdentitiesByAccountHandler(identitiesByAccountService)
// 	identitiesByRegionHandler := handlerdashboard.NewIdentitiesByRegionHandler(identitiesByRegionService)
// 	credentialsByTypeHandler := handlerdashboard.NewCredentialsByTypeHandler(credentialsByTypeService)
// 	blastRadiusHandler := handlerdashboard.NewBlastRadiusHandler(blastRadiusService)
// 	overprivilegeHandler := handlerdashboard.NewOverprivilegeHandler(overprivilegeService)
// 	trustRisksHandler := handlerdashboard.NewTrustRisksHandler(trustRisksService)
// 	permissionDistributionHandler := handlerdashboard.NewPermissionDistributionHandler(permissionDistributionService)
// 	activityHeatmapHandler := handlerdashboard.NewActivityHeatmapHandler(activityHeatmapService)
// 	sharedCredentialsHandler := handlerdashboard.NewSharedCredentialsHandler(sharedCredentialsService)
// 	attackPathsHandler := handlers.NewAttackPathsHandler(attackPathsService)
// 	unusedPermissionsHandler := handlers.NewUnusedPermissionsHandler(unusedPermissionsService)
// 	credentialHygieneSummaryHandler := handlerdashboard.NewCredentialHygieneSummaryHandler(credentialHygieneSummaryService)
// 	identitiesExposureHandler := handlerdashboard.NewIdentitiesExposureHandler(identitiesExposureService)

// 	boundIdentitiesHandler := handlerinventory.NewCredentialBoundIdentitiesHandler(boundIdentitiesService, credentialC1C4Scope)
// 	effectivePermissionsHandler := handlerinventory.NewCredentialEffectivePermissionsHandler(effectivePermissionsService, credentialC1C4Scope)
// 	usageHandler := handlerinventory.NewCredentialUsageHandler(credentialUsageService, credentialC1C4Scope)
// 	trustChainHandler := handlerinventory.NewCredentialTrustChainHandler(trustChainService, credentialC1C4Scope)
// 	trustGraphHandler := handlerinventory.NewTrustGraphHandler(trustGraphService, credentialC1C4Scope)
// 	orphanedCredentialsHandler := handlerinventory.NewOrphanedCredentialsHandler(orphanedCredentialsService, credentialC1C4Scope)
// 	impactAnalysisHandler := handlerinventory.NewImpactAnalysisHandler(impactAnalysisService, credentialC1C4Scope)

// 	credentialExposureFindingsHandler := handlercredentialexposure.NewFindingsHandler(credentialExposureFindingsService)
// 	credentialExposureAllowlistHandler := handlercredentialexposure.NewAllowlistHandler(credentialExposureAllowlistService)
// 	credentialExposureDecisionHandler := handlercredentialexposure.NewDecisionHandler(credentialExposureDecisionService)
// 	credentialExposureDeepScanHandler := handlercredentialexposure.NewDeepScanHandler(credentialExposureDeepScanService)

// 	inventoryCredHandler := handlerinventory.NewCredentialHandler(inventoryCredService)
// 	inventoryCredDetailsHandler := handlerinventory.NewCredentialDetailsHandler(inventoryCredDetailsService)
// 	inventoryCredCountHandler := handlerinventory.NewCredentialCountHandler(inventoryCredCountService)
// 	inventoryCredHygieneHandler := handlerinventory.NewCredentialHygieneHandler(inventoryCredHygieneService)
// 	trustPolicyHandler := handlerinventory.NewTrustPolicyHandler(trustPolicyService)
// 	attachedPoliciesHandler := handlerinventory.NewAttachedPoliciesHandler(attachedPoliciesService)
// 	inventoryCredExpiringHandler := handlerinventory.NewCredentialExpiringHandler(inventoryCredExpiringService)
// 	inventoryCredStaleHandler := handlerinventory.NewCredentialStaleHandler(inventoryCredStaleService)
// 	inventoryCredExportHandler := handlerinventory.NewCredentialExportHandler(inventoryCredExportService)
// 	inventoryCredUpdateHandler := handlerinventory.NewUpdateCredentialHandler(inventoryCredUpdateService)

// 	identityListHandler := handlerinventory.NewIdentityListHandler(identityListService)
// 	identityDetailHandler := handlerinventory.NewIdentityDetailHandler(identityDetailService)
// 	identityAttributesHandler := handlerinventory.NewIdentityAttributesHandler(identityAttributesService)
// 	identityTimelineHandler := handlerinventory.NewIdentityTimelineHandler(identityTimelineService)
// 	identityGroupedByClassHandler := handlerinventory.NewIdentityGroupedByClassHandler(identityGroupedByClassService)
// 	identityDormantHandler := handlerinventory.NewIdentityDormantHandler(identityDormantService)
// 	exportIdentitiesHandler := handlerinventory.NewExportIdentitiesHandler(exportIdentitiesSvc)
// 	updateIdentityHandler := handlerinventory.NewUpdateIdentityHandler(updateIdentityService)
// 	identityCountsHandler := handlerinventory.NewIdentityCountsHandler(identityCountsService)
// 	searchHandler := handlerinventory.NewSearchHandler(searchService)
// 	identityCredentialsHandler := handlerinventory.NewIdentityCredentialsHandler(identityCredentialsService, credentialC1C4Scope)
// 	identityActivityHandler := handlerinventory.NewIdentityActivityHandler(identityActivityService, credentialC1C4Scope)
// 	identityBlastRadiusHandler := handlerinventory.NewIdentityBlastRadiusHandler(identityBlastRadiusService, credentialC1C4Scope)

// 	// 6. Router
// 	router := routes.SetupRoutes(routes.HandlerContainer{
// 		// Auth
// 		AuthHandler:    authHandler,
// 		AuthMiddleware: authMiddleware,

// 		// Legacy
// 		DashboardHandler:  dashboardHandler,
// 		ScanHandler:       scanHandler,
// 		EventHandler:      eventHandler,
// 		LineageHandler:    lineageHandler,
// 		CredentialHandler: credentialHandler,

// 		// Dashboard
// 		DiscoveryHandler:                discoveryHandler,
// 		PrivilegeDistributionHandler:    privilegeDistributionHandler,
// 		OwnershipCoverageHandler:        ownershipCoverageHandler,
// 		FiltersHandler:                  filtersHandler,
// 		DashboardSummaryHandler:         dashboardSummaryHandler,
// 		IdentitiesByTypeHandler:         identitiesByTypeHandler,
// 		IdentitiesByClassHandler:        identitiesByClassHandler,
// 		IdentitiesByAccountHandler:      identitiesByAccountHandler,
// 		IdentitiesByRegionHandler:       identitiesByRegionHandler,
// 		CredentialsByTypeHandler:        credentialsByTypeHandler,
// 		BlastRadiusHandler:              blastRadiusHandler,
// 		OverprivilegeHandler:            overprivilegeHandler,
// 		TrustRisksHandler:               trustRisksHandler,
// 		PermissionDistributionHandler:   permissionDistributionHandler,
// 		ActivityHeatmapHandler:          activityHeatmapHandler,
// 		SharedCredentialsHandler:        sharedCredentialsHandler,
// 		AttackPathsHandler:              attackPathsHandler,
// 		UnusedPermissionsHandler:        unusedPermissionsHandler,
// 		CredentialHygieneSummaryHandler: credentialHygieneSummaryHandler,
// 		IdentitiesExposureHandler:       identitiesExposureHandler,

// 		// Inventory — Credentials
// 		InventoryCredentialHandler:         inventoryCredHandler,
// 		InventoryCredentialDetailsHandler:  inventoryCredDetailsHandler,
// 		InventoryCredentialCountHandler:    inventoryCredCountHandler,
// 		InventoryCredentialHygieneHandler:  inventoryCredHygieneHandler,
// 		InventoryTrustPolicyHandler:        trustPolicyHandler,
// 		InventoryAttachedPoliciesHandler:   attachedPoliciesHandler,
// 		InventoryCredentialExpiringHandler: inventoryCredExpiringHandler,
// 		InventoryCredentialStaleHandler:    inventoryCredStaleHandler,
// 		InventoryCredentialExportHandler:   inventoryCredExportHandler,
// 		InventoryCredentialUpdateHandler:   inventoryCredUpdateHandler,

// 		// Inventory — Identities
// 		IdentityListHandler:           identityListHandler,
// 		IdentityDetailHandler:         identityDetailHandler,
// 		IdentityAttributesHandler:     identityAttributesHandler,
// 		IdentityTimelineHandler:       identityTimelineHandler,
// 		IdentityGroupedByClassHandler: identityGroupedByClassHandler,
// 		IdentityDormantHandler:        identityDormantHandler,
// 		ExportIdentitiesHandler:       exportIdentitiesHandler,
// 		UpdateIdentityHandler:         updateIdentityHandler,
// 		IdentityCountsHandler:         identityCountsHandler,
// 		IdentitySearchHandler:         searchHandler,
// 		IdentityCredentialsHandler:    identityCredentialsHandler,
// 		IdentityActivityHandler:       identityActivityHandler,
// 		IdentityBlastRadiusHandler:    identityBlastRadiusHandler,

// 		// Credential C1–C4, trust graph, orphaned, impact
// 		CredentialBoundIdentitiesHandler:      boundIdentitiesHandler,
// 		CredentialEffectivePermissionsHandler: effectivePermissionsHandler,
// 		CredentialUsageHandler:                usageHandler,
// 		CredentialTrustChainHandler:           trustChainHandler,
// 		TrustGraphHandler:                     trustGraphHandler,
// 		OrphanedCredentialsHandler:            orphanedCredentialsHandler,
// 		ImpactAnalysisHandler:                 impactAnalysisHandler,

// 		// Credential Exposure
// 		CredentialExposureFindingsHandler:  credentialExposureFindingsHandler,
// 		CredentialExposureAllowlistHandler: credentialExposureAllowlistHandler,
// 		CredentialExposureDecisionHandler:  credentialExposureDecisionHandler,
// 		CredentialExposureDeepScanHandler:  credentialExposureDeepScanHandler,
// 	})

// 	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

// 	// 7. Server Setup
// 	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
// 	server := &http.Server{
// 		Addr:         addr,
// 		Handler:      corsHandler,
// 		ReadTimeout:  15 * time.Second,
// 		WriteTimeout: 15 * time.Second,
// 		IdleTimeout:  60 * time.Second,
// 	}

// 	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
// 	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
// 		log.Fatalf("❌ Server error: %v", err)
// 	}
// }















package main
 
import (
	"fmt"
	"log"
	"net/http"
	"time"
 
	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/database"
	"nhi-backend-api/internal/handlers"
	handlernewapi "nhi-backend-api/internal/handlers/new_api"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	reponewapi "nhi-backend-api/internal/repository/new_api"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	svcnewapi "nhi-backend-api/internal/services/new_api"



	handlerpostures "nhi-backend-api/internal/handlers/postures"
	repopostures "nhi-backend-api/internal/repository/postures"
	svcpostures "nhi-backend-api/internal/services/postures"
)
 
func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()
 
	// 1. Load Config (database NAMES live in configs/config.yaml, never in code)
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
 
	// 2. Databases
	//    • global_database → authentication only (users / tenants)
	//    • database        → default DATA db; each tenant's own db_name (from the JWT)
	//                        is opened on demand by the manager.
	dbm, err := database.NewManager(cfg)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer dbm.Close()
	fmt.Printf("schemas → global=%q data=%q\n", dbm.GlobalSchema(), dbm.DataSchema())
 
	// 3. Auth — uses the GLOBAL database only
	userRepo := repository.NewUserRepository(dbm.Global(), dbm.GlobalSchema())
	authService := services.NewAuthService(userRepo, cfg.JWT)
	authHandler := handlers.NewAuthHandler(authService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT, authService)
 
	// 4. New APIs (internal/*/new_api) — tenant data DB comes from the JWT db_name
	scanRepo := reponewapi.NewScanRepository(dbm.DataSchema())
 
	// Endpoint 1A — Get Settings
	settingsRepo := reponewapi.NewSettingsRepository(dbm.DataSchema())
	settingsService := svcnewapi.NewSettingsService(dbm, settingsRepo, scanRepo)
	settingsHandler := handlernewapi.NewSettingsHandler(settingsService)
 
	// Endpoint 1B — Update Settings (separate API; needs scanRepo, so it comes after it)
	updateSettingsRepo := reponewapi.NewUpdateSettingsRepository(dbm.DataSchema())
	updateSettingsService := svcnewapi.NewUpdateSettingsService(dbm, updateSettingsRepo, scanRepo)
	updateSettingsHandler := handlernewapi.NewUpdateSettingsHandler(updateSettingsService)



	// Endpoint 2 — Filter Options
	filterOptionsRepo := reponewapi.NewFilterOptionsRepository(dbm.DataSchema())
	filterOptionsService := svcnewapi.NewFilterOptionsService(dbm, filterOptionsRepo, scanRepo)
	filterOptionsHandler := handlernewapi.NewFilterOptionsHandler(filterOptionsService)


	// Endpoint 3 — Dashboard Overview
	dashboardOverviewRepo := reponewapi.NewDashboardOverviewRepository(dbm.DataSchema())
	dashboardOverviewService := svcnewapi.NewDashboardOverviewService(dbm, dashboardOverviewRepo, scanRepo, settingsService)
	dashboardOverviewHandler := handlernewapi.NewDashboardOverviewHandler(dashboardOverviewService)


	// Endpoint 4 — Identities List
	identitiesListRepo := reponewapi.NewIdentitiesListRepository(dbm.DataSchema())
	identitiesListService := svcnewapi.NewIdentitiesListService(dbm, identitiesListRepo, scanRepo)
	identitiesListHandler := handlernewapi.NewIdentitiesListHandler(identitiesListService)


	// Endpoint 5 — Identities Detail
	identityDetailRepo := reponewapi.NewIdentityDetailRepository(dbm.DataSchema())
	identityDetailService := svcnewapi.NewIdentityDetailService(dbm, identityDetailRepo, scanRepo)
	identityDetailHandler := handlernewapi.NewIdentityDetailHandler(identityDetailService)


	// Endpoint 6 — credentials Detail
	credentialsListRepo := reponewapi.NewCredentialsListRepository(dbm.DataSchema())
	credentialsListService := svcnewapi.NewCredentialsListService(dbm, credentialsListRepo, scanRepo)
	credentialsListHandler := handlernewapi.NewCredentialsListHandler(credentialsListService)


	// Endpoint 7 — credentials Detail
	credentialDetailRepo := reponewapi.NewCredentialDetailRepository(dbm.DataSchema())
	credentialDetailService := svcnewapi.NewCredentialDetailService(dbm, credentialDetailRepo, scanRepo) // reuse existing scanRepo
	credentialDetailHandler := handlernewapi.NewCredentialDetailHandler(credentialDetailService)




	// postures..............
	categoryRepo := repopostures.NewCategoryRepository(dbm.DataSchema())
	categoryService := svcpostures.NewCategoryService(dbm, categoryRepo, scanRepo)
	categoryHandler := handlerpostures.NewCategoryHandler(categoryService)
 
	// 5. Router
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:           authHandler,
		AuthMiddleware:        authMiddleware,
		SettingsHandler:       settingsHandler,
		UpdateSettingsHandler: updateSettingsHandler,
		FilterOptionsHandler:     filterOptionsHandler,
		DashboardOverviewHandler: dashboardOverviewHandler,
		IdentitiesListHandler: identitiesListHandler, 
		IdentityDetailHandler: identityDetailHandler,
		CredentialsListHandler: credentialsListHandler,
		CredentialDetailHandler: credentialDetailHandler,


		CategoryHandler:  categoryHandler,


	})
 
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)
 
	// 6. Server Setup
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}
 
	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}