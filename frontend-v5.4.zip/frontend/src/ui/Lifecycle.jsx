import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { formatDate, formatDateTime, parseDate } from '../lib/format';
import { EASE_OUT } from '../lib/motion';
import { TONE_FG, TONE_VAR, cn } from './cn';

const DAY = 86_400_000;
/* Width a marker label needs, in px, before the next one in its row may start. */
const LABEL_PX = 120;

/**
 * A record's life as swimlanes on one time axis (a Gantt view of its
 * lifecycle), with the durations that matter read out above it.
 *
 *   Age 207 days | Unseen for 100 days | Idle for 78 days | Expires never
 *   ──────────────────────────────────────────────────────────────────────
 *   Scanner view  [////// unseen //////][ watched by the scanner ......]|
 *   Usage         [ in use ...........................][ idle ........]|
 *                 ◆ Created      ◆ First discovered   ◆ Last used    Today
 *
 * A plain dot timeline only places dates; the lanes show the *periods*
 * between them - how long it existed before anyone could see it, how long it
 * has sat unused, how long it has left - which is what a reviewer weighs
 * before disabling or renewing it.
 *
 * stats:  [{ key, label, value, sub?, tone? }]
 * lanes:  [{ key, label, segments: [{ key, from, to, label, tone, hatch? }] }]
 *         `from`/`to` are dates or 'now'
 * events: [{ key, label, at, tone? }]  dated markers on the axis; undated
 *         ones are listed as "not recorded" rather than guessed
 */
export function Lifecycle({ stats = [], lanes = [], events = [], now }) {
  const areaRef = useRef(null);
  const [width, setWidth] = useState(720);
  const [focus, setFocus] = useState(null);
  useEffect(() => {
    const node = areaRef.current;
    if (!node || typeof ResizeObserver === 'undefined') return undefined;
    const observer = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width || 720));
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const toTime = (value) => (value === 'now' ? now : parseDate(value)?.getTime());
  const dated = events.map((event) => ({ ...event, time: toTime(event.at) })).filter((event) => Number.isFinite(event.time));
  const missing = events.filter((event) => !Number.isFinite(toTime(event.at)));
  const segmentTimes = lanes.flatMap((lane) => lane.segments.flatMap((segment) => [toTime(segment.from), toTime(segment.to)])).filter(Number.isFinite);
  const times = [...dated.map((event) => event.time), ...segmentTimes, now];
  const min = Math.min(...times);
  const max = Math.max(...times);
  const span = Math.max(max - min, DAY);
  const pad = span * 0.025;
  const x = (time) => ((time - (min - pad)) / (span + pad * 2)) * 100;
  const pxPerPct = width / 100;

  const markers = [...dated, { key: 'today', label: 'Today', time: now, today: true }].sort((a, b) => a.time - b.time);
  const rows = [];
  const labelPct = (LABEL_PX / Math.max(width, 200)) * 100;
  const placed = markers.map((event) => {
    const left = x(event.time);
    const shift = left > 86 ? 1 : left < 14 ? 0 : 0.5;
    const start = left - labelPct * shift;
    let row = rows.findIndex((lastEnd) => start > lastEnd + 0.5);
    if (row === -1) {
      rows.push(start + labelPct);
      row = rows.length - 1;
    } else rows[row] = start + labelPct;
    return { ...event, left, row, shift };
  });

  const ticks = monthTicks(min - pad, max + pad, width);
  const readout = focus ?? null;

  return (
    <div className="flex flex-col gap-4">
      {stats.length > 0 && (
        <dl className="grid grid-cols-2 overflow-hidden rounded-[var(--radius-control)] border border-line bg-surface-2/60 @min-[40rem]:grid-cols-4">
          {stats.map((stat, index) => (
            <div
              key={stat.key}
              className={cn(
                'min-w-0 px-3.5 py-2.5',
                index % 2 === 1 && 'border-l border-line',
                index >= 2 && 'border-t border-line @min-[40rem]:border-t-0',
                index >= 1 && '@min-[40rem]:border-l',
              )}
            >
              <dt className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{stat.label}</dt>
              <dd className={cn('mt-1 truncate font-display text-[17px] leading-tight font-bold', stat.tone ? TONE_FG[stat.tone] : 'text-ink')} data-numeric="">
                {stat.value}
              </dd>
              {stat.sub && <dd className="mt-0.5 truncate text-[11.5px] text-ink-3">{stat.sub}</dd>}
            </div>
          ))}
        </dl>
      )}

      <p className="h-4 text-[12px] text-ink-3" aria-live="polite">
        {readout ? (
          <>
            <span className={cn('font-semibold', readout.tone ? TONE_FG[readout.tone] : 'text-ink-2')}>{readout.label}</span>
            <span> · {readout.range}</span>
            {readout.length && <span className="font-medium text-ink-2"> · {readout.length}</span>}
          </>
        ) : (
          'Point at a period or a date for the details.'
        )}
      </p>

      <div className="grid grid-cols-1 gap-x-4 gap-y-2 @min-[36rem]:grid-cols-[7.5rem_minmax(0,1fr)]">
        {lanes.map((lane, laneIndex) => (
          <Lane
            key={lane.key}
            lane={lane}
            laneIndex={laneIndex}
            toTime={toTime}
            x={x}
            pxPerPct={pxPerPct}
            now={now}
            onFocus={setFocus}
          />
        ))}

        {/* The shared axis: month ticks, then the dated markers. */}
        <div aria-hidden="true" className="hidden @min-[36rem]:block" />
        <div ref={areaRef} className="relative hidden @min-[36rem]:block" style={{ height: `${46 + rows.length * 38}px` }}>
          <div className="absolute inset-x-0 top-0 h-px bg-line" />
          {ticks.map((tick) => (
            <span key={tick.time} className="absolute top-0 flex -translate-x-1/2 flex-col items-center" style={{ left: `${x(tick.time)}%` }}>
              <span className="h-1.5 w-px bg-line-strong" />
              <span className="mt-0.5 text-[10px] whitespace-nowrap text-ink-3/80">{tick.label}</span>
            </span>
          ))}
          {placed.map((event, index) => (
            <div key={event.key} className="absolute top-[22px]" style={{ left: `${event.left}%` }}>
              <motion.span
                aria-hidden="true"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', visualDuration: 0.35, bounce: 0.35, delay: 0.5 + index * 0.06 }}
                className={cn(
                  'absolute top-0 -ml-[5px] block size-[10px] rotate-45 rounded-[2px] border-2 border-surface',
                  event.today && 'size-[12px] -ml-[6px] rounded-full ring-2 ring-ink/60',
                )}
                style={{ background: event.today ? 'var(--t-ink)' : TONE_VAR[event.tone] ?? 'var(--t-brand)' }}
              />
              <span aria-hidden="true" className="absolute top-[10px] w-px bg-line" style={{ height: `${6 + event.row * 38}px` }} />
              <button
                type="button"
                onMouseEnter={() => setFocus({ label: event.label, range: formatDateTime(new Date(event.time)), length: event.today ? null : `${spanText(now - event.time)} ago`, tone: event.tone })}
                onMouseLeave={() => setFocus(null)}
                onFocus={() => setFocus({ label: event.label, range: formatDateTime(new Date(event.time)), length: event.today ? null : `${spanText(now - event.time)} ago`, tone: event.tone })}
                onBlur={() => setFocus(null)}
                className={cn(
                  'absolute w-max max-w-[8rem] rounded px-0.5 text-center focus-visible:outline-2 focus-visible:outline-brand',
                  event.shift === 0.5 && '-translate-x-1/2',
                  event.shift === 1 && '-translate-x-full text-right',
                  event.shift === 0 && 'text-left',
                )}
                style={{ top: `${16 + event.row * 38}px` }}
              >
                <span className={cn('block text-[11.5px] leading-tight font-semibold', event.today ? 'text-ink' : 'text-ink-2')}>{event.label}</span>
                <span className="block text-[11px] leading-tight text-ink-3">{formatDate(new Date(event.time))}</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Narrow layout: the dated markers as a list, with the time between them. */}
      <ol className="flex flex-col @min-[36rem]:hidden">
        {markers.map((event, index) => (
          <li key={event.key} className="relative flex gap-3 pb-3 last:pb-0">
            <span className="relative flex flex-col items-center">
              <span
                aria-hidden="true"
                className="mt-1 size-2.5 shrink-0 rotate-45 rounded-[2px]"
                style={{ background: event.today ? 'var(--t-ink)' : TONE_VAR[event.tone] ?? 'var(--t-brand)' }}
              />
              {index < markers.length - 1 && <span aria-hidden="true" className="mt-1 w-px flex-1 bg-line" />}
            </span>
            <span className="min-w-0">
              <span className="block text-[13px] font-medium text-ink">{event.label}</span>
              <span className="block text-[12px] text-ink-3">{formatDate(new Date(event.time))}</span>
              {index < markers.length - 1 && markers[index + 1].time - event.time >= DAY && (
                <span className="mt-1 block text-[11.5px] text-ink-3 italic">{spanText(markers[index + 1].time - event.time)} later</span>
              )}
            </span>
          </li>
        ))}
      </ol>

      {missing.length > 0 && (
        <p className="text-[12px] text-ink-3">Not recorded: {missing.map((event) => event.label.toLowerCase()).join(', ')}.</p>
      )}
    </div>
  );
}

function Lane({ lane, laneIndex, toTime, x, pxPerPct, now, onFocus }) {
  return (
    <>
      <div className="flex items-center text-[11.5px] font-semibold text-ink-2 @min-[36rem]:justify-end @min-[36rem]:text-right">{lane.label}</div>
      <div className="relative h-7 rounded-md bg-surface-2">
        {/* Today, through every lane. */}
        <span aria-hidden="true" className="absolute -top-1 -bottom-1 z-[1] w-px bg-ink/50" style={{ left: `${x(now)}%` }} />
        {lane.segments.map((segment, index) => {
          const from = toTime(segment.from);
          const to = toTime(segment.to);
          if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from) return null;
          const left = x(from);
          const widthPct = Math.max(0.6, x(to) - left);
          const color = TONE_VAR[segment.tone] ?? 'var(--t-brand)';
          const length = spanText(to - from);
          const text = `${segment.label} · ${length}`;
          const fits = widthPct * pxPerPct > text.length * 7 + 20;
          const info = {
            label: segment.label,
            range: `${formatDate(new Date(from))} - ${to === now ? 'today' : formatDate(new Date(to))}`,
            length,
            tone: segment.tone,
          };
          return (
            <motion.button
              type="button"
              key={segment.key}
              aria-label={`${lane.label}: ${segment.label}, ${info.range}, ${length}`}
              onMouseEnter={() => onFocus(info)}
              onMouseLeave={() => onFocus(null)}
              onFocus={() => onFocus(info)}
              onBlur={() => onFocus(null)}
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: 1, opacity: 1 }}
              transition={{ duration: 0.7, ease: EASE_OUT, delay: 0.1 + laneIndex * 0.12 + index * 0.1 }}
              className="absolute inset-y-1 flex items-center overflow-hidden rounded-[5px] px-2 text-left transition-[filter] hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand"
              style={{
                left: `${left}%`,
                width: `${widthPct}%`,
                transformOrigin: 'left',
                background: segment.hatch
                  ? `repeating-linear-gradient(135deg, color-mix(in srgb, ${color} 30%, transparent) 0 5px, color-mix(in srgb, ${color} 12%, transparent) 5px 10px)`
                  : `color-mix(in srgb, ${color} 85%, transparent)`,
                border: segment.hatch ? `1px dashed color-mix(in srgb, ${color} 55%, transparent)` : undefined,
              }}
            >
              {fits && (
                <span className={cn('truncate text-[11px] font-semibold whitespace-nowrap', segment.hatch ? 'text-ink-2' : 'text-[var(--t-surface)]')}>{text}</span>
              )}
            </motion.button>
          );
        })}
      </div>
    </>
  );
}

/** "78 days", "4 months", "1.6 years": precise while short, rounder as it grows. */
export function spanText(ms) {
  const days = Math.max(0, Math.round(ms / DAY));
  if (days < 1) return 'under a day';
  if (days < 120) return `${days} day${days === 1 ? '' : 's'}`;
  if (days < 730) return `${Math.round(days / 30.44)} months`;
  return `${(days / 365.25).toFixed(1)} years`;
}

/** Month (or quarter, or year) starts across the axis, spaced to stay legible. */
function monthTicks(from, to, width) {
  const months = (to - from) / (30.44 * DAY);
  const room = Math.max(1, Math.floor(width / 64));
  const step = [1, 2, 3, 6, 12, 24].find((n) => months / n <= room) ?? 24;
  const start = new Date(from);
  start.setDate(1);
  start.setHours(0, 0, 0, 0);
  start.setMonth(start.getMonth() + 1);
  while (start.getMonth() % step !== 0 && step <= 12) start.setMonth(start.getMonth() + 1);
  const ticks = [];
  for (const date = new Date(start); date.getTime() <= to; date.setMonth(date.getMonth() + step)) {
    ticks.push({
      time: date.getTime(),
      label:
        step >= 12 || date.getMonth() === 0
          ? date.toLocaleDateString(undefined, { month: 'short', year: 'numeric' })
          : date.toLocaleDateString(undefined, { month: 'short' }),
    });
  }
  return ticks;
}

/**
 * What the scanner could see: the period between creation and first
 * discovery (when the record existed but nobody was watching it), then the
 * period it has been watched. A last confirmation well before today becomes
 * its own "not confirmed since" period rather than being drawn as watched.
 */
export function scannerSegments(created, found, confirmed, now) {
  const segments = [];
  if (created && found && found > created) {
    segments.push({ key: 'unseen', from: created.toISOString(), to: found.toISOString(), label: 'Before discovery', tone: 'neutral', hatch: true });
  }
  if (found) {
    const stale = confirmed && now - confirmed.getTime() > 2 * DAY && confirmed > found;
    segments.push({ key: 'watched', from: found.toISOString(), to: stale ? confirmed.toISOString() : 'now', label: 'Watched', tone: 'brand' });
    if (stale) segments.push({ key: 'unconfirmed', from: confirmed.toISOString(), to: 'now', label: 'Not confirmed since', tone: 'medium', hatch: true });
  }
  return segments;
}

/** How long the record existed before the scanner first saw it. */
export function unseenStat(created, found) {
  if (!created || !found) return { key: 'unseen', label: 'Unseen for', value: 'Unknown', sub: 'Needs both creation and discovery dates' };
  const lag = found.getTime() - created.getTime();
  if (lag <= DAY) return { key: 'unseen', label: 'Unseen for', value: 'Under a day', sub: `Found ${formatDate(found)}`, tone: 'low' };
  return {
    key: 'unseen',
    label: 'Unseen for',
    value: spanText(lag),
    sub: `Before discovery on ${formatDate(found)}`,
    tone: lag > 30 * DAY ? 'medium' : undefined,
  };
}
