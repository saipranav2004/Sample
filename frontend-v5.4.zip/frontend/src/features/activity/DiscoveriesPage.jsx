import { useMemo, useRef } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Building2, CalendarClock, History, List, Minus, Plus, TrendingUp } from 'lucide-react';
import { fetchRecentDiscoveries } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelativeShort, parseDate, percentValue } from '../../lib/format';
import { Page, Reveal } from '../../lib/motion';
import { credentialBadge, identityBadge, regionLabel, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { ChangeColumns, bucketEvents } from '../../charts/ChangeColumns';
import { Select } from '../../ui/Field';
import { Panel, PanelHeader } from '../../ui/Panel';
import { DataGrid } from '../../ui/DataGrid';
import { Pagination } from '../../ui/Pagination';
import { MetricTile } from '../../ui/Stat';
import { Tag } from '../../ui/Tag';
import { TypeBadge } from '../../ui/TypeBadge';
import { ListSkeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { RefreshButton, TableToolbar } from '../../ui/TableTools';
import { RecordBar } from '../../ui/WorkArea';
import { cn } from '../../ui/cn';

const WINDOWS = [
  { value: '24', label: '24h', title: 'Last 24 hours', phrase: 'in the last 24 hours' },
  { value: '168', label: '7d', title: 'Last 7 days', phrase: 'in the last 7 days' },
  { value: '720', label: '30d', title: 'Last 30 days', phrase: 'in the last 30 days' },
  { value: '2160', label: '90d', title: 'Last 90 days', phrase: 'in the last 90 days' },
];
const TYPES = [
  { value: 'both', label: 'Everything' },
  { value: 'identities', label: 'Identities' },
  { value: 'credentials', label: 'Credentials' },
];
const CHANGES = [
  { value: 'both', label: 'All changes' },
  { value: 'new', label: 'Discovered' },
  { value: 'removed', label: 'Removed' },
];
const VIEWS = [
  { value: 'table', label: 'Table', icon: List },
  { value: 'timeline', label: 'Timeline', icon: CalendarClock },
];
const LIMITS = [100, 250, 500];
const PAGE_SIZES = [25, 50, 100];
const DEFAULTS = { hours: '168', type: 'both', event: 'both', limit: '250', view: 'table', page: '1', page_size: '25' };

/**
 * What the scanner added and removed: GET /api/v1/dashboard/recent-discoveries.
 *
 * Laid out like the reference console's activity screen: headline tiles, the
 * shape of the window, then the events as a table or a timeline. The API
 * gives totals for the whole window but returns at most `limit` events (500
 * at most) with no paging, so the chart, the breakdowns and the pages below
 * are worked out from the loaded events - and every one of them says so.
 *
 * Events carry no record id: a discovered one links to its list filtered by
 * ARN, a removed one (no longer listed anywhere) does not link.
 */
export default function DiscoveriesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const pick = (key, allowed) => (allowed.includes(searchParams.get(key)) ? searchParams.get(key) : DEFAULTS[key]);
  const hours = pick('hours', WINDOWS.map((entry) => entry.value));
  const type = pick('type', TYPES.map((entry) => entry.value));
  const event = pick('event', CHANGES.map((entry) => entry.value));
  const view = pick('view', VIEWS.map((entry) => entry.value));
  const limit = Number(pick('limit', LIMITS.map(String)));
  const pageSize = Number(pick('page_size', PAGE_SIZES.map(String)));
  const page = Math.max(1, Number(searchParams.get('page')) || 1);
  const tableTop = useRef(null);

  const update = (changes) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (String(value) === DEFAULTS[key]) next.delete(key);
      else next.set(key, String(value));
    }
    /* Anything that changes the result set starts again at page one. */
    if (!('page' in changes)) next.delete('page');
    setSearchParams(next, { replace: true });
  };

  const query = useQuery(
    (signal) => fetchRecentDiscoveries({ hours, type, event, limit }, signal),
    [hours, type, event, limit],
  );
  const data = query.data;
  const items = useMemo(() => data?.discoveries ?? [], [data]);
  const totalNew = data?.total_new ?? null;
  const totalRemoved = data?.total_removed ?? null;
  const expected = event === 'new' ? totalNew : event === 'removed' ? totalRemoved : (totalNew ?? 0) + (totalRemoved ?? 0);
  const truncated = Boolean(data) && items.length < expected;
  const windowMeta = WINDOWS.find((entry) => entry.value === hours);
  const loading = !data && !query.isError;

  const shape = useMemo(() => summarise(items, Number(hours)), [items, hours]);
  const pageRows = items.slice((page - 1) * pageSize, page * pageSize);
  const net = totalNew !== null && totalRemoved !== null ? totalNew - totalRemoved : null;
  const scopeWord = type === 'identities' ? 'identities' : type === 'credentials' ? 'credentials' : 'records';

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Discovery activity"
          lede="What the scanner found for the first time, and what has gone from AWS since. Choose a window; everything on this page follows it."
          actions={
            <>
              <SegmentedControl label="Time window" value={hours} onChange={(value) => update({ hours: value })} options={WINDOWS} />
              <RefreshButton onRefresh={query.refetch} refreshing={query.isRefreshing} label="Refresh activity" />
            </>
          }
        />
      </Reveal>

      <Reveal className="grid grid-cols-2 gap-3 @min-[60rem]:grid-cols-4">
        <MetricTile
          as="button"
          type="button"
          aria-pressed={event === 'new'}
          onClick={() => update({ event: event === 'new' ? 'both' : 'new' })}
          label="Discovered"
          value={totalNew}
          tone="low"
          icon={Plus}
          caption={`New ${scopeWord} ${windowMeta.phrase}`}
          className={cn(event === 'new' && 'ring-2 ring-low/30')}
        />
        <MetricTile
          as="button"
          type="button"
          aria-pressed={event === 'removed'}
          onClick={() => update({ event: event === 'removed' ? 'both' : 'removed' })}
          label="Removed"
          value={totalRemoved}
          tone="neutral"
          icon={Minus}
          caption={`Gone from AWS ${windowMeta.phrase}`}
          className={cn(event === 'removed' && 'ring-2 ring-ink-3/25')}
        />
        <MetricTile
          label="Net change"
          value={net === null ? null : Math.abs(net)}
          unit={net === null ? undefined : net > 0 ? 'more' : net < 0 ? 'fewer' : 'change'}
          tone={net > 0 ? 'brand' : 'neutral'}
          icon={TrendingUp}
          caption={net === null ? 'Waiting for totals' : `${scopeWord[0].toUpperCase()}${scopeWord.slice(1)} than at the start of the window`}
        />
        <MetricTile
          label="Accounts with changes"
          value={data ? shape.accounts.length : null}
          tone="info"
          icon={Building2}
          caption={shape.accounts[0] ? `Most changes: ${shape.accounts[0][0]}` : 'No changes loaded'}
          meter={data && shape.accounts[0] ? percentValue(shape.accounts[0][1], items.length) : undefined}
          meterLabel="Share of loaded events in the busiest account"
        />
      </Reveal>

      <Reveal>
        <Panel>
          <PanelHeader
            title="When the estate changed"
            subtitle={
              !data
                ? 'Loading events…'
                : truncated
                  ? `Worked out from the newest ${formatNumber(items.length)} of ${formatNumber(expected)} events; load more below to see further back.`
                  : `Worked out from all ${formatNumber(items.length)} events ${windowMeta.phrase}, one column per ${shape.unit}.`
            }
          />
          {!data ? (
            <div className="mt-4 h-[180px] animate-pulse rounded-[var(--radius-control)] bg-surface-2" />
          ) : items.length === 0 ? (
            <p className="mt-3 text-[12.5px] text-ink-3">Nothing changed {windowMeta.phrase}.</p>
          ) : (
            <div className="mt-4 grid gap-6 @min-[56rem]:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)]">
              <ChangeColumns
                height={172}
                buckets={shape.buckets}
                ariaLabel={`Discovered and removed records per ${shape.unit}`}
                tickEvery={Math.ceil(shape.buckets.length / 8)}
              />
              <div className="grid content-start gap-5 @min-[30rem]:grid-cols-2 @min-[56rem]:grid-cols-1">
                <TopList title="Busiest accounts" rows={shape.accounts.slice(0, 4)} total={items.length} mono />
                <TopList title="Most common types" rows={shape.types.slice(0, 4)} total={items.length} />
              </div>
            </div>
          )}
        </Panel>
      </Reveal>

      <Reveal>
        <Panel flush className="overflow-hidden">
          <div ref={tableTop} className="scroll-mt-20" />
          <RecordBar
            trailing={
              <TableToolbar>
                <SegmentedControl label="View mode" options={VIEWS} value={view} onChange={(value) => update({ view: value, page: String(page) })} />
              </TableToolbar>
            }
          >
            <SegmentedControl label="Record kind" value={type} onChange={(value) => update({ type: value })} options={TYPES} />
            <SegmentedControl label="Change" value={event} onChange={(value) => update({ event: value })} options={CHANGES} />
            <span className="text-[12.5px] text-ink-3" aria-live="polite" data-numeric="">
              {!data ? (
                'Loading…'
              ) : (
                <>
                  <span className="font-semibold text-ink">{formatNumber(items.length)}</span>
                  {truncated ? <> of {formatNumber(expected)}</> : null} events
                </>
              )}
            </span>
          </RecordBar>

          {query.isError && !data ? (
            <ErrorState error={query.error} onRetry={query.refetch} />
          ) : loading ? (
            <div className="p-4">
              <ListSkeleton rows={8} />
            </div>
          ) : items.length === 0 ? (
            <EmptyState
              icon={History}
              title={`No changes ${windowMeta.phrase}`}
              description="Nothing was discovered or removed in this window. Choose a longer window to look further back."
            />
          ) : (
            <>
              {query.isError && (
                <div className="p-3">
                  <InlineError error={query.error} onRetry={query.refetch} label="Could not refresh" />
                </div>
              )}
              {view === 'timeline' ? <Timeline items={pageRows} /> : <EventTable rows={pageRows} />}
              <Pagination
                page={page}
                pageSize={pageSize}
                total={items.length}
                unit="events"
                pageSizes={PAGE_SIZES}
                scrollTarget={tableTop}
                onPageChange={(next) => update({ page: String(next) })}
                onPageSizeChange={(size) => update({ page_size: String(size) })}
              />
              {truncated && (
                <div className="flex flex-wrap items-center justify-center gap-2 border-t border-line px-4 py-2.5 text-[12.5px] text-ink-3">
                  The API returns the newest events only.
                  <label className="inline-flex items-center gap-2">
                    Load up to
                    <Select
                      size="sm"
                      value={String(limit)}
                      onChange={(changeEvent) => update({ limit: changeEvent.target.value })}
                      options={LIMITS.map((n) => ({ value: String(n), label: String(n) }))}
                      className="w-20"
                      aria-label="Most events to load"
                    />
                    events
                  </label>
                </div>
              )}
            </>
          )}
        </Panel>
      </Reveal>
    </Page>
  );
}

function summarise(items, hours) {
  const count = (pickValue) =>
    Object.entries(
      items.reduce((acc, item) => {
        const value = pickValue(item);
        if (value) acc[value] = (acc[value] ?? 0) + 1;
        return acc;
      }, {}),
    ).sort((a, b) => b[1] - a[1]);
  const { buckets, unit } = bucketEvents(items, hours);
  return {
    buckets,
    unit,
    accounts: count((item) => item.account_id),
    types: count((item) => (item.type ? tokenLabel(item.type) : null)),
  };
}

function badgeFor(item) {
  if (item.entity === 'identity') return { code: identityBadge(item.type), color: 'var(--t-brand)' };
  return credentialBadge(item.type);
}

function recordLink(item) {
  if (item.event !== 'new' || !item.arn) return null;
  return `/${item.entity === 'identity' ? 'identities' : 'credentials'}?search=${encodeURIComponent(item.arn)}`;
}

/** The events as a table: what it is, what happened, where, and when. */
function EventTable({ rows }) {
  return (
    <DataGrid
      caption="Discovery events"
      density="compact"
      rows={rows}
      rowKey={(row, index) => `${row.event}-${row.entity}-${row.arn}-${index}`}
      columns={[
        {
          key: 'record',
          header: 'Record',
          primary: true,
          width: '34%',
          cell: (row) => {
            const badge = badgeFor(row);
            const to = recordLink(row);
            const name = row.name || row.arn || 'Unnamed';
            return (
              <span className="flex min-w-0 items-center gap-2.5">
                <TypeBadge code={badge.code} color={badge.color} className={cn(row.event !== 'new' && 'opacity-60 grayscale')} />
                <span className="min-w-0">
                  {to ? (
                    <Link to={to} className="block truncate text-[13px] font-semibold text-ink hover:text-brand hover:underline" title={`Find ${name} in the inventory`}>
                      {name}
                    </Link>
                  ) : (
                    <span className="block truncate text-[13px] font-semibold text-ink-2" title={name}>
                      {name}
                    </span>
                  )}
                  <span className="block truncate text-[11.5px] text-ink-3">{tokenLabel(row.type)}</span>
                </span>
              </span>
            );
          },
        },
        {
          key: 'change',
          header: 'Change',
          width: 120,
          mobile: true,
          cell: (row) =>
            row.event === 'new' ? (
              <Tag size="sm" tone="low" icon={Plus}>
                Discovered
              </Tag>
            ) : (
              <Tag size="sm" tone="neutral" icon={Minus}>
                Removed
              </Tag>
            ),
        },
        {
          key: 'kind',
          header: 'Kind',
          width: 110,
          cell: (row) => (
            <Tag size="sm" tone={row.entity === 'identity' ? 'brand' : 'info'}>
              {row.entity === 'identity' ? 'Identity' : 'Credential'}
            </Tag>
          ),
        },
        {
          key: 'account',
          header: 'Account',
          width: 140,
          cell: (row) => <span className="font-mono text-[12px] text-ink-2">{row.account_id || '-'}</span>,
        },
        {
          key: 'region',
          header: 'Region',
          width: 130,
          priority: 'wide',
          cell: (row) => <span className="text-[12.5px] text-ink-2">{regionLabel(row.region)}</span>,
        },
        {
          key: 'when',
          header: 'When',
          width: 110,
          mobile: true,
          cell: (row) => (
            <time dateTime={row.discovered_at} title={formatDateTime(row.discovered_at)} className="text-[12.5px] whitespace-nowrap text-ink-2">
              {formatRelativeShort(row.discovered_at)}
            </time>
          ),
        },
      ]}
    />
  );
}

/** The same events on a time rail, grouped by day (reference timeline view). */
function Timeline({ items }) {
  const groups = [];
  for (const item of items) {
    const label = dayLabel(item.discovered_at);
    const last = groups.at(-1);
    if (last && last.label === label) last.items.push(item);
    else groups.push({ label, items: [item] });
  }
  return (
    <div className="px-3 py-3 sm:px-5">
      {groups.map((group) => (
        <section key={group.label} aria-label={group.label} className="pb-2">
          <h3 className="sticky top-0 z-[2] flex items-center gap-2 bg-surface py-2 text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
            <CalendarClock aria-hidden="true" className="size-3.5" />
            {group.label}
            <span className="font-medium tracking-normal normal-case">· {formatNumber(group.items.length)}</span>
          </h3>
          <ol className="relative">
            {/* One rail for the day, running behind the badges, which carry
                their own fill; the clock time sits to its left. */}
            <span aria-hidden="true" className="absolute top-4 bottom-4 left-[calc(4.25rem+29px)] w-0.5 rounded-full bg-line" />
            {group.items.map((item, index) => (
              <TimelineRow key={`${item.event}-${item.arn}-${index}`} item={item} />
            ))}
          </ol>
        </section>
      ))}
    </div>
  );
}

function TimelineRow({ item }) {
  const to = recordLink(item);
  const isNew = item.event === 'new';
  const identity = item.entity === 'identity';
  const badge = badgeFor(item);
  const name = item.name || item.arn || 'Unnamed';
  const body = (
    <>
      <time
        dateTime={item.discovered_at}
        title={formatDateTime(item.discovered_at)}
        className="w-[4.25rem] shrink-0 pt-2 text-right text-[11.5px] text-ink-3"
        data-numeric=""
      >
        {clockTime(item.discovered_at)}
      </time>
      <span className="relative z-[1] shrink-0 rounded-[9px] bg-surface p-0.5">
        <TypeBadge code={badge.code} color={badge.color} className={cn(!isNew && 'opacity-60 grayscale')} />
        <span
          aria-hidden="true"
          className={cn('absolute -right-0.5 -bottom-0.5 grid size-4 place-items-center rounded-full border-2 border-surface text-white', isNew ? 'bg-low' : 'bg-ink-3')}
        >
          {isNew ? <Plus className="size-2.5" strokeWidth={3} /> : <Minus className="size-2.5" strokeWidth={3} />}
        </span>
      </span>
      <span className="min-w-0 flex-1 pt-0.5">
        <span className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1">
          <span className={cn('truncate text-[13px] font-semibold', isNew ? 'text-ink' : 'text-ink-2')}>{name}</span>
          <span className={cn('text-[11.5px] font-medium', isNew ? 'text-low' : 'text-ink-3')}>{isNew ? 'discovered' : 'removed'}</span>
        </span>
        <span className="mt-0.5 block truncate text-[11.5px] text-ink-3">
          {[identity ? 'Identity' : 'Credential', tokenLabel(item.type), item.account_id, regionLabel(item.region)].filter((part) => part && part !== '-').join(' · ')}
        </span>
      </span>
    </>
  );
  const rowClass = 'flex items-start gap-3 rounded-md py-1.5 pr-2';
  return (
    <li className="relative">
      {to ? (
        <Link to={to} className={cn(rowClass, 'transition-colors hover:bg-surface-2')} title="Find this record in the inventory">
          {body}
        </Link>
      ) : (
        <div className={rowClass}>{body}</div>
      )}
    </li>
  );
}

function clockTime(value) {
  const date = parseDate(value);
  return date ? date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }) : '-';
}

function dayLabel(value) {
  const date = parseDate(value);
  if (!date) return 'Unknown date';
  const start = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diff = Math.round((start(new Date()) - start(date)) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  return date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: date.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
}

function TopList({ title, rows, total, mono }) {
  const max = Math.max(1, ...rows.map(([, n]) => n));
  return (
    <div className="min-w-0">
      <p className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{title}</p>
      <ul className="mt-2 flex flex-col gap-2">
        {rows.map(([label, count]) => (
          <li key={label} className="grid grid-cols-[minmax(0,1fr)_5.5rem_2rem] items-center gap-3 text-[12px]">
            <span className={cn('min-w-0 truncate text-ink-2', mono && 'font-mono text-[11.5px]')} title={label}>
              {label}
            </span>
            <span className="h-1.5 overflow-hidden rounded-full bg-[var(--t-track)]" title={`${percentValue(count, total)}% of loaded events`}>
              <span className="block h-full rounded-full bg-[var(--t-ramp-4)] transition-[width] duration-700" style={{ width: `${(count / max) * 100}%` }} />
            </span>
            <span data-numeric="" className="text-right font-semibold text-ink">
              {formatNumber(count)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
