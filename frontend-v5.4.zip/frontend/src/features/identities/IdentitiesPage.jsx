import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Copy, Download, FileJson, Fingerprint, Globe2, LayoutGrid, Moon, Rows3, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import {
  fetchDormantIdentities,
  fetchIdentities,
  fetchIdentitiesByAccount,
  fetchIdentitiesByRegion,
  fetchIdentityCounts,
} from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { useExport } from '../../lib/useExport';
import { Page, Reveal } from '../../lib/motion';
import { SegmentedControl, Tabs } from '../../ui/Tabs';
import { DormantView } from './DormantView';
import { GroupedByClass } from './GroupedByClass';
import { formatNumber } from '../../lib/format';
import { classColor, functionalClassLabel, identityBadge, identityTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { StatusText, Tag } from '../../ui/Tag';
import { Freshness } from '../../ui/Freshness';
import { TypeBadge } from '../../ui/TypeBadge';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { FILTER_KEYS, PAGE_SIZES, appliedCount, readListState, toApiFilters } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const FILTER_LABELS = {
  search: 'Search',
  identity_type: 'Type',
  functional_class: 'Class',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  owner: 'Owner',
  environment: 'Environment',
  is_public: 'Public',
  last_active_before: 'Inactive for',
  last_active_custom: 'Last active before a date',
};

/**
 * Identity inventory: `GET /api/v1/inventory/identities`, filtered, sorted and
 * paged on the server. All state lives in the URL, so a dashboard drill-down,
 * a bookmark and a shared link resolve to the same list.
 */
export default function IdentitiesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const { railOpen, toggleRail } = useFacetRail();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => readDensity());

  /* Apply URL changes: every filter change returns to page one. */
  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next, { replace: false });
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  /* Back/forward or a link can change the search in the URL underneath. */
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const apiFilters = toApiFilters(filters);
  const listKey = JSON.stringify([apiFilters, page, limit, sort]);
  const list = useQuery(
    (signal) =>
      fetchIdentities({ ...apiFilters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
    { enabled: searchParams.get('view') !== 'dormant' },
  );
  const counts = useQuery((signal) => fetchIdentityCounts({}, signal), []);
  const accounts = useQuery((signal) => fetchIdentitiesByAccount({}, signal), []);
  const regions = useQuery((signal) => fetchIdentitiesByRegion({}, signal), []);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  /* A page past the end (rows removed since the link was made) goes back to
     the last page that exists rather than showing an empty table. */
  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const facetGroups = useFacetGroups({ filters, counts: counts.data, accounts: accounts.data, regions: regions.data, update });

  const chips = FILTER_KEYS.filter((key) => filters[key]).map((key) => ({
    key,
    label: FILTER_LABELS[key],
    value: describeValue(key, filters[key]),
  }));

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('identities');
  const exporting = exporter.exporting;
  /* Export takes the list filters; page and limit are left off so the file
     holds every match, not the page on screen. */
  const onExport = (format) => exporter.run(format, { ...apiFilters, sort_by: sort.key, sort_order: sort.direction });
  const view = searchParams.get('view') === 'class' ? 'class' : 'table';

  /* View tabs: the inventory, and the two conditions people act on. */
  const pageView = searchParams.get('view') === 'dormant' ? 'dormant' : filters.is_public === 'true' && !searchParams.get('view') ? 'exposed' : 'all';
  const dormantDays = (() => {
    const n = Number(searchParams.get('days'));
    return pageView === 'dormant' && [30, 60, 90, 180, 365].includes(n) ? n : 90;
  })();
  const exposedCount = useQuery((signal) => fetchIdentities({ is_public: 'true', limit: 1 }, signal), []);
  const dormantCount = useQuery((signal) => fetchDormantIdentities({ days: dormantDays, limit: 1 }, signal), [dormantDays]);
  const viewTabs = [
    { value: 'all', label: 'All identities', icon: Fingerprint, count: counts.data ? formatNumber(counts.data.total) : undefined },
    { value: 'exposed', label: 'Internet-exposed', icon: Globe2, count: exposedCount.data ? formatNumber(exposedCount.data.total) : undefined },
    { value: 'dormant', label: `Dormant ${dormantDays}+ days`, icon: Moon, count: dormantCount.data ? formatNumber(dormantCount.data.total_dormant) : undefined },
  ];
  const setPageView = (next) => {
    setSearchDraft('');
    setSearchParams(next === 'dormant' ? { view: 'dormant' } : next === 'exposed' ? { is_public: 'true' } : {});
  };

  const columns = [
    {
      key: 'name',
      header: 'Identity',
      primary: true,
      sortable: true,
      width: '23%',
      cell: (row) => (
        <span className="flex min-w-0 items-center gap-3">
          <TypeBadge code={identityBadge(row.identity_type)} color={classColor(row.functional_class)} />
          <span className="min-w-0">
            <span className="block truncate text-[13px] font-semibold text-ink" title={row.name || row.arn}>
              {row.name || row.arn}
            </span>
            <span className="block truncate text-[11px] text-ink-3">
              {identityTypeLabel(row.identity_type)} · {regionLabel(row.region)}
            </span>
          </span>
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => {
        const meta = statusMeta(row.status);
        return (
          <span className="inline-flex max-w-full flex-wrap items-center gap-x-2 gap-y-1">
            <StatusText tone={meta.tone}>{meta.label}</StatusText>
            {row.is_publicly_accessible === true && (
              <Tag size="sm" tone="critical" icon={Globe2}>
                Public
              </Tag>
            )}
          </span>
        );
      },
    },
    {
      key: 'functional_class',
      header: 'Class',
      sortable: true,
      width: '132px',
      priority: 'wide',
      cell: (row) => (
        <span className="flex min-w-0 items-center gap-2">
          <span aria-hidden="true" className="size-2 shrink-0 rounded-[3px]" style={{ background: classColor(row.functional_class) }} />
          <span className="truncate text-ink-2">{functionalClassLabel(row.functional_class)}</span>
        </span>
      ),
    },
    {
      key: 'owner',
      header: 'Owner',
      width: '164px',
      mobile: true,
      cell: (row) => (
        <span className="block min-w-0">
          {row.owner ? (
            <span className="block truncate text-ink" title={row.owner}>{row.owner}</span>
          ) : (
            <span className="block truncate text-high italic">No owner</span>
          )}
          <span className="block truncate text-[11px] text-ink-3">{row.environment || 'No environment'}</span>
        </span>
      ),
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '128px',
      priority: 'wide',
      cell: (row) => <span className="block font-mono text-[12px]">{row.account_id}</span>,
    },
    {
      key: 'last_activity_at',
      header: 'Last active',
      sortable: true,
      width: '146px',
      mobile: true,
      cell: (row) => <Freshness value={row.last_activity_at} />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
      <PageHeader
        title="Identities"
        lede="Every non-human identity discovered in your AWS accounts. Open one for its full record, timeline and type-specific attributes."
        tabs={<Tabs size="sm" tabs={viewTabs} value={pageView} onChange={setPageView} />}
        actions={
          <>
            <Button
              variant="secondary"
              icon={Download}
              loading={exporting === 'csv'}
              disabled={Boolean(exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          </>
        }
      />
      </Reveal>

      {pageView === 'dormant' ? (
        <DormantView />
      ) : (
      <Reveal>
      <div ref={tableTop} className="scroll-mt-20">
      <WorkArea
        railOpen={railOpen}
        rail={
          <FacetRail
            groups={facetGroups}
            appliedCount={applied}
            onClearAll={clearAll}
            onClose={toggleRail}
          />
        }
      >
        <Panel flush className="overflow-hidden">
          <RecordBar
            trailing={
              <TableToolbar>
                <SegmentedControl
                  label="View"
                  value={view}
                  onChange={(next) => update({ view: next === 'class' ? 'class' : '' }, { keepPage: true })}
                  options={[
                    { value: 'table', label: 'Table', icon: Rows3 },
                    { value: 'class', label: 'By class', icon: LayoutGrid },
                  ]}
                />
                {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                <TableSettings
                  density={density}
                  onDensityChange={(value) => {
                    setDensity(value);
                    writeDensity(value);
                  }}
                />
                <OverflowMenu
                  items={[
                    {
                      key: 'json',
                      label: 'Export as JSON',
                      hint: 'Every identity matching these filters, with full records',
                      icon: FileJson,
                      onSelect: () => onExport('json'),
                      disabled: Boolean(exporting) || !can('data.export'),
                      disabledHint: exporting ? 'An export is already running' : lock('data.export'),
                    },
                  ]}
                />
              </TableToolbar>
            }
          >
            <SearchInput
              size="sm"
              value={searchDraft}
              onChange={setSearchDraft}
              maxLength={256}
              placeholder="Search name or ARN…"
              className="w-full min-w-0 sm:max-w-sm"
            />
            <ResultCount
              shown={formatNumber(total)}
              unit={total === 1 ? 'identity' : 'identities'}
              loading={list.isLoading && !list.data}
            />
          </RecordBar>

          <AppliedFilters
            filters={chips}
            onRemove={(key) => {
              if (key === 'search') setSearchDraft('');
              update({ [key]: '' });
            }}
            onClearAll={clearAll}
          />

          {view === 'class' ? (
            <GroupedByClass accountId={filters.account_id} region={filters.region} />
          ) : list.isError && !list.data ? (
            <ErrorState
              error={list.error}
              onRetry={list.error?.status === 400 ? undefined : list.refetch}
              title={list.error?.status === 400 ? 'These filters were not accepted' : undefined}
            />
          ) : (
            <>
              {list.isError && (
                <div className="p-3">
                  <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                </div>
              )}
              <DataGrid
                caption="Discovered identities"
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                loading={list.isLoading && !list.data}
                refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                onRowClick={(row, event) => {
                  if (event?.metaKey || event?.ctrlKey) window.open(`/identities/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                  else setPeek(rows.indexOf(row));
                }}
                selectedKey={peek !== null ? rows[peek]?.id : undefined}
                rowLabel={(row) => `Preview ${row.name || row.arn}`}
                sort={sort}
                onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction }, { keepPage: false })}
                density={density}
                skeletonRows={10}
                rowActions={(row) => (
                  <IconButton
                    icon={Copy}
                    label={`Copy ARN for ${row.name || row.arn}`}
                    size="sm"
                    onClick={(event) => {
                      event.stopPropagation();
                      copyText(row.arn).then((ok) =>
                        notify(
                          ok
                            ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                            : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                        ),
                      );
                    }}
                  />
                )}
                emptyState={
                  applied > 0 ? (
                    <EmptyState
                      icon={SearchX}
                      title="No identities match these filters"
                      description="Remove a filter or change the search to widen the list."
                      action={
                        <Button variant="secondary" size="sm" onClick={clearAll}>
                          Clear all filters
                        </Button>
                      }
                    />
                  ) : (
                    <EmptyState
                      title="No identities discovered yet"
                      description="Identities appear here after the scanner completes a discovery run on a connected AWS account."
                    />
                  )
                }
              />
              {total > 0 && (
                <Pagination
                  page={page}
                  pageSize={limit}
                  total={total}
                  pageSizes={PAGE_SIZES}
                  unit={total === 1 ? 'identity' : 'identities'}
                  scrollTarget={tableTop}
                  onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                  onPageSizeChange={(size) => update({ limit: size })}
                />
              )}
            </>
          )}
        </Panel>
      </WorkArea>
      </div>
      </Reveal>
      )}
      <RecordPreview kind="identity" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacetGroups({ filters, counts, accounts, regions, update }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner);
  const [environmentDraft, setEnvironmentDraft] = useState(filters.environment);
  useEffect(() => setOwnerDraft(filters.owner), [filters.owner]);
  useEffect(() => setEnvironmentDraft(filters.environment), [filters.environment]);

  const optionsFrom = (map, key, label) => {
    const entries = Object.entries(map ?? {}).filter(([, count]) => count > 0);
    if (filters[key] && !entries.some(([value]) => value === filters[key])) entries.push([filters[key], undefined]);
    return entries
      .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0))
      .map(([value, count]) => ({ value, label: label(value), count, active: filters[key] === value }));
  };

  const single = (key, options, extra = {}) => ({
    key,
    single: true,
    options,
    onToggle: (value) => update({ [key]: value }),
    ...extra,
  });

  const statusMap = counts ? { active: counts.active, stopped: counts.stopped, terminated: counts.terminated } : {};
  const accountMap = Object.fromEntries((accounts?.breakdown ?? []).map((row) => [row.account_id, row.identity_count]));
  const regionMap = Object.fromEntries((regions?.breakdown ?? []).map((row) => [row.region, row.identity_count]));

  const textFilter = (key, draft, setDraft, placeholder) => (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        update({ [key]: draft.trim().slice(0, 256) });
      }}
      className="flex flex-col gap-1.5"
    >
      <Input
        size="sm"
        value={draft}
        maxLength={256}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={() => {
          if (draft.trim() !== filters[key]) update({ [key]: draft.trim().slice(0, 256) });
        }}
        placeholder={placeholder}
        aria-label={FILTER_LABELS[key]}
      />
      <span className="text-[11px] text-ink-3">Exact value. Press Enter to apply.</span>
    </form>
  );

  /* "Inactive for" offers the windows people act on and turns each into
     the date the API filters by; a date that came in on a link and matches
     none of them still shows, as its own choice. */
  const inactivePresets = [30, 90, 180, 365].map((days) => ({ value: daysAgo(days), label: `${days}+ days`, active: filters.last_active_before === daysAgo(days) }));
  if (filters.last_active_before && !inactivePresets.some((option) => option.active)) {
    inactivePresets.push({ value: filters.last_active_before, label: `Before ${filters.last_active_before}`, active: true });
  }

  /* Ordered by how a reviewer narrows the inventory: what the identity is,
     then the risk questions (exposed, idle), then state and location, and the
     free-text ownership fields last. */
  return [
    single('functional_class', optionsFrom(counts?.by_class, 'functional_class', functionalClassLabel), {
      label: 'Functional class',
      emptyText: counts ? 'No identities yet.' : 'Loading…',
    }),
    single('identity_type', optionsFrom(counts?.by_type, 'identity_type', identityTypeLabel), {
      label: 'Type',
      emptyText: counts ? 'No identities yet.' : 'Loading…',
    }),
    single(
      'is_public',
      [
        { value: 'true', label: 'Publicly accessible', active: filters.is_public === 'true' },
        { value: 'false', label: 'Not public', active: filters.is_public === 'false' },
      ],
      { label: 'Internet exposure' },
    ),
    single('last_active_before', inactivePresets, {
      label: 'Inactive for',
      note: 'Identities with no tracked activity are not included.',
    }),
    single('status', optionsFrom(statusMap, 'status', (value) => statusMeta(value).label)),
    single('account_id', optionsFrom(accountMap, 'account_id', (value) => value), {
      label: 'AWS account',
      emptyText: accounts ? 'No accounts yet.' : 'Loading…',
      defaultOpen: false,
    }),
    single('region', optionsFrom(regionMap, 'region', regionLabel), {
      label: 'Region',
      emptyText: regions ? 'No regions yet.' : 'Loading…',
      defaultOpen: false,
    }),
    {
      key: 'owner',
      label: 'Owner',
      defaultOpen: Boolean(filters.owner),
      activeCount: filters.owner ? 1 : 0,
      content: textFilter('owner', ownerDraft, setOwnerDraft, 'e.g. platform-team'),
    },
    {
      key: 'environment',
      label: 'Environment',
      defaultOpen: Boolean(filters.environment),
      activeCount: filters.environment ? 1 : 0,
      content: textFilter('environment', environmentDraft, setEnvironmentDraft, 'e.g. production'),
    },
    {
      key: 'last_active_custom',
      label: 'Last active before a date',
      defaultOpen: false,
      content: (
        <Input
          size="sm"
          type="date"
          value={filters.last_active_before}
          max={new Date().toISOString().slice(0, 10)}
          onChange={(event) => update({ last_active_before: event.target.value })}
          aria-label="Last active before a date"
        />
      ),
    },
  ].map((group) => ({ label: FILTER_LABELS[group.key], ...group }));
}

/** The calendar date N days before today, as the API's YYYY-MM-DD. */
function daysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function describeValue(key, value) {
  switch (key) {
    case 'identity_type':
      return identityTypeLabel(value);
    case 'functional_class':
      return functionalClassLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'is_public':
      return value === 'true' ? 'Yes' : 'No';
    case 'last_active_before': {
      const preset = [30, 90, 180, 365].find((days) => daysAgo(days) === value);
      return preset ? `${preset}+ days` : `since ${value}`;
    }
    default:
      return value;
  }
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */

function readDensity() {
  try {
    return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
  } catch {
    return 'comfortable';
  }
}

function writeDensity(value) {
  try {
    localStorage.setItem(DENSITY_KEY, value);
  } catch {
    /* a reading preference; safe to lose */
  }
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

