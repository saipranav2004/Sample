import { useState } from 'react';
import { motion } from 'motion/react';
import { formatNumber } from '../lib/format';
import { EASE_GROW } from '../lib/motion';
import { cn } from '../ui/cn';

/**
 * Vertical columns over an ordered axis (privilege level 0-10). Columns grow
 * from the baseline; hovering one fades the rest and shows its exact value in
 * the readout above the chart, so there is no floating tooltip to chase.
 *
 * bins: [{ key, axisLabel, value, label, color }]
 */
export function Histogram({ bins, height = 168, onSelect, ariaLabel, readoutLabel = 'roles', bands }) {
  const [active, setActive] = useState(null);
  const max = Math.max(1, ...bins.map((bin) => Number(bin.value) || 0));
  const focus = bins.find((bin) => bin.key === active) ?? null;

  return (
    <div>
      <p className="mb-2 h-5 text-[12px] text-ink-3" aria-live="polite">
        {focus ? (
          <>
            <span className="font-semibold text-ink">{formatNumber(focus.value)}</span> {readoutLabel} at level{' '}
            {focus.axisLabel} <span className="text-ink-3">· {focus.label}</span>
          </>
        ) : (
          'Point at a column for its count.'
        )}
      </p>
      <div
        role="group"
        aria-label={ariaLabel}
        className="grid items-end gap-1.5 border-b border-line pt-4"
        style={{ gridTemplateColumns: `repeat(${bins.length}, minmax(0, 1fr))`, height: height + 16 }}
        onMouseLeave={() => setActive(null)}
      >
        {bins.map((bin, index) => {
          const value = Number(bin.value) || 0;
          const pct = (value / max) * 100;
          const dimmed = active !== null && active !== bin.key;
          const Column = onSelect ? motion.button : motion.div;
          return (
            <Column
              key={bin.key}
              type={onSelect ? 'button' : undefined}
              onClick={onSelect ? () => onSelect(bin) : undefined}
              onMouseEnter={() => setActive(bin.key)}
              onFocus={() => setActive(bin.key)}
              onBlur={() => setActive(null)}
              aria-label={`Level ${bin.axisLabel}, ${bin.label}: ${formatNumber(value)}`}
              title={`Level ${bin.axisLabel} · ${bin.label} · ${formatNumber(value)}`}
              className={cn(
                'relative w-full rounded-t-[5px] transition-opacity duration-200 focus-visible:outline-2 focus-visible:outline-offset-2',
                onSelect && 'cursor-pointer',
                dimmed ? 'opacity-30' : 'opacity-100',
              )}
              style={{ background: bin.color, transformOrigin: 'bottom', minHeight: value > 0 ? 3 : 0 }}
              initial={{ height: 0 }}
              animate={{ height: `${pct}%` }}
              transition={{ duration: 0.85, ease: EASE_GROW, delay: index * 0.035 }}
            >
              {/* Direct value label: the count is readable without hovering. */}
              {value > 0 && (
                <span aria-hidden="true" className="absolute inset-x-0 -top-4 text-center text-[10.5px] font-semibold text-ink-2" data-numeric="">
                  {formatNumber(value)}
                </span>
              )}
            </Column>
          );
        })}
      </div>
      <div
        className="mt-1.5 grid gap-1.5 text-center text-[11px] text-ink-3"
        style={{ gridTemplateColumns: `repeat(${bins.length}, minmax(0, 1fr))` }}
        aria-hidden="true"
      >
        {bins.map((bin) => (
          <span key={bin.key} data-numeric="">
            {bin.axisLabel}
          </span>
        ))}
      </div>
      {bands && (
        <div
          className="mt-1.5 grid gap-1.5 text-center text-[10.5px] font-semibold text-ink-3"
          style={{ gridTemplateColumns: `repeat(${bins.length}, minmax(0, 1fr))` }}
        >
          {bands.map((band) => (
            <span
              key={band.label}
              className="truncate border-t-2 pt-1"
              style={{ gridColumn: `${band.from + 1} / ${band.to + 2}`, borderColor: band.color }}
            >
              {band.label}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
