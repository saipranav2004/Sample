import { useState } from 'react';
import { motion } from 'motion/react';
import { EASE_GROW } from '../lib/motion';
import { cn } from '../ui/cn';

/**
 * Two series compared across the same categories, as paired horizontal bars
 * on one 0-100% scale (dataviz: "tell distinct series apart" is a grouped
 * bar). Each bar is direct-labelled with its share; pointing at a category
 * fades the others and shows the counts behind the shares.
 *
 * series: [{ key, label, color }]
 * rows:   [{ key, label, values: { [seriesKey]: { pct, detail? } } }]
 */
export function PairedBars({ series, rows, ariaLabel }) {
  const [focus, setFocus] = useState(null);
  return (
    <div role="group" aria-label={ariaLabel}>
      <ul className="mb-3 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-ink-2">
        {series.map((entry) => (
          <li key={entry.key} className="inline-flex items-center gap-1.5">
            <span aria-hidden="true" className="size-2.5 rounded-[3px]" style={{ background: entry.color }} />
            {entry.label}
          </li>
        ))}
      </ul>
      <ul className="flex flex-col" onMouseLeave={() => setFocus(null)}>
        {rows.map((row, rowIndex) => (
          <li
            key={row.key}
            onMouseEnter={() => setFocus(row.key)}
            className={cn('border-b border-line/70 py-2.5 transition-opacity duration-150 last:border-b-0', focus !== null && focus !== row.key && 'opacity-40')}
          >
            <p className="mb-1.5 flex items-baseline justify-between gap-3 text-[12.5px]">
              <span className="font-medium text-ink">{row.label}</span>
              {focus === row.key && (
                <span className="truncate text-[11.5px] text-ink-3">
                  {series.map((entry) => row.values[entry.key]?.detail && `${entry.label} ${row.values[entry.key].detail}`).filter(Boolean).join(' · ')}
                </span>
              )}
            </p>
            <div className="flex flex-col gap-1">
              {series.map((entry, seriesIndex) => {
                const value = row.values[entry.key];
                const pct = Math.max(0, Math.min(100, Number(value?.pct) || 0));
                return (
                  <div key={entry.key} className="grid grid-cols-[minmax(0,1fr)_3.25rem] items-center gap-2.5" title={`${entry.label}: ${formatPct(pct)}${value?.detail ? ` (${value.detail})` : ''}`}>
                    <span className="h-2 overflow-hidden rounded-full bg-[var(--t-track)]">
                      <motion.span
                        className="block h-full rounded-full"
                        style={{ background: entry.color }}
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, ease: EASE_GROW, delay: rowIndex * 0.06 + seriesIndex * 0.04 }}
                      />
                    </span>
                    <span data-numeric="" className="text-right text-[12px] font-semibold text-ink">
                      {value ? formatPct(pct) : '-'}
                    </span>
                  </div>
                );
              })}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function formatPct(n) {
  return `${n.toFixed(n % 1 ? 1 : 0)}%`;
}
