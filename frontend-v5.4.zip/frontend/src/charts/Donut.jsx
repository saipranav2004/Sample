import { useEffect, useId, useState } from 'react';
import { animate, motion, useMotionValue, useReducedMotion, useTransform } from 'motion/react';
import { formatNumber } from '../lib/format';
import { cn } from '../ui/cn';

/**
 * Part-to-whole for a handful of categories where the total matters - the
 * one job a donut does better than a bar (dataviz "choosing a form": keep it
 * to five or so slices; past that, use a bar list).
 *
 * Bklit's pie, ported to the libraries this console already ships: each
 * slice sweeps in on a short stagger; pointing at a slice or its legend row
 * springs that slice outward, fades the rest, and the centre reads it out.
 * With nothing in focus the centre carries the total.
 *
 * slices: [{ key, label, value, color, to? }]
 */
export function Donut({ slices, size = 148, thickness = 20, totalLabel = 'total', onSelect, title, className }) {
  const [focus, setFocus] = useState(null);
  const labelId = useId();
  const items = slices.filter((slice) => Number(slice.value) > 0);
  const total = items.reduce((sum, slice) => sum + Number(slice.value), 0);
  const radius = size / 2 - 6;
  const inner = radius - thickness;
  const gap = items.length > 1 ? Math.min(0.035, 2 / radius) : 0;

  let angle = 0;
  const arcs = items.map((slice) => {
    const sweep = total ? (Number(slice.value) / total) * Math.PI * 2 : 0;
    const arc = { ...slice, start: angle, end: angle + sweep };
    angle += sweep;
    return arc;
  });
  const current = arcs.find((arc) => arc.key === focus) ?? null;

  return (
    <div className={cn('flex flex-wrap items-center gap-x-5 gap-y-3', className)}>
      <svg
        width={size}
        height={size}
        viewBox={`${-size / 2} ${-size / 2} ${size} ${size}`}
        role="img"
        aria-labelledby={labelId}
        className="shrink-0 overflow-visible"
        onMouseLeave={() => setFocus(null)}
      >
        <title id={labelId}>{`${title ?? 'Breakdown'}: ${arcs.map((arc) => `${arc.label} ${arc.value}`).join(', ')}`}</title>
        <circle r={(radius + inner) / 2} fill="none" stroke="var(--t-track)" strokeWidth={thickness} />
        {arcs.map((arc, index) => (
          <Slice
            key={arc.key}
            arc={arc}
            index={index}
            radius={radius}
            inner={inner}
            gap={gap}
            focused={focus === arc.key}
            faded={focus !== null && focus !== arc.key}
            onEnter={() => setFocus(arc.key)}
            onSelect={onSelect ? () => onSelect(arc) : undefined}
          />
        ))}
        <text y={-2} textAnchor="middle" className="fill-ink font-display text-[22px] font-extrabold" style={{ fontVariantNumeric: 'tabular-nums' }}>
          {formatNumber(current ? current.value : total)}
        </text>
        <text y={15} textAnchor="middle" className="fill-[var(--t-ink-3)] text-[10.5px]">
          {current ? `${Math.round((current.value / total) * 100)}% · ${current.label.toLowerCase()}` : totalLabel}
        </text>
      </svg>

      <ul className="flex min-w-[11.5rem] flex-1 flex-col" onMouseLeave={() => setFocus(null)}>
        {arcs.map((arc) => {
          const Row = onSelect ? 'button' : 'div';
          return (
            <li key={arc.key}>
              <Row
                type={onSelect ? 'button' : undefined}
                onClick={onSelect ? () => onSelect(arc) : undefined}
                onMouseEnter={() => setFocus(arc.key)}
                onFocus={() => setFocus(arc.key)}
                onBlur={() => setFocus(null)}
                className={cn(
                  'flex w-full items-center gap-2 rounded-md px-1.5 py-1.5 text-left text-[12.5px] transition-opacity duration-150',
                  onSelect && 'hover:bg-surface-2 focus-visible:bg-surface-2',
                  focus !== null && focus !== arc.key && 'opacity-45',
                )}
              >
                <span aria-hidden="true" className="size-2.5 shrink-0 rounded-[3px]" style={{ background: arc.color }} />
                <span className="min-w-0 flex-1 truncate text-ink-2">{arc.label}</span>
                <span data-numeric="" className="font-semibold text-ink">
                  {formatNumber(arc.value)}
                </span>
                <span data-numeric="" className="w-10 text-right text-[11.5px] text-ink-3">
                  {Math.round((arc.value / total) * 100)}%
                </span>
              </Row>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Slice({ arc, index, radius, inner, gap, focused, faded, onEnter, onSelect }) {
  const reduced = useReducedMotion();
  const progress = useMotionValue(reduced ? 1 : 0);
  useEffect(() => {
    if (reduced) return undefined;
    const controls = animate(progress, 1, { duration: 0.75, ease: [0.22, 1, 0.36, 1], delay: 0.1 + index * 0.08 });
    return () => controls.stop();
  }, [progress, index, reduced]);
  const d = useTransform(progress, (p) => arcPath(arc.start, arc.start + (arc.end - arc.start) * p, radius, inner, gap));
  const mid = (arc.start + arc.end) / 2;
  return (
    <motion.path
      d={d}
      fill={arc.color}
      fillRule="evenodd"
      onMouseEnter={onEnter}
      onClick={onSelect}
      animate={{ opacity: faded ? 0.35 : 1, x: focused ? Math.sin(mid) * 5 : 0, y: focused ? -Math.cos(mid) * 5 : 0 }}
      transition={{ opacity: { duration: 0.15 }, x: { type: 'spring', stiffness: 400, damping: 25 }, y: { type: 'spring', stiffness: 400, damping: 25 } }}
      style={{ cursor: onSelect ? 'pointer' : 'default' }}
    />
  );
}

/** An annular sector from `start` to `end` radians, 0 at twelve o'clock, clockwise. */
function arcPath(start, end, outer, inner, gap) {
  const sweep = end - start;
  if (sweep <= 0.0005) return '';
  if (sweep >= Math.PI * 2 - 0.0001) {
    /* A full ring cannot be one arc; draw it as two halves. */
    return [
      `M 0 ${-outer}`,
      `A ${outer} ${outer} 0 1 1 0 ${outer}`,
      `A ${outer} ${outer} 0 1 1 0 ${-outer}`,
      `M 0 ${-inner}`,
      `A ${inner} ${inner} 0 1 0 0 ${inner}`,
      `A ${inner} ${inner} 0 1 0 0 ${-inner}`,
      'Z',
    ].join(' ');
  }
  const pad = Math.min(gap, sweep / 3);
  const a0 = start + pad / 2;
  const a1 = end - pad / 2;
  const point = (r, a) => `${(Math.sin(a) * r).toFixed(3)} ${(-Math.cos(a) * r).toFixed(3)}`;
  const large = a1 - a0 > Math.PI ? 1 : 0;
  return [
    `M ${point(outer, a0)}`,
    `A ${outer} ${outer} 0 ${large} 1 ${point(outer, a1)}`,
    `L ${point(inner, a1)}`,
    `A ${inner} ${inner} 0 ${large} 0 ${point(inner, a0)}`,
    'Z',
  ].join(' ');
}
