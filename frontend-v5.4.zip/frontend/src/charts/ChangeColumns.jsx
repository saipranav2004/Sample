import { useState } from 'react';
import { motion } from 'motion/react';
import { formatNumber } from '../lib/format';
import { EASE_GROW } from '../lib/motion';
import { cn } from '../ui/cn';

/**
 * Change over time as diverging columns: what arrived grows up from the
 * baseline, what went grows down from it, one column per time bucket. The
 * shape answers "when did the estate change, and which way" at a glance -
 * the question a feed of rows cannot answer.
 *
 * Columns grow from the baseline with a short stagger (bklit's bar entrance);
 * pointing at one fades the rest and reads it out above the chart, so there
 * is no floating tooltip to chase.
 *
 * buckets: [{ key, label (axis), title (readout), up, down }]
 */
export function ChangeColumns({
  buckets,
  height = 132,
  upLabel = 'Discovered',
  downLabel = 'Removed',
  upColor = 'var(--t-low)',
  downColor = 'var(--t-neutral)',
  ariaLabel,
  tickEvery = 1,
}) {
  const [active, setActive] = useState(null);
  const maxUp = Math.max(0, ...buckets.map((bucket) => bucket.up));
  const maxDown = Math.max(0, ...buckets.map((bucket) => bucket.down));
  const scale = Math.max(1, maxUp + maxDown);
  /* The baseline sits where the two directions' peaks meet, so neither side
     is squeezed when one direction dominates. A small floor keeps an empty
     side visible as "nothing happened" rather than missing. */
  const upShare = maxDown === 0 ? 0.88 : maxUp === 0 ? 0.12 : Math.min(0.85, Math.max(0.15, maxUp / scale));
  const upHeight = height * upShare;
  const downHeight = height - upHeight;
  const focus = buckets.find((bucket) => bucket.key === active) ?? null;
  const totalUp = buckets.reduce((sum, bucket) => sum + bucket.up, 0);
  const totalDown = buckets.reduce((sum, bucket) => sum + bucket.down, 0);
  const columns = `repeat(${buckets.length}, minmax(0, 1fr))`;

  return (
    <div>
      <p className="mb-2 flex h-5 flex-wrap items-center gap-x-3 text-[12px] text-ink-3" aria-live="polite">
        {focus ? (
          <>
            <span className="font-semibold text-ink-2">{focus.title}</span>
            <Readout color={upColor} label={upLabel} value={focus.up} />
            <Readout color={downColor} label={downLabel} value={focus.down} />
          </>
        ) : (
          <>
            <Readout color={upColor} label={upLabel} value={totalUp} />
            <Readout color={downColor} label={downLabel} value={totalDown} />
          </>
        )}
      </p>

      <div role="group" aria-label={ariaLabel} onMouseLeave={() => setActive(null)} className="relative">
        <div className="grid items-end gap-[3px]" style={{ gridTemplateColumns: columns, height: upHeight }}>
          {buckets.map((bucket, index) => (
            <Column
              key={bucket.key}
              bucket={bucket}
              value={bucket.up}
              max={maxUp}
              color={upColor}
              direction="up"
              dimmed={active !== null && active !== bucket.key}
              index={index}
              onFocus={setActive}
              labels={[upLabel, downLabel]}
            />
          ))}
        </div>
        <div aria-hidden="true" className="h-px bg-line-strong" />
        <div className="grid items-start gap-[3px]" style={{ gridTemplateColumns: columns, height: downHeight }}>
          {buckets.map((bucket, index) => (
            <Column
              key={bucket.key}
              bucket={bucket}
              value={bucket.down}
              max={maxDown}
              color={downColor}
              direction="down"
              dimmed={active !== null && active !== bucket.key}
              index={index}
              onFocus={setActive}
              labels={[upLabel, downLabel]}
            />
          ))}
        </div>
      </div>

      <div aria-hidden="true" className="mt-1.5 grid gap-[3px] text-center text-[10.5px] text-ink-3" style={{ gridTemplateColumns: columns }}>
        {buckets.map((bucket, index) => (
          <span key={bucket.key} className="truncate" data-numeric="">
            {index % tickEvery === 0 || index === buckets.length - 1 ? bucket.label : ''}
          </span>
        ))}
      </div>
    </div>
  );
}

function Column({ bucket, value, max, color, direction, dimmed, index, onFocus, labels }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  const up = direction === 'up';
  return (
    <span
      tabIndex={up ? 0 : -1}
      aria-label={up ? `${bucket.title}: ${labels[0]} ${bucket.up}, ${labels[1]} ${bucket.down}` : undefined}
      aria-hidden={up ? undefined : 'true'}
      onMouseEnter={() => onFocus(bucket.key)}
      onFocus={() => onFocus(bucket.key)}
      onBlur={() => onFocus(null)}
      className={cn('flex h-full w-full rounded-sm outline-none focus-visible:ring-2 focus-visible:ring-brand', up ? 'items-end' : 'items-start')}
    >
      <motion.span
        className={cn('block w-full transition-opacity duration-200', up ? 'rounded-t-[4px]' : 'rounded-b-[4px]', dimmed ? 'opacity-30' : 'opacity-100')}
        style={{ background: color, minHeight: value > 0 ? 3 : 0, transformOrigin: up ? 'bottom' : 'top' }}
        initial={{ height: 0 }}
        animate={{ height: `${pct}%` }}
        transition={{ duration: 0.8, ease: EASE_GROW, delay: Math.min(index * 0.02, 0.5) }}
      />
    </span>
  );
}

function Readout({ color, label, value }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span aria-hidden="true" className="size-2.5 rounded-[3px]" style={{ background: color }} />
      {label} <b data-numeric="" className="font-semibold text-ink">{formatNumber(value)}</b>
    </span>
  );
}

/**
 * Buckets events into the window's natural unit: hours for a day, days for a
 * week or month, weeks for a quarter. Every bucket in the window is present,
 * so a quiet day shows as a gap rather than disappearing from the axis.
 */
export function bucketEvents(items, hours, now = Date.now(), at = (item) => item.discovered_at, isUp = (item) => item.event === 'new') {
  const HOUR = 3_600_000;
  const DAY = 24 * HOUR;
  const unit = hours <= 24 ? 'hour' : hours <= 720 ? 'day' : 'week';
  const step = unit === 'hour' ? HOUR : unit === 'day' ? DAY : 7 * DAY;
  const end = new Date(now);
  if (unit === 'hour') end.setMinutes(0, 0, 0);
  else end.setHours(0, 0, 0, 0);
  /* One extra bucket: the window reaches back into the part-filled first
     hour, day or week, which would otherwise be dropped. */
  const count = Math.ceil((hours * HOUR) / step) + 1;
  const buckets = [];
  for (let index = count - 1; index >= 0; index -= 1) {
    const start = end.getTime() - index * step;
    const date = new Date(start);
    buckets.push({
      key: String(start),
      start,
      label:
        unit === 'hour'
          ? date.toLocaleTimeString(undefined, { hour: 'numeric' })
          : date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }),
      title:
        unit === 'hour'
          ? `${date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}, ${date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}`
          : unit === 'week'
            ? `Week of ${date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}`
            : date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }),
      up: 0,
      down: 0,
    });
  }
  for (const item of items) {
    const time = new Date(at(item)).getTime();
    if (!Number.isFinite(time)) continue;
    if (time < buckets[0].start) continue;
    const index = Math.floor((time - buckets[0].start) / step);
    const bucket = buckets[Math.min(index, buckets.length - 1)];
    if (isUp(item)) bucket.up += 1;
    else bucket.down += 1;
  }
  return { buckets, unit };
}
