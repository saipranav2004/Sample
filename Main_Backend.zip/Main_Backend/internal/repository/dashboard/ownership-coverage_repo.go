// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"math"
// 	"strings"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// const (
// 	OwnershipEntityIdentities  = "identities"
// 	OwnershipEntityCredentials = "credentials"
// 	OwnershipEntityBoth        = "both"
// )

// type OwnershipCoverageFilter struct {
// 	AccountID string
// 	Entity    string
// }

// type OwnershipCoverageRepository struct {
// 	db *repository.PostgresDB
// }

// func NewOwnershipCoverageRepository(db *repository.PostgresDB) *OwnershipCoverageRepository {
// 	return &OwnershipCoverageRepository{db: db}
// }

// func pct(count, total int) float64 {
// 	if total == 0 {
// 		return 0
// 	}
// 	v := (float64(count) / float64(total)) * 100
// 	return math.Round(v*10) / 10
// }

// // iacDiscoverySources — STILL A GUESS, unverified against real discovery_source values.
// func iacSourceList() string {
// 	sources := []string{"terraform", "cloudformation", "pulumi", "cdk"}
// 	quoted := make([]string, len(sources))
// 	for i, s := range sources {
// 		quoted[i] = "'" + strings.ReplaceAll(s, "'", "''") + "'"
// 	}
// 	return strings.Join(quoted, ", ")
// }

// func (r *OwnershipCoverageRepository) getIdentitiesCoverage(ctx context.Context, accountID string) (*models.IdentityOwnershipCoverage, error) {
// 	where := "WHERE 1=1"
// 	args := []interface{}{}
// 	if accountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, accountID)
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) AS total,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(environment,''), tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
// 			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
// 			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
// 			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
// 		FROM %[1]s.identities
// 		%[3]s
// 	`, repository.Schema, iacSourceList(), where)

// 	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).
// 		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
// 		return nil, fmt.Errorf("identities ownership coverage: %w", err)
// 	}

// 	return &models.IdentityOwnershipCoverage{
// 		Total:             total,
// 		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
// 		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
// 		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
// 		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
// 		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
// 	}, nil
// }

// // getCredentialsCoverage queries the real credentials table.
// // has_owner_tag uses owner_principal_arn column with tags fallback.
// // has_environment_tag uses ONLY tags (no dedicated environment column exists
// // on credentials) — confirmed via: tags->>'Environment' / tags->>'environment'.
// // is_in_iac uses discovery_source, same guessed IaC list as identities.
// func (r *OwnershipCoverageRepository) getCredentialsCoverage(ctx context.Context, accountID string) (*models.CredentialOwnershipCoverage, error) {
// 	where := "WHERE 1=1"
// 	args := []interface{}{}
// 	if accountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, accountID)
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) AS total,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner_principal_arn,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
// 			COUNT(*) FILTER (WHERE COALESCE(tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
// 			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
// 			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
// 			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
// 		FROM %[1]s.credentials
// 		%[3]s
// 	`, repository.Schema, iacSourceList(), where)

// 	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).
// 		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
// 		return nil, fmt.Errorf("credentials ownership coverage: %w", err)
// 	}

// 	return &models.CredentialOwnershipCoverage{
// 		Total:             total,
// 		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
// 		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
// 		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
// 		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
// 		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
// 	}, nil
// }

// func (r *OwnershipCoverageRepository) GetOwnershipCoverage(ctx context.Context, f OwnershipCoverageFilter) (*models.OwnershipCoverageResponse, error) {
// 	resp := &models.OwnershipCoverageResponse{}

// 	switch f.Entity {
// 	case OwnershipEntityCredentials:
// 		cov, err := r.getCredentialsCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Credentials = cov
// 	case OwnershipEntityIdentities:
// 		cov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Identities = cov
// 	default: // "both" or empty
// 		idCov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		credCov, err := r.getCredentialsCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Identities = idCov
// 		resp.Credentials = credCov
// 	}

// 	return resp, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"math"
// 	"strings"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// const (
// 	OwnershipEntityIdentities  = "identities"
// 	OwnershipEntityCredentials = "credentials"
// 	OwnershipEntityBoth        = "both"
// )

// type OwnershipCoverageFilter struct {
// 	AccountID string
// 	Entity    string
// }

// type OwnershipCoverageRepository struct {
// 	db *repository.PostgresDB
// }

// func NewOwnershipCoverageRepository(db *repository.PostgresDB) *OwnershipCoverageRepository {
// 	return &OwnershipCoverageRepository{db: db}
// }

// func pct(count, total int) float64 {
// 	if total == 0 {
// 		return 0
// 	}
// 	v := (float64(count) / float64(total)) * 100
// 	return math.Round(v*10) / 10
// }

// func iacSourceList() string {
// 	sources := []string{"terraform", "cloudformation", "pulumi", "cdk"}
// 	quoted := make([]string, len(sources))
// 	for i, s := range sources {
// 		quoted[i] = "'" + strings.ReplaceAll(s, "'", "''") + "'"
// 	}
// 	return strings.Join(quoted, ", ")
// }

// func (r *OwnershipCoverageRepository) getIdentitiesCoverage(ctx context.Context, accountID string) (*models.IdentityOwnershipCoverage, error) {
// 	where := "WHERE " + repository.ScanScopeCondition()
// 	args := []interface{}{}
// 	if accountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, accountID)
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) AS total,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(environment,''), tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
// 			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
// 			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
// 			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
// 		FROM %[1]s.identities
// 		%[3]s
// 	`, repository.Schema, iacSourceList(), where)

// 	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).
// 		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
// 		return nil, fmt.Errorf("identities ownership coverage: %w", err)
// 	}

// 	return &models.IdentityOwnershipCoverage{
// 		Total:             total,
// 		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
// 		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
// 		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
// 		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
// 		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
// 	}, nil
// }

// func (r *OwnershipCoverageRepository) getCredentialsCoverage(ctx context.Context, accountID string) (*models.CredentialOwnershipCoverage, error) {
// 	where := "WHERE " + repository.ScanScopeCondition()
// 	args := []interface{}{}
// 	if accountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, accountID)
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) AS total,
// 			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner_principal_arn,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
// 			COUNT(*) FILTER (WHERE COALESCE(tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
// 			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
// 			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
// 			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
// 		FROM %[1]s.credentials
// 		%[3]s
// 	`, repository.Schema, iacSourceList(), where)

// 	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).
// 		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
// 		return nil, fmt.Errorf("credentials ownership coverage: %w", err)
// 	}

// 	return &models.CredentialOwnershipCoverage{
// 		Total:             total,
// 		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
// 		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
// 		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
// 		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
// 		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
// 	}, nil
// }

// func (r *OwnershipCoverageRepository) GetOwnershipCoverage(ctx context.Context, f OwnershipCoverageFilter) (*models.OwnershipCoverageResponse, error) {
// 	resp := &models.OwnershipCoverageResponse{}

// 	switch f.Entity {
// 	case OwnershipEntityCredentials:
// 		cov, err := r.getCredentialsCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Credentials = cov
// 	case OwnershipEntityIdentities:
// 		cov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Identities = cov
// 	default:
// 		idCov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		credCov, err := r.getCredentialsCoverage(ctx, f.AccountID)
// 		if err != nil {
// 			return nil, err
// 		}
// 		resp.Identities = idCov
// 		resp.Credentials = credCov
// 	}

// 	return resp, nil
// }

package dashboard

import (
	"context"
	"fmt"
	"math"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

const (
	OwnershipEntityIdentities  = "identities"
	OwnershipEntityCredentials = "credentials"
	OwnershipEntityBoth        = "both"
)

type OwnershipCoverageFilter struct {
	AccountID string
	Entity    string
}

type OwnershipCoverageRepository struct {
	db *repository.PostgresDB
}

func NewOwnershipCoverageRepository(db *repository.PostgresDB) *OwnershipCoverageRepository {
	return &OwnershipCoverageRepository{db: db}
}

func pct(count, total int) float64 {
	if total == 0 {
		return 0
	}
	v := (float64(count) / float64(total)) * 100
	return math.Round(v*10) / 10
}

// iacDiscoverySources — STILL A GUESS, unverified against real discovery_source values.
func iacSourceList() string {
	sources := []string{"terraform", "cloudformation", "pulumi", "cdk"}
	quoted := make([]string, len(sources))
	for i, s := range sources {
		quoted[i] = "'" + strings.ReplaceAll(s, "'", "''") + "'"
	}
	return strings.Join(quoted, ", ")
}

func (r *OwnershipCoverageRepository) getIdentitiesCoverage(ctx context.Context, accountID string) (*models.IdentityOwnershipCoverage, error) {
	where := "WHERE " + repository.LatestScanFilter
	args := []interface{}{}
	if accountID != "" {
		where += " AND account_id = $1"
		args = append(args, accountID)
	}

	query := fmt.Sprintf(`
		SELECT
			COUNT(*) AS total,
			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
			COUNT(*) FILTER (WHERE COALESCE(NULLIF(environment,''), tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
		FROM %[1]s.identities
		%[3]s
	`, repository.Schema, iacSourceList(), where)

	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
	if err := r.db.DB.QueryRowContext(ctx, query, args...).
		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
		return nil, fmt.Errorf("identities ownership coverage: %w", err)
	}

	return &models.IdentityOwnershipCoverage{
		Total:             total,
		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
	}, nil
}

// getCredentialsCoverage queries the real credentials table.
// has_owner_tag uses owner_principal_arn column with tags fallback.
// has_environment_tag uses ONLY tags (no dedicated environment column exists
// on credentials) — confirmed via: tags->>'Environment' / tags->>'environment'.
// is_in_iac uses discovery_source, same guessed IaC list as identities.
func (r *OwnershipCoverageRepository) getCredentialsCoverage(ctx context.Context, accountID string) (*models.CredentialOwnershipCoverage, error) {
	where := "WHERE " + repository.LatestScanFilter
	args := []interface{}{}
	if accountID != "" {
		where += " AND account_id = $1"
		args = append(args, accountID)
	}

	query := fmt.Sprintf(`
		SELECT
			COUNT(*) AS total,
			COUNT(*) FILTER (WHERE COALESCE(NULLIF(owner_principal_arn,''), tags->>'Owner', tags->>'owner') IS NOT NULL) AS has_owner_tag,
			COUNT(*) FILTER (WHERE COALESCE(tags->>'Environment', tags->>'environment') IS NOT NULL) AS has_environment_tag,
			COUNT(*) FILTER (WHERE tags IS NOT NULL AND tags <> '{}'::jsonb) AS has_any_tag,
			COUNT(*) FILTER (WHERE tags IS NULL OR tags = '{}'::jsonb) AS has_no_tags,
			COUNT(*) FILTER (WHERE discovery_source IS NOT NULL AND LOWER(discovery_source) IN (%[2]s)) AS is_in_iac
		FROM %[1]s.credentials
		%[3]s
	`, repository.Schema, iacSourceList(), where)

	var total, hasOwner, hasEnv, hasAny, hasNone, isIac int
	if err := r.db.DB.QueryRowContext(ctx, query, args...).
		Scan(&total, &hasOwner, &hasEnv, &hasAny, &hasNone, &isIac); err != nil {
		return nil, fmt.Errorf("credentials ownership coverage: %w", err)
	}

	return &models.CredentialOwnershipCoverage{
		Total:             total,
		HasOwnerTag:       models.CoverageStat{Count: hasOwner, Percentage: pct(hasOwner, total)},
		HasEnvironmentTag: models.CoverageStat{Count: hasEnv, Percentage: pct(hasEnv, total)},
		HasAnyTag:         models.CoverageStat{Count: hasAny, Percentage: pct(hasAny, total)},
		HasNoTags:         models.CoverageStat{Count: hasNone, Percentage: pct(hasNone, total)},
		IsInIaC:           models.CoverageStat{Count: isIac, Percentage: pct(isIac, total)},
	}, nil
}

func (r *OwnershipCoverageRepository) GetOwnershipCoverage(ctx context.Context, f OwnershipCoverageFilter) (*models.OwnershipCoverageResponse, error) {
	resp := &models.OwnershipCoverageResponse{}

	switch f.Entity {
	case OwnershipEntityCredentials:
		cov, err := r.getCredentialsCoverage(ctx, f.AccountID)
		if err != nil {
			return nil, err
		}
		resp.Credentials = cov
	case OwnershipEntityIdentities:
		cov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
		if err != nil {
			return nil, err
		}
		resp.Identities = cov
	default: // "both" or empty
		idCov, err := r.getIdentitiesCoverage(ctx, f.AccountID)
		if err != nil {
			return nil, err
		}
		credCov, err := r.getCredentialsCoverage(ctx, f.AccountID)
		if err != nil {
			return nil, err
		}
		resp.Identities = idCov
		resp.Credentials = credCov
	}

	return resp, nil
}
