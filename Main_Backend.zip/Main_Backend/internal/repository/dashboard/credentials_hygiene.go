// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"os"
// 	"strconv"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )
// func highPrivilegeThreshold() int {
// 	if v := os.Getenv("HYGIENE_PRIVILEGE_THRESHOLD"); v != "" {
// 		if n, err := strconv.Atoi(v); err == nil {
// 			return n
// 		}
// 	}
// 	return 7
// }

// var credentialTypePatterns = struct {
// 	AccessKey string
// 	Secret    string
// 	Role      string
// }{
// 	AccessKey: "%access_key%",
// 	Secret:    "%secret%",
// 	Role:      "%role%",
// }

// // ============================================================================

// type CredentialHygieneSummaryRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialHygieneSummaryRepository(db *repository.PostgresDB) *CredentialHygieneSummaryRepository {
// 	return &CredentialHygieneSummaryRepository{db: db}
// }

// func hygieneAccountFilterClause(accountID string, paramIndex int) string {
// 	if accountID == "" {
// 		return ""
// 	}
// 	return fmt.Sprintf("AND account_id = $%d", paramIndex)
// }

// func hygieneAccountFilterArgs(accountID string) []interface{} {
// 	if accountID == "" {
// 		return []interface{}{}
// 	}
// 	return []interface{}{accountID}
// }

// func (r *CredentialHygieneSummaryRepository) expiryBreakdown(ctx context.Context, condition, accountID string) (models.HygieneExpirySummary, error) {
// 	summary := models.HygieneExpirySummary{ByType: []models.HygieneByTypeCount{}}

// 	query := fmt.Sprintf(`
// 		SELECT credential_type, COUNT(*) AS cnt
// 		FROM %s.credentials
// 		WHERE deleted_at IS NULL
// 		  AND expires_at IS NOT NULL
// 		  AND %s
// 		  %s
// 		GROUP BY credential_type
// 		ORDER BY cnt DESC`,
// 		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1))

// 	rows, err := r.db.DB.QueryContext(ctx, query, hygieneAccountFilterArgs(accountID)...)
// 	if err != nil {
// 		return summary, err
// 	}
// 	defer rows.Close()

// 	for rows.Next() {
// 		var row models.HygieneByTypeCount
// 		if err := rows.Scan(&row.CredentialType, &row.Count); err != nil {
// 			return summary, err
// 		}
// 		summary.Total += row.Count
// 		summary.ByType = append(summary.ByType, row)
// 	}
// 	return summary, rows.Err()
// }

// func (r *CredentialHygieneSummaryRepository) countWhere(ctx context.Context, condition, accountID string) (int, error) {
// 	query := fmt.Sprintf(`
// 		SELECT COUNT(*)
// 		FROM %s.credentials
// 		WHERE deleted_at IS NULL
// 		  AND %s
// 		  %s`,
// 		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1))

// 	var count int
// 	err := r.db.DB.QueryRowContext(ctx, query, hygieneAccountFilterArgs(accountID)...).Scan(&count)
// 	return count, err
// }

// func (r *CredentialHygieneSummaryRepository) GetHygieneSummary(ctx context.Context, accountID string) (*models.CredentialHygieneSummaryResponse, error) {
// 	resp := &models.CredentialHygieneSummaryResponse{}

// 	expiring, err := r.expiryBreakdown(ctx, "expires_at BETWEEN NOW() AND NOW() + INTERVAL '30 days'", accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("expiring_within_30d: %w", err)
// 	}
// 	resp.ExpiringWithin30d = expiring

// 	expired, err := r.expiryBreakdown(ctx, "expires_at < NOW()", accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("already_expired: %w", err)
// 	}
// 	resp.AlreadyExpired = expired

// 	staleKeys, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NOT NULL AND last_used_at < NOW() - INTERVAL '90 days'", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("stale_access_keys_90d: %w", err)
// 	}
// 	resp.StaleAccessKeys90d = staleKeys

// 	neverUsed, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NULL", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("never_used_access_keys: %w", err)
// 	}
// 	resp.NeverUsedAccessKeys = neverUsed

// 	unrotated, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND (last_rotated_at IS NULL OR last_rotated_at < NOW() - INTERVAL '90 days')", credentialTypePatterns.Secret),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("unrotated_secrets_90d: %w", err)
// 	}
// 	resp.UnrotatedSecrets90d = unrotated

// 	rotationDisabled, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND rotation_enabled = false", credentialTypePatterns.Secret),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("rotation_disabled_secrets: %w", err)
// 	}
// 	resp.RotationDisabledSecrets = rotationDisabled

// 	rootKeys, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND owner_principal_arn ILIKE '%%:root'", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("root_access_keys_present: %w", err)
// 	}
// 	resp.RootAccessKeysPresent = rootKeys

// 	hpTotal, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND privilege_level >= %d", credentialTypePatterns.Role, highPrivilegeThreshold()),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.total: %w", err)
// 	}

// 	adminAccess, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%AdministratorAccess%%' OR inline_policies::text ILIKE '%%AdministratorAccess%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.admin_access: %w", err)
// 	}

// 	wildcardActions, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%"Action":"*"%%' OR inline_policies::text ILIKE '%%"Action":"*"%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.wildcard_actions: %w", err)
// 	}

// 	resp.HighPrivilegeRoles = models.HygieneHighPrivilegeSummary{
// 		Total:           hpTotal,
// 		AdminAccess:     adminAccess,
// 		WildcardActions: wildcardActions,
// 	}

// 	publicTrust, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (trust_policy::text ILIKE '%%"Principal":"*"%%' OR trust_policy::text ILIKE '%%"AWS":"*"%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("public_trust_roles: %w", err)
// 	}
// 	resp.PublicTrustRoles = publicTrust

// 	return resp, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"os"
// 	"strconv"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// func highPrivilegeThreshold() int {
// 	if v := os.Getenv("HYGIENE_PRIVILEGE_THRESHOLD"); v != "" {
// 		if n, err := strconv.Atoi(v); err == nil {
// 			return n
// 		}
// 	}
// 	return 7
// }

// var credentialTypePatterns = struct {
// 	AccessKey string
// 	Secret    string
// 	Role      string
// }{
// 	AccessKey: "%access_key%",
// 	Secret:    "%secret%",
// 	Role:      "%role%",
// }

// type CredentialHygieneSummaryRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialHygieneSummaryRepository(db *repository.PostgresDB) *CredentialHygieneSummaryRepository {
// 	return &CredentialHygieneSummaryRepository{db: db}
// }

// func hygieneAccountFilterClause(accountID string, paramIndex int) string {
// 	if accountID == "" {
// 		return ""
// 	}
// 	return fmt.Sprintf("AND account_id = $%d", paramIndex)
// }

// func hygieneAccountFilterArgs(accountID string) []interface{} {
// 	if accountID == "" {
// 		return []interface{}{}
// 	}
// 	return []interface{}{accountID}
// }

// // hygieneScanFilterClause scopes every hygiene query to the latest COMPLETED
// // scan_id (global), so superseded scan data is automatically excluded.
// func hygieneScanFilterClause() string {
// 	return fmt.Sprintf("AND %s", repository.ScanScopeCondition())
// }

// func (r *CredentialHygieneSummaryRepository) expiryBreakdown(ctx context.Context, condition, accountID string) (models.HygieneExpirySummary, error) {
// 	summary := models.HygieneExpirySummary{ByType: []models.HygieneByTypeCount{}}

// 	query := fmt.Sprintf(`
// 		SELECT credential_type, COUNT(*) AS cnt
// 		FROM %s.credentials
// 		WHERE deleted_at IS NULL
// 		  AND expires_at IS NOT NULL
// 		  AND %s
// 		  %s
// 		  %s
// 		GROUP BY credential_type
// 		ORDER BY cnt DESC`,
// 		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1), hygieneScanFilterClause())

// 	rows, err := r.db.DB.QueryContext(ctx, query, hygieneAccountFilterArgs(accountID)...)
// 	if err != nil {
// 		return summary, err
// 	}
// 	defer rows.Close()

// 	for rows.Next() {
// 		var row models.HygieneByTypeCount
// 		if err := rows.Scan(&row.CredentialType, &row.Count); err != nil {
// 			return summary, err
// 		}
// 		summary.Total += row.Count
// 		summary.ByType = append(summary.ByType, row)
// 	}
// 	return summary, rows.Err()
// }

// func (r *CredentialHygieneSummaryRepository) countWhere(ctx context.Context, condition, accountID string) (int, error) {
// 	query := fmt.Sprintf(`
// 		SELECT COUNT(*)
// 		FROM %s.credentials
// 		WHERE deleted_at IS NULL
// 		  AND %s
// 		  %s
// 		  %s`,
// 		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1), hygieneScanFilterClause())

// 	var count int
// 	err := r.db.DB.QueryRowContext(ctx, query, hygieneAccountFilterArgs(accountID)...).Scan(&count)
// 	return count, err
// }

// func (r *CredentialHygieneSummaryRepository) GetHygieneSummary(ctx context.Context, accountID string) (*models.CredentialHygieneSummaryResponse, error) {
// 	resp := &models.CredentialHygieneSummaryResponse{}

// 	expiring, err := r.expiryBreakdown(ctx, "expires_at BETWEEN NOW() AND NOW() + INTERVAL '30 days'", accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("expiring_within_30d: %w", err)
// 	}
// 	resp.ExpiringWithin30d = expiring

// 	expired, err := r.expiryBreakdown(ctx, "expires_at < NOW()", accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("already_expired: %w", err)
// 	}
// 	resp.AlreadyExpired = expired

// 	staleKeys, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NOT NULL AND last_used_at < NOW() - INTERVAL '90 days'", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("stale_access_keys_90d: %w", err)
// 	}
// 	resp.StaleAccessKeys90d = staleKeys

// 	neverUsed, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NULL", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("never_used_access_keys: %w", err)
// 	}
// 	resp.NeverUsedAccessKeys = neverUsed

// 	unrotated, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND (last_rotated_at IS NULL OR last_rotated_at < NOW() - INTERVAL '90 days')", credentialTypePatterns.Secret),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("unrotated_secrets_90d: %w", err)
// 	}
// 	resp.UnrotatedSecrets90d = unrotated

// 	rotationDisabled, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND rotation_enabled = false", credentialTypePatterns.Secret),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("rotation_disabled_secrets: %w", err)
// 	}
// 	resp.RotationDisabledSecrets = rotationDisabled

// 	rootKeys, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND owner_principal_arn ILIKE '%%:root'", credentialTypePatterns.AccessKey),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("root_access_keys_present: %w", err)
// 	}
// 	resp.RootAccessKeysPresent = rootKeys

// 	hpTotal, err := r.countWhere(ctx,
// 		fmt.Sprintf("credential_type ILIKE '%s' AND privilege_level >= %d", credentialTypePatterns.Role, highPrivilegeThreshold()),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.total: %w", err)
// 	}

// 	adminAccess, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%AdministratorAccess%%' OR inline_policies::text ILIKE '%%AdministratorAccess%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.admin_access: %w", err)
// 	}

// 	wildcardActions, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%"Action":"*"%%' OR inline_policies::text ILIKE '%%"Action":"*"%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("high_privilege_roles.wildcard_actions: %w", err)
// 	}

// 	resp.HighPrivilegeRoles = models.HygieneHighPrivilegeSummary{
// 		Total:           hpTotal,
// 		AdminAccess:     adminAccess,
// 		WildcardActions: wildcardActions,
// 	}

// 	publicTrust, err := r.countWhere(ctx,
// 		fmt.Sprintf(`credential_type ILIKE '%s' AND (trust_policy::text ILIKE '%%"Principal":"*"%%' OR trust_policy::text ILIKE '%%"AWS":"*"%%')`, credentialTypePatterns.Role),
// 		accountID)
// 	if err != nil {
// 		return nil, fmt.Errorf("public_trust_roles: %w", err)
// 	}
// 	resp.PublicTrustRoles = publicTrust

// 	return resp, nil
// }

package dashboard

import (
	"context"
	"fmt"
	"os"
	"strconv"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

func highPrivilegeThreshold() int {
	if v := os.Getenv("HYGIENE_PRIVILEGE_THRESHOLD"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return 7
}

var credentialTypePatterns = struct {
	AccessKey string
	Secret    string
	Role      string
}{
	AccessKey: "%access_key%",
	Secret:    "%secret%",
	Role:      "%role%",
}

// ============================================================================

type CredentialHygieneSummaryRepository struct {
	db *repository.PostgresDB
}

func NewCredentialHygieneSummaryRepository(db *repository.PostgresDB) *CredentialHygieneSummaryRepository {
	return &CredentialHygieneSummaryRepository{db: db}
}

func hygieneAccountFilterClause(accountID string, paramIndex int) string {
	if accountID == "" {
		return ""
	}
	return fmt.Sprintf("AND account_id = $%d", paramIndex)
}

func hygieneAccountFilterArgs(accountID string) []interface{} {
	if accountID == "" {
		return []interface{}{}
	}
	return []interface{}{accountID}
}

func (r *CredentialHygieneSummaryRepository) expiryBreakdown(ctx context.Context, condition, accountID string) (models.HygieneExpirySummary, error) {
	summary := models.HygieneExpirySummary{ByType: []models.HygieneByTypeCount{}}

	query := fmt.Sprintf(`
		SELECT credential_type, COUNT(*) AS cnt
		FROM %s.credentials
		WHERE deleted_at IS NULL AND `+repository.LatestScanFilter+`
		  AND expires_at IS NOT NULL
		  AND %s
		  %s
		GROUP BY credential_type
		ORDER BY cnt DESC`,
		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1))

	rows, err := r.db.DB.QueryContext(ctx, query, hygieneAccountFilterArgs(accountID)...)
	if err != nil {
		return summary, err
	}
	defer rows.Close()

	for rows.Next() {
		var row models.HygieneByTypeCount
		if err := rows.Scan(&row.CredentialType, &row.Count); err != nil {
			return summary, err
		}
		summary.Total += row.Count
		summary.ByType = append(summary.ByType, row)
	}
	return summary, rows.Err()
}

func (r *CredentialHygieneSummaryRepository) countWhere(ctx context.Context, condition, accountID string) (int, error) {
	query := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM %s.credentials
		WHERE deleted_at IS NULL AND `+repository.LatestScanFilter+`
		  AND %s
		  %s`,
		repository.Schema, condition, hygieneAccountFilterClause(accountID, 1))

	var count int
	err := r.db.DB.QueryRowContext(ctx, query, hygieneAccountFilterArgs(accountID)...).Scan(&count)
	return count, err
}

func (r *CredentialHygieneSummaryRepository) GetHygieneSummary(ctx context.Context, accountID string) (*models.CredentialHygieneSummaryResponse, error) {
	resp := &models.CredentialHygieneSummaryResponse{}

	expiring, err := r.expiryBreakdown(ctx, "expires_at BETWEEN NOW() AND NOW() + INTERVAL '30 days'", accountID)
	if err != nil {
		return nil, fmt.Errorf("expiring_within_30d: %w", err)
	}
	resp.ExpiringWithin30d = expiring

	expired, err := r.expiryBreakdown(ctx, "expires_at < NOW()", accountID)
	if err != nil {
		return nil, fmt.Errorf("already_expired: %w", err)
	}
	resp.AlreadyExpired = expired

	staleKeys, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NOT NULL AND last_used_at < NOW() - INTERVAL '90 days'", credentialTypePatterns.AccessKey),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("stale_access_keys_90d: %w", err)
	}
	resp.StaleAccessKeys90d = staleKeys

	neverUsed, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND last_used_at IS NULL", credentialTypePatterns.AccessKey),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("never_used_access_keys: %w", err)
	}
	resp.NeverUsedAccessKeys = neverUsed

	unrotated, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND (last_rotated_at IS NULL OR last_rotated_at < NOW() - INTERVAL '90 days')", credentialTypePatterns.Secret),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("unrotated_secrets_90d: %w", err)
	}
	resp.UnrotatedSecrets90d = unrotated

	rotationDisabled, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND rotation_enabled = false", credentialTypePatterns.Secret),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("rotation_disabled_secrets: %w", err)
	}
	resp.RotationDisabledSecrets = rotationDisabled

	rootKeys, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND owner_principal_arn ILIKE '%%:root'", credentialTypePatterns.AccessKey),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("root_access_keys_present: %w", err)
	}
	resp.RootAccessKeysPresent = rootKeys

	hpTotal, err := r.countWhere(ctx,
		fmt.Sprintf("credential_type ILIKE '%s' AND privilege_level >= %d", credentialTypePatterns.Role, highPrivilegeThreshold()),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("high_privilege_roles.total: %w", err)
	}

	adminAccess, err := r.countWhere(ctx,
		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%AdministratorAccess%%' OR inline_policies::text ILIKE '%%AdministratorAccess%%')`, credentialTypePatterns.Role),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("high_privilege_roles.admin_access: %w", err)
	}

	wildcardActions, err := r.countWhere(ctx,
		fmt.Sprintf(`credential_type ILIKE '%s' AND (attached_policies::text ILIKE '%%"Action":"*"%%' OR inline_policies::text ILIKE '%%"Action":"*"%%')`, credentialTypePatterns.Role),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("high_privilege_roles.wildcard_actions: %w", err)
	}

	resp.HighPrivilegeRoles = models.HygieneHighPrivilegeSummary{
		Total:           hpTotal,
		AdminAccess:     adminAccess,
		WildcardActions: wildcardActions,
	}

	publicTrust, err := r.countWhere(ctx,
		fmt.Sprintf(`credential_type ILIKE '%s' AND (trust_policy::text ILIKE '%%"Principal":"*"%%' OR trust_policy::text ILIKE '%%"AWS":"*"%%')`, credentialTypePatterns.Role),
		accountID)
	if err != nil {
		return nil, fmt.Errorf("public_trust_roles: %w", err)
	}
	resp.PublicTrustRoles = publicTrust

	return resp, nil
}
