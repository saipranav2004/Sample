// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByAccountFilter struct {
// 	Region       string
// 	IdentityType string
// }

// type IdentitiesByAccountRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByAccountRepository(db *repository.PostgresDB) *IdentitiesByAccountRepository {
// 	return &IdentitiesByAccountRepository{db: db}
// }

// func (r *IdentitiesByAccountRepository) Breakdown(ctx context.Context, f IdentitiesByAccountFilter) (*models.IdentitiesByAccountResponse, error) {
// 	identityCounts := make(map[string]int)
// 	credentialCounts := make(map[string]int)

// 	// --- identity_count per account (filters: region, identity_type) ---
// 	{
// 		var conditions = "deleted_at IS NULL"
// 		var args []interface{}
// 		argIdx := 1

// 		if f.Region != "" {
// 			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 			args = append(args, f.Region)
// 			argIdx++
// 		}

// 		if f.IdentityType != "" {
// 			conditions += fmt.Sprintf(" AND identity_type = $%d", argIdx)
// 			args = append(args, f.IdentityType)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT account_id, COUNT(*)
// 			FROM %s.identities
// 			WHERE %s
// 			GROUP BY account_id
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count identities by account: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var accountID string
// 			var count int
// 			if err := rows.Scan(&accountID, &count); err != nil {
// 				return nil, fmt.Errorf("scan identity account count: %w", err)
// 			}
// 			identityCounts[accountID] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate identity account counts: %w", err)
// 		}
// 	}

// 	// --- credential_count per account (filter: region only — credentials table has no identity_type) ---
// 	{
// 		var conditions = "deleted_at IS NULL"
// 		var args []interface{}
// 		argIdx := 1

// 		if f.Region != "" {
// 			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 			args = append(args, f.Region)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT account_id, COUNT(*)
// 			FROM %s.credentials
// 			WHERE %s
// 			GROUP BY account_id
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count credentials by account: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var accountID string
// 			var count int
// 			if err := rows.Scan(&accountID, &count); err != nil {
// 				return nil, fmt.Errorf("scan credential account count: %w", err)
// 			}
// 			credentialCounts[accountID] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate credential account counts: %w", err)
// 		}
// 	}

// 	// --- merge both maps into a unified set of account_ids ---
// 	accountSet := make(map[string]struct{})
// 	for accountID := range identityCounts {
// 		accountSet[accountID] = struct{}{}
// 	}
// 	for accountID := range credentialCounts {
// 		accountSet[accountID] = struct{}{}
// 	}

// 	breakdown := make([]models.AccountIdentityBreakdown, 0, len(accountSet))
// 	for accountID := range accountSet {
// 		breakdown = append(breakdown, models.AccountIdentityBreakdown{
// 			AccountID: accountID,
// 			// NOTE: no account_name/OU column exists in identities or credentials
// 			// tables, and no accounts reference table was provided. Defaulting
// 			// account_name to account_id until a proper accounts table is wired up.
// 			AccountName:     nil,
// 			IdentityCount:   identityCounts[accountID],
// 			CredentialCount: credentialCounts[accountID],
// 		})
// 	}

// 	return &models.IdentitiesByAccountResponse{
// 		TotalAccounts: len(breakdown),
// 		Breakdown:     breakdown,
// 	}, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByAccountFilter struct {
// 	Region       string
// 	IdentityType string
// }

// type IdentitiesByAccountRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByAccountRepository(db *repository.PostgresDB) *IdentitiesByAccountRepository {
// 	return &IdentitiesByAccountRepository{db: db}
// }

// func (r *IdentitiesByAccountRepository) Breakdown(ctx context.Context, f IdentitiesByAccountFilter) (*models.IdentitiesByAccountResponse, error) {
// 	identityCounts := make(map[string]int)
// 	credentialCounts := make(map[string]int)

// 	// --- identity_count per account ---
// 	{
// 		var conditions = "deleted_at IS NULL AND " + repository.ScanScopeCondition()
// 		var args []interface{}
// 		argIdx := 1

// 		if f.Region != "" {
// 			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 			args = append(args, f.Region)
// 			argIdx++
// 		}

// 		if f.IdentityType != "" {
// 			conditions += fmt.Sprintf(" AND identity_type = $%d", argIdx)
// 			args = append(args, f.IdentityType)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT account_id, COUNT(*)
// 			FROM %s.identities
// 			WHERE %s
// 			GROUP BY account_id
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count identities by account: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var accountID string
// 			var count int
// 			if err := rows.Scan(&accountID, &count); err != nil {
// 				return nil, fmt.Errorf("scan identity account count: %w", err)
// 			}
// 			identityCounts[accountID] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate identity account counts: %w", err)
// 		}
// 	}

// 	// --- credential_count per account ---
// 	{
// 		var conditions = "deleted_at IS NULL AND " + repository.ScanScopeCondition()
// 		var args []interface{}
// 		argIdx := 1

// 		if f.Region != "" {
// 			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 			args = append(args, f.Region)
// 			argIdx++
// 		}

// 		query := fmt.Sprintf(`
// 			SELECT account_id, COUNT(*)
// 			FROM %s.credentials
// 			WHERE %s
// 			GROUP BY account_id
// 		`, repository.Schema, conditions)

// 		rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 		if err != nil {
// 			return nil, fmt.Errorf("count credentials by account: %w", err)
// 		}
// 		defer rows.Close()

// 		for rows.Next() {
// 			var accountID string
// 			var count int
// 			if err := rows.Scan(&accountID, &count); err != nil {
// 				return nil, fmt.Errorf("scan credential account count: %w", err)
// 			}
// 			credentialCounts[accountID] = count
// 		}
// 		if err := rows.Err(); err != nil {
// 			return nil, fmt.Errorf("iterate credential account counts: %w", err)
// 		}
// 	}

// 	accountSet := make(map[string]struct{})
// 	for accountID := range identityCounts {
// 		accountSet[accountID] = struct{}{}
// 	}
// 	for accountID := range credentialCounts {
// 		accountSet[accountID] = struct{}{}
// 	}

// 	breakdown := make([]models.AccountIdentityBreakdown, 0, len(accountSet))
// 	for accountID := range accountSet {
// 		breakdown = append(breakdown, models.AccountIdentityBreakdown{
// 			AccountID:       accountID,
// 			AccountName:     nil,
// 			IdentityCount:   identityCounts[accountID],
// 			CredentialCount: credentialCounts[accountID],
// 		})
// 	}

// 	return &models.IdentitiesByAccountResponse{
// 		TotalAccounts: len(breakdown),
// 		Breakdown:     breakdown,
// 	}, nil
// }

package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesByAccountFilter struct {
	Region       string
	IdentityType string
}

type IdentitiesByAccountRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesByAccountRepository(db *repository.PostgresDB) *IdentitiesByAccountRepository {
	return &IdentitiesByAccountRepository{db: db}
}

func (r *IdentitiesByAccountRepository) Breakdown(ctx context.Context, f IdentitiesByAccountFilter) (*models.IdentitiesByAccountResponse, error) {
	identityCounts := make(map[string]int)
	credentialCounts := make(map[string]int)

	// --- identity_count per account (filters: region, identity_type) ---
	{
		var conditions = "deleted_at IS NULL AND " + repository.LatestScanFilter
		var args []interface{}
		argIdx := 1

		if f.Region != "" {
			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
			args = append(args, f.Region)
			argIdx++
		}

		if f.IdentityType != "" {
			conditions += fmt.Sprintf(" AND identity_type = $%d", argIdx)
			args = append(args, f.IdentityType)
			argIdx++
		}

		query := fmt.Sprintf(`
			SELECT account_id, COUNT(*)
			FROM %s.identities
			WHERE %s
			GROUP BY account_id
		`, repository.Schema, conditions)

		rows, err := r.db.DB.QueryContext(ctx, query, args...)
		if err != nil {
			return nil, fmt.Errorf("count identities by account: %w", err)
		}
		defer rows.Close()

		for rows.Next() {
			var accountID string
			var count int
			if err := rows.Scan(&accountID, &count); err != nil {
				return nil, fmt.Errorf("scan identity account count: %w", err)
			}
			identityCounts[accountID] = count
		}
		if err := rows.Err(); err != nil {
			return nil, fmt.Errorf("iterate identity account counts: %w", err)
		}
	}

	// --- credential_count per account (filter: region only — credentials table has no identity_type) ---
	{
		var conditions = "deleted_at IS NULL AND " + repository.LatestScanFilter
		var args []interface{}
		argIdx := 1

		if f.Region != "" {
			conditions += fmt.Sprintf(" AND region = $%d", argIdx)
			args = append(args, f.Region)
			argIdx++
		}

		query := fmt.Sprintf(`
			SELECT account_id, COUNT(*)
			FROM %s.credentials
			WHERE %s
			GROUP BY account_id
		`, repository.Schema, conditions)

		rows, err := r.db.DB.QueryContext(ctx, query, args...)
		if err != nil {
			return nil, fmt.Errorf("count credentials by account: %w", err)
		}
		defer rows.Close()

		for rows.Next() {
			var accountID string
			var count int
			if err := rows.Scan(&accountID, &count); err != nil {
				return nil, fmt.Errorf("scan credential account count: %w", err)
			}
			credentialCounts[accountID] = count
		}
		if err := rows.Err(); err != nil {
			return nil, fmt.Errorf("iterate credential account counts: %w", err)
		}
	}

	// --- merge both maps into a unified set of account_ids ---
	accountSet := make(map[string]struct{})
	for accountID := range identityCounts {
		accountSet[accountID] = struct{}{}
	}
	for accountID := range credentialCounts {
		accountSet[accountID] = struct{}{}
	}

	breakdown := make([]models.AccountIdentityBreakdown, 0, len(accountSet))
	for accountID := range accountSet {
		breakdown = append(breakdown, models.AccountIdentityBreakdown{
			AccountID: accountID,
			// NOTE: no account_name/OU column exists in identities or credentials
			// tables, and no accounts reference table was provided. Defaulting
			// account_name to account_id until a proper accounts table is wired up.
			AccountName:     nil,
			IdentityCount:   identityCounts[accountID],
			CredentialCount: credentialCounts[accountID],
		})
	}

	return &models.IdentitiesByAccountResponse{
		TotalAccounts: len(breakdown),
		Breakdown:     breakdown,
	}, nil
}
