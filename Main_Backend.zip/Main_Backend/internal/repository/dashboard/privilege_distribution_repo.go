// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// var privilegeLevelLabels = map[int]string{
// 	0: "Minimal", 1: "Minimal",
// 	2: "Low", 3: "Low",
// 	4: "Medium", 5: "Medium",
// 	6: "High", 7: "High",
// 	8: "Critical", 9: "Critical", 10: "Critical",
// }

// type PrivilegeDistributionFilter struct {
// 	AccountID string
// }

// type PrivilegeDistributionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewPrivilegeDistributionRepository(db *repository.PostgresDB) *PrivilegeDistributionRepository {
// 	return &PrivilegeDistributionRepository{db: db}
// }

// // GetPrivilegeDistribution reads the real privilege_level integer column on
// // the credentials table, filtered to IAM roles (credential_type = 'iam_role').
// func (r *PrivilegeDistributionRepository) GetPrivilegeDistribution(
// 	ctx context.Context,
// 	f PrivilegeDistributionFilter,
// ) (*models.PrivilegeDistributionResponse, error) {

// 	where := "WHERE credential_type = 'iam_role'"
// 	args := []interface{}{}
// 	if f.AccountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, f.AccountID)
// 	}

// 	totalsQuery := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) FILTER (WHERE privilege_level IS NOT NULL) AS with_score,
// 			COUNT(*) FILTER (WHERE privilege_level IS NULL) AS unscored
// 		FROM %[1]s.credentials
// 		%[2]s
// 	`, repository.Schema, where)

// 	resp := &models.PrivilegeDistributionResponse{
// 		Distribution: make([]models.PrivilegeDistributionItem, 0, 11),
// 	}

// 	if err := r.db.DB.QueryRowContext(ctx, totalsQuery, args...).
// 		Scan(&resp.TotalRolesWithScore, &resp.TotalRolesUnscored); err != nil {
// 		return nil, fmt.Errorf("privilege distribution totals: %w", err)
// 	}

// 	distQuery := fmt.Sprintf(`
// 		SELECT privilege_level, COUNT(*)
// 		FROM %[1]s.credentials
// 		%[2]s AND privilege_level IS NOT NULL
// 		GROUP BY privilege_level
// 	`, repository.Schema, where)

// 	rows, err := r.db.DB.QueryContext(ctx, distQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("privilege distribution query: %w", err)
// 	}
// 	defer rows.Close()

// 	counts := make(map[int]int)
// 	for rows.Next() {
// 		var level, count int
// 		if err := rows.Scan(&level, &count); err != nil {
// 			return nil, fmt.Errorf("scan privilege distribution row: %w", err)
// 		}
// 		counts[level] = count
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate privilege distribution rows: %w", err)
// 	}

// 	for level := 0; level <= 10; level++ {
// 		resp.Distribution = append(resp.Distribution, models.PrivilegeDistributionItem{
// 			PrivilegeLevel: level,
// 			Count:          counts[level],
// 			Label:          privilegeLevelLabels[level],
// 		})
// 	}

// 	return resp, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// var privilegeLevelLabels = map[int]string{
// 	0: "Minimal", 1: "Minimal",
// 	2: "Low", 3: "Low",
// 	4: "Medium", 5: "Medium",
// 	6: "High", 7: "High",
// 	8: "Critical", 9: "Critical", 10: "Critical",
// }

// type PrivilegeDistributionFilter struct {
// 	AccountID string
// }

// type PrivilegeDistributionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewPrivilegeDistributionRepository(db *repository.PostgresDB) *PrivilegeDistributionRepository {
// 	return &PrivilegeDistributionRepository{db: db}
// }

// func (r *PrivilegeDistributionRepository) GetPrivilegeDistribution(
// 	ctx context.Context,
// 	f PrivilegeDistributionFilter,
// ) (*models.PrivilegeDistributionResponse, error) {

// 	where := fmt.Sprintf("WHERE credential_type = 'iam_role' AND %s", repository.ScanScopeCondition())
// 	args := []interface{}{}
// 	if f.AccountID != "" {
// 		where += " AND account_id = $1"
// 		args = append(args, f.AccountID)
// 	}

// 	totalsQuery := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*) FILTER (WHERE privilege_level IS NOT NULL) AS with_score,
// 			COUNT(*) FILTER (WHERE privilege_level IS NULL) AS unscored
// 		FROM %[1]s.credentials
// 		%[2]s
// 	`, repository.Schema, where)

// 	resp := &models.PrivilegeDistributionResponse{
// 		Distribution: make([]models.PrivilegeDistributionItem, 0, 11),
// 	}

// 	if err := r.db.DB.QueryRowContext(ctx, totalsQuery, args...).
// 		Scan(&resp.TotalRolesWithScore, &resp.TotalRolesUnscored); err != nil {
// 		return nil, fmt.Errorf("privilege distribution totals: %w", err)
// 	}

// 	distQuery := fmt.Sprintf(`
// 		SELECT privilege_level, COUNT(*)
// 		FROM %[1]s.credentials
// 		%[2]s AND privilege_level IS NOT NULL
// 		GROUP BY privilege_level
// 	`, repository.Schema, where)

// 	rows, err := r.db.DB.QueryContext(ctx, distQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("privilege distribution query: %w", err)
// 	}
// 	defer rows.Close()

// 	counts := make(map[int]int)
// 	for rows.Next() {
// 		var level, count int
// 		if err := rows.Scan(&level, &count); err != nil {
// 			return nil, fmt.Errorf("scan privilege distribution row: %w", err)
// 		}
// 		counts[level] = count
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate privilege distribution rows: %w", err)
// 	}

// 	for level := 0; level <= 10; level++ {
// 		resp.Distribution = append(resp.Distribution, models.PrivilegeDistributionItem{
// 			PrivilegeLevel: level,
// 			Count:          counts[level],
// 			Label:          privilegeLevelLabels[level],
// 		})
// 	}

// 	return resp, nil
// }

package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

var privilegeLevelLabels = map[int]string{
	0: "Minimal", 1: "Minimal",
	2: "Low", 3: "Low",
	4: "Medium", 5: "Medium",
	6: "High", 7: "High",
	8: "Critical", 9: "Critical", 10: "Critical",
}

type PrivilegeDistributionFilter struct {
	AccountID string
}

type PrivilegeDistributionRepository struct {
	db *repository.PostgresDB
}

func NewPrivilegeDistributionRepository(db *repository.PostgresDB) *PrivilegeDistributionRepository {
	return &PrivilegeDistributionRepository{db: db}
}

// GetPrivilegeDistribution reads the real privilege_level integer column on
// the credentials table, filtered to IAM roles (credential_type = 'iam_role').
func (r *PrivilegeDistributionRepository) GetPrivilegeDistribution(
	ctx context.Context,
	f PrivilegeDistributionFilter,
) (*models.PrivilegeDistributionResponse, error) {

	where := "WHERE credential_type = 'iam_role' AND " + repository.LatestScanFilter
	args := []interface{}{}
	if f.AccountID != "" {
		where += " AND account_id = $1"
		args = append(args, f.AccountID)
	}

	totalsQuery := fmt.Sprintf(`
		SELECT
			COUNT(*) FILTER (WHERE privilege_level IS NOT NULL) AS with_score,
			COUNT(*) FILTER (WHERE privilege_level IS NULL) AS unscored
		FROM %[1]s.credentials
		%[2]s
	`, repository.Schema, where)

	resp := &models.PrivilegeDistributionResponse{
		Distribution: make([]models.PrivilegeDistributionItem, 0, 11),
	}

	if err := r.db.DB.QueryRowContext(ctx, totalsQuery, args...).
		Scan(&resp.TotalRolesWithScore, &resp.TotalRolesUnscored); err != nil {
		return nil, fmt.Errorf("privilege distribution totals: %w", err)
	}

	distQuery := fmt.Sprintf(`
		SELECT privilege_level, COUNT(*)
		FROM %[1]s.credentials
		%[2]s AND privilege_level IS NOT NULL
		GROUP BY privilege_level
	`, repository.Schema, where)

	rows, err := r.db.DB.QueryContext(ctx, distQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("privilege distribution query: %w", err)
	}
	defer rows.Close()

	counts := make(map[int]int)
	for rows.Next() {
		var level, count int
		if err := rows.Scan(&level, &count); err != nil {
			return nil, fmt.Errorf("scan privilege distribution row: %w", err)
		}
		counts[level] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate privilege distribution rows: %w", err)
	}

	for level := 0; level <= 10; level++ {
		resp.Distribution = append(resp.Distribution, models.PrivilegeDistributionItem{
			PrivilegeLevel: level,
			Count:          counts[level],
			Label:          privilegeLevelLabels[level],
		})
	}

	return resp, nil
}
