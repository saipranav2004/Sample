// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByRegionFilter struct {
// 	AccountID    string
// 	IdentityType string
// }

// type IdentitiesByRegionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
// 	return &IdentitiesByRegionRepository{db: db}
// }

// // ValidIdentityType checks whether the given identity_type value actually
// // exists in the identities table — queried live, not hardcoded.
// func (r *IdentitiesByRegionRepository) ValidIdentityType(ctx context.Context, identityType string) (bool, error) {
// 	if identityType == "" {
// 		return true, nil // empty = no filter, always valid
// 	}
// 	query := fmt.Sprintf(`
// 		SELECT EXISTS (
// 			SELECT 1 FROM %s.identities WHERE identity_type = $1
// 		)`, repository.Schema)

// 	var exists bool
// 	err := r.db.DB.QueryRowContext(ctx, query, identityType).Scan(&exists)
// 	if err != nil {
// 		return false, fmt.Errorf("validate identity_type: %w", err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
// 	query := fmt.Sprintf(`
// 		SELECT
// 			combined.region,
// 			SUM(combined.identity_count)::int   AS identity_count,
// 			SUM(combined.credential_count)::int AS credential_count
// 		FROM (
// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				COUNT(*) AS identity_count,
// 				0        AS credential_count
// 			FROM %s.identities
// 			WHERE deleted_at IS NULL
// 			  AND ($1 = '' OR account_id = $1)
// 			  AND ($2 = '' OR identity_type = $2)
// 			GROUP BY COALESCE(region, 'unknown')

// 			UNION ALL

// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				0 AS identity_count,
// 				COUNT(*) AS credential_count
// 			FROM %s.credentials
// 			WHERE deleted_at IS NULL
// 			  AND ($1 = '' OR account_id = $1)
// 			GROUP BY COALESCE(region, 'unknown')
// 		) combined
// 		GROUP BY combined.region
// 		ORDER BY combined.region`,
// 		repository.Schema, repository.Schema)

// 	rows, err := r.db.DB.QueryContext(ctx, query, f.AccountID, f.IdentityType)
// 	if err != nil {
// 		return nil, fmt.Errorf("identities by region breakdown: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]models.RegionIdentityBreakdown, 0)
// 	for rows.Next() {
// 		var row models.RegionIdentityBreakdown
// 		if err := rows.Scan(&row.Region, &row.IdentityCount, &row.CredentialCount); err != nil {
// 			return nil, fmt.Errorf("scan region breakdown row: %w", err)
// 		}
// 		breakdown = append(breakdown, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate region breakdown rows: %w", err)
// 	}

// 	return &models.IdentitiesByRegionResponse{
// 		TotalRegions: len(breakdown),
// 		Breakdown:    breakdown,
// 	}, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByRegionFilter struct {
// 	AccountID    string
// 	IdentityType string
// }

// type IdentitiesByRegionRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
// 	return &IdentitiesByRegionRepository{db: db}
// }

// func (r *IdentitiesByRegionRepository) ValidIdentityType(ctx context.Context, identityType string) (bool, error) {
// 	if identityType == "" {
// 		return true, nil
// 	}
// 	query := fmt.Sprintf(`
// 		SELECT EXISTS (
// 			SELECT 1 FROM %s.identities WHERE identity_type = $1 AND %s
// 		)`, repository.Schema, repository.ScanScopeCondition())

// 	var exists bool
// 	err := r.db.DB.QueryRowContext(ctx, query, identityType).Scan(&exists)
// 	if err != nil {
// 		return false, fmt.Errorf("validate identity_type: %w", err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
// 	scanCond := repository.ScanScopeCondition()

// 	query := fmt.Sprintf(`
// 		SELECT
// 			combined.region,
// 			SUM(combined.identity_count)::int   AS identity_count,
// 			SUM(combined.credential_count)::int AS credential_count
// 		FROM (
// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				COUNT(*) AS identity_count,
// 				0        AS credential_count
// 			FROM %[1]s.identities
// 			WHERE deleted_at IS NULL
// 			  AND %[2]s
// 			  AND ($1 = '' OR account_id = $1)
// 			  AND ($2 = '' OR identity_type = $2)
// 			GROUP BY COALESCE(region, 'unknown')

// 			UNION ALL

// 			SELECT
// 				COALESCE(region, 'unknown') AS region,
// 				0 AS identity_count,
// 				COUNT(*) AS credential_count
// 			FROM %[1]s.credentials
// 			WHERE deleted_at IS NULL
// 			  AND %[2]s
// 			  AND ($1 = '' OR account_id = $1)
// 			GROUP BY COALESCE(region, 'unknown')
// 		) combined
// 		GROUP BY combined.region
// 		ORDER BY combined.region`,
// 		repository.Schema, scanCond)

// 	rows, err := r.db.DB.QueryContext(ctx, query, f.AccountID, f.IdentityType)
// 	if err != nil {
// 		return nil, fmt.Errorf("identities by region breakdown: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]models.RegionIdentityBreakdown, 0)
// 	for rows.Next() {
// 		var row models.RegionIdentityBreakdown
// 		if err := rows.Scan(&row.Region, &row.IdentityCount, &row.CredentialCount); err != nil {
// 			return nil, fmt.Errorf("scan region breakdown row: %w", err)
// 		}
// 		breakdown = append(breakdown, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate region breakdown rows: %w", err)
// 	}

// 	return &models.IdentitiesByRegionResponse{
// 		TotalRegions: len(breakdown),
// 		Breakdown:    breakdown,
// 	}, nil
// }

package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesByRegionFilter struct {
	AccountID    string
	IdentityType string
}

type IdentitiesByRegionRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesByRegionRepository(db *repository.PostgresDB) *IdentitiesByRegionRepository {
	return &IdentitiesByRegionRepository{db: db}
}

// ValidIdentityType checks whether the given identity_type value actually
// exists in the identities table — queried live, not hardcoded.
func (r *IdentitiesByRegionRepository) ValidIdentityType(ctx context.Context, identityType string) (bool, error) {
	if identityType == "" {
		return true, nil // empty = no filter, always valid
	}
	query := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1 FROM %s.identities WHERE identity_type = $1
			  AND %s
		)`, repository.Schema, repository.LatestScanFilter)

	var exists bool
	err := r.db.DB.QueryRowContext(ctx, query, identityType).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("validate identity_type: %w", err)
	}
	return exists, nil
}

func (r *IdentitiesByRegionRepository) Breakdown(ctx context.Context, f IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
	query := fmt.Sprintf(`
		SELECT
			combined.region,
			SUM(combined.identity_count)::int   AS identity_count,
			SUM(combined.credential_count)::int AS credential_count
		FROM (
			SELECT
				COALESCE(region, 'unknown') AS region,
				COUNT(*) AS identity_count,
				0        AS credential_count
			FROM %s.identities
			WHERE deleted_at IS NULL
			  AND %s
			  AND ($1 = '' OR account_id = $1)
			  AND ($2 = '' OR identity_type = $2)
			GROUP BY COALESCE(region, 'unknown')

			UNION ALL

			SELECT
				COALESCE(region, 'unknown') AS region,
				0 AS identity_count,
				COUNT(*) AS credential_count
			FROM %s.credentials
			WHERE deleted_at IS NULL
			  AND %s
			  AND ($1 = '' OR account_id = $1)
			GROUP BY COALESCE(region, 'unknown')
		) combined
		GROUP BY combined.region
		ORDER BY combined.region`,
		repository.Schema, repository.LatestScanFilter, repository.Schema, repository.LatestScanFilter)

	rows, err := r.db.DB.QueryContext(ctx, query, f.AccountID, f.IdentityType)
	if err != nil {
		return nil, fmt.Errorf("identities by region breakdown: %w", err)
	}
	defer rows.Close()

	breakdown := make([]models.RegionIdentityBreakdown, 0)
	for rows.Next() {
		var row models.RegionIdentityBreakdown
		if err := rows.Scan(&row.Region, &row.IdentityCount, &row.CredentialCount); err != nil {
			return nil, fmt.Errorf("scan region breakdown row: %w", err)
		}
		breakdown = append(breakdown, row)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate region breakdown rows: %w", err)
	}

	return &models.IdentitiesByRegionResponse{
		TotalRegions: len(breakdown),
		Breakdown:    breakdown,
	}, nil
}
