// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	modelsdashboard "nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByTypeRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByTypeRepository(db *repository.PostgresDB) *IdentitiesByTypeRepository {
// 	return &IdentitiesByTypeRepository{db: db}
// }

// func (r *IdentitiesByTypeRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	return r.existsIn(ctx, "account_id", accountID)
// }
// func (r *IdentitiesByTypeRepository) RegionExists(ctx context.Context, region string) (bool, error) {
// 	return r.existsIn(ctx, "region", region)
// }
// func (r *IdentitiesByTypeRepository) StatusExists(ctx context.Context, status string) (bool, error) {
// 	return r.existsIn(ctx, "status", status)
// }
// func (r *IdentitiesByTypeRepository) FunctionalClassExists(ctx context.Context, functionalClass string) (bool, error) {
// 	return r.existsIn(ctx, "functional_class", functionalClass)
// }

// func (r *IdentitiesByTypeRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
// 	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL)`, repository.Schema, column)
// 	var exists bool
// 	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
// 		return false, fmt.Errorf("check %s exists: %w", column, err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesByTypeRepository) buildWhere(f modelsdashboard.IdentityByTypeFilter) (string, []interface{}) {
// 	clauses := []string{"deleted_at IS NULL"}
// 	args := []interface{}{}
// 	idx := 1
// 	add := func(col string, val interface{}) {
// 		clauses = append(clauses, fmt.Sprintf("%s = $%d", col, idx))
// 		args = append(args, val)
// 		idx++
// 	}
// 	if f.AccountID != "" {
// 		add("account_id", f.AccountID)
// 	}
// 	if f.Region != "" {
// 		add("region", f.Region)
// 	}
// 	if f.Status != "" {
// 		add("status", f.Status)
// 	}
// 	if f.FunctionalClass != "" {
// 		add("functional_class", f.FunctionalClass)
// 	}
// 	return strings.Join(clauses, " AND "), args
// }

// func (r *IdentitiesByTypeRepository) ByType(ctx context.Context, f modelsdashboard.IdentityByTypeFilter) (*modelsdashboard.IdentitiesByTypeResponse, error) {
// 	where, args := r.buildWhere(f)

// 	query := fmt.Sprintf(`
// 		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
// 		FROM %s.identities
// 		WHERE %s
// 		GROUP BY identity_type
// 		ORDER BY cnt DESC, identity_type ASC
// 	`, repository.Schema, where)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("identities by type: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]modelsdashboard.IdentityTypeCount, 0)
// 	total := 0
// 	for rows.Next() {
// 		var row modelsdashboard.IdentityTypeCount
// 		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
// 			return nil, fmt.Errorf("scan identity type count: %w", err)
// 		}
// 		total += row.Count
// 		breakdown = append(breakdown, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, err
// 	}

// 	return &modelsdashboard.IdentitiesByTypeResponse{
// 		Total:     total,
// 		Breakdown: breakdown,
// 	}, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	modelsdashboard "nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesByTypeRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesByTypeRepository(db *repository.PostgresDB) *IdentitiesByTypeRepository {
// 	return &IdentitiesByTypeRepository{db: db}
// }

// func (r *IdentitiesByTypeRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	return r.existsIn(ctx, "account_id", accountID)
// }
// func (r *IdentitiesByTypeRepository) RegionExists(ctx context.Context, region string) (bool, error) {
// 	return r.existsIn(ctx, "region", region)
// }
// func (r *IdentitiesByTypeRepository) StatusExists(ctx context.Context, status string) (bool, error) {
// 	return r.existsIn(ctx, "status", status)
// }
// func (r *IdentitiesByTypeRepository) FunctionalClassExists(ctx context.Context, functionalClass string) (bool, error) {
// 	return r.existsIn(ctx, "functional_class", functionalClass)
// }

// func (r *IdentitiesByTypeRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
// 	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL AND %s)`,
// 		repository.Schema, column, repository.ScanScopeCondition())
// 	var exists bool
// 	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
// 		return false, fmt.Errorf("check %s exists: %w", column, err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesByTypeRepository) buildWhere(f modelsdashboard.IdentityByTypeFilter) (string, []interface{}) {
// 	clauses := []string{"deleted_at IS NULL", repository.ScanScopeCondition()}
// 	args := []interface{}{}
// 	idx := 1
// 	add := func(col string, val interface{}) {
// 		clauses = append(clauses, fmt.Sprintf("%s = $%d", col, idx))
// 		args = append(args, val)
// 		idx++
// 	}
// 	if f.AccountID != "" {
// 		add("account_id", f.AccountID)
// 	}
// 	if f.Region != "" {
// 		add("region", f.Region)
// 	}
// 	if f.Status != "" {
// 		add("status", f.Status)
// 	}
// 	if f.FunctionalClass != "" {
// 		add("functional_class", f.FunctionalClass)
// 	}
// 	return strings.Join(clauses, " AND "), args
// }

// func (r *IdentitiesByTypeRepository) ByType(ctx context.Context, f modelsdashboard.IdentityByTypeFilter) (*modelsdashboard.IdentitiesByTypeResponse, error) {
// 	where, args := r.buildWhere(f)

// 	query := fmt.Sprintf(`
// 		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
// 		FROM %s.identities
// 		WHERE %s
// 		GROUP BY identity_type
// 		ORDER BY cnt DESC, identity_type ASC
// 	`, repository.Schema, where)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("identities by type: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]modelsdashboard.IdentityTypeCount, 0)
// 	total := 0
// 	for rows.Next() {
// 		var row modelsdashboard.IdentityTypeCount
// 		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
// 			return nil, fmt.Errorf("scan identity type count: %w", err)
// 		}
// 		total += row.Count
// 		breakdown = append(breakdown, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, err
// 	}

// 	return &modelsdashboard.IdentitiesByTypeResponse{
// 		Total:     total,
// 		Breakdown: breakdown,
// 	}, nil
// }

package dashboard

import (
	"context"
	"fmt"
	"strings"

	modelsdashboard "nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesByTypeRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesByTypeRepository(db *repository.PostgresDB) *IdentitiesByTypeRepository {
	return &IdentitiesByTypeRepository{db: db}
}

func (r *IdentitiesByTypeRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return r.existsIn(ctx, "account_id", accountID)
}
func (r *IdentitiesByTypeRepository) RegionExists(ctx context.Context, region string) (bool, error) {
	return r.existsIn(ctx, "region", region)
}
func (r *IdentitiesByTypeRepository) StatusExists(ctx context.Context, status string) (bool, error) {
	return r.existsIn(ctx, "status", status)
}
func (r *IdentitiesByTypeRepository) FunctionalClassExists(ctx context.Context, functionalClass string) (bool, error) {
	return r.existsIn(ctx, "functional_class", functionalClass)
}

func (r *IdentitiesByTypeRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL AND `+repository.LatestScanFilter+`)`, repository.Schema, column)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
		return false, fmt.Errorf("check %s exists: %w", column, err)
	}
	return exists, nil
}

func (r *IdentitiesByTypeRepository) buildWhere(f modelsdashboard.IdentityByTypeFilter) (string, []interface{}) {
	clauses := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}
	args := []interface{}{}
	idx := 1
	add := func(col string, val interface{}) {
		clauses = append(clauses, fmt.Sprintf("%s = $%d", col, idx))
		args = append(args, val)
		idx++
	}
	if f.AccountID != "" {
		add("account_id", f.AccountID)
	}
	if f.Region != "" {
		add("region", f.Region)
	}
	if f.Status != "" {
		add("status", f.Status)
	}
	if f.FunctionalClass != "" {
		add("functional_class", f.FunctionalClass)
	}
	return strings.Join(clauses, " AND "), args
}

func (r *IdentitiesByTypeRepository) ByType(ctx context.Context, f modelsdashboard.IdentityByTypeFilter) (*modelsdashboard.IdentitiesByTypeResponse, error) {
	where, args := r.buildWhere(f)

	query := fmt.Sprintf(`
		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
		FROM %s.identities
		WHERE %s
		GROUP BY identity_type
		ORDER BY cnt DESC, identity_type ASC
	`, repository.Schema, where)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("identities by type: %w", err)
	}
	defer rows.Close()

	breakdown := make([]modelsdashboard.IdentityTypeCount, 0)
	total := 0
	for rows.Next() {
		var row modelsdashboard.IdentityTypeCount
		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
			return nil, fmt.Errorf("scan identity type count: %w", err)
		}
		total += row.Count
		breakdown = append(breakdown, row)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return &modelsdashboard.IdentitiesByTypeResponse{
		Total:     total,
		Breakdown: breakdown,
	}, nil
}
