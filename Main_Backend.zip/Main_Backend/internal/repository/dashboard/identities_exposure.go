// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	modelsdashboard "nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesExposureRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesExposureRepository(db *repository.PostgresDB) *IdentitiesExposureRepository {
// 	return &IdentitiesExposureRepository{db: db}
// }

// func (r *IdentitiesExposureRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE account_id = $1 AND deleted_at IS NULL)`, repository.Schema)
// 	var exists bool
// 	if err := r.db.DB.QueryRowContext(ctx, query, accountID).Scan(&exists); err != nil {
// 		return false, fmt.Errorf("check account_id exists: %w", err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesExposureRepository) accountFilter(f modelsdashboard.IdentityExposureFilter) (string, []interface{}) {
// 	if f.AccountID == "" {
// 		return "", []interface{}{}
// 	}
// 	return " AND account_id = $1", []interface{}{f.AccountID}
// }

// func (r *IdentitiesExposureRepository) byTypeBucket(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (modelsdashboard.ExposureBucket, error) {
// 	accFilter, args := r.accountFilter(f)

// 	totalQuery := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND %s %s`, repository.Schema, whereExtra, accFilter)
// 	var total int
// 	if err := r.db.DB.QueryRowContext(ctx, totalQuery, args...).Scan(&total); err != nil {
// 		return modelsdashboard.ExposureBucket{}, fmt.Errorf("count bucket total: %w", err)
// 	}

// 	typeQuery := fmt.Sprintf(`
// 		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
// 		FROM %s.identities
// 		WHERE deleted_at IS NULL AND %s %s
// 		GROUP BY identity_type
// 		ORDER BY cnt DESC, identity_type ASC
// 	`, repository.Schema, whereExtra, accFilter)

// 	rows, err := r.db.DB.QueryContext(ctx, typeQuery, args...)
// 	if err != nil {
// 		return modelsdashboard.ExposureBucket{}, fmt.Errorf("bucket by type: %w", err)
// 	}
// 	defer rows.Close()

// 	byType := make([]modelsdashboard.ExposureTypeCount, 0)
// 	for rows.Next() {
// 		var row modelsdashboard.ExposureTypeCount
// 		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
// 			return modelsdashboard.ExposureBucket{}, fmt.Errorf("scan bucket row: %w", err)
// 		}
// 		byType = append(byType, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return modelsdashboard.ExposureBucket{}, err
// 	}

// 	return modelsdashboard.ExposureBucket{Total: total, ByType: byType}, nil
// }

// func (r *IdentitiesExposureRepository) scalarCount(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (int, error) {
// 	accFilter, args := r.accountFilter(f)
// 	query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND %s %s`, repository.Schema, whereExtra, accFilter)
// 	var count int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&count); err != nil {
// 		return 0, fmt.Errorf("scalar count: %w", err)
// 	}
// 	return count, nil
// }

// func (r *IdentitiesExposureRepository) Exposure(ctx context.Context, f modelsdashboard.IdentityExposureFilter) (*modelsdashboard.IdentityExposureResponse, error) {
// 	publicly, err := r.byTypeBucket(ctx, "is_publicly_accessible = true", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	dormant, err := r.byTypeBucket(ctx, "last_activity_at IS NOT NULL AND last_activity_at < now() - interval '90 days'", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	noActivityTracked, err := r.scalarCount(ctx, "last_activity_at IS NULL", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	missingOwner, err := r.scalarCount(ctx, "(owner IS NULL OR owner = '')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	missingEnvironment, err := r.scalarCount(ctx, "(environment IS NULL OR environment = '')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	// ASSUMPTION: "not in IaC" is derived from type_attributes->>'managed_by_iac'.
// 	// Confirm actual column/JSON key and adjust this one clause if different.
// 	notInIaC, err := r.scalarCount(ctx, "(type_attributes->>'managed_by_iac' IS DISTINCT FROM 'true')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	return &modelsdashboard.IdentityExposureResponse{
// 		PubliclyAccessible:    publicly,
// 		Dormant90d:            dormant,
// 		NoActivityTracked:     noActivityTracked,
// 		MissingOwnerTag:       missingOwner,
// 		MissingEnvironmentTag: missingEnvironment,
// 		NotInIaC:              notInIaC,
// 	}, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	modelsdashboard "nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentitiesExposureRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentitiesExposureRepository(db *repository.PostgresDB) *IdentitiesExposureRepository {
// 	return &IdentitiesExposureRepository{db: db}
// }

// func (r *IdentitiesExposureRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE account_id = $1 AND deleted_at IS NULL AND %s)`,
// 		repository.Schema, repository.ScanScopeCondition())
// 	var exists bool
// 	if err := r.db.DB.QueryRowContext(ctx, query, accountID).Scan(&exists); err != nil {
// 		return false, fmt.Errorf("check account_id exists: %w", err)
// 	}
// 	return exists, nil
// }

// func (r *IdentitiesExposureRepository) accountFilter(f modelsdashboard.IdentityExposureFilter) (string, []interface{}) {
// 	if f.AccountID == "" {
// 		return "", []interface{}{}
// 	}
// 	return " AND account_id = $1", []interface{}{f.AccountID}
// }

// func (r *IdentitiesExposureRepository) byTypeBucket(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (modelsdashboard.ExposureBucket, error) {
// 	accFilter, args := r.accountFilter(f)
// 	scanCond := repository.ScanScopeCondition()

// 	totalQuery := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND %s AND %s %s`, repository.Schema, whereExtra, scanCond, accFilter)
// 	var total int
// 	if err := r.db.DB.QueryRowContext(ctx, totalQuery, args...).Scan(&total); err != nil {
// 		return modelsdashboard.ExposureBucket{}, fmt.Errorf("count bucket total: %w", err)
// 	}

// 	typeQuery := fmt.Sprintf(`
// 		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
// 		FROM %s.identities
// 		WHERE deleted_at IS NULL AND %s AND %s %s
// 		GROUP BY identity_type
// 		ORDER BY cnt DESC, identity_type ASC
// 	`, repository.Schema, whereExtra, scanCond, accFilter)

// 	rows, err := r.db.DB.QueryContext(ctx, typeQuery, args...)
// 	if err != nil {
// 		return modelsdashboard.ExposureBucket{}, fmt.Errorf("bucket by type: %w", err)
// 	}
// 	defer rows.Close()

// 	byType := make([]modelsdashboard.ExposureTypeCount, 0)
// 	for rows.Next() {
// 		var row modelsdashboard.ExposureTypeCount
// 		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
// 			return modelsdashboard.ExposureBucket{}, fmt.Errorf("scan bucket row: %w", err)
// 		}
// 		byType = append(byType, row)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return modelsdashboard.ExposureBucket{}, err
// 	}

// 	return modelsdashboard.ExposureBucket{Total: total, ByType: byType}, nil
// }

// func (r *IdentitiesExposureRepository) scalarCount(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (int, error) {
// 	accFilter, args := r.accountFilter(f)
// 	scanCond := repository.ScanScopeCondition()
// 	query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND %s AND %s %s`, repository.Schema, whereExtra, scanCond, accFilter)
// 	var count int
// 	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&count); err != nil {
// 		return 0, fmt.Errorf("scalar count: %w", err)
// 	}
// 	return count, nil
// }

// func (r *IdentitiesExposureRepository) Exposure(ctx context.Context, f modelsdashboard.IdentityExposureFilter) (*modelsdashboard.IdentityExposureResponse, error) {
// 	publicly, err := r.byTypeBucket(ctx, "is_publicly_accessible = true", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	dormant, err := r.byTypeBucket(ctx, "last_activity_at IS NOT NULL AND last_activity_at < now() - interval '90 days'", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	noActivityTracked, err := r.scalarCount(ctx, "last_activity_at IS NULL", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	missingOwner, err := r.scalarCount(ctx, "(owner IS NULL OR owner = '')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	missingEnvironment, err := r.scalarCount(ctx, "(environment IS NULL OR environment = '')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	notInIaC, err := r.scalarCount(ctx, "(type_attributes->>'managed_by_iac' IS DISTINCT FROM 'true')", f)
// 	if err != nil {
// 		return nil, err
// 	}

// 	return &modelsdashboard.IdentityExposureResponse{
// 		PubliclyAccessible:    publicly,
// 		Dormant90d:            dormant,
// 		NoActivityTracked:     noActivityTracked,
// 		MissingOwnerTag:       missingOwner,
// 		MissingEnvironmentTag: missingEnvironment,
// 		NotInIaC:              notInIaC,
// 	}, nil
// }

package dashboard

import (
	"context"
	"fmt"

	modelsdashboard "nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type IdentitiesExposureRepository struct {
	db *repository.PostgresDB
}

func NewIdentitiesExposureRepository(db *repository.PostgresDB) *IdentitiesExposureRepository {
	return &IdentitiesExposureRepository{db: db}
}

func (r *IdentitiesExposureRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE account_id = $1 AND deleted_at IS NULL AND `+repository.LatestScanFilter+`)`, repository.Schema)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, accountID).Scan(&exists); err != nil {
		return false, fmt.Errorf("check account_id exists: %w", err)
	}
	return exists, nil
}

func (r *IdentitiesExposureRepository) accountFilter(f modelsdashboard.IdentityExposureFilter) (string, []interface{}) {
	if f.AccountID == "" {
		return "", []interface{}{}
	}
	return " AND account_id = $1", []interface{}{f.AccountID}
}

func (r *IdentitiesExposureRepository) byTypeBucket(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (modelsdashboard.ExposureBucket, error) {
	accFilter, args := r.accountFilter(f)

	totalQuery := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND `+repository.LatestScanFilter+` AND %s %s`, repository.Schema, whereExtra, accFilter)
	var total int
	if err := r.db.DB.QueryRowContext(ctx, totalQuery, args...).Scan(&total); err != nil {
		return modelsdashboard.ExposureBucket{}, fmt.Errorf("count bucket total: %w", err)
	}

	typeQuery := fmt.Sprintf(`
		SELECT COALESCE(identity_type, 'unknown') AS identity_type, COUNT(*) AS cnt
		FROM %s.identities
		WHERE deleted_at IS NULL AND `+repository.LatestScanFilter+` AND %s %s
		GROUP BY identity_type
		ORDER BY cnt DESC, identity_type ASC
	`, repository.Schema, whereExtra, accFilter)

	rows, err := r.db.DB.QueryContext(ctx, typeQuery, args...)
	if err != nil {
		return modelsdashboard.ExposureBucket{}, fmt.Errorf("bucket by type: %w", err)
	}
	defer rows.Close()

	byType := make([]modelsdashboard.ExposureTypeCount, 0)
	for rows.Next() {
		var row modelsdashboard.ExposureTypeCount
		if err := rows.Scan(&row.IdentityType, &row.Count); err != nil {
			return modelsdashboard.ExposureBucket{}, fmt.Errorf("scan bucket row: %w", err)
		}
		byType = append(byType, row)
	}
	if err := rows.Err(); err != nil {
		return modelsdashboard.ExposureBucket{}, err
	}

	return modelsdashboard.ExposureBucket{Total: total, ByType: byType}, nil
}

func (r *IdentitiesExposureRepository) scalarCount(ctx context.Context, whereExtra string, f modelsdashboard.IdentityExposureFilter) (int, error) {
	accFilter, args := r.accountFilter(f)
	query := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE deleted_at IS NULL AND `+repository.LatestScanFilter+` AND %s %s`, repository.Schema, whereExtra, accFilter)
	var count int
	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(&count); err != nil {
		return 0, fmt.Errorf("scalar count: %w", err)
	}
	return count, nil
}

func (r *IdentitiesExposureRepository) Exposure(ctx context.Context, f modelsdashboard.IdentityExposureFilter) (*modelsdashboard.IdentityExposureResponse, error) {
	publicly, err := r.byTypeBucket(ctx, "is_publicly_accessible = true", f)
	if err != nil {
		return nil, err
	}

	dormant, err := r.byTypeBucket(ctx, "last_activity_at IS NOT NULL AND last_activity_at < now() - interval '90 days'", f)
	if err != nil {
		return nil, err
	}

	noActivityTracked, err := r.scalarCount(ctx, "last_activity_at IS NULL", f)
	if err != nil {
		return nil, err
	}

	missingOwner, err := r.scalarCount(ctx, "(owner IS NULL OR owner = '')", f)
	if err != nil {
		return nil, err
	}

	missingEnvironment, err := r.scalarCount(ctx, "(environment IS NULL OR environment = '')", f)
	if err != nil {
		return nil, err
	}

	// ASSUMPTION: "not in IaC" is derived from type_attributes->>'managed_by_iac'.
	// Confirm actual column/JSON key and adjust this one clause if different.
	notInIaC, err := r.scalarCount(ctx, "(type_attributes->>'managed_by_iac' IS DISTINCT FROM 'true')", f)
	if err != nil {
		return nil, err
	}

	return &modelsdashboard.IdentityExposureResponse{
		PubliclyAccessible:    publicly,
		Dormant90d:            dormant,
		NoActivityTracked:     noActivityTracked,
		MissingOwnerTag:       missingOwner,
		MissingEnvironmentTag: missingEnvironment,
		NotInIaC:              notInIaC,
	}, nil
}
