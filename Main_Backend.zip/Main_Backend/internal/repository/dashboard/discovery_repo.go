// package dashboard

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// const (
// 	DiscoveryTypeIdentities  = "identities"
// 	DiscoveryTypeCredentials = "credentials"
// 	DiscoveryTypeBoth        = "both"

// 	DiscoveryEventNew     = "new"
// 	DiscoveryEventRemoved = "removed"
// 	DiscoveryEventBoth    = "both"
// )

// type DiscoveryFilter struct {
// 	Hours int
// 	Type  string
// 	Event string
// 	Limit int
// }

// type DiscoveryRepository struct {
// 	db *repository.PostgresDB
// }

// func NewDiscoveryRepository(db *repository.PostgresDB) *DiscoveryRepository {
// 	return &DiscoveryRepository{db: db}
// }

// // GetRecentDiscoveries unions new/removed events from both the identities
// // table and the credentials table. Each row's "entity" is now determined
// // simply by which table it came from — no guessing based on identity_type.
// func (r *DiscoveryRepository) GetRecentDiscoveries(ctx context.Context, f DiscoveryFilter) (*models.RecentDiscoveriesResponse, error) {
// 	entityWhere := ""
// 	switch f.Type {
// 	case DiscoveryTypeIdentities:
// 		entityWhere = "WHERE entity = 'identity'"
// 	case DiscoveryTypeCredentials:
// 		entityWhere = "WHERE entity = 'credential'"
// 	}

// 	cte := fmt.Sprintf(`
// 		WITH ev AS (
// 			SELECT 'new' AS event, 'identity' AS entity,
// 			       arn, name, identity_type AS type, account_id, region,
// 			       COALESCE(first_seen_at, created_at) AS discovered_at
// 			FROM %[1]s.identities
// 			WHERE COALESCE(first_seen_at, created_at) >= NOW() - make_interval(hours => $1::int)

// 			UNION ALL

// 			SELECT 'removed' AS event, 'identity' AS entity,
// 			       arn, name, identity_type AS type, account_id, region,
// 			       deleted_at AS discovered_at
// 			FROM %[1]s.identities
// 			WHERE deleted_at IS NOT NULL
// 			  AND deleted_at >= NOW() - make_interval(hours => $1::int)

// 			UNION ALL

// 			SELECT 'new' AS event, 'credential' AS entity,
// 			       arn, name, credential_type AS type, account_id, region,
// 			       COALESCE(first_seen_at, created_at) AS discovered_at
// 			FROM %[1]s.credentials
// 			WHERE COALESCE(first_seen_at, created_at) >= NOW() - make_interval(hours => $1::int)

// 			UNION ALL

// 			SELECT 'removed' AS event, 'credential' AS entity,
// 			       arn, name, credential_type AS type, account_id, region,
// 			       deleted_at AS discovered_at
// 			FROM %[1]s.credentials
// 			WHERE deleted_at IS NOT NULL
// 			  AND deleted_at >= NOW() - make_interval(hours => $1::int)
// 		),
// 		filtered AS (
// 			SELECT * FROM ev %[2]s
// 		)`, repository.Schema, entityWhere)

// 	totalsQuery := cte + `
// 		SELECT COUNT(*) FILTER (WHERE event = 'new'),
// 		       COUNT(*) FILTER (WHERE event = 'removed')
// 		FROM filtered`

// 	resp := &models.RecentDiscoveriesResponse{Discoveries: []models.Discovery{}}
// 	if err := r.db.DB.QueryRowContext(ctx, totalsQuery, f.Hours).
// 		Scan(&resp.TotalNew, &resp.TotalRemoved); err != nil {
// 		return nil, fmt.Errorf("count recent discoveries: %w", err)
// 	}

// 	eventWhere := ""
// 	switch f.Event {
// 	case DiscoveryEventNew:
// 		eventWhere = "WHERE event = 'new'"
// 	case DiscoveryEventRemoved:
// 		eventWhere = "WHERE event = 'removed'"
// 	}

// 	listQuery := cte + `
// 		SELECT event, entity, arn, name, type, account_id, region, discovered_at
// 		FROM filtered
// 		` + eventWhere + `
// 		ORDER BY discovered_at DESC, arn
// 		LIMIT $2`

// 	rows, err := r.db.DB.QueryContext(ctx, listQuery, f.Hours, f.Limit)
// 	if err != nil {
// 		return nil, fmt.Errorf("query recent discoveries: %w", err)
// 	}
// 	defer rows.Close()

// 	for rows.Next() {
// 		var d models.Discovery
// 		var arn, name, typ, account, region sql.NullString
// 		var at time.Time

// 		if err := rows.Scan(&d.Event, &d.Entity, &arn, &name, &typ, &account, &region, &at); err != nil {
// 			return nil, fmt.Errorf("scan discovery row: %w", err)
// 		}

// 		d.ARN = nullStr(arn)
// 		d.Name = nullStr(name)
// 		d.Type = nullStr(typ)
// 		d.AccountID = nullStr(account)
// 		d.Region = nullStr(region)
// 		d.DiscoveredAt = at.UTC().Format(time.RFC3339)

// 		resp.Discoveries = append(resp.Discoveries, d)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate discovery rows: %w", err)
// 	}

// 	return resp, nil
// }

// func nullStr(s sql.NullString) *string {
// 	if !s.Valid || strings.TrimSpace(s.String) == "" {
// 		return nil
// 	}
// 	v := s.String
// 	return &v
// }

package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

const (
	DiscoveryTypeIdentities  = "identities"
	DiscoveryTypeCredentials = "credentials"
	DiscoveryTypeBoth        = "both"

	DiscoveryEventNew     = "new"
	DiscoveryEventRemoved = "removed"
	DiscoveryEventBoth    = "both"
)

type DiscoveryFilter struct {
	Hours int
	Type  string
	Event string
	Limit int
}

type DiscoveryRepository struct {
	db *repository.PostgresDB
}

func NewDiscoveryRepository(db *repository.PostgresDB) *DiscoveryRepository {
	return &DiscoveryRepository{db: db}
}

// GetRecentDiscoveries unions new/removed events from both the identities
// table and the credentials table. Each row's "entity" is now determined
// simply by which table it came from — no guessing based on identity_type.
func (r *DiscoveryRepository) GetRecentDiscoveries(ctx context.Context, f DiscoveryFilter) (*models.RecentDiscoveriesResponse, error) {
	entityWhere := ""
	switch f.Type {
	case DiscoveryTypeIdentities:
		entityWhere = "WHERE entity = 'identity'"
	case DiscoveryTypeCredentials:
		entityWhere = "WHERE entity = 'credential'"
	}

	cte := fmt.Sprintf(`
		WITH ev AS (
			SELECT 'new' AS event, 'identity' AS entity,
			       arn, name, identity_type AS type, account_id, region,
			       COALESCE(first_seen_at, created_at) AS discovered_at
			FROM %[1]s.identities
			WHERE %[3]s
			  AND COALESCE(first_seen_at, created_at) >= NOW() - make_interval(hours => $1::int)

			UNION ALL

			SELECT 'removed' AS event, 'identity' AS entity,
			       arn, name, identity_type AS type, account_id, region,
			       deleted_at AS discovered_at
			FROM %[1]s.identities
			WHERE %[3]s
			  AND deleted_at IS NOT NULL
			  AND deleted_at >= NOW() - make_interval(hours => $1::int)

			UNION ALL

			SELECT 'new' AS event, 'credential' AS entity,
			       arn, name, credential_type AS type, account_id, region,
			       COALESCE(first_seen_at, created_at) AS discovered_at
			FROM %[1]s.credentials
			WHERE %[3]s
			  AND COALESCE(first_seen_at, created_at) >= NOW() - make_interval(hours => $1::int)

			UNION ALL

			SELECT 'removed' AS event, 'credential' AS entity,
			       arn, name, credential_type AS type, account_id, region,
			       deleted_at AS discovered_at
			FROM %[1]s.credentials
			WHERE %[3]s
			  AND deleted_at IS NOT NULL
			  AND deleted_at >= NOW() - make_interval(hours => $1::int)
		),
		filtered AS (
			SELECT * FROM ev %[2]s
		)`, repository.Schema, entityWhere, repository.LatestScanFilter)

	totalsQuery := cte + `
		SELECT COUNT(*) FILTER (WHERE event = 'new'),
		       COUNT(*) FILTER (WHERE event = 'removed')
		FROM filtered`

	resp := &models.RecentDiscoveriesResponse{Discoveries: []models.Discovery{}}
	if err := r.db.DB.QueryRowContext(ctx, totalsQuery, f.Hours).
		Scan(&resp.TotalNew, &resp.TotalRemoved); err != nil {
		return nil, fmt.Errorf("count recent discoveries: %w", err)
	}

	eventWhere := ""
	switch f.Event {
	case DiscoveryEventNew:
		eventWhere = "WHERE event = 'new'"
	case DiscoveryEventRemoved:
		eventWhere = "WHERE event = 'removed'"
	}

	listQuery := cte + `
		SELECT event, entity, arn, name, type, account_id, region, discovered_at
		FROM filtered
		` + eventWhere + `
		ORDER BY discovered_at DESC, arn
		LIMIT $2`

	rows, err := r.db.DB.QueryContext(ctx, listQuery, f.Hours, f.Limit)
	if err != nil {
		return nil, fmt.Errorf("query recent discoveries: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var d models.Discovery
		var arn, name, typ, account, region sql.NullString
		var at time.Time

		if err := rows.Scan(&d.Event, &d.Entity, &arn, &name, &typ, &account, &region, &at); err != nil {
			return nil, fmt.Errorf("scan discovery row: %w", err)
		}

		d.ARN = nullStr(arn)
		d.Name = nullStr(name)
		d.Type = nullStr(typ)
		d.AccountID = nullStr(account)
		d.Region = nullStr(region)
		d.DiscoveredAt = at.UTC().Format(time.RFC3339)

		resp.Discoveries = append(resp.Discoveries, d)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate discovery rows: %w", err)
	}

	return resp, nil
}

func nullStr(s sql.NullString) *string {
	if !s.Valid || strings.TrimSpace(s.String) == "" {
		return nil
	}
	v := s.String
	return &v
}
