// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type CredentialsByTypeFilter struct {
// 	AccountID string
// 	Region    string
// 	Status    string
// }

// type CredentialsByTypeRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialsByTypeRepository(db *repository.PostgresDB) *CredentialsByTypeRepository {
// 	return &CredentialsByTypeRepository{db: db}
// }

// func (r *CredentialsByTypeRepository) Breakdown(ctx context.Context, f CredentialsByTypeFilter) (*models.CredentialsByTypeResponse, error) {
// 	conditions := "deleted_at IS NULL"
// 	var args []interface{}
// 	argIdx := 1

// 	if f.AccountID != "" {
// 		conditions += fmt.Sprintf(" AND account_id = $%d", argIdx)
// 		args = append(args, f.AccountID)
// 		argIdx++
// 	}

// 	if f.Region != "" {
// 		conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 		args = append(args, f.Region)
// 		argIdx++
// 	}

// 	if f.Status != "" {
// 		conditions += fmt.Sprintf(" AND status = $%d", argIdx)
// 		args = append(args, f.Status)
// 		argIdx++
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT credential_type, COUNT(*)
// 		FROM %s.credentials
// 		WHERE %s
// 		GROUP BY credential_type
// 		ORDER BY COUNT(*) DESC
// 	`, repository.Schema, conditions)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("count credentials by type: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]models.CredentialTypeBreakdown, 0)
// 	total := 0

// 	for rows.Next() {
// 		var credentialType string
// 		var count int
// 		if err := rows.Scan(&credentialType, &count); err != nil {
// 			return nil, fmt.Errorf("scan credential type count: %w", err)
// 		}
// 		breakdown = append(breakdown, models.CredentialTypeBreakdown{
// 			CredentialType: credentialType,
// 			Count:          count,
// 		})
// 		total += count
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate credential type counts: %w", err)
// 	}

// 	return &models.CredentialsByTypeResponse{
// 		Total:     total,
// 		Breakdown: breakdown,
// 	}, nil
// }

// package dashboard

// import (
// 	"context"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// )

// type CredentialsByTypeFilter struct {
// 	AccountID string
// 	Region    string
// 	Status    string
// }

// type CredentialsByTypeRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialsByTypeRepository(db *repository.PostgresDB) *CredentialsByTypeRepository {
// 	return &CredentialsByTypeRepository{db: db}
// }

// func (r *CredentialsByTypeRepository) Breakdown(ctx context.Context, f CredentialsByTypeFilter) (*models.CredentialsByTypeResponse, error) {
// 	conditions := "deleted_at IS NULL AND " + repository.ScanScopeCondition()
// 	var args []interface{}
// 	argIdx := 1

// 	if f.AccountID != "" {
// 		conditions += fmt.Sprintf(" AND account_id = $%d", argIdx)
// 		args = append(args, f.AccountID)
// 		argIdx++
// 	}

// 	if f.Region != "" {
// 		conditions += fmt.Sprintf(" AND region = $%d", argIdx)
// 		args = append(args, f.Region)
// 		argIdx++
// 	}

// 	if f.Status != "" {
// 		conditions += fmt.Sprintf(" AND status = $%d", argIdx)
// 		args = append(args, f.Status)
// 		argIdx++
// 	}

// 	query := fmt.Sprintf(`
// 		SELECT credential_type, COUNT(*)
// 		FROM %s.credentials
// 		WHERE %s
// 		GROUP BY credential_type
// 		ORDER BY COUNT(*) DESC
// 	`, repository.Schema, conditions)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("count credentials by type: %w", err)
// 	}
// 	defer rows.Close()

// 	breakdown := make([]models.CredentialTypeBreakdown, 0)
// 	total := 0

// 	for rows.Next() {
// 		var credentialType string
// 		var count int
// 		if err := rows.Scan(&credentialType, &count); err != nil {
// 			return nil, fmt.Errorf("scan credential type count: %w", err)
// 		}
// 		breakdown = append(breakdown, models.CredentialTypeBreakdown{
// 			CredentialType: credentialType,
// 			Count:          count,
// 		})
// 		total += count
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate credential type counts: %w", err)
// 	}

// 	return &models.CredentialsByTypeResponse{
// 		Total:     total,
// 		Breakdown: breakdown,
// 	}, nil
// }

package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type CredentialsByTypeFilter struct {
	AccountID string
	Region    string
	Status    string
}

type CredentialsByTypeRepository struct {
	db *repository.PostgresDB
}

func NewCredentialsByTypeRepository(db *repository.PostgresDB) *CredentialsByTypeRepository {
	return &CredentialsByTypeRepository{db: db}
}

func (r *CredentialsByTypeRepository) Breakdown(ctx context.Context, f CredentialsByTypeFilter) (*models.CredentialsByTypeResponse, error) {
	conditions := "deleted_at IS NULL AND " + repository.LatestScanFilter
	var args []interface{}
	argIdx := 1

	if f.AccountID != "" {
		conditions += fmt.Sprintf(" AND account_id = $%d", argIdx)
		args = append(args, f.AccountID)
		argIdx++
	}

	if f.Region != "" {
		conditions += fmt.Sprintf(" AND region = $%d", argIdx)
		args = append(args, f.Region)
		argIdx++
	}

	if f.Status != "" {
		conditions += fmt.Sprintf(" AND status = $%d", argIdx)
		args = append(args, f.Status)
		argIdx++
	}

	query := fmt.Sprintf(`
		SELECT credential_type, COUNT(*)
		FROM %s.credentials
		WHERE %s
		GROUP BY credential_type
		ORDER BY COUNT(*) DESC
	`, repository.Schema, conditions)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("count credentials by type: %w", err)
	}
	defer rows.Close()

	breakdown := make([]models.CredentialTypeBreakdown, 0)
	total := 0

	for rows.Next() {
		var credentialType string
		var count int
		if err := rows.Scan(&credentialType, &count); err != nil {
			return nil, fmt.Errorf("scan credential type count: %w", err)
		}
		breakdown = append(breakdown, models.CredentialTypeBreakdown{
			CredentialType: credentialType,
			Count:          count,
		})
		total += count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential type counts: %w", err)
	}

	return &models.CredentialsByTypeResponse{
		Total:     total,
		Breakdown: breakdown,
	}, nil
}
