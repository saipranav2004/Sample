package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type DashboardRepository struct {
	db *PostgresDB
}

func NewDashboardRepository(db *PostgresDB) *DashboardRepository {
	return &DashboardRepository{db: db}
}

// GetSummary calculates top-level metrics for the latest scan (supporting scan isolation)
func (r *DashboardRepository) GetSummary(ctx context.Context, scanID string) (*models.DashboardSummary, error) {
	scanFilter := "scan_id = " + latestCompletedScanSQL
	var args []interface{}

	if scanID != "" {
		scanFilter = "scan_id = $1"
		args = append(args, scanID)
	}

	// ── Oracle → PostgreSQL notes ────────────────────────────────────────
	//   NVL(a, b)                → COALESCE(a, b)
	//   SYSDATE - 90             → NOW() - INTERVAL '90 days'
	//   col = 1 / col = 0        → col IS TRUE / col IS NOT TRUE
	//                               (IS NOT TRUE covers FALSE and NULL in one
	//                                predicate, exactly matching the original
	//                                "mfa_enabled = 0 OR mfa_enabled IS NULL")
	//   REGEXP_COUNT(owned_credentials, '"type"')
	//                            → jsonb_array_length(owned_credentials)
	//                               Because owned_credentials is jsonb,
	//                               PostgreSQL validates it on INSERT, so the
	//                               "is it really an array?" guard that the
	//                               text version needed disappears.
	countsQuery := fmt.Sprintf(`
		SELECT
			COUNT(*) AS total_identities,
			COALESCE(SUM(CASE WHEN is_secret     IS TRUE THEN 1 ELSE 0 END), 0) AS total_secrets,
			COALESCE(SUM(CASE WHEN owner_type = 'ORPHANED' THEN 1 ELSE 0 END), 0) AS total_orphaned,
			COALESCE(SUM(CASE WHEN classification = 'HUMAN' THEN 1 ELSE 0 END), 0) AS total_humans,
			COALESCE(SUM(CASE WHEN classification <> 'HUMAN' THEN 1 ELSE 0 END), 0) AS total_nhis,
			COALESCE(SUM(CASE WHEN classification = 'HUMAN' AND mfa_enabled IS NOT TRUE THEN 1 ELSE 0 END), 0) AS total_humans_without_mfa,
			COALESCE(SUM(jsonb_array_length(COALESCE(owned_credentials, '[]'::jsonb))), 0) AS total_credentials,
			
			-- ── POSTURE METRICS ──
			COALESCE(SUM(CASE WHEN classification = 'NHI_AGENT' THEN 1 ELSE 0 END), 0) AS total_nhi_agents,
			COALESCE(SUM(CASE WHEN classification = 'NHI_CICD' THEN 1 ELSE 0 END), 0) AS total_nhi_cicd,
			COALESCE(SUM(CASE WHEN trust_type = 'FEDERATED' THEN 1 ELSE 0 END), 0) AS total_federated,
			COALESCE(SUM(CASE WHEN is_admin IS TRUE THEN 1 ELSE 0 END), 0) AS total_admin,
			
			-- ── STALE / INACTIVE METRICS ──
			COALESCE(SUM(CASE WHEN last_active <= NOW() - INTERVAL '90 days' THEN 1 ELSE 0 END), 0) AS total_stale_90plus,
			COALESCE(SUM(CASE WHEN last_active <= NOW() - INTERVAL '30 days' AND last_active > NOW() - INTERVAL '90 days' THEN 1 ELSE 0 END), 0) AS total_inactive_30plus
		FROM %s.nhi_identities_aws
		WHERE %s`, Schema, scanFilter)

	var summary models.DashboardSummary
	var totalCreds sql.NullInt64

	err := r.db.DB.QueryRowContext(ctx, countsQuery, args...).Scan(
		&summary.TotalIdentities,
		&summary.TotalSecrets,
		&summary.TotalOrphaned,
		&summary.TotalHumans,
		&summary.TotalNHIs,
		&summary.TotalHumansWithoutMFA,
		&totalCreds,
		&summary.TotalNhiAgents,
		&summary.TotalNhiCicd,
		&summary.TotalFederated,
		&summary.TotalAdmin,
		&summary.TotalStale90Plus,
		&summary.TotalInactive30Plus,
	)
	if err != nil {
		return nil, fmt.Errorf("get dashboard counts: %w", err)
	}
	if totalCreds.Valid {
		summary.TotalCredentials = int(totalCreds.Int64)
	}

	// Fetch classification breakdown
	breakdownQuery := fmt.Sprintf(`
		SELECT classification, COUNT(*)
		FROM %s.nhi_identities_aws
		WHERE %s
		GROUP BY classification`, Schema, scanFilter)

	rows, err := r.db.DB.QueryContext(ctx, breakdownQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("get classification breakdown: %w", err)
	}
	defer rows.Close()

	summary.ClassificationBreakdown = make(map[string]int)
	for rows.Next() {
		var class sql.NullString
		var count int
		if err := rows.Scan(&class, &count); err == nil {
			summary.ClassificationBreakdown[class.String] = count
		}
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate classification breakdown: %w", err)
	}

	// ── Oracle JSON_TABLE → PostgreSQL jsonb_array_elements ─────────────
	//
	//	FROM nhi_scanner.nhi_identities_aws t,
	//	     JSON_TABLE(t.owned_credentials, '$[*]'
	//	         COLUMNS (credential_type VARCHAR2(100) PATH '$.type')) jt
	//
	// becomes a set-returning jsonb function in the FROM list. In PostgreSQL
	// a function in FROM is implicitly LATERAL, so t.owned_credentials is
	// visible to it, exactly like Oracle's implicit JSON_TABLE lateral join.
	// The '$[*]' path maps to the function itself, and the
	// '$.type' PATH maps to the ->> operator.
	credsBreakdownQuery := fmt.Sprintf(`
		SELECT COALESCE(elem ->> 'type', '') AS credential_type, COUNT(*)
		FROM %s.nhi_identities_aws t,
		     jsonb_array_elements(COALESCE(t.owned_credentials, '[]'::jsonb)) AS elem
		WHERE t.%s
		GROUP BY COALESCE(elem ->> 'type', '')`, Schema, scanFilter)

	credRows, err := r.db.DB.QueryContext(ctx, credsBreakdownQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("get credentials breakdown: %w", err)
	}
	defer credRows.Close()

	summary.CredentialsBreakdown = make(map[string]int)
	for credRows.Next() {
		var credType sql.NullString
		var count int
		if err := credRows.Scan(&credType, &count); err == nil && credType.String != "" {
			summary.CredentialsBreakdown[credType.String] = count
		}
	}
	if err := credRows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials breakdown: %w", err)
	}

	return &summary, nil
}

// AllKnownAccountIDs returns the distinct account IDs represented by the latest
// completed scan. It is consumed by authenticated credential APIs to constrain
// queries to accounts actually present in the current inventory snapshot.
func (r *DashboardRepository) AllKnownAccountIDs(ctx context.Context) ([]string, error) {
	if r == nil || r.db == nil || r.db.DB == nil {
		return nil, fmt.Errorf("dashboard repository unavailable")
	}
	rows, err := r.db.DB.QueryContext(ctx, `
		SELECT account_id FROM (
			SELECT account_id FROM nhi_scanner.identities WHERE deleted_at IS NULL AND `+LatestScanFilter+`
			UNION
			SELECT account_id FROM nhi_scanner.credentials WHERE deleted_at IS NULL AND `+LatestScanFilter+`
		) scoped_accounts
		WHERE account_id IS NOT NULL AND BTRIM(account_id) <> ''
		ORDER BY account_id`)
	if err != nil {
		return nil, fmt.Errorf("query latest-scan account scope: %w", err)
	}
	defer rows.Close()
	ids := make([]string, 0)
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, fmt.Errorf("scan latest-scan account scope: %w", err)
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate latest-scan account scope: %w", err)
	}
	return ids, nil
}
