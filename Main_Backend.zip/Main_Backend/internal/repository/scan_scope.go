package repository

import "fmt"

// LatestScanIDSubquery returns a SQL scalar subquery resolving to the scan_id
// of the single most recently COMPLETED scan (global — across all accounts),
// from nhi_scans_aws, ordered by scan_end DESC.
//
// Every identities/credentials query MUST filter:
//
//	AND scan_id = <this subquery>
//
// so that only rows belonging to the latest completed scan are returned.
// Whenever a new scan finishes, its scan_id automatically takes over on the
// very next query — nothing hardcoded, always resolved live.
//
// If no COMPLETED scan exists yet, this subquery evaluates to NULL, and
// "scan_id = NULL" is never true in SQL — so every scoped query will safely
// return zero rows rather than leaking unscoped data. This is intentional
// fail-closed behavior, not a bug.
//
// NOTE: this is a single GLOBAL latest scan, not per-account. If you actually
// run independent scans per AWS account and want each account's own latest
// completed scan honored separately, this needs to change to a
// DISTINCT ON (account_id) subquery + a per-row account_id join instead of a
// flat scalar — flag this if that's actually what you need.
func LatestScanIDSubquery() string {
	return latestCompletedScanSQL
}

// ScanScopeCondition returns the ready-to-use SQL condition string
// "scan_id = (<subquery>)" for embedding directly into any WHERE clause.
func ScanScopeCondition() string {
	return fmt.Sprintf("scan_id = %s", LatestScanIDSubquery())
}
