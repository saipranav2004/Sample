package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type EventRepository struct {
	db *PostgresDB
}

func NewEventRepository(db *PostgresDB) *EventRepository {
	return &EventRepository{db: db}
}

// ListByIdentity retrieves CloudTrail events safely handling casing, NULLs, and scan isolation
func (r *EventRepository) ListByIdentity(ctx context.Context, identityARN, scanID string, offset, limit int) ([]models.Event, int, error) {
	whereClause := "WHERE 1=1"
	var args []interface{}
	argIdx := 1

	if identityARN != "" {
		// Use LOWER() and TRIM() to guarantee matches regardless of ARN case mismatches
		whereClause += fmt.Sprintf(" AND LOWER(TRIM(identity_arn)) = LOWER(TRIM($%d))", argIdx)
		args = append(args, identityARN)
		argIdx++
	}

	// ── Default to latest completed scan if scanID is empty ──
	if scanID != "" {
		whereClause += fmt.Sprintf(" AND scan_id = $%d", argIdx)
		args = append(args, scanID)
		argIdx++
	} else {
		whereClause += " AND scan_id = " + latestCompletedScanSQL
	}

	offsetPos, limitPos := argIdx, argIdx+1

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM %s.nhi_events_aws %s", Schema, whereClause)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count events: %w", err)
	}

	query := fmt.Sprintf(`
		SELECT id, scan_id, identity_name, identity_arn, identity_type,
		       event_time, event_name, event_source, source_ip,
		       user_agent, read_only, region, discovered_at
		FROM %s.nhi_events_aws
		%s
		ORDER BY event_time DESC
		LIMIT $%d OFFSET $%d`, Schema, whereClause, limitPos, offsetPos)

	args = append(args, offset, limit)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query events: %w", err)
	}
	defer rows.Close()

	var events []models.Event
	for rows.Next() {
		var e models.Event
		var eventTime sql.NullTime
		var idName, idARN, idType sql.NullString
		var evName, evSource, srcIP, uAgent, region sql.NullString
		// models.Event.ReadOnly is a string. Scanning through NullString works
		// whether the column is boolean ("true"/"false"), integer ("1"/"0") or text.
		var readOnly sql.NullString

		err := rows.Scan(
			&e.ID, &e.ScanID, &idName, &idARN, &idType,
			&eventTime, &evName, &evSource, &srcIP,
			&uAgent, &readOnly, &region, &e.DiscoveredAt,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan event row: %w", err)
		}

		e.IdentityName = idName.String
		e.IdentityARN = idARN.String
		e.IdentityType = idType.String
		e.EventName = evName.String
		e.EventSource = evSource.String
		e.SourceIP = srcIP.String
		e.UserAgent = uAgent.String
		e.Region = region.String
		e.ReadOnly = readOnly.String

		if eventTime.Valid {
			e.EventTime = &eventTime.Time
		}

		events = append(events, e)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate event rows: %w", err)
	}

	return events, totalCount, nil
}
