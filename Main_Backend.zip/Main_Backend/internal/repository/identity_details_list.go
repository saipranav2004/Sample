// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"strings"

// 	"nhi-backend-api/internal/models"
// )

// // IdentityDetailsFilter holds the supported filter and pagination options
// // for the Identities screen (GET /api/identities).
// type IdentityDetailsFilter struct {
// 	Search         string
// 	Classification string
// 	IdentityType   string
// 	ScanID         string
// 	OwnerName      string
// 	IsSecret       *bool
// 	Offset         int
// 	Limit          int
// }

// // List returns a page of identity rows (full 41-column shape) matching the
// // filter, plus the total matching row count (ignoring pagination) so the
// // UI can render "22 of 3,291 identities" and page controls.
// func (r *IdentityDetailsRepository) List(ctx context.Context, filter IdentityDetailsFilter) ([]models.IdentityDetail, int, error) {
// 	var conditions []string
// 	var args []interface{}
// 	pos := 1

// 	// ── Oracle :N → PostgreSQL $N ──
// 	// Oracle allowed the same :N to be repeated (the search filter binds
// 	// one value twice). PostgreSQL does not: every occurrence needs its own
// 	// position, so the same value is bound once per position.
// 	if filter.Search != "" {
// 		conditions = append(conditions, fmt.Sprintf(
// 			"(LOWER(name) LIKE LOWER($%d) OR LOWER(arn) LIKE LOWER($%d))", pos, pos+1))
// 		like := "%" + filter.Search + "%"
// 		args = append(args, like, like)
// 		pos += 2
// 	}
// 	if filter.Classification != "" {
// 		conditions = append(conditions, fmt.Sprintf("classification = $%d", pos))
// 		args = append(args, filter.Classification)
// 		pos++
// 	}
// 	if filter.IdentityType != "" {
// 		conditions = append(conditions, fmt.Sprintf("identity_type = $%d", pos))
// 		args = append(args, filter.IdentityType)
// 		pos++
// 	}
// 	if filter.ScanID != "" {
// 		conditions = append(conditions, fmt.Sprintf("scan_id = $%d", pos))
// 		args = append(args, filter.ScanID)
// 		pos++
// 	}

// 	// is_secret is a boolean column in PostgreSQL, so the 0/1 conversion the
// 	// Oracle code did in Go becomes a boolean bind parameter.
// 	//
// 	// Note: this must be `is_secret = $n`, NOT `is_secret IS $n`. IS TRUE /
// 	// IS FALSE / IS NULL are predicates and PostgreSQL does not permit a
// 	// bind parameter in that position — it is a syntax error. Plain equality
// 	// against a boolean parameter is both valid and correct, because a NULL
// 	// is_secret yields NULL (not true), which the row filter then rejects.
// 	if filter.IsSecret != nil {
// 		conditions = append(conditions, fmt.Sprintf("is_secret = $%d", pos))
// 		args = append(args, *filter.IsSecret)
// 		pos++
// 	}

// 	whereClause := ""
// 	if len(conditions) > 0 {
// 		whereClause = "WHERE " + strings.Join(conditions, " AND ")
// 	}

// 	// --- total count (for pagination), same filters, no offset/limit ---
// 	countQuery := fmt.Sprintf(
// 		`SELECT COUNT(*) FROM `+Schema+`.nhi_identity_details %s`, whereClause)

// 	var total int
// 	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
// 		return nil, 0, fmt.Errorf("count identities: %w", err)
// 	}

// 	// --- paginated data query ---
// 	offset := filter.Offset
// 	limit := filter.Limit
// 	if limit <= 0 {
// 		limit = 20
// 	}

// 	// Placeholder positions: OFFSET is bound first, then LIMIT, so $offsetPos
// 	// is the offset and $limitPos is the limit. The query below reads
// 	// `LIMIT $limitPos OFFSET $offsetPos` and dataArgs is appended in the
// 	// matching (offset, limit) order.
// 	offsetPos, limitPos := pos, pos+1

// 	dataArgs := append(append([]interface{}{}, args...), offset, limit)

// 	// ORDER BY … LIMIT/OFFSET replaces Oracle's OFFSET :n ROWS FETCH NEXT :m
// 	// ROWS ONLY; LIMIT/OFFSET works on every PostgreSQL version, whereas
// 	// OFFSET/FETCH in that SQL-standard form needs PG 13+.
// 	query := fmt.Sprintf(`
// 		SELECT
// 			id, scan_id, arn, account_id, name, identity_type,
// 			classification, matched_rules, evidence, trust_type, trust_service,
// 			total_events, last_active, owner_name, owner_type, created_at,
// 			primary_owner, created_by_name, is_secret, owned_credentials, attached_policies,
// 			is_admin, groups_list, console_access, console_last_signin, mfa_enabled,
// 			password_age_days, access_key_1_id, access_key_1_age_days, access_key_last_used, relationships,
// 			bound_cred_type, bound_cred_assumed_via, bound_cred_policies, overview_bound_cred, overview_permissions,
// 			overview_discovery, overview_tags, overview_risk_factors, full_profile_json, discovered_at
// 		FROM `+Schema+`.nhi_identity_details
// 		%s
// 		ORDER BY id
// 		LIMIT $%d OFFSET $%d`, whereClause, limitPos, offsetPos)

// 	rows, err := r.db.DB.QueryContext(ctx, query, dataArgs...)
// 	if err != nil {
// 		return nil, 0, fmt.Errorf("list identities: %w", err)
// 	}
// 	defer rows.Close()

// 	var items []models.IdentityDetail
// 	for rows.Next() {
// 		var item models.IdentityDetail
// 		var (
// 			scanID, arn, accountID, name, identityType, classification   sql.NullString
// 			matchedRules, evidence, trustType, trustService              sql.NullString
// 			ownerName, ownerType, primaryOwner, createdByName            sql.NullString
// 			ownedCreds, attachedPolicies, groupsList                     sql.NullString
// 			consoleAccess, accessKey1ID, relationships                   sql.NullString
// 			boundCredType, boundCredAssumedVia, boundCredPolicies        sql.NullString
// 			overviewBoundCred, overviewPerms, overviewDisc, overviewTags sql.NullString
// 			overviewRiskFactors, fullProfileJSON                         sql.NullString
// 		)

// 		// The 0/1 NUMBER(1) flags become PostgreSQL booleans, so they are
// 		// scanned as NullBool instead of NullInt64.
// 		var (
// 			totalEvents                       sql.NullInt64
// 			isSecret, isAdmin, mfaEnabled     sql.NullBool
// 			pwdAge, accKeyAge                 sql.NullInt64
// 			lastActive, createdAt             sql.NullTime
// 			consoleLastSignin, accKeyLastUsed sql.NullTime
// 			discAt                            sql.NullTime
// 		)

// 		// owned_credentials and full_profile_json are jsonb. Both drivers
// 		// hand jsonb back as []byte, and sql.NullString.Scan accepts []byte,
// 		// so these still land in the string fields of models.IdentityDetail
// 		// without a change to the model.
// 		if err := rows.Scan(
// 			&item.ID, &scanID, &arn, &accountID, &name, &identityType,
// 			&classification, &matchedRules, &evidence, &trustType, &trustService,
// 			&totalEvents, &lastActive, &ownerName, &ownerType, &createdAt,
// 			&primaryOwner, &createdByName, &isSecret, &ownedCreds, &attachedPolicies,
// 			&isAdmin, &groupsList, &consoleAccess, &consoleLastSignin, &mfaEnabled,
// 			&pwdAge, &accessKey1ID, &accKeyAge, &accKeyLastUsed, &relationships,
// 			&boundCredType, &boundCredAssumedVia, &boundCredPolicies, &overviewBoundCred, &overviewPerms,
// 			&overviewDisc, &overviewTags, &overviewRiskFactors, &fullProfileJSON, &discAt,
// 		); err != nil {
// 			return nil, 0, fmt.Errorf("scan identity row: %w", err)
// 		}

// 		item.ScanID = scanID.String
// 		item.ARN = arn.String
// 		item.AccountID = accountID.String
// 		item.Name = name.String
// 		item.IdentityType = identityType.String
// 		item.Classification = classification.String
// 		item.MatchedRules = matchedRules.String
// 		item.Evidence = evidence.String
// 		item.TrustType = trustType.String
// 		item.TrustService = trustService.String
// 		item.OwnerName = ownerName.String
// 		item.OwnerType = ownerType.String
// 		item.PrimaryOwner = primaryOwner.String
// 		item.CreatedByName = createdByName.String
// 		item.OwnedCredentials = ownedCreds.String
// 		item.AttachedPolicies = attachedPolicies.String
// 		item.GroupsList = groupsList.String
// 		item.ConsoleAccess = consoleAccess.String
// 		item.AccessKey1ID = accessKey1ID.String
// 		item.Relationships = relationships.String
// 		item.BoundCredType = boundCredType.String
// 		item.BoundCredAssumedVia = boundCredAssumedVia.String
// 		item.BoundCredPolicies = boundCredPolicies.String
// 		item.OverviewBoundCred = overviewBoundCred.String
// 		item.OverviewPermissions = overviewPerms.String
// 		item.OverviewDiscovery = overviewDisc.String
// 		item.OverviewTags = overviewTags.String
// 		item.OverviewRiskFactors = overviewRiskFactors.String
// 		item.FullProfileJSON = fullProfileJSON.String

// 		if totalEvents.Valid {
// 			item.TotalEvents = int(totalEvents.Int64)
// 		}
// 		if isSecret.Valid {
// 			item.IsSecret = isSecret.Bool
// 		}
// 		if isAdmin.Valid {
// 			item.IsAdmin = isAdmin.Bool
// 		}
// 		if mfaEnabled.Valid {
// 			item.MFAEnabled = mfaEnabled.Bool
// 		}
// 		if pwdAge.Valid {
// 			item.PasswordAgeDays = int(pwdAge.Int64)
// 		}
// 		if accKeyAge.Valid {
// 			item.AccessKey1AgeDays = int(accKeyAge.Int64)
// 		}

// 		if lastActive.Valid {
// 			item.LastActive = &lastActive.Time
// 		}
// 		if createdAt.Valid {
// 			item.CreatedAt = &createdAt.Time
// 		}
// 		if consoleLastSignin.Valid {
// 			item.ConsoleLastSignin = &consoleLastSignin.Time
// 		}
// 		if accKeyLastUsed.Valid {
// 			item.AccessKeyLastUsed = &accKeyLastUsed.Time
// 		}
// 		if discAt.Valid {
// 			item.DiscoveredAt = &discAt.Time
// 		}

// 		items = append(items, item)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, 0, fmt.Errorf("iterate identity rows: %w", err)
// 	}

// 	return items, total, nil
// }

package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
)

// IdentityDetailsFilter holds the supported filter and pagination options
// for the Identities screen (GET /api/identities).
type IdentityDetailsFilter struct {
	Search         string
	Classification string
	IdentityType   string
	ScanID         string
	OwnerName      string
	IsSecret       *bool
	Offset         int
	Limit          int
}

// List returns a page of identity rows (full 41-column shape) matching the
// filter, plus the total matching row count (ignoring pagination) so the
// UI can render "22 of 3,291 identities" and page controls.
func (r *IdentityDetailsRepository) List(ctx context.Context, filter IdentityDetailsFilter) ([]models.IdentityDetail, int, error) {
	var conditions []string
	var args []interface{}
	pos := 1

	// ── Oracle :N → PostgreSQL $N ──
	// Oracle allowed the same :N to be repeated (the search filter binds
	// one value twice). PostgreSQL does not: every occurrence needs its own
	// position, so the same value is bound once per position.
	if filter.Search != "" {
		conditions = append(conditions, fmt.Sprintf(
			"(LOWER(name) LIKE LOWER($%d) OR LOWER(arn) LIKE LOWER($%d))", pos, pos+1))
		like := "%" + filter.Search + "%"
		args = append(args, like, like)
		pos += 2
	}
	if filter.Classification != "" {
		conditions = append(conditions, fmt.Sprintf("classification = $%d", pos))
		args = append(args, filter.Classification)
		pos++
	}
	if filter.IdentityType != "" {
		conditions = append(conditions, fmt.Sprintf("identity_type = $%d", pos))
		args = append(args, filter.IdentityType)
		pos++
	}
	if filter.ScanID != "" {
		conditions = append(conditions, fmt.Sprintf("scan_id = $%d", pos))
		args = append(args, filter.ScanID)
		pos++
	} else {
		// No explicit scan_id requested → only serve the latest scan's data.
		conditions = append(conditions, LatestScanFilter)
	}

	// is_secret is a boolean column in PostgreSQL, so the 0/1 conversion the
	// Oracle code did in Go becomes a boolean bind parameter.
	//
	// Note: this must be `is_secret = $n`, NOT `is_secret IS $n`. IS TRUE /
	// IS FALSE / IS NULL are predicates and PostgreSQL does not permit a
	// bind parameter in that position — it is a syntax error. Plain equality
	// against a boolean parameter is both valid and correct, because a NULL
	// is_secret yields NULL (not true), which the row filter then rejects.
	if filter.IsSecret != nil {
		conditions = append(conditions, fmt.Sprintf("is_secret = $%d", pos))
		args = append(args, *filter.IsSecret)
		pos++
	}

	whereClause := ""
	if len(conditions) > 0 {
		whereClause = "WHERE " + strings.Join(conditions, " AND ")
	}

	// --- total count (for pagination), same filters, no offset/limit ---
	countQuery := fmt.Sprintf(
		`SELECT COUNT(*) FROM `+Schema+`.nhi_identity_details %s`, whereClause)

	var total int
	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count identities: %w", err)
	}

	// --- paginated data query ---
	offset := filter.Offset
	limit := filter.Limit
	if limit <= 0 {
		limit = 20
	}

	// Placeholder positions: OFFSET is bound first, then LIMIT, so $offsetPos
	// is the offset and $limitPos is the limit. The query below reads
	// `LIMIT $limitPos OFFSET $offsetPos` and dataArgs is appended in the
	// matching (offset, limit) order.
	offsetPos, limitPos := pos, pos+1

	dataArgs := append(append([]interface{}{}, args...), offset, limit)

	// ORDER BY … LIMIT/OFFSET replaces Oracle's OFFSET :n ROWS FETCH NEXT :m
	// ROWS ONLY; LIMIT/OFFSET works on every PostgreSQL version, whereas
	// OFFSET/FETCH in that SQL-standard form needs PG 13+.
	query := fmt.Sprintf(`
		SELECT
			id, scan_id, arn, account_id, name, identity_type,
			classification, matched_rules, evidence, trust_type, trust_service,
			total_events, last_active, owner_name, owner_type, created_at,
			primary_owner, created_by_name, is_secret, owned_credentials, attached_policies,
			is_admin, groups_list, console_access, console_last_signin, mfa_enabled,
			password_age_days, access_key_1_id, access_key_1_age_days, access_key_last_used, relationships,
			bound_cred_type, bound_cred_assumed_via, bound_cred_policies, overview_bound_cred, overview_permissions,
			overview_discovery, overview_tags, overview_risk_factors, full_profile_json, discovered_at
		FROM `+Schema+`.nhi_identity_details
		%s
		ORDER BY id
		LIMIT $%d OFFSET $%d`, whereClause, limitPos, offsetPos)

	rows, err := r.db.DB.QueryContext(ctx, query, dataArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("list identities: %w", err)
	}
	defer rows.Close()

	var items []models.IdentityDetail
	for rows.Next() {
		var item models.IdentityDetail
		var (
			scanID, arn, accountID, name, identityType, classification   sql.NullString
			matchedRules, evidence, trustType, trustService              sql.NullString
			ownerName, ownerType, primaryOwner, createdByName            sql.NullString
			ownedCreds, attachedPolicies, groupsList                     sql.NullString
			consoleAccess, accessKey1ID, relationships                   sql.NullString
			boundCredType, boundCredAssumedVia, boundCredPolicies        sql.NullString
			overviewBoundCred, overviewPerms, overviewDisc, overviewTags sql.NullString
			overviewRiskFactors, fullProfileJSON                         sql.NullString
		)

		// The 0/1 NUMBER(1) flags become PostgreSQL booleans, so they are
		// scanned as NullBool instead of NullInt64.
		var (
			totalEvents                       sql.NullInt64
			isSecret, isAdmin, mfaEnabled     sql.NullBool
			pwdAge, accKeyAge                 sql.NullInt64
			lastActive, createdAt             sql.NullTime
			consoleLastSignin, accKeyLastUsed sql.NullTime
			discAt                            sql.NullTime
		)

		// owned_credentials and full_profile_json are jsonb. Both drivers
		// hand jsonb back as []byte, and sql.NullString.Scan accepts []byte,
		// so these still land in the string fields of models.IdentityDetail
		// without a change to the model.
		if err := rows.Scan(
			&item.ID, &scanID, &arn, &accountID, &name, &identityType,
			&classification, &matchedRules, &evidence, &trustType, &trustService,
			&totalEvents, &lastActive, &ownerName, &ownerType, &createdAt,
			&primaryOwner, &createdByName, &isSecret, &ownedCreds, &attachedPolicies,
			&isAdmin, &groupsList, &consoleAccess, &consoleLastSignin, &mfaEnabled,
			&pwdAge, &accessKey1ID, &accKeyAge, &accKeyLastUsed, &relationships,
			&boundCredType, &boundCredAssumedVia, &boundCredPolicies, &overviewBoundCred, &overviewPerms,
			&overviewDisc, &overviewTags, &overviewRiskFactors, &fullProfileJSON, &discAt,
		); err != nil {
			return nil, 0, fmt.Errorf("scan identity row: %w", err)
		}

		item.ScanID = scanID.String
		item.ARN = arn.String
		item.AccountID = accountID.String
		item.Name = name.String
		item.IdentityType = identityType.String
		item.Classification = classification.String
		item.MatchedRules = matchedRules.String
		item.Evidence = evidence.String
		item.TrustType = trustType.String
		item.TrustService = trustService.String
		item.OwnerName = ownerName.String
		item.OwnerType = ownerType.String
		item.PrimaryOwner = primaryOwner.String
		item.CreatedByName = createdByName.String
		item.OwnedCredentials = ownedCreds.String
		item.AttachedPolicies = attachedPolicies.String
		item.GroupsList = groupsList.String
		item.ConsoleAccess = consoleAccess.String
		item.AccessKey1ID = accessKey1ID.String
		item.Relationships = relationships.String
		item.BoundCredType = boundCredType.String
		item.BoundCredAssumedVia = boundCredAssumedVia.String
		item.BoundCredPolicies = boundCredPolicies.String
		item.OverviewBoundCred = overviewBoundCred.String
		item.OverviewPermissions = overviewPerms.String
		item.OverviewDiscovery = overviewDisc.String
		item.OverviewTags = overviewTags.String
		item.OverviewRiskFactors = overviewRiskFactors.String
		item.FullProfileJSON = fullProfileJSON.String

		if totalEvents.Valid {
			item.TotalEvents = int(totalEvents.Int64)
		}
		if isSecret.Valid {
			item.IsSecret = isSecret.Bool
		}
		if isAdmin.Valid {
			item.IsAdmin = isAdmin.Bool
		}
		if mfaEnabled.Valid {
			item.MFAEnabled = mfaEnabled.Bool
		}
		if pwdAge.Valid {
			item.PasswordAgeDays = int(pwdAge.Int64)
		}
		if accKeyAge.Valid {
			item.AccessKey1AgeDays = int(accKeyAge.Int64)
		}

		if lastActive.Valid {
			item.LastActive = &lastActive.Time
		}
		if createdAt.Valid {
			item.CreatedAt = &createdAt.Time
		}
		if consoleLastSignin.Valid {
			item.ConsoleLastSignin = &consoleLastSignin.Time
		}
		if accKeyLastUsed.Valid {
			item.AccessKeyLastUsed = &accKeyLastUsed.Time
		}
		if discAt.Valid {
			item.DiscoveredAt = &discAt.Time
		}

		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate identity rows: %w", err)
	}

	return items, total, nil
}
