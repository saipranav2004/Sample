// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"strings"
// 	"time"

// 	_ "github.com/jackc/pgx/v5/stdlib"

// 	"nhi-backend-api/internal/config"
// )

// const DriverName = "pgx"

// const Schema = "nhi_scanner"

// const latestCompletedScanSQL = `(SELECT scan_id FROM ` + Schema + `.nhi_scans_aws ` +
// 	`WHERE status = 'COMPLETED' ORDER BY scan_start DESC NULLS LAST LIMIT 1)`

// type PostgresDB struct {
// 	DB *sql.DB
// }

// func NewPostgresDB(cfg *config.DatabaseConfig) (*PostgresDB, error) {
// 	if cfg.DBName() == "" {
// 		return nil, fmt.Errorf("postgres: database name is empty — set database.database_name in configs/config.yaml")
// 	}

// 	connStr := strings.TrimSpace(cfg.GetConnectionString())
// 	if connStr == "" {
// 		return nil, fmt.Errorf("postgres: empty connection string")
// 	}

// 	db, err := sql.Open(DriverName, connStr)
// 	if err != nil {
// 		return nil, fmt.Errorf("open postgres: %w", err)
// 	}

// 	db.SetMaxOpenConns(20)
// 	db.SetMaxIdleConns(10)
// 	db.SetConnMaxLifetime(30 * time.Minute)

// 	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	defer cancel()

// 	if err := db.PingContext(ctx); err != nil {
// 		_ = db.Close()
// 		return nil, fmt.Errorf("ping postgres: %w", err)
// 	}

// 	// Show which database/user the app really connected to.
// 	var dbName, dbUser string
// 	_ = db.QueryRowContext(ctx, "SELECT current_database(), current_user").Scan(&dbName, &dbUser)
// 	fmt.Printf("✅ PostgreSQL connected → db=%s user=%s\n", dbName, dbUser)

// 	return &PostgresDB{DB: db}, nil
// }

// // Close releases every pooled connection.
// func (p *PostgresDB) Close() {
// 	if p != nil && p.DB != nil {
// 		_ = p.DB.Close()
// 	}
// }

// // ownedCredsArray returns a SQL expression that always yields a JSONB *array*
// // for the owned_credentials column of the given table alias.
// //
// // jsonb_array_elements() / jsonb_array_length() raise an error when the value
// // is JSON null, an object, or an empty string. Oracle's JSON_TABLE silently
// // skipped those rows, so this guard keeps the same forgiving behaviour. The
// // ::text::jsonb round-trip also works whether the column is text, json or jsonb.
// func ownedCredsArray(alias string) string {
// 	col := "NULLIF(" + alias + ".owned_credentials::text, '')::jsonb"
// 	return "(CASE WHEN jsonb_typeof(" + col + ") = 'array' THEN " + col + " ELSE '[]'::jsonb END)"
// }

// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"strings"
// 	"time"

// 	_ "github.com/jackc/pgx/v5/stdlib"

// 	"nhi-backend-api/internal/config"
// )

// const DriverName = "pgx"

// const Schema = "nhi_scanner"

// // latestCompletedScanSQL resolves to the scan_id of the single most recently
// // COMPLETED scan, globally (not per-account), ordered by scan_end — the only
// // confirmed timestamp column on nhi_scans_aws. Consumed via
// // repository.LatestScanIDSubquery() / repository.ScanScopeCondition().
// const latestCompletedScanSQL = `(SELECT scan_id FROM ` + Schema + `.nhi_scans_aws ` +
// 	`WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST LIMIT 1)`

// type PostgresDB struct {
// 	DB *sql.DB
// }

// func NewPostgresDB(cfg *config.DatabaseConfig) (*PostgresDB, error) {
// 	if cfg.DBName() == "" {
// 		return nil, fmt.Errorf("postgres: database name is empty — set database.database_name in configs/config.yaml")
// 	}

// 	connStr := strings.TrimSpace(cfg.GetConnectionString())
// 	if connStr == "" {
// 		return nil, fmt.Errorf("postgres: empty connection string")
// 	}

// 	db, err := sql.Open(DriverName, connStr)
// 	if err != nil {
// 		return nil, fmt.Errorf("open postgres: %w", err)
// 	}

// 	db.SetMaxOpenConns(20)
// 	db.SetMaxIdleConns(10)
// 	db.SetConnMaxLifetime(30 * time.Minute)

// 	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	defer cancel()

// 	if err := db.PingContext(ctx); err != nil {
// 		_ = db.Close()
// 		return nil, fmt.Errorf("ping postgres: %w", err)
// 	}

// 	var dbName, dbUser string
// 	_ = db.QueryRowContext(ctx, "SELECT current_database(), current_user").Scan(&dbName, &dbUser)
// 	fmt.Printf("✅ PostgreSQL connected → db=%s user=%s\n", dbName, dbUser)

// 	return &PostgresDB{DB: db}, nil
// }

// func (p *PostgresDB) Close() {
// 	if p != nil && p.DB != nil {
// 		_ = p.DB.Close()
// 	}
// }

// func ownedCredsArray(alias string) string {
// 	col := "NULLIF(" + alias + ".owned_credentials::text, '')::jsonb"
// 	return "(CASE WHEN jsonb_typeof(" + col + ") = 'array' THEN " + col + " ELSE '[]'::jsonb END)"
// }

package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"

	"nhi-backend-api/internal/config"
)

const DriverName = "pgx"

const Schema = "nhi_scanner"

const latestCompletedScanSQL = `(SELECT scan_id FROM ` + Schema + `.nhi_scans_aws ` +
	`WHERE UPPER(BTRIM(status)) = 'COMPLETED' AND scan_end IS NOT NULL ` +
	`ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)`

// LatestScanFilter is a ready-to-use SQL condition that restricts any query on
// nhi_scanner.identities / nhi_scanner.credentials to the rows that belong to
// the most recent COMPLETED scan recorded in nhi_scanner.nhi_scans_aws.
//
// Every time a new scan finishes its scan_id becomes the latest one, so the API
// automatically stops returning data from the previous scan and only serves
// data of the new scan_id. The condition contains no placeholders, so it can be
// appended to any WHERE clause without disturbing $n argument numbering.
//
// Usage:  "... WHERE deleted_at IS NULL AND " + repository.LatestScanFilter
const LatestScanFilter = `scan_id = ` + latestCompletedScanSQL

type PostgresDB struct {
	DB *sql.DB
}

func NewPostgresDB(cfg *config.DatabaseConfig) (*PostgresDB, error) {
	if cfg.DBName() == "" {
		return nil, fmt.Errorf("postgres: database name is empty — set database.database_name in configs/config.yaml")
	}

	connStr := strings.TrimSpace(cfg.GetConnectionString())
	if connStr == "" {
		return nil, fmt.Errorf("postgres: empty connection string")
	}

	db, err := sql.Open(DriverName, connStr)
	if err != nil {
		return nil, fmt.Errorf("open postgres: %w", err)
	}

	db.SetMaxOpenConns(20)
	db.SetMaxIdleConns(10)
	db.SetConnMaxLifetime(30 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}

	// Show which database/user the app really connected to.
	var dbName, dbUser string
	_ = db.QueryRowContext(ctx, "SELECT current_database(), current_user").Scan(&dbName, &dbUser)
	fmt.Printf("✅ PostgreSQL connected → db=%s user=%s\n", dbName, dbUser)

	return &PostgresDB{DB: db}, nil
}

// Close releases every pooled connection.
func (p *PostgresDB) Close() {
	if p != nil && p.DB != nil {
		_ = p.DB.Close()
	}
}

// ownedCredsArray returns a SQL expression that always yields a JSONB *array*
// for the owned_credentials column of the given table alias.
//
// jsonb_array_elements() / jsonb_array_length() raise an error when the value
// is JSON null, an object, or an empty string. Oracle's JSON_TABLE silently
// skipped those rows, so this guard keeps the same forgiving behaviour. The
// ::text::jsonb round-trip also works whether the column is text, json or jsonb.
func ownedCredsArray(alias string) string {
	col := "NULLIF(" + alias + ".owned_credentials::text, '')::jsonb"
	return "(CASE WHEN jsonb_typeof(" + col + ") = 'array' THEN " + col + " ELSE '[]'::jsonb END)"
}
