package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *CredentialAPIRepository) CredentialUsageData(ctx context.Context, id string, allowed []string, days int) (string, []m.CredentialUsageGrant, []m.CredentialUsageEvent, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return "", nil, nil, fmt.Errorf("credential usage source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return "", nil, nil, fmt.Errorf("begin credential usage snapshot: %w", err)
	}
	defer tx.Rollback()
	var accountID string
	if err := tx.QueryRowContext(ctx, `SELECT account_id FROM nhi_scanner.credentials WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE UPPER(BTRIM(status))='COMPLETED' AND scan_end IS NOT NULL ORDER BY scan_end DESC NULLS LAST,id DESC LIMIT 1)`, id, pq.Array(allowed)).Scan(&accountID); err != nil {
		return "", nil, nil, fmt.Errorf("load authorized credential: %w", err)
	}
	scanID, err := latestCompletedCredentialScan(ctx, tx, accountID)
	if err != nil {
		return "", nil, nil, err
	}
	gr, err := tx.QueryContext(ctx, `SELECT DISTINCT action,effect,source_name FROM nhi_scanner.effective_permissions WHERE credential_id=$1::uuid AND scan_id=$2::text AND LOWER(BTRIM(COALESCE(effect,'')))='allow' ORDER BY action,source_name`, id, scanID)
	if err != nil {
		return "", nil, nil, fmt.Errorf("query granted credential actions: %w", err)
	}
	grants := []m.CredentialUsageGrant{}
	for gr.Next() {
		var x m.CredentialUsageGrant
		var source sql.NullString
		if err := gr.Scan(&x.Action, &x.Effect, &source); err != nil {
			gr.Close()
			return "", nil, nil, fmt.Errorf("scan granted credential action: %w", err)
		}
		if source.Valid {
			x.SourceName = &source.String
		}
		grants = append(grants, x)
	}
	if err := gr.Err(); err != nil {
		gr.Close()
		return "", nil, nil, fmt.Errorf("iterate granted actions: %w", err)
	}
	if err := gr.Close(); err != nil {
		return "", nil, nil, fmt.Errorf("close granted actions: %w", err)
	}

	const q = `SELECT CASE WHEN POSITION(':' IN COALESCE(event_name,''))>0 THEN BTRIM(event_name) ELSE LOWER(COALESCE(NULLIF(BTRIM(service),''),'unknown'))||':'||BTRIM(COALESCE(event_name,'')) END AS used_action,MAX(last_seen),SUM(COALESCE(event_count,0))::bigint
FROM nhi_scanner.identity_usage
WHERE credential_id=$1::uuid AND scan_id=$2::text
  AND last_seen >= $3::timestamptz-($4::int*INTERVAL '1 day')
  AND NULLIF(BTRIM(COALESCE(event_name,'')),'') IS NOT NULL
GROUP BY 1 ORDER BY 1`
	rows, err := tx.QueryContext(ctx, q, id, scanID, time.Now().UTC(), days)
	if err != nil {
		return "", nil, nil, fmt.Errorf("query credential usage events: %w", err)
	}
	events := []m.CredentialUsageEvent{}
	for rows.Next() {
		var x m.CredentialUsageEvent
		if err := rows.Scan(&x.Action, &x.LastSeen, &x.CallCount); err != nil {
			rows.Close()
			return "", nil, nil, fmt.Errorf("scan credential usage event: %w", err)
		}
		x.LastSeen = x.LastSeen.UTC()
		events = append(events, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return "", nil, nil, fmt.Errorf("iterate credential usage events: %w", err)
	}
	if err := rows.Close(); err != nil {
		return "", nil, nil, fmt.Errorf("close credential usage events: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return "", nil, nil, fmt.Errorf("commit credential usage snapshot: %w", err)
	}
	return scanID, grants, events, nil
}
