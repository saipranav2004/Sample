package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

type ImpactAnalysisRepository struct{ db *sql.DB }

func NewImpactAnalysisRepository(db *sql.DB) *ImpactAnalysisRepository {
	return &ImpactAnalysisRepository{db: db}
}

func (r *ImpactAnalysisRepository) Analyze(ctx context.Context, entityType, entityID string, allowed []string) (*m.ImpactAnalysisResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("impact analysis source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin impact snapshot: %w", err)
	}
	defer tx.Rollback()
	scanID, err := latestCompletedCredentialScan(ctx, tx, "")
	if err != nil {
		return nil, err
	}
	var accountID, entityARN string
	credentialIDs := []string{}
	switch entityType {
	case "credentials":
		err = tx.QueryRowContext(ctx, `SELECT id::text,COALESCE(arn,''),account_id::text FROM nhi_scanner.credentials
WHERE id::text=$1::text AND scan_id=$2::text AND account_id=ANY($3::text[]) AND deleted_at IS NULL`, entityID, scanID, pq.Array(allowed)).Scan(&entityID, &entityARN, &accountID)
		if err == nil {
			credentialIDs = append(credentialIDs, entityID)
		}
	case "identities":
		err = tx.QueryRowContext(ctx, `SELECT id::text,COALESCE(arn,''),account_id::text FROM nhi_scanner.identities
WHERE id::text=$1::text AND scan_id=$2::text AND account_id=ANY($3::text[])`, entityID, scanID, pq.Array(allowed)).Scan(&entityID, &entityARN, &accountID)
	default:
		return nil, fmt.Errorf("unsupported impact entity type")
	}
	if err != nil {
		return nil, fmt.Errorf("load impact entity: %w", err)
	}

	identitiesAffected := 0
	if entityType == "credentials" {
		err = tx.QueryRowContext(ctx, `SELECT COUNT(DISTINCT identity_id)::int FROM nhi_scanner.identity_credentials
WHERE credential_id::text=$1::text AND scan_id=$2::text
 AND LOWER(BTRIM(COALESCE(is_active::text,''))) IN ('1','t','true','yes','y')`, entityID, scanID).Scan(&identitiesAffected)
		if err != nil {
			return nil, fmt.Errorf("count impacted identities: %w", err)
		}
	} else {
		links, err := tx.QueryContext(ctx, `SELECT DISTINCT credential_id::text FROM nhi_scanner.identity_credentials
WHERE identity_id::text=$1::text AND scan_id=$2::text
 AND LOWER(BTRIM(COALESCE(is_active::text,''))) IN ('1','t','true','yes','y') ORDER BY 1`, entityID, scanID)
		if err != nil {
			return nil, fmt.Errorf("query identity credential links: %w", err)
		}
		for links.Next() {
			var id string
			if err := links.Scan(&id); err != nil {
				links.Close()
				return nil, fmt.Errorf("scan identity credential link: %w", err)
			}
			credentialIDs = append(credentialIDs, id)
		}
		if err := links.Err(); err != nil {
			links.Close()
			return nil, fmt.Errorf("iterate identity credential links: %w", err)
		}
		if err := links.Close(); err != nil {
			return nil, fmt.Errorf("close identity credential links: %w", err)
		}
		if len(credentialIDs) > 0 {
			err = tx.QueryRowContext(ctx, `SELECT COUNT(DISTINCT other.identity_id)::int
FROM nhi_scanner.identity_credentials own
JOIN nhi_scanner.identity_credentials other ON other.credential_id=own.credential_id AND other.scan_id=own.scan_id
WHERE own.identity_id::text=$1::text AND own.scan_id=$2::text AND other.identity_id::text<>$1::text
 AND LOWER(BTRIM(COALESCE(own.is_active::text,''))) IN ('1','t','true','yes','y')
 AND LOWER(BTRIM(COALESCE(other.is_active::text,''))) IN ('1','t','true','yes','y')`, entityID, scanID).Scan(&identitiesAffected)
			if err != nil {
				return nil, fmt.Errorf("count identities sharing credentials: %w", err)
			}
		}
	}

	permissionsGranted := 0
	services := []string{}
	if len(credentialIDs) > 0 {
		err = tx.QueryRowContext(ctx, `SELECT COUNT(DISTINCT action)::int FROM nhi_scanner.effective_permissions
WHERE credential_id::text=ANY($1::text[]) AND scan_id=$2::text`, pq.Array(credentialIDs), scanID).Scan(&permissionsGranted)
		if err != nil {
			return nil, fmt.Errorf("count granted impact permissions: %w", err)
		}
		serviceRows, err := tx.QueryContext(ctx, `SELECT DISTINCT LOWER(split_part(action,':',1)) FROM nhi_scanner.effective_permissions
WHERE credential_id::text=ANY($1::text[]) AND scan_id=$2::text AND NULLIF(split_part(action,':',1),'') IS NOT NULL ORDER BY 1`, pq.Array(credentialIDs), scanID)
		if err != nil {
			return nil, fmt.Errorf("query accessible services: %w", err)
		}
		for serviceRows.Next() {
			var s string
			if err := serviceRows.Scan(&s); err != nil {
				serviceRows.Close()
				return nil, fmt.Errorf("scan accessible service: %w", err)
			}
			services = append(services, s)
		}
		if err := serviceRows.Err(); err != nil {
			serviceRows.Close()
			return nil, fmt.Errorf("iterate accessible services: %w", err)
		}
		if err := serviceRows.Close(); err != nil {
			return nil, fmt.Errorf("close accessible services: %w", err)
		}
	}

	arns := []string{}
	if entityARN != "" {
		arns = append(arns, entityARN)
	}
	if entityType == "identities" && len(credentialIDs) > 0 {
		arnRows, err := tx.QueryContext(ctx, `SELECT DISTINCT arn FROM nhi_scanner.credentials
WHERE id::text=ANY($1::text[]) AND scan_id=$2::text AND account_id=ANY($3::text[]) AND NULLIF(BTRIM(COALESCE(arn,'')),'') IS NOT NULL`, pq.Array(credentialIDs), scanID, pq.Array(allowed))
		if err != nil {
			return nil, fmt.Errorf("query linked credential ARNs: %w", err)
		}
		for arnRows.Next() {
			var a string
			if err := arnRows.Scan(&a); err != nil {
				arnRows.Close()
				return nil, fmt.Errorf("scan linked credential ARN: %w", err)
			}
			arns = append(arns, a)
		}
		if err := arnRows.Err(); err != nil {
			arnRows.Close()
			return nil, fmt.Errorf("iterate linked credential ARNs: %w", err)
		}
		if err := arnRows.Close(); err != nil {
			return nil, fmt.Errorf("close linked credential ARNs: %w", err)
		}
	}
	attackPaths, privEsc := 0, false
	crossAccount := false
	if len(arns) > 0 {
		err = tx.QueryRowContext(ctx, `SELECT COUNT(*)::int,
COALESCE(BOOL_OR(LOWER(edge_type) LIKE '%assume%' OR LOWER(edge_type) LIKE '%pass_role%'),false),
COALESCE(BOOL_OR(NULLIF(split_part(target_arn,':',5),'') IS NOT NULL AND split_part(target_arn,':',5)<>$2::text),false)
FROM nhi_scanner.trust_edges
WHERE scan_id=$1::text AND source_arn=ANY($3::text[])
 AND LOWER(BTRIM(COALESCE(is_active::text,''))) IN ('1','t','true','yes','y')`, scanID, accountID, pq.Array(arns)).Scan(&attackPaths, &privEsc, &crossAccount)
		if err != nil {
			return nil, fmt.Errorf("query impact trust paths: %w", err)
		}
	}
	if len(credentialIDs) > 0 {
		var externalResource bool
		err = tx.QueryRowContext(ctx, `SELECT COALESCE(BOOL_OR(NULLIF(split_part(resource,':',5),'') IS NOT NULL AND split_part(resource,':',5)<>$2::text),false)
FROM nhi_scanner.effective_permissions WHERE credential_id::text=ANY($1::text[]) AND scan_id=$3::text`, pq.Array(credentialIDs), accountID, scanID).Scan(&externalResource)
		if err != nil {
			return nil, fmt.Errorf("check impact resource scope: %w", err)
		}
		crossAccount = crossAccount || externalResource
	}
	scope := "account-scoped"
	if crossAccount {
		scope = "cross-account"
	}
	severity := "low"
	switch {
	case identitiesAffected >= 10 || (privEsc && attackPaths >= 3):
		severity = "critical"
	case privEsc || permissionsGranted >= 100:
		severity = "high"
	case identitiesAffected > 0 || permissionsGranted > 0:
		severity = "medium"
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit impact snapshot: %w", err)
	}
	return &m.ImpactAnalysisResponse{ScanID: scanID, EntityID: entityID, EntityType: entityType, Impact: m.ImpactAnalysisMetrics{IdentitiesAffected: identitiesAffected, PermissionsGranted: permissionsGranted, ServicesAccessible: services, PrivilegeEscalationPossible: privEsc, AttackPathsCount: attackPaths, DataAccessScope: scope}, OverallSeverity: strings.ToLower(severity)}, nil
}
