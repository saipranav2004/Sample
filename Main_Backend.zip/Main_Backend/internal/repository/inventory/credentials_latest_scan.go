package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/inventory"
)

// CredentialAPIRepository isolates C1–C4 SQL from the existing inventory repositories.
type CredentialAPIRepository struct{ db *sql.DB }

func NewCredentialAPIRepository(db *sql.DB) *CredentialAPIRepository {
	return &CredentialAPIRepository{db: db}
}

// latestCompletedCredentialScan returns the same canonical latest completed scan
// used by the rest of this backend. accountID is retained for call-site clarity;
// the backend's scan selector is global, not per-account.
func latestCompletedCredentialScan(ctx context.Context, tx *sql.Tx, accountID string) (string, error) {
	_ = accountID
	var scanID sql.NullString
	query := `SELECT scan_id FROM nhi_scanner.nhi_scans_aws
WHERE UPPER(BTRIM(status))='COMPLETED' AND scan_end IS NOT NULL
ORDER BY scan_end DESC NULLS LAST,id DESC LIMIT 1`
	err := tx.QueryRowContext(ctx, query).Scan(&scanID)
	if errors.Is(err, sql.ErrNoRows) {
		return "", m.ErrLatestCompletedScanUnavailable
	}
	if err != nil {
		return "", fmt.Errorf("load latest completed scan: %w", err)
	}
	if !scanID.Valid || strings.TrimSpace(scanID.String) == "" {
		return "", m.ErrLatestCompletedScanUnavailable
	}
	return scanID.String, nil
}
