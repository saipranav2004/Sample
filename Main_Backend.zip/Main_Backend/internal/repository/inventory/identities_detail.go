// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"
// 	"time"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// var ErrIdentityNotFound = errors.New("identity not found")

// type IdentityDetailRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentityDetailRepository(db *repository.PostgresDB) *IdentityDetailRepository {
// 	return &IdentityDetailRepository{db: db}
// }

// func (r *IdentityDetailRepository) Detail(ctx context.Context, id string) (*modelsinventory.IdentityDetail, error) {
// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text, arn, name, identity_type, functional_class,
// 			account_id, region, status,
// 			created_at_aws, first_seen_at, last_seen_at, last_activity_at, deleted_at,
// 			vpc_id, subnet_id, security_group_ids, is_publicly_accessible,
// 			tags, owner, environment,
// 			parent_arn, cloudtrail_creator_arn,
// 			discovery_source, scan_id,
// 			type_attributes, raw_api_response
// 		FROM %s.identities
// 		WHERE id = $1::uuid AND deleted_at IS NULL
// 	`, repository.Schema)

// 	var (
// 		idVal, arnVal, nameVal, identityTypeVal sql.NullString
// 		functionalClass                         sql.NullString
// 		accountIDVal, regionVal, statusVal      sql.NullString
// 		createdAtAWS, firstSeenAt, lastSeenAt   sql.NullTime
// 		lastActivityAt, deletedAt               sql.NullTime
// 		vpcID, subnetID                         sql.NullString
// 		securityGroupIDs                        []byte
// 		isPubliclyAccessible                    sql.NullBool
// 		tags                                    []byte
// 		owner, environment                      sql.NullString
// 		parentARN, cloudtrailCreatorARN         sql.NullString
// 		discoverySourceVal                      sql.NullString
// 		scanID                                  sql.NullString
// 		typeAttributes, rawAPIResponse          []byte
// 	)

// 	err := r.db.DB.QueryRowContext(ctx, query, id).Scan(
// 		&idVal, &arnVal, &nameVal, &identityTypeVal, &functionalClass,
// 		&accountIDVal, &regionVal, &statusVal,
// 		&createdAtAWS, &firstSeenAt, &lastSeenAt, &lastActivityAt, &deletedAt,
// 		&vpcID, &subnetID, &securityGroupIDs, &isPubliclyAccessible,
// 		&tags, &owner, &environment,
// 		&parentARN, &cloudtrailCreatorARN,
// 		&discoverySourceVal, &scanID,
// 		&typeAttributes, &rawAPIResponse,
// 	)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, ErrIdentityNotFound
// 		}
// 		return nil, fmt.Errorf("load identity detail: %w", err)
// 	}

// 	d := &modelsinventory.IdentityDetail{
// 		ID:              idVal.String,
// 		ARN:             arnVal.String,
// 		Name:            nameVal.String,
// 		IdentityType:    identityTypeVal.String,
// 		FunctionalClass: identityNullStr(functionalClass),
// 		AccountID:       accountIDVal.String,
// 		Region:          regionVal.String,
// 		Status:          statusVal.String,
// 		CreatedAtAWS:    identityNullTime(createdAtAWS),
// 		FirstSeenAt:     identityNullTime(firstSeenAt),
// 		LastSeenAt:      identityNullTime(lastSeenAt),
// 		LastActivityAt:  identityNullTime(lastActivityAt),
// 		DeletedAt:       identityNullTime(deletedAt),
// 		Network: modelsinventory.IdentityNetwork{
// 			VPCID:                identityNullStr(vpcID),
// 			SubnetID:             identityNullStr(subnetID),
// 			SecurityGroupIDs:     identityNullRawOrEmptyArray(securityGroupIDs),
// 			IsPubliclyAccessible: identityNullBool(isPubliclyAccessible),
// 		},
// 		Ownership: modelsinventory.IdentityOwnership{
// 			Owner:       identityNullStr(owner),
// 			Environment: identityNullStr(environment),
// 			Tags:        identityNullRawOrEmptyObject(tags),
// 		},
// 		Lineage: modelsinventory.IdentityLineage{
// 			ParentARN:            identityNullStr(parentARN),
// 			CloudTrailCreatorARN: identityNullStr(cloudtrailCreatorARN),
// 		},
// 		Discovery: modelsinventory.IdentityDiscovery{
// 			DiscoverySource: discoverySourceVal.String,
// 			ScanID:          identityNullStr(scanID),
// 		},
// 		TypeAttributes: identityNullRawOrEmptyObject(typeAttributes),
// 		RawAPIResponse: identityNullRawOrEmptyObject(rawAPIResponse),
// 	}

// 	return d, nil
// }

// // --- local null-handling helpers (shared across identities_*.go files in this package) ---

// func identityNullStr(v sql.NullString) *string {
// 	if !v.Valid {
// 		return nil
// 	}
// 	return &v.String
// }

// func identityNullTime(v sql.NullTime) *time.Time {
// 	if !v.Valid {
// 		return nil
// 	}
// 	return &v.Time
// }

// func identityNullBool(v sql.NullBool) *bool {
// 	if !v.Valid {
// 		return nil
// 	}
// 	return &v.Bool
// }

// func identityNullRawOrEmptyObject(b []byte) []byte {
// 	if len(b) == 0 {
// 		return []byte("{}")
// 	}
// 	return b
// }

// func identityNullRawOrEmptyArray(b []byte) []byte {
// 	if len(b) == 0 {
// 		return []byte("[]")
// 	}
// 	return b
// }

package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

var ErrIdentityNotFound = errors.New("identity not found")

type IdentityDetailRepository struct {
	db *repository.PostgresDB
}

func NewIdentityDetailRepository(db *repository.PostgresDB) *IdentityDetailRepository {
	return &IdentityDetailRepository{db: db}
}

func (r *IdentityDetailRepository) Detail(ctx context.Context, id string) (*modelsinventory.IdentityDetail, error) {
	query := fmt.Sprintf(`
		SELECT
			id::text, arn, name, identity_type, functional_class,
			account_id, region, status,
			created_at_aws, first_seen_at, last_seen_at, last_activity_at, deleted_at,
			vpc_id, subnet_id, security_group_ids, is_publicly_accessible,
			tags, owner, environment,
			parent_arn, cloudtrail_creator_arn,
			discovery_source, scan_id,
			type_attributes, raw_api_response
		FROM %s.identities
		WHERE id = $1::uuid AND deleted_at IS NULL AND `+repository.LatestScanFilter+`
	`, repository.Schema)

	var (
		idVal, arnVal, nameVal, identityTypeVal sql.NullString
		functionalClass                         sql.NullString
		accountIDVal, regionVal, statusVal      sql.NullString
		createdAtAWS, firstSeenAt, lastSeenAt   sql.NullTime
		lastActivityAt, deletedAt               sql.NullTime
		vpcID, subnetID                         sql.NullString
		securityGroupIDs                        []byte
		isPubliclyAccessible                    sql.NullBool
		tags                                    []byte
		owner, environment                      sql.NullString
		parentARN, cloudtrailCreatorARN         sql.NullString
		discoverySourceVal                      sql.NullString
		scanID                                  sql.NullString
		typeAttributes, rawAPIResponse          []byte
	)

	err := r.db.DB.QueryRowContext(ctx, query, id).Scan(
		&idVal, &arnVal, &nameVal, &identityTypeVal, &functionalClass,
		&accountIDVal, &regionVal, &statusVal,
		&createdAtAWS, &firstSeenAt, &lastSeenAt, &lastActivityAt, &deletedAt,
		&vpcID, &subnetID, &securityGroupIDs, &isPubliclyAccessible,
		&tags, &owner, &environment,
		&parentARN, &cloudtrailCreatorARN,
		&discoverySourceVal, &scanID,
		&typeAttributes, &rawAPIResponse,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrIdentityNotFound
		}
		return nil, fmt.Errorf("load identity detail: %w", err)
	}

	d := &modelsinventory.IdentityDetail{
		ID:              idVal.String,
		ARN:             arnVal.String,
		Name:            nameVal.String,
		IdentityType:    identityTypeVal.String,
		FunctionalClass: identityNullStr(functionalClass),
		AccountID:       accountIDVal.String,
		Region:          regionVal.String,
		Status:          statusVal.String,
		CreatedAtAWS:    identityNullTime(createdAtAWS),
		FirstSeenAt:     identityNullTime(firstSeenAt),
		LastSeenAt:      identityNullTime(lastSeenAt),
		LastActivityAt:  identityNullTime(lastActivityAt),
		DeletedAt:       identityNullTime(deletedAt),
		Network: modelsinventory.IdentityNetwork{
			VPCID:                identityNullStr(vpcID),
			SubnetID:             identityNullStr(subnetID),
			SecurityGroupIDs:     identityNullRawOrEmptyArray(securityGroupIDs),
			IsPubliclyAccessible: identityNullBool(isPubliclyAccessible),
		},
		Ownership: modelsinventory.IdentityOwnership{
			Owner:       identityNullStr(owner),
			Environment: identityNullStr(environment),
			Tags:        identityNullRawOrEmptyObject(tags),
		},
		Lineage: modelsinventory.IdentityLineage{
			ParentARN:            identityNullStr(parentARN),
			CloudTrailCreatorARN: identityNullStr(cloudtrailCreatorARN),
		},
		Discovery: modelsinventory.IdentityDiscovery{
			DiscoverySource: discoverySourceVal.String,
			ScanID:          identityNullStr(scanID),
		},
		TypeAttributes: identityNullRawOrEmptyObject(typeAttributes),
		RawAPIResponse: identityNullRawOrEmptyObject(rawAPIResponse),
	}

	return d, nil
}

// --- local null-handling helpers (shared across identities_*.go files in this package) ---

func identityNullStr(v sql.NullString) *string {
	if !v.Valid {
		return nil
	}
	return &v.String
}

func identityNullTime(v sql.NullTime) *time.Time {
	if !v.Valid {
		return nil
	}
	return &v.Time
}

func identityNullBool(v sql.NullBool) *bool {
	if !v.Valid {
		return nil
	}
	return &v.Bool
}

func identityNullRawOrEmptyObject(b []byte) []byte {
	if len(b) == 0 {
		return []byte("{}")
	}
	return b
}

func identityNullRawOrEmptyArray(b []byte) []byte {
	if len(b) == 0 {
		return []byte("[]")
	}
	return b
}
