// package inventory

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentityCountsFilter struct {
// 	AccountID       string
// 	Region          string
// 	FunctionalClass string
// }

// type IdentityCountsRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentityCountsRepository(db *repository.PostgresDB) *IdentityCountsRepository {
// 	return &IdentityCountsRepository{db: db}
// }

// // buildWhere constructs a shared WHERE clause + args from the given filter.
// func (r *IdentityCountsRepository) buildWhere(f IdentityCountsFilter) (string, []interface{}) {
// 	conditions := []string{"deleted_at IS NULL"}
// 	var args []interface{}
// 	argIdx := 1

// 	if f.AccountID != "" {
// 		conditions = append(conditions, fmt.Sprintf("account_id = $%d", argIdx))
// 		args = append(args, f.AccountID)
// 		argIdx++
// 	}

// 	if f.Region != "" {
// 		conditions = append(conditions, fmt.Sprintf("region = $%d", argIdx))
// 		args = append(args, f.Region)
// 		argIdx++
// 	}

// 	if f.FunctionalClass != "" {
// 		conditions = append(conditions, fmt.Sprintf("functional_class = $%d", argIdx))
// 		args = append(args, f.FunctionalClass)
// 		argIdx++
// 	}

// 	return strings.Join(conditions, " AND "), args
// }

// func (r *IdentityCountsRepository) Counts(ctx context.Context, f IdentityCountsFilter) (*modelsinventory.IdentityCountsResponse, error) {
// 	whereClause, args := r.buildWhere(f)

// 	resp := &modelsinventory.IdentityCountsResponse{
// 		ByType:  make(map[string]int),
// 		ByClass: make(map[string]int),
// 	}

// 	// --- counts grouped by status ---
// 	statusQuery := fmt.Sprintf(`
// 		SELECT status, COUNT(*)
// 		FROM %s.identities
// 		WHERE %s
// 		GROUP BY status
// 	`, repository.Schema, whereClause)

// 	statusRows, err := r.db.DB.QueryContext(ctx, statusQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("count identities by status: %w", err)
// 	}
// 	defer statusRows.Close()

// 	for statusRows.Next() {
// 		var status string
// 		var count int
// 		if err := statusRows.Scan(&status, &count); err != nil {
// 			return nil, fmt.Errorf("scan status count: %w", err)
// 		}

// 		resp.Total += count

// 		switch strings.ToLower(status) {
// 		case "active":
// 			resp.Active = count
// 		case "stopped":
// 			resp.Stopped = count
// 		case "terminated":
// 			resp.Terminated = count
// 		}
// 	}
// 	if err := statusRows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate status counts: %w", err)
// 	}

// 	// --- counts grouped by identity_type ---
// 	typeQuery := fmt.Sprintf(`
// 		SELECT identity_type, COUNT(*)
// 		FROM %s.identities
// 		WHERE %s
// 		GROUP BY identity_type
// 	`, repository.Schema, whereClause)

// 	typeRows, err := r.db.DB.QueryContext(ctx, typeQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("count identities by type: %w", err)
// 	}
// 	defer typeRows.Close()

// 	for typeRows.Next() {
// 		var identityType string
// 		var count int
// 		if err := typeRows.Scan(&identityType, &count); err != nil {
// 			return nil, fmt.Errorf("scan type count: %w", err)
// 		}
// 		resp.ByType[identityType] = count
// 	}
// 	if err := typeRows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate type counts: %w", err)
// 	}

// 	// --- counts grouped by functional_class ---
// 	classQuery := fmt.Sprintf(`
// 		SELECT COALESCE(functional_class, 'unclassified'), COUNT(*)
// 		FROM %s.identities
// 		WHERE %s
// 		GROUP BY COALESCE(functional_class, 'unclassified')
// 	`, repository.Schema, whereClause)

// 	classRows, err := r.db.DB.QueryContext(ctx, classQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("count identities by class: %w", err)
// 	}
// 	defer classRows.Close()

// 	for classRows.Next() {
// 		var functionalClass string
// 		var count int
// 		if err := classRows.Scan(&functionalClass, &count); err != nil {
// 			return nil, fmt.Errorf("scan class count: %w", err)
// 		}
// 		resp.ByClass[functionalClass] = count
// 	}
// 	if err := classRows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate class counts: %w", err)
// 	}

// 	return resp, nil
// }

package inventory

import (
	"context"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityCountsFilter struct {
	AccountID       string
	Region          string
	FunctionalClass string
}

type IdentityCountsRepository struct {
	db *repository.PostgresDB
}

func NewIdentityCountsRepository(db *repository.PostgresDB) *IdentityCountsRepository {
	return &IdentityCountsRepository{db: db}
}

// buildWhere constructs a shared WHERE clause + args from the given filter.
func (r *IdentityCountsRepository) buildWhere(f IdentityCountsFilter) (string, []interface{}) {
	conditions := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}
	var args []interface{}
	argIdx := 1

	if f.AccountID != "" {
		conditions = append(conditions, fmt.Sprintf("account_id = $%d", argIdx))
		args = append(args, f.AccountID)
		argIdx++
	}

	if f.Region != "" {
		conditions = append(conditions, fmt.Sprintf("region = $%d", argIdx))
		args = append(args, f.Region)
		argIdx++
	}

	if f.FunctionalClass != "" {
		conditions = append(conditions, fmt.Sprintf("functional_class = $%d", argIdx))
		args = append(args, f.FunctionalClass)
		argIdx++
	}

	return strings.Join(conditions, " AND "), args
}

func (r *IdentityCountsRepository) Counts(ctx context.Context, f IdentityCountsFilter) (*modelsinventory.IdentityCountsResponse, error) {
	whereClause, args := r.buildWhere(f)

	resp := &modelsinventory.IdentityCountsResponse{
		ByType:  make(map[string]int),
		ByClass: make(map[string]int),
	}

	// --- counts grouped by status ---
	statusQuery := fmt.Sprintf(`
		SELECT status, COUNT(*)
		FROM %s.identities
		WHERE %s
		GROUP BY status
	`, repository.Schema, whereClause)

	statusRows, err := r.db.DB.QueryContext(ctx, statusQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("count identities by status: %w", err)
	}
	defer statusRows.Close()

	for statusRows.Next() {
		var status string
		var count int
		if err := statusRows.Scan(&status, &count); err != nil {
			return nil, fmt.Errorf("scan status count: %w", err)
		}

		resp.Total += count

		switch strings.ToLower(status) {
		case "active":
			resp.Active = count
		case "stopped":
			resp.Stopped = count
		case "terminated":
			resp.Terminated = count
		}
	}
	if err := statusRows.Err(); err != nil {
		return nil, fmt.Errorf("iterate status counts: %w", err)
	}

	// --- counts grouped by identity_type ---
	typeQuery := fmt.Sprintf(`
		SELECT identity_type, COUNT(*)
		FROM %s.identities
		WHERE %s
		GROUP BY identity_type
	`, repository.Schema, whereClause)

	typeRows, err := r.db.DB.QueryContext(ctx, typeQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("count identities by type: %w", err)
	}
	defer typeRows.Close()

	for typeRows.Next() {
		var identityType string
		var count int
		if err := typeRows.Scan(&identityType, &count); err != nil {
			return nil, fmt.Errorf("scan type count: %w", err)
		}
		resp.ByType[identityType] = count
	}
	if err := typeRows.Err(); err != nil {
		return nil, fmt.Errorf("iterate type counts: %w", err)
	}

	// --- counts grouped by functional_class ---
	classQuery := fmt.Sprintf(`
		SELECT COALESCE(functional_class, 'unclassified'), COUNT(*)
		FROM %s.identities
		WHERE %s
		GROUP BY COALESCE(functional_class, 'unclassified')
	`, repository.Schema, whereClause)

	classRows, err := r.db.DB.QueryContext(ctx, classQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("count identities by class: %w", err)
	}
	defer classRows.Close()

	for classRows.Next() {
		var functionalClass string
		var count int
		if err := classRows.Scan(&functionalClass, &count); err != nil {
			return nil, fmt.Errorf("scan class count: %w", err)
		}
		resp.ByClass[functionalClass] = count
	}
	if err := classRows.Err(); err != nil {
		return nil, fmt.Errorf("iterate class counts: %w", err)
	}

	return resp, nil
}
