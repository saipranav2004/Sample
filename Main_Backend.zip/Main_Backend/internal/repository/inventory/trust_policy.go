// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"strings"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// // TrustPolicyRepository handles trust policy queries.
// type TrustPolicyRepository struct {
// 	db *repository.PostgresDB
// }

// func NewTrustPolicyRepository(db *repository.PostgresDB) *TrustPolicyRepository {
// 	return &TrustPolicyRepository{db: db}
// }

// func (r *TrustPolicyRepository) GetTrustPolicy(
// 	ctx context.Context,
// 	id string,
// ) (*inventorymodels.TrustPolicyResponse, error) {

// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text,
// 			COALESCE(trust_policy, '{}'::jsonb) AS trust_policy
// 		FROM %s.credentials
// 		WHERE id = $1::uuid
// 		  AND deleted_at IS NULL
// 		LIMIT 1
// 	`, repository.Schema)

// 	var credID string
// 	var trustPolicyRaw []byte

// 	if err := r.db.DB.QueryRowContext(ctx, query, id).
// 		Scan(&credID, &trustPolicyRaw); err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, fmt.Errorf("credential '%s' not found", id)
// 		}
// 		return nil, fmt.Errorf("query trust policy: %w", err)
// 	}

// 	var rawPolicy map[string]interface{}
// 	if len(trustPolicyRaw) > 0 {
// 		_ = json.Unmarshal(trustPolicyRaw, &rawPolicy)
// 	}

// 	statements := parseTrustPolicyStatements(rawPolicy)
// 	riskSummary := computeTrustPolicyRisk(statements)

// 	return &inventorymodels.TrustPolicyResponse{
// 		CredentialID: credID,
// 		TrustPolicy: inventorymodels.TrustPolicyDetail{
// 			Statements:  statements,
// 			RiskSummary: riskSummary,
// 		},
// 	}, nil
// }

// func parseTrustPolicyStatements(rawPolicy map[string]interface{}) []inventorymodels.TrustPolicyStatement {
// 	statements := []inventorymodels.TrustPolicyStatement{}
// 	if rawPolicy == nil {
// 		return statements
// 	}

// 	rawStmts, ok := rawPolicy["Statement"].([]interface{})
// 	if !ok {
// 		return statements
// 	}

// 	for _, s := range rawStmts {
// 		stmtMap, ok := s.(map[string]interface{})
// 		if !ok {
// 			continue
// 		}

// 		stmt := inventorymodels.TrustPolicyStatement{
// 			Conditions: []inventorymodels.TrustPolicyCondition{},
// 		}

// 		if v, ok := stmtMap["Effect"].(string); ok {
// 			stmt.Effect = v
// 		}

// 		switch action := stmtMap["Action"].(type) {
// 		case string:
// 			stmt.Action = action
// 		case []interface{}:
// 			parts := []string{}
// 			for _, a := range action {
// 				if s, ok := a.(string); ok {
// 					parts = append(parts, s)
// 				}
// 			}
// 			stmt.Action = strings.Join(parts, ", ")
// 		}

// 		switch principal := stmtMap["Principal"].(type) {
// 		case string:
// 			stmt.PrincipalType = "AWS"
// 			stmt.PrincipalValue = principal
// 		case map[string]interface{}:
// 			for pType, pVal := range principal {
// 				stmt.PrincipalType = pType
// 				switch v := pVal.(type) {
// 				case string:
// 					stmt.PrincipalValue = v
// 				case []interface{}:
// 					vals := []string{}
// 					for _, item := range v {
// 						if s, ok := item.(string); ok {
// 							vals = append(vals, s)
// 						}
// 					}
// 					stmt.PrincipalValue = strings.Join(vals, ", ")
// 				}
// 				break
// 			}
// 		}

// 		if condMap, ok := stmtMap["Condition"].(map[string]interface{}); ok {
// 			for operator, keyVals := range condMap {
// 				if kvMap, ok := keyVals.(map[string]interface{}); ok {
// 					for key, val := range kvMap {
// 						valStr := ""
// 						switch v := val.(type) {
// 						case string:
// 							valStr = v
// 						case []interface{}:
// 							parts := []string{}
// 							for _, item := range v {
// 								if s, ok := item.(string); ok {
// 									parts = append(parts, s)
// 								}
// 							}
// 							valStr = strings.Join(parts, ", ")
// 						}
// 						stmt.Conditions = append(stmt.Conditions,
// 							inventorymodels.TrustPolicyCondition{
// 								Operator: operator,
// 								Key:      key,
// 								Value:    valStr,
// 							})
// 					}
// 				}
// 			}
// 		}

// 		statements = append(statements, stmt)
// 	}

// 	return statements
// }

// func computeTrustPolicyRisk(statements []inventorymodels.TrustPolicyStatement) inventorymodels.TrustPolicyRiskSummary {
// 	risk := inventorymodels.TrustPolicyRiskSummary{}
// 	for _, stmt := range statements {
// 		if stmt.Effect != "Allow" {
// 			continue
// 		}
// 		pv := stmt.PrincipalValue
// 		if pv == "*" {
// 			risk.IsPublic = true
// 			risk.HasWildcardPrincipal = true
// 		}
// 		if strings.Contains(pv, "*") {
// 			risk.HasWildcardPrincipal = true
// 		}
// 		if stmt.PrincipalType == "AWS" &&
// 			strings.Contains(pv, "arn:aws:iam::") {
// 			risk.HasExternalAccount = true
// 		}
// 	}
// 	return risk
// }

package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// TrustPolicyRepository handles trust policy queries.
type TrustPolicyRepository struct {
	db *repository.PostgresDB
}

func NewTrustPolicyRepository(db *repository.PostgresDB) *TrustPolicyRepository {
	return &TrustPolicyRepository{db: db}
}

func (r *TrustPolicyRepository) GetTrustPolicy(
	ctx context.Context,
	id string,
) (*inventorymodels.TrustPolicyResponse, error) {

	query := fmt.Sprintf(`
		SELECT
			id::text,
			COALESCE(trust_policy, '{}'::jsonb) AS trust_policy
		FROM %s.credentials
		WHERE id = $1::uuid
		  AND deleted_at IS NULL AND `+repository.LatestScanFilter+`
		LIMIT 1
	`, repository.Schema)

	var credID string
	var trustPolicyRaw []byte

	if err := r.db.DB.QueryRowContext(ctx, query, id).
		Scan(&credID, &trustPolicyRaw); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("credential '%s' not found", id)
		}
		return nil, fmt.Errorf("query trust policy: %w", err)
	}

	var rawPolicy map[string]interface{}
	if len(trustPolicyRaw) > 0 {
		_ = json.Unmarshal(trustPolicyRaw, &rawPolicy)
	}

	statements := parseTrustPolicyStatements(rawPolicy)
	riskSummary := computeTrustPolicyRisk(statements)

	return &inventorymodels.TrustPolicyResponse{
		CredentialID: credID,
		TrustPolicy: inventorymodels.TrustPolicyDetail{
			Statements:  statements,
			RiskSummary: riskSummary,
		},
	}, nil
}

func parseTrustPolicyStatements(rawPolicy map[string]interface{}) []inventorymodels.TrustPolicyStatement {
	statements := []inventorymodels.TrustPolicyStatement{}
	if rawPolicy == nil {
		return statements
	}

	rawStmts, ok := rawPolicy["Statement"].([]interface{})
	if !ok {
		return statements
	}

	for _, s := range rawStmts {
		stmtMap, ok := s.(map[string]interface{})
		if !ok {
			continue
		}

		stmt := inventorymodels.TrustPolicyStatement{
			Conditions: []inventorymodels.TrustPolicyCondition{},
		}

		if v, ok := stmtMap["Effect"].(string); ok {
			stmt.Effect = v
		}

		switch action := stmtMap["Action"].(type) {
		case string:
			stmt.Action = action
		case []interface{}:
			parts := []string{}
			for _, a := range action {
				if s, ok := a.(string); ok {
					parts = append(parts, s)
				}
			}
			stmt.Action = strings.Join(parts, ", ")
		}

		switch principal := stmtMap["Principal"].(type) {
		case string:
			stmt.PrincipalType = "AWS"
			stmt.PrincipalValue = principal
		case map[string]interface{}:
			for pType, pVal := range principal {
				stmt.PrincipalType = pType
				switch v := pVal.(type) {
				case string:
					stmt.PrincipalValue = v
				case []interface{}:
					vals := []string{}
					for _, item := range v {
						if s, ok := item.(string); ok {
							vals = append(vals, s)
						}
					}
					stmt.PrincipalValue = strings.Join(vals, ", ")
				}
				break
			}
		}

		if condMap, ok := stmtMap["Condition"].(map[string]interface{}); ok {
			for operator, keyVals := range condMap {
				if kvMap, ok := keyVals.(map[string]interface{}); ok {
					for key, val := range kvMap {
						valStr := ""
						switch v := val.(type) {
						case string:
							valStr = v
						case []interface{}:
							parts := []string{}
							for _, item := range v {
								if s, ok := item.(string); ok {
									parts = append(parts, s)
								}
							}
							valStr = strings.Join(parts, ", ")
						}
						stmt.Conditions = append(stmt.Conditions,
							inventorymodels.TrustPolicyCondition{
								Operator: operator,
								Key:      key,
								Value:    valStr,
							})
					}
				}
			}
		}

		statements = append(statements, stmt)
	}

	return statements
}

func computeTrustPolicyRisk(statements []inventorymodels.TrustPolicyStatement) inventorymodels.TrustPolicyRiskSummary {
	risk := inventorymodels.TrustPolicyRiskSummary{}
	for _, stmt := range statements {
		if stmt.Effect != "Allow" {
			continue
		}
		pv := stmt.PrincipalValue
		if pv == "*" {
			risk.IsPublic = true
			risk.HasWildcardPrincipal = true
		}
		if strings.Contains(pv, "*") {
			risk.HasWildcardPrincipal = true
		}
		if stmt.PrincipalType == "AWS" &&
			strings.Contains(pv, "arn:aws:iam::") {
			risk.HasExternalAccount = true
		}
	}
	return risk
}
