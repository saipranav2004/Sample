// package inventory

// import (
// 	"context"
// 	"encoding/json"
// 	"fmt"
// 	"strings"

// 	invmodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type CredentialExportRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialExportRepository(db *repository.PostgresDB) *CredentialExportRepository {
// 	return &CredentialExportRepository{db: db}
// }

// func (r *CredentialExportRepository) table() string {
// 	return fmt.Sprintf("%s.credentials", repository.Schema)
// }

// // ---------- validation helpers (DB driven) ----------

// func (r *CredentialExportRepository) existsIn(ctx context.Context, col, val string) (bool, error) {
// 	q := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s WHERE LOWER(COALESCE(%s::text,'')) = LOWER($1))`, r.table(), col)
// 	var ok bool
// 	if err := r.db.DB.QueryRowContext(ctx, q, val).Scan(&ok); err != nil {
// 		return false, err
// 	}
// 	return ok, nil
// }

// func (r *CredentialExportRepository) listDistinct(ctx context.Context, col string) ([]string, error) {
// 	q := fmt.Sprintf(`SELECT DISTINCT %s::text FROM %s WHERE %s IS NOT NULL AND %s::text <> '' ORDER BY 1`,
// 		col, r.table(), col, col)
// 	rows, err := r.db.DB.QueryContext(ctx, q)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer rows.Close()

// 	out := make([]string, 0)
// 	for rows.Next() {
// 		var s string
// 		if err := rows.Scan(&s); err != nil {
// 			return nil, err
// 		}
// 		out = append(out, s)
// 	}
// 	return out, rows.Err()
// }

// func (r *CredentialExportRepository) AccountIDExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "account_id", v)
// }
// func (r *CredentialExportRepository) CredentialTypeExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "credential_type", v)
// }
// func (r *CredentialExportRepository) RegionExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "region", v)
// }
// func (r *CredentialExportRepository) StatusExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "status", v)
// }
// func (r *CredentialExportRepository) ListCredentialTypes(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "credential_type")
// }
// func (r *CredentialExportRepository) ListRegions(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "region")
// }
// func (r *CredentialExportRepository) ListStatuses(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "status")
// }

// // ---------- query building ----------

// var exportSortColumns = map[string]string{
// 	"name":            "name",
// 	"credential_type": "credential_type",
// 	"account_id":      "account_id",
// 	"region":          "region",
// 	"status":          "status",
// 	"created_at_aws":  "created_at_aws",
// 	"first_seen_at":   "first_seen_at",
// 	"last_seen_at":    "last_seen_at",
// 	"last_used_at":    "last_used_at",
// 	"expires_at":      "expires_at",
// 	"privilege_level": "privilege_level",
// }

// var exportLikeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

// func exportBuildWhere(f invmodels.ExportCredentialFilter) (string, []interface{}) {
// 	conds := []string{"deleted_at IS NULL"}
// 	args := make([]interface{}, 0)

// 	add := func(cond string, v interface{}) {
// 		args = append(args, v)
// 		conds = append(conds, strings.ReplaceAll(cond, "?", fmt.Sprintf("$%d", len(args))))
// 	}

// 	if f.Search != "" {
// 		add(`(name ILIKE ? OR arn ILIKE ?)`, "%"+exportLikeEscaper.Replace(f.Search)+"%")
// 	}
// 	if f.CredentialType != "" {
// 		add(`LOWER(credential_type) = LOWER(?)`, f.CredentialType)
// 	}
// 	if f.AccountID != "" {
// 		add(`account_id = ?`, f.AccountID)
// 	}
// 	if f.Region != "" {
// 		add(`LOWER(region) = LOWER(?)`, f.Region)
// 	}
// 	if f.Status != "" {
// 		add(`LOWER(COALESCE(status,'')) = LOWER(?)`, f.Status)
// 	}
// 	if f.RotationEnabled != nil {
// 		add(`rotation_enabled = ?`, *f.RotationEnabled)
// 	}
// 	if f.ExpiringWithinDays != nil {
// 		add(`(expires_at IS NOT NULL AND expires_at > NOW() AND expires_at <= NOW() + make_interval(days => ?::int))`, *f.ExpiringWithinDays)
// 	}
// 	if f.StaleDays != nil {
// 		add(`(last_used_at IS NULL OR last_used_at < NOW() - make_interval(days => ?::int))`, *f.StaleDays)
// 	}
// 	if f.PrivilegeLevelMin != nil {
// 		add(`privilege_level >= ?`, *f.PrivilegeLevelMin)
// 	}
// 	if f.PrivilegeLevelMax != nil {
// 		add(`privilege_level <= ?`, *f.PrivilegeLevelMax)
// 	}
// 	if f.OwnerPrincipalARN != "" {
// 		add(`owner_principal_arn = ?`, f.OwnerPrincipalARN)
// 	}

// 	return " WHERE " + strings.Join(conds, " AND "), args
// }

// func exportJSONOr(b []byte, def string) json.RawMessage {
// 	t := strings.TrimSpace(string(b))
// 	if t == "" || t == "null" {
// 		return json.RawMessage(def)
// 	}
// 	return json.RawMessage(t)
// }

// // ---------- count ----------

// // Count returns the total number of rows matching the filters (ignores page/limit).
// func (r *CredentialExportRepository) Count(ctx context.Context, f invmodels.ExportCredentialFilter) (int, error) {
// 	where, args := exportBuildWhere(f)
// 	q := fmt.Sprintf(`SELECT COUNT(*) FROM %s%s`, r.table(), where)

// 	var n int
// 	if err := r.db.DB.QueryRowContext(ctx, q, args...).Scan(&n); err != nil {
// 		return 0, err
// 	}
// 	return n, nil
// }

// // ---------- stream ----------

// // Stream runs the query and calls fn for every row, without loading all rows in memory.
// // If f.Limit is set, only that page is returned (f.Page defaults to 1).
// func (r *CredentialExportRepository) Stream(
// 	ctx context.Context,
// 	f invmodels.ExportCredentialFilter,
// 	fn func(*invmodels.ExportCredential) error,
// ) error {
// 	where, args := exportBuildWhere(f)

// 	col, ok := exportSortColumns[strings.ToLower(f.SortBy)]
// 	if !ok {
// 		col = "name"
// 	}
// 	dir := "ASC"
// 	if strings.EqualFold(f.SortOrder, "desc") {
// 		dir = "DESC"
// 	}

// 	q := fmt.Sprintf(`
// SELECT
//   id::text, COALESCE(arn,''), COALESCE(name,''), COALESCE(credential_type,''),
//   COALESCE(account_id,''), COALESCE(region,''), COALESCE(status,''),
//   created_at_aws, first_seen_at, last_seen_at, last_used_at, last_rotated_at, expires_at,
//   rotation_enabled, rotation_interval_days, tags, owner_principal_arn,
//   trust_policy, attached_policies, inline_policies, permission_boundary_arn,
//   max_session_duration, privilege_level, assumable_role_arns,
//   type_attributes, discovery_source, scan_id
// FROM %s%s
// ORDER BY %s %s NULLS LAST, id ASC`, r.table(), where, col, dir)

// 	// pagination (only when limit is provided)
// 	if f.Limit != nil {
// 		page := 1
// 		if f.Page != nil {
// 			page = *f.Page
// 		}
// 		args = append(args, *f.Limit)
// 		q += fmt.Sprintf(" LIMIT $%d", len(args))
// 		args = append(args, (page-1)*(*f.Limit))
// 		q += fmt.Sprintf(" OFFSET $%d", len(args))
// 	}

// 	rows, err := r.db.DB.QueryContext(ctx, q, args...)
// 	if err != nil {
// 		return err
// 	}
// 	defer rows.Close()

// 	for rows.Next() {
// 		var c invmodels.ExportCredential
// 		var tags, trust, attached, inline, assumable, typeAttrs []byte

// 		if err := rows.Scan(
// 			&c.ID, &c.ARN, &c.Name, &c.CredentialType,
// 			&c.AccountID, &c.Region, &c.Status,
// 			&c.CreatedAtAWS, &c.FirstSeenAt, &c.LastSeenAt, &c.LastUsedAt, &c.LastRotatedAt, &c.ExpiresAt,
// 			&c.RotationEnabled, &c.RotationIntervalDays, &tags, &c.OwnerPrincipalARN,
// 			&trust, &attached, &inline, &c.IAMRoleDetails.PermissionBoundaryARN,
// 			&c.IAMRoleDetails.MaxSessionDuration, &c.IAMRoleDetails.PrivilegeLevel, &assumable,
// 			&typeAttrs, &c.Discovery.DiscoverySource, &c.Discovery.ScanID,
// 		); err != nil {
// 			return err
// 		}

// 		c.Tags = exportJSONOr(tags, "{}")
// 		c.TypeAttributes = exportJSONOr(typeAttrs, "{}")
// 		c.IAMRoleDetails.TrustPolicy = exportJSONOr(trust, "{}")
// 		c.IAMRoleDetails.AttachedPolicies = exportJSONOr(attached, "[]")
// 		c.IAMRoleDetails.InlinePolicies = exportJSONOr(inline, "[]")
// 		c.IAMRoleDetails.AssumableRoleARNs = exportJSONOr(assumable, "[]")

// 		if err := fn(&c); err != nil {
// 			return err
// 		}
// 	}
// 	return rows.Err()
// }

package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	invmodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type CredentialExportRepository struct {
	db *repository.PostgresDB
}

func NewCredentialExportRepository(db *repository.PostgresDB) *CredentialExportRepository {
	return &CredentialExportRepository{db: db}
}

func (r *CredentialExportRepository) table() string {
	return fmt.Sprintf("%s.credentials", repository.Schema)
}

// ---------- validation helpers (DB driven) ----------

func (r *CredentialExportRepository) existsIn(ctx context.Context, col, val string) (bool, error) {
	q := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s WHERE %s AND LOWER(COALESCE(%s::text,'')) = LOWER($1))`, r.table(), repository.LatestScanFilter, col)
	var ok bool
	if err := r.db.DB.QueryRowContext(ctx, q, val).Scan(&ok); err != nil {
		return false, err
	}
	return ok, nil
}

func (r *CredentialExportRepository) listDistinct(ctx context.Context, col string) ([]string, error) {
	q := fmt.Sprintf(`SELECT DISTINCT %s::text FROM %s WHERE %s AND %s IS NOT NULL AND %s::text <> '' ORDER BY 1`,
		col, r.table(), repository.LatestScanFilter, col, col)
	rows, err := r.db.DB.QueryContext(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]string, 0)
	for rows.Next() {
		var s string
		if err := rows.Scan(&s); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

func (r *CredentialExportRepository) AccountIDExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "account_id", v)
}
func (r *CredentialExportRepository) CredentialTypeExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "credential_type", v)
}
func (r *CredentialExportRepository) RegionExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "region", v)
}
func (r *CredentialExportRepository) StatusExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "status", v)
}
func (r *CredentialExportRepository) ListCredentialTypes(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "credential_type")
}
func (r *CredentialExportRepository) ListRegions(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "region")
}
func (r *CredentialExportRepository) ListStatuses(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "status")
}

// ---------- query building ----------

var exportSortColumns = map[string]string{
	"name":            "name",
	"credential_type": "credential_type",
	"account_id":      "account_id",
	"region":          "region",
	"status":          "status",
	"created_at_aws":  "created_at_aws",
	"first_seen_at":   "first_seen_at",
	"last_seen_at":    "last_seen_at",
	"last_used_at":    "last_used_at",
	"expires_at":      "expires_at",
	"privilege_level": "privilege_level",
}

var exportLikeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

func exportBuildWhere(f invmodels.ExportCredentialFilter) (string, []interface{}) {
	conds := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}
	args := make([]interface{}, 0)

	add := func(cond string, v interface{}) {
		args = append(args, v)
		conds = append(conds, strings.ReplaceAll(cond, "?", fmt.Sprintf("$%d", len(args))))
	}

	if f.Search != "" {
		add(`(name ILIKE ? OR arn ILIKE ?)`, "%"+exportLikeEscaper.Replace(f.Search)+"%")
	}
	if f.CredentialType != "" {
		add(`LOWER(credential_type) = LOWER(?)`, f.CredentialType)
	}
	if f.AccountID != "" {
		add(`account_id = ?`, f.AccountID)
	}
	if f.Region != "" {
		add(`LOWER(region) = LOWER(?)`, f.Region)
	}
	if f.Status != "" {
		add(`LOWER(COALESCE(status,'')) = LOWER(?)`, f.Status)
	}
	if f.RotationEnabled != nil {
		add(`rotation_enabled = ?`, *f.RotationEnabled)
	}
	if f.ExpiringWithinDays != nil {
		add(`(expires_at IS NOT NULL AND expires_at > NOW() AND expires_at <= NOW() + make_interval(days => ?::int))`, *f.ExpiringWithinDays)
	}
	if f.StaleDays != nil {
		add(`(last_used_at IS NULL OR last_used_at < NOW() - make_interval(days => ?::int))`, *f.StaleDays)
	}
	if f.PrivilegeLevelMin != nil {
		add(`privilege_level >= ?`, *f.PrivilegeLevelMin)
	}
	if f.PrivilegeLevelMax != nil {
		add(`privilege_level <= ?`, *f.PrivilegeLevelMax)
	}
	if f.OwnerPrincipalARN != "" {
		add(`owner_principal_arn = ?`, f.OwnerPrincipalARN)
	}

	return " WHERE " + strings.Join(conds, " AND "), args
}

func exportJSONOr(b []byte, def string) json.RawMessage {
	t := strings.TrimSpace(string(b))
	if t == "" || t == "null" {
		return json.RawMessage(def)
	}
	return json.RawMessage(t)
}

// ---------- count ----------

// Count returns the total number of rows matching the filters (ignores page/limit).
func (r *CredentialExportRepository) Count(ctx context.Context, f invmodels.ExportCredentialFilter) (int, error) {
	where, args := exportBuildWhere(f)
	q := fmt.Sprintf(`SELECT COUNT(*) FROM %s%s`, r.table(), where)

	var n int
	if err := r.db.DB.QueryRowContext(ctx, q, args...).Scan(&n); err != nil {
		return 0, err
	}
	return n, nil
}

// ---------- stream ----------

// Stream runs the query and calls fn for every row, without loading all rows in memory.
// If f.Limit is set, only that page is returned (f.Page defaults to 1).
func (r *CredentialExportRepository) Stream(
	ctx context.Context,
	f invmodels.ExportCredentialFilter,
	fn func(*invmodels.ExportCredential) error,
) error {
	where, args := exportBuildWhere(f)

	col, ok := exportSortColumns[strings.ToLower(f.SortBy)]
	if !ok {
		col = "name"
	}
	dir := "ASC"
	if strings.EqualFold(f.SortOrder, "desc") {
		dir = "DESC"
	}

	q := fmt.Sprintf(`
SELECT
  id::text, COALESCE(arn,''), COALESCE(name,''), COALESCE(credential_type,''),
  COALESCE(account_id,''), COALESCE(region,''), COALESCE(status,''),
  created_at_aws, first_seen_at, last_seen_at, last_used_at, last_rotated_at, expires_at,
  rotation_enabled, rotation_interval_days, tags, owner_principal_arn,
  trust_policy, attached_policies, inline_policies, permission_boundary_arn,
  max_session_duration, privilege_level, assumable_role_arns,
  type_attributes, discovery_source, scan_id
FROM %s%s
ORDER BY %s %s NULLS LAST, id ASC`, r.table(), where, col, dir)

	// pagination (only when limit is provided)
	if f.Limit != nil {
		page := 1
		if f.Page != nil {
			page = *f.Page
		}
		args = append(args, *f.Limit)
		q += fmt.Sprintf(" LIMIT $%d", len(args))
		args = append(args, (page-1)*(*f.Limit))
		q += fmt.Sprintf(" OFFSET $%d", len(args))
	}

	rows, err := r.db.DB.QueryContext(ctx, q, args...)
	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var c invmodels.ExportCredential
		var tags, trust, attached, inline, assumable, typeAttrs []byte

		if err := rows.Scan(
			&c.ID, &c.ARN, &c.Name, &c.CredentialType,
			&c.AccountID, &c.Region, &c.Status,
			&c.CreatedAtAWS, &c.FirstSeenAt, &c.LastSeenAt, &c.LastUsedAt, &c.LastRotatedAt, &c.ExpiresAt,
			&c.RotationEnabled, &c.RotationIntervalDays, &tags, &c.OwnerPrincipalARN,
			&trust, &attached, &inline, &c.IAMRoleDetails.PermissionBoundaryARN,
			&c.IAMRoleDetails.MaxSessionDuration, &c.IAMRoleDetails.PrivilegeLevel, &assumable,
			&typeAttrs, &c.Discovery.DiscoverySource, &c.Discovery.ScanID,
		); err != nil {
			return err
		}

		c.Tags = exportJSONOr(tags, "{}")
		c.TypeAttributes = exportJSONOr(typeAttrs, "{}")
		c.IAMRoleDetails.TrustPolicy = exportJSONOr(trust, "{}")
		c.IAMRoleDetails.AttachedPolicies = exportJSONOr(attached, "[]")
		c.IAMRoleDetails.InlinePolicies = exportJSONOr(inline, "[]")
		c.IAMRoleDetails.AssumableRoleARNs = exportJSONOr(assumable, "[]")

		if err := fn(&c); err != nil {
			return err
		}
	}
	return rows.Err()
}
