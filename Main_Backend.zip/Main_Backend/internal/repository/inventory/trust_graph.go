package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"sort"
	"strings"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

type TrustGraphRepository struct{ db *sql.DB }

func NewTrustGraphRepository(db *sql.DB) *TrustGraphRepository { return &TrustGraphRepository{db: db} }

func (r *TrustGraphRepository) Graph(ctx context.Context, allowed []string, accountID, edgeType string) (*m.TrustGraphResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("trust graph source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin trust graph snapshot: %w", err)
	}
	defer tx.Rollback()
	scanID, err := latestCompletedCredentialScan(ctx, tx, "")
	if err != nil {
		return nil, err
	}
	out := &m.TrustGraphResponse{ScanID: scanID, Nodes: []m.TrustGraphNode{}, Edges: []m.TrustGraphEdge{}}
	nodes := make(map[string]m.TrustGraphNode)

	credRows, err := tx.QueryContext(ctx, `SELECT arn,COALESCE(name,''),COALESCE(credential_type,'credential'),privilege_level
FROM nhi_scanner.credentials
WHERE scan_id=$1::text AND account_id=ANY($2::text[]) AND ($3::text='' OR account_id=$3::text)
  AND deleted_at IS NULL AND NULLIF(BTRIM(COALESCE(arn,'')),'') IS NOT NULL`, scanID, pq.Array(allowed), accountID)
	if err != nil {
		return nil, fmt.Errorf("query trust graph credentials: %w", err)
	}
	for credRows.Next() {
		var arn, name, typ string
		var privilege sql.NullInt64
		if err := credRows.Scan(&arn, &name, &typ, &privilege); err != nil {
			credRows.Close()
			return nil, fmt.Errorf("scan trust graph credential: %w", err)
		}
		if strings.TrimSpace(name) == "" {
			name = arn
		}
		n := m.TrustGraphNode{ID: arn, Label: name, Type: "credential"}
		if privilege.Valid {
			v := int(privilege.Int64)
			n.Privilege = &v
		}
		nodes[arn] = n
	}
	if err := credRows.Err(); err != nil {
		credRows.Close()
		return nil, fmt.Errorf("iterate trust graph credentials: %w", err)
	}
	if err := credRows.Close(); err != nil {
		return nil, fmt.Errorf("close trust graph credentials: %w", err)
	}

	idRows, err := tx.QueryContext(ctx, `SELECT arn,COALESCE(name,''),COALESCE(identity_type,'identity')
FROM nhi_scanner.identities
WHERE scan_id=$1::text AND account_id=ANY($2::text[]) AND ($3::text='' OR account_id=$3::text)
  AND NULLIF(BTRIM(COALESCE(arn,'')),'') IS NOT NULL`, scanID, pq.Array(allowed), accountID)
	if err != nil {
		return nil, fmt.Errorf("query trust graph identities: %w", err)
	}
	for idRows.Next() {
		var arn, name, typ string
		if err := idRows.Scan(&arn, &name, &typ); err != nil {
			idRows.Close()
			return nil, fmt.Errorf("scan trust graph identity: %w", err)
		}
		if strings.TrimSpace(name) == "" {
			name = arn
		}
		nodes[arn] = m.TrustGraphNode{ID: arn, Label: name, Type: "identity"}
	}
	if err := idRows.Err(); err != nil {
		idRows.Close()
		return nil, fmt.Errorf("iterate trust graph identities: %w", err)
	}
	if err := idRows.Close(); err != nil {
		return nil, fmt.Errorf("close trust graph identities: %w", err)
	}

	rows, err := tx.QueryContext(ctx, `SELECT source_arn,target_arn,COALESCE(edge_type,'unknown')
FROM nhi_scanner.trust_edges
WHERE scan_id=$1::text AND LOWER(BTRIM(COALESCE(is_active::text,''))) IN ('1','t','true','yes','y')
  AND ($2::text='' OR LOWER(edge_type)=LOWER($2::text))
ORDER BY source_arn,target_arn,edge_type`, scanID, edgeType)
	if err != nil {
		return nil, fmt.Errorf("query trust graph edges: %w", err)
	}
	for rows.Next() {
		var source, target, typ string
		if err := rows.Scan(&source, &target, &typ); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan trust graph edge: %w", err)
		}
		// Expose only edges connected to an entity inside the caller's authorized latest-scan scope.
		if _, sourceKnown := nodes[source]; !sourceKnown {
			if _, targetKnown := nodes[target]; !targetKnown {
				continue
			}
		}
		out.Edges = append(out.Edges, m.TrustGraphEdge{Source: source, Target: target, Type: typ})
		for _, arn := range []string{source, target} {
			if _, ok := nodes[arn]; !ok {
				typNode := "external"
				lt := strings.ToLower(typ)
				if strings.Contains(lt, "federated") || strings.Contains(lt, "oidc") || strings.Contains(lt, "saml") || strings.Contains(arn, ".") && !strings.HasPrefix(arn, "arn:") {
					typNode = "federated"
				}
				nodes[arn] = m.TrustGraphNode{ID: arn, Label: arn, Type: typNode}
			}
		}
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate trust graph edges: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close trust graph edges: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit trust graph snapshot: %w", err)
	}
	for _, node := range nodes {
		out.Nodes = append(out.Nodes, node)
	}
	sort.Slice(out.Nodes, func(i, j int) bool { return out.Nodes[i].ID < out.Nodes[j].ID })
	sort.Slice(out.Edges, func(i, j int) bool {
		if out.Edges[i].Source != out.Edges[j].Source {
			return out.Edges[i].Source < out.Edges[j].Source
		}
		if out.Edges[i].Target != out.Edges[j].Target {
			return out.Edges[i].Target < out.Edges[j].Target
		}
		return out.Edges[i].Type < out.Edges[j].Type
	})
	return out, nil
}
