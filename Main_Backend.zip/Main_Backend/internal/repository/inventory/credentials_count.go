// package inventory

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// // CredentialCountRepository handles DB queries for credential counts.
// type CredentialCountRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialCountRepository(db *repository.PostgresDB) *CredentialCountRepository {
// 	return &CredentialCountRepository{db: db}
// }

// func (r *CredentialCountRepository) GetCounts(
// 	ctx context.Context,
// 	f inventorymodels.CredentialCountFilter,
// ) (*inventorymodels.CredentialCountResponse, error) {

// 	args := []interface{}{}
// 	argIdx := 1

// 	addArg := func(v interface{}) string {
// 		args = append(args, v)
// 		ph := fmt.Sprintf("$%d", argIdx)
// 		argIdx++
// 		return ph
// 	}

// 	// ── WHERE ─────────────────────────────────────────────────────────────
// 	where := []string{"deleted_at IS NULL"}

// 	if strings.TrimSpace(f.AccountID) != "" {
// 		where = append(where,
// 			fmt.Sprintf("account_id = %s", addArg(f.AccountID)))
// 	}

// 	if strings.TrimSpace(f.Region) != "" {
// 		where = append(where,
// 			fmt.Sprintf("region = %s", addArg(f.Region)))
// 	}

// 	whereClause := "WHERE " + strings.Join(where, " AND ")

// 	// ── Summary counts ────────────────────────────────────────────────────
// 	summaryQuery := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*)                                                   AS total,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'active')          AS active,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'inactive')        AS inactive,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'expired')         AS expired,
// 			COUNT(*) FILTER (
// 				WHERE expires_at IS NOT NULL
// 				  AND expires_at > NOW()
// 				  AND expires_at <= NOW() + INTERVAL '30 days'
// 			)                                                          AS expiring_within_30d,
// 			COUNT(*) FILTER (
// 				WHERE last_used_at IS NOT NULL
// 				  AND last_used_at < NOW() - INTERVAL '90 days'
// 			)                                                          AS stale_90d,
// 			COUNT(*) FILTER (
// 				WHERE privilege_level IS NOT NULL
// 				  AND privilege_level >= 7
// 			)                                                          AS high_privilege
// 		FROM %s.credentials
// 		%s
// 	`, repository.Schema, whereClause)

// 	var (
// 		total             int
// 		active            int
// 		inactive          int
// 		expired           int
// 		expiringWithin30d int
// 		stale90d          int
// 		highPrivilege     int
// 	)

// 	if err := r.db.DB.QueryRowContext(ctx, summaryQuery, args...).Scan(
// 		&total,
// 		&active,
// 		&inactive,
// 		&expired,
// 		&expiringWithin30d,
// 		&stale90d,
// 		&highPrivilege,
// 	); err != nil {
// 		return nil, fmt.Errorf("query credential counts: %w", err)
// 	}

// 	// ── Per-type breakdown ────────────────────────────────────────────────
// 	byTypeQuery := fmt.Sprintf(`
// 		SELECT
// 			credential_type,
// 			COUNT(*) AS count
// 		FROM %s.credentials
// 		%s
// 		GROUP BY credential_type
// 		ORDER BY count DESC
// 	`, repository.Schema, whereClause)

// 	rows, err := r.db.DB.QueryContext(ctx, byTypeQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("query credential counts by type: %w", err)
// 	}
// 	defer rows.Close()

// 	byType := make(inventorymodels.CredentialCountByType)

// 	for rows.Next() {
// 		var credType string
// 		var count int
// 		if err := rows.Scan(&credType, &count); err != nil {
// 			return nil, fmt.Errorf("scan credential count row: %w", err)
// 		}
// 		byType[credType] = count
// 	}

// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate credential count rows: %w", err)
// 	}

// 	return &inventorymodels.CredentialCountResponse{
// 		Total:             total,
// 		Active:            active,
// 		Inactive:          inactive,
// 		Expired:           expired,
// 		ByType:            byType,
// 		ExpiringWithin30d: expiringWithin30d,
// 		Stale90d:          stale90d,
// 		HighPrivilege:     highPrivilege,
// 	}, nil
// }

// package inventory

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type CredentialCountRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialCountRepository(db *repository.PostgresDB) *CredentialCountRepository {
// 	return &CredentialCountRepository{db: db}
// }

// func (r *CredentialCountRepository) GetCounts(
// 	ctx context.Context,
// 	f inventorymodels.CredentialCountFilter,
// ) (*inventorymodels.CredentialCountResponse, error) {

// 	args := []interface{}{}
// 	argIdx := 1

// 	addArg := func(v interface{}) string {
// 		args = append(args, v)
// 		ph := fmt.Sprintf("$%d", argIdx)
// 		argIdx++
// 		return ph
// 	}

// 	where := []string{"deleted_at IS NULL", repository.ScanScopeCondition()}

// 	if strings.TrimSpace(f.AccountID) != "" {
// 		where = append(where, fmt.Sprintf("account_id = %s", addArg(f.AccountID)))
// 	}

// 	if strings.TrimSpace(f.Region) != "" {
// 		where = append(where, fmt.Sprintf("region = %s", addArg(f.Region)))
// 	}

// 	whereClause := "WHERE " + strings.Join(where, " AND ")

// 	summaryQuery := fmt.Sprintf(`
// 		SELECT
// 			COUNT(*)                                                   AS total,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'active')          AS active,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'inactive')        AS inactive,
// 			COUNT(*) FILTER (WHERE LOWER(status) = 'expired')         AS expired,
// 			COUNT(*) FILTER (
// 				WHERE expires_at IS NOT NULL
// 				  AND expires_at > NOW()
// 				  AND expires_at <= NOW() + INTERVAL '30 days'
// 			)                                                          AS expiring_within_30d,
// 			COUNT(*) FILTER (
// 				WHERE last_used_at IS NOT NULL
// 				  AND last_used_at < NOW() - INTERVAL '90 days'
// 			)                                                          AS stale_90d,
// 			COUNT(*) FILTER (
// 				WHERE privilege_level IS NOT NULL
// 				  AND privilege_level >= 7
// 			)                                                          AS high_privilege
// 		FROM %s.credentials
// 		%s
// 	`, repository.Schema, whereClause)

// 	var (
// 		total             int
// 		active            int
// 		inactive          int
// 		expired           int
// 		expiringWithin30d int
// 		stale90d          int
// 		highPrivilege     int
// 	)

// 	if err := r.db.DB.QueryRowContext(ctx, summaryQuery, args...).Scan(
// 		&total, &active, &inactive, &expired, &expiringWithin30d, &stale90d, &highPrivilege,
// 	); err != nil {
// 		return nil, fmt.Errorf("query credential counts: %w", err)
// 	}

// 	byTypeQuery := fmt.Sprintf(`
// 		SELECT credential_type, COUNT(*) AS count
// 		FROM %s.credentials
// 		%s
// 		GROUP BY credential_type
// 		ORDER BY count DESC
// 	`, repository.Schema, whereClause)

// 	rows, err := r.db.DB.QueryContext(ctx, byTypeQuery, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("query credential counts by type: %w", err)
// 	}
// 	defer rows.Close()

// 	byType := make(inventorymodels.CredentialCountByType)

// 	for rows.Next() {
// 		var credType string
// 		var count int
// 		if err := rows.Scan(&credType, &count); err != nil {
// 			return nil, fmt.Errorf("scan credential count row: %w", err)
// 		}
// 		byType[credType] = count
// 	}

// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate credential count rows: %w", err)
// 	}

// 	return &inventorymodels.CredentialCountResponse{
// 		Total:             total,
// 		Active:            active,
// 		Inactive:          inactive,
// 		Expired:           expired,
// 		ByType:            byType,
// 		ExpiringWithin30d: expiringWithin30d,
// 		Stale90d:          stale90d,
// 		HighPrivilege:     highPrivilege,
// 	}, nil
// }

package inventory

import (
	"context"
	"fmt"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// CredentialCountRepository handles DB queries for credential counts.
type CredentialCountRepository struct {
	db *repository.PostgresDB
}

func NewCredentialCountRepository(db *repository.PostgresDB) *CredentialCountRepository {
	return &CredentialCountRepository{db: db}
}

func (r *CredentialCountRepository) GetCounts(
	ctx context.Context,
	f inventorymodels.CredentialCountFilter,
) (*inventorymodels.CredentialCountResponse, error) {

	args := []interface{}{}
	argIdx := 1

	addArg := func(v interface{}) string {
		args = append(args, v)
		ph := fmt.Sprintf("$%d", argIdx)
		argIdx++
		return ph
	}

	// ── WHERE ─────────────────────────────────────────────────────────────
	where := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}

	if strings.TrimSpace(f.AccountID) != "" {
		where = append(where,
			fmt.Sprintf("account_id = %s", addArg(f.AccountID)))
	}

	if strings.TrimSpace(f.Region) != "" {
		where = append(where,
			fmt.Sprintf("region = %s", addArg(f.Region)))
	}

	whereClause := "WHERE " + strings.Join(where, " AND ")

	// ── Summary counts ────────────────────────────────────────────────────
	summaryQuery := fmt.Sprintf(`
		SELECT
			COUNT(*)                                                   AS total,
			COUNT(*) FILTER (WHERE LOWER(status) = 'active')          AS active,
			COUNT(*) FILTER (WHERE LOWER(status) = 'inactive')        AS inactive,
			COUNT(*) FILTER (WHERE LOWER(status) = 'expired')         AS expired,
			COUNT(*) FILTER (
				WHERE expires_at IS NOT NULL
				  AND expires_at > NOW()
				  AND expires_at <= NOW() + INTERVAL '30 days'
			)                                                          AS expiring_within_30d,
			COUNT(*) FILTER (
				WHERE last_used_at IS NOT NULL
				  AND last_used_at < NOW() - INTERVAL '90 days'
			)                                                          AS stale_90d,
			COUNT(*) FILTER (
				WHERE privilege_level IS NOT NULL
				  AND privilege_level >= 7
			)                                                          AS high_privilege
		FROM %s.credentials
		%s
	`, repository.Schema, whereClause)

	var (
		total             int
		active            int
		inactive          int
		expired           int
		expiringWithin30d int
		stale90d          int
		highPrivilege     int
	)

	if err := r.db.DB.QueryRowContext(ctx, summaryQuery, args...).Scan(
		&total,
		&active,
		&inactive,
		&expired,
		&expiringWithin30d,
		&stale90d,
		&highPrivilege,
	); err != nil {
		return nil, fmt.Errorf("query credential counts: %w", err)
	}

	// ── Per-type breakdown ────────────────────────────────────────────────
	byTypeQuery := fmt.Sprintf(`
		SELECT
			credential_type,
			COUNT(*) AS count
		FROM %s.credentials
		%s
		GROUP BY credential_type
		ORDER BY count DESC
	`, repository.Schema, whereClause)

	rows, err := r.db.DB.QueryContext(ctx, byTypeQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("query credential counts by type: %w", err)
	}
	defer rows.Close()

	byType := make(inventorymodels.CredentialCountByType)

	for rows.Next() {
		var credType string
		var count int
		if err := rows.Scan(&credType, &count); err != nil {
			return nil, fmt.Errorf("scan credential count row: %w", err)
		}
		byType[credType] = count
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential count rows: %w", err)
	}

	return &inventorymodels.CredentialCountResponse{
		Total:             total,
		Active:            active,
		Inactive:          inactive,
		Expired:           expired,
		ByType:            byType,
		ExpiringWithin30d: expiringWithin30d,
		Stale90d:          stale90d,
		HighPrivilege:     highPrivilege,
	}, nil
}
