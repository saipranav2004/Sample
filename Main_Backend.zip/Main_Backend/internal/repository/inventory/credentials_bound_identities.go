package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *CredentialAPIRepository) BoundIdentities(ctx context.Context, credentialID string, allowed []string) (*m.CredentialBoundIdentitiesResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("credential binding source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin credential identity snapshot: %w", err)
	}
	defer tx.Rollback()

	out := &m.CredentialBoundIdentitiesResponse{CredentialID: credentialID, Identities: []m.CredentialBoundIdentity{}}
	var credentialName sql.NullString
	var accountID string
	if err := tx.QueryRowContext(ctx, `SELECT name,account_id FROM nhi_scanner.credentials WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE UPPER(BTRIM(status))='COMPLETED' AND scan_end IS NOT NULL ORDER BY scan_end DESC NULLS LAST,id DESC LIMIT 1)`, credentialID, pq.Array(allowed)).Scan(&credentialName, &accountID); err != nil {
		return nil, fmt.Errorf("load authorized credential: %w", err)
	}
	if credentialName.Valid {
		out.CredentialName = &credentialName.String
	}
	scanID, err := latestCompletedCredentialScan(ctx, tx, accountID)
	if err != nil {
		return nil, err
	}
	out.ScanID = scanID
	const query = `SELECT i.id::text,i.name,i.identity_type,i.account_id::text,ic.binding_type,ic.is_primary::text,ic.last_seen_at
FROM nhi_scanner.identity_credentials ic
JOIN nhi_scanner.identities i ON i.id::text=ic.identity_id::text
WHERE ic.credential_id::text=$1::text
  AND LOWER(BTRIM(COALESCE(ic.is_active::text,''))) IN ('1','t','true','yes','y')
  AND ic.scan_id::text=$2::text
  AND i.account_id::text=ANY($3::text[])
ORDER BY i.name NULLS LAST,i.id,ic.binding_type`
	rows, err := tx.QueryContext(ctx, query, credentialID, scanID, pq.Array(allowed))
	if err != nil {
		return nil, fmt.Errorf("query identities bound to credential: %w", err)
	}
	for rows.Next() {
		var item m.CredentialBoundIdentity
		var name, identityType, bindingType sql.NullString
		var isPrimary sql.NullString
		var lastSeen sql.NullTime
		if err := rows.Scan(&item.IdentityID, &name, &identityType, &item.AccountID, &bindingType, &isPrimary, &lastSeen); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan credential identity binding: %w", err)
		}
		if name.Valid {
			item.IdentityName = &name.String
		}
		if identityType.Valid {
			item.IdentityType = &identityType.String
		}
		if bindingType.Valid {
			item.BindingType = &bindingType.String
		}
		if isPrimary.Valid {
			v := strings.ToLower(strings.TrimSpace(isPrimary.String))
			switch v {
			case "1", "t", "true", "yes", "y":
				b := true
				item.IsPrimary = &b
			case "0", "f", "false", "no", "n":
				b := false
				item.IsPrimary = &b
			default:
				rows.Close()
				return nil, fmt.Errorf("invalid identity binding primary flag")
			}
		}
		if lastSeen.Valid {
			v := lastSeen.Time.UTC()
			item.LastSeenAt = &v
		}
		out.Identities = append(out.Identities, item)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate credential identity bindings: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close credential identity rows: %w", err)
	}
	out.TotalIdentities = len(out.Identities)
	switch {
	case out.TotalIdentities >= 10:
		out.BlastRadiusSeverity = "critical"
	case out.TotalIdentities >= 5:
		out.BlastRadiusSeverity = "high"
	case out.TotalIdentities >= 2:
		out.BlastRadiusSeverity = "medium"
	default:
		out.BlastRadiusSeverity = "low"
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit credential identity snapshot: %w", err)
	}
	return out, nil
}
