package inventory

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

type OrphanedCredentialsRepository struct{ db *sql.DB }

func NewOrphanedCredentialsRepository(db *sql.DB) *OrphanedCredentialsRepository {
	return &OrphanedCredentialsRepository{db: db}
}

func (r *OrphanedCredentialsRepository) List(ctx context.Context, allowed []string) (*m.OrphanedCredentialsResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("orphaned credential source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin orphaned credential snapshot: %w", err)
	}
	defer tx.Rollback()
	scanID, err := latestCompletedCredentialScan(ctx, tx, "")
	if err != nil {
		return nil, err
	}
	const q = `SELECT c.id::text,COALESCE(c.name,''),COALESCE(c.credential_type,'unknown'),c.created_at_aws,c.last_used_at,
 CASE WHEN c.last_used_at IS NULL THEN NULL ELSE FLOOR(EXTRACT(EPOCH FROM (NOW()-c.last_used_at))/86400)::int END AS days_unused
FROM nhi_scanner.credentials c
WHERE c.scan_id=$1::text AND c.account_id=ANY($2::text[]) AND c.deleted_at IS NULL
  AND NOT EXISTS (
    SELECT 1 FROM nhi_scanner.identity_credentials ic
    WHERE ic.credential_id::text=c.id::text AND ic.scan_id=$1::text
      AND LOWER(BTRIM(COALESCE(ic.is_active::text,''))) IN ('1','t','true','yes','y')
  )
ORDER BY c.last_used_at ASC NULLS FIRST,c.name ASC,c.id`
	rows, err := tx.QueryContext(ctx, q, scanID, pq.Array(allowed))
	if err != nil {
		return nil, fmt.Errorf("query orphaned credentials: %w", err)
	}
	out := &m.OrphanedCredentialsResponse{ScanID: scanID, Orphaned: []m.OrphanedCredential{}}
	for rows.Next() {
		var item m.OrphanedCredential
		var created, lastUsed sql.NullTime
		var days sql.NullInt64
		if err := rows.Scan(&item.CredentialID, &item.Name, &item.CredentialType, &created, &lastUsed, &days); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan orphaned credential: %w", err)
		}
		if created.Valid {
			t := created.Time.UTC()
			item.CreatedAtAWS = &t
		}
		if lastUsed.Valid {
			t := lastUsed.Time.UTC()
			item.LastUsedAt = &t
		}
		if days.Valid {
			d := int(days.Int64)
			item.DaysUnused = &d
		}
		out.Orphaned = append(out.Orphaned, item)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate orphaned credentials: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close orphaned credentials: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit orphaned credentials snapshot: %w", err)
	}
	out.Total = len(out.Orphaned)
	return out, nil
}
