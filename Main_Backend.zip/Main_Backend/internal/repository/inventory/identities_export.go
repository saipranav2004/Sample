// package inventory

// import (
// 	"context"
// 	"encoding/json"
// 	"fmt"
// 	"strings"

// 	invmodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type ExportIdentitiesRepository struct {
// 	db *repository.PostgresDB
// }

// func NewExportIdentitiesRepository(db *repository.PostgresDB) *ExportIdentitiesRepository {
// 	return &ExportIdentitiesRepository{db: db}
// }

// func (r *ExportIdentitiesRepository) table() string {
// 	return fmt.Sprintf("%s.identities", repository.Schema)
// }

// // ---------- validation helpers (DB driven) ----------

// func (r *ExportIdentitiesRepository) existsIn(ctx context.Context, col, val string) (bool, error) {
// 	q := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s WHERE LOWER(COALESCE(%s::text,'')) = LOWER($1))`, r.table(), col)
// 	var ok bool
// 	if err := r.db.DB.QueryRowContext(ctx, q, val).Scan(&ok); err != nil {
// 		return false, err
// 	}
// 	return ok, nil
// }

// func (r *ExportIdentitiesRepository) listDistinct(ctx context.Context, col string) ([]string, error) {
// 	q := fmt.Sprintf(`SELECT DISTINCT %s::text FROM %s WHERE %s IS NOT NULL AND %s::text <> '' ORDER BY 1`,
// 		col, r.table(), col, col)
// 	rows, err := r.db.DB.QueryContext(ctx, q)
// 	if err != nil {
// 		return nil, err
// 	}
// 	defer rows.Close()

// 	out := make([]string, 0)
// 	for rows.Next() {
// 		var s string
// 		if err := rows.Scan(&s); err != nil {
// 			return nil, err
// 		}
// 		out = append(out, s)
// 	}
// 	return out, rows.Err()
// }

// func (r *ExportIdentitiesRepository) AccountIDExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "account_id", v)
// }
// func (r *ExportIdentitiesRepository) IdentityTypeExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "identity_type", v)
// }
// func (r *ExportIdentitiesRepository) RegionExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "region", v)
// }
// func (r *ExportIdentitiesRepository) StatusExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "status", v)
// }
// func (r *ExportIdentitiesRepository) FunctionalClassExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "functional_class", v)
// }
// func (r *ExportIdentitiesRepository) EnvironmentExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "environment", v)
// }
// func (r *ExportIdentitiesRepository) OwnerExists(ctx context.Context, v string) (bool, error) {
// 	return r.existsIn(ctx, "owner", v)
// }

// func (r *ExportIdentitiesRepository) ListIdentityTypes(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "identity_type")
// }
// func (r *ExportIdentitiesRepository) ListRegions(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "region")
// }
// func (r *ExportIdentitiesRepository) ListStatuses(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "status")
// }
// func (r *ExportIdentitiesRepository) ListFunctionalClasses(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "functional_class")
// }
// func (r *ExportIdentitiesRepository) ListEnvironments(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "environment")
// }

// // ---------- query building ----------

// var identityExportSortColumns = map[string]string{
// 	"name":             "name",
// 	"identity_type":    "identity_type",
// 	"functional_class": "functional_class",
// 	"account_id":       "account_id",
// 	"region":           "region",
// 	"status":           "status",
// 	"created_at_aws":   "created_at_aws",
// 	"first_seen_at":    "first_seen_at",
// 	"last_seen_at":     "last_seen_at",
// 	"last_activity_at": "last_activity_at",
// }

// var identityExportLikeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

// func identityExportBuildWhere(f invmodels.ExportIdentityFilter) (string, []interface{}) {
// 	conds := []string{"deleted_at IS NULL"}
// 	args := make([]interface{}, 0)

// 	add := func(cond string, v interface{}) {
// 		args = append(args, v)
// 		conds = append(conds, strings.ReplaceAll(cond, "?", fmt.Sprintf("$%d", len(args))))
// 	}

// 	if f.Search != "" {
// 		add(`(name ILIKE ? OR arn ILIKE ?)`, "%"+identityExportLikeEscaper.Replace(f.Search)+"%")
// 	}
// 	if f.AccountID != "" {
// 		add(`account_id = ?`, f.AccountID)
// 	}
// 	if f.Region != "" {
// 		add(`LOWER(region) = LOWER(?)`, f.Region)
// 	}
// 	if f.IdentityType != "" {
// 		add(`LOWER(identity_type) = LOWER(?)`, f.IdentityType)
// 	}
// 	if f.Status != "" {
// 		add(`LOWER(COALESCE(status,'')) = LOWER(?)`, f.Status)
// 	}
// 	if f.FunctionalClass != "" {
// 		add(`LOWER(COALESCE(functional_class,'')) = LOWER(?)`, f.FunctionalClass)
// 	}
// 	if f.Environment != "" {
// 		add(`LOWER(COALESCE(environment,'')) = LOWER(?)`, f.Environment)
// 	}
// 	if f.Owner != "" {
// 		add(`LOWER(COALESCE(owner,'')) = LOWER(?)`, f.Owner)
// 	}

// 	return " WHERE " + strings.Join(conds, " AND "), args
// }

// func identityExportJSONOr(b []byte, def string) json.RawMessage {
// 	t := strings.TrimSpace(string(b))
// 	if t == "" || t == "null" {
// 		return json.RawMessage(def)
// 	}
// 	return json.RawMessage(t)
// }

// // ---------- count ----------

// func (r *ExportIdentitiesRepository) Count(ctx context.Context, f invmodels.ExportIdentityFilter) (int, error) {
// 	where, args := identityExportBuildWhere(f)
// 	q := fmt.Sprintf(`SELECT COUNT(*) FROM %s%s`, r.table(), where)

// 	var n int
// 	if err := r.db.DB.QueryRowContext(ctx, q, args...).Scan(&n); err != nil {
// 		return 0, err
// 	}
// 	return n, nil
// }

// // ---------- stream ----------

// func (r *ExportIdentitiesRepository) Stream(
// 	ctx context.Context,
// 	f invmodels.ExportIdentityFilter,
// 	fn func(*invmodels.ExportIdentity) error,
// ) error {
// 	where, args := identityExportBuildWhere(f)

// 	col, ok := identityExportSortColumns[strings.ToLower(f.SortBy)]
// 	if !ok {
// 		col = "name"
// 	}
// 	dir := "ASC"
// 	if strings.EqualFold(f.SortOrder, "desc") {
// 		dir = "DESC"
// 	}

// 	q := fmt.Sprintf(`
// SELECT
//   id::text, COALESCE(arn,''), COALESCE(name,''), COALESCE(identity_type,''), COALESCE(functional_class,''),
//   COALESCE(account_id,''), COALESCE(region,''), COALESCE(status,''),
//   created_at_aws, first_seen_at, last_seen_at, last_activity_at,
//   vpc_id, subnet_id, security_group_ids, is_publicly_accessible,
//   tags, owner, environment, parent_arn, cloudtrail_creator_arn,
//   discovery_source, scan_id, type_attributes, raw_api_response,
//   created_at, updated_at
// FROM %s%s
// ORDER BY %s %s NULLS LAST, id ASC`, r.table(), where, col, dir)

// 	if f.Limit != nil {
// 		page := 1
// 		if f.Page != nil {
// 			page = *f.Page
// 		}
// 		args = append(args, *f.Limit)
// 		q += fmt.Sprintf(" LIMIT $%d", len(args))
// 		args = append(args, (page-1)*(*f.Limit))
// 		q += fmt.Sprintf(" OFFSET $%d", len(args))
// 	}

// 	rows, err := r.db.DB.QueryContext(ctx, q, args...)
// 	if err != nil {
// 		return err
// 	}
// 	defer rows.Close()

// 	for rows.Next() {
// 		var ident invmodels.ExportIdentity
// 		var securityGroupIDs, tags, typeAttrs, rawAPIResp []byte

// 		if err := rows.Scan(
// 			&ident.ID, &ident.ARN, &ident.Name, &ident.IdentityType, &ident.FunctionalClass,
// 			&ident.AccountID, &ident.Region, &ident.Status,
// 			&ident.CreatedAtAWS, &ident.FirstSeenAt, &ident.LastSeenAt, &ident.LastActivityAt,
// 			&ident.Network.VpcID, &ident.Network.SubnetID, &securityGroupIDs, &ident.Network.IsPubliclyAccessible,
// 			&tags, &ident.Owner, &ident.Environment, &ident.ParentARN, &ident.CloudtrailCreatorARN,
// 			&ident.Discovery.DiscoverySource, &ident.Discovery.ScanID, &typeAttrs, &rawAPIResp,
// 			&ident.CreatedAt, &ident.UpdatedAt,
// 		); err != nil {
// 			return err
// 		}

// 		ident.Network.SecurityGroupIDs = identityExportJSONOr(securityGroupIDs, "[]")
// 		ident.Tags = identityExportJSONOr(tags, "{}")
// 		ident.TypeAttributes = identityExportJSONOr(typeAttrs, "{}")
// 		ident.RawAPIResponse = identityExportJSONOr(rawAPIResp, "{}")

// 		if err := fn(&ident); err != nil {
// 			return err
// 		}
// 	}
// 	return rows.Err()
// }

package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	invmodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type ExportIdentitiesRepository struct {
	db *repository.PostgresDB
}

func NewExportIdentitiesRepository(db *repository.PostgresDB) *ExportIdentitiesRepository {
	return &ExportIdentitiesRepository{db: db}
}

func (r *ExportIdentitiesRepository) table() string {
	return fmt.Sprintf("%s.identities", repository.Schema)
}

// ---------- validation helpers (DB driven) ----------

func (r *ExportIdentitiesRepository) existsIn(ctx context.Context, col, val string) (bool, error) {
	q := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s WHERE %s AND LOWER(COALESCE(%s::text,'')) = LOWER($1))`, r.table(), repository.LatestScanFilter, col)
	var ok bool
	if err := r.db.DB.QueryRowContext(ctx, q, val).Scan(&ok); err != nil {
		return false, err
	}
	return ok, nil
}

func (r *ExportIdentitiesRepository) listDistinct(ctx context.Context, col string) ([]string, error) {
	q := fmt.Sprintf(`SELECT DISTINCT %s::text FROM %s WHERE %s AND %s IS NOT NULL AND %s::text <> '' ORDER BY 1`,
		col, r.table(), repository.LatestScanFilter, col, col)
	rows, err := r.db.DB.QueryContext(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]string, 0)
	for rows.Next() {
		var s string
		if err := rows.Scan(&s); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

func (r *ExportIdentitiesRepository) AccountIDExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "account_id", v)
}
func (r *ExportIdentitiesRepository) IdentityTypeExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "identity_type", v)
}
func (r *ExportIdentitiesRepository) RegionExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "region", v)
}
func (r *ExportIdentitiesRepository) StatusExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "status", v)
}
func (r *ExportIdentitiesRepository) FunctionalClassExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "functional_class", v)
}
func (r *ExportIdentitiesRepository) EnvironmentExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "environment", v)
}
func (r *ExportIdentitiesRepository) OwnerExists(ctx context.Context, v string) (bool, error) {
	return r.existsIn(ctx, "owner", v)
}

func (r *ExportIdentitiesRepository) ListIdentityTypes(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "identity_type")
}
func (r *ExportIdentitiesRepository) ListRegions(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "region")
}
func (r *ExportIdentitiesRepository) ListStatuses(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "status")
}
func (r *ExportIdentitiesRepository) ListFunctionalClasses(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "functional_class")
}
func (r *ExportIdentitiesRepository) ListEnvironments(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "environment")
}

// ---------- query building ----------

var identityExportSortColumns = map[string]string{
	"name":             "name",
	"identity_type":    "identity_type",
	"functional_class": "functional_class",
	"account_id":       "account_id",
	"region":           "region",
	"status":           "status",
	"created_at_aws":   "created_at_aws",
	"first_seen_at":    "first_seen_at",
	"last_seen_at":     "last_seen_at",
	"last_activity_at": "last_activity_at",
}

var identityExportLikeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

func identityExportBuildWhere(f invmodels.ExportIdentityFilter) (string, []interface{}) {
	conds := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}
	args := make([]interface{}, 0)

	add := func(cond string, v interface{}) {
		args = append(args, v)
		conds = append(conds, strings.ReplaceAll(cond, "?", fmt.Sprintf("$%d", len(args))))
	}

	if f.Search != "" {
		add(`(name ILIKE ? OR arn ILIKE ?)`, "%"+identityExportLikeEscaper.Replace(f.Search)+"%")
	}
	if f.AccountID != "" {
		add(`account_id = ?`, f.AccountID)
	}
	if f.Region != "" {
		add(`LOWER(region) = LOWER(?)`, f.Region)
	}
	if f.IdentityType != "" {
		add(`LOWER(identity_type) = LOWER(?)`, f.IdentityType)
	}
	if f.Status != "" {
		add(`LOWER(COALESCE(status,'')) = LOWER(?)`, f.Status)
	}
	if f.FunctionalClass != "" {
		add(`LOWER(COALESCE(functional_class,'')) = LOWER(?)`, f.FunctionalClass)
	}
	if f.Environment != "" {
		add(`LOWER(COALESCE(environment,'')) = LOWER(?)`, f.Environment)
	}
	if f.Owner != "" {
		add(`LOWER(COALESCE(owner,'')) = LOWER(?)`, f.Owner)
	}

	return " WHERE " + strings.Join(conds, " AND "), args
}

func identityExportJSONOr(b []byte, def string) json.RawMessage {
	t := strings.TrimSpace(string(b))
	if t == "" || t == "null" {
		return json.RawMessage(def)
	}
	return json.RawMessage(t)
}

// ---------- count ----------

func (r *ExportIdentitiesRepository) Count(ctx context.Context, f invmodels.ExportIdentityFilter) (int, error) {
	where, args := identityExportBuildWhere(f)
	q := fmt.Sprintf(`SELECT COUNT(*) FROM %s%s`, r.table(), where)

	var n int
	if err := r.db.DB.QueryRowContext(ctx, q, args...).Scan(&n); err != nil {
		return 0, err
	}
	return n, nil
}

// ---------- stream ----------

func (r *ExportIdentitiesRepository) Stream(
	ctx context.Context,
	f invmodels.ExportIdentityFilter,
	fn func(*invmodels.ExportIdentity) error,
) error {
	where, args := identityExportBuildWhere(f)

	col, ok := identityExportSortColumns[strings.ToLower(f.SortBy)]
	if !ok {
		col = "name"
	}
	dir := "ASC"
	if strings.EqualFold(f.SortOrder, "desc") {
		dir = "DESC"
	}

	q := fmt.Sprintf(`
SELECT
  id::text, COALESCE(arn,''), COALESCE(name,''), COALESCE(identity_type,''), COALESCE(functional_class,''),
  COALESCE(account_id,''), COALESCE(region,''), COALESCE(status,''),
  created_at_aws, first_seen_at, last_seen_at, last_activity_at,
  vpc_id, subnet_id, security_group_ids, is_publicly_accessible,
  tags, owner, environment, parent_arn, cloudtrail_creator_arn,
  discovery_source, scan_id, type_attributes, raw_api_response,
  created_at, updated_at
FROM %s%s
ORDER BY %s %s NULLS LAST, id ASC`, r.table(), where, col, dir)

	if f.Limit != nil {
		page := 1
		if f.Page != nil {
			page = *f.Page
		}
		args = append(args, *f.Limit)
		q += fmt.Sprintf(" LIMIT $%d", len(args))
		args = append(args, (page-1)*(*f.Limit))
		q += fmt.Sprintf(" OFFSET $%d", len(args))
	}

	rows, err := r.db.DB.QueryContext(ctx, q, args...)
	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var ident invmodels.ExportIdentity
		var securityGroupIDs, tags, typeAttrs, rawAPIResp []byte

		if err := rows.Scan(
			&ident.ID, &ident.ARN, &ident.Name, &ident.IdentityType, &ident.FunctionalClass,
			&ident.AccountID, &ident.Region, &ident.Status,
			&ident.CreatedAtAWS, &ident.FirstSeenAt, &ident.LastSeenAt, &ident.LastActivityAt,
			&ident.Network.VpcID, &ident.Network.SubnetID, &securityGroupIDs, &ident.Network.IsPubliclyAccessible,
			&tags, &ident.Owner, &ident.Environment, &ident.ParentARN, &ident.CloudtrailCreatorARN,
			&ident.Discovery.DiscoverySource, &ident.Discovery.ScanID, &typeAttrs, &rawAPIResp,
			&ident.CreatedAt, &ident.UpdatedAt,
		); err != nil {
			return err
		}

		ident.Network.SecurityGroupIDs = identityExportJSONOr(securityGroupIDs, "[]")
		ident.Tags = identityExportJSONOr(tags, "{}")
		ident.TypeAttributes = identityExportJSONOr(typeAttrs, "{}")
		ident.RawAPIResponse = identityExportJSONOr(rawAPIResp, "{}")

		if err := fn(&ident); err != nil {
			return err
		}
	}
	return rows.Err()
}
