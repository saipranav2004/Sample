// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"strings"
// 	"time"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type DormantIdentitiesFilter struct {
// 	Days         int
// 	IdentityType string
// 	AccountID    string
// 	Page         int
// 	Limit        int
// }

// type IdentityDormantRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentityDormantRepository(db *repository.PostgresDB) *IdentityDormantRepository {
// 	return &IdentityDormantRepository{db: db}
// }

// func (r *IdentityDormantRepository) List(ctx context.Context, f DormantIdentitiesFilter) ([]modelsinventory.DormantIdentity, int, error) {
// 	var (
// 		conditions []string
// 		args       []interface{}
// 		argIdx     = 1
// 	)

// 	conditions = append(conditions, "deleted_at IS NULL")

// 	// Dormant = last_activity_at older than N days, or never active at all
// 	conditions = append(conditions, fmt.Sprintf(
// 		"(last_activity_at IS NULL OR last_activity_at < NOW() - (INTERVAL '1 day' * $%d))", argIdx,
// 	))
// 	args = append(args, f.Days)
// 	argIdx++

// 	if f.IdentityType != "" {
// 		conditions = append(conditions, fmt.Sprintf("identity_type = $%d", argIdx))
// 		args = append(args, f.IdentityType)
// 		argIdx++
// 	}

// 	if f.AccountID != "" {
// 		conditions = append(conditions, fmt.Sprintf("account_id = $%d", argIdx))
// 		args = append(args, f.AccountID)
// 		argIdx++
// 	}

// 	whereClause := strings.Join(conditions, " AND ")

// 	// --- total count (ignores pagination) ---
// 	countQuery := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE %s`, repository.Schema, whereClause)

// 	var total int
// 	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
// 		return nil, 0, fmt.Errorf("count dormant identities: %w", err)
// 	}

// 	// --- pagination ---
// 	limit := f.Limit
// 	if limit <= 0 {
// 		limit = 20
// 	}
// 	page := f.Page
// 	if page <= 0 {
// 		page = 1
// 	}
// 	offset := (page - 1) * limit

// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text, name, identity_type, last_activity_at, owner, environment
// 		FROM %s.identities
// 		WHERE %s
// 		ORDER BY last_activity_at ASC NULLS FIRST
// 		LIMIT $%d OFFSET $%d
// 	`, repository.Schema, whereClause, argIdx, argIdx+1)

// 	queryArgs := append(args, limit, offset)

// 	rows, err := r.db.DB.QueryContext(ctx, query, queryArgs...)
// 	if err != nil {
// 		return nil, 0, fmt.Errorf("list dormant identities: %w", err)
// 	}
// 	defer rows.Close()

// 	result := make([]modelsinventory.DormantIdentity, 0)
// 	now := time.Now()

// 	for rows.Next() {
// 		var (
// 			id, name, identityType string
// 			lastActivityAt         sql.NullTime
// 			owner, environment     sql.NullString
// 		)

// 		if err := rows.Scan(&id, &name, &identityType, &lastActivityAt, &owner, &environment); err != nil {
// 			return nil, 0, fmt.Errorf("scan dormant identity: %w", err)
// 		}

// 		item := modelsinventory.DormantIdentity{
// 			ID:           id,
// 			Name:         name,
// 			IdentityType: identityType,
// 			Owner:        identityNullStr(owner),
// 			Environment:  identityNullStr(environment),
// 		}

// 		if lastActivityAt.Valid {
// 			t := lastActivityAt.Time
// 			item.LastActivityAt = &t
// 			item.DaysInactive = int(now.Sub(t).Hours() / 24)
// 		}

// 		result = append(result, item)
// 	}

// 	if err := rows.Err(); err != nil {
// 		return nil, 0, fmt.Errorf("iterate dormant identities: %w", err)
// 	}

// 	return result, total, nil
// }

package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type DormantIdentitiesFilter struct {
	Days         int
	IdentityType string
	AccountID    string
	Page         int
	Limit        int
}

type IdentityDormantRepository struct {
	db *repository.PostgresDB
}

func NewIdentityDormantRepository(db *repository.PostgresDB) *IdentityDormantRepository {
	return &IdentityDormantRepository{db: db}
}

func (r *IdentityDormantRepository) List(ctx context.Context, f DormantIdentitiesFilter) ([]modelsinventory.DormantIdentity, int, error) {
	var (
		conditions []string
		args       []interface{}
		argIdx     = 1
	)

	conditions = append(conditions, "deleted_at IS NULL AND "+repository.LatestScanFilter)

	// Dormant = last_activity_at older than N days, or never active at all
	conditions = append(conditions, fmt.Sprintf(
		"(last_activity_at IS NULL OR last_activity_at < NOW() - (INTERVAL '1 day' * $%d))", argIdx,
	))
	args = append(args, f.Days)
	argIdx++

	if f.IdentityType != "" {
		conditions = append(conditions, fmt.Sprintf("identity_type = $%d", argIdx))
		args = append(args, f.IdentityType)
		argIdx++
	}

	if f.AccountID != "" {
		conditions = append(conditions, fmt.Sprintf("account_id = $%d", argIdx))
		args = append(args, f.AccountID)
		argIdx++
	}

	whereClause := strings.Join(conditions, " AND ")

	// --- total count (ignores pagination) ---
	countQuery := fmt.Sprintf(`SELECT COUNT(*) FROM %s.identities WHERE %s`, repository.Schema, whereClause)

	var total int
	if err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count dormant identities: %w", err)
	}

	// --- pagination ---
	limit := f.Limit
	if limit <= 0 {
		limit = 20
	}
	page := f.Page
	if page <= 0 {
		page = 1
	}
	offset := (page - 1) * limit

	query := fmt.Sprintf(`
		SELECT
			id::text, name, identity_type, last_activity_at, owner, environment
		FROM %s.identities
		WHERE %s
		ORDER BY last_activity_at ASC NULLS FIRST
		LIMIT $%d OFFSET $%d
	`, repository.Schema, whereClause, argIdx, argIdx+1)

	queryArgs := append(args, limit, offset)

	rows, err := r.db.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("list dormant identities: %w", err)
	}
	defer rows.Close()

	result := make([]modelsinventory.DormantIdentity, 0)
	now := time.Now()

	for rows.Next() {
		var (
			id, name, identityType string
			lastActivityAt         sql.NullTime
			owner, environment     sql.NullString
		)

		if err := rows.Scan(&id, &name, &identityType, &lastActivityAt, &owner, &environment); err != nil {
			return nil, 0, fmt.Errorf("scan dormant identity: %w", err)
		}

		item := modelsinventory.DormantIdentity{
			ID:           id,
			Name:         name,
			IdentityType: identityType,
			Owner:        identityNullStr(owner),
			Environment:  identityNullStr(environment),
		}

		if lastActivityAt.Valid {
			t := lastActivityAt.Time
			item.LastActivityAt = &t
			item.DaysInactive = int(now.Sub(t).Hours() / 24)
		}

		result = append(result, item)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate dormant identities: %w", err)
	}

	return result, total, nil
}
