// package inventory

// import (
// 	"context"
// 	"fmt"
// 	"strings"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// type IdentityGroupedByClassRepository struct {
// 	db *repository.PostgresDB
// }

// func NewIdentityGroupedByClassRepository(db *repository.PostgresDB) *IdentityGroupedByClassRepository {
// 	return &IdentityGroupedByClassRepository{db: db}
// }

// func (r *IdentityGroupedByClassRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	return r.existsIn(ctx, "account_id", accountID)
// }

// func (r *IdentityGroupedByClassRepository) RegionExists(ctx context.Context, region string) (bool, error) {
// 	return r.existsIn(ctx, "region", region)
// }

// func (r *IdentityGroupedByClassRepository) ListRegions(ctx context.Context) ([]string, error) {
// 	return r.listDistinct(ctx, "region")
// }

// func (r *IdentityGroupedByClassRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
// 	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL)`, repository.Schema, column)
// 	var exists bool
// 	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
// 		return false, fmt.Errorf("check %s exists: %w", column, err)
// 	}
// 	return exists, nil
// }

// func (r *IdentityGroupedByClassRepository) listDistinct(ctx context.Context, column string) ([]string, error) {
// 	query := fmt.Sprintf(`SELECT DISTINCT %s FROM %s.identities WHERE %s IS NOT NULL AND deleted_at IS NULL ORDER BY %s`, column, repository.Schema, column, column)
// 	rows, err := r.db.DB.QueryContext(ctx, query)
// 	if err != nil {
// 		return nil, fmt.Errorf("list %s: %w", column, err)
// 	}
// 	defer rows.Close()

// 	values := make([]string, 0)
// 	for rows.Next() {
// 		var v string
// 		if err := rows.Scan(&v); err != nil {
// 			return nil, fmt.Errorf("scan %s: %w", column, err)
// 		}
// 		values = append(values, v)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, err
// 	}
// 	return values, nil
// }

// func (r *IdentityGroupedByClassRepository) GroupedByClass(ctx context.Context, f modelsinventory.GroupedByClassFilter) ([]modelsinventory.IdentityClassGroup, error) {
// 	where := []string{"deleted_at IS NULL"}
// 	args := []interface{}{}
// 	idx := 1

// 	if f.AccountID != "" {
// 		where = append(where, fmt.Sprintf("account_id = $%d", idx))
// 		args = append(args, f.AccountID)
// 		idx++
// 	}
// 	if f.Region != "" {
// 		where = append(where, fmt.Sprintf("region = $%d", idx))
// 		args = append(args, f.Region)
// 		idx++
// 	}

// 	limitIdx := idx
// 	args = append(args, f.LimitPerClass)

// 	query := fmt.Sprintf(`
// 		SELECT functional_class, id, name, identity_type, status, class_count
// 		FROM (
// 			SELECT
// 				COALESCE(functional_class, 'unknown') AS functional_class,
// 				id::text AS id,
// 				COALESCE(name, '') AS name,
// 				COALESCE(identity_type, '') AS identity_type,
// 				COALESCE(status, '') AS status,
// 				COUNT(*) OVER (PARTITION BY COALESCE(functional_class, 'unknown')) AS class_count,
// 				ROW_NUMBER() OVER (PARTITION BY COALESCE(functional_class, 'unknown') ORDER BY id ASC) AS rn
// 			FROM %s.identities
// 			WHERE %s
// 		) t
// 		WHERE rn <= $%d
// 		ORDER BY functional_class ASC, id ASC
// 	`, repository.Schema, strings.Join(where, " AND "), limitIdx)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("group identities by class: %w", err)
// 	}
// 	defer rows.Close()

// 	groupIndex := make(map[string]int)
// 	groups := make([]modelsinventory.IdentityClassGroup, 0)

// 	for rows.Next() {
// 		var functionalClass, id, name, identityType, status string
// 		var classCount int

// 		if err := rows.Scan(&functionalClass, &id, &name, &identityType, &status, &classCount); err != nil {
// 			return nil, fmt.Errorf("scan grouped identity row: %w", err)
// 		}

// 		idxPos, ok := groupIndex[functionalClass]
// 		if !ok {
// 			groups = append(groups, modelsinventory.IdentityClassGroup{
// 				FunctionalClass: functionalClass,
// 				Count:           classCount,
// 				Identities:      make([]modelsinventory.GroupedIdentitySummary, 0),
// 			})
// 			idxPos = len(groups) - 1
// 			groupIndex[functionalClass] = idxPos
// 		}

// 		groups[idxPos].Identities = append(groups[idxPos].Identities, modelsinventory.GroupedIdentitySummary{
// 			ID:           id,
// 			Name:         name,
// 			IdentityType: identityType,
// 			Status:       status,
// 		})
// 	}

// 	if err := rows.Err(); err != nil {
// 		return nil, err
// 	}

// 	return groups, nil
// }

package inventory

import (
	"context"
	"fmt"
	"strings"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

type IdentityGroupedByClassRepository struct {
	db *repository.PostgresDB
}

func NewIdentityGroupedByClassRepository(db *repository.PostgresDB) *IdentityGroupedByClassRepository {
	return &IdentityGroupedByClassRepository{db: db}
}

func (r *IdentityGroupedByClassRepository) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return r.existsIn(ctx, "account_id", accountID)
}

func (r *IdentityGroupedByClassRepository) RegionExists(ctx context.Context, region string) (bool, error) {
	return r.existsIn(ctx, "region", region)
}

func (r *IdentityGroupedByClassRepository) ListRegions(ctx context.Context) ([]string, error) {
	return r.listDistinct(ctx, "region")
}

func (r *IdentityGroupedByClassRepository) existsIn(ctx context.Context, column, value string) (bool, error) {
	query := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s.identities WHERE %s = $1 AND deleted_at IS NULL AND `+repository.LatestScanFilter+`)`, repository.Schema, column)
	var exists bool
	if err := r.db.DB.QueryRowContext(ctx, query, value).Scan(&exists); err != nil {
		return false, fmt.Errorf("check %s exists: %w", column, err)
	}
	return exists, nil
}

func (r *IdentityGroupedByClassRepository) listDistinct(ctx context.Context, column string) ([]string, error) {
	query := fmt.Sprintf(`SELECT DISTINCT %s FROM %s.identities WHERE %s IS NOT NULL AND deleted_at IS NULL AND `+repository.LatestScanFilter+` ORDER BY %s`, column, repository.Schema, column, column)
	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("list %s: %w", column, err)
	}
	defer rows.Close()

	values := make([]string, 0)
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			return nil, fmt.Errorf("scan %s: %w", column, err)
		}
		values = append(values, v)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return values, nil
}

func (r *IdentityGroupedByClassRepository) GroupedByClass(ctx context.Context, f modelsinventory.GroupedByClassFilter) ([]modelsinventory.IdentityClassGroup, error) {
	where := []string{"deleted_at IS NULL AND " + repository.LatestScanFilter}
	args := []interface{}{}
	idx := 1

	if f.AccountID != "" {
		where = append(where, fmt.Sprintf("account_id = $%d", idx))
		args = append(args, f.AccountID)
		idx++
	}
	if f.Region != "" {
		where = append(where, fmt.Sprintf("region = $%d", idx))
		args = append(args, f.Region)
		idx++
	}

	limitIdx := idx
	args = append(args, f.LimitPerClass)

	query := fmt.Sprintf(`
		SELECT functional_class, id, name, identity_type, status, class_count
		FROM (
			SELECT
				COALESCE(functional_class, 'unknown') AS functional_class,
				id::text AS id,
				COALESCE(name, '') AS name,
				COALESCE(identity_type, '') AS identity_type,
				COALESCE(status, '') AS status,
				COUNT(*) OVER (PARTITION BY COALESCE(functional_class, 'unknown')) AS class_count,
				ROW_NUMBER() OVER (PARTITION BY COALESCE(functional_class, 'unknown') ORDER BY id ASC) AS rn
			FROM %s.identities
			WHERE %s
		) t
		WHERE rn <= $%d
		ORDER BY functional_class ASC, id ASC
	`, repository.Schema, strings.Join(where, " AND "), limitIdx)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("group identities by class: %w", err)
	}
	defer rows.Close()

	groupIndex := make(map[string]int)
	groups := make([]modelsinventory.IdentityClassGroup, 0)

	for rows.Next() {
		var functionalClass, id, name, identityType, status string
		var classCount int

		if err := rows.Scan(&functionalClass, &id, &name, &identityType, &status, &classCount); err != nil {
			return nil, fmt.Errorf("scan grouped identity row: %w", err)
		}

		idxPos, ok := groupIndex[functionalClass]
		if !ok {
			groups = append(groups, modelsinventory.IdentityClassGroup{
				FunctionalClass: functionalClass,
				Count:           classCount,
				Identities:      make([]modelsinventory.GroupedIdentitySummary, 0),
			})
			idxPos = len(groups) - 1
			groupIndex[functionalClass] = idxPos
		}

		groups[idxPos].Identities = append(groups[idxPos].Identities, modelsinventory.GroupedIdentitySummary{
			ID:           id,
			Name:         name,
			IdentityType: identityType,
			Status:       status,
		})
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return groups, nil
}
