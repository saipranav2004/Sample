package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *CredentialAPIRepository) CredentialTrustChain(ctx context.Context, id string, allowed []string) (*m.CredentialTrustChainResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("credential trust source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin trust-chain snapshot: %w", err)
	}
	defer tx.Rollback()
	var arn, accountID string
	if err := tx.QueryRowContext(ctx, `SELECT arn,account_id FROM nhi_scanner.credentials WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE UPPER(BTRIM(status))='COMPLETED' AND scan_end IS NOT NULL ORDER BY scan_end DESC NULLS LAST,id DESC LIMIT 1)`, id, pq.Array(allowed)).Scan(&arn, &accountID); err != nil {
		return nil, fmt.Errorf("load authorized credential: %w", err)
	}
	scanID, err := latestCompletedCredentialScan(ctx, tx, accountID)
	if err != nil {
		return nil, err
	}
	out := &m.CredentialTrustChainResponse{CredentialID: id, ScanID: scanID, RoleARN: &arn, CanBeAssumedBy: []m.TrustChainEdge{}, CanAssume: []m.TrustChainEdge{}, CanPassRoleTo: []m.TrustChainEdge{}}
	const q = `SELECT source_arn,target_arn,edge_type,conditions FROM nhi_scanner.trust_edges WHERE is_active IS TRUE AND scan_id=$2::text AND ((target_arn=$1 AND edge_type NOT ILIKE 'pass_role%') OR source_arn=$1) ORDER BY edge_type,source_arn,target_arn`
	rows, err := tx.QueryContext(ctx, q, arn, scanID)
	if err != nil {
		return nil, fmt.Errorf("query credential trust edges: %w", err)
	}
	for rows.Next() {
		var source, target, edgeType sql.NullString
		var conditions sql.NullString
		if err := rows.Scan(&source, &target, &edgeType, &conditions); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan credential trust edge: %w", err)
		}
		e := m.TrustChainEdge{EdgeType: "unknown", Conditions: json.RawMessage("null")}
		if source.Valid {
			e.SourceARN = source.String
		}
		if target.Valid {
			e.TargetARN = target.String
		}
		if edgeType.Valid && strings.TrimSpace(edgeType.String) != "" {
			e.EdgeType = edgeType.String
		}
		if conditions.Valid && strings.TrimSpace(conditions.String) != "" && conditions.String != "null" {
			raw := json.RawMessage(conditions.String)
			if !json.Valid(raw) {
				rows.Close()
				return nil, fmt.Errorf("invalid trust conditions JSON")
			}
			e.Conditions = raw
		}
		if e.TargetARN == arn && !strings.HasPrefix(strings.ToLower(e.EdgeType), "pass_role") {
			out.CanBeAssumedBy = append(out.CanBeAssumedBy, e)
		} else if e.SourceARN == arn && strings.HasPrefix(strings.ToLower(e.EdgeType), "pass_role") {
			out.CanPassRoleTo = append(out.CanPassRoleTo, e)
		} else if e.SourceARN == arn {
			out.CanAssume = append(out.CanAssume, e)
		}
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate credential trust edges: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close credential trust edges: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit trust-chain snapshot: %w", err)
	}
	return out, nil
}
