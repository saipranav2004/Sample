package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *CredentialAPIRepository) EffectivePermissions(ctx context.Context, id string, allowed []string, f m.CredentialPermissionFilter) (*m.CredentialEffectivePermissionsResponse, error) {
	if r == nil || r.db == nil || len(allowed) == 0 {
		return nil, fmt.Errorf("credential permission source unavailable")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin permission snapshot: %w", err)
	}
	defer tx.Rollback()
	var accountID string
	if err := tx.QueryRowContext(ctx, `SELECT account_id FROM nhi_scanner.credentials WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE UPPER(BTRIM(status))='COMPLETED' AND scan_end IS NOT NULL ORDER BY scan_end DESC NULLS LAST,id DESC LIMIT 1)`, id, pq.Array(allowed)).Scan(&accountID); err != nil {
		return nil, fmt.Errorf("load authorized credential: %w", err)
	}
	scanID, err := latestCompletedCredentialScan(ctx, tx, accountID)
	if err != nil {
		return nil, err
	}
	const q = `SELECT action,resource,effect,source,source_name,condition FROM nhi_scanner.effective_permissions WHERE credential_id=$1::uuid AND scan_id=$2::text AND ($3::text='' OR LOWER(BTRIM(effect))=LOWER($3)) AND ($4::text='' OR LOWER(split_part(action,':',1))=LOWER($4)) ORDER BY action,resource,effect,source_name`
	rows, err := tx.QueryContext(ctx, q, id, scanID, f.Effect, f.Service)
	if err != nil {
		return nil, fmt.Errorf("query effective permissions: %w", err)
	}
	out := &m.CredentialEffectivePermissionsResponse{CredentialID: id, ScanID: scanID, Permissions: []m.CredentialPermission{}, ByService: []m.PermissionServiceCount{}, WildcardActions: []string{}}
	serviceCounts := map[string]int64{}
	wild := map[string]bool{}
	for rows.Next() {
		var x m.CredentialPermission
		var resource, effect, source, sourceName, condition sql.NullString
		if err := rows.Scan(&x.Action, &resource, &effect, &source, &sourceName, &condition); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan effective permission: %w", err)
		}
		if resource.Valid {
			x.Resource = &resource.String
		}
		if effect.Valid {
			x.Effect = effect.String
		}
		if source.Valid {
			x.Source = &source.String
		}
		if sourceName.Valid {
			x.SourceName = &sourceName.String
		}
		if condition.Valid && strings.TrimSpace(condition.String) != "" && condition.String != "null" {
			raw := json.RawMessage(condition.String)
			if !json.Valid(raw) {
				rows.Close()
				return nil, fmt.Errorf("invalid permission condition JSON")
			}
			x.Condition = raw
		} else {
			x.Condition = json.RawMessage("null")
		}
		out.TotalPermissions++
		if strings.EqualFold(x.Effect, "allow") {
			out.AllowCount++
		}
		if strings.EqualFold(x.Effect, "deny") {
			out.DenyCount++
		}
		svcName := permissionService(x.Action)
		serviceCounts[svcName]++
		if strings.Contains(x.Action, "*") {
			wild[x.Action] = true
		}
		if strings.EqualFold(x.Effect, "allow") && ((x.SourceName != nil && strings.Contains(strings.ToLower(*x.SourceName), "administratoraccess")) || (x.Action == "*" && x.Resource != nil && *x.Resource == "*")) {
			out.HasAdminAccess = true
		}
		out.Permissions = append(out.Permissions, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate effective permissions: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close permission rows: %w", err)
	}
	for name, count := range serviceCounts {
		out.ByService = append(out.ByService, m.PermissionServiceCount{Service: name, ActionCount: count})
	}
	sort.Slice(out.ByService, func(i, j int) bool { return out.ByService[i].Service < out.ByService[j].Service })
	for action := range wild {
		out.WildcardActions = append(out.WildcardActions, action)
	}
	sort.Strings(out.WildcardActions)
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit permission snapshot: %w", err)
	}
	return out, nil
}

func permissionService(action string) string {
	parts := strings.SplitN(action, ":", 2)
	if len(parts) == 2 && strings.TrimSpace(parts[0]) != "" {
		return strings.ToLower(parts[0])
	}
	return "unknown"
}
