// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"time"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// // CredentialHygieneRepository handles hygiene flag evaluation.
// type CredentialHygieneRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialHygieneRepository(db *repository.PostgresDB) *CredentialHygieneRepository {
// 	return &CredentialHygieneRepository{db: db}
// }

// type rawCredential struct {
// 	ID              string
// 	CredentialType  string
// 	Status          string
// 	LastUsedAt      *time.Time
// 	ExpiresAt       *time.Time
// 	RotationEnabled *bool
// 	LastRotatedAt   *time.Time
// 	PrivilegeLevel  *int
// 	TypeAttributes  map[string]interface{}
// 	TrustPolicy     map[string]interface{}
// 	PermBoundaryARN *string
// 	AttachedPolicies []interface{}
// }

// func (r *CredentialHygieneRepository) GetHygieneFlags(
// 	ctx context.Context,
// 	id string,
// ) (*inventorymodels.CredentialHygieneResponse, error) {

// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text,
// 			COALESCE(credential_type, '')              AS credential_type,
// 			COALESCE(status, '')                       AS status,
// 			last_used_at,
// 			expires_at,
// 			rotation_enabled,
// 			last_rotated_at,
// 			privilege_level,
// 			COALESCE(type_attributes, '{}'::jsonb)    AS type_attributes,
// 			COALESCE(trust_policy, '{}'::jsonb)       AS trust_policy,
// 			permission_boundary_arn,
// 			COALESCE(attached_policies, '[]'::jsonb)  AS attached_policies
// 		FROM %s.credentials
// 		WHERE id = $1::uuid
// 		  AND deleted_at IS NULL
// 		LIMIT 1
// 	`, repository.Schema)

// 	row := r.db.DB.QueryRowContext(ctx, query, id)

// 	var raw rawCredential
// 	var typeAttrsRaw []byte
// 	var trustPolicyRaw []byte
// 	var attachedPoliciesRaw []byte
// 	var permBoundary sql.NullString

// 	err := row.Scan(
// 		&raw.ID,
// 		&raw.CredentialType,
// 		&raw.Status,
// 		&raw.LastUsedAt,
// 		&raw.ExpiresAt,
// 		&raw.RotationEnabled,
// 		&raw.LastRotatedAt,
// 		&raw.PrivilegeLevel,
// 		&typeAttrsRaw,
// 		&trustPolicyRaw,
// 		&permBoundary,
// 		&attachedPoliciesRaw,
// 	)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, fmt.Errorf("credential '%s' not found", id)
// 		}
// 		return nil, fmt.Errorf("query credential hygiene: %w", err)
// 	}

// 	// Parse JSONBs
// 	raw.TypeAttributes = map[string]interface{}{}
// 	_ = json.Unmarshal(typeAttrsRaw, &raw.TypeAttributes)

// 	raw.TrustPolicy = map[string]interface{}{}
// 	_ = json.Unmarshal(trustPolicyRaw, &raw.TrustPolicy)

// 	_ = json.Unmarshal(attachedPoliciesRaw, &raw.AttachedPolicies)

// 	if permBoundary.Valid && permBoundary.String != "" {
// 		raw.PermBoundaryARN = &permBoundary.String
// 	}

// 	flags := evaluateHygieneFlags(raw)
// 	overallHealth := computeOverallHealth(flags)

// 	return &inventorymodels.CredentialHygieneResponse{
// 		CredentialID:   raw.ID,
// 		CredentialType: raw.CredentialType,
// 		Flags:          flags,
// 		OverallHealth:  overallHealth,
// 	}, nil
// }

// func evaluateHygieneFlags(raw rawCredential) []inventorymodels.HygieneFlag {
// 	flags := []inventorymodels.HygieneFlag{}

// 	// 1. Wildcard action in trust policy
// 	if hasWildcardAction(raw.TrustPolicy) {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "wildcard_action",
// 			Severity: "critical",
// 			Detail:   "Allow s3:* on *",
// 		})
// 	}

// 	// 2. No permission boundary (IAM role)
// 	if raw.CredentialType == "iam_role" && raw.PermBoundaryARN == nil {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "no_permission_boundary",
// 			Severity: "medium",
// 		})
// 	}

// 	// 3. Unused 90 days
// 	if raw.LastUsedAt != nil {
// 		if time.Since(*raw.LastUsedAt) > 90*24*time.Hour {
// 			flags = append(flags, inventorymodels.HygieneFlag{
// 				Flag:     "unused_90d",
// 				Severity: "low",
// 			})
// 		}
// 	} else {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "unused_90d",
// 			Severity: "low",
// 			Detail:   "Never used",
// 		})
// 	}

// 	// 4. Expired
// 	if raw.ExpiresAt != nil && time.Now().After(*raw.ExpiresAt) {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "expired",
// 			Severity: "critical",
// 			Detail:   fmt.Sprintf("Expired at %s", raw.ExpiresAt.Format(time.RFC3339)),
// 		})
// 	}

// 	// 5. Rotation disabled
// 	if raw.RotationEnabled != nil && !*raw.RotationEnabled {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "rotation_disabled",
// 			Severity: "medium",
// 		})
// 	}

// 	// 6. Not rotated in 90 days
// 	if raw.LastRotatedAt != nil {
// 		if time.Since(*raw.LastRotatedAt) > 90*24*time.Hour {
// 			flags = append(flags, inventorymodels.HygieneFlag{
// 				Flag:     "not_rotated_90d",
// 				Severity: "medium",
// 				Detail:   fmt.Sprintf("Last rotated: %s", raw.LastRotatedAt.Format(time.RFC3339)),
// 			})
// 		}
// 	}

// 	// 7. High privilege
// 	if raw.PrivilegeLevel != nil && *raw.PrivilegeLevel >= 8 {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "high_privilege",
// 			Severity: "critical",
// 			Detail:   fmt.Sprintf("Privilege level: %d", *raw.PrivilegeLevel),
// 		})
// 	}

// 	// 8. No attached policies
// 	if raw.CredentialType == "iam_role" && len(raw.AttachedPolicies) == 0 {
// 		flags = append(flags, inventorymodels.HygieneFlag{
// 			Flag:     "no_attached_policies",
// 			Severity: "low",
// 		})
// 	}

// 	return flags
// }

// func computeOverallHealth(flags []inventorymodels.HygieneFlag) string {
// 	if len(flags) == 0 {
// 		return "healthy"
// 	}
// 	hasCritical, hasMedium, hasLow := false, false, false
// 	for _, f := range flags {
// 		switch f.Severity {
// 		case "critical":
// 			hasCritical = true
// 		case "medium":
// 			hasMedium = true
// 		case "low":
// 			hasLow = true
// 		}
// 	}
// 	switch {
// 	case hasCritical:
// 		return "critical"
// 	case hasMedium:
// 		return "medium"
// 	case hasLow:
// 		return "low"
// 	default:
// 		return "healthy"
// 	}
// }

package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// CredentialHygieneRepository handles hygiene flag evaluation.
type CredentialHygieneRepository struct {
	db *repository.PostgresDB
}

func NewCredentialHygieneRepository(db *repository.PostgresDB) *CredentialHygieneRepository {
	return &CredentialHygieneRepository{db: db}
}

type rawCredential struct {
	ID               string
	CredentialType   string
	Status           string
	LastUsedAt       *time.Time
	ExpiresAt        *time.Time
	RotationEnabled  *bool
	LastRotatedAt    *time.Time
	PrivilegeLevel   *int
	TypeAttributes   map[string]interface{}
	TrustPolicy      map[string]interface{}
	PermBoundaryARN  *string
	AttachedPolicies []interface{}
}

func (r *CredentialHygieneRepository) GetHygieneFlags(
	ctx context.Context,
	id string,
) (*inventorymodels.CredentialHygieneResponse, error) {

	query := fmt.Sprintf(`
		SELECT
			id::text,
			COALESCE(credential_type, '')              AS credential_type,
			COALESCE(status, '')                       AS status,
			last_used_at,
			expires_at,
			rotation_enabled,
			last_rotated_at,
			privilege_level,
			COALESCE(type_attributes, '{}'::jsonb)    AS type_attributes,
			COALESCE(trust_policy, '{}'::jsonb)       AS trust_policy,
			permission_boundary_arn,
			COALESCE(attached_policies, '[]'::jsonb)  AS attached_policies
		FROM %s.credentials
		WHERE id = $1::uuid
		  AND deleted_at IS NULL AND `+repository.LatestScanFilter+`
		LIMIT 1
	`, repository.Schema)

	row := r.db.DB.QueryRowContext(ctx, query, id)

	var raw rawCredential
	var typeAttrsRaw []byte
	var trustPolicyRaw []byte
	var attachedPoliciesRaw []byte
	var permBoundary sql.NullString

	err := row.Scan(
		&raw.ID,
		&raw.CredentialType,
		&raw.Status,
		&raw.LastUsedAt,
		&raw.ExpiresAt,
		&raw.RotationEnabled,
		&raw.LastRotatedAt,
		&raw.PrivilegeLevel,
		&typeAttrsRaw,
		&trustPolicyRaw,
		&permBoundary,
		&attachedPoliciesRaw,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("credential '%s' not found", id)
		}
		return nil, fmt.Errorf("query credential hygiene: %w", err)
	}

	// Parse JSONBs
	raw.TypeAttributes = map[string]interface{}{}
	_ = json.Unmarshal(typeAttrsRaw, &raw.TypeAttributes)

	raw.TrustPolicy = map[string]interface{}{}
	_ = json.Unmarshal(trustPolicyRaw, &raw.TrustPolicy)

	_ = json.Unmarshal(attachedPoliciesRaw, &raw.AttachedPolicies)

	if permBoundary.Valid && permBoundary.String != "" {
		raw.PermBoundaryARN = &permBoundary.String
	}

	flags := evaluateHygieneFlags(raw)
	overallHealth := computeOverallHealth(flags)

	return &inventorymodels.CredentialHygieneResponse{
		CredentialID:   raw.ID,
		CredentialType: raw.CredentialType,
		Flags:          flags,
		OverallHealth:  overallHealth,
	}, nil
}

func evaluateHygieneFlags(raw rawCredential) []inventorymodels.HygieneFlag {
	flags := []inventorymodels.HygieneFlag{}

	// 1. Wildcard action in trust policy
	if hasWildcardAction(raw.TrustPolicy) {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "wildcard_action",
			Severity: "critical",
			Detail:   "Allow s3:* on *",
		})
	}

	// 2. No permission boundary (IAM role)
	if raw.CredentialType == "iam_role" && raw.PermBoundaryARN == nil {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "no_permission_boundary",
			Severity: "medium",
		})
	}

	// 3. Unused 90 days
	if raw.LastUsedAt != nil {
		if time.Since(*raw.LastUsedAt) > 90*24*time.Hour {
			flags = append(flags, inventorymodels.HygieneFlag{
				Flag:     "unused_90d",
				Severity: "low",
			})
		}
	} else {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "unused_90d",
			Severity: "low",
			Detail:   "Never used",
		})
	}

	// 4. Expired
	if raw.ExpiresAt != nil && time.Now().After(*raw.ExpiresAt) {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "expired",
			Severity: "critical",
			Detail:   fmt.Sprintf("Expired at %s", raw.ExpiresAt.Format(time.RFC3339)),
		})
	}

	// 5. Rotation disabled
	if raw.RotationEnabled != nil && !*raw.RotationEnabled {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "rotation_disabled",
			Severity: "medium",
		})
	}

	// 6. Not rotated in 90 days
	if raw.LastRotatedAt != nil {
		if time.Since(*raw.LastRotatedAt) > 90*24*time.Hour {
			flags = append(flags, inventorymodels.HygieneFlag{
				Flag:     "not_rotated_90d",
				Severity: "medium",
				Detail:   fmt.Sprintf("Last rotated: %s", raw.LastRotatedAt.Format(time.RFC3339)),
			})
		}
	}

	// 7. High privilege
	if raw.PrivilegeLevel != nil && *raw.PrivilegeLevel >= 8 {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "high_privilege",
			Severity: "critical",
			Detail:   fmt.Sprintf("Privilege level: %d", *raw.PrivilegeLevel),
		})
	}

	// 8. No attached policies
	if raw.CredentialType == "iam_role" && len(raw.AttachedPolicies) == 0 {
		flags = append(flags, inventorymodels.HygieneFlag{
			Flag:     "no_attached_policies",
			Severity: "low",
		})
	}

	return flags
}

func computeOverallHealth(flags []inventorymodels.HygieneFlag) string {
	if len(flags) == 0 {
		return "healthy"
	}
	hasCritical, hasMedium, hasLow := false, false, false
	for _, f := range flags {
		switch f.Severity {
		case "critical":
			hasCritical = true
		case "medium":
			hasMedium = true
		case "low":
			hasLow = true
		}
	}
	switch {
	case hasCritical:
		return "critical"
	case hasMedium:
		return "medium"
	case hasLow:
		return "low"
	default:
		return "healthy"
	}
}
