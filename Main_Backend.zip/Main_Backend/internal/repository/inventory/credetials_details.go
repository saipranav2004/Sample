// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"errors"
// 	"fmt"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// // ErrCredentialNotFound is returned when no credential matches the given id.
// var ErrCredentialNotFound = errors.New("credential not found")

// // CredentialDetailsRepository handles DB queries for a single credential's details.
// type CredentialDetailsRepository struct {
// 	db *repository.PostgresDB
// }

// func NewCredentialDetailsRepository(db *repository.PostgresDB) *CredentialDetailsRepository {
// 	return &CredentialDetailsRepository{db: db}
// }

// // GetByID fetches a single credential by UUID from nhi_scanner.credentials.
// func (r *CredentialDetailsRepository) GetByID(
// 	ctx context.Context,
// 	id string,
// ) (*inventorymodels.CredentialDetail, error) {

// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text,
// 			COALESCE(arn, '')                        AS arn,
// 			COALESCE(name, '')                       AS name,
// 			COALESCE(credential_type, '')          AS credential_type,
// 			COALESCE(account_id, '')               AS account_id,
// 			COALESCE(region, '')                   AS region,
// 			COALESCE(status, '')                   AS status,
// 			created_at_aws,
// 			first_seen_at,
// 			last_seen_at,
// 			last_used_at,
// 			last_rotated_at,
// 			expires_at,
// 			rotation_enabled,
// 			rotation_interval_days,
// 			COALESCE(tags, '{}'::jsonb)             AS tags,
// 			owner_principal_arn,
// 			COALESCE(trust_policy, '{}'::jsonb)         AS trust_policy,
// 			COALESCE(attached_policies, '[]'::jsonb)    AS attached_policies,
// 			COALESCE(inline_policies, '[]'::jsonb)      AS inline_policies,
// 			permission_boundary_arn,
// 			COALESCE(max_session_duration, 3600)        AS max_session_duration,
// 			COALESCE(privilege_level, 0)               AS privilege_level,
// 			COALESCE(assumable_role_arns, '[]'::jsonb)  AS assumable_role_arns,
// 			COALESCE(type_attributes, '{}'::jsonb)      AS type_attributes,
// 			COALESCE(discovery_source, '')              AS discovery_source,
// 			COALESCE(scan_id, '')                       AS scan_id
// 		FROM %s.credentials
// 		WHERE id = $1::uuid
// 		  AND deleted_at IS NULL
// 		LIMIT 1
// 	`, repository.Schema)

// 	row := r.db.DB.QueryRowContext(ctx, query, id)

// 	var c inventorymodels.CredentialDetail
// 	var tagsRaw []byte
// 	var ownerArn sql.NullString
// 	var trustPolicyRaw []byte
// 	var attachedPoliciesRaw []byte
// 	var inlinePoliciesRaw []byte
// 	var permBoundaryArn sql.NullString
// 	var maxSessionDuration int
// 	var privilegeLevel int
// 	var assumableRoleArnsRaw []byte
// 	var typeAttrsRaw []byte
// 	var discoverySource string
// 	var scanID string

// 	err := row.Scan(
// 		&c.ID,
// 		&c.ARN,
// 		&c.Name,
// 		&c.CredentialType,
// 		&c.AccountID,
// 		&c.Region,
// 		&c.Status,
// 		&c.CreatedAtAWS,
// 		&c.FirstSeenAt,
// 		&c.LastSeenAt,
// 		&c.LastUsedAt,
// 		&c.LastRotatedAt,
// 		&c.ExpiresAt,
// 		&c.RotationEnabled,
// 		&c.RotationIntervalDays,
// 		&tagsRaw,
// 		&ownerArn,
// 		&trustPolicyRaw,
// 		&attachedPoliciesRaw,
// 		&inlinePoliciesRaw,
// 		&permBoundaryArn,
// 		&maxSessionDuration,
// 		&privilegeLevel,
// 		&assumableRoleArnsRaw,
// 		&typeAttrsRaw,
// 		&discoverySource,
// 		&scanID,
// 	)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			// Sentinel error — handler checks this with errors.Is, never
// 			// string-matches error text (fragile/wrong, was the root cause
// 			// of the 500-instead-of-404 bug).
// 			return nil, ErrCredentialNotFound
// 		}
// 		return nil, fmt.Errorf("get credential by id: %w", err)
// 	}

// 	// Owner Principal ARN
// 	if ownerArn.Valid && ownerArn.String != "" {
// 		c.OwnerPrincipalARN = &ownerArn.String
// 	}

// 	// Parse tags
// 	c.Tags = make(map[string]interface{})
// 	if len(tagsRaw) > 0 {
// 		_ = json.Unmarshal(tagsRaw, &c.Tags)
// 	}

// 	// Parse type_attributes
// 	c.TypeAttributes = make(map[string]interface{})
// 	if len(typeAttrsRaw) > 0 {
// 		_ = json.Unmarshal(typeAttrsRaw, &c.TypeAttributes)
// 	}

// 	// Discovery metadata
// 	c.Discovery = inventorymodels.CredentialDiscovery{
// 		DiscoverySource: discoverySource,
// 		ScanID:          scanID,
// 	}

// 	// Always populate IAMRoleDetails (never nil)
// 	iamDetails := inventorymodels.IAMRoleDetails{
// 		MaxSessionDuration: maxSessionDuration,
// 		PrivilegeLevel:     privilegeLevel,
// 	}

// 	if permBoundaryArn.Valid && permBoundaryArn.String != "" {
// 		iamDetails.PermissionBoundaryARN = &permBoundaryArn.String
// 	}

// 	// Parse trust_policy
// 	iamDetails.TrustPolicy = make(map[string]interface{})
// 	if len(trustPolicyRaw) > 0 {
// 		_ = json.Unmarshal(trustPolicyRaw, &iamDetails.TrustPolicy)
// 	}

// 	// Parse attached_policies
// 	iamDetails.AttachedPolicies = make([]inventorymodels.IAMRolePolicy, 0)
// 	if len(attachedPoliciesRaw) > 0 {
// 		_ = json.Unmarshal(attachedPoliciesRaw, &iamDetails.AttachedPolicies)
// 	}

// 	// Parse inline_policies
// 	iamDetails.InlinePolicies = make([]string, 0)
// 	if len(inlinePoliciesRaw) > 0 {
// 		_ = json.Unmarshal(inlinePoliciesRaw, &iamDetails.InlinePolicies)
// 	}

// 	// Parse assumable_role_arns
// 	iamDetails.AssumableRoleARNs = make([]string, 0)
// 	if len(assumableRoleArnsRaw) > 0 {
// 		_ = json.Unmarshal(assumableRoleArnsRaw, &iamDetails.AssumableRoleARNs)
// 	}

// 	c.IAMRoleDetails = &iamDetails

// 	return &c, nil
// }

package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// ErrCredentialNotFound is returned when no credential matches the given id.
var ErrCredentialNotFound = errors.New("credential not found")

// CredentialDetailsRepository handles DB queries for a single credential's details.
type CredentialDetailsRepository struct {
	db *repository.PostgresDB
}

func NewCredentialDetailsRepository(db *repository.PostgresDB) *CredentialDetailsRepository {
	return &CredentialDetailsRepository{db: db}
}

// GetByID fetches a single credential by UUID from nhi_scanner.credentials.
func (r *CredentialDetailsRepository) GetByID(
	ctx context.Context,
	id string,
) (*inventorymodels.CredentialDetail, error) {

	query := fmt.Sprintf(`
		SELECT
			id::text,
			COALESCE(arn, '')                        AS arn,
			COALESCE(name, '')                       AS name,
			COALESCE(credential_type, '')          AS credential_type,
			COALESCE(account_id, '')               AS account_id,
			COALESCE(region, '')                   AS region,
			COALESCE(status, '')                   AS status,
			created_at_aws,
			first_seen_at,
			last_seen_at,
			last_used_at,
			last_rotated_at,
			expires_at,
			rotation_enabled,
			rotation_interval_days,
			COALESCE(tags, '{}'::jsonb)             AS tags,
			owner_principal_arn,
			COALESCE(trust_policy, '{}'::jsonb)         AS trust_policy,
			COALESCE(attached_policies, '[]'::jsonb)    AS attached_policies,
			COALESCE(inline_policies, '[]'::jsonb)      AS inline_policies,
			permission_boundary_arn,
			COALESCE(max_session_duration, 3600)        AS max_session_duration,
			COALESCE(privilege_level, 0)               AS privilege_level,
			COALESCE(assumable_role_arns, '[]'::jsonb)  AS assumable_role_arns,
			COALESCE(type_attributes, '{}'::jsonb)      AS type_attributes,
			COALESCE(discovery_source, '')              AS discovery_source,
			COALESCE(scan_id, '')                       AS scan_id
		FROM %s.credentials
		WHERE id = $1::uuid
		  AND deleted_at IS NULL AND `+repository.LatestScanFilter+`
		LIMIT 1
	`, repository.Schema)

	row := r.db.DB.QueryRowContext(ctx, query, id)

	var c inventorymodels.CredentialDetail
	var tagsRaw []byte
	var ownerArn sql.NullString
	var trustPolicyRaw []byte
	var attachedPoliciesRaw []byte
	var inlinePoliciesRaw []byte
	var permBoundaryArn sql.NullString
	var maxSessionDuration int
	var privilegeLevel int
	var assumableRoleArnsRaw []byte
	var typeAttrsRaw []byte
	var discoverySource string
	var scanID string

	err := row.Scan(
		&c.ID,
		&c.ARN,
		&c.Name,
		&c.CredentialType,
		&c.AccountID,
		&c.Region,
		&c.Status,
		&c.CreatedAtAWS,
		&c.FirstSeenAt,
		&c.LastSeenAt,
		&c.LastUsedAt,
		&c.LastRotatedAt,
		&c.ExpiresAt,
		&c.RotationEnabled,
		&c.RotationIntervalDays,
		&tagsRaw,
		&ownerArn,
		&trustPolicyRaw,
		&attachedPoliciesRaw,
		&inlinePoliciesRaw,
		&permBoundaryArn,
		&maxSessionDuration,
		&privilegeLevel,
		&assumableRoleArnsRaw,
		&typeAttrsRaw,
		&discoverySource,
		&scanID,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			// Sentinel error — handler checks this with errors.Is, never
			// string-matches error text (fragile/wrong, was the root cause
			// of the 500-instead-of-404 bug).
			return nil, ErrCredentialNotFound
		}
		return nil, fmt.Errorf("get credential by id: %w", err)
	}

	// Owner Principal ARN
	if ownerArn.Valid && ownerArn.String != "" {
		c.OwnerPrincipalARN = &ownerArn.String
	}

	// Parse tags
	c.Tags = make(map[string]interface{})
	if len(tagsRaw) > 0 {
		_ = json.Unmarshal(tagsRaw, &c.Tags)
	}

	// Parse type_attributes
	c.TypeAttributes = make(map[string]interface{})
	if len(typeAttrsRaw) > 0 {
		_ = json.Unmarshal(typeAttrsRaw, &c.TypeAttributes)
	}

	// Discovery metadata
	c.Discovery = inventorymodels.CredentialDiscovery{
		DiscoverySource: discoverySource,
		ScanID:          scanID,
	}

	// Always populate IAMRoleDetails (never nil)
	iamDetails := inventorymodels.IAMRoleDetails{
		MaxSessionDuration: maxSessionDuration,
		PrivilegeLevel:     privilegeLevel,
	}

	if permBoundaryArn.Valid && permBoundaryArn.String != "" {
		iamDetails.PermissionBoundaryARN = &permBoundaryArn.String
	}

	// Parse trust_policy
	iamDetails.TrustPolicy = make(map[string]interface{})
	if len(trustPolicyRaw) > 0 {
		_ = json.Unmarshal(trustPolicyRaw, &iamDetails.TrustPolicy)
	}

	// Parse attached_policies
	iamDetails.AttachedPolicies = make([]inventorymodels.IAMRolePolicy, 0)
	if len(attachedPoliciesRaw) > 0 {
		_ = json.Unmarshal(attachedPoliciesRaw, &iamDetails.AttachedPolicies)
	}

	// Parse inline_policies
	iamDetails.InlinePolicies = make([]string, 0)
	if len(inlinePoliciesRaw) > 0 {
		_ = json.Unmarshal(inlinePoliciesRaw, &iamDetails.InlinePolicies)
	}

	// Parse assumable_role_arns
	iamDetails.AssumableRoleARNs = make([]string, 0)
	if len(assumableRoleArnsRaw) > 0 {
		_ = json.Unmarshal(assumableRoleArnsRaw, &iamDetails.AssumableRoleARNs)
	}

	c.IAMRoleDetails = &iamDetails

	return &c, nil
}
