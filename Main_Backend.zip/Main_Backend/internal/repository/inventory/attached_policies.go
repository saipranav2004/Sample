// package inventory

// import (
// 	"context"
// 	"database/sql"
// 	// "encoding/json"
// 	"errors"
// 	"fmt"
// 	"strings"

// 	inventorymodels "nhi-backend-api/internal/models/inventory"
// 	"nhi-backend-api/internal/repository"
// )

// // AttachedPoliciesRepository handles policies queries.
// type AttachedPoliciesRepository struct {
// 	db *repository.PostgresDB
// }

// func NewAttachedPoliciesRepository(db *repository.PostgresDB) *AttachedPoliciesRepository {
// 	return &AttachedPoliciesRepository{db: db}
// }

// func (r *AttachedPoliciesRepository) GetPolicies(
// 	ctx context.Context,
// 	id string,
// ) (*inventorymodels.AttachedPoliciesResponse, error) {

// 	query := fmt.Sprintf(`
// 		SELECT
// 			id::text,
// 			COALESCE(attached_policies, '[]'::jsonb)   AS attached_policies,
// 			COALESCE(inline_policies,   '[]'::jsonb)   AS inline_policies,
// 			permission_boundary_arn
// 		FROM %s.credentials
// 		WHERE id = $1::uuid
// 		  AND deleted_at IS NULL
// 		LIMIT 1
// 	`, repository.Schema)

// 	var (
// 		credID              string
// 		attachedRaw         []byte
// 		inlineRaw           []byte
// 		permBoundary        sql.NullString
// 	)

// 	if err := r.db.DB.QueryRowContext(ctx, query, id).Scan(
// 		&credID,
// 		&attachedRaw,
// 		&inlineRaw,
// 		&permBoundary,
// 	); err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, fmt.Errorf("credential '%s' not found", id)
// 		}
// 		return nil, fmt.Errorf("query attached policies: %w", err)
// 	}

// 	managedPolicies := parseManagedPolicies(attachedRaw)
// 	inlinePolicies := parseInlinePolicies(inlineRaw)

// 	var permBoundaryPtr *string
// 	if permBoundary.Valid && strings.TrimSpace(permBoundary.String) != "" {
// 		s := permBoundary.String
// 		permBoundaryPtr = &s
// 	}

// 	return &inventorymodels.AttachedPoliciesResponse{
// 		CredentialID:       credID,
// 		ManagedPolicies:    managedPolicies,
// 		InlinePolicies:     inlinePolicies,
// 		PermissionBoundary: permBoundaryPtr,
// 	}, nil
// }

package inventory

import (
	"context"
	"database/sql"
	// "encoding/json"
	"errors"
	"fmt"
	"strings"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

// AttachedPoliciesRepository handles policies queries.
type AttachedPoliciesRepository struct {
	db *repository.PostgresDB
}

func NewAttachedPoliciesRepository(db *repository.PostgresDB) *AttachedPoliciesRepository {
	return &AttachedPoliciesRepository{db: db}
}

func (r *AttachedPoliciesRepository) GetPolicies(
	ctx context.Context,
	id string,
) (*inventorymodels.AttachedPoliciesResponse, error) {

	query := fmt.Sprintf(`
		SELECT
			id::text,
			COALESCE(attached_policies, '[]'::jsonb)   AS attached_policies,
			COALESCE(inline_policies,   '[]'::jsonb)   AS inline_policies,
			permission_boundary_arn
		FROM %s.credentials
		WHERE id = $1::uuid
		  AND deleted_at IS NULL AND `+repository.LatestScanFilter+`
		LIMIT 1
	`, repository.Schema)

	var (
		credID       string
		attachedRaw  []byte
		inlineRaw    []byte
		permBoundary sql.NullString
	)

	if err := r.db.DB.QueryRowContext(ctx, query, id).Scan(
		&credID,
		&attachedRaw,
		&inlineRaw,
		&permBoundary,
	); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("credential '%s' not found", id)
		}
		return nil, fmt.Errorf("query attached policies: %w", err)
	}

	managedPolicies := parseManagedPolicies(attachedRaw)
	inlinePolicies := parseInlinePolicies(inlineRaw)

	var permBoundaryPtr *string
	if permBoundary.Valid && strings.TrimSpace(permBoundary.String) != "" {
		s := permBoundary.String
		permBoundaryPtr = &s
	}

	return &inventorymodels.AttachedPoliciesResponse{
		CredentialID:       credID,
		ManagedPolicies:    managedPolicies,
		InlinePolicies:     inlinePolicies,
		PermissionBoundary: permBoundaryPtr,
	}, nil
}
