package credentialexposure

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
)

var (
	ErrFindingNotFound  = errors.New("finding not found")
	ErrFindingAmbiguous = errors.New("finding id exists in both platform tables")
)

type FindingsRepository struct{ db *sql.DB }

func NewFindingsRepository(db *sql.DB) *FindingsRepository { return &FindingsRepository{db: db} }

const findingColumns = `finding_id, client_id, repository, branch, commit_id, author, created_at,
 detector, severity, file_path, line_number, redacted, verification_status, risk_tier,
 recommended_action, codecommit_uri, platform, github_uri, line_preview, confidence,
 category, committer, commit_message, commit_authored_at, files_changed, additions,
 deletions, repo_visibility, repo_stars, repo_forks, repo_pushed_at, ml_score,
 ml_decision, ml_model_version, analyst_decision, analyst_decided_at, analyst_decided_by`

func findingsUnion() string {
	return `SELECT ` + findingColumns + ` FROM (
 SELECT finding_id,client_id,repository,branch,commit_id,author,created_at,detector,severity,file_path,line_number,redacted,verification_status,risk_tier,recommended_action,codecommit_uri,COALESCE(NULLIF(platform,''),'codecommit') AS platform,github_uri,line_preview,confidence,category,committer,commit_message,commit_authored_at,files_changed,additions,deletions,repo_visibility,repo_stars,repo_forks,repo_pushed_at,ml_score,ml_decision,ml_model_version,analyst_decision,analyst_decided_at,analyst_decided_by
 FROM nhi_scanner.secscan_findings_codecommit f
 WHERE NOT EXISTS (SELECT 1 FROM nhi_scanner.secscan_allowlist_dashboard a WHERE a.client_id=f.client_id AND a.file_path=f.file_path AND a.detector=f.detector AND a.redacted=f.redacted)
 UNION ALL
 SELECT finding_id,client_id,repository,branch,commit_id,author,created_at,detector,severity,file_path,line_number,redacted,verification_status,risk_tier,recommended_action,codecommit_uri,COALESCE(NULLIF(platform,''),'github') AS platform,github_uri,line_preview,confidence,category,committer,commit_message,commit_authored_at,files_changed,additions,deletions,repo_visibility,repo_stars,repo_forks,repo_pushed_at,ml_score,ml_decision,ml_model_version,analyst_decision,analyst_decided_at,analyst_decided_by
 FROM nhi_scanner.secscan_findings_github f
 WHERE NOT EXISTS (SELECT 1 FROM nhi_scanner.secscan_allowlist_dashboard a WHERE a.client_id=f.client_id AND a.file_path=f.file_path AND a.detector=f.detector AND a.redacted=f.redacted)
) AS findings`
}

func (r *FindingsRepository) List(ctx context.Context, filter m.FindingsFilter) ([]m.Finding, int, error) {
	if r == nil || r.db == nil {
		return nil, 0, fmt.Errorf("findings repository unavailable")
	}
	where := make([]string, 0, 3)
	args := make([]any, 0, 4)
	if filter.ClientID != "" {
		args = append(args, filter.ClientID)
		where = append(where, fmt.Sprintf("client_id=$%d", len(args)))
	}
	if filter.Platform != "" {
		args = append(args, filter.Platform)
		where = append(where, fmt.Sprintf("LOWER(platform)=LOWER($%d)", len(args)))
	}
	if filter.MLFlagged {
		where = append(where, "ml_decision='FALSE_POSITIVE'")
	} else {
		where = append(where, "ml_decision IS DISTINCT FROM 'FALSE_POSITIVE'")
	}
	clause := ""
	if len(where) > 0 {
		clause = " WHERE " + strings.Join(where, " AND ")
	}
	base := findingsUnion()
	var total int
	if err := r.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM ("+base+") f"+clause, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count credential exposure findings: %w", err)
	}
	listArgs := append([]any(nil), args...)
	listArgs = append(listArgs, filter.Limit, filter.Offset)
	query := "SELECT " + findingColumns + " FROM (" + base + ") f" + clause +
		fmt.Sprintf(" ORDER BY created_at DESC, finding_id ASC LIMIT $%d OFFSET $%d", len(listArgs)-1, len(listArgs))
	rows, err := r.db.QueryContext(ctx, query, listArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("query credential exposure findings: %w", err)
	}
	defer rows.Close()
	items := make([]m.Finding, 0)
	for rows.Next() {
		item, err := scanFinding(rows)
		if err != nil {
			return nil, 0, fmt.Errorf("scan credential exposure finding: %w", err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate credential exposure findings: %w", err)
	}
	return items, total, nil
}

func (r *FindingsRepository) GetByID(ctx context.Context, id string) (*m.Finding, error) {
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("findings repository unavailable")
	}
	rows, err := r.db.QueryContext(ctx, "SELECT "+findingColumns+" FROM ("+findingsUnion()+") f WHERE finding_id=$1 LIMIT 2", id)
	if err != nil {
		return nil, fmt.Errorf("query finding: %w", err)
	}
	defer rows.Close()
	if !rows.Next() {
		if err := rows.Err(); err != nil {
			return nil, fmt.Errorf("iterate finding: %w", err)
		}
		return nil, ErrFindingNotFound
	}
	item, err := scanFinding(rows)
	if err != nil {
		return nil, fmt.Errorf("scan finding: %w", err)
	}
	if rows.Next() {
		return nil, ErrFindingAmbiguous
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate finding: %w", err)
	}
	return &item, nil
}

func scanFinding(row interface{ Scan(...any) error }) (m.Finding, error) {
	var f m.Finding
	var codeURI, githubURI, preview, confidence, category, committer, message, authoredAt sql.NullString
	var visibility, pushedAt, mlDecision, mlVersion, analystDecision, analystAt, analystBy sql.NullString
	var filesChanged, additions, deletions, stars, forks sql.NullInt64
	var mlScore sql.NullFloat64
	err := row.Scan(
		&f.FindingID, &f.ClientID, &f.Repository, &f.Branch, &f.CommitID, &f.Author, &f.CreatedAt,
		&f.Detector, &f.Severity, &f.FilePath, &f.LineNumber, &f.Redacted, &f.VerificationStatus,
		&f.RiskTier, &f.RecommendedAction, &codeURI, &f.Platform, &githubURI, &preview, &confidence,
		&category, &committer, &message, &authoredAt, &filesChanged, &additions, &deletions,
		&visibility, &stars, &forks, &pushedAt, &mlScore, &mlDecision, &mlVersion,
		&analystDecision, &analystAt, &analystBy,
	)
	if err != nil {
		return f, err
	}
	f.CodeCommitURI, f.GitHubURI, f.LinePreview = stringPtr(codeURI), stringPtr(githubURI), stringPtr(preview)
	f.Confidence, f.Category, f.Committer = stringPtr(confidence), stringPtr(category), stringPtr(committer)
	f.CommitMessage, f.CommitAuthoredAt = stringPtr(message), stringPtr(authoredAt)
	f.RepoVisibility, f.RepoPushedAt = stringPtr(visibility), stringPtr(pushedAt)
	f.MLDecision, f.MLModelVersion = stringPtr(mlDecision), stringPtr(mlVersion)
	f.AnalystDecision, f.AnalystDecidedAt, f.AnalystDecidedBy = stringPtr(analystDecision), stringPtr(analystAt), stringPtr(analystBy)
	f.FilesChanged, f.Additions, f.Deletions = nullableIntPtr(filesChanged), nullableIntPtr(additions), nullableIntPtr(deletions)
	f.RepoStars, f.RepoForks, f.MLScore = nullableIntPtr(stars), nullableIntPtr(forks), floatPtr(mlScore)
	return f, nil
}

func stringPtr(v sql.NullString) *string {
	if !v.Valid {
		return nil
	}
	x := v.String
	return &x
}
func nullableIntPtr(v sql.NullInt64) *int {
	if !v.Valid {
		return nil
	}
	x := int(v.Int64)
	return &x
}
func floatPtr(v sql.NullFloat64) *float64 {
	if !v.Valid {
		return nil
	}
	x := v.Float64
	return &x
}
