package credentialexposure

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	m "nhi-backend-api/internal/models/Credential_Exposure"
)

type AllowlistRepository struct{ db *sql.DB }

func NewAllowlistRepository(db *sql.DB) *AllowlistRepository { return &AllowlistRepository{db: db} }

func (r *AllowlistRepository) List(ctx context.Context, clientID string) ([]m.AllowlistEntry, error) {
	query := `SELECT client_id,file_path,detector,redacted,reason,dismissed_by,dismissed_at FROM nhi_scanner.secscan_allowlist_dashboard`
	args := []any{}
	if clientID != "" {
		query += ` WHERE client_id=$1`
		args = append(args, clientID)
	}
	query += ` ORDER BY dismissed_at DESC,client_id,file_path,detector`
	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query dashboard allowlist: %w", err)
	}
	defer rows.Close()
	out := make([]m.AllowlistEntry, 0)
	for rows.Next() {
		var item m.AllowlistEntry
		if err := rows.Scan(&item.ClientID, &item.FilePath, &item.Detector, &item.Redacted, &item.Reason, &item.DismissedBy, &item.DismissedAt); err != nil {
			return nil, fmt.Errorf("scan dashboard allowlist: %w", err)
		}
		out = append(out, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate dashboard allowlist: %w", err)
	}
	return out, nil
}

func (r *AllowlistRepository) Upsert(ctx context.Context, req m.AllowlistRequest) (*m.AllowlistEntry, error) {
	by := req.DismissedBy
	if by == "" {
		by = "dashboard user"
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	query := `INSERT INTO nhi_scanner.secscan_allowlist_dashboard (client_id,file_path,detector,redacted,reason,dismissed_by,dismissed_at)
VALUES ($1,$2,$3,$4,$5,$6,$7)
ON CONFLICT (client_id,file_path,detector,redacted) DO UPDATE SET reason=EXCLUDED.reason,dismissed_by=EXCLUDED.dismissed_by,dismissed_at=EXCLUDED.dismissed_at
RETURNING client_id,file_path,detector,redacted,reason,dismissed_by,dismissed_at`
	var out m.AllowlistEntry
	err := r.db.QueryRowContext(ctx, query, req.ClientID, req.FilePath, req.Detector, req.Redacted, req.Reason, by, now).Scan(&out.ClientID, &out.FilePath, &out.Detector, &out.Redacted, &out.Reason, &out.DismissedBy, &out.DismissedAt)
	if err != nil {
		return nil, fmt.Errorf("upsert dashboard allowlist: %w", err)
	}
	return &out, nil
}

func (r *AllowlistRepository) Delete(ctx context.Context, req m.AllowlistRequest) (bool, error) {
	res, err := r.db.ExecContext(ctx, `DELETE FROM nhi_scanner.secscan_allowlist_dashboard WHERE client_id=$1 AND file_path=$2 AND detector=$3 AND redacted=$4`, req.ClientID, req.FilePath, req.Detector, req.Redacted)
	if err != nil {
		return false, fmt.Errorf("delete dashboard allowlist entry: %w", err)
	}
	n, err := res.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("count deleted allowlist rows: %w", err)
	}
	return n > 0, nil
}
