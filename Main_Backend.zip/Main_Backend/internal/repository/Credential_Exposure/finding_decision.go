package credentialexposure

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"
)

var ErrDecisionFindingNotFound = errors.New("finding not found")
var ErrDecisionFindingAmbiguous = errors.New("finding id exists in both platform tables")

type DecisionRepository struct{ db *sql.DB }

func NewDecisionRepository(db *sql.DB) *DecisionRepository { return &DecisionRepository{db: db} }

func (r *DecisionRepository) Save(ctx context.Context, findingID, decision, decidedBy string) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin finding decision: %w", err)
	}
	defer tx.Rollback()
	var cc, gh bool
	if err := tx.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM nhi_scanner.secscan_findings_codecommit WHERE finding_id=$1), EXISTS(SELECT 1 FROM nhi_scanner.secscan_findings_github WHERE finding_id=$1)`, findingID).Scan(&cc, &gh); err != nil {
		return fmt.Errorf("locate finding for decision: %w", err)
	}
	if !cc && !gh {
		return ErrDecisionFindingNotFound
	}
	if cc && gh {
		return ErrDecisionFindingAmbiguous
	}
	table := "nhi_scanner.secscan_findings_codecommit"
	if gh {
		table = "nhi_scanner.secscan_findings_github"
	}
	query := `UPDATE ` + table + ` SET analyst_decision=$1,analyst_decided_at=$2,analyst_decided_by=$3 WHERE finding_id=$4`
	res, err := tx.ExecContext(ctx, query, decision, time.Now().UTC().Format(time.RFC3339Nano), decidedBy, findingID)
	if err != nil {
		return fmt.Errorf("save analyst decision: %w", err)
	}
	n, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("verify analyst decision update: %w", err)
	}
	if n != 1 {
		return ErrDecisionFindingNotFound
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit analyst decision: %w", err)
	}
	return nil
}
