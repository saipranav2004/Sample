package inventory

import (
	"context"
	"database/sql"
	"errors"
	"regexp"
	"strings"

	m "nhi-backend-api/internal/models/inventory"
)

var ErrImpactAnalysisUnavailable = errors.New("impact analysis source unavailable")
var ErrImpactAnalysisNotFound = errors.New("impact entity not found")
var ErrImpactAnalysisInvalid = errors.New("invalid impact entity")

type impactAnalysisReader interface {
	Analyze(context.Context, string, string, []string) (*m.ImpactAnalysisResponse, error)
}
type ImpactAnalysisService struct{ reader impactAnalysisReader }

func NewImpactAnalysisService(r impactAnalysisReader) *ImpactAnalysisService {
	return &ImpactAnalysisService{reader: r}
}

var impactUUIDPattern = regexp.MustCompile(`(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$`)
var impactBigintPattern = regexp.MustCompile(`^[1-9][0-9]{0,18}$`)

func (s *ImpactAnalysisService) Analyze(ctx context.Context, entityType, id string, allowed []string) (*m.ImpactAnalysisResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrImpactAnalysisUnavailable
	}
	entityType = strings.ToLower(strings.TrimSpace(entityType))
	id = strings.TrimSpace(id)
	if entityType != "credentials" && entityType != "identities" {
		return nil, ErrImpactAnalysisInvalid
	}
	if (entityType == "credentials" && !impactUUIDPattern.MatchString(id)) || (entityType == "identities" && !impactBigintPattern.MatchString(id)) {
		return nil, ErrImpactAnalysisInvalid
	}
	out, err := s.reader.Analyze(ctx, entityType, id, allowed)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrImpactAnalysisNotFound
	}
	if err != nil {
		return nil, err
	}
	if out == nil || out.ScanID == "" || out.EntityID != id || out.EntityType != entityType || out.Impact.ServicesAccessible == nil {
		return nil, ErrImpactAnalysisUnavailable
	}
	return out, nil
}
