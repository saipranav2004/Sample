package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityCountsService struct {
	repo *repoinventory.IdentityCountsRepository
}

func NewIdentityCountsService(repo *repoinventory.IdentityCountsRepository) *IdentityCountsService {
	return &IdentityCountsService{repo: repo}
}

func (s *IdentityCountsService) Counts(ctx context.Context, filter repoinventory.IdentityCountsFilter) (*modelsinventory.IdentityCountsResponse, error) {
	return s.repo.Counts(ctx, filter)
}
