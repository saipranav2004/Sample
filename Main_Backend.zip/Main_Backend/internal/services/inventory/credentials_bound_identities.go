package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

type boundIdentitiesReader interface {
	BoundIdentities(context.Context, string, []string) (*m.CredentialBoundIdentitiesResponse, error)
}

type CredentialBoundIdentitiesService struct{ reader boundIdentitiesReader }

func NewCredentialBoundIdentitiesService(r boundIdentitiesReader) *CredentialBoundIdentitiesService {
	return &CredentialBoundIdentitiesService{reader: r}
}

func (s *CredentialBoundIdentitiesService) Get(ctx context.Context, id string, allowed []string) (*m.CredentialBoundIdentitiesResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrCredentialAPIUnavailable
	}
	out, err := s.reader.BoundIdentities(ctx, id, allowed)
	if err != nil {
		return nil, credentialAPIError(err)
	}
	if out == nil || out.CredentialID != id || out.ScanID == "" || out.Identities == nil || out.TotalIdentities != len(out.Identities) {
		return nil, ErrCredentialAPIIncomplete
	}
	if out.BlastRadiusSeverity != "low" && out.BlastRadiusSeverity != "medium" && out.BlastRadiusSeverity != "high" && out.BlastRadiusSeverity != "critical" {
		return nil, ErrCredentialAPIIncomplete
	}
	return out, nil
}
