package inventory

import (
	"context"

	invmodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type CredentialExportService struct {
	repo *repoinventory.CredentialExportRepository
}

func NewCredentialExportService(repo *repoinventory.CredentialExportRepository) *CredentialExportService {
	return &CredentialExportService{repo: repo}
}

func (s *CredentialExportService) Stream(ctx context.Context, f invmodels.ExportCredentialFilter, fn func(*invmodels.ExportCredential) error) error {
	return s.repo.Stream(ctx, f, fn)
}
func (s *CredentialExportService) AccountIDExists(ctx context.Context, v string) (bool, error) {
	return s.repo.AccountIDExists(ctx, v)
}
func (s *CredentialExportService) CredentialTypeExists(ctx context.Context, v string) (bool, error) {
	return s.repo.CredentialTypeExists(ctx, v)
}
func (s *CredentialExportService) RegionExists(ctx context.Context, v string) (bool, error) {
	return s.repo.RegionExists(ctx, v)
}
func (s *CredentialExportService) StatusExists(ctx context.Context, v string) (bool, error) {
	return s.repo.StatusExists(ctx, v)
}
func (s *CredentialExportService) ListCredentialTypes(ctx context.Context) ([]string, error) {
	return s.repo.ListCredentialTypes(ctx)
}
func (s *CredentialExportService) ListRegions(ctx context.Context) ([]string, error) {
	return s.repo.ListRegions(ctx)
}
func (s *CredentialExportService) ListStatuses(ctx context.Context) ([]string, error) {
	return s.repo.ListStatuses(ctx)
}
func (s *CredentialExportService) Count(ctx context.Context, f invmodels.ExportCredentialFilter) (int, error) {
	return s.repo.Count(ctx, f)
}
