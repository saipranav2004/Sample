package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type UpdateIdentityService struct {
	repo *repoinventory.UpdateIdentityRepository
}

func NewUpdateIdentityService(repo *repoinventory.UpdateIdentityRepository) *UpdateIdentityService {
	return &UpdateIdentityService{repo: repo}
}

func (s *UpdateIdentityService) Update(ctx context.Context, id string, req modelsinventory.UpdateIdentityRequest) (*modelsinventory.UpdateIdentityResponse, error) {
	updatedFields, err := s.repo.Update(ctx, id, req)
	if err != nil {
		return nil, err
	}

	return &modelsinventory.UpdateIdentityResponse{
		ID:            id,
		Message:       "Updated",
		UpdatedFields: updatedFields,
	}, nil
}
