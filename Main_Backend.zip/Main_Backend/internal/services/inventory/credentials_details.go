package inventory

import (
	"context"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

// CredentialDetailsService sits between handler and repository.
type CredentialDetailsService struct {
	repo *repoinventory.CredentialDetailsRepository
}

func NewCredentialDetailsService(
	repo *repoinventory.CredentialDetailsRepository,
) *CredentialDetailsService {
	return &CredentialDetailsService{repo: repo}
}

func (s *CredentialDetailsService) GetByID(
	ctx context.Context,
	id string,
) (*inventorymodels.CredentialDetail, error) {
	if id == "" {
		return nil, fmt.Errorf("credential id is required")
	}
	return s.repo.GetByID(ctx, id)
}
