package inventory

import (
	"context"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

// CredentialCountService sits between handler and repository.
type CredentialCountService struct {
	repo      *repoinventory.CredentialCountRepository
	validator *repoinventory.ValidatorRepository
}

func NewCredentialCountService(
	repo *repoinventory.CredentialCountRepository,
	validator *repoinventory.ValidatorRepository,
) *CredentialCountService {
	return &CredentialCountService{
		repo:      repo,
		validator: validator,
	}
}

func (s *CredentialCountService) GetCounts(
	ctx context.Context,
	f inventorymodels.CredentialCountFilter,
) (*inventorymodels.CredentialCountResponse, error) {

	// ── DB-driven validation ──────────────────────────────────────────────
	if err := s.validator.AccountIDExists(ctx, f.AccountID); err != nil {
		return nil, fmt.Errorf("validation: %w", err)
	}

	if err := s.validator.RegionExists(ctx, f.Region); err != nil {
		return nil, fmt.Errorf("validation: %w", err)
	}

	return s.repo.GetCounts(ctx, f)
}
