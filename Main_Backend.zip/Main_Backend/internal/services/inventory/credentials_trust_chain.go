package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

type credentialTrustChainReader interface {
	CredentialTrustChain(context.Context, string, []string) (*m.CredentialTrustChainResponse, error)
}
type CredentialTrustChainService struct{ reader credentialTrustChainReader }

func NewCredentialTrustChainService(r credentialTrustChainReader) *CredentialTrustChainService {
	return &CredentialTrustChainService{reader: r}
}
func (s *CredentialTrustChainService) Get(ctx context.Context, id string, allowed []string) (*m.CredentialTrustChainResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrCredentialAPIUnavailable
	}
	out, err := s.reader.CredentialTrustChain(ctx, id, allowed)
	if err != nil {
		return nil, credentialAPIError(err)
	}
	if out == nil || out.CredentialID != id || out.ScanID == "" || out.CanBeAssumedBy == nil || out.CanAssume == nil || out.CanPassRoleTo == nil {
		return nil, ErrCredentialAPIIncomplete
	}
	return out, nil
}
