// package inventory

// import (
// 	"context"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	repoinventory "nhi-backend-api/internal/repository/inventory"
// )

// type IdentityExportService struct {
// 	repo *repoinventory.IdentityExportRepository
// }

// func NewIdentityExportService(repo *repoinventory.IdentityExportRepository) *IdentityExportService {
// 	return &IdentityExportService{repo: repo}
// }

// func (s *IdentityExportService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
// 	return s.repo.AccountIDExists(ctx, accountID)
// }
// func (s *IdentityExportService) IdentityTypeExists(ctx context.Context, identityType string) (bool, error) {
// 	return s.repo.IdentityTypeExists(ctx, identityType)
// }
// func (s *IdentityExportService) RegionExists(ctx context.Context, region string) (bool, error) {
// 	return s.repo.RegionExists(ctx, region)
// }
// func (s *IdentityExportService) StatusExists(ctx context.Context, status string) (bool, error) {
// 	return s.repo.StatusExists(ctx, status)
// }
// func (s *IdentityExportService) Count(ctx context.Context, f modelsinventory.IdentityExportFilter) (int, error) {
// 	return s.repo.Count(ctx, f)
// }
// func (s *IdentityExportService) Export(ctx context.Context, f modelsinventory.IdentityExportFilter) ([]modelsinventory.IdentityExportRow, error) {
// 	return s.repo.Export(ctx, f)
// }

// package inventory

// import (
// 	"context"

// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	repoinventory "nhi-backend-api/internal/repository/inventory"
// )

// type ExportIdentitiesService struct {
// 	repo *repoinventory.ExportIdentitiesRepository
// }

// func NewExportIdentitiesService(repo *repoinventory.ExportIdentitiesRepository) *ExportIdentitiesService {
// 	return &ExportIdentitiesService{repo: repo}
// }

// func (s *ExportIdentitiesService) Export(ctx context.Context, f modelsinventory.ExportIdentitiesFilter) ([]modelsinventory.IdentityExportRow, error) {
// 	return s.repo.Export(ctx, f)
// }

package inventory

import (
	"context"

	invmodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type ExportIdentitiesService struct {
	repo *repoinventory.ExportIdentitiesRepository
}

func NewExportIdentitiesService(repo *repoinventory.ExportIdentitiesRepository) *ExportIdentitiesService {
	return &ExportIdentitiesService{repo: repo}
}

func (s *ExportIdentitiesService) Stream(ctx context.Context, f invmodels.ExportIdentityFilter, fn func(*invmodels.ExportIdentity) error) error {
	return s.repo.Stream(ctx, f, fn)
}
func (s *ExportIdentitiesService) AccountIDExists(ctx context.Context, v string) (bool, error) {
	return s.repo.AccountIDExists(ctx, v)
}
func (s *ExportIdentitiesService) IdentityTypeExists(ctx context.Context, v string) (bool, error) {
	return s.repo.IdentityTypeExists(ctx, v)
}
func (s *ExportIdentitiesService) RegionExists(ctx context.Context, v string) (bool, error) {
	return s.repo.RegionExists(ctx, v)
}
func (s *ExportIdentitiesService) StatusExists(ctx context.Context, v string) (bool, error) {
	return s.repo.StatusExists(ctx, v)
}
func (s *ExportIdentitiesService) FunctionalClassExists(ctx context.Context, v string) (bool, error) {
	return s.repo.FunctionalClassExists(ctx, v)
}
func (s *ExportIdentitiesService) EnvironmentExists(ctx context.Context, v string) (bool, error) {
	return s.repo.EnvironmentExists(ctx, v)
}
func (s *ExportIdentitiesService) OwnerExists(ctx context.Context, v string) (bool, error) {
	return s.repo.OwnerExists(ctx, v)
}
func (s *ExportIdentitiesService) ListIdentityTypes(ctx context.Context) ([]string, error) {
	return s.repo.ListIdentityTypes(ctx)
}
func (s *ExportIdentitiesService) ListRegions(ctx context.Context) ([]string, error) {
	return s.repo.ListRegions(ctx)
}
func (s *ExportIdentitiesService) ListStatuses(ctx context.Context) ([]string, error) {
	return s.repo.ListStatuses(ctx)
}
func (s *ExportIdentitiesService) ListFunctionalClasses(ctx context.Context) ([]string, error) {
	return s.repo.ListFunctionalClasses(ctx)
}
func (s *ExportIdentitiesService) ListEnvironments(ctx context.Context) ([]string, error) {
	return s.repo.ListEnvironments(ctx)
}
func (s *ExportIdentitiesService) Count(ctx context.Context, f invmodels.ExportIdentityFilter) (int, error) {
	return s.repo.Count(ctx, f)
}
