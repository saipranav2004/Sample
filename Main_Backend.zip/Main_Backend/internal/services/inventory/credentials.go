package inventory

import (
	"context"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
)

// CredentialService sits between the handler and the repository.
type CredentialService struct {
	repo *inventoryrepo.CredentialRepository
}

func NewCredentialService(repo *inventoryrepo.CredentialRepository) *CredentialService {
	return &CredentialService{repo: repo}
}

func (s *CredentialService) List(
	ctx context.Context,
	f inventorymodels.CredentialFilter,
) (*inventorymodels.CredentialListResponse, error) {
	return s.repo.List(ctx, f)
}
