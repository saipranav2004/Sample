package inventory

import (
	"context"
	"math"
	m "nhi-backend-api/internal/models/inventory"
	"path"
	"strings"
)

type credentialUsageReader interface {
	CredentialUsageData(context.Context, string, []string, int) (string, []m.CredentialUsageGrant, []m.CredentialUsageEvent, error)
}
type CredentialUsageService struct{ reader credentialUsageReader }

func NewCredentialUsageService(r credentialUsageReader) *CredentialUsageService {
	return &CredentialUsageService{reader: r}
}
func (s *CredentialUsageService) Get(ctx context.Context, id string, allowed []string, days int) (*m.CredentialUsageResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrCredentialAPIUnavailable
	}
	if days < 1 || days > 3650 {
		return nil, ErrCredentialAPIInvalid
	}
	scanID, grants, events, err := s.reader.CredentialUsageData(ctx, id, allowed, days)
	if err != nil {
		return nil, credentialAPIError(err)
	}
	if grants == nil || events == nil {
		return nil, ErrCredentialAPIIncomplete
	}
	allowedActions := map[string]m.CredentialUsageGrant{}
	for _, g := range grants {
		if strings.EqualFold(g.Effect, "allow") && strings.TrimSpace(g.Action) != "" {
			key := strings.ToLower(strings.TrimSpace(g.Action))
			if _, ok := allowedActions[key]; !ok {
				allowedActions[key] = g
			}
		}
	}
	usedActions := map[string]m.CredentialUsageEvent{}
	for _, e := range events {
		if e.CallCount < 0 || strings.TrimSpace(e.Action) == "" {
			return nil, ErrCredentialAPIIncomplete
		}
		key := strings.ToLower(strings.TrimSpace(e.Action))
		if old, ok := usedActions[key]; ok {
			old.CallCount += e.CallCount
			if e.LastSeen.After(old.LastSeen) {
				old.LastSeen = e.LastSeen
			}
			usedActions[key] = old
		} else {
			usedActions[key] = e
		}
	}
	if strings.TrimSpace(scanID) == "" {
		return nil, ErrCredentialAPIIncomplete
	}
	out := &m.CredentialUsageResponse{CredentialID: id, ScanID: scanID, GrantedActions: int64(len(allowedActions)), UsedActionsList: []m.UsedCredentialAction{}, UnusedButGranted: []m.UnusedCredentialAction{}}
	for key, e := range usedActions {
		matched := false
		for grant := range allowedActions {
			if iamActionMatches(grant, key) {
				matched = true
				break
			}
		}
		if matched {
			out.UsedActionsList = append(out.UsedActionsList, m.UsedCredentialAction{Action: e.Action, LastUsed: e.LastSeen, CallCount: e.CallCount})
		}
	}
	// One grant action is counted as used if any observed action matches it exactly or via IAM wildcard.
	usedGrants := map[string]bool{}
	for grant := range allowedActions {
		for action := range usedActions {
			if iamActionMatches(grant, action) {
				usedGrants[grant] = true
				break
			}
		}
	}
	for grant, g := range allowedActions {
		if !usedGrants[grant] {
			out.UnusedButGranted = append(out.UnusedButGranted, m.UnusedCredentialAction{Action: g.Action, GrantedBy: g.SourceName})
		}
	}
	out.UsedActions = int64(len(usedGrants))
	out.UnusedActions = out.GrantedActions - out.UsedActions
	if out.GrantedActions > 0 {
		out.UnusedPercentage = math.Round(float64(out.UnusedActions)*1000/float64(out.GrantedActions)) / 10
	}
	out.OverprivilegeSeverity = usageSeverity(out.UnusedActions)
	out.Recommendation = usageRecommendation(out.OverprivilegeSeverity, out.UnusedActions)
	return out, nil
}
func iamActionMatches(grant, used string) bool {
	grant = strings.ToLower(grant)
	used = strings.ToLower(used)
	ok, err := path.Match(grant, used)
	return err == nil && ok
}
func usageSeverity(n int64) string {
	switch {
	case n >= 100:
		return "critical"
	case n >= 50:
		return "high"
	case n >= 10:
		return "medium"
	case n > 0:
		return "low"
	default:
		return "none"
	}
}
func usageRecommendation(severity string, n int64) string {
	if n == 0 {
		return "No unused granted actions were identified in the selected period."
	}
	return "Review unused permissions with the service owner and remove permissions only after validating operational requirements."
}
