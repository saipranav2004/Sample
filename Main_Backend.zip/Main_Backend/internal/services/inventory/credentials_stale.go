package inventory

import (
	"context"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
)

type CredentialStaleService struct {
	repo *inventoryrepo.CredentialStaleRepository
}

func NewCredentialStaleService(
	repo *inventoryrepo.CredentialStaleRepository,
) *CredentialStaleService {
	return &CredentialStaleService{repo: repo}
}

func (s *CredentialStaleService) List(
	ctx context.Context,
	f inventorymodels.StaleCredentialFilter,
) (*inventorymodels.StaleCredentialsResponse, error) {
	return s.repo.List(ctx, f)
}

func (s *CredentialStaleService) AccountIDExists(
	ctx context.Context,
	accountID string,
) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}

func (s *CredentialStaleService) CredentialTypeExists(
	ctx context.Context,
	credentialType string,
) (bool, error) {
	return s.repo.CredentialTypeExists(ctx, credentialType)
}

func (s *CredentialStaleService) ListCredentialTypes(
	ctx context.Context,
) ([]string, error) {
	return s.repo.ListCredentialTypes(ctx)
}
