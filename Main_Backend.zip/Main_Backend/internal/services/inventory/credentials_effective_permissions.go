package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"regexp"
	"strings"
)

var permissionServicePattern = regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`)

type effectivePermissionsReader interface {
	EffectivePermissions(context.Context, string, []string, m.CredentialPermissionFilter) (*m.CredentialEffectivePermissionsResponse, error)
}
type CredentialEffectivePermissionsService struct{ reader effectivePermissionsReader }

func NewCredentialEffectivePermissionsService(r effectivePermissionsReader) *CredentialEffectivePermissionsService {
	return &CredentialEffectivePermissionsService{reader: r}
}
func (s *CredentialEffectivePermissionsService) Get(ctx context.Context, id string, allowed []string, f m.CredentialPermissionFilter) (*m.CredentialEffectivePermissionsResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrCredentialAPIUnavailable
	}
	if f.Effect != "" && !strings.EqualFold(f.Effect, "allow") && !strings.EqualFold(f.Effect, "deny") {
		return nil, ErrCredentialAPIInvalid
	}
	if f.Service != "" && !permissionServicePattern.MatchString(f.Service) {
		return nil, ErrCredentialAPIInvalid
	}
	out, err := s.reader.EffectivePermissions(ctx, id, allowed, f)
	if err != nil {
		return nil, credentialAPIError(err)
	}
	if out == nil || out.CredentialID != id || out.ScanID == "" || out.Permissions == nil || out.ByService == nil || out.WildcardActions == nil || out.TotalPermissions != int64(len(out.Permissions)) {
		return nil, ErrCredentialAPIIncomplete
	}
	for _, p := range out.Permissions {
		if strings.TrimSpace(p.Action) == "" || (!strings.EqualFold(p.Effect, "allow") && !strings.EqualFold(p.Effect, "deny")) {
			return nil, ErrCredentialAPIIncomplete
		}
	}
	return out, nil
}
