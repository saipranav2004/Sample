package inventory

import (
	"context"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
)

type CredentialExpiringService struct {
	repo *inventoryrepo.CredentialExpiringRepository
}

func NewCredentialExpiringService(
	repo *inventoryrepo.CredentialExpiringRepository,
) *CredentialExpiringService {
	return &CredentialExpiringService{repo: repo}
}

func (s *CredentialExpiringService) List(
	ctx context.Context,
	f inventorymodels.ExpiringCredentialFilter,
) (*inventorymodels.ExpiringCredentialsResponse, error) {
	return s.repo.List(ctx, f)
}

// AccountIDExists validates account_id against the DB.
func (s *CredentialExpiringService) AccountIDExists(
	ctx context.Context,
	accountID string,
) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}

// CredentialTypeExists validates credential_type against the DB.
func (s *CredentialExpiringService) CredentialTypeExists(
	ctx context.Context,
	credentialType string,
) (bool, error) {
	return s.repo.CredentialTypeExists(ctx, credentialType)
}

// ListCredentialTypes returns the credential types that exist in the DB.
func (s *CredentialExpiringService) ListCredentialTypes(
	ctx context.Context,
) ([]string, error) {
	return s.repo.ListCredentialTypes(ctx)
}
