package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityGroupedByClassService struct {
	repo *repoinventory.IdentityGroupedByClassRepository
}

func NewIdentityGroupedByClassService(repo *repoinventory.IdentityGroupedByClassRepository) *IdentityGroupedByClassService {
	return &IdentityGroupedByClassService{repo: repo}
}

func (s *IdentityGroupedByClassService) GroupedByClass(ctx context.Context, f modelsinventory.GroupedByClassFilter) (modelsinventory.GroupedByClassResponse, error) {
	groups, err := s.repo.GroupedByClass(ctx, f)
	if err != nil {
		return modelsinventory.GroupedByClassResponse{}, err
	}
	return modelsinventory.GroupedByClassResponse{Groups: groups}, nil
}

func (s *IdentityGroupedByClassService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}

func (s *IdentityGroupedByClassService) RegionExists(ctx context.Context, region string) (bool, error) {
	return s.repo.RegionExists(ctx, region)
}

func (s *IdentityGroupedByClassService) ListRegions(ctx context.Context) ([]string, error) {
	return s.repo.ListRegions(ctx)
}
