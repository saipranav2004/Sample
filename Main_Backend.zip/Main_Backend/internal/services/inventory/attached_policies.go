package inventory

import (
	"context"
	"fmt"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

// AttachedPoliciesService sits between handler and repository.
type AttachedPoliciesService struct {
	repo *repoinventory.AttachedPoliciesRepository
}

func NewAttachedPoliciesService(
	repo *repoinventory.AttachedPoliciesRepository,
) *AttachedPoliciesService {
	return &AttachedPoliciesService{repo: repo}
}

func (s *AttachedPoliciesService) GetPolicies(
	ctx context.Context,
	id string,
) (*inventorymodels.AttachedPoliciesResponse, error) {
	if id == "" {
		return nil, fmt.Errorf("credential id is required")
	}
	return s.repo.GetPolicies(ctx, id)
}
