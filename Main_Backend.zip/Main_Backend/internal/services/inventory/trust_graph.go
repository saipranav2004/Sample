package inventory

import (
	"context"
	"errors"
	"regexp"
	"strings"

	m "nhi-backend-api/internal/models/inventory"
)

var ErrTrustGraphUnavailable = errors.New("trust graph source unavailable")
var ErrTrustGraphInvalid = errors.New("invalid trust graph filter")

type trustGraphReader interface {
	Graph(context.Context, []string, string, string) (*m.TrustGraphResponse, error)
}
type TrustGraphService struct{ reader trustGraphReader }

func NewTrustGraphService(r trustGraphReader) *TrustGraphService {
	return &TrustGraphService{reader: r}
}

var trustEdgeTypePattern = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,80}$`)

func (s *TrustGraphService) Get(ctx context.Context, allowed []string, accountID, edgeType string) (*m.TrustGraphResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrTrustGraphUnavailable
	}
	if accountID != "" {
		ok := false
		for _, a := range allowed {
			if a == accountID {
				ok = true
				break
			}
		}
		if !ok {
			return nil, ErrTrustGraphInvalid
		}
	}
	edgeType = strings.TrimSpace(edgeType)
	if edgeType != "" && !trustEdgeTypePattern.MatchString(edgeType) {
		return nil, ErrTrustGraphInvalid
	}
	out, err := s.reader.Graph(ctx, allowed, accountID, edgeType)
	if err != nil {
		return nil, err
	}
	if out == nil || out.ScanID == "" || out.Nodes == nil || out.Edges == nil {
		return nil, ErrTrustGraphUnavailable
	}
	return out, nil
}
