package inventory

import (
	"database/sql"
	"errors"

	m "nhi-backend-api/internal/models/inventory"
)

var (
	ErrCredentialAPIUnavailable = errors.New("credential API source unavailable")
	ErrCredentialAPINotFound    = errors.New("credential not found")
	ErrCredentialAPIIncomplete  = errors.New("credential API source incomplete")
	ErrCredentialAPIInvalid     = errors.New("invalid credential API filters")
)

func credentialAPIError(err error) error {
	if errors.Is(err, m.ErrLatestCompletedScanUnavailable) {
		return ErrCredentialAPIUnavailable
	}
	if errors.Is(err, sql.ErrNoRows) {
		return ErrCredentialAPINotFound
	}
	return err
}
