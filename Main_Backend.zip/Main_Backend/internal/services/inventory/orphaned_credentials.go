package inventory

import (
	"context"
	"errors"

	m "nhi-backend-api/internal/models/inventory"
)

var ErrOrphanedCredentialsUnavailable = errors.New("orphaned credentials source unavailable")

type orphanedCredentialsReader interface {
	List(context.Context, []string) (*m.OrphanedCredentialsResponse, error)
}
type OrphanedCredentialsService struct{ reader orphanedCredentialsReader }

func NewOrphanedCredentialsService(r orphanedCredentialsReader) *OrphanedCredentialsService {
	return &OrphanedCredentialsService{reader: r}
}
func (s *OrphanedCredentialsService) Get(ctx context.Context, allowed []string) (*m.OrphanedCredentialsResponse, error) {
	if s == nil || s.reader == nil || len(allowed) == 0 {
		return nil, ErrOrphanedCredentialsUnavailable
	}
	out, err := s.reader.List(ctx, allowed)
	if err != nil {
		return nil, err
	}
	if out == nil || out.ScanID == "" || out.Orphaned == nil || out.Total != len(out.Orphaned) {
		return nil, ErrOrphanedCredentialsUnavailable
	}
	return out, nil
}
