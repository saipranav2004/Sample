package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type FiltersService struct {
	repo *repodashboard.FiltersRepository
}

func NewFiltersService(repo *repodashboard.FiltersRepository) *FiltersService {
	return &FiltersService{repo: repo}
}

func (s *FiltersService) GetFilters(ctx context.Context) (*models.DashboardFiltersResponse, error) {
	return s.repo.GetFilters(ctx)
}
