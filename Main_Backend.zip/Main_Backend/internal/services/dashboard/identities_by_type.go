package dashboard

import (
	"context"

	modelsdashboard "nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type IdentitiesByTypeService struct {
	repo *repodashboard.IdentitiesByTypeRepository
}

func NewIdentitiesByTypeService(repo *repodashboard.IdentitiesByTypeRepository) *IdentitiesByTypeService {
	return &IdentitiesByTypeService{repo: repo}
}

func (s *IdentitiesByTypeService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}
func (s *IdentitiesByTypeService) RegionExists(ctx context.Context, region string) (bool, error) {
	return s.repo.RegionExists(ctx, region)
}
func (s *IdentitiesByTypeService) StatusExists(ctx context.Context, status string) (bool, error) {
	return s.repo.StatusExists(ctx, status)
}
func (s *IdentitiesByTypeService) FunctionalClassExists(ctx context.Context, functionalClass string) (bool, error) {
	return s.repo.FunctionalClassExists(ctx, functionalClass)
}
func (s *IdentitiesByTypeService) ByType(ctx context.Context, f modelsdashboard.IdentityByTypeFilter) (*modelsdashboard.IdentitiesByTypeResponse, error) {
	return s.repo.ByType(ctx, f)
}
