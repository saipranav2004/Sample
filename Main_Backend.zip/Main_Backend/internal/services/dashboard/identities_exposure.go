package dashboard

import (
	"context"

	modelsdashboard "nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type IdentitiesExposureService struct {
	repo *repodashboard.IdentitiesExposureRepository
}

func NewIdentitiesExposureService(repo *repodashboard.IdentitiesExposureRepository) *IdentitiesExposureService {
	return &IdentitiesExposureService{repo: repo}
}

func (s *IdentitiesExposureService) AccountIDExists(ctx context.Context, accountID string) (bool, error) {
	return s.repo.AccountIDExists(ctx, accountID)
}

func (s *IdentitiesExposureService) Exposure(ctx context.Context, f modelsdashboard.IdentityExposureFilter) (*modelsdashboard.IdentityExposureResponse, error) {
	return s.repo.Exposure(ctx, f)
}
