// package dashboard

// import (
// 	"context"

// 	"nhi-backend-api/internal/models"
// 	repodashboard "nhi-backend-api/internal/repository/dashboard"
// )

// type IdentitiesByRegionService struct {
// 	repo *repodashboard.IdentitiesByRegionRepository
// }

// func NewIdentitiesByRegionService(repo *repodashboard.IdentitiesByRegionRepository) *IdentitiesByRegionService {
// 	return &IdentitiesByRegionService{repo: repo}
// }

// func (s *IdentitiesByRegionService) Breakdown(ctx context.Context, filter repodashboard.IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
// 	return s.repo.Breakdown(ctx, filter)
// }

package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type IdentitiesByRegionService struct {
	repo *repodashboard.IdentitiesByRegionRepository
}

func NewIdentitiesByRegionService(repo *repodashboard.IdentitiesByRegionRepository) *IdentitiesByRegionService {
	return &IdentitiesByRegionService{repo: repo}
}

var ErrInvalidIdentityType = fmt.Errorf("invalid identity_type value")

func (s *IdentitiesByRegionService) Breakdown(ctx context.Context, filter repodashboard.IdentitiesByRegionFilter) (*models.IdentitiesByRegionResponse, error) {
	valid, err := s.repo.ValidIdentityType(ctx, filter.IdentityType)
	if err != nil {
		return nil, err
	}
	if !valid {
		return nil, ErrInvalidIdentityType
	}
	return s.repo.Breakdown(ctx, filter)
}
