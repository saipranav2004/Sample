package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type OwnershipCoverageService struct {
	repo *repodashboard.OwnershipCoverageRepository
}

func NewOwnershipCoverageService(repo *repodashboard.OwnershipCoverageRepository) *OwnershipCoverageService {
	return &OwnershipCoverageService{repo: repo}
}

func (s *OwnershipCoverageService) GetOwnershipCoverage(ctx context.Context, f repodashboard.OwnershipCoverageFilter) (*models.OwnershipCoverageResponse, error) {
	return s.repo.GetOwnershipCoverage(ctx, f)
}
