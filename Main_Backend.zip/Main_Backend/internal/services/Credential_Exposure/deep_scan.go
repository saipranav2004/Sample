package credentialexposure

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	r "nhi-backend-api/internal/repository/Credential_Exposure"
)

var ErrScannerProxyUnavailable = errors.New("scanner proxy is not configured")

type DeepScanService struct {
	repo         *r.DeepScanRepository
	baseURL, key string
	client       *http.Client
}

func NewDeepScanService(repo *r.DeepScanRepository, baseURL, key string) *DeepScanService {
	return &DeepScanService{repo: repo, baseURL: strings.TrimRight(strings.TrimSpace(baseURL), "/"), key: strings.TrimSpace(key), client: &http.Client{Timeout: 25 * time.Second, CheckRedirect: func(_ *http.Request, _ []*http.Request) error { return http.ErrUseLastResponse }}}
}
func (s *DeepScanService) Status(ctx context.Context, clientID, repoKey, platform string) ([]m.DeepScanResult, error) {
	return s.repo.Status(ctx, clientID, repoKey, platform)
}
func (s *DeepScanService) Trigger(ctx context.Context, req m.DeepScanRequest) (int, []byte, error) {
	if s.baseURL == "" || s.key == "" {
		return 0, nil, ErrScannerProxyUnavailable
	}
	u, err := url.Parse(s.baseURL)
	if err != nil || u.Scheme != "https" || u.Host == "" || u.User != nil {
		return 0, nil, fmt.Errorf("scanner proxy URL must be an https URL")
	}
	body, err := json.Marshal(req)
	if err != nil {
		return 0, nil, fmt.Errorf("encode deep scan request: %w", err)
	}
	hreq, err := http.NewRequestWithContext(ctx, http.MethodPost, s.baseURL+"/api/deep-scan", bytes.NewReader(body))
	if err != nil {
		return 0, nil, fmt.Errorf("create scanner request: %w", err)
	}
	hreq.Header.Set("Content-Type", "application/json")
	hreq.Header.Set("Accept", "application/json")
	hreq.Header.Set("X-Dashboard-Key", s.key)
	resp, err := s.client.Do(hreq)
	if err != nil {
		return 0, nil, fmt.Errorf("scanner aggregator unavailable: %w", err)
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20+1))
	if err != nil {
		return 0, nil, fmt.Errorf("read scanner response: %w", err)
	}
	if len(b) > 1<<20 {
		return 0, nil, fmt.Errorf("scanner response exceeds limit")
	}
	if !json.Valid(b) {
		return 0, nil, fmt.Errorf("scanner returned a non-JSON response")
	}
	return resp.StatusCode, b, nil
}
