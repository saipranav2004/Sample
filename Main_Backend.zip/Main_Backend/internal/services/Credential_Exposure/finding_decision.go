package credentialexposure

import (
	"context"
	"fmt"
	"strings"

	r "nhi-backend-api/internal/repository/Credential_Exposure"
)

type DecisionService struct{ repo *r.DecisionRepository }

func NewDecisionService(repo *r.DecisionRepository) *DecisionService {
	return &DecisionService{repo: repo}
}
func (s *DecisionService) Save(ctx context.Context, id, decision, by string) error {
	id = strings.TrimSpace(id)
	decision = strings.ToLower(strings.TrimSpace(decision))
	by = strings.TrimSpace(by)
	if id == "" || len(id) > 1000 {
		return fmt.Errorf("finding_id is required and must not exceed 1000 characters")
	}
	if decision != "real_secret" && decision != "false_positive" {
		return fmt.Errorf("decision must be real_secret or false_positive")
	}
	if by == "" {
		by = "dashboard user"
	}
	if len(by) > 300 {
		return fmt.Errorf("decided_by exceeds 300 characters")
	}
	return s.repo.Save(ctx, id, decision, by)
}
