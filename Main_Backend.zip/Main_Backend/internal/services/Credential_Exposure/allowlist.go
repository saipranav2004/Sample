package credentialexposure

import (
	"context"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	r "nhi-backend-api/internal/repository/Credential_Exposure"
)

type AllowlistService struct{ repo *r.AllowlistRepository }

func NewAllowlistService(repo *r.AllowlistRepository) *AllowlistService {
	return &AllowlistService{repo: repo}
}
func (s *AllowlistService) List(ctx context.Context, clientID string) ([]m.AllowlistEntry, error) {
	return s.repo.List(ctx, clientID)
}
func (s *AllowlistService) Upsert(ctx context.Context, req m.AllowlistRequest) (*m.AllowlistEntry, error) {
	if strings.TrimSpace(req.ClientID) == "" || len(req.ClientID) > 200 || strings.TrimSpace(req.FilePath) == "" || len(req.FilePath) > 1000 || strings.TrimSpace(req.Detector) == "" || len(req.Detector) > 200 || strings.TrimSpace(req.Redacted) == "" || len(req.Redacted) > 500 {
		return nil, fmt.Errorf("client_id, file_path, detector and redacted are required and must fit their database columns")
	}
	if len(req.Reason) > 1000 {
		return nil, fmt.Errorf("reason exceeds 1000 characters")
	}
	if len(req.DismissedBy) > 200 {
		return nil, fmt.Errorf("dismissed_by exceeds 200 characters")
	}
	return s.repo.Upsert(ctx, req)
}
func (s *AllowlistService) Delete(ctx context.Context, req m.AllowlistRequest) (bool, error) {
	if strings.TrimSpace(req.ClientID) == "" || len(req.ClientID) > 200 || strings.TrimSpace(req.FilePath) == "" || len(req.FilePath) > 1000 || strings.TrimSpace(req.Detector) == "" || len(req.Detector) > 200 || strings.TrimSpace(req.Redacted) == "" || len(req.Redacted) > 500 {
		return false, fmt.Errorf("client_id, file_path, detector and redacted are required and must fit their database columns")
	}
	return s.repo.Delete(ctx, req)
}
