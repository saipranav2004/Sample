package credentialexposure

import (
	"context"
	"errors"
	"testing"

	m "nhi-backend-api/internal/models/Credential_Exposure"
)

func TestFindingsServiceRejectsInvalidPlatformBeforeRepositoryAccess(t *testing.T) {
	svc := NewFindingsService(nil)
	_, _, err := svc.List(context.Background(), m.FindingsFilter{Platform: "bitbucket", Limit: 20})
	if err == nil {
		t.Fatal("expected invalid platform error")
	}
}

func TestDecisionServiceRejectsUnsupportedDecisionBeforeRepositoryAccess(t *testing.T) {
	svc := NewDecisionService(nil)
	err := svc.Save(context.Background(), "some-finding", "dismiss", "reviewer")
	if err == nil {
		t.Fatal("expected unsupported decision error")
	}
}

func TestDeepScanProxyRequiresServerConfiguration(t *testing.T) {
	svc := NewDeepScanService(nil, "", "")
	_, _, err := svc.Trigger(context.Background(), m.DeepScanRequest{ClientID: "client", Repository: "repo"})
	if !errors.Is(err, ErrScannerProxyUnavailable) {
		t.Fatalf("expected ErrScannerProxyUnavailable, got %v", err)
	}
}
