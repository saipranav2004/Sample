package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type DashboardService struct {
	dashboardRepo *repository.DashboardRepository
	identityRepo  *repository.IdentityDetailsRepository // <-- UPDATED
}

func NewDashboardService(dashboardRepo *repository.DashboardRepository, identityRepo *repository.IdentityDetailsRepository) *DashboardService {
	return &DashboardService{
		dashboardRepo: dashboardRepo,
		identityRepo:  identityRepo,
	}
}

func (s *DashboardService) GetSummary(ctx context.Context, scanID string) (*models.DashboardSummary, error) {
	return s.dashboardRepo.GetSummary(ctx, scanID)
}

func (s *DashboardService) GetMyResources(ctx context.Context, userEmail string, offset, limit int, scanID string) ([]models.IdentityDetail, int, error) { // <-- UPDATED RETURN TYPE
	filter := repository.IdentityDetailsFilter{ // <-- UPDATED
		OwnerName: userEmail,
		Offset:    offset,
		Limit:     limit,
		ScanID:    scanID,
	}
	return s.identityRepo.List(ctx, filter)
}
