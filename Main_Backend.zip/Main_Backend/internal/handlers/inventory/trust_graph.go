package inventory

import (
	"errors"
	"log"
	"net/http"

	svc "nhi-backend-api/internal/services/inventory"
)

type TrustGraphHandler struct {
	service *svc.TrustGraphService
	scope   CredentialListScope
}

func NewTrustGraphHandler(s *svc.TrustGraphService, scope CredentialListScope) *TrustGraphHandler {
	return &TrustGraphHandler{service: s, scope: scope}
}
func (h *TrustGraphHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil || h.service == nil {
		credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Trust graph source unavailable")
		return
	}
	q, ok := credentialAPIQuery(r, "account_id", "edge_type")
	if !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "Invalid trust graph filters")
		return
	}
	allowed, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	accountID := q.Get("account_id")
	if accountID != "" {
		found := false
		for _, a := range allowed {
			if a == accountID {
				found = true
				break
			}
		}
		if !found {
			credentialAPIError(w, 403, "FORBIDDEN", "AWS account is not authorized")
			return
		}
	}
	out, err := h.service.Get(r.Context(), allowed, accountID, q.Get("edge_type"))
	if err != nil {
		switch {
		case errors.Is(err, svc.ErrTrustGraphInvalid):
			credentialAPIError(w, 400, "INVALID_FILTER", "Invalid trust graph filters")
		case errors.Is(err, svc.ErrTrustGraphUnavailable):
			credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Trust graph source unavailable")
		default:
			log.Printf("trust graph failed: %T", err)
			credentialAPIError(w, 500, "INTERNAL_ERROR", "Unable to load trust graph")
		}
		return
	}
	credentialAPIOK(w, out)
}
