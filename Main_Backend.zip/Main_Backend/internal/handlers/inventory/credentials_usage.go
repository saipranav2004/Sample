package inventory

import (
	"github.com/gorilla/mux"
	"net/http"
	svc "nhi-backend-api/internal/services/inventory"
)

type CredentialUsageHandler struct {
	service *svc.CredentialUsageService
	scope   CredentialListScope
}

func NewCredentialUsageHandler(service *svc.CredentialUsageService, scope CredentialListScope) *CredentialUsageHandler {
	return &CredentialUsageHandler{service: service, scope: scope}
}
func (h *CredentialUsageHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil {
		credentialAPIError(w, 503, "SOURCE_UNAVAILABLE", "Credential usage source unavailable")
		return
	}
	id := mux.Vars(r)["id"]
	if !credentialAPIUUID.MatchString(id) {
		credentialAPIError(w, 400, "INVALID_ID", "Credential ID must be a UUID")
		return
	}
	q, ok := credentialAPIQuery(r, "days")
	if !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "Invalid or duplicate usage filter")
		return
	}
	days, valid := credentialAPIParseInt(q.Get("days"), 90, 1, 3650)
	if !valid {
		credentialAPIError(w, 400, "INVALID_FILTER", "days must be between 1 and 3650")
		return
	}
	ids, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	out, err := h.service.Get(r.Context(), id, ids, days)
	if err != nil {
		credentialAPIServiceError(w, err)
		return
	}
	credentialAPIOK(w, out)
}
