// package inventory

// import (
// 	"encoding/csv"
// 	"encoding/json"
// 	"fmt"
// 	"net/http"
// 	"strconv"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/models"
// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	svcinventory "nhi-backend-api/internal/services/inventory"
// )

// type IdentityExportHandler struct {
// 	service *svcinventory.IdentityExportService
// }

// func NewIdentityExportHandler(service *svcinventory.IdentityExportService) *IdentityExportHandler {
// 	return &IdentityExportHandler{service: service}
// }

// func (h *IdentityExportHandler) Export(w http.ResponseWriter, r *http.Request) {
// 	ctx := r.Context()
// 	q := r.URL.Query()

// 	format := strings.ToLower(strings.TrimSpace(q.Get("format")))
// 	if format == "" {
// 		format = "csv"
// 	}
// 	if format != "csv" && format != "json" {
// 		sendJSON(w, http.StatusBadRequest, models.APIResponse{
// 			Success: false,
// 			Message: "invalid format",
// 			Error:   "format must be one of: csv, json",
// 		})
// 		return
// 	}

// 	page := 1
// 	if v := q.Get("page"); v != "" {
// 		p, err := strconv.Atoi(v)
// 		if err != nil || p < 1 || p > maxIdentityListPage {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid page", Error: "page must be a positive integer"})
// 			return
// 		}
// 		page = p
// 	}

// 	limit := 50
// 	if v := q.Get("limit"); v != "" {
// 		l, err := strconv.Atoi(v)
// 		if err != nil || l < 1 || l > maxIdentityListLimit {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid limit", Error: fmt.Sprintf("limit must be between 1 and %d", maxIdentityListLimit)})
// 			return
// 		}
// 		limit = l
// 	}

// 	sortBy := q.Get("sort_by")
// 	if sortBy != "" {
// 		if _, ok := identitySortFields[sortBy]; !ok {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid sort_by", Error: "unsupported sort_by field"})
// 			return
// 		}
// 	}

// 	sortOrder := strings.ToLower(q.Get("sort_order"))
// 	if sortOrder != "" && sortOrder != "asc" && sortOrder != "desc" {
// 		sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid sort_order", Error: "sort_order must be asc or desc"})
// 		return
// 	}

// 	filter := modelsinventory.IdentityExportFilter{
// 		Page:            page,
// 		Limit:           limit,
// 		SortBy:          sortBy,
// 		SortOrder:       sortOrder,
// 		Search:          q.Get("search"),
// 		IdentityType:    q.Get("identity_type"),
// 		FunctionalClass: q.Get("functional_class"),
// 		AccountID:       q.Get("account_id"),
// 		Region:          q.Get("region"),
// 		Status:          q.Get("status"),
// 		Owner:           q.Get("owner"),
// 		Environment:     q.Get("environment"),
// 		Format:          format,
// 	}

// 	if v := q.Get("is_public"); v != "" {
// 		b, err := strconv.ParseBool(v)
// 		if err != nil {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid is_public", Error: "is_public must be true or false"})
// 			return
// 		}
// 		filter.IsPublic = &b
// 	}

// 	if v := q.Get("last_active_before"); v != "" {
// 		t, err := time.Parse(time.RFC3339, v)
// 		if err != nil {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid last_active_before", Error: "last_active_before must be an RFC3339 timestamp"})
// 			return
// 		}
// 		filter.LastActiveBefore = &t
// 	}

// 	if filter.IdentityType != "" {
// 		ok, err := h.service.IdentityTypeExists(ctx, filter.IdentityType)
// 		if err != nil {
// 			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate identity_type", Error: err.Error()})
// 			return
// 		}
// 		if !ok {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid identity_type", Error: "identity_type does not exist"})
// 			return
// 		}
// 	}
// 	if filter.AccountID != "" {
// 		ok, err := h.service.AccountIDExists(ctx, filter.AccountID)
// 		if err != nil {
// 			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate account_id", Error: err.Error()})
// 			return
// 		}
// 		if !ok {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid account_id", Error: "account_id does not exist"})
// 			return
// 		}
// 	}
// 	if filter.Region != "" {
// 		ok, err := h.service.RegionExists(ctx, filter.Region)
// 		if err != nil {
// 			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate region", Error: err.Error()})
// 			return
// 		}
// 		if !ok {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid region", Error: "region does not exist"})
// 			return
// 		}
// 	}
// 	if filter.Status != "" {
// 		ok, err := h.service.StatusExists(ctx, filter.Status)
// 		if err != nil {
// 			sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to validate status", Error: err.Error()})
// 			return
// 		}
// 		if !ok {
// 			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "invalid status", Error: "status does not exist"})
// 			return
// 		}
// 	}

// 	total, err := h.service.Count(ctx, filter)
// 	if err != nil {
// 		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to count identities", Error: err.Error()})
// 		return
// 	}

// 	if total == 0 {
// 		sendJSON(w, http.StatusOK, map[string]interface{}{
// 			"success": true,
// 			"message": "no identities matched the given filters",
// 			"data":    []interface{}{},
// 		})
// 		return
// 	}

// 	rows, err := h.service.Export(ctx, filter)
// 	if err != nil {
// 		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to export identities", Error: err.Error()})
// 		return
// 	}

// 	w.Header().Set("X-Total-Count", strconv.Itoa(total))

// 	if format == "json" {
// 		w.Header().Set("Content-Type", "application/json")
// 		w.Header().Set("Content-Disposition", `attachment; filename="identities_export.json"`)
// 		w.WriteHeader(http.StatusOK)
// 		_ = json.NewEncoder(w).Encode(rows)
// 		return
// 	}

// 	w.Header().Set("Content-Type", "text/csv")
// 	w.Header().Set("Content-Disposition", `attachment; filename="identities_export.csv"`)
// 	w.WriteHeader(http.StatusOK)

// 	writer := csv.NewWriter(w)
// 	defer writer.Flush()

// 	header := []string{
// 		"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
// 		"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "deleted_at",
// 		"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible",
// 		"tags", "owner", "environment", "parent_arn", "cloudtrail_creator_arn",
// 		"discovery_source", "scan_id", "type_attributes", "raw_api_response",
// 	}
// 	_ = writer.Write(header)

// 	for _, row := range rows {
// 		record := []string{
// 			row.ID, row.ARN, row.Name, row.IdentityType, row.FunctionalClass, row.AccountID, row.Region, row.Status,
// 			row.CreatedAtAWS, row.FirstSeenAt, row.LastSeenAt, row.LastActivityAt, row.DeletedAt,
// 			row.VPCID, row.SubnetID, string(row.SecurityGroupIDs), strconv.FormatBool(row.IsPubliclyAccessible),
// 			string(row.Tags), row.Owner, row.Environment, row.ParentARN, row.CloudTrailCreatorARN,
// 			row.DiscoverySource, row.ScanID, string(row.TypeAttributes), string(row.RawAPIResponse),
// 		}
// 		_ = writer.Write(record)
// 	}
// }

// package inventory

// import (
// 	"encoding/csv"
// 	"encoding/json"
// 	"fmt"
// 	"net/http"
// 	"strconv"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/models"
// 	modelsinventory "nhi-backend-api/internal/models/inventory"
// 	svcinventory "nhi-backend-api/internal/services/inventory"
// )

// type ExportIdentitiesHandler struct {
// 	service *svcinventory.ExportIdentitiesService
// }

// func NewExportIdentitiesHandler(service *svcinventory.ExportIdentitiesService) *ExportIdentitiesHandler {
// 	return &ExportIdentitiesHandler{service: service}
// }

// func (h *ExportIdentitiesHandler) Export(w http.ResponseWriter, r *http.Request) {
// 	query := r.URL.Query()

// 	format := strings.ToLower(strings.TrimSpace(query.Get("format")))
// 	if format == "" {
// 		format = "json"
// 	}
// 	if format != "json" && format != "csv" {
// 		sendJSON(w, http.StatusBadRequest, models.APIResponse{
// 			Success: false,
// 			Message: "invalid format",
// 			Error:   "format must be 'csv' or 'json'",
// 		})
// 		return
// 	}

// 	filter := modelsinventory.ExportIdentitiesFilter{
// 		AccountID:       strings.TrimSpace(query.Get("account_id")),
// 		Region:          strings.TrimSpace(query.Get("region")),
// 		IdentityType:    strings.TrimSpace(query.Get("identity_type")),
// 		Status:          strings.TrimSpace(query.Get("status")),
// 		FunctionalClass: strings.TrimSpace(query.Get("functional_class")),
// 		Environment:     strings.TrimSpace(query.Get("environment")),
// 		Owner:           strings.TrimSpace(query.Get("owner")),
// 		Search:          strings.TrimSpace(query.Get("search")),
// 		Format:          format,
// 	}

// 	rows, err := h.service.Export(r.Context(), filter)
// 	if err != nil {
// 		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
// 			Success: false,
// 			Message: "failed to export identities",
// 			Error:   err.Error(),
// 		})
// 		return
// 	}

// 	timestamp := time.Now().UTC().Format("20060102_150405")
// 	filename := fmt.Sprintf("identities_export_%s.%s", timestamp, format)

// 	if format == "csv" {
// 		h.writeCSV(w, filename, rows)
// 		return
// 	}
// 	h.writeJSON(w, filename, rows)
// }

// func (h *ExportIdentitiesHandler) writeJSON(w http.ResponseWriter, filename string, rows []modelsinventory.IdentityExportRow) {
// 	w.Header().Set("Content-Type", "application/json")
// 	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", filename))
// 	w.WriteHeader(http.StatusOK)
// 	_ = json.NewEncoder(w).Encode(rows)
// }

// func (h *ExportIdentitiesHandler) writeCSV(w http.ResponseWriter, filename string, rows []modelsinventory.IdentityExportRow) {
// 	w.Header().Set("Content-Type", "text/csv")
// 	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", filename))
// 	w.WriteHeader(http.StatusOK)

// 	writer := csv.NewWriter(w)
// 	defer writer.Flush()

// 	_ = writer.Write([]string{
// 		"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
// 		"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "deleted_at",
// 		"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible", "tags",
// 		"owner", "environment", "parent_arn", "cloudtrail_creator_arn", "discovery_source", "scan_id",
// 		"type_attributes", "raw_api_response", "created_at", "updated_at",
// 	})

// 	for _, row := range rows {
// 		_ = writer.Write([]string{
// 			row.ID, row.ARN, strPtrOrEmpty(row.Name), row.IdentityType, strPtrOrEmpty(row.FunctionalClass),
// 			row.AccountID, strPtrOrEmpty(row.Region), strPtrOrEmpty(row.Status),
// 			timePtrOrEmpty(row.CreatedAtAWS), timePtrOrEmpty(row.FirstSeenAt), timePtrOrEmpty(row.LastSeenAt),
// 			timePtrOrEmpty(row.LastActivityAt), timePtrOrEmpty(row.DeletedAt),
// 			strPtrOrEmpty(row.VpcID), strPtrOrEmpty(row.SubnetID), strPtrOrEmpty(row.SecurityGroupIDs),
// 			boolPtrOrEmpty(row.IsPubliclyAccessible), strPtrOrEmpty(row.Tags),
// 			strPtrOrEmpty(row.Owner), strPtrOrEmpty(row.Environment), strPtrOrEmpty(row.ParentARN),
// 			strPtrOrEmpty(row.CloudtrailCreatorARN), strPtrOrEmpty(row.DiscoverySource), strPtrOrEmpty(row.ScanID),
// 			strPtrOrEmpty(row.TypeAttributes), strPtrOrEmpty(row.RawAPIResponse),
// 			row.CreatedAt, row.UpdatedAt,
// 		})
// 	}
// }

// func strPtrOrEmpty(s *string) string {
// 	if s == nil {
// 		return ""
// 	}
// 	return *s
// }

// func boolPtrOrEmpty(b *bool) string {
// 	if b == nil {
// 		return ""
// 	}
// 	return strconv.FormatBool(*b)
// }

// func timePtrOrEmpty(t *time.Time) string {
// 	if t == nil {
// 		return ""
// 	}
// 	return t.Format(time.RFC3339)
// }

// package inventory

// import (
// 	"context"
// 	"encoding/csv"
// 	"encoding/json"
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"strconv"
// 	"strings"
// 	"time"

// 	invmodels "nhi-backend-api/internal/models/inventory"
// 	svcinventory "nhi-backend-api/internal/services/inventory"
// )

// var identitySortFields = []string{
// 	"name", "identity_type", "functional_class", "account_id", "region", "status",
// 	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at",
// }

// var identityCSVHeader = []string{
// 	"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
// 	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at",
// 	"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible",
// 	"tags", "owner", "environment", "parent_arn", "cloudtrail_creator_arn",
// 	"discovery_source", "scan_id", "type_attributes", "raw_api_response",
// 	"created_at", "updated_at",
// }

// var identityFilterKeys = []string{
// 	"search", "account_id", "region", "identity_type", "status", "functional_class",
// 	"environment", "owner", "sort_by", "sort_order", "page", "limit",
// }

// type ExportIdentitiesHandler struct {
// 	service *svcinventory.ExportIdentitiesService
// }

// func NewExportIdentitiesHandler(service *svcinventory.ExportIdentitiesService) *ExportIdentitiesHandler {
// 	return &ExportIdentitiesHandler{service: service}
// }

// // checkDB — same name as CredentialExportHandler.checkDB, but different receiver type, so no collision.
// func (h *ExportIdentitiesHandler) checkDB(
// 	ctx context.Context, w http.ResponseWriter, name, value string,
// 	exists func(context.Context, string) (bool, error),
// 	list func(context.Context) ([]string, error),
// ) bool {
// 	if value == "" {
// 		return true
// 	}
// 	ok, err := exists(ctx, value)
// 	if err != nil {
// 		exportServerError(w, err)
// 		return false
// 	}
// 	if ok {
// 		return true
// 	}
// 	var valid []string
// 	if list != nil {
// 		valid, err = list(ctx)
// 		if err != nil {
// 			exportServerError(w, err)
// 			return false
// 		}
// 	}
// 	exportBadRequest(w, "invalid "+name+": '"+value+"' does not exist", valid)
// 	return false
// }

// func identityExportEmpty(w http.ResponseWriter, r *http.Request, total int, message string) {
// 	filters := make(map[string]string)
// 	q := r.URL.Query()
// 	for _, k := range identityFilterKeys {
// 		if v := strings.TrimSpace(q.Get(k)); v != "" {
// 			filters[k] = v
// 		}
// 	}
// 	if f := strings.TrimSpace(q.Get("format")); f != "" {
// 		filters["format"] = f
// 	}

// 	sendJSON(w, http.StatusOK, map[string]interface{}{
// 		"message": message,
// 		"total":   total,
// 		"data":    make([]interface{}, 0),
// 		"filters": filters,
// 	})
// }

// func (h *ExportIdentitiesHandler) Export(w http.ResponseWriter, r *http.Request) {
// 	ctx := r.Context()
// 	q := r.URL.Query()

// 	// ---- format ----
// 	format := strings.ToLower(strings.TrimSpace(q.Get("format")))
// 	if format == "" {
// 		format = "json"
// 	}
// 	if format != "json" && format != "csv" {
// 		exportBadRequest(w, "invalid format", []string{"csv", "json"})
// 		return
// 	}

// 	f := invmodels.ExportIdentityFilter{
// 		Format:          format,
// 		Search:          strings.TrimSpace(q.Get("search")),
// 		AccountID:       strings.TrimSpace(q.Get("account_id")),
// 		Region:          strings.TrimSpace(q.Get("region")),
// 		IdentityType:    strings.TrimSpace(q.Get("identity_type")),
// 		Status:          strings.TrimSpace(q.Get("status")),
// 		FunctionalClass: strings.TrimSpace(q.Get("functional_class")),
// 		Environment:     strings.TrimSpace(q.Get("environment")),
// 		Owner:           strings.TrimSpace(q.Get("owner")),
// 	}

// 	// ---- sorting ----
// 	f.SortBy = strings.ToLower(strings.TrimSpace(q.Get("sort_by")))
// 	if f.SortBy == "" {
// 		f.SortBy = "name"
// 	}
// 	validSort := false
// 	for _, s := range identitySortFields {
// 		if s == f.SortBy {
// 			validSort = true
// 			break
// 		}
// 	}
// 	if !validSort {
// 		exportBadRequest(w, "invalid sort_by", identitySortFields)
// 		return
// 	}
// 	f.SortOrder = strings.ToLower(strings.TrimSpace(q.Get("sort_order")))
// 	if f.SortOrder == "" {
// 		f.SortOrder = "asc"
// 	}
// 	if f.SortOrder != "asc" && f.SortOrder != "desc" {
// 		exportBadRequest(w, "invalid sort_order", []string{"asc", "desc"})
// 		return
// 	}

// 	// ---- page / limit ----
// 	var msg string
// 	if f.Limit, msg = exportOptInt(q, "limit", 1, maxExportLimit); msg != "" {
// 		exportBadRequest(w, msg, nil)
// 		return
// 	}
// 	if f.Page, msg = exportOptInt(q, "page", 1, maxExportPage); msg != "" {
// 		exportBadRequest(w, msg, nil)
// 		return
// 	}
// 	if f.Page != nil && f.Limit == nil {
// 		exportBadRequest(w, "page requires limit", nil)
// 		return
// 	}

// 	// ---- DB-driven validation ----
// 	if !h.checkDB(ctx, w, "account_id", f.AccountID, h.service.AccountIDExists, nil) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "region", f.Region, h.service.RegionExists, h.service.ListRegions) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "identity_type", f.IdentityType, h.service.IdentityTypeExists, h.service.ListIdentityTypes) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "status", f.Status, h.service.StatusExists, h.service.ListStatuses) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "functional_class", f.FunctionalClass, h.service.FunctionalClassExists, h.service.ListFunctionalClasses) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "environment", f.Environment, h.service.EnvironmentExists, h.service.ListEnvironments) {
// 		return
// 	}
// 	if !h.checkDB(ctx, w, "owner", f.Owner, h.service.OwnerExists, nil) {
// 		return
// 	}

// 	// ---- count first, so empty results get a proper message ----
// 	total, err := h.service.Count(ctx, f)
// 	if err != nil {
// 		exportServerError(w, err)
// 		return
// 	}
// 	if total == 0 {
// 		identityExportEmpty(w, r, 0, "no identities match the given filters")
// 		return
// 	}
// 	if f.Limit != nil {
// 		page := 1
// 		if f.Page != nil {
// 			page = *f.Page
// 		}
// 		if (page-1)*(*f.Limit) >= total {
// 			identityExportEmpty(w, r, total, fmt.Sprintf("page %d is beyond the last page (total matching: %d)", page, total))
// 			return
// 		}
// 	}

// 	// ---- stream the file ----
// 	started := false
// 	count := 0
// 	var csvW *csv.Writer
// 	flusher, _ := w.(http.Flusher)

// 	begin := func() {
// 		started = true
// 		filename := "identities_export_" + time.Now().UTC().Format("20060102_150405") + "." + format
// 		if format == "csv" {
// 			w.Header().Set("Content-Type", "text/csv; charset=utf-8")
// 		} else {
// 			w.Header().Set("Content-Type", "application/json; charset=utf-8")
// 		}
// 		w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
// 		w.Header().Set("Cache-Control", "no-store")
// 		w.Header().Set("X-Content-Type-Options", "nosniff")
// 		w.Header().Set("X-Total-Count", strconv.Itoa(total))
// 		w.WriteHeader(http.StatusOK)

// 		if format == "csv" {
// 			csvW = csv.NewWriter(w)
// 			_ = csvW.Write(identityCSVHeader)
// 		} else {
// 			_, _ = w.Write([]byte("[\n"))
// 		}
// 	}

// 	err = h.service.Stream(ctx, f, func(ident *invmodels.ExportIdentity) error {
// 		if !started {
// 			begin()
// 		}
// 		if format == "csv" {
// 			if err := csvW.Write(identityCSVRow(ident)); err != nil {
// 				return err
// 			}
// 		} else {
// 			b, err := json.Marshal(ident)
// 			if err != nil {
// 				return err
// 			}
// 			if count > 0 {
// 				if _, err := w.Write([]byte(",\n")); err != nil {
// 					return err
// 				}
// 			}
// 			if _, err := w.Write(b); err != nil {
// 				return err
// 			}
// 		}
// 		count++
// 		if count%500 == 0 {
// 			if csvW != nil {
// 				csvW.Flush()
// 			}
// 			if flusher != nil {
// 				flusher.Flush()
// 			}
// 		}
// 		return nil
// 	})

// 	if err != nil {
// 		if !started {
// 			exportServerError(w, err)
// 			return
// 		}
// 		log.Printf("identities export aborted after %d rows: %v", count, err)
// 		return
// 	}

// 	if !started {
// 		identityExportEmpty(w, r, 0, "no identities match the given filters")
// 		return
// 	}

// 	if format == "csv" {
// 		csvW.Flush()
// 	} else {
// 		_, _ = w.Write([]byte("\n]\n"))
// 	}
// 	if flusher != nil {
// 		flusher.Flush()
// 	}
// }

// // ---------- identity-specific CSV row builder (scalar helpers exportStr/exportBool/exportTime reused from credential_export.go) ----------

// func identityCSVRow(ident *invmodels.ExportIdentity) []string {
// 	return []string{
// 		ident.ID, ident.ARN, ident.Name, ident.IdentityType, ident.FunctionalClass,
// 		ident.AccountID, ident.Region, ident.Status,
// 		exportTime(ident.CreatedAtAWS), exportTime(ident.FirstSeenAt), exportTime(ident.LastSeenAt), exportTime(ident.LastActivityAt),
// 		exportStr(ident.Network.VpcID), exportStr(ident.Network.SubnetID), string(ident.Network.SecurityGroupIDs), exportBool(ident.Network.IsPubliclyAccessible),
// 		string(ident.Tags), exportStr(ident.Owner), exportStr(ident.Environment), exportStr(ident.ParentARN), exportStr(ident.CloudtrailCreatorARN),
// 		exportStr(ident.Discovery.DiscoverySource), exportStr(ident.Discovery.ScanID), string(ident.TypeAttributes), string(ident.RawAPIResponse),
// 		exportTime(ident.CreatedAt), exportTime(ident.UpdatedAt),
// 	}
// }

package inventory

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	invmodels "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

var identityExportSortFields = []string{
	"name", "identity_type", "functional_class", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at",
}

var identityExportCSVHeader = []string{
	"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at",
	"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible",
	"tags", "owner", "environment", "parent_arn", "cloudtrail_creator_arn",
	"discovery_source", "scan_id", "type_attributes", "raw_api_response",
	"created_at", "updated_at",
}

var identityExportFilterKeys = []string{
	"search", "account_id", "region", "identity_type", "status", "functional_class",
	"environment", "owner", "sort_by", "sort_order", "page", "limit",
}

type ExportIdentitiesHandler struct {
	service *svcinventory.ExportIdentitiesService
}

func NewExportIdentitiesHandler(service *svcinventory.ExportIdentitiesService) *ExportIdentitiesHandler {
	return &ExportIdentitiesHandler{service: service}
}

// checkDB — same name as CredentialExportHandler.checkDB, but different receiver type, so no collision.
func (h *ExportIdentitiesHandler) checkDB(
	ctx context.Context, w http.ResponseWriter, name, value string,
	exists func(context.Context, string) (bool, error),
	list func(context.Context) ([]string, error),
) bool {
	if value == "" {
		return true
	}
	ok, err := exists(ctx, value)
	if err != nil {
		exportServerError(w, err)
		return false
	}
	if ok {
		return true
	}
	var valid []string
	if list != nil {
		valid, err = list(ctx)
		if err != nil {
			exportServerError(w, err)
			return false
		}
	}
	exportBadRequest(w, "invalid "+name+": '"+value+"' does not exist", valid)
	return false
}

func identityExportEmptyResponse(w http.ResponseWriter, r *http.Request, total int, message string) {
	filters := make(map[string]string)
	q := r.URL.Query()
	for _, k := range identityExportFilterKeys {
		if v := strings.TrimSpace(q.Get(k)); v != "" {
			filters[k] = v
		}
	}
	if f := strings.TrimSpace(q.Get("format")); f != "" {
		filters["format"] = f
	}

	sendJSON(w, http.StatusOK, map[string]interface{}{
		"message": message,
		"total":   total,
		"data":    make([]interface{}, 0),
		"filters": filters,
	})
}

func (h *ExportIdentitiesHandler) Export(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	// ---- format ----
	format := strings.ToLower(strings.TrimSpace(q.Get("format")))
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "csv" {
		exportBadRequest(w, "invalid format", []string{"csv", "json"})
		return
	}

	f := invmodels.ExportIdentityFilter{
		Format:          format,
		Search:          strings.TrimSpace(q.Get("search")),
		AccountID:       strings.TrimSpace(q.Get("account_id")),
		Region:          strings.TrimSpace(q.Get("region")),
		IdentityType:    strings.TrimSpace(q.Get("identity_type")),
		Status:          strings.TrimSpace(q.Get("status")),
		FunctionalClass: strings.TrimSpace(q.Get("functional_class")),
		Environment:     strings.TrimSpace(q.Get("environment")),
		Owner:           strings.TrimSpace(q.Get("owner")),
	}

	// ---- sorting ----
	f.SortBy = strings.ToLower(strings.TrimSpace(q.Get("sort_by")))
	if f.SortBy == "" {
		f.SortBy = "name"
	}
	validSort := false
	for _, s := range identityExportSortFields {
		if s == f.SortBy {
			validSort = true
			break
		}
	}
	if !validSort {
		exportBadRequest(w, "invalid sort_by", identityExportSortFields)
		return
	}
	f.SortOrder = strings.ToLower(strings.TrimSpace(q.Get("sort_order")))
	if f.SortOrder == "" {
		f.SortOrder = "asc"
	}
	if f.SortOrder != "asc" && f.SortOrder != "desc" {
		exportBadRequest(w, "invalid sort_order", []string{"asc", "desc"})
		return
	}

	// ---- page / limit ----
	var msg string
	if f.Limit, msg = exportOptInt(q, "limit", 1, maxExportLimit); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.Page, msg = exportOptInt(q, "page", 1, maxExportPage); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.Page != nil && f.Limit == nil {
		exportBadRequest(w, "page requires limit", nil)
		return
	}

	// ---- DB-driven validation ----
	if !h.checkDB(ctx, w, "account_id", f.AccountID, h.service.AccountIDExists, nil) {
		return
	}
	if !h.checkDB(ctx, w, "region", f.Region, h.service.RegionExists, h.service.ListRegions) {
		return
	}
	if !h.checkDB(ctx, w, "identity_type", f.IdentityType, h.service.IdentityTypeExists, h.service.ListIdentityTypes) {
		return
	}
	if !h.checkDB(ctx, w, "status", f.Status, h.service.StatusExists, h.service.ListStatuses) {
		return
	}
	if !h.checkDB(ctx, w, "functional_class", f.FunctionalClass, h.service.FunctionalClassExists, h.service.ListFunctionalClasses) {
		return
	}
	if !h.checkDB(ctx, w, "environment", f.Environment, h.service.EnvironmentExists, h.service.ListEnvironments) {
		return
	}
	if !h.checkDB(ctx, w, "owner", f.Owner, h.service.OwnerExists, nil) {
		return
	}

	// ---- count first, so empty results get a proper message ----
	total, err := h.service.Count(ctx, f)
	if err != nil {
		exportServerError(w, err)
		return
	}
	if total == 0 {
		identityExportEmptyResponse(w, r, 0, "no identities match the given filters")
		return
	}
	if f.Limit != nil {
		page := 1
		if f.Page != nil {
			page = *f.Page
		}
		if (page-1)*(*f.Limit) >= total {
			identityExportEmptyResponse(w, r, total, fmt.Sprintf("page %d is beyond the last page (total matching: %d)", page, total))
			return
		}
	}

	// ---- stream the file ----
	started := false
	count := 0
	var csvW *csv.Writer
	flusher, _ := w.(http.Flusher)

	begin := func() {
		started = true
		filename := "identities_export_" + time.Now().UTC().Format("20060102_150405") + "." + format
		if format == "csv" {
			w.Header().Set("Content-Type", "text/csv; charset=utf-8")
		} else {
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
		}
		w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Total-Count", strconv.Itoa(total))
		w.WriteHeader(http.StatusOK)

		if format == "csv" {
			csvW = csv.NewWriter(w)
			_ = csvW.Write(identityExportCSVHeader)
		} else {
			_, _ = w.Write([]byte("[\n"))
		}
	}

	err = h.service.Stream(ctx, f, func(ident *invmodels.ExportIdentity) error {
		if !started {
			begin()
		}
		if format == "csv" {
			if err := csvW.Write(identityExportCSVRow(ident)); err != nil {
				return err
			}
		} else {
			b, err := json.Marshal(ident)
			if err != nil {
				return err
			}
			if count > 0 {
				if _, err := w.Write([]byte(",\n")); err != nil {
					return err
				}
			}
			if _, err := w.Write(b); err != nil {
				return err
			}
		}
		count++
		if count%500 == 0 {
			if csvW != nil {
				csvW.Flush()
			}
			if flusher != nil {
				flusher.Flush()
			}
		}
		return nil
	})

	if err != nil {
		if !started {
			exportServerError(w, err)
			return
		}
		log.Printf("identities export aborted after %d rows: %v", count, err)
		return
	}

	if !started {
		identityExportEmptyResponse(w, r, 0, "no identities match the given filters")
		return
	}

	if format == "csv" {
		csvW.Flush()
	} else {
		_, _ = w.Write([]byte("\n]\n"))
	}
	if flusher != nil {
		flusher.Flush()
	}
}

// ---------- identity-specific CSV row builder ----------
// scalar helpers exportStr/exportBool/exportTime are reused from credential export file.

func identityExportCSVRow(ident *invmodels.ExportIdentity) []string {
	return []string{
		ident.ID, ident.ARN, ident.Name, ident.IdentityType, ident.FunctionalClass,
		ident.AccountID, ident.Region, ident.Status,
		exportTime(ident.CreatedAtAWS), exportTime(ident.FirstSeenAt), exportTime(ident.LastSeenAt), exportTime(ident.LastActivityAt),
		exportStr(ident.Network.VpcID), exportStr(ident.Network.SubnetID), string(ident.Network.SecurityGroupIDs), exportBool(ident.Network.IsPubliclyAccessible),
		string(ident.Tags), exportStr(ident.Owner), exportStr(ident.Environment), exportStr(ident.ParentARN), exportStr(ident.CloudtrailCreatorARN),
		exportStr(ident.Discovery.DiscoverySource), exportStr(ident.Discovery.ScanID), string(ident.TypeAttributes), string(ident.RawAPIResponse),
		exportTime(ident.CreatedAt), exportTime(ident.UpdatedAt),
	}
}
