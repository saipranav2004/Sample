package inventory

import (
	"net/http"

	"github.com/gorilla/mux"
	svc "nhi-backend-api/internal/services/inventory"
)

type CredentialBoundIdentitiesHandler struct {
	service *svc.CredentialBoundIdentitiesService
	scope   CredentialListScope
}

func NewCredentialBoundIdentitiesHandler(service *svc.CredentialBoundIdentitiesService, scope CredentialListScope) *CredentialBoundIdentitiesHandler {
	return &CredentialBoundIdentitiesHandler{service: service, scope: scope}
}

func (h *CredentialBoundIdentitiesHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil {
		credentialAPIError(w, 503, "SOURCE_UNAVAILABLE", "Credential relationship source unavailable")
		return
	}
	id := mux.Vars(r)["id"]
	if !credentialAPIUUID.MatchString(id) {
		credentialAPIError(w, 400, "INVALID_ID", "Credential ID must be a UUID")
		return
	}
	ids, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	out, err := h.service.Get(r.Context(), id, ids)
	if err != nil {
		credentialAPIServiceError(w, err)
		return
	}
	credentialAPIOK(w, out)
}
