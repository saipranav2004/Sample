package inventory

import (
	"log"
	"net/http"

	svc "nhi-backend-api/internal/services/inventory"
)

type OrphanedCredentialsHandler struct {
	service *svc.OrphanedCredentialsService
	scope   CredentialListScope
}

func NewOrphanedCredentialsHandler(s *svc.OrphanedCredentialsService, scope CredentialListScope) *OrphanedCredentialsHandler {
	return &OrphanedCredentialsHandler{service: s, scope: scope}
}
func (h *OrphanedCredentialsHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil || h.service == nil {
		credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Orphaned credentials source unavailable")
		return
	}
	if _, ok := credentialAPIQuery(r); !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "This endpoint does not accept query parameters")
		return
	}
	allowed, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	out, err := h.service.Get(r.Context(), allowed)
	if err != nil {
		log.Printf("orphaned credentials failed: %T", err)
		credentialAPIError(w, 500, "INTERNAL_ERROR", "Unable to load orphaned credentials")
		return
	}
	credentialAPIOK(w, out)
}
