package inventory

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/gorilla/mux"
	m "nhi-backend-api/internal/models/inventory"
	svc "nhi-backend-api/internal/services/inventory"
)

var credentialPermissionServicePattern = regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`)

type CredentialEffectivePermissionsHandler struct {
	service *svc.CredentialEffectivePermissionsService
	scope   CredentialListScope
}

func NewCredentialEffectivePermissionsHandler(service *svc.CredentialEffectivePermissionsService, scope CredentialListScope) *CredentialEffectivePermissionsHandler {
	return &CredentialEffectivePermissionsHandler{service: service, scope: scope}
}
func (h *CredentialEffectivePermissionsHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil {
		credentialAPIError(w, 503, "SOURCE_UNAVAILABLE", "Credential permission source unavailable")
		return
	}
	id := mux.Vars(r)["id"]
	if !credentialAPIUUID.MatchString(id) {
		credentialAPIError(w, 400, "INVALID_ID", "Credential ID must be a UUID")
		return
	}
	q, ok := credentialAPIQuery(r, "effect", "service")
	if !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "Invalid or duplicate permission filter")
		return
	}
	effect, service := q.Get("effect"), q.Get("service")
	if effect != "" && effect != "Allow" && effect != "Deny" && !strings.EqualFold(effect, "allow") && !strings.EqualFold(effect, "deny") {
		credentialAPIError(w, 400, "INVALID_FILTER", "effect must be Allow or Deny")
		return
	}
	if service != "" && !credentialPermissionServicePattern.MatchString(service) {
		credentialAPIError(w, 400, "INVALID_FILTER", "Invalid service filter")
		return
	}
	ids, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	out, err := h.service.Get(r.Context(), id, ids, m.CredentialPermissionFilter{Effect: effect, Service: service})
	if err != nil {
		credentialAPIServiceError(w, err)
		return
	}
	credentialAPIOK(w, out)
}
