package inventory

import (
	"net/http"
	"strconv"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityDormantHandler struct {
	service *svcinventory.IdentityDormantService
}

func NewIdentityDormantHandler(service *svcinventory.IdentityDormantService) *IdentityDormantHandler {
	return &IdentityDormantHandler{service: service}
}

func (h *IdentityDormantHandler) Dormant(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	daysStr := query.Get("days")
	if daysStr == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request",
			Error:   "days is a required query parameter",
		})
		return
	}

	days, err := strconv.Atoi(daysStr)
	if err != nil || days <= 0 {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request",
			Error:   "days must be a positive integer",
		})
		return
	}

	page, _ := strconv.Atoi(query.Get("page"))
	limit, _ := strconv.Atoi(query.Get("limit"))

	filter := repoinventory.DormantIdentitiesFilter{
		Days:         days,
		IdentityType: query.Get("identity_type"),
		AccountID:    query.Get("account_id"),
		Page:         page,
		Limit:        limit,
	}

	result, err := h.service.List(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load dormant identities",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
