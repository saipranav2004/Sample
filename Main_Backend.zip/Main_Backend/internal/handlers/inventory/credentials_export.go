package inventory

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	invmodels "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

const (
	maxExportLimit = 100000
	maxExportPage  = 1000000
)

var exportSortFields = []string{
	"name", "credential_type", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_used_at",
	"expires_at", "privilege_level",
}

var exportCSVHeader = []string{
	"id", "arn", "name", "credential_type", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_used_at", "last_rotated_at", "expires_at",
	"rotation_enabled", "rotation_interval_days", "tags", "owner_principal_arn",
	"trust_policy", "attached_policies", "inline_policies", "permission_boundary_arn",
	"max_session_duration", "privilege_level", "assumable_role_arns",
	"type_attributes", "discovery_source", "scan_id",
}

var exportFilterKeys = []string{
	"search", "credential_type", "account_id", "region", "status", "rotation_enabled",
	"expiring_within_days", "stale_days", "privilege_level_min", "privilege_level_max",
	"owner_principal_arn", "sort_by", "sort_order", "page", "limit",
}

type CredentialExportHandler struct {
	service *svcinventory.CredentialExportService
}

func NewCredentialExportHandler(service *svcinventory.CredentialExportService) *CredentialExportHandler {
	return &CredentialExportHandler{service: service}
}

func exportBadRequest(w http.ResponseWriter, msg string, valid []string) {
	body := map[string]interface{}{"error": msg}
	if valid != nil {
		body["valid_values"] = valid
	}
	sendJSON(w, http.StatusBadRequest, body)
}

func exportServerError(w http.ResponseWriter, err error) {
	log.Printf("credentials export error: %v", err)
	sendJSON(w, http.StatusInternalServerError, map[string]interface{}{"error": "internal server error"})
}

// exportOptInt returns (nil,"") when absent, or an error message when invalid.
func exportOptInt(q map[string][]string, key string, min, max int) (*int, string) {
	vals, ok := q[key]
	if !ok || strings.TrimSpace(vals[0]) == "" {
		return nil, ""
	}
	n, err := strconv.Atoi(strings.TrimSpace(vals[0]))
	if err != nil || n < min || n > max {
		return nil, key + " must be an integer between " + strconv.Itoa(min) + " and " + strconv.Itoa(max)
	}
	return &n, ""
}

// checkDB validates a value against the DB; returns false after writing a 400/500 response.
func (h *CredentialExportHandler) checkDB(
	ctx context.Context, w http.ResponseWriter, name, value string,
	exists func(context.Context, string) (bool, error),
	list func(context.Context) ([]string, error),
) bool {
	if value == "" {
		return true
	}
	ok, err := exists(ctx, value)
	if err != nil {
		exportServerError(w, err)
		return false
	}
	if ok {
		return true
	}
	var valid []string
	if list != nil {
		valid, err = list(ctx)
		if err != nil {
			exportServerError(w, err)
			return false
		}
	}
	exportBadRequest(w, "invalid "+name+": '"+value+"' does not exist", valid)
	return false
}

// exportEmpty writes the JSON "nothing to export" response.
func exportEmpty(w http.ResponseWriter, r *http.Request, total int, message string) {
	filters := make(map[string]string)
	q := r.URL.Query()
	for _, k := range exportFilterKeys {
		if v := strings.TrimSpace(q.Get(k)); v != "" {
			filters[k] = v
		}
	}
	if f := strings.TrimSpace(q.Get("format")); f != "" {
		filters["format"] = f
	}

	sendJSON(w, http.StatusOK, map[string]interface{}{
		"message": message,
		"total":   total,
		"data":    make([]interface{}, 0),
		"filters": filters,
	})
}

func (h *CredentialExportHandler) Export(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	q := r.URL.Query()

	// ---- format ----
	format := strings.ToLower(strings.TrimSpace(q.Get("format")))
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "csv" {
		exportBadRequest(w, "invalid format", []string{"csv", "json"})
		return
	}

	f := invmodels.ExportCredentialFilter{
		Format:            format,
		Search:            strings.TrimSpace(q.Get("search")),
		CredentialType:    strings.TrimSpace(q.Get("credential_type")),
		AccountID:         strings.TrimSpace(q.Get("account_id")),
		Region:            strings.TrimSpace(q.Get("region")),
		Status:            strings.TrimSpace(q.Get("status")),
		OwnerPrincipalARN: strings.TrimSpace(q.Get("owner_principal_arn")),
	}

	// ---- sorting ----
	f.SortBy = strings.ToLower(strings.TrimSpace(q.Get("sort_by")))
	if f.SortBy == "" {
		f.SortBy = "name"
	}
	validSort := false
	for _, s := range exportSortFields {
		if s == f.SortBy {
			validSort = true
			break
		}
	}
	if !validSort {
		exportBadRequest(w, "invalid sort_by", exportSortFields)
		return
	}
	f.SortOrder = strings.ToLower(strings.TrimSpace(q.Get("sort_order")))
	if f.SortOrder == "" {
		f.SortOrder = "asc"
	}
	if f.SortOrder != "asc" && f.SortOrder != "desc" {
		exportBadRequest(w, "invalid sort_order", []string{"asc", "desc"})
		return
	}

	// ---- rotation_enabled ----
	if v := strings.TrimSpace(q.Get("rotation_enabled")); v != "" {
		b, err := strconv.ParseBool(v)
		if err != nil {
			exportBadRequest(w, "rotation_enabled must be true or false", []string{"true", "false"})
			return
		}
		f.RotationEnabled = &b
	}

	// ---- integers ----
	var msg string
	if f.ExpiringWithinDays, msg = exportOptInt(q, "expiring_within_days", 1, 36500); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.StaleDays, msg = exportOptInt(q, "stale_days", 1, 36500); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.PrivilegeLevelMin, msg = exportOptInt(q, "privilege_level_min", 0, 10); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.PrivilegeLevelMax, msg = exportOptInt(q, "privilege_level_max", 0, 10); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.PrivilegeLevelMin != nil && f.PrivilegeLevelMax != nil && *f.PrivilegeLevelMin > *f.PrivilegeLevelMax {
		exportBadRequest(w, "privilege_level_min cannot be greater than privilege_level_max", nil)
		return
	}

	// ---- page / limit ----
	if f.Limit, msg = exportOptInt(q, "limit", 1, maxExportLimit); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.Page, msg = exportOptInt(q, "page", 1, maxExportPage); msg != "" {
		exportBadRequest(w, msg, nil)
		return
	}
	if f.Page != nil && f.Limit == nil {
		exportBadRequest(w, "page requires limit", nil)
		return
	}

	// ---- DB-driven validation ----
	if !h.checkDB(ctx, w, "credential_type", f.CredentialType, h.service.CredentialTypeExists, h.service.ListCredentialTypes) {
		return
	}
	if !h.checkDB(ctx, w, "account_id", f.AccountID, h.service.AccountIDExists, nil) {
		return
	}
	if !h.checkDB(ctx, w, "region", f.Region, h.service.RegionExists, h.service.ListRegions) {
		return
	}
	if !h.checkDB(ctx, w, "status", f.Status, h.service.StatusExists, h.service.ListStatuses) {
		return
	}

	// ---- count first, so empty results get a proper message ----
	total, err := h.service.Count(ctx, f)
	if err != nil {
		exportServerError(w, err)
		return
	}
	if total == 0 {
		exportEmpty(w, r, 0, "no credentials match the given filters")
		return
	}
	if f.Limit != nil {
		page := 1
		if f.Page != nil {
			page = *f.Page
		}
		if (page-1)*(*f.Limit) >= total {
			exportEmpty(w, r, total, fmt.Sprintf("page %d is beyond the last page (total matching: %d)", page, total))
			return
		}
	}

	// ---- stream the file ----
	started := false
	count := 0
	var csvW *csv.Writer
	flusher, _ := w.(http.Flusher)

	begin := func() {
		started = true
		filename := "credentials_export_" + time.Now().UTC().Format("20060102_150405") + "." + format
		if format == "csv" {
			w.Header().Set("Content-Type", "text/csv; charset=utf-8")
		} else {
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
		}
		w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Total-Count", strconv.Itoa(total))
		w.WriteHeader(http.StatusOK)

		if format == "csv" {
			csvW = csv.NewWriter(w)
			_ = csvW.Write(exportCSVHeader)
		} else {
			_, _ = w.Write([]byte("[\n"))
		}
	}

	err = h.service.Stream(ctx, f, func(c *invmodels.ExportCredential) error {
		if !started {
			begin()
		}
		if format == "csv" {
			if err := csvW.Write(exportCSVRow(c)); err != nil {
				return err
			}
		} else {
			b, err := json.Marshal(c)
			if err != nil {
				return err
			}
			if count > 0 {
				if _, err := w.Write([]byte(",\n")); err != nil {
					return err
				}
			}
			if _, err := w.Write(b); err != nil {
				return err
			}
		}
		count++
		if count%500 == 0 {
			if csvW != nil {
				csvW.Flush()
			}
			if flusher != nil {
				flusher.Flush()
			}
		}
		return nil
	})

	if err != nil {
		if !started {
			exportServerError(w, err)
			return
		}
		log.Printf("credentials export aborted after %d rows: %v", count, err)
		return
	}

	if !started {
		// rows disappeared between COUNT and SELECT (data changed mid-request)
		exportEmpty(w, r, 0, "no credentials match the given filters")
		return
	}

	if format == "csv" {
		csvW.Flush()
	} else {
		_, _ = w.Write([]byte("\n]\n"))
	}
	if flusher != nil {
		flusher.Flush()
	}
}

// ---------- CSV helpers ----------

func exportStr(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}
func exportInt(p *int) string {
	if p == nil {
		return ""
	}
	return strconv.Itoa(*p)
}
func exportBool(p *bool) string {
	if p == nil {
		return ""
	}
	return strconv.FormatBool(*p)
}
func exportTime(p *time.Time) string {
	if p == nil {
		return ""
	}
	return p.UTC().Format(time.RFC3339)
}

func exportCSVRow(c *invmodels.ExportCredential) []string {
	return []string{
		c.ID, c.ARN, c.Name, c.CredentialType, c.AccountID, c.Region, c.Status,
		exportTime(c.CreatedAtAWS), exportTime(c.FirstSeenAt), exportTime(c.LastSeenAt),
		exportTime(c.LastUsedAt), exportTime(c.LastRotatedAt), exportTime(c.ExpiresAt),
		exportBool(c.RotationEnabled), exportInt(c.RotationIntervalDays),
		string(c.Tags), exportStr(c.OwnerPrincipalARN),
		string(c.IAMRoleDetails.TrustPolicy),
		string(c.IAMRoleDetails.AttachedPolicies),
		string(c.IAMRoleDetails.InlinePolicies),
		exportStr(c.IAMRoleDetails.PermissionBoundaryARN),
		exportInt(c.IAMRoleDetails.MaxSessionDuration),
		exportInt(c.IAMRoleDetails.PrivilegeLevel),
		string(c.IAMRoleDetails.AssumableRoleARNs),
		string(c.TypeAttributes),
		exportStr(c.Discovery.DiscoverySource), exportStr(c.Discovery.ScanID),
	}
}
