package inventory

import (
	"net/http"
	"strconv"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type SearchHandler struct {
	service *svcinventory.SearchService
}

func NewSearchHandler(service *svcinventory.SearchService) *SearchHandler {
	return &SearchHandler{service: service}
}

var validEntityTypes = map[string]bool{
	"identities":  true,
	"credentials": true,
	"both":        true,
}

func (h *SearchHandler) Search(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	q := query.Get("q")
	if q == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request",
			Error:   "q is a required query parameter",
		})
		return
	}

	entityType := query.Get("entity_type")
	if entityType == "" {
		entityType = "both"
	}
	if !validEntityTypes[entityType] {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request",
			Error:   "entity_type must be one of: identities, credentials, both",
		})
		return
	}

	limit := 20
	if limitStr := query.Get("limit"); limitStr != "" {
		if parsed, err := strconv.Atoi(limitStr); err == nil && parsed > 0 {
			limit = parsed
		}
	}

	filter := repoinventory.GlobalSearchFilter{
		Query:      q,
		EntityType: entityType,
		Limit:      limit,
	}

	result, err := h.service.Search(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to perform search",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
