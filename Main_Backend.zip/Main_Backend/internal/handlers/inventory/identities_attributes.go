package inventory

import (
	"errors"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/models"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityAttributesHandler struct {
	service *svcinventory.IdentityAttributesService
}

func NewIdentityAttributesHandler(service *svcinventory.IdentityAttributesService) *IdentityAttributesHandler {
	return &IdentityAttributesHandler{service: service}
}

func (h *IdentityAttributesHandler) Attributes(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]

	if !isValidIdentityUUID(id) {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid id",
			Error:   "id must be a valid UUID",
		})
		return
	}

	result, err := h.service.Attributes(r.Context(), id)
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityNotFound) {
			sendJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false,
				Message: "identity not found",
				Error:   "no identity exists with the given id",
			})
			return
		}
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity attributes",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
