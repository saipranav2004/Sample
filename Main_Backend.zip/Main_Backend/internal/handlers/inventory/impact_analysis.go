package inventory

import (
	"errors"
	"log"
	"net/http"

	"github.com/gorilla/mux"
	svc "nhi-backend-api/internal/services/inventory"
)

type ImpactAnalysisHandler struct {
	service *svc.ImpactAnalysisService
	scope   CredentialListScope
}

func NewImpactAnalysisHandler(s *svc.ImpactAnalysisService, scope CredentialListScope) *ImpactAnalysisHandler {
	return &ImpactAnalysisHandler{service: s, scope: scope}
}
func (h *ImpactAnalysisHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil || h.service == nil {
		credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Impact analysis source unavailable")
		return
	}
	if _, ok := credentialAPIQuery(r); !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "This endpoint does not accept query parameters")
		return
	}
	allowed, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	v := mux.Vars(r)
	entityType, id := v["entity_type"], v["id"]
	out, err := h.service.Analyze(r.Context(), entityType, id, allowed)
	if err != nil {
		switch {
		case errors.Is(err, svc.ErrImpactAnalysisInvalid):
			credentialAPIError(w, 400, "INVALID_ENTITY", "Invalid entity type or ID")
		case errors.Is(err, svc.ErrImpactAnalysisNotFound):
			credentialAPIError(w, 404, "NOT_FOUND", "Entity not found in the latest scan")
		case errors.Is(err, svc.ErrImpactAnalysisUnavailable):
			credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Impact analysis source unavailable")
		default:
			log.Printf("impact analysis failed: %T", err)
			credentialAPIError(w, 500, "INTERNAL_ERROR", "Unable to analyze entity impact")
		}
		return
	}
	credentialAPIOK(w, out)
}
