package inventory

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/gorilla/mux"
	"nhi-backend-api/internal/models"
	modelsinventory "nhi-backend-api/internal/models/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type UpdateCredentialHandler struct {
	service *svcinventory.UpdateCredentialService
}

func NewUpdateCredentialHandler(
	service *svcinventory.UpdateCredentialService,
) *UpdateCredentialHandler {
	return &UpdateCredentialHandler{service: service}
}

// UpdateCredential handles PATCH /api/v1/inventory/credentials/{id}
//
// Body:
//
//	{
//	  "owner_principal_arn": "arn:aws:iam::123:user/alice",
//	  "tags": {"owner": "alice"}
//	}
func (h *UpdateCredentialHandler) UpdateCredential(
	w http.ResponseWriter,
	r *http.Request,
) {
	// ── Get id from URL ───────────────────────────────────────────────────────
	vars := mux.Vars(r)
	id := strings.TrimSpace(vars["id"])
	if id == "" {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "id is required",
			Error:   "id is required",
		})
		return
	}

	// ── Decode request body ───────────────────────────────────────────────────
	var req modelsinventory.UpdateCredentialRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "invalid request body",
			Error:   err.Error(),
		})
		return
	}

	// ── Validate at least one field is provided ───────────────────────────────
	if req.OwnerPrincipalARN == nil && req.Tags == nil {
		sendJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false,
			Message: "at least one field must be provided: owner_principal_arn, tags",
			Error:   "at least one field must be provided: owner_principal_arn, tags",
		})
		return
	}

	// ── Call service ──────────────────────────────────────────────────────────
	result, err := h.service.UpdateCredential(r.Context(), id, req)
	if err != nil {
		if strings.Contains(err.Error(), "no rows") {
			sendJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false,
				Message: "Credential not found",
				Error:   err.Error(),
			})
			return
		}
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to update credential",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
