package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"

	"github.com/lib/pq"
	"nhi-backend-api/internal/middleware"
	svc "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
)

type CredentialListScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}

type CredentialAccountIDReader interface {
	AllKnownAccountIDs(context.Context) ([]string, error)
}

type CredentialAllAccountsScope struct{ reader CredentialAccountIDReader }

func NewCredentialAllAccountsScope(reader CredentialAccountIDReader) *CredentialAllAccountsScope {
	return &CredentialAllAccountsScope{reader: reader}
}

func (s *CredentialAllAccountsScope) AllowedAccountIDs(ctx context.Context, claims *appjwt.CustomClaims) ([]string, error) {
	if s == nil || s.reader == nil || claims == nil || claims.UserID <= 0 {
		return nil, errors.New("authenticated account scope unavailable")
	}
	return s.reader.AllKnownAccountIDs(ctx)
}

var credentialAPIUUID = regexp.MustCompile(`(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$`)

type credentialAPIErrorEnvelope struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func credentialAPIError(w http.ResponseWriter, status int, code, message string) {
	var out credentialAPIErrorEnvelope
	out.Error.Code, out.Error.Message = code, message
	b, _ := json.Marshal(out)
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_, _ = w.Write(append(b, '\n'))
}

func credentialAPIOK(w http.ResponseWriter, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("C1-C4 response encoding failed: %T", err)
		credentialAPIError(w, 500, "INTERNAL_ERROR", "Unable to encode credential response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(append(b, '\n'))
}

func credentialFeatureAccounts(w http.ResponseWriter, r *http.Request, scope CredentialListScope, configured bool) ([]string, bool) {
	if scope == nil || !configured {
		credentialAPIError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	claims := middleware.GetClaims(r)
	if claims == nil {
		credentialAPIError(w, 401, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	ids, err := scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil || len(ids) == 0 {
		log.Printf("C1-C4 account scope unavailable: %T", err)
		credentialAPIError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	return ids, true
}

func credentialAPIQuery(r *http.Request, allowed ...string) (url.Values, bool) {
	q, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allow := make(map[string]bool, len(allowed))
	for _, k := range allowed {
		allow[k] = true
	}
	for k, vals := range q {
		if !allow[k] || len(vals) != 1 {
			return nil, false
		}
	}
	return q, true
}

func credentialAPIParseInt(v string, def, min, max int) (int, bool) {
	if v == "" {
		return def, true
	}
	n, err := strconv.Atoi(v)
	return n, err == nil && n >= min && n <= max
}

func credentialAPIServiceError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, svc.ErrCredentialAPINotFound), errors.Is(err, sql.ErrNoRows):
		credentialAPIError(w, 404, "NOT_FOUND", "Credential not found")
	case errors.Is(err, svc.ErrCredentialAPIUnavailable):
		credentialAPIError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Credential inventory source unavailable")
	case errors.Is(err, svc.ErrCredentialAPIIncomplete):
		credentialAPIError(w, 503, "DATA_SOURCE_INCOMPLETE", "Credential inventory data is incomplete")
	case errors.Is(err, svc.ErrCredentialAPIInvalid):
		credentialAPIError(w, 400, "INVALID_FILTER", "Invalid credential filters")
	default:
		var pe *pq.Error
		if errors.As(err, &pe) {
			log.Printf("C1-C4 database error sqlstate=%s", string(pe.Code))
		} else {
			log.Printf("C1-C4 internal error type=%T", err)
		}
		credentialAPIError(w, 500, "INTERNAL_ERROR", "Unable to load credential data")
	}
}
