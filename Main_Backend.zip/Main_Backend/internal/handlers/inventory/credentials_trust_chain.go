package inventory

import (
	"github.com/gorilla/mux"
	"net/http"
	svc "nhi-backend-api/internal/services/inventory"
)

type CredentialTrustChainHandler struct {
	service *svc.CredentialTrustChainService
	scope   CredentialListScope
}

func NewCredentialTrustChainHandler(service *svc.CredentialTrustChainService, scope CredentialListScope) *CredentialTrustChainHandler {
	return &CredentialTrustChainHandler{service: service, scope: scope}
}
func (h *CredentialTrustChainHandler) Get(w http.ResponseWriter, r *http.Request) {
	if h == nil {
		credentialAPIError(w, 503, "SOURCE_UNAVAILABLE", "Credential trust source unavailable")
		return
	}
	id := mux.Vars(r)["id"]
	if !credentialAPIUUID.MatchString(id) {
		credentialAPIError(w, 400, "INVALID_ID", "Credential ID must be a UUID")
		return
	}
	if _, ok := credentialAPIQuery(r); !ok {
		credentialAPIError(w, 400, "INVALID_FILTER", "Trust-chain endpoint accepts no query parameters")
		return
	}
	ids, ok := credentialFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok {
		return
	}
	out, err := h.service.Get(r.Context(), id, ids)
	if err != nil {
		credentialAPIServiceError(w, err)
		return
	}
	credentialAPIOK(w, out)
}
