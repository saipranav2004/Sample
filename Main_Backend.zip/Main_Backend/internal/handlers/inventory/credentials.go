package inventory

import (
	"encoding/json"
	"net/http"
	"strconv"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	inventorysvc "nhi-backend-api/internal/services/inventory"
)

// CredentialHandler handles HTTP requests for the credentials inventory.
type CredentialHandler struct {
	service *inventorysvc.CredentialService
}

func NewCredentialHandler(service *inventorysvc.CredentialService) *CredentialHandler {
	return &CredentialHandler{service: service}
}

// List handles GET /api/v1/inventory/credentials
func (h *CredentialHandler) List(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	f := inventorymodels.CredentialFilter{
		Page:              parseIntDefault(q.Get("page"), 1),
		Limit:             parseIntDefault(q.Get("limit"), 50),
		SortBy:            q.Get("sort_by"),
		SortOrder:         q.Get("sort_order"),
		Search:            q.Get("search"),
		CredentialType:    q.Get("credential_type"),
		AccountID:         q.Get("account_id"),
		Region:            q.Get("region"),
		Status:            q.Get("status"),
		OwnerPrincipalARN: q.Get("owner_principal_arn"),
	}

	// rotation_enabled — optional boolean
	if v := q.Get("rotation_enabled"); v != "" {
		b, err := strconv.ParseBool(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "rotation_enabled must be true or false",
			})
			return
		}
		f.RotationEnabled = &b
	}

	// expiring_within_days — optional int
	if v := q.Get("expiring_within_days"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "expiring_within_days must be a non-negative integer",
			})
			return
		}
		f.ExpiringWithinDays = &n
	}

	// stale_days — optional int
	if v := q.Get("stale_days"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "stale_days must be a non-negative integer",
			})
			return
		}
		f.StaleDays = &n
	}

	// privilege_level_min — optional int
	if v := q.Get("privilege_level_min"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "privilege_level_min must be an integer",
			})
			return
		}
		f.PrivilegeLevelMin = &n
	}

	// privilege_level_max — optional int
	if v := q.Get("privilege_level_max"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil {
			sendJSON(w, http.StatusBadRequest, map[string]interface{}{
				"success": false,
				"message": "privilege_level_max must be an integer",
			})
			return
		}
		f.PrivilegeLevelMax = &n
	}

	result, err := h.service.List(r.Context(), f)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Failed to fetch credentials",
			"error":   err.Error(),
		})
		return
	}

	// Always return the envelope; data is [] when empty (never null).
	sendJSON(w, http.StatusOK, result)
}

// ── helpers ───────────────────────────────────────────────────────────────────

func sendJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func parseIntDefault(s string, def int) int {
	if s == "" {
		return def
	}
	n, err := strconv.Atoi(s)
	if err != nil || n < 1 {
		return def
	}
	return n
}
