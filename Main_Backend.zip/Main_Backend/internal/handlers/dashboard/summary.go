package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type SummaryHandler struct {
	service *svcdashboard.SummaryService
}

func NewSummaryHandler(service *svcdashboard.SummaryService) *SummaryHandler {
	return &SummaryHandler{service: service}
}

func (h *SummaryHandler) Summary(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	filter := repodashboard.SummaryFilter{
		AccountID: query.Get("account_id"),
		Region:    query.Get("region"),
	}

	result, err := h.service.Summary(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load dashboard summary",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
