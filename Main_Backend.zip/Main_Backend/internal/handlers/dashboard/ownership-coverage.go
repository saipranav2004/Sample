package dashboard

import (
	"net/http"
	"strings"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type OwnershipCoverageHandler struct {
	service *svcdashboard.OwnershipCoverageService
}

func NewOwnershipCoverageHandler(service *svcdashboard.OwnershipCoverageService) *OwnershipCoverageHandler {
	return &OwnershipCoverageHandler{service: service}
}

// OwnershipCoverage handles GET /dashboard/ownership-coverage
//
// Query params (all optional):
//
//	account_id – filter to a single AWS account
//	entity     – identities | credentials | both (default both)
func (h *OwnershipCoverageHandler) OwnershipCoverage(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	filter := repodashboard.OwnershipCoverageFilter{
		AccountID: strings.TrimSpace(q.Get("account_id")),
		Entity:    repodashboard.OwnershipEntityBoth,
	}

	if v := strings.ToLower(strings.TrimSpace(q.Get("entity"))); v != "" {
		switch v {
		case repodashboard.OwnershipEntityIdentities, repodashboard.OwnershipEntityCredentials, repodashboard.OwnershipEntityBoth:
			filter.Entity = v
		default:
			badRequest(w, "entity must be one of: identities, credentials, both")
			return
		}
	}

	result, err := h.service.GetOwnershipCoverage(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load ownership coverage",
			Error:   err.Error(),
		})
		return
	}

	// Returned without the success/data envelope, exactly as in the API document.
	sendJSON(w, http.StatusOK, result)
}
