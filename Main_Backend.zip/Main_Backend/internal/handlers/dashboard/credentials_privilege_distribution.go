package dashboard

import (
	"net/http"
	"strings"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type PrivilegeDistributionHandler struct {
	service *svcdashboard.PrivilegeDistributionService
}

func NewPrivilegeDistributionHandler(service *svcdashboard.PrivilegeDistributionService) *PrivilegeDistributionHandler {
	return &PrivilegeDistributionHandler{service: service}
}

// PrivilegeDistribution handles GET /dashboard/credentials/privilege-distribution
//
// Query params (optional):
//
//	account_id – filter to a single AWS account
func (h *PrivilegeDistributionHandler) PrivilegeDistribution(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	filter := repodashboard.PrivilegeDistributionFilter{
		AccountID: strings.TrimSpace(q.Get("account_id")),
	}

	result, err := h.service.GetPrivilegeDistribution(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load privilege distribution",
			Error:   err.Error(),
		})
		return
	}

	// Returned without the success/data envelope, exactly as in the API document.
	sendJSON(w, http.StatusOK, result)
}
