// package dashboard

// import (
// 	"net/http"

// 	"nhi-backend-api/internal/models"
// 	repodashboard "nhi-backend-api/internal/repository/dashboard"
// 	svcdashboard "nhi-backend-api/internal/services/dashboard"
// )

// type IdentitiesByRegionHandler struct {
// 	service *svcdashboard.IdentitiesByRegionService
// }

// func NewIdentitiesByRegionHandler(service *svcdashboard.IdentitiesByRegionService) *IdentitiesByRegionHandler {
// 	return &IdentitiesByRegionHandler{service: service}
// }

// func (h *IdentitiesByRegionHandler) ByRegion(w http.ResponseWriter, r *http.Request) {
// 	query := r.URL.Query()

// 	filter := repodashboard.IdentitiesByRegionFilter{
// 		AccountID:    query.Get("account_id"),
// 		IdentityType: query.Get("identity_type"),
// 	}

// 	result, err := h.service.Breakdown(r.Context(), filter)
// 	if err != nil {
// 		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
// 			Success: false,
// 			Message: "failed to load identity breakdown by region",
// 			Error:   err.Error(),
// 		})
// 		return
// 	}

// 	sendJSON(w, http.StatusOK, result)
// }

package dashboard

import (
	"errors"
	"net/http"
	"strings"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type IdentitiesByRegionHandler struct {
	service *svcdashboard.IdentitiesByRegionService
}

func NewIdentitiesByRegionHandler(service *svcdashboard.IdentitiesByRegionService) *IdentitiesByRegionHandler {
	return &IdentitiesByRegionHandler{service: service}
}

func (h *IdentitiesByRegionHandler) ByRegion(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	filter := repodashboard.IdentitiesByRegionFilter{
		AccountID:    strings.TrimSpace(query.Get("account_id")),
		IdentityType: strings.TrimSpace(query.Get("identity_type")),
	}

	result, err := h.service.Breakdown(r.Context(), filter)
	if err != nil {
		if errors.Is(err, svcdashboard.ErrInvalidIdentityType) {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false,
				Message: "invalid identity_type: no identities found with this type",
				Error:   err.Error(),
			})
			return
		}
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load identity breakdown by region",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
