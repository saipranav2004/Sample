package credentialexposure

import (
	"errors"
	"net/http"
	"strconv"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	r "nhi-backend-api/internal/repository/Credential_Exposure"
	s "nhi-backend-api/internal/services/Credential_Exposure"
)

type FindingsHandler struct{ service *s.FindingsService }

func NewFindingsHandler(service *s.FindingsService) *FindingsHandler {
	return &FindingsHandler{service: service}
}

func (h *FindingsHandler) List(w http.ResponseWriter, rq *http.Request)        { h.list(w, rq, false) }
func (h *FindingsHandler) ListFlagged(w http.ResponseWriter, rq *http.Request) { h.list(w, rq, true) }
func (h *FindingsHandler) list(w http.ResponseWriter, rq *http.Request, forceFlagged bool) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	q := rq.URL.Query()
	allowed := map[string]bool{"client_id": true, "platform": true, "ml_flagged": true, "limit": true, "offset": true, "finding_id": true}
	for k, vs := range q {
		if !allowed[k] || len(vs) != 1 {
			writeError(w, 400, "INVALID_QUERY", "Unsupported or repeated query parameter: "+k)
			return
		}
	}
	if values, hasID := q["finding_id"]; hasID {
		id := strings.TrimSpace(values[0])
		if len(q) != 1 || id == "" || len(id) > 1000 {
			writeError(w, 400, "INVALID_QUERY", "finding_id must be the only query parameter and must not exceed 1000 characters")
			return
		}
		item, err := h.service.Get(rq.Context(), id)
		if err != nil {
			switch {
			case errors.Is(err, r.ErrFindingNotFound):
				writeError(w, 404, "NOT_FOUND", "Finding not found")
			case errors.Is(err, r.ErrFindingAmbiguous):
				writeError(w, 409, "AMBIGUOUS_FINDING", "Finding ID matched more than one platform table")
			default:
				writeError(w, 500, "INTERNAL_ERROR", "Unable to load finding")
			}
			return
		}
		writeJSON(w, 200, item)
		return
	}
	filter := m.FindingsFilter{ClientID: strings.TrimSpace(q.Get("client_id")), Platform: strings.TrimSpace(q.Get("platform")), Limit: 200, MLFlagged: forceFlagged}
	if len(filter.ClientID) > 200 {
		writeError(w, 400, "INVALID_QUERY", "client_id exceeds 200 characters")
		return
	}
	if raw := q.Get("ml_flagged"); raw != "" && !forceFlagged {
		v, err := strconv.ParseBool(raw)
		if err != nil {
			writeError(w, 400, "INVALID_QUERY", "ml_flagged must be true or false")
			return
		}
		filter.MLFlagged = v
	}
	if raw := q.Get("limit"); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 || v > 500 {
			writeError(w, 400, "INVALID_QUERY", "limit must be between 1 and 500")
			return
		}
		filter.Limit = v
	}
	if raw := q.Get("offset"); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 0 {
			writeError(w, 400, "INVALID_QUERY", "offset must be a non-negative integer")
			return
		}
		filter.Offset = v
	}
	items, count, err := h.service.List(rq.Context(), filter)
	if err != nil {
		if strings.Contains(err.Error(), "platform must") {
			writeError(w, 400, "INVALID_QUERY", err.Error())
		} else {
			writeError(w, 500, "INTERNAL_ERROR", "Unable to load findings")
		}
		return
	}
	writeJSON(w, 200, m.FindingsResponse{Count: count, Findings: items, Limit: filter.Limit, Offset: filter.Offset})
}
