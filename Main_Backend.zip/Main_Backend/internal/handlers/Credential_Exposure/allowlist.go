package credentialexposure

import (
	"net/http"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	s "nhi-backend-api/internal/services/Credential_Exposure"
)

type AllowlistHandler struct{ service *s.AllowlistService }

func NewAllowlistHandler(service *s.AllowlistService) *AllowlistHandler {
	return &AllowlistHandler{service: service}
}
func (h *AllowlistHandler) List(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	q := rq.URL.Query()
	for k, v := range q {
		if k != "client_id" || len(v) != 1 {
			writeError(w, 400, "INVALID_QUERY", "Only one client_id query parameter is supported")
			return
		}
	}
	id := strings.TrimSpace(q.Get("client_id"))
	if len(id) > 200 {
		writeError(w, 400, "INVALID_QUERY", "client_id exceeds 200 characters")
		return
	}
	entries, err := h.service.List(rq.Context(), id)
	if err != nil {
		writeError(w, 500, "INTERNAL_ERROR", "Unable to load allowlist")
		return
	}
	writeJSON(w, 200, m.AllowlistListResponse{Entries: entries})
}
func (h *AllowlistHandler) Create(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	var req m.AllowlistRequest
	if !decodeJSONBody(w, rq, &req) {
		return
	}
	entry, err := h.service.Upsert(rq.Context(), req)
	if err != nil {
		writeError(w, 400, "INVALID_ALLOWLIST_ENTRY", err.Error())
		return
	}
	writeJSON(w, 200, map[string]any{"ok": true, "entry": entry})
}
func (h *AllowlistHandler) Delete(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	var req m.AllowlistRequest
	if !decodeJSONBody(w, rq, &req) {
		return
	}
	ok, err := h.service.Delete(rq.Context(), req)
	if err != nil {
		writeError(w, 400, "INVALID_ALLOWLIST_ENTRY", err.Error())
		return
	}
	writeJSON(w, 200, m.OKResponse{OK: ok})
}
