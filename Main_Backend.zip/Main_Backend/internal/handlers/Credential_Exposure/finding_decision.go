package credentialexposure

import (
	"errors"
	"net/http"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	r "nhi-backend-api/internal/repository/Credential_Exposure"
	s "nhi-backend-api/internal/services/Credential_Exposure"
)

type DecisionHandler struct{ service *s.DecisionService }

func NewDecisionHandler(service *s.DecisionService) *DecisionHandler {
	return &DecisionHandler{service: service}
}
func (h *DecisionHandler) Save(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	var req m.FindingDecisionRequest
	if !decodeJSONBody(w, rq, &req) {
		return
	}
	by := strings.TrimSpace(req.DecidedBy)
	if by == "" {
		by = "dashboard user"
	}
	err := h.service.Save(rq.Context(), req.FindingID, req.Decision, by)
	if err != nil {
		switch {
		case errors.Is(err, r.ErrDecisionFindingNotFound):
			writeError(w, 404, "NOT_FOUND", "Finding not found")
		case errors.Is(err, r.ErrDecisionFindingAmbiguous):
			writeError(w, 409, "AMBIGUOUS_FINDING", "Finding ID matched more than one platform table")
		case strings.Contains(err.Error(), "required") || strings.Contains(err.Error(), "must be") || strings.Contains(err.Error(), "decision must") || strings.Contains(err.Error(), "exceeds"):
			writeError(w, 400, "INVALID_DECISION", err.Error())
		default:
			writeError(w, 500, "INTERNAL_ERROR", "Unable to save analyst decision")
		}
		return
	}
	writeJSON(w, 200, m.OKResponse{OK: true})
}
