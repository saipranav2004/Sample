package credentialexposure

import (
	"encoding/json"
	"errors"
	"net/http"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	s "nhi-backend-api/internal/services/Credential_Exposure"
)

type DeepScanHandler struct{ service *s.DeepScanService }

func NewDeepScanHandler(service *s.DeepScanService) *DeepScanHandler {
	return &DeepScanHandler{service: service}
}
func (h *DeepScanHandler) Trigger(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	var req m.DeepScanRequest
	if !decodeJSONBody(w, rq, &req) {
		return
	}
	req.ClientID = strings.TrimSpace(req.ClientID)
	req.Repository = strings.TrimSpace(req.Repository)
	if req.ClientID == "" || len(req.ClientID) > 200 || req.Repository == "" || len(req.Repository) > 500 {
		writeError(w, 400, "INVALID_REQUEST", "client_id and repository are required and must fit their database columns")
		return
	}
	status, body, err := h.service.Trigger(rq.Context(), req)
	if err != nil {
		if errors.Is(err, s.ErrScannerProxyUnavailable) {
			writeError(w, 503, "SCANNER_UNAVAILABLE", "Deep-scan proxy is not configured")
		} else {
			writeError(w, 502, "SCANNER_UNAVAILABLE", "Unable to reach the scanner aggregator")
		}
		return
	}
	var payload any
	if err := json.Unmarshal(body, &payload); err != nil {
		writeError(w, 502, "INVALID_SCANNER_RESPONSE", "Scanner aggregator returned invalid JSON")
		return
	}
	writeJSON(w, status, payload)
}
func (h *DeepScanHandler) Status(w http.ResponseWriter, rq *http.Request) {
	if !requireScannerAdmin(w, rq) {
		return
	}
	q := rq.URL.Query()
	for k, v := range q {
		if (k != "client_id" && k != "repository" && k != "platform") || len(v) != 1 {
			writeError(w, 400, "INVALID_QUERY", "Supported query parameters are client_id, repository and platform")
			return
		}
	}
	clientID, repoKey, platform := strings.TrimSpace(q.Get("client_id")), strings.TrimSpace(q.Get("repository")), strings.ToLower(strings.TrimSpace(q.Get("platform")))
	if clientID == "" || len(clientID) > 200 || repoKey == "" || len(repoKey) > 500 {
		writeError(w, 400, "INVALID_QUERY", "client_id and repository are required and must fit their database columns")
		return
	}
	if platform != "" && platform != "codecommit" && platform != "github" {
		writeError(w, 400, "INVALID_QUERY", "platform must be codecommit or github")
		return
	}
	items, err := h.service.Status(rq.Context(), clientID, repoKey, platform)
	if err != nil {
		writeError(w, 500, "INTERNAL_ERROR", "Unable to load repository scan status")
		return
	}
	if len(items) == 0 {
		writeJSON(w, 200, map[string]string{"status": "not_started"})
		return
	}
	if len(items) > 1 {
		writeError(w, 409, "PLATFORM_REQUIRED", "More than one platform matched; provide the platform query parameter")
		return
	}
	writeJSON(w, 200, items[0])
}
