package inventory

import "time"

type OrphanedCredential struct {
	CredentialID   string     `json:"credential_id"`
	Name           string     `json:"name"`
	CredentialType string     `json:"credential_type"`
	CreatedAtAWS   *time.Time `json:"created_at_aws"`
	LastUsedAt     *time.Time `json:"last_used_at"`
	DaysUnused     *int       `json:"days_unused"`
}

type OrphanedCredentialsResponse struct {
	ScanID   string               `json:"scan_id"`
	Orphaned []OrphanedCredential `json:"orphaned"`
	Total    int                  `json:"total"`
}
