package inventory

import "time"

type CredentialBoundIdentity struct {
	IdentityID   string     `json:"identity_id"`
	IdentityName *string    `json:"identity_name"`
	IdentityType *string    `json:"identity_type"`
	AccountID    string     `json:"account_id"`
	BindingType  *string    `json:"binding_type"`
	IsPrimary    *bool      `json:"is_primary"`
	LastSeenAt   *time.Time `json:"last_seen_at"`
}

type CredentialBoundIdentitiesResponse struct {
	CredentialID        string                    `json:"credential_id"`
	ScanID              string                    `json:"scan_id"`
	CredentialName      *string                   `json:"credential_name"`
	Identities          []CredentialBoundIdentity `json:"identities"`
	TotalIdentities     int                       `json:"total_identities"`
	BlastRadiusSeverity string                    `json:"blast_radius_severity"`
}
