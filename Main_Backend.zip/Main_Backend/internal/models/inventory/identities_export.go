// package inventory

// import (
// 	"encoding/json"
// 	"time"
// )

// // IdentityExportFilter reuses the same filters as A1 List Identities, plus format.
// type IdentityExportFilter struct {
// 	Page             int
// 	Limit            int
// 	SortBy           string
// 	SortOrder        string
// 	Search           string
// 	IdentityType     string
// 	FunctionalClass  string
// 	AccountID        string
// 	Region           string
// 	Status           string
// 	Owner            string
// 	Environment      string
// 	IsPublic         *bool
// 	LastActiveBefore *time.Time
// 	Format           string
// }

// // IdentityExportRow represents all columns of nhi_scanner.identities for export.
// type IdentityExportRow struct {
// 	ID                   string          `json:"id"`
// 	ARN                  string          `json:"arn"`
// 	Name                 string          `json:"name"`
// 	IdentityType         string          `json:"identity_type"`
// 	FunctionalClass      string          `json:"functional_class"`
// 	AccountID            string          `json:"account_id"`
// 	Region               string          `json:"region"`
// 	Status               string          `json:"status"`
// 	CreatedAtAWS         string          `json:"created_at_aws"`
// 	FirstSeenAt          string          `json:"first_seen_at"`
// 	LastSeenAt           string          `json:"last_seen_at"`
// 	LastActivityAt       string          `json:"last_activity_at"`
// 	DeletedAt            string          `json:"deleted_at"`
// 	VPCID                string          `json:"vpc_id"`
// 	SubnetID             string          `json:"subnet_id"`
// 	SecurityGroupIDs     json.RawMessage `json:"security_group_ids"`
// 	IsPubliclyAccessible bool            `json:"is_publicly_accessible"`
// 	Tags                 json.RawMessage `json:"tags"`
// 	Owner                string          `json:"owner"`
// 	Environment          string          `json:"environment"`
// 	ParentARN            string          `json:"parent_arn"`
// 	CloudTrailCreatorARN string          `json:"cloudtrail_creator_arn"`
// 	DiscoverySource      string          `json:"discovery_source"`
// 	ScanID               string          `json:"scan_id"`
// 	TypeAttributes       json.RawMessage `json:"type_attributes"`
// 	RawAPIResponse       json.RawMessage `json:"raw_api_response"`
// }

// package inventory

// import "time"

// // ExportIdentitiesFilter mirrors the A1 (List Identities) filter set, plus format.
// type ExportIdentitiesFilter struct {
// 	AccountID       string
// 	Region          string
// 	IdentityType    string
// 	Status          string
// 	FunctionalClass string
// 	Environment     string
// 	Owner           string
// 	Search          string
// 	Format          string // "csv" or "json"
// }

// // IdentityExportRow represents a full row of the identities table (all columns).
// type IdentityExportRow struct {
// 	ID                   string     `json:"id"`
// 	ARN                  string     `json:"arn"`
// 	Name                 *string    `json:"name"`
// 	IdentityType         string     `json:"identity_type"`
// 	FunctionalClass      *string    `json:"functional_class"`
// 	AccountID            string     `json:"account_id"`
// 	Region               *string    `json:"region"`
// 	Status               *string    `json:"status"`
// 	CreatedAtAWS         *time.Time `json:"created_at_aws"`
// 	FirstSeenAt          *time.Time `json:"first_seen_at"`
// 	LastSeenAt           *time.Time `json:"last_seen_at"`
// 	LastActivityAt       *time.Time `json:"last_activity_at"`
// 	DeletedAt            *time.Time `json:"deleted_at"`
// 	VpcID                *string    `json:"vpc_id"`
// 	SubnetID             *string    `json:"subnet_id"`
// 	SecurityGroupIDs     *string    `json:"security_group_ids"`
// 	IsPubliclyAccessible *bool      `json:"is_publicly_accessible"`
// 	Tags                 *string    `json:"tags"`
// 	Owner                *string    `json:"owner"`
// 	Environment          *string    `json:"environment"`
// 	ParentARN            *string    `json:"parent_arn"`
// 	CloudtrailCreatorARN *string    `json:"cloudtrail_creator_arn"`
// 	DiscoverySource      *string    `json:"discovery_source"`
// 	ScanID               *string    `json:"scan_id"`
// 	TypeAttributes       *string    `json:"type_attributes"`
// 	RawAPIResponse       *string    `json:"raw_api_response"`
// 	CreatedAt            string     `json:"created_at"`
// 	UpdatedAt            string     `json:"updated_at"`
// }

package inventory

import (
	"encoding/json"
	"time"
)

// ExportIdentityFilter holds the A8 query params (format + all A1 filters).
type ExportIdentityFilter struct {
	Format          string
	Search          string
	AccountID       string
	Region          string
	IdentityType    string
	Status          string
	FunctionalClass string
	Environment     string
	Owner           string
	SortBy          string
	SortOrder       string
	Page            *int
	Limit           *int
}

type ExportIdentityNetwork struct {
	VpcID                *string         `json:"vpc_id"`
	SubnetID             *string         `json:"subnet_id"`
	SecurityGroupIDs     json.RawMessage `json:"security_group_ids"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
}

type ExportIdentityDiscovery struct {
	DiscoverySource *string `json:"discovery_source"`
	ScanID          *string `json:"scan_id"`
}

// ExportIdentity maps 1:1 to every column in the identities table — nothing fabricated.
type ExportIdentity struct {
	ID                   string                  `json:"id"`
	ARN                  string                  `json:"arn"`
	Name                 string                  `json:"name"`
	IdentityType         string                  `json:"identity_type"`
	FunctionalClass      string                  `json:"functional_class"`
	AccountID            string                  `json:"account_id"`
	Region               string                  `json:"region"`
	Status               string                  `json:"status"`
	CreatedAtAWS         *time.Time              `json:"created_at_aws"`
	FirstSeenAt          *time.Time              `json:"first_seen_at"`
	LastSeenAt           *time.Time              `json:"last_seen_at"`
	LastActivityAt       *time.Time              `json:"last_activity_at"`
	Network              ExportIdentityNetwork   `json:"network"`
	Tags                 json.RawMessage         `json:"tags"`
	Owner                *string                 `json:"owner"`
	Environment          *string                 `json:"environment"`
	ParentARN            *string                 `json:"parent_arn"`
	CloudtrailCreatorARN *string                 `json:"cloudtrail_creator_arn"`
	Discovery            ExportIdentityDiscovery `json:"discovery"`
	TypeAttributes       json.RawMessage         `json:"type_attributes"`
	RawAPIResponse       json.RawMessage         `json:"raw_api_response"`
	CreatedAt            *time.Time              `json:"created_at"`
	UpdatedAt            *time.Time              `json:"updated_at"`
}
