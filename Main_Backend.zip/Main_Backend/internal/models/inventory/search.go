package inventory

type SearchIdentityResult struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	IdentityType string `json:"identity_type"`
}

type SearchCredentialResult struct {
	ID             string `json:"id"`
	Name           string `json:"name"`
	CredentialType string `json:"credential_type"`
}

type GlobalSearchResponse struct {
	Query        string                   `json:"query"`
	TotalResults int                      `json:"total_results"`
	Identities   []SearchIdentityResult   `json:"identities"`
	Credentials  []SearchCredentialResult `json:"credentials"`
}
