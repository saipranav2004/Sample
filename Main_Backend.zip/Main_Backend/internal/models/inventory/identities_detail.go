package inventory

import (
	"encoding/json"
	"time"
)

type IdentityNetwork struct {
	VPCID                *string         `json:"vpc_id"`
	SubnetID             *string         `json:"subnet_id"`
	SecurityGroupIDs     json.RawMessage `json:"security_group_ids"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
}

type IdentityOwnership struct {
	Owner       *string         `json:"owner"`
	Environment *string         `json:"environment"`
	Tags        json.RawMessage `json:"tags"`
}

type IdentityLineage struct {
	ParentARN            *string `json:"parent_arn"`
	CloudTrailCreatorARN *string `json:"cloudtrail_creator_arn"`
}

type IdentityDiscovery struct {
	DiscoverySource string  `json:"discovery_source"`
	ScanID          *string `json:"scan_id"`
}

type IdentityDetail struct {
	ID              string            `json:"id"`
	ARN             string            `json:"arn"`
	Name            string            `json:"name"`
	IdentityType    string            `json:"identity_type"`
	FunctionalClass *string           `json:"functional_class"`
	AccountID       string            `json:"account_id"`
	Region          string            `json:"region"`
	Status          string            `json:"status"`
	CreatedAtAWS    *time.Time        `json:"created_at_aws"`
	FirstSeenAt     *time.Time        `json:"first_seen_at"`
	LastSeenAt      *time.Time        `json:"last_seen_at"`
	LastActivityAt  *time.Time        `json:"last_activity_at"`
	DeletedAt       *time.Time        `json:"deleted_at"`
	Network         IdentityNetwork   `json:"network"`
	Ownership       IdentityOwnership `json:"ownership"`
	Lineage         IdentityLineage   `json:"lineage"`
	Discovery       IdentityDiscovery `json:"discovery"`
	TypeAttributes  json.RawMessage   `json:"type_attributes"`
	RawAPIResponse  json.RawMessage   `json:"raw_api_response"`
}
