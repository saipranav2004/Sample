package inventory

// ManagedPolicy represents a single attached managed policy.
type ManagedPolicy struct {
	ARN             string                   `json:"arn"`
	Name            string                   `json:"name"`
	StatementCount  int                      `json:"statement_count"`
	RiskyStatements []map[string]interface{} `json:"risky_statements"`
}

// AttachedPoliciesResponse is the full response for
// GET /api/v1/inventory/credentials/{id}/policies
type AttachedPoliciesResponse struct {
	CredentialID       string          `json:"credential_id"`
	ManagedPolicies    []ManagedPolicy `json:"managed_policies"`
	InlinePolicies     []string        `json:"inline_policies"`
	PermissionBoundary *string         `json:"permission_boundary"`
}
