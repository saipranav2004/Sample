package inventory

import "time"

type UsedCredentialAction struct {
	Action    string    `json:"action"`
	LastUsed  time.Time `json:"last_used"`
	CallCount int64     `json:"call_count"`
}

type UnusedCredentialAction struct {
	Action    string  `json:"action"`
	GrantedBy *string `json:"granted_by"`
}

type CredentialUsageResponse struct {
	CredentialID          string                   `json:"credential_id"`
	ScanID                string                   `json:"scan_id"`
	GrantedActions        int64                    `json:"granted_actions"`
	UsedActions           int64                    `json:"used_actions"`
	UnusedActions         int64                    `json:"unused_actions"`
	UnusedPercentage      float64                  `json:"unused_percentage"`
	OverprivilegeSeverity string                   `json:"overprivilege_severity"`
	UsedActionsList       []UsedCredentialAction   `json:"used_actions_list"`
	UnusedButGranted      []UnusedCredentialAction `json:"unused_but_granted"`
	Recommendation        string                   `json:"recommendation"`
}

type CredentialUsageFilter struct{ Days int }

type CredentialUsageGrant struct {
	Action     string
	Effect     string
	SourceName *string
}
type CredentialUsageEvent struct {
	Action    string
	LastSeen  time.Time
	CallCount int64
}
