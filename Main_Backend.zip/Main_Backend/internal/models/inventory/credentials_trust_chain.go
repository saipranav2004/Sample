package inventory

import "encoding/json"

type TrustChainEdge struct {
	SourceARN  string          `json:"source_arn,omitempty"`
	TargetARN  string          `json:"target_arn,omitempty"`
	EdgeType   string          `json:"edge_type"`
	Conditions json.RawMessage `json:"conditions"`
}

type CredentialTrustChainResponse struct {
	CredentialID   string           `json:"credential_id"`
	ScanID         string           `json:"scan_id"`
	RoleARN        *string          `json:"role_arn"`
	CanBeAssumedBy []TrustChainEdge `json:"can_be_assumed_by"`
	CanAssume      []TrustChainEdge `json:"can_assume"`
	CanPassRoleTo  []TrustChainEdge `json:"can_pass_role_to"`
}
