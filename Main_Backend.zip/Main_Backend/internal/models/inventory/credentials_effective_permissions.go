package inventory

import "encoding/json"

type CredentialPermission struct {
	Action     string          `json:"action"`
	Resource   *string         `json:"resource"`
	Effect     string          `json:"effect"`
	Source     *string         `json:"source"`
	SourceName *string         `json:"source_name"`
	Condition  json.RawMessage `json:"condition"`
}

type PermissionServiceCount struct {
	Service     string `json:"service"`
	ActionCount int64  `json:"action_count"`
}

type CredentialEffectivePermissionsResponse struct {
	CredentialID     string                   `json:"credential_id"`
	ScanID           string                   `json:"scan_id"`
	TotalPermissions int64                    `json:"total_permissions"`
	AllowCount       int64                    `json:"allow_count"`
	DenyCount        int64                    `json:"deny_count"`
	Permissions      []CredentialPermission   `json:"permissions"`
	ByService        []PermissionServiceCount `json:"by_service"`
	WildcardActions  []string                 `json:"wildcard_actions"`
	HasAdminAccess   bool                     `json:"has_admin_access"`
}

type CredentialPermissionFilter struct {
	Effect  string
	Service string
}
