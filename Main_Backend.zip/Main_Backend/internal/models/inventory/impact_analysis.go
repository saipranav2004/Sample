package inventory

type ImpactAnalysisMetrics struct {
	IdentitiesAffected          int      `json:"identities_affected"`
	PermissionsGranted          int      `json:"permissions_granted"`
	ServicesAccessible          []string `json:"services_accessible"`
	PrivilegeEscalationPossible bool     `json:"privilege_escalation_possible"`
	AttackPathsCount            int      `json:"attack_paths_count"`
	DataAccessScope             string   `json:"data_access_scope"`
}

type ImpactAnalysisResponse struct {
	ScanID          string                `json:"scan_id"`
	EntityID        string                `json:"entity_id"`
	EntityType      string                `json:"entity_type"`
	Impact          ImpactAnalysisMetrics `json:"impact"`
	OverallSeverity string                `json:"overall_severity"`
}
