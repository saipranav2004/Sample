package inventory

import (
	"encoding/json"
	"time"
)

// ExportCredentialFilter holds the B9 query params.
type ExportCredentialFilter struct {
	Format             string
	Search             string
	CredentialType     string
	AccountID          string
	Region             string
	Status             string
	RotationEnabled    *bool
	ExpiringWithinDays *int
	StaleDays          *int
	PrivilegeLevelMin  *int
	PrivilegeLevelMax  *int
	OwnerPrincipalARN  string
	SortBy             string
	SortOrder          string
	Page               *int
	Limit              *int
}

type ExportIAMRoleDetails struct {
	TrustPolicy           json.RawMessage `json:"trust_policy"`
	AttachedPolicies      json.RawMessage `json:"attached_policies"`
	InlinePolicies        json.RawMessage `json:"inline_policies"`
	PermissionBoundaryARN *string         `json:"permission_boundary_arn"`
	MaxSessionDuration    *int            `json:"max_session_duration"`
	PrivilegeLevel        *int            `json:"privilege_level"`
	AssumableRoleARNs     json.RawMessage `json:"assumable_role_arns"`
}

type ExportDiscovery struct {
	DiscoverySource *string `json:"discovery_source"`
	ScanID          *string `json:"scan_id"`
}

type ExportCredential struct {
	ID                   string               `json:"id"`
	ARN                  string               `json:"arn"`
	Name                 string               `json:"name"`
	CredentialType       string               `json:"credential_type"`
	AccountID            string               `json:"account_id"`
	Region               string               `json:"region"`
	Status               string               `json:"status"`
	CreatedAtAWS         *time.Time           `json:"created_at_aws"`
	FirstSeenAt          *time.Time           `json:"first_seen_at"`
	LastSeenAt           *time.Time           `json:"last_seen_at"`
	LastUsedAt           *time.Time           `json:"last_used_at"`
	LastRotatedAt        *time.Time           `json:"last_rotated_at"`
	ExpiresAt            *time.Time           `json:"expires_at"`
	RotationEnabled      *bool                `json:"rotation_enabled"`
	RotationIntervalDays *int                 `json:"rotation_interval_days"`
	Tags                 json.RawMessage      `json:"tags"`
	OwnerPrincipalARN    *string              `json:"owner_principal_arn"`
	IAMRoleDetails       ExportIAMRoleDetails `json:"iam_role_details"`
	TypeAttributes       json.RawMessage      `json:"type_attributes"`
	Discovery            ExportDiscovery      `json:"discovery"`
}
