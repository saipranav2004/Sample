package inventory

import "time"

// IAMRolePolicy represents an attached policy inside iam_role_details
type IAMRolePolicy struct {
	ARN      string                 `json:"arn"`
	Name     string                 `json:"name"`
	Document map[string]interface{} `json:"document"`
}

// IAMRoleDetails holds the role policy and configuration fields
type IAMRoleDetails struct {
	TrustPolicy           map[string]interface{} `json:"trust_policy"`
	AttachedPolicies      []IAMRolePolicy        `json:"attached_policies"`
	InlinePolicies        []string               `json:"inline_policies"`
	PermissionBoundaryARN *string                `json:"permission_boundary_arn"`
	MaxSessionDuration    int                    `json:"max_session_duration"`
	PrivilegeLevel        int                    `json:"privilege_level"`
	AssumableRoleARNs     []string               `json:"assumable_role_arns"`
}

// CredentialDiscovery holds discovery scan metadata
type CredentialDiscovery struct {
	DiscoverySource string `json:"discovery_source"`
	ScanID          string `json:"scan_id"`
}

// CredentialDetail is the full detail response matching endpoint B2
type CredentialDetail struct {
	ID                   string                 `json:"id"`
	ARN                  string                 `json:"arn"`
	Name                 string                 `json:"name"`
	CredentialType       string                 `json:"credential_type"`
	AccountID            string                 `json:"account_id"`
	Region               string                 `json:"region"`
	Status               string                 `json:"status"`
	CreatedAtAWS         *time.Time             `json:"created_at_aws"`
	FirstSeenAt          *time.Time             `json:"first_seen_at"`
	LastSeenAt           *time.Time             `json:"last_seen_at"`
	LastUsedAt           *time.Time             `json:"last_used_at"`
	LastRotatedAt        *time.Time             `json:"last_rotated_at"`
	ExpiresAt            *time.Time             `json:"expires_at"`
	RotationEnabled      *bool                  `json:"rotation_enabled"`
	RotationIntervalDays *int                   `json:"rotation_interval_days"`
	Tags                 map[string]interface{} `json:"tags"`
	OwnerPrincipalARN    *string                `json:"owner_principal_arn"`
	IAMRoleDetails       *IAMRoleDetails        `json:"iam_role_details"` // Always included in JSON
	TypeAttributes       map[string]interface{} `json:"type_attributes"`
	Discovery            CredentialDiscovery    `json:"discovery"`
}
