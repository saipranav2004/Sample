package inventory

// UpdateIdentityRequest represents the partial-update payload for PATCH /inventory/identities/{id}.
// Pointer fields allow distinguishing "not provided" from "empty string".
type UpdateIdentityRequest struct {
	FunctionalClass *string `json:"functional_class,omitempty"`
	Owner           *string `json:"owner,omitempty"`
	Environment     *string `json:"environment,omitempty"`
}

type UpdateIdentityResponse struct {
	ID            string   `json:"id"`
	Message       string   `json:"message"`
	UpdatedFields []string `json:"updated_fields"`
}
