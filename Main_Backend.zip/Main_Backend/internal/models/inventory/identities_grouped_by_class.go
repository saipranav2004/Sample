package inventory

type GroupedIdentitySummary struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	IdentityType string `json:"identity_type"`
	Status       string `json:"status"`
}

type IdentityClassGroup struct {
	FunctionalClass string                   `json:"functional_class"`
	Count           int                      `json:"count"`
	Identities      []GroupedIdentitySummary `json:"identities"`
}

type GroupedByClassResponse struct {
	Groups []IdentityClassGroup `json:"groups"`
}

type GroupedByClassFilter struct {
	AccountID     string
	Region        string
	LimitPerClass int
}
