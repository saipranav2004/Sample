package inventory

// TrustPolicyCondition represents a single condition in a trust policy statement.
type TrustPolicyCondition struct {
	Operator string `json:"operator"`
	Key      string `json:"key"`
	Value    string `json:"value"`
}

// TrustPolicyStatement represents a single parsed statement from the trust policy.
type TrustPolicyStatement struct {
	Effect         string                 `json:"effect"`
	PrincipalType  string                 `json:"principal_type"`
	PrincipalValue string                 `json:"principal_value"`
	Action         string                 `json:"action"`
	Conditions     []TrustPolicyCondition `json:"conditions"`
}

// TrustPolicyRiskSummary holds computed risk flags for the trust policy.
type TrustPolicyRiskSummary struct {
	IsPublic             bool `json:"is_public"`
	HasExternalAccount   bool `json:"has_external_account"`
	HasWildcardPrincipal bool `json:"has_wildcard_principal"`
}

// TrustPolicyDetail holds the parsed trust policy and risk summary.
type TrustPolicyDetail struct {
	Statements  []TrustPolicyStatement `json:"statements"`
	RiskSummary TrustPolicyRiskSummary `json:"risk_summary"`
}

// TrustPolicyResponse is the full response for
// GET /api/v1/inventory/credentials/{id}/trust-policy
type TrustPolicyResponse struct {
	CredentialID string            `json:"credential_id"`
	TrustPolicy  TrustPolicyDetail `json:"trust_policy"`
}
