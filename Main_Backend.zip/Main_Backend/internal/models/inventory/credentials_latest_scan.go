package inventory

import "errors"

// ErrLatestCompletedScanUnavailable means an account has no completed scan with scan_end.
var ErrLatestCompletedScanUnavailable = errors.New("latest completed scan unavailable")
