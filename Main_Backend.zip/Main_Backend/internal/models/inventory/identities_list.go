package inventory

import (
	"encoding/json"
	"time"
)

type IdentityListFilter struct {
	Page             int
	Limit            int
	SortBy           string
	SortOrder        string
	Search           string
	IdentityType     string
	FunctionalClass  string
	AccountID        string
	Region           string
	Status           string
	Owner            string
	Environment      string
	IsPublic         *bool
	LastActiveBefore *time.Time
}

type Identity struct {
	ID                   string          `json:"id"`
	ARN                  string          `json:"arn"`
	Name                 string          `json:"name"`
	IdentityType         string          `json:"identity_type"`
	FunctionalClass      *string         `json:"functional_class"`
	AccountID            string          `json:"account_id"`
	Region               string          `json:"region"`
	Status               string          `json:"status"`
	CreatedAtAWS         *time.Time      `json:"created_at_aws"`
	LastSeenAt           *time.Time      `json:"last_seen_at"`
	LastActivityAt       *time.Time      `json:"last_activity_at"`
	Owner                *string         `json:"owner"`
	Environment          *string         `json:"environment"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
	Tags                 json.RawMessage `json:"tags"`
}

type IdentityListResponse struct {
	Total int        `json:"total"`
	Page  int        `json:"page"`
	Limit int        `json:"limit"`
	Data  []Identity `json:"data"`
}
