package inventory

type TrustGraphNode struct {
	ID        string `json:"id"`
	Label     string `json:"label"`
	Type      string `json:"type"`
	Privilege *int   `json:"privilege,omitempty"`
}

type TrustGraphEdge struct {
	Source string `json:"source"`
	Target string `json:"target"`
	Type   string `json:"type"`
}

type TrustGraphResponse struct {
	ScanID string           `json:"scan_id"`
	Nodes  []TrustGraphNode `json:"nodes"`
	Edges  []TrustGraphEdge `json:"edges"`
}
