package inventory

// HygieneFlag represents a single hygiene issue found on a credential.
type HygieneFlag struct {
	Flag     string `json:"flag"`
	Severity string `json:"severity"`
	Detail   string `json:"detail,omitempty"`
}

// CredentialHygieneResponse is the full response for
// GET /api/v1/inventory/credentials/{id}/hygiene
type CredentialHygieneResponse struct {
	CredentialID   string        `json:"credential_id"`
	CredentialType string        `json:"credential_type"`
	Flags          []HygieneFlag `json:"flags"`
	OverallHealth  string        `json:"overall_health"` // critical | medium | low | healthy
}
