package inventory

import "time"

// StaleCredentialFilter holds the query params for B8.
type StaleCredentialFilter struct {
	Days           int // required, > 0
	CredentialType string
	AccountID      string
	Page           int
	Limit          int
}

// StaleCredential is one row in the B8 response.
type StaleCredential struct {
	ID                string    `json:"id"`
	Name              string    `json:"name"`
	CredentialType    string    `json:"credential_type"`
	LastUsedAt        time.Time `json:"last_used_at"`
	DaysUnused        int       `json:"days_unused"`
	OwnerPrincipalARN *string   `json:"owner_principal_arn"` // null when no owner
}

// StaleCredentialsResponse matches the spec:
// { "threshold_days": 90, "total_stale": 67, "data": [...] }
type StaleCredentialsResponse struct {
	ThresholdDays int               `json:"threshold_days"`
	TotalStale    int               `json:"total_stale"`
	Data          []StaleCredential `json:"data"`
}
