package models

import "time"

type DashboardSummary struct {
	TotalIdentities         int            `json:"total_identities"`
	TotalSecrets            int            `json:"total_secrets"`
	TotalOrphaned           int            `json:"total_orphaned"`
	TotalHumans             int            `json:"total_humans"`
	TotalNHIs               int            `json:"total_nhis"`
	TotalHumansWithoutMFA   int            `json:"total_humans_without_mfa"`
	TotalCredentials        int            `json:"total_credentials"`
	ClassificationBreakdown map[string]int `json:"classification_breakdown"`
	CredentialsBreakdown    map[string]int `json:"credentials_breakdown"`

	// ── POSTURE METRICS ──
	TotalNhiAgents      int `json:"total_nhi_agents"`
	TotalNhiCicd        int `json:"total_nhi_cicd"`
	TotalFederated      int `json:"total_federated"`
	TotalAdmin          int `json:"total_admin"`
	TotalStale90Plus    int `json:"total_stale_90plus"`
	TotalInactive30Plus int `json:"total_inactive_30plus"`
}

// IdentityDetail maps to the full 41-column NHI_IDENTITY_DETAILS table.
// This is the "raw" shape — every column, untouched. Use it for the
// identity detail view. For the Identities table/grid view, see
// IdentityListItem below, which is a formatted projection of this.
type IdentityDetail struct {
	ID                  int        `json:"id"`
	ScanID              string     `json:"scan_id"`
	ARN                 string     `json:"arn"`
	AccountID           string     `json:"account_id"`
	Name                string     `json:"name"`
	IdentityType        string     `json:"identity_type"`
	Classification      string     `json:"classification"`
	MatchedRules        string     `json:"matched_rules,omitempty"`
	Evidence            string     `json:"evidence,omitempty"`
	TrustType           string     `json:"trust_type,omitempty"`
	TrustService        string     `json:"trust_service,omitempty"`
	TotalEvents         int        `json:"total_events"`
	LastActive          *time.Time `json:"last_active"`
	OwnerName           string     `json:"owner_name,omitempty"`
	OwnerType           string     `json:"owner_type,omitempty"`
	CreatedAt           *time.Time `json:"created_at"`
	PrimaryOwner        string     `json:"primary_owner,omitempty"`
	CreatedByName       string     `json:"created_by_name,omitempty"`
	IsSecret            bool       `json:"is_secret"`
	OwnedCredentials    string     `json:"owned_credentials,omitempty"`
	AttachedPolicies    string     `json:"attached_policies,omitempty"`
	IsAdmin             bool       `json:"is_admin"`
	GroupsList          string     `json:"groups_list,omitempty"`
	ConsoleAccess       string     `json:"console_access,omitempty"`
	ConsoleLastSignin   *time.Time `json:"console_last_signin,omitempty"`
	MFAEnabled          bool       `json:"mfa_enabled"`
	PasswordAgeDays     int        `json:"password_age_days"`
	AccessKey1ID        string     `json:"access_key_1_id,omitempty"`
	AccessKey1AgeDays   int        `json:"access_key_1_age_days"`
	AccessKeyLastUsed   *time.Time `json:"access_key_last_used,omitempty"`
	Relationships       string     `json:"relationships,omitempty"`
	BoundCredType       string     `json:"bound_cred_type,omitempty"`
	BoundCredAssumedVia string     `json:"bound_cred_assumed_via,omitempty"`
	BoundCredPolicies   string     `json:"bound_cred_policies,omitempty"`
	OverviewBoundCred   string     `json:"overview_bound_cred,omitempty"`
	OverviewPermissions string     `json:"overview_permissions,omitempty"`
	OverviewDiscovery   string     `json:"overview_discovery,omitempty"`
	OverviewTags        string     `json:"overview_tags,omitempty"`
	OverviewRiskFactors string     `json:"overview_risk_factors,omitempty"`
	FullProfileJSON     string     `json:"full_profile_json,omitempty"`
	DiscoveredAt        *time.Time `json:"discovered_at"`
}

// IdentityListItem is the shape the Identities table/grid consumes.
// Every field maps to a real column on nhi_identity_details, except
// Permissions/Risk, which are derived at read time (see
// pkg/utils/identity_helpers.go) because those don't have dedicated columns.
type IdentityListItem struct {
	Name            string     `json:"name"`             // NAME
	ARN             string     `json:"arn"`              // ARN (unique — used for detail lookup)
	IdentityType    string     `json:"identity_type"`    // IDENTITY_TYPE
	Classification  string     `json:"classification"`   // CLASSIFICATION
	AccountID       string     `json:"account_id"`       // ACCOUNT_ID
	TrustService    string     `json:"trust_service"`    // TRUST_SERVICE
	BoundCredential string     `json:"bound_credential"` // OVERVIEW_BOUND_CRED, falls back to BOUND_CRED_ASSUMED_VIA
	BoundCredType   string     `json:"bound_cred_type"`  // BOUND_CRED_TYPE, title-cased
	Permissions     string     `json:"permissions"`      // derived: IS_ADMIN + OVERVIEW_PERMISSIONS + ATTACHED_POLICIES
	LastActive      *time.Time `json:"last_active"`      // LAST_ACTIVE
	Risk            string     `json:"risk"`             // derived: IS_ADMIN + Permissions + OVERVIEW_RISK_FACTORS + MFA/console
	IsAdmin         bool       `json:"is_admin"`         // IS_ADMIN
	MFAEnabled      bool       `json:"mfa_enabled"`      // MFA_ENABLED
}

// IdentityOverview is the response shape for GET /api/identities/{id}/overview
// — the page shown when an identity is opened from the list. Header is the
// full raw row (IdentityDetail, unchanged); the sections below group
// specific columns for the Overview tab's cards.
type IdentityOverview struct {
	IdentityDetails   IdentityDetailsSection   `json:"identity_details"`
	BoundCredential   BoundCredentialSection   `json:"bound_credential"`
	PermissionSummary PermissionSummarySection `json:"permission_summary"`
	Discovery         DiscoverySection         `json:"discovery"`
}

type IdentityDetailsSection struct {
	OwnerName         string     `json:"owner_name"`
	OwnerType         string     `json:"owner_type"`
	PrimaryOwner      string     `json:"primary_owner"`
	CreatedByName     string     `json:"created_by_name"`
	TrustType         string     `json:"trust_type"`
	TrustService      string     `json:"trust_service"`
	ConsoleAccess     string     `json:"console_access"`
	ConsoleLastSignin *time.Time `json:"console_last_signin"`
	MFAEnabled        bool       `json:"mfa_enabled"`
	PasswordAgeDays   int        `json:"password_age_days"`
	AccessKey1ID      string     `json:"access_key_1_id"`
	AccessKey1AgeDays int        `json:"access_key_1_age_days"`
	AccessKeyLastUsed *time.Time `json:"access_key_last_used"`
	GroupsList        string     `json:"groups_list"`
}

type BoundCredentialSection struct {
	Type       string `json:"type"`        // BOUND_CRED_TYPE, formatted (e.g. "IAM Role")
	AssumedVia string `json:"assumed_via"` // BOUND_CRED_ASSUMED_VIA
	Policies   string `json:"policies"`    // BOUND_CRED_POLICIES
	Summary    string `json:"summary"`     // OVERVIEW_BOUND_CRED
}

type PermissionSummarySection struct {
	Level               string `json:"level"`                // derived: BROAD/SCOPED
	OverviewPermissions string `json:"overview_permissions"` // OVERVIEW_PERMISSIONS
	AttachedPolicies    string `json:"attached_policies"`    // ATTACHED_POLICIES
	RiskLevel           string `json:"risk_level"`           // derived: HIGH/MEDIUM/LOW
	RiskFactors         string `json:"risk_factors"`         // OVERVIEW_RISK_FACTORS
}

type DiscoverySection struct {
	ScanID       string `json:"scan_id"`       // SCAN_ID
	Method       string `json:"method"`        // OVERVIEW_DISCOVERY
	MatchedRules string `json:"matched_rules"` // MATCHED_RULES
	Evidence     string `json:"evidence"`      // EVIDENCE
}
