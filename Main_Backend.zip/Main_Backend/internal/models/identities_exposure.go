package models

type IdentityExposureFilter struct {
	AccountID string
}

type ExposureTypeCount struct {
	IdentityType string `json:"identity_type"`
	Count        int    `json:"count"`
}

type ExposureBucket struct {
	Total  int                 `json:"total"`
	ByType []ExposureTypeCount `json:"by_type"`
}

type IdentityExposureResponse struct {
	PubliclyAccessible    ExposureBucket `json:"publicly_accessible"`
	Dormant90d            ExposureBucket `json:"dormant_90d"`
	NoActivityTracked     int            `json:"no_activity_tracked"`
	MissingOwnerTag       int            `json:"missing_owner_tag"`
	MissingEnvironmentTag int            `json:"missing_environment_tag"`
	NotInIaC              int            `json:"not_in_iac"`
}
