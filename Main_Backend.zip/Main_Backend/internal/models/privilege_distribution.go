package models

// PrivilegeDistributionItem represents a single bucket of the 0-10
// privilege-level histogram.
type PrivilegeDistributionItem struct {
	PrivilegeLevel int    `json:"privilege_level"`
	Count          int    `json:"count"`
	Label          string `json:"label"`
}

// PrivilegeDistributionResponse is the exact shape documented in
// "12. Privilege Distribution" of the API spec.
type PrivilegeDistributionResponse struct {
	TotalRolesWithScore int                         `json:"total_roles_with_score"`
	TotalRolesUnscored  int                         `json:"total_roles_unscored"`
	Distribution        []PrivilegeDistributionItem `json:"distribution"`
}
