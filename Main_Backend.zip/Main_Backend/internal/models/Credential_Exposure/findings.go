package credentialexposure

// Finding is a normalized row from either scanner findings table.
type Finding struct {
	FindingID          string   `json:"finding_id"`
	ClientID           string   `json:"client_id"`
	Repository         string   `json:"repository"`
	Branch             string   `json:"branch"`
	CommitID           string   `json:"commit_id"`
	Author             string   `json:"author"`
	CreatedAt          string   `json:"created_at"`
	Detector           string   `json:"detector"`
	Severity           string   `json:"severity"`
	FilePath           string   `json:"file_path"`
	LineNumber         int      `json:"line_number"`
	Redacted           string   `json:"redacted"`
	VerificationStatus string   `json:"verification_status"`
	RiskTier           string   `json:"risk_tier"`
	RecommendedAction  string   `json:"recommended_action"`
	CodeCommitURI      *string  `json:"codecommit_uri"`
	Platform           string   `json:"platform"`
	GitHubURI          *string  `json:"github_uri"`
	LinePreview        *string  `json:"line_preview"`
	Confidence         *string  `json:"confidence"`
	Category           *string  `json:"category"`
	Committer          *string  `json:"committer"`
	CommitMessage      *string  `json:"commit_message"`
	CommitAuthoredAt   *string  `json:"commit_authored_at"`
	FilesChanged       *int     `json:"files_changed"`
	Additions          *int     `json:"additions"`
	Deletions          *int     `json:"deletions"`
	RepoVisibility     *string  `json:"repo_visibility"`
	RepoStars          *int     `json:"repo_stars"`
	RepoForks          *int     `json:"repo_forks"`
	RepoPushedAt       *string  `json:"repo_pushed_at"`
	MLScore            *float64 `json:"ml_score"`
	MLDecision         *string  `json:"ml_decision"`
	MLModelVersion     *string  `json:"ml_model_version"`
	AnalystDecision    *string  `json:"analyst_decision"`
	AnalystDecidedAt   *string  `json:"analyst_decided_at"`
	AnalystDecidedBy   *string  `json:"analyst_decided_by"`
}

type FindingsResponse struct {
	Count    int       `json:"count"`
	Findings []Finding `json:"findings"`
	Limit    int       `json:"limit,omitempty"`
	Offset   int       `json:"offset,omitempty"`
}

type FindingsFilter struct {
	ClientID  string
	Platform  string
	MLFlagged bool
	Limit     int
	Offset    int
}
