package credentialexposure

type AllowlistEntry struct {
	ClientID    string `json:"client_id"`
	FilePath    string `json:"file_path"`
	Detector    string `json:"detector"`
	Redacted    string `json:"redacted"`
	Reason      string `json:"reason"`
	DismissedBy string `json:"dismissed_by"`
	DismissedAt string `json:"dismissed_at"`
}

type AllowlistListResponse struct {
	Entries []AllowlistEntry `json:"entries"`
}

type AllowlistRequest struct {
	ClientID    string `json:"client_id"`
	FilePath    string `json:"file_path"`
	Detector    string `json:"detector"`
	Redacted    string `json:"redacted"`
	Reason      string `json:"reason,omitempty"`
	DismissedBy string `json:"dismissed_by,omitempty"`
}
