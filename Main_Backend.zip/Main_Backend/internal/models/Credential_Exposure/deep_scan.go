package credentialexposure

type DeepScanRequest struct {
	ClientID   string `json:"client_id"`
	Repository string `json:"repository"`
}

type DeepScanResult struct {
	ClientID        string  `json:"client_id"`
	RepoKey         string  `json:"repo_key"`
	Platform        string  `json:"platform"`
	RequestedAt     *string `json:"requested_at"`
	CompletedAt     *string `json:"completed_at"`
	CommitsScanned  *int    `json:"commits_scanned"`
	Findings        *int    `json:"findings"`
	FailedAt        *string `json:"failed_at"`
	Error           *string `json:"error"`
	Status          string  `json:"status"`
	LastCommitID    *string `json:"last_commit_id,omitempty"`
	UpdatedAt       *string `json:"updated_at,omitempty"`
	PendingCommitID *string `json:"pending_commit_id,omitempty"`
	PendingSince    *string `json:"pending_since,omitempty"`
}
