package credentialexposure

type FindingDecisionRequest struct {
	FindingID string `json:"finding_id"`
	Decision  string `json:"decision"`
	DecidedBy string `json:"decided_by,omitempty"`
}

type OKResponse struct {
	OK bool `json:"ok"`
}
