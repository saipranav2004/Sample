package models

type CoverageStat struct {
	Count      int     `json:"count"`
	Percentage float64 `json:"percentage"`
}

type IdentityOwnershipCoverage struct {
	Total             int          `json:"total"`
	HasOwnerTag       CoverageStat `json:"has_owner_tag"`
	HasEnvironmentTag CoverageStat `json:"has_environment_tag"`
	HasAnyTag         CoverageStat `json:"has_any_tag"`
	HasNoTags         CoverageStat `json:"has_no_tags"`
	IsInIaC           CoverageStat `json:"is_in_iac"`
}

type CredentialOwnershipCoverage struct {
	Total             int          `json:"total"`
	HasOwnerTag       CoverageStat `json:"has_owner_tag"`
	HasEnvironmentTag CoverageStat `json:"has_environment_tag"` // NEW — derived from tags jsonb only (no dedicated column)
	HasAnyTag         CoverageStat `json:"has_any_tag"`
	HasNoTags         CoverageStat `json:"has_no_tags"`
	IsInIaC           CoverageStat `json:"is_in_iac"` // NEW — derived from discovery_source
}

type OwnershipCoverageResponse struct {
	Identities  *IdentityOwnershipCoverage   `json:"identities,omitempty"`
	Credentials *CredentialOwnershipCoverage `json:"credentials,omitempty"`
}
