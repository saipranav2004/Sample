package models

// HygieneByTypeCount represents a per-credential-type count used in breakdown lists.
type HygieneByTypeCount struct {
	CredentialType string `json:"credential_type"`
	Count          int    `json:"count"`
}

// HygieneExpirySummary represents a total + by-type breakdown for expiry-related buckets.
type HygieneExpirySummary struct {
	Total  int                  `json:"total"`
	ByType []HygieneByTypeCount `json:"by_type"`
}

// HygieneHighPrivilegeSummary represents the high-privilege-roles sub-section.
type HygieneHighPrivilegeSummary struct {
	Total           int `json:"total"`
	AdminAccess     int `json:"admin_access"`
	WildcardActions int `json:"wildcard_actions"`
}

// CredentialHygieneSummaryResponse is the full response for
// GET /dashboard/credentials/hygiene
type CredentialHygieneSummaryResponse struct {
	ExpiringWithin30d       HygieneExpirySummary        `json:"expiring_within_30d"`
	AlreadyExpired          HygieneExpirySummary        `json:"already_expired"`
	StaleAccessKeys90d      int                         `json:"stale_access_keys_90d"`
	NeverUsedAccessKeys     int                         `json:"never_used_access_keys"`
	UnrotatedSecrets90d     int                         `json:"unrotated_secrets_90d"`
	RotationDisabledSecrets int                         `json:"rotation_disabled_secrets"`
	RootAccessKeysPresent   int                         `json:"root_access_keys_present"`
	HighPrivilegeRoles      HygieneHighPrivilegeSummary `json:"high_privilege_roles"`
	PublicTrustRoles        int                         `json:"public_trust_roles"`
}
