package models

type DashboardFiltersResponse struct {
	Accounts          []string `json:"accounts"`
	Regions           []string `json:"regions"`
	IdentityTypes     []string `json:"identity_types"`
	CredentialTypes   []string `json:"credential_types"`
	FunctionalClasses []string `json:"functional_classes"`
	Statuses          []string `json:"statuses"`
}
