package models

type IdentityByTypeFilter struct {
	AccountID       string
	Region          string
	Status          string
	FunctionalClass string
}

type IdentityTypeCount struct {
	IdentityType string `json:"identity_type"`
	Count        int    `json:"count"`
}

type IdentitiesByTypeResponse struct {
	Total     int                 `json:"total"`
	Breakdown []IdentityTypeCount `json:"breakdown"`
}
