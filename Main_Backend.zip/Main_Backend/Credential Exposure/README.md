# Credential Exposure API module

The Go implementation follows the backend's layered structure. Because Go import paths cannot contain spaces, the source package directories use `Credential_Exposure`:

- `internal/models/Credential_Exposure`
- `internal/repository/Credential_Exposure`
- `internal/services/Credential_Exposure`
- `internal/handlers/Credential_Exposure`

Routes are registered in the existing `internal/routes/routes.go`; dependencies are wired in `cmd/api-server/main.go`.

## Routes

All routes use the existing JWT middleware. Until JWT-to-`client_id` authorization is configured, the handlers require the `admin` role.

- `GET /api/findings` — combined CodeCommit and GitHub findings. Supports `client_id`, `platform`, `ml_flagged`, `limit`, and `offset` query parameters. Overview summaries can be calculated from this response.
- `GET /api/findings/ml-flagged` — compatibility alias for the ML-flagged findings view.
- `GET /api/findings?finding_id=...` — retrieve a finding by its full ID (which may contain `/`).
- `POST /api/findings/decision` — set `analyst_decision`, `analyst_decided_at`, and `analyst_decided_by`.
- `GET`, `POST`, and `DELETE /api/allowlist` — list, upsert, and remove entries in `secscan_allowlist_dashboard`.
- `POST /api/deep-scan` — server-side proxy to the existing scanner aggregator.
- `GET /api/deep-scan-status?client_id=...&repository=...&platform=...` — deep-scan and ledger state. `platform` is optional unless both platform tables match.

The regular findings view excludes dashboard-allowlisted rows and `ml_decision = 'FALSE_POSITIVE'`; the flagged view returns those ML false positives while still excluding dashboard-allowlisted rows. Nullable table columns remain nullable in the JSON model.

## Deep-scan proxy configuration

Set these server-side environment variables:

- `SECRET_SCANNER_BASE_URL` — HTTPS URL for the existing scanner aggregator, e.g. `https://js-dev.adapid.link`.
- `SECRET_SCANNER_DASHBOARD_KEY` — aggregator key. Do not expose this value to browser code or commit it to source control.

The Go API does not enqueue directly into `secscan_jobs_*`; the scanner worker's payload contract is not defined in the supplied database guide.
