import { Fingerprint, Gauge, Globe2, History, KeyRound, Moon, TimerReset } from 'lucide-react';

/**
 * Information architecture. Every item is a screen backed by the NHI API
 * (see docs/WIREFRAMES.md for the endpoint behind each one).
 */
export const NAV_GROUPS = [
  {
    key: 'overview',
    label: 'Overview',
    items: [{ to: '/overview', label: 'Dashboard', icon: Gauge, end: true }],
  },
  {
    key: 'inventory',
    label: 'Inventory',
    items: [
      { to: '/identities', label: 'Identities', icon: Fingerprint },
      { to: '/credentials', label: 'Credentials', icon: KeyRound },
    ],
  },
  {
    key: 'activity',
    label: 'Activity',
    items: [{ to: '/discoveries', label: 'Recent discoveries', icon: History }],
  },
];

/** The navigation a role can use; groups left empty are removed. */
export function navGroupsFor(can) {
  return NAV_GROUPS.map((group) => ({
    ...group,
    items: group.items.filter((item) => !item.permission || can(item.permission)),
  })).filter((group) => group.items.length > 0);
}

/* Views inside the lists, so the command palette can jump straight to them. */
const VIEW_SHORTCUTS = [
  { to: '/credentials?view=expiring', label: 'Expiring credentials', icon: TimerReset, group: 'Credentials' },
  { to: '/credentials?view=stale', label: 'Unused credentials', icon: TimerReset, group: 'Credentials' },
  { to: '/identities?is_public=true', label: 'Internet-exposed identities', icon: Globe2, group: 'Identities' },
  { to: '/identities?view=dormant', label: 'Dormant identities', icon: Moon, group: 'Identities' },
];

export const ALL_NAV_ITEMS = [
  ...NAV_GROUPS.flatMap((group) => group.items.map((item) => ({ ...item, group: group.label }))),
  ...VIEW_SHORTCUTS,
];

/** Breadcrumb trail per route, kept as data so labels match the navigation. */
export const BREADCRUMBS = {
  '/overview': ['Overview', 'Dashboard'],
  '/identities': ['Inventory', 'Identities'],
  '/credentials': ['Inventory', 'Credentials'],
  '/discoveries': ['Activity', 'Recent discoveries'],
};

/** Breadcrumbs for routes with a parameter, matched by prefix. */
export const BREADCRUMB_PREFIXES = [
  { prefix: '/identities/', trail: ['Inventory', 'Identities', 'Identity'] },
  { prefix: '/credentials/', trail: ['Inventory', 'Credentials', 'Credential'] },
];
