import { Link, useSearchParams } from 'react-router-dom';
import { History, Minus, Plus } from 'lucide-react';
import { fetchRecentDiscoveries } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatNumber, parseDate } from '../../lib/format';
import { AnimatedNumber, Page, Reveal, RevealItem, RevealList } from '../../lib/motion';
import { PageHeader } from '../../shell/PageHeader';
import { Select } from '../../ui/Field';
import { Panel } from '../../ui/Panel';
import { ListSkeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { RefreshButton } from '../../ui/TableTools';
import { cn } from '../../ui/cn';
import { ProportionBar } from '../../ui/Meter';
import { tokenLabel } from '../../lib/labels';
import { DiscoveryRow } from './DiscoveryRow';

const WINDOWS = [
  { value: '24', label: '24h', title: 'Last 24 hours', phrase: 'in the last 24 hours' },
  { value: '168', label: '7d', title: 'Last 7 days', phrase: 'in the last 7 days' },
  { value: '720', label: '30d', title: 'Last 30 days', phrase: 'in the last 30 days' },
  { value: '2160', label: '90d', title: 'Last 90 days', phrase: 'in the last 90 days' },
];
const TYPES = [
  { value: 'both', label: 'Everything' },
  { value: 'identities', label: 'Identities' },
  { value: 'credentials', label: 'Credentials' },
];
const EVENTS = ['both', 'new', 'removed'];
const LIMITS = [50, 100, 250, 500];

/**
 * What the scanner added and removed: GET /api/v1/dashboard/recent-discoveries.
 * The totals cover the whole window; the feed is the newest `limit` events.
 * Events carry no record id, so a new one links to its list filtered by ARN
 * and a removed one (no longer listed anywhere) does not link.
 */
export default function DiscoveriesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const hours = WINDOWS.some((entry) => entry.value === searchParams.get('hours')) ? searchParams.get('hours') : '168';
  const type = TYPES.some((entry) => entry.value === searchParams.get('type')) ? searchParams.get('type') : 'both';
  const event = EVENTS.includes(searchParams.get('event')) ? searchParams.get('event') : 'both';
  const limit = LIMITS.includes(Number(searchParams.get('limit'))) ? Number(searchParams.get('limit')) : 100;

  const update = (changes) => {
    const next = new URLSearchParams(searchParams);
    const defaults = { hours: '168', type: 'both', event: 'both', limit: '100' };
    for (const [key, value] of Object.entries(changes)) {
      if (String(value) === defaults[key]) next.delete(key);
      else next.set(key, String(value));
    }
    setSearchParams(next, { replace: true });
  };

  const query = useQuery(
    (signal) => fetchRecentDiscoveries({ hours, type, event, limit }, signal),
    [hours, type, event, limit],
  );
  const data = query.data;
  const items = data?.discoveries ?? [];
  const totalNew = data?.total_new ?? null;
  const totalRemoved = data?.total_removed ?? null;
  const expected = event === 'new' ? totalNew : event === 'removed' ? totalRemoved : (totalNew ?? 0) + (totalRemoved ?? 0);
  const truncated = data && items.length < expected;
  const windowMeta = WINDOWS.find((entry) => entry.value === hours);

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Recent discoveries"
          lede="Identities and credentials the scanner found for the first time, and ones that have gone from AWS since."
          actions={<RefreshButton onRefresh={query.refetch} refreshing={query.isRefreshing} label="Refresh feed" />}
        />
      </Reveal>

      <Reveal className="flex flex-wrap items-center gap-2">
        <SegmentedControl label="Time window" value={hours} onChange={(value) => update({ hours: value })} options={WINDOWS} />
        <SegmentedControl label="Show" value={type} onChange={(value) => update({ type: value })} options={TYPES} />
      </Reveal>

      <Reveal className="grid gap-3 sm:grid-cols-2">
        <EventTile
          kind="new"
          active={event === 'new'}
          value={totalNew}
          phrase={windowMeta.phrase}
          onClick={() => update({ event: event === 'new' ? 'both' : 'new' })}
        />
        <EventTile
          kind="removed"
          active={event === 'removed'}
          value={totalRemoved}
          phrase={windowMeta.phrase}
          onClick={() => update({ event: event === 'removed' ? 'both' : 'removed' })}
        />
      </Reveal>

      {items.length > 0 && (
        <Reveal>
          <WindowShape items={items} />
        </Reveal>
      )}

      <Reveal>
        <Panel flush className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
            <p className="text-[12.5px] text-ink-3" aria-live="polite">
              {!data
                ? 'Loading events…'
                : truncated
                  ? `Newest ${formatNumber(items.length)} of ${formatNumber(expected)} events`
                  : `${formatNumber(items.length)} event${items.length === 1 ? '' : 's'}`}
              {event !== 'both' && data && (
                <button type="button" onClick={() => update({ event: 'both' })} className="ml-2 font-medium text-brand hover:underline">
                  Show all events
                </button>
              )}
            </p>
            <label className="flex items-center gap-2 text-[12.5px] text-ink-3">
              Show up to
              <Select
                size="sm"
                value={String(limit)}
                onChange={(changeEvent) => update({ limit: changeEvent.target.value })}
                options={LIMITS.map((n) => ({ value: String(n), label: String(n) }))}
                className="w-20"
                aria-label="Most events to show"
              />
            </label>
          </div>

          {query.isError && !data ? (
            <ErrorState error={query.error} onRetry={query.refetch} />
          ) : !data ? (
            <div className="p-4">
              <ListSkeleton rows={8} />
            </div>
          ) : items.length === 0 ? (
            <EmptyState
              icon={History}
              title={`No changes ${windowMeta.phrase}`}
              description="Nothing was discovered or removed in this window. Choose a longer window to look further back."
            />
          ) : (
            <>
              {query.isError && (
                <div className="p-3">
                  <InlineError error={query.error} onRetry={query.refetch} label="Could not refresh" />
                </div>
              )}
              <Feed items={items} />
              {truncated && limit < 500 && (
                <div className="border-t border-line px-4 py-3 text-center">
                  <button
                    type="button"
                    onClick={() => update({ limit: LIMITS.find((n) => n > limit) })}
                    className="text-[12.5px] font-medium text-brand hover:underline"
                  >
                    Show up to {LIMITS.find((n) => n > limit)} events
                  </button>
                </div>
              )}
            </>
          )}
        </Panel>
      </Reveal>
    </Page>
  );
}

function EventTile({ kind, active, value, phrase, onClick }) {
  const isNew = kind === 'new';
  const Icon = isNew ? Plus : Minus;
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'group flex items-center gap-4 rounded-[var(--radius-panel)] border bg-surface p-4 text-left shadow-sm transition-[border-color,box-shadow,transform] duration-200 hover:-translate-y-px hover:shadow-md',
        active ? (isNew ? 'border-low/60 ring-2 ring-low/20' : 'border-ink-3/60 ring-2 ring-ink-3/15') : 'border-line',
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'grid size-10 shrink-0 place-items-center rounded-full border',
          isNew ? 'border-low/25 bg-low-soft text-low' : 'border-line-strong bg-surface-3 text-ink-3',
        )}
      >
        <Icon className="size-4.5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[12px] font-medium text-ink-3">{isNew ? 'Discovered' : 'Removed'}</span>
        <AnimatedNumber value={value} className="block font-display text-[26px] leading-tight font-bold text-ink" />
        <span className="block text-[11.5px] text-ink-3">{phrase}</span>
      </span>
      <span className="shrink-0 text-[11.5px] font-medium text-ink-3 group-hover:text-ink-2">{active ? 'Filtered' : 'Filter'}</span>
    </button>
  );
}

/** Events grouped by calendar day, newest first, as the API orders them. */
function Feed({ items }) {
  const groups = [];
  for (const item of items) {
    const label = dayLabel(item.discovered_at);
    const last = groups.at(-1);
    if (last && last.label === label) last.items.push(item);
    else groups.push({ label, items: [item] });
  }
  return (
    <div className="divide-y divide-line">
      {groups.map((group) => (
        <section key={group.label} aria-label={group.label} className="px-3 py-2 sm:px-4">
          <h3 className="sticky top-0 z-[1] bg-surface py-1.5 text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
            {group.label} <span className="font-medium normal-case tracking-normal">· {formatNumber(group.items.length)}</span>
          </h3>
          <RevealList className="divide-y divide-line/70">
            {group.items.map((item, index) => (
              <RevealItem index={index} key={`${item.event}-${item.entity}-${item.arn}-${index}`}>
                {item.event === 'new' && item.arn ? (
                  <Link
                    to={`/${item.entity === 'identity' ? 'identities' : 'credentials'}?search=${encodeURIComponent(item.arn)}`}
                    className="block rounded-md transition-colors hover:bg-surface-2"
                    title="Find this record in the inventory"
                  >
                    <DiscoveryRow item={item} />
                  </Link>
                ) : (
                  <DiscoveryRow item={item} />
                )}
              </RevealItem>
            ))}
          </RevealList>
        </section>
      ))}
    </div>
  );
}

function dayLabel(value) {
  const date = parseDate(value);
  if (!date) return 'Unknown date';
  const start = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diff = Math.round((start(new Date()) - start(date)) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  return date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: date.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
}

/**
 * What the loaded events are made of (reference console's "shape of the
 * loaded window"): identities against credentials, and where and what they
 * are. Worked out from the events on screen, and labelled as such - the API
 * returns totals for the window but no breakdown.
 */
function WindowShape({ items }) {
  const identities = items.filter((item) => item.entity === 'identity').length;
  const credentials = items.length - identities;
  const top = (key, label) =>
    Object.entries(
      items.reduce((acc, item) => {
        const value = label(item[key]);
        if (value) acc[value] = (acc[value] ?? 0) + 1;
        return acc;
      }, {}),
    )
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  const accounts = top('account_id', (value) => value);
  const types = top('type', (value) => (value ? tokenLabel(value) : null));
  const max = Math.max(1, ...accounts.map(([, n]) => n), ...types.map(([, n]) => n));
  return (
    <Panel>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h2 className="text-[14px] font-semibold text-ink">Shape of these events</h2>
        <span className="text-[11.5px] text-ink-3">Worked out from the {formatNumber(items.length)} events loaded below</span>
      </div>
      <div className="mt-4 grid gap-6 @min-[52rem]:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <div>
          <p className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Identities and credentials</p>
          <ProportionBar
            className="mt-3"
            segments={[
              { key: 'identity', label: 'Identities', value: identities, color: 'var(--t-brand)' },
              { key: 'credential', label: 'Credentials', value: credentials, color: 'var(--t-series-2)' },
            ]}
          />
          <p className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-ink-2">
            <span className="inline-flex items-center gap-1.5">
              <span aria-hidden="true" className="size-2.5 rounded-[3px] bg-brand" /> Identities <b className="text-ink">{formatNumber(identities)}</b>
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span aria-hidden="true" className="size-2.5 rounded-[3px]" style={{ background: 'var(--t-series-2)' }} /> Credentials <b className="text-ink">{formatNumber(credentials)}</b>
            </span>
          </p>
        </div>
        <TopList title="Busiest accounts" rows={accounts} max={max} mono />
        <TopList title="Most common types" rows={types} max={max} />
      </div>
    </Panel>
  );
}

function TopList({ title, rows, max, mono }) {
  return (
    <div className="min-w-0">
      <p className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{title}</p>
      <ul className="mt-2 flex flex-col gap-1.5">
        {rows.map(([label, count]) => (
          <li key={label} className="flex items-center gap-3 text-[12px]">
            <span className={cn('w-[46%] min-w-0 truncate text-ink-2', mono && 'font-mono text-[11.5px]')} title={label}>
              {label}
            </span>
            <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[var(--t-track)]">
              <span className="block h-full rounded-full bg-brand" style={{ width: `${(count / max) * 100}%` }} />
            </span>
            <span data-numeric="" className="w-6 text-right font-semibold text-ink">
              {count}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
