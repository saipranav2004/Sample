import { Minus, Plus } from 'lucide-react';
import { formatDateTime, formatRelative } from '../../lib/format';
import { credentialBadge, identityBadge, regionLabel, tokenLabel } from '../../lib/labels';
import { TypeBadge } from '../../ui/TypeBadge';
import { Tag } from '../../ui/Tag';
import { cn } from '../../ui/cn';

/** One discovered or removed identity or credential, as the feed shows it. */
export function DiscoveryRow({ item }) {
  const isNew = item.event === 'new';
  const identity = item.entity === 'identity';
  return (
    <span className="flex min-w-0 items-center gap-3 px-1 py-2.5">
      {/* What it is, with a corner mark for what happened to it. */}
      <span aria-hidden="true" className="relative shrink-0">
        <TypeBadge
          code={identity ? identityBadge(item.type) : credentialBadge(item.type).code}
          color={identity ? 'var(--t-brand)' : credentialBadge(item.type).color}
          className={cn(!isNew && 'opacity-60 grayscale')}
        />
        <span
          className={cn(
            'absolute -right-1 -bottom-1 grid size-4 place-items-center rounded-full border-2 border-surface',
            isNew ? 'bg-low text-white' : 'bg-ink-3 text-white',
          )}
        >
          {isNew ? <Plus className="size-2.5" strokeWidth={3} /> : <Minus className="size-2.5" strokeWidth={3} />}
        </span>
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex min-w-0 items-center gap-2">
          <span className="truncate text-[13px] font-semibold text-ink">{item.name || item.arn || 'Unnamed'}</span>
          <Tag size="sm" tone={identity ? 'brand' : 'info'}>
            {identity ? 'Identity' : 'Credential'}
          </Tag>
        </span>
        <span className="mt-0.5 block truncate text-[11.5px] text-ink-3">
          {[tokenLabel(item.type), item.account_id, regionLabel(item.region)].filter((part) => part && part !== '-').join(' · ')}
        </span>
      </span>
      <span className="shrink-0 text-right text-[11.5px] text-ink-3">
        <span className={cn('block font-semibold', isNew ? 'text-low' : 'text-ink-2')}>{isNew ? 'Discovered' : 'Removed'}</span>
        <time dateTime={item.discovered_at} title={formatDateTime(item.discovered_at)}>
          {formatRelative(item.discovered_at)}
        </time>
      </span>
    </span>
  );
}
