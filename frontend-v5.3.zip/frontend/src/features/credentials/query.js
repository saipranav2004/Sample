/**
 * The credential list's URL state, validated against what
 * GET /api/v1/inventory/credentials accepts, so a stale or hand-edited link
 * never turns the screen into a 400.
 */

export const SORTABLE = [
  'name',
  'credential_type',
  'account_id',
  'region',
  'status',
  'created_at_aws',
  'last_used_at',
  'last_rotated_at',
  'expires_at',
  'privilege_level',
];

/* The export route accepts a slightly different set of sort columns. */
export const EXPORT_SORTABLE = new Set([
  'name',
  'credential_type',
  'account_id',
  'region',
  'status',
  'created_at_aws',
  'last_used_at',
  'expires_at',
  'privilege_level',
]);

export const PAGE_SIZES = [25, 50, 100];
export const DEFAULT_LIMIT = 25;

export const FILTER_KEYS = [
  'search',
  'credential_type',
  'account_id',
  'region',
  'status',
  'rotation_enabled',
  'expiring_within_days',
  'stale_days',
  'privilege_level_min',
  'privilege_level_max',
  'owner_principal_arn',
];

const ACCOUNT = /^[0-9]{12}$/;
const REGION = /^[a-z0-9-]{1,64}$/;
const TOKEN = /^[a-zA-Z0-9_-]{1,100}$/;

function cleanText(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  return text.length > 512 || /[\0\r\n]/.test(text) ? '' : text;
}

function intIn(value, min, max) {
  if (value === '' || value === null || value === undefined) return '';
  const n = Number(value);
  return Number.isInteger(n) && n >= min && n <= max ? String(n) : '';
}

export function readListState(searchParams) {
  const get = (key) => cleanText(searchParams.get(key) ?? '');
  const filters = {
    search: get('search').slice(0, 256),
    credential_type: TOKEN.test(get('credential_type')) ? get('credential_type') : '',
    account_id: ACCOUNT.test(get('account_id')) ? get('account_id') : '',
    region: REGION.test(get('region')) ? get('region') : '',
    status: TOKEN.test(get('status')) ? get('status') : '',
    rotation_enabled: ['true', 'false'].includes(get('rotation_enabled')) ? get('rotation_enabled') : '',
    expiring_within_days: intIn(get('expiring_within_days'), 1, 36500),
    stale_days: intIn(get('stale_days'), 1, 36500),
    privilege_level_min: intIn(get('privilege_level_min'), 0, 10),
    privilege_level_max: intIn(get('privilege_level_max'), 0, 10),
    owner_principal_arn: get('owner_principal_arn').startsWith('arn:') ? get('owner_principal_arn') : '',
  };
  if (filters.privilege_level_min && filters.privilege_level_max && Number(filters.privilege_level_min) > Number(filters.privilege_level_max)) {
    filters.privilege_level_max = '';
  }
  const sortBy = SORTABLE.includes(get('sort_by')) ? get('sort_by') : 'created_at_aws';
  const sortOrder = get('sort_order') === 'asc' ? 'asc' : 'desc';
  const page = Number(get('page'));
  return {
    filters,
    page: Number.isInteger(page) && page >= 1 && page <= 1_000_000 ? page : 1,
    limit: PAGE_SIZES.includes(Number(get('limit'))) ? Number(get('limit')) : DEFAULT_LIMIT,
    sort: { key: sortBy, direction: sortOrder },
  };
}

export function appliedCount(filters) {
  /* The two privilege bounds are one filter on screen. */
  return FILTER_KEYS.filter((key) => filters[key] && key !== 'privilege_level_max').length +
    (filters.privilege_level_max && !filters.privilege_level_min ? 1 : 0);
}
