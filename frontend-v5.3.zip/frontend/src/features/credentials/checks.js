import { formatDateTime, formatRelative, parseDate } from '../../lib/format';
import { flagLabel } from '../../lib/labels';
import { NEXT_STEP } from './flags';

/*
 * Every hygiene check the API runs (GET /credentials/{id}/hygiene), with the
 * condition under which it runs, taken from the API's own rules. A check that
 * ran and raised no flag is Clear; one that does not apply to this credential
 * is left out rather than shown as passing.
 */
const CHECKS = [
  { flag: 'expired', label: 'Not expired', applies: (c) => Boolean(c.expires_at) },
  { flag: 'unused_90d', label: 'Used in the last 90 days', applies: () => true },
  { flag: 'not_rotated_90d', label: 'Rotated in the last 90 days', applies: (c) => Boolean(c.last_rotated_at) },
  { flag: 'rotation_disabled', label: 'Automatic rotation on', applies: (c) => c.rotation_enabled === true || c.rotation_enabled === false },
  { flag: 'high_privilege', label: 'Privilege below 8 of 10', applies: (c) => c.credential_type === 'iam_role' },
  { flag: 'no_permission_boundary', label: 'Permission boundary attached', applies: (c) => c.credential_type === 'iam_role' },
  { flag: 'no_attached_policies', label: 'Has attached policies', applies: (c) => c.credential_type === 'iam_role' },
  { flag: 'wildcard_action', label: 'No wildcard action in the trust policy', applies: (c) => c.credential_type === 'iam_role' },
];

/* The API returns the same fixed detail for every wildcard_action flag, so it
   says nothing about this credential and is not shown. */
const UNRELIABLE_DETAIL = new Set(['wildcard_action']);

function detailText(flag) {
  if (!flag?.detail || UNRELIABLE_DETAIL.has(flag.flag)) return null;
  return String(flag.detail).replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z/g, (stamp) => formatDateTime(stamp));
}

export function credentialChecks(credential, flags = []) {
  const byFlag = new Map(flags.map((flag) => [flag.flag, flag]));
  const checks = CHECKS.filter((check) => check.applies(credential) || byFlag.has(check.flag)).map((check) => {
    const flag = byFlag.get(check.flag);
    if (flag) {
      return { key: check.flag, label: check.label, result: 'failing', severity: flag.severity, detail: detailText(flag), next: NEXT_STEP[check.flag] };
    }
    return { key: check.flag, label: check.label, result: 'clear', detail: clearDetail(check.flag, credential) };
  });
  /* A flag this console does not know yet still shows, as failing. */
  for (const flag of flags) {
    if (!CHECKS.some((check) => check.flag === flag.flag)) {
      checks.push({ key: flag.flag, label: flagLabel(flag.flag), result: 'failing', severity: flag.severity, detail: detailText(flag), next: NEXT_STEP[flag.flag] });
    }
  }
  return checks;
}

function clearDetail(flag, c) {
  if (flag === 'unused_90d' && c.last_used_at) return `Last used ${formatRelative(c.last_used_at)}`;
  if (flag === 'not_rotated_90d' && c.last_rotated_at) return `Last rotated ${formatRelative(c.last_rotated_at)}`;
  if (flag === 'expired' && parseDate(c.expires_at)) return `Expires ${formatRelative(c.expires_at)}`;
  return null;
}
