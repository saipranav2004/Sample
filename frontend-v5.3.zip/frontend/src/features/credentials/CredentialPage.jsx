import { useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle,
  CalendarClock,
  ArrowLeft,
  ArrowRight,
  FileLock2,
  Globe2,
  KeyRound,
  ListTree,
  Pencil,
  ShieldAlert,
  ShieldCheck,
  UserRoundCheck,
} from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchAttachedPolicies, fetchCredential, fetchCredentialFlags, fetchTrustPolicy, isUuid } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatDate, formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import { credentialBadge, credentialTypeLabel, healthMeta, privilegeMeta, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Meter } from '../../ui/Meter';
import { AccessChain } from '../../ui/AccessChain';
import { LifeTimeline } from '../../ui/LifeTimeline';
import { FactsCard } from '../../ui/FactsCard';
import { StatusChecks, checkSummary } from '../../ui/StatusChecks';
import { TypeBadge } from '../../ui/TypeBadge';
import { RelatedLinks } from '../../ui/RelatedLinks';
import { credentialChecks } from './checks';
import { DetailList, DetailRow, Panel, PanelHeader } from '../../ui/Panel';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { AttributeList, JsonBlock } from '../identities/JsonView';
import { EditCredentialDialog } from './EditCredentialDialog';
import { TagChips } from './parts';

/**
 * One credential: `GET /api/v1/inventory/credentials/{id}` plus its hygiene
 * flags, and for IAM roles the parsed trust policy and attached policies.
 *
 * The API answers 500 (not 404) for an id it does not hold and for anything
 * that is not a UUID, so the id is checked here first and a missing record
 * is told apart from a server fault by that check.
 */
export default function CredentialPage() {
  const { id } = useParams();
  const validId = isUuid(id);
  const [searchParams, setSearchParams] = useSearchParams();
  const { can, lock } = useAccess();
  const [editing, setEditing] = useState(false);

  const detail = useQuery((signal) => fetchCredential(id, signal), [id], { enabled: validId });
  const credential = detail.data;
  const isRole = credential?.credential_type === 'iam_role';

  const tabs = [
    { value: 'overview', label: 'Overview', icon: KeyRound },
    ...(isRole ? [{ value: 'access', label: 'Permissions and trust', icon: FileLock2 }] : []),
    { value: 'attributes', label: 'Attributes', icon: ListTree },
  ];
  /* Hygiene used to be its own tab; its findings now open the overview, so
     old links to ?tab=hygiene land there. */
  const requested = searchParams.get('tab') === 'hygiene' ? 'overview' : searchParams.get('tab') || 'overview';
  const tab = !credential || tabs.some((entry) => entry.value === requested) ? requested : 'overview';

  /* Hygiene is small and feeds the header, so it loads with the record. */
  const hygiene = useQuery((signal) => fetchCredentialFlags(id, signal), [id], { enabled: validId && Boolean(credential) });
  const trust = useQuery((signal) => fetchTrustPolicy(id, signal), [id], { enabled: validId && isRole });
  const policies = useQuery((signal) => fetchAttachedPolicies(id, signal), [id], { enabled: validId && isRole });

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/credentials" icon={ArrowLeft}>
      Credentials
    </Button>
  );

  if (!validId || (detail.isError && !credential)) {
    /* A 404 never comes back from this route; a well-formed id that fails is
       most likely gone, but a real fault must stay retryable. */
    const missing = !validId || detail.error?.status === 404;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Credential" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={KeyRound}
              title="No credential with that id"
              description="The link is incomplete, or the credential was removed by a later discovery run. Find it again from Credentials."
              action={back}
            />
          ) : (
            <ErrorState
              error={detail.error}
              onRetry={detail.refetch}
              title="This credential could not be loaded"
            />
          )}
        </Panel>
      </div>
    );
  }

  if (!credential) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} />
        <Panel prominence="lead">
          <DetailSkeleton rows={8} />
        </Panel>
        <span role="status" className="sr-only">
          Loading credential
        </span>
      </div>
    );
  }

  const status = statusMeta(credential.status);
  const health = hygiene.data ? healthMeta(hygiene.data.overall_health) : null;
  const expiresAt = parseDate(credential.expires_at);
  const expired = expiresAt && expiresAt.getTime() < Date.now();

  return (
    <Page className="flex flex-col gap-6">
      <Reveal>
        <PageHeader
          title={
            <span className="flex min-w-0 items-center gap-3">
              <TypeBadge size="lg" code={credentialBadge(credential.credential_type).code} color={credentialBadge(credential.credential_type).color} title={credentialTypeLabel(credential.credential_type)} />
              <span className="block min-w-0 truncate font-mono">{credential.name || credential.arn}</span>
            </span>
          }
          lede={credentialSummary(credential)}
          actions={
            <>
              <Button variant="secondary" as={Link} to="/credentials" icon={ArrowLeft}>
                Credentials
              </Button>
              {credential.owner_principal_arn && (
                <Button variant="secondary" as={Link} to={`/credentials?owner_principal_arn=${encodeURIComponent(credential.owner_principal_arn)}`}>
                  Everything {String(credential.owner_principal_arn).split(':').pop()} holds
                </Button>
              )}
              <Button variant="primary" icon={Pencil} onClick={() => setEditing(true)} locked={lock('credential.edit')}>
                Edit ownership
              </Button>
            </>
          }
          meta={
            <div className="flex flex-wrap items-center gap-2">
              <Tag tone={status.tone} dot>
                {status.label}
              </Tag>
              {health ? (
                <Tag tone={health.tone} icon={hygiene.data.overall_health === 'healthy' ? ShieldCheck : ShieldAlert}>
                  {hygiene.data.overall_health === 'healthy'
                    ? 'Healthy'
                    : `${health.label} · ${hygiene.data.flags.length} flag${hygiene.data.flags.length === 1 ? '' : 's'}`}
                </Tag>
              ) : hygiene.isLoading ? (
                <Skeleton className="h-6 w-28 rounded-full" />
              ) : null}
              {expired && <Tag tone="critical">Expired {formatRelative(credential.expires_at)}</Tag>}
              <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
                <CopyableValue value={credential.arn} />
              </span>
            </div>
          }
          tabs={<Tabs size="sm" tabs={tabs} value={tab} onChange={setTab} />}
        />
      </Reveal>

      <Reveal key={tab}>
        {tab === 'overview' && (
          <OverviewTab credential={credential} hygiene={hygiene} trust={trust} policies={policies} isRole={isRole} onOpenAccess={() => setTab('access')} />
        )}
        {tab === 'access' && isRole && <AccessTab credential={credential} trust={trust} policies={policies} />}
        {tab === 'attributes' && (
          <Panel>
            <PanelHeader
              title={`${credentialTypeLabel(credential.credential_type)} attributes`}
              subtitle="Type-specific fields the scanner recorded for this credential."
            />
            <div className="mt-3">
              <AttributeList
                value={credential.type_attributes}
                emptyTitle="No type-specific attributes"
                emptyText="The scanner recorded no extra attributes for this credential."
              />
            </div>
          </Panel>
        )}
      </Reveal>

      <EditCredentialDialog
        open={editing && can('credential.edit')}
        credential={credential}
        onClose={() => setEditing(false)}
        onSaved={() => {
          setEditing(false);
          detail.refetch();
        }}
      />
    </Page>
  );
}

function When({ value, fallback = '-' }) {
  if (!value) return <span className="text-ink-3">{fallback}</span>;
  return (
    <span title={formatDateTime(value)}>
      {formatDateTime(value)} <span className="text-ink-3">· {formatRelative(value)}</span>
    </span>
  );
}

function Missing({ children = 'Not recorded' }) {
  return <span className="text-ink-3">{children}</span>;
}

/** One plain sentence: what it is, who owns it, and where it stands. */
function credentialSummary(credential) {
  const owner = credential.owner_principal_arn ? credential.owner_principal_arn.split(':').pop() : null;
  const parts = [
    `${credentialTypeLabel(credential.credential_type)} in account ${credential.account_id} (${regionLabel(credential.region)})`,
    owner ? 'owned by ' : 'with no owner recorded',
  ];
  const facts = [];
  facts.push(credential.last_used_at ? `last used ${formatRelative(credential.last_used_at)}` : 'no recorded use');
  if (credential.last_rotated_at) facts.push(`last rotated ${formatRelative(credential.last_rotated_at)}`);
  const expires = parseDate(credential.expires_at);
  if (!expires) facts.push('does not expire');
  else facts.push(expires.getTime() < Date.now() ? `expired ${formatRelative(credential.expires_at)}` : `expires ${formatRelative(credential.expires_at)}`);
  /* The owner name stays on one line: a hyphen in it is not a place to wrap. */
  return (
    <>
      {parts.join(', ')}
      {owner && <span className="whitespace-nowrap">{owner}</span>}. {facts.join(', ').replace(/^./, (c) => c.toUpperCase())}.
    </>
  );
}

const DAY = 86_400_000;

function lifecycleGaps(credential, now) {
  const gaps = [];
  const used = parseDate(credential.last_used_at);
  if (used) {
    const days = Math.floor((now - used.getTime()) / DAY);
    if (days >= 30) gaps.push({ from: credential.last_used_at, to: 'now', label: `Not used for ${days} days`, tone: days >= 90 ? 'high' : 'medium' });
  }
  const expires = parseDate(credential.expires_at);
  if (expires) {
    const days = Math.round((expires.getTime() - now) / DAY);
    if (days < 0) gaps.push({ from: credential.expires_at, to: 'now', label: `Expired ${-days} days ago`, tone: 'critical' });
    else if (days <= 90) gaps.push({ from: 'now', to: credential.expires_at, label: `Expires in ${days} days`, tone: days <= 30 ? 'critical' : 'high' });
  }
  return gaps;
}

function OverviewTab({ credential, hygiene, trust, policies, isRole, onOpenAccess }) {
  const discovery = credential.discovery ?? {};
  const owner = credential.owner_principal_arn;
  const [now] = useState(() => Date.now());
  const expires = parseDate(credential.expires_at);
  const role = credential.iam_role_details ?? {};
  const level = Number(role.privilege_level);
  const boundaryArn = policies.data?.permission_boundary ?? role.permission_boundary_arn;
  const checks = hygiene.data ? credentialChecks(credential, hygiene.data.flags) : [];
  return (
    <div className="flex flex-col gap-4">
      {/* 1. The record at a glance (reference console). */}
      <FactsCard
        facts={[
          { label: 'What it is', value: credentialTypeLabel(credential.credential_type), sub: `${regionLabel(credential.region)} · account ${credential.account_id}` },
          { label: 'Held by', value: owner ? String(owner).split(':').pop() : null, mono: Boolean(owner), sub: owner ? 'Owner principal' : 'No owner recorded' },
          isRole
            ? {
                label: 'Privilege',
                value: Number.isFinite(level) ? `${level} of 10 · ${privilegeMeta(level).label}` : 'Not scored',
                tone: Number.isFinite(level) && level >= 6 ? privilegeMeta(level).tone : undefined,
                sub: boundaryArn ? `Boundary: ${String(boundaryArn).split('/').pop()}` : 'No permission boundary',
              }
            : { label: 'Status', value: statusMeta(credential.status).label, sub: `Last confirmed ${formatRelative(credential.last_seen_at)}` },
          { label: 'Last used', value: credential.last_used_at ? formatRelative(credential.last_used_at) : null, sub: credential.last_used_at ? formatDateTime(credential.last_used_at) : 'No recorded use' },
          {
            label: 'Rotation',
            value: credential.rotation_enabled === true ? 'Automatic' : credential.rotation_enabled === false ? 'Turned off' : 'Not managed',
            tone: credential.rotation_enabled === false ? 'high' : undefined,
            sub: [credential.rotation_interval_days ? `every ${formatNumber(credential.rotation_interval_days)} days` : null, credential.last_rotated_at ? `last ${formatDate(credential.last_rotated_at)}` : 'never rotated'].filter(Boolean).join(' · '),
          },
          {
            label: 'Expires',
            value: expires ? (expires.getTime() < now ? `Expired ${formatRelative(credential.expires_at)}` : formatRelative(credential.expires_at)) : 'Does not expire',
            tone: expires && expires.getTime() - now < 30 * DAY ? 'critical' : undefined,
            sub: expires ? formatDateTime(credential.expires_at) : isRole && role.max_session_duration ? `Max session ${formatDuration(role.max_session_duration)}` : undefined,
          },
        ]}
      />

      {/* 2. Every check the API runs on it: what fails, and what is fine. */}
      <div className="grid gap-4 @min-[60rem]:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
        <Panel prominence="lead">
          <PanelHeader title="Status checks" subtitle={hygiene.data ? checkSummary(checks) : 'Hygiene checks on this credential'} icon={ShieldAlert} />
          <div className="mt-2">
            {hygiene.isError && !hygiene.data ? (
              <ErrorState compact error={hygiene.error} onRetry={hygiene.refetch} />
            ) : !hygiene.data ? (
              <ListSkeleton rows={3} />
            ) : (
              <StatusChecks checks={checks} />
            )}
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Tags" subtitle="Edit ownership changes these in the inventory, not in AWS." />
          <div className="mt-3">
            <TagChips tags={credential.tags} />
          </div>
          <h3 className="mt-5 mb-1 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Related</h3>
          <RelatedLinks
            links={[
              owner && { to: `/credentials?owner_principal_arn=${encodeURIComponent(owner)}`, label: `Everything ${String(owner).split(':').pop()} holds`, hint: 'Same owner principal' },
              { to: `/credentials?credential_type=${encodeURIComponent(credential.credential_type)}`, label: `Every ${credentialTypeLabel(credential.credential_type)}`, hint: 'Same type' },
              { to: `/credentials?account_id=${encodeURIComponent(credential.account_id)}`, label: `Credentials in ${credential.account_id}`, hint: 'Same account' },
              isRole && { to: `/credentials?credential_type=iam_role&privilege_level_min=7`, label: 'High-privilege IAM roles', hint: 'Privilege 7 or above' },
            ]}
          />
        </Panel>
      </div>

      {/* 3. Is it safe to act: when it was last used, and its clock. */}
      <Panel>
        <PanelHeader
          title="Lifecycle"
          subtitle="Its life on one line. A long gap since last use is the case for disabling it; an expiry close to today, for renewing it."
          icon={CalendarClock}
        />
        <div className="mt-5">
          <LifeTimeline
            now={now}
            events={[
              { key: 'created', label: 'Created in AWS', at: credential.created_at_aws },
              { key: 'discovered', label: 'First discovered', at: credential.first_seen_at, tone: 'neutral' },
              { key: 'rotated', label: 'Last rotated', at: credential.last_rotated_at, tone: 'info' },
              { key: 'used', label: 'Last used', at: credential.last_used_at, tone: 'low' },
              ...(expires ? [{ key: 'expires', label: expires.getTime() < now ? 'Expired' : 'Expires', at: credential.expires_at, tone: 'critical' }] : []),
            ]}
            gaps={lifecycleGaps(credential, now)}
          />
        </div>
      </Panel>

      {/* 4. How bad if misused: who can use it and what it can do. */}
      {isRole && <AccessSummary credential={credential} trust={trust} policies={policies} onOpenAccess={onOpenAccess} />}

      {/* 5. How it was found (reference console). */}
      <Panel prominence="quiet">
        <PanelHeader title="How it was found" prominence="quiet" />
        <DetailList className="mt-2">
          <DetailRow label="Source">
            {discovery.discovery_source ? tokenLabel(discovery.discovery_source) : <Missing />}
            {discovery.scan_id && <span className="ml-2 font-mono text-[12px] text-ink-3">{discovery.scan_id}</span>}
          </DetailRow>
          <DetailRow label="First discovered">
            <When value={credential.first_seen_at} />
          </DetailRow>
          <DetailRow label="Last confirmed">
            <When value={credential.last_seen_at} />
          </DetailRow>
          {owner && (
            <DetailRow label="Owner principal" mono>
              <CopyableValue value={owner} />
            </DetailRow>
          )}
          <DetailRow label="ID" mono>
            <CopyableValue value={credential.id} />
          </DetailRow>
        </DetailList>
      </Panel>
    </div>
  );
}

/** Who can assume the role, the role, what it grants, and where it can go next. */
function AccessSummary({ credential, trust, policies, onOpenAccess }) {
  const role = credential.iam_role_details ?? {};
  const level = Number(role.privilege_level);
  const privilege = privilegeMeta(level);
  const assumable = Array.isArray(role.assumable_role_arns) ? role.assumable_role_arns : [];
  const loading = (!trust.data && !trust.isError) || (!policies.data && !policies.isError);

  const statements = Array.isArray(trust.data?.trust_policy?.statements) ? trust.data.trust_policy.statements : [];
  const risk = trust.data?.trust_policy?.risk_summary ?? {};
  const trustRisky = risk.is_public || risk.has_wildcard_principal;
  const managed = Array.isArray(policies.data?.managed_policies) ? policies.data.managed_policies : [];
  const inline = Array.isArray(policies.data?.inline_policies) ? policies.data.inline_policies : [];
  const broad = managed.reduce((sum, policy) => sum + (Array.isArray(policy.risky_statements) ? policy.risky_statements.length : 0), 0);
  const boundary = policies.data?.permission_boundary ?? role.permission_boundary_arn;

  return (
    <Panel>
      <PanelHeader
        title="Access"
        subtitle="Who can take on this role, and what it can then do. Read left to right; a coloured step is where the risk is."
        icon={FileLock2}
        actions={
          <Button variant="secondary" size="sm" iconRight={ArrowRight} onClick={onOpenAccess}>
            Policies and trust
          </Button>
        }
      />
      <div className="mt-3">
        {loading ? (
          <ListSkeleton rows={2} />
        ) : (
          <AccessChain
            links={['can assume', 'grants', 'can assume']}
            steps={[
              {
                key: 'trust',
                label: 'Who can assume it',
                tone: trustRisky ? 'critical' : undefined,
                empty: trust.isError ? 'Trust policy could not be loaded' : 'No trust statements recorded',
                items: statements.map((statement) => ({
                  title: statement.principal_value || 'Unknown principal',
                  meta: [statement.principal_type, statement.conditions?.length ? `${statement.conditions.length} condition${statement.conditions.length === 1 ? '' : 's'}` : 'no conditions'].filter(Boolean).join(' · '),
                  mono: true,
                  tone: statement.principal_value === '*' ? 'critical' : undefined,
                })),
              },
              {
                key: 'self',
                label: 'This role',
                self: true,
                items: [
                  { title: credential.name || credential.arn, meta: Number.isFinite(level) ? `Privilege ${level} of 10 · ${privilege.label}` : 'Privilege not scored' },
                  {
                    title: boundary ? 'Permission boundary set' : 'No permission boundary',
                    meta: boundary ? String(boundary).split('/').pop() : 'Nothing caps what it can be granted',
                    tone: boundary ? undefined : 'high',
                  },
                ],
              },
              {
                key: 'grants',
                label: 'What it can do',
                tone: broad > 0 ? 'high' : undefined,
                empty: policies.isError ? 'Policies could not be loaded' : 'No policies attached',
                items: [
                  ...managed.map((policy) => {
                    const n = Array.isArray(policy.risky_statements) ? policy.risky_statements.length : 0;
                    return { title: policy.name || 'Unnamed policy', meta: n ? `${n} broad statement${n === 1 ? '' : 's'}` : `${formatNumber(policy.statement_count)} statement${policy.statement_count === 1 ? '' : 's'}`, tone: n ? 'high' : undefined };
                  }),
                  ...(inline.length ? [{ title: `${inline.length} inline polic${inline.length === 1 ? 'y' : 'ies'}`, meta: 'Statements not recorded by the API' }] : []),
                ],
              },
              {
                key: 'next',
                label: 'Roles it can assume',
                empty: 'None',
                items: assumable.map((arn) => ({ title: String(arn).split('/').pop(), meta: String(arn).split(':')[4] ? `account ${String(arn).split(':')[4]}` : undefined, mono: true })),
              },
            ]}
          />
        )}
      </div>
    </Panel>
  );
}

function AccessTab({ credential, trust, policies }) {
  const role = credential.iam_role_details ?? {};
  const level = Number(role.privilege_level);
  const privilege = privilegeMeta(level);
  const assumable = Array.isArray(role.assumable_role_arns) ? role.assumable_role_arns : [];

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-4 @min-[60rem]:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <Panel>
          <PanelHeader title="Role settings" />
          <div className="mt-3 flex items-end justify-between gap-3">
            <div>
              <p className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Privilege level</p>
              <p data-numeric="" className="mt-1 font-display text-[26px] leading-none font-bold text-ink">
                {Number.isFinite(level) ? level : '-'}
                <span className="text-[13px] font-medium text-ink-3"> / 10</span>
              </p>
            </div>
            <Tag tone={privilege.tone}>{privilege.label}</Tag>
          </div>
          <Meter className="mt-3" value={Number.isFinite(level) ? level * 10 : 0} tone={privilege.tone} label={`Privilege level ${level} of 10`} />
          <DetailList className="mt-4">
            <DetailRow label="Max session">
              {role.max_session_duration ? formatDuration(role.max_session_duration) : <Missing>Not reported</Missing>}
            </DetailRow>
            <DetailRow label="Permission boundary" mono>
              {role.permission_boundary_arn ? <CopyableValue value={role.permission_boundary_arn} /> : <span className="font-sans text-high">None. Nothing caps this role's permissions.</span>}
            </DetailRow>
            <DetailRow label="Can assume" mono>
              {assumable.length === 0 ? (
                <Missing>No other roles</Missing>
              ) : (
                <ul className="flex flex-col gap-1">
                  {assumable.map((arn) => (
                    <li key={arn}>
                      <CopyableValue value={arn} />
                    </li>
                  ))}
                </ul>
              )}
            </DetailRow>
          </DetailList>
        </Panel>

        <TrustPanel query={trust} />
      </div>

      <PoliciesPanel query={policies} />
    </div>
  );
}

function formatDuration(seconds) {
  const s = Number(seconds);
  if (!Number.isFinite(s) || s <= 0) return '-';
  const hours = Math.floor(s / 3600);
  const minutes = Math.round((s % 3600) / 60);
  if (hours && minutes) return `${hours} h ${minutes} min`;
  if (hours) return `${hours} hour${hours === 1 ? '' : 's'}`;
  return `${minutes} min`;
}

function TrustPanel({ query }) {
  const body = (() => {
    if (query.isError && !query.data) return <ErrorState compact error={query.error} onRetry={query.refetch} />;
    if (!query.data) return <ListSkeleton rows={2} />;
    const policy = query.data.trust_policy ?? {};
    const statements = Array.isArray(policy.statements) ? policy.statements : [];
    const risk = policy.risk_summary ?? {};
    return (
      <>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <RiskChip on={risk.is_public} icon={Globe2} label="Anyone can assume" off="Not public" />
          <RiskChip on={risk.has_wildcard_principal} label="Wildcard principal" off="No wildcard principal" />
          <RiskChip
            on={risk.has_external_account}
            tone="medium"
            label="AWS account principal"
            off="No AWS account principal"
            title="The API raises this for any AWS account ARN in the trust policy, including this role's own account."
          />
        </div>
        {statements.length === 0 ? (
          <EmptyState compact title="No trust statements" description="The scanner recorded no trust policy for this role." />
        ) : (
          <ul className="mt-3 flex flex-col gap-2">
            {statements.map((statement, index) => (
              <li key={index} className="rounded-[var(--radius-control)] border border-line bg-surface-2/50 px-3.5 py-3 text-[12.5px]">
                <div className="flex flex-wrap items-center gap-2">
                  <Tag size="sm" tone={statement.effect === 'Allow' ? 'info' : 'neutral'}>
                    {statement.effect || 'Unknown'}
                  </Tag>
                  <span className="font-mono text-ink">{statement.action || '-'}</span>
                </div>
                <p className="mt-1.5 text-ink-3">
                  {statement.principal_type ? `${statement.principal_type}: ` : ''}
                  <span className="font-mono break-all text-ink-2">{statement.principal_value || '-'}</span>
                </p>
                {Array.isArray(statement.conditions) && statement.conditions.length > 0 && (
                  <ul className="mt-2 flex flex-col gap-1 border-t border-line pt-2">
                    {statement.conditions.map((condition, cIndex) => (
                      <li key={cIndex} className="font-mono text-[11.5px] break-all text-ink-2">
                        <span className="text-ink-3">{condition.operator}</span> {condition.key} = {condition.value}
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        )}
      </>
    );
  })();

  return (
    <Panel>
      <PanelHeader title="Trust policy" subtitle="Who may assume this role." icon={UserRoundCheck} />
      {body}
    </Panel>
  );
}

function RiskChip({ on, label, off, icon, tone = 'critical', title }) {
  if (on === undefined || on === null) return null;
  return (
    <span title={title}>
      <Tag size="sm" tone={on ? tone : 'neutral'} icon={on ? icon ?? ShieldAlert : ShieldCheck}>
        {on ? label : off}
      </Tag>
    </span>
  );
}

function PoliciesPanel({ query }) {
  let body;
  if (query.isError && !query.data) {
    body = <ErrorState compact error={query.error} onRetry={query.refetch} />;
  } else if (!query.data) {
    body = <ListSkeleton rows={3} />;
  } else {
    const managed = Array.isArray(query.data.managed_policies) ? query.data.managed_policies : [];
    const inline = Array.isArray(query.data.inline_policies) ? query.data.inline_policies : [];
    body = (
      <div className="mt-3 flex flex-col gap-4">
        {managed.length === 0 ? (
          <EmptyState compact title="No managed policies attached" description="This role grants nothing through managed policies." />
        ) : (
          <ul className="flex flex-col gap-2">
            {managed.map((policy) => (
              <ManagedPolicy key={policy.arn || policy.name} policy={policy} />
            ))}
          </ul>
        )}
        <div>
          <p className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Inline policies</p>
          {inline.length === 0 ? (
            <p className="mt-1.5 text-[12.5px] text-ink-3">None</p>
          ) : (
            <ul className="mt-1.5 flex flex-wrap gap-1.5">
              {inline.map((name) => (
                <li key={name} className="rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px] text-ink">
                  {name}
                </li>
              ))}
            </ul>
          )}
          <p className="mt-1.5 text-[11.5px] text-ink-3">The API lists inline policies by name only; their statements are not recorded.</p>
        </div>
      </div>
    );
  }
  return (
    <Panel>
      <PanelHeader
        title="Permissions"
        icon={FileLock2}
        subtitle="Managed policies attached to the role. Broad statements allow a wildcard action or apply to every resource."
      />
      {body}
    </Panel>
  );
}

function ManagedPolicy({ policy }) {
  const [open, setOpen] = useState(false);
  const risky = Array.isArray(policy.risky_statements) ? policy.risky_statements : [];
  return (
    <li className="rounded-[var(--radius-control)] border border-line">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-3.5 py-3">
        <div className="min-w-0 flex-1 basis-[16rem]">
          <p className="truncate text-[13px] font-medium text-ink">{policy.name || 'Unnamed policy'}</p>
          <p className="truncate font-mono text-[11.5px] text-ink-3" title={policy.arn}>
            {policy.arn}
          </p>
        </div>
        <span className="text-[12px] text-ink-3">
          {formatNumber(policy.statement_count)} statement{policy.statement_count === 1 ? '' : 's'}
        </span>
        {risky.length > 0 ? (
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            className="rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
          >
            <Tag size="sm" tone="high" icon={AlertTriangle}>
              {risky.length} broad · {open ? 'Hide' : 'Show'}
            </Tag>
          </button>
        ) : (
          <Tag size="sm" tone="neutral" icon={ShieldCheck}>
            No broad statements
          </Tag>
        )}
      </div>
      {open && risky.length > 0 && (
        <div className="border-t border-line bg-surface-2/40 p-3">
          <JsonBlock value={risky.length === 1 ? risky[0] : risky} compact />
        </div>
      )}
    </li>
  );
}
