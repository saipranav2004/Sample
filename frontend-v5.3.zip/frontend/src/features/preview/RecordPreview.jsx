import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, ChevronDown, ChevronUp, Globe2 } from 'lucide-react';
import { fetchCredential, fetchCredentialFlags, fetchIdentity } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatRelative } from '../../lib/format';
import { credentialTypeLabel, functionalClassLabel, healthMeta, identityTypeLabel, privilegeMeta, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { EASE_OUT } from '../../lib/motion';
import { Button, IconButton } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Drawer } from '../../ui/Overlay';
import { FactsCard } from '../../ui/FactsCard';
import { StatusChecks, checkSummary } from '../../ui/StatusChecks';
import { DetailSkeleton, ListSkeleton } from '../../ui/Skeleton';
import { ErrorState } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import { credentialChecks } from '../credentials/checks';
import { ExpiryCell, TagChips } from '../credentials/parts';
import { identityChecks } from '../identities/checks';

/**
 * Quick look at one row without leaving the list: what is wrong with it,
 * who owns it, and the dates that matter. Up and down (or J and K) step
 * through the rows behind it; the full page is one click away.
 *
 * Triage is "check ten rows in a row". Opening each one as a page costs a
 * load and the reader's place in the list every time.
 */
export function RecordPreview({ kind, rows, index, onIndexChange, onClose }) {
  const open = index !== null && index >= 0 && index < rows.length;
  const row = open ? rows[index] : null;
  const total = rows.length;

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      const tag = event.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((event.key === 'ArrowDown' || event.key === 'j') && index < total - 1) {
        event.preventDefault();
        onIndexChange(index + 1);
      }
      if ((event.key === 'ArrowUp' || event.key === 'k') && index > 0) {
        event.preventDefault();
        onIndexChange(index - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, index, total, onIndexChange]);

  const href = row ? `/${kind === 'identity' ? 'identities' : 'credentials'}/${encodeURIComponent(row.id)}` : '#';
  const typeLabel = row ? (kind === 'identity' ? identityTypeLabel(row.identity_type) : credentialTypeLabel(row.credential_type)) : '';

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="md"
      eyebrow={row ? (kind === 'identity' ? `${functionalClassLabel(row.functional_class)} identity` : 'Credential') : ''}
      title={row ? row.name || row.arn : ''}
      subtitle={row ? [typeLabel, row.account_id && `account ${row.account_id}`, row.region && regionLabel(row.region)].filter(Boolean).join(' · ') : null}
      footer={
        <>
          <span className="mr-auto flex items-center gap-1">
            <IconButton icon={ChevronUp} label="Previous row (K)" size="sm" variant="secondary" disabled={!open || index === 0} onClick={() => onIndexChange(index - 1)} />
            <IconButton icon={ChevronDown} label="Next row (J)" size="sm" variant="secondary" disabled={!open || index >= total - 1} onClick={() => onIndexChange(index + 1)} />
            <span data-numeric="" className="ml-1.5 text-[12px] text-ink-3">
              {open ? `${index + 1} of ${total}` : ''}
            </span>
          </span>
          <Button as={Link} to={href} variant="primary" iconRight={ArrowRight}>
            Open {kind === 'identity' ? 'identity' : 'credential'}
          </Button>
        </>
      }
    >
      {/* Stepping between rows swaps the body with a short cross-fade, so the
          change of record is visible without the panel moving. */}
      <AnimatePresence mode="wait" initial={false}>
        {row && (
          <motion.div
            key={row.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_OUT }}
            className="@container flex flex-col gap-5 p-4 sm:p-5"
          >
            {kind === 'identity' ? <IdentityBody id={row.id} /> : <CredentialBody id={row.id} />}
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}

function Section({ title, aside, children }) {
  return (
    <section>
      <div className="mb-1.5 flex items-baseline justify-between gap-3">
        <h3 className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{title}</h3>
        {aside && <span className="text-[11.5px] text-ink-3">{aside}</span>}
      </div>
      {children}
    </section>
  );
}

function CredentialBody({ id }) {
  const detail = useQuery((signal) => fetchCredential(id, signal), [id]);
  const flags = useQuery((signal) => fetchCredentialFlags(id, signal), [id]);
  const credential = detail.data;
  if (detail.isError) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!credential) {
    return (
      <>
        <DetailSkeleton rows={6} />
        <ListSkeleton rows={3} />
      </>
    );
  }
  const status = statusMeta(credential.status);
  const isRole = credential.credential_type === 'iam_role';
  const level = Number(credential.iam_role_details?.privilege_level);
  const owner = credential.owner_principal_arn;
  const health = flags.data ? healthMeta(flags.data.overall_health) : null;
  const checks = flags.data ? credentialChecks(credential, flags.data.flags) : [];
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Tag size="sm" tone={status.tone} dot>
          {status.label}
        </Tag>
        {health && (
          <Tag size="sm" tone={health.tone}>
            {flags.data.overall_health === 'healthy' ? 'Healthy' : `${health.label} · ${flags.data.flags.length} failing`}
          </Tag>
        )}
        <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
          <CopyableValue value={credential.arn} />
        </span>
      </div>
      <FactsCard
        facts={[
          { label: 'Held by', value: owner ? String(owner).split(':').pop() : null, mono: Boolean(owner), sub: owner ? 'Owner principal' : 'No owner recorded' },
          isRole
            ? { label: 'Privilege', value: Number.isFinite(level) ? `${level} of 10 · ${privilegeMeta(level).label}` : 'Not scored', tone: Number.isFinite(level) && level >= 6 ? privilegeMeta(level).tone : undefined }
            : { label: 'Rotation', value: credential.rotation_enabled === true ? 'Automatic' : credential.rotation_enabled === false ? 'Turned off' : 'Not managed' },
          { label: 'Last used', value: credential.last_used_at ? formatRelative(credential.last_used_at) : null, sub: credential.last_used_at ? formatDateTime(credential.last_used_at) : 'No recorded use' },
          { label: 'Expires', value: <ExpiryCell value={credential.expires_at} /> },
        ]}
      />
      <Section title="Status checks" aside={flags.data ? checkSummary(checks) : null}>
        {flags.isError ? (
          <ErrorState compact error={flags.error} onRetry={flags.refetch} />
        ) : !flags.data ? (
          <ListSkeleton rows={3} />
        ) : (
          <StatusChecks checks={checks} />
        )}
      </Section>
      <Section title="Tags">
        <TagChips tags={credential.tags} />
      </Section>
    </>
  );
}

function IdentityBody({ id }) {
  const detail = useQuery((signal) => fetchIdentity(id, signal), [id]);
  const identity = detail.data;
  if (detail.isError) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!identity) {
    return (
      <>
        <DetailSkeleton rows={6} />
        <ListSkeleton rows={3} />
      </>
    );
  }
  const status = statusMeta(identity.status);
  const checks = identityChecks(identity);
  const isPublic = identity.network?.is_publicly_accessible === true;
  const creator = identity.lineage?.cloudtrail_creator_arn;
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Tag size="sm" tone={status.tone} dot>
          {status.label}
        </Tag>
        {isPublic && (
          <Tag size="sm" tone="critical" icon={Globe2}>
            Publicly accessible
          </Tag>
        )}
        {identity.deleted_at && <Tag size="sm" tone="neutral">Removed {formatRelative(identity.deleted_at)}</Tag>}
        <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
          <CopyableValue value={identity.arn} />
        </span>
      </div>
      <FactsCard
        facts={[
          { label: 'What it is', value: identityTypeLabel(identity.identity_type), sub: `${functionalClassLabel(identity.functional_class)} class` },
          { label: 'Owner', value: identity.ownership?.owner || null, sub: identity.ownership?.environment || 'No environment' },
          { label: 'Reachable from', value: isPublic ? 'The internet' : identity.network?.is_publicly_accessible === false ? 'Private network only' : null, tone: isPublic ? 'critical' : undefined },
          { label: 'Created by', value: creator ? String(creator).split('/').pop() : null, mono: Boolean(creator), sub: creator ? 'CloudTrail' : 'Not found in CloudTrail' },
          { label: 'Last active', value: identity.last_activity_at ? formatRelative(identity.last_activity_at) : null, sub: identity.last_activity_at ? formatDateTime(identity.last_activity_at) : 'AWS records no activity' },
          { label: 'Source', value: tokenLabel(identity.discovery?.discovery_source), sub: identity.discovery?.scan_id },
        ]}
      />
      <Section title="Status checks" aside={checkSummary(checks)}>
        <StatusChecks checks={checks} />
      </Section>
    </>
  );
}
