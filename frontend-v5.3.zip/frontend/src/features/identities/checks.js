import { formatRelative, parseDate } from '../../lib/format';

const DAY = 86_400_000;

/*
 * The checks behind an identity's status, read from fields the identity
 * record returns - the same tests the dashboard's exposure panel counts,
 * applied to one record. Nothing is scored or estimated.
 */
export function identityChecks(identity, now = Date.now()) {
  if (!identity) return [];
  const pub = identity.network?.is_publicly_accessible;
  const owner = identity.ownership?.owner;
  const environment = identity.ownership?.environment;
  const last = parseDate(identity.last_activity_at);
  const days = last ? Math.floor((now - last.getTime()) / DAY) : null;
  return [
    pub === true
      ? { key: 'public', label: 'Not reachable from the internet', result: 'failing', severity: 'critical', detail: 'Publicly accessible', next: 'Check it needs to be public; restrict its security groups if not.' }
      : pub === false
        ? { key: 'public', label: 'Not reachable from the internet', result: 'clear' }
        : { key: 'public', label: 'Not reachable from the internet', result: 'unknown', detail: 'The scanner could not tell' },
    owner
      ? { key: 'owner', label: 'Owner recorded', result: 'clear', detail: owner }
      : { key: 'owner', label: 'Owner recorded', result: 'failing', severity: 'medium', next: 'Nobody is answerable for it. Set an owner.' },
    environment
      ? { key: 'environment', label: 'Environment recorded', result: 'clear', detail: environment }
      : { key: 'environment', label: 'Environment recorded', result: 'failing', severity: 'medium', next: 'Mark it production, staging or similar so it can be prioritised.' },
    days === null
      ? { key: 'activity', label: 'Used in the last 90 days', result: 'unknown', detail: 'AWS records no activity for this identity' }
      : days >= 90
        ? { key: 'activity', label: 'Used in the last 90 days', result: 'failing', severity: 'high', detail: `Last active ${formatRelative(identity.last_activity_at)}`, next: 'Confirm with the owner, then remove it if it is no longer needed.' }
        : { key: 'activity', label: 'Used in the last 90 days', result: 'clear', detail: `Last active ${formatRelative(identity.last_activity_at)}` },
  ];
}
