import { useId, useState } from 'react';
import { motion } from 'motion/react';
import { cn } from '../ui/cn';

/**
 * Concentric progress rings, one per measure (bklit's ring chart, ported to
 * the libraries this console already ships). Each ring draws in on a short
 * stagger; pointing at a ring or its legend row lifts it and fades the rest,
 * and the centre reads out the one in focus.
 *
 * rings: [{ key, label, value (0-100), color, detail? }]
 */
export function CoverageRings({ rings, size = 172, stroke = 8, gap = 4, title, stacked = false, className }) {
  const [focus, setFocus] = useState(null);
  const labelId = useId();
  const centre = size / 2;
  const current = rings[focus ?? 0];

  return (
    <div className={cn('grid items-center gap-4', !stacked && '@min-[26rem]:grid-cols-[auto_minmax(0,1fr)]', className)}>
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        role="img"
        aria-labelledby={labelId}
        className="mx-auto shrink-0 overflow-visible"
        onMouseLeave={() => setFocus(null)}
      >
        <title id={labelId}>{`${title}: ${rings.map((ring) => `${ring.label} ${formatPct(ring.value)}`).join(', ')}`}</title>
        {rings.map((ring, index) => {
          const radius = centre - stroke / 2 - index * (stroke + gap);
          if (radius <= stroke) return null;
          const faded = focus !== null && focus !== index;
          return (
            <g key={ring.key} transform={`rotate(-90 ${centre} ${centre})`} onMouseEnter={() => setFocus(index)}>
              <circle cx={centre} cy={centre} r={radius} fill="none" stroke="var(--t-track)" strokeWidth={stroke} />
              <motion.circle
                cx={centre}
                cy={centre}
                r={radius}
                fill="none"
                stroke={ring.color}
                strokeWidth={stroke}
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: Math.max(0.001, Math.min(1, ring.value / 100)), opacity: faded ? 0.28 : 1 }}
                transition={{
                  pathLength: { type: 'spring', visualDuration: 0.9, bounce: 0, delay: 0.15 + index * 0.08 },
                  opacity: { duration: 0.18 },
                }}
                style={{ cursor: 'default' }}
              />
            </g>
          );
        })}
        <text x={centre} y={centre - 2} textAnchor="middle" className="fill-ink font-display text-[20px] font-extrabold" style={{ fontVariantNumeric: 'tabular-nums' }}>
          {current ? formatPct(current.value) : '-'}
        </text>
        <text x={centre} y={centre + 14} textAnchor="middle" className="fill-[var(--t-ink-3)] text-[10.5px]">
          {current ? current.label.toLowerCase() : ''}
        </text>
      </svg>

      <ul className="flex min-w-0 flex-col" onMouseLeave={() => setFocus(null)}>
        {rings.map((ring, index) => (
          <li
            key={ring.key}
            onMouseEnter={() => setFocus(index)}
            className={cn(
              'flex items-center gap-2.5 border-b border-line py-2 text-[12.5px] transition-opacity duration-150 last:border-b-0',
              focus !== null && focus !== index && 'opacity-45',
            )}
          >
            <span aria-hidden="true" className="size-2.5 shrink-0 rounded-[3px]" style={{ background: ring.color }} />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-ink-2">{ring.label}</span>
              {ring.detail && <span className="block truncate text-[11px] text-ink-3">{ring.detail}</span>}
            </span>
            <span data-numeric="" className="shrink-0 font-semibold text-ink">
              {formatPct(ring.value)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function formatPct(value) {
  const n = Number(value) || 0;
  return `${n.toFixed(n % 1 ? 1 : 0)}%`;
}
