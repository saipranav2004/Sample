import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import { homeFor } from '../lib/roles';
import { MotionProvider } from '../lib/motion';
import { ThemeProvider } from './ThemeContext';
import { RequireAuth } from './RequireAuth';
import { ToastProvider } from '../ui/Toast';
import { AppShell } from '../shell/AppShell';
import { RouteFallback } from '../shell/RouteFallback';

/* Routes are split per screen, and the sign-in screen (with its animation
   library) is its own chunk too, so a signed-in reload never downloads it. */
const LoginPage = lazy(() => import('../features/auth/LoginPage'));
const OverviewPage = lazy(() => import('../features/overview/OverviewPage'));
const IdentitiesPage = lazy(() => import('../features/identities/IdentitiesPage'));
const IdentityPage = lazy(() => import('../features/identities/IdentityPage'));
const CredentialsPage = lazy(() => import('../features/credentials/CredentialsPage'));
const CredentialPage = lazy(() => import('../features/credentials/CredentialPage'));
const DiscoveriesPage = lazy(() => import('../features/activity/DiscoveriesPage'));
const NotFoundPage = lazy(() => import('../features/NotFoundPage'));

function screen(Page) {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Page />
    </Suspense>
  );
}

/** Old links keep working: same filters, new home. */
function Moved({ to, view }) {
  const { search } = useLocation();
  const query = new URLSearchParams(search);
  query.set('view', view(query));
  return <Navigate to={`${to}?${query}`} replace />;
}

export default function App() {
  return (
    <MotionProvider>
      <ThemeProvider>
        <ToastProvider>
          <BrowserRouter>
            <AuthProvider>
              <Routes>
                <Route
                  path="/login"
                  element={
                    <Suspense fallback={<div className="auth-canvas" />}>
                      <LoginPage />
                    </Suspense>
                  }
                />
                <Route
                  element={
                    <RequireAuth>
                      <AppShell />
                    </RequireAuth>
                  }
                >
                  <Route index element={<Navigate to={homeFor()} replace />} />
                  <Route path="/overview" element={screen(OverviewPage)} />
                  <Route path="/identities" element={screen(IdentitiesPage)} />
                  <Route path="/identities/:id" element={screen(IdentityPage)} />
                  <Route path="/credentials" element={screen(CredentialsPage)} />
                  <Route path="/credentials/:id" element={screen(CredentialPage)} />
                  {/* These were their own pages; they are now views of the lists. */}
                  <Route path="/hygiene" element={<Moved to="/credentials" view={(q) => (q.get('view') === 'stale' ? 'stale' : 'expiring')} />} />
                  <Route path="/dormant" element={<Moved to="/identities" view={() => 'dormant'} />} />
                  <Route path="/discoveries" element={screen(DiscoveriesPage)} />
                  <Route path="*" element={screen(NotFoundPage)} />
                </Route>
              </Routes>
            </AuthProvider>
          </BrowserRouter>
        </ToastProvider>
      </ThemeProvider>
    </MotionProvider>
  );
}
