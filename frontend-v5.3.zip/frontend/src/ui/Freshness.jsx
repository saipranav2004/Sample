import { useState } from 'react';
import { formatDateTime, formatRelativeShort, parseDate } from '../lib/format';
import { MiniMeter } from './TypeBadge';

/**
 * When it was last active, with a meter that empties over a year: a glance
 * down the column shows which identities have gone quiet.
 */
export function Freshness({ value, empty = 'Not tracked', emptyTitle = 'AWS records no last-used time for this identity' }) {
  const [now] = useState(() => Date.now());
  const date = parseDate(value);
  if (!date) {
    return (
      <span className="block truncate text-ink-3" title={emptyTitle}>
        {empty}
      </span>
    );
  }
  const days = Math.max(0, Math.floor((now - date.getTime()) / 86_400_000));
  const tone = days >= 90 ? 'var(--t-high)' : days >= 30 ? 'var(--t-medium)' : 'var(--t-brand)';
  return (
    <span className="flex min-w-0 items-center gap-2" title={formatDateTime(value)}>
      <span className="w-[4.25rem] shrink-0 whitespace-nowrap">{formatRelativeShort(value)}</span>
      <MiniMeter value={100 - (days / 365) * 100} tone={tone} width={44} label={`${days} days ago`} />
    </span>
  );
}
