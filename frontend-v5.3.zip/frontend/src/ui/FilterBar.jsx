import { useId, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { formatNumber } from '../lib/format';
import { usePopover } from '../lib/hooks';
import { cn } from './cn';

/**
 * The filter row above a list (docs/RESEARCH.md, "Filters").
 *
 * A list offers only the two or three categories people actually narrow it
 * by, each as one pill: `Type: Any`. Opening a pill lists that category's
 * values with how many records each holds; picking one applies it at once.
 * An applied pill reads `Type: Lambda function` and carries its own clear
 * button, so what is scoping the list is always on screen in one row.
 *
 * Single value per category, "and" between categories: what the inventory
 * API accepts, and what Cloudscape recommends when users filter by one or
 * two properties.
 */
export function FilterBar({ children, onClearAll, appliedCount = 0, className }) {
  return (
    <div className={cn('flex w-full min-w-0 flex-wrap items-center gap-2 sm:w-auto', className)}>
      {children}
      {appliedCount > 0 && onClearAll && (
        <button
          type="button"
          onClick={onClearAll}
          className="h-8 rounded-[var(--radius-control)] px-2 text-[12.5px] font-medium text-brand hover:bg-info-soft/60 hover:underline"
        >
          Clear filters
        </button>
      )}
    </div>
  );
}

/**
 * options: [{ value, label, count?, hint? }]. `value` '' is never an option;
 * "Any" is added on top and clears the category.
 */
export function FilterSelect({ label, value, options, onChange, anyLabel = 'Any', loading = false, searchable }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const listId = useId();
  const close = () => {
    setOpen(false);
    setQuery('');
  };
  const { wrapperRef, triggerRef, panelProps } = usePopover(open, close);
  const searchRef = useRef(null);

  const selected = options.find((option) => option.value === value);
  /* A value that came in on a link but has no records right now still shows
     as applied, so the reader can see and clear it. */
  const shownValue = selected?.label ?? (value || null);
  const canSearch = searchable ?? options.length > 8;
  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? options.filter((option) => `${option.label} ${option.value}`.toLowerCase().includes(q)) : options;
  }, [options, query]);

  const pick = (next) => {
    onChange(next);
    close();
    triggerRef.current?.focus();
  };

  return (
    <div ref={wrapperRef} className="relative">
      <div
        className={cn(
          'flex h-8 items-stretch overflow-hidden rounded-[var(--radius-control)] border text-[12.5px] transition-colors',
          shownValue ? 'border-brand/45 bg-info-soft/55' : 'border-line-strong bg-surface hover:bg-surface-2',
        )}
      >
        <button
          ref={triggerRef}
          type="button"
          aria-haspopup="listbox"
          aria-expanded={open}
          aria-controls={open ? listId : undefined}
          onClick={() => {
            setOpen((current) => !current);
            if (canSearch) requestAnimationFrame(() => searchRef.current?.focus());
          }}
          className="flex min-w-0 items-center gap-1.5 pr-2 pl-2.5 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brand"
        >
          <span className={cn(shownValue ? 'text-ink-2' : 'text-ink-3')}>{label}</span>
          <span className={cn('max-w-[14rem] truncate font-medium', shownValue ? 'text-brand' : 'text-ink-2')}>
            {shownValue ?? anyLabel}
          </span>
          {!shownValue && <ChevronDown aria-hidden="true" className="size-3.5 shrink-0 text-ink-3" />}
        </button>
        {shownValue && (
          <button
            type="button"
            onClick={() => onChange('')}
            aria-label={`Clear ${label} filter`}
            title={`Clear ${label}`}
            className="grid w-7 place-items-center border-l border-brand/25 text-brand hover:bg-brand/10 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brand"
          >
            <X aria-hidden="true" className="size-3.5" />
          </button>
        )}
      </div>

      {open && (
        <div
          {...panelProps}
          className={cn(
            'animate-pop absolute left-0 z-40 flex w-72 max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-[var(--radius-panel)] border border-line bg-surface shadow-lg',
            panelProps['data-placement'] === 'top' ? 'bottom-full mb-1.5' : 'top-full mt-1.5',
          )}
        >
          <div className="border-b border-line px-3 pt-2.5 pb-2">
            <p className="text-[11px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{label}</p>
            {canSearch && (
              <div className="relative mt-2">
                <Search aria-hidden="true" className="pointer-events-none absolute top-1/2 left-2.5 size-3.5 -translate-y-1/2 text-ink-3" />
                <input
                  ref={searchRef}
                  type="search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={`Find ${label.toLowerCase()}`}
                  aria-label={`Find ${label.toLowerCase()}`}
                  className="h-8 w-full rounded-[var(--radius-control)] border border-line-strong bg-surface pr-2 pl-8 text-[12.5px] text-ink placeholder:text-ink-3/80 focus:border-brand focus:outline-none"
                />
              </div>
            )}
          </div>
          <ul id={listId} role="listbox" aria-label={label} className="min-h-0 flex-1 overflow-y-auto p-1">
            <Option active={!value} label={anyLabel} onSelect={() => pick('')} />
            {loading && options.length === 0 ? (
              <li className="px-2.5 py-2 text-[12.5px] text-ink-3">Loading...</li>
            ) : visible.length === 0 ? (
              <li className="px-2.5 py-2 text-[12.5px] text-ink-3">{query ? 'No match' : 'Nothing to filter by yet'}</li>
            ) : (
              visible.map((option) => (
                <Option
                  key={option.value}
                  active={option.value === value}
                  label={option.label}
                  hint={option.hint}
                  count={option.count}
                  mono={option.mono}
                  onSelect={() => pick(option.value)}
                />
              ))
            )}
          </ul>
        </div>
      )}
    </div>
  );
}

function Option({ active, label, hint, count, mono, onSelect }) {
  return (
    <li role="option" aria-selected={active}>
      <button
        type="button"
        onClick={onSelect}
        className={cn(
          'flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-[13px] transition-colors',
          active ? 'bg-info-soft/60 text-ink' : 'text-ink-2 hover:bg-surface-3 hover:text-ink',
        )}
      >
        <Check aria-hidden="true" className={cn('size-3.5 shrink-0 text-brand', !active && 'invisible')} />
        <span className="min-w-0 flex-1">
          <span className={cn('block truncate', mono && 'font-mono text-[12.5px]')}>{label}</span>
          {hint && <span className="block truncate text-[11.5px] text-ink-3">{hint}</span>}
        </span>
        {count !== undefined && count !== null && (
          <span data-numeric="" className="shrink-0 text-[12px] text-ink-3">
            {formatNumber(count)}
          </span>
        )}
      </button>
    </li>
  );
}

/**
 * Filters that arrived on a link (a dashboard drill-down, "everything this
 * principal owns") but are not offered in the filter row. Shown so the reader
 * knows the list is scoped, and removable.
 */
export function LinkedFilters({ filters, onRemove }) {
  if (filters.length === 0) return null;
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface px-3 py-2">
      <span className="text-[12px] text-ink-3">Also filtered by</span>
      {filters.map((filter) => (
        <span
          key={filter.key}
          className="inline-flex h-7 max-w-full items-center overflow-hidden rounded-full border border-line-strong bg-surface-2 text-[12px]"
        >
          <span className="truncate pl-2.5 text-ink-2">
            {filter.label}: <span className={cn('font-medium text-ink', filter.mono && 'font-mono text-[11.5px]')}>{filter.value}</span>
          </span>
          <button
            type="button"
            onClick={() => onRemove(filter.key)}
            aria-label={`Remove ${filter.label} filter`}
            className="ml-1 grid h-full w-7 place-items-center text-ink-3 hover:bg-surface-3 hover:text-ink"
          >
            <X aria-hidden="true" className="size-3.5" />
          </button>
        </span>
      ))}
    </div>
  );
}
