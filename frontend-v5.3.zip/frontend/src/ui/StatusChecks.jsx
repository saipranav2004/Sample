import { RevealItem, RevealList } from '../lib/motion';
import { TONE_VAR, cn } from './cn';

const RESULT = {
  failing: { label: 'Failing' },
  clear: { label: 'Clear', tone: 'low' },
  unknown: { label: 'Not recorded', tone: 'neutral' },
};
const ORDER = { failing: 0, unknown: 1, clear: 2 };
const SEVERITY = { critical: 0, high: 1, medium: 2, low: 3 };

/**
 * Every check that applies to a record, with its result: Failing (in its
 * severity colour, with the next step), Clear, or Not recorded. A clean
 * record says so check by check instead of showing an empty box.
 *
 * checks: [{ key, label, result: 'failing'|'clear'|'unknown', severity?, detail?, next? }]
 */
export function StatusChecks({ checks, className }) {
  const sorted = [...checks].sort(
    (a, b) => ORDER[a.result] - ORDER[b.result] || (SEVERITY[a.severity] ?? 9) - (SEVERITY[b.severity] ?? 9),
  );
  return (
    <RevealList as="ul" className={cn('flex flex-col', className)}>
      {sorted.map((check, index) => {
        const tone = check.result === 'failing' ? check.severity ?? 'high' : RESULT[check.result].tone;
        const color = TONE_VAR[tone === 'low' && check.result === 'failing' ? 'medium' : tone] ?? TONE_VAR.neutral;
        return (
          <RevealItem
            as="li"
            index={index}
            key={check.key}
            className="flex items-start gap-3 border-b border-line py-2.5 last:border-b-0"
          >
            <span aria-hidden="true" className="mt-[7px] size-[7px] shrink-0 rounded-full" style={{ background: color }} />
            <div className="min-w-0 flex-1">
              <p className="text-[13px] text-ink">{check.label}</p>
              {(check.detail || (check.result === 'failing' && check.next)) && (
                <p className="mt-0.5 text-[12px] text-ink-3">
                  {check.detail}
                  {check.detail && check.result === 'failing' && check.next ? ' · ' : ''}
                  {check.result === 'failing' && check.next ? <span className="text-ink-2">{check.next}</span> : null}
                </p>
              )}
            </div>
            <span className="shrink-0 text-[12.5px] font-semibold" style={{ color }}>
              {RESULT[check.result].label}
              {check.result === 'failing' && check.severity && (
                <span className="sr-only">, {check.severity} severity</span>
              )}
            </span>
          </RevealItem>
        );
      })}
    </RevealList>
  );
}

export function checkSummary(checks) {
  const failing = checks.filter((check) => check.result === 'failing').length;
  const clear = checks.filter((check) => check.result === 'clear').length;
  return [failing ? `${failing} failing` : null, clear ? `${clear} clear` : null].filter(Boolean).join(' · ') || 'No checks apply';
}
