import { useEffect, useRef, useState } from 'react';
import { formatDate, formatDateTime, parseDate } from '../lib/format';
import { TONE_VAR, cn } from './cn';

const DAY = 86_400_000;

/**
 * A record's life on one time axis: when it was created, discovered,
 * rotated, last used, today, and when it expires. The question it answers is
 * "is it safe to act on this?" - a long gap between last use and today is
 * the case for disabling it, an expiry close to today the case for renewing.
 *
 * events: [{ key, label, at, tone? }]  (events without a date are listed as
 *   "not recorded" under the axis rather than guessed)
 * gaps:   [{ from, to, label, tone }]  shaded spans on the axis
 */
/* Width a label needs, in px, before the next one in its row may start. */
const LABEL_PX = 128;

export function LifeTimeline({ events, gaps = [], now }) {
  const axisRef = useRef(null);
  const [width, setWidth] = useState(900);
  useEffect(() => {
    const node = axisRef.current;
    if (!node || typeof ResizeObserver === 'undefined') return undefined;
    const observer = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width || 900));
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  const dated = events
    .map((event) => ({ ...event, time: parseDate(event.at)?.getTime() }))
    .filter((event) => Number.isFinite(event.time));
  const missing = events.filter((event) => !Number.isFinite(parseDate(event.at)?.getTime()));
  const all = [...dated, { key: 'today', label: 'Today', time: now, today: true }].sort((a, b) => a.time - b.time);

  const min = all[0].time;
  const max = all[all.length - 1].time;
  const span = Math.max(max - min, DAY);
  const pad = span * 0.04;
  const x = (time) => ((time - (min - pad)) / (span + pad * 2)) * 100;

  /* Labels go in rows under the axis; a label moves down a row when it would
     collide with the one before it in the same row. */
  const rows = [];
  const labelPct = (LABEL_PX / Math.max(width, 200)) * 100;
  const placed = all.map((event) => {
    const left = x(event.time);
    /* The same anchoring the label uses below: pulled in at either edge. */
    const shift = left > 88 ? 0.9 : left < 12 ? 0.1 : 0.5;
    const start = left - labelPct * shift;
    const end = start + labelPct;
    let row = rows.findIndex((lastEnd) => start > lastEnd + 1);
    if (row === -1) {
      rows.push(end);
      row = rows.length - 1;
    } else rows[row] = end;
    return { ...event, left, row };
  });
  const rowCount = Math.max(1, rows.length);

  return (
    <div>
      {/* Wide layout: the axis. */}
      <div className="hidden @min-[36rem]:block">
        <div ref={axisRef} className="relative mx-2" style={{ height: `${34 + rowCount * 44}px` }}>
          <div className="absolute inset-x-0 top-[14px] h-[3px] rounded-full bg-line" />
          {gaps.map((gap) => {
            const from = parseDate(gap.from)?.getTime() ?? (gap.from === 'now' ? now : NaN);
            const to = parseDate(gap.to)?.getTime() ?? (gap.to === 'now' ? now : NaN);
            if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from) return null;
            const left = x(from);
            const width = Math.max(0.8, x(to) - left);
            return (
              <div key={gap.label} className="absolute top-0" style={{ left: `${left}%`, width: `${width}%` }}>
                <div
                  className="mt-[12px] h-[7px] rounded-full"
                  style={{ background: `color-mix(in srgb, ${TONE_VAR[gap.tone] ?? TONE_VAR.medium} 55%, transparent)` }}
                />
                <p
                  className="absolute -top-[6px] left-1/2 -translate-x-1/2 -translate-y-full rounded px-1.5 text-[11px] font-semibold whitespace-nowrap"
                  style={{ color: TONE_VAR[gap.tone] ?? TONE_VAR.medium }}
                >
                  {gap.label}
                </p>
              </div>
            );
          })}
          {placed.map((event) => (
            <div key={event.key} className="absolute top-0" style={{ left: `${event.left}%` }}>
              <span
                aria-hidden="true"
                className={cn(
                  'absolute top-[9px] -ml-[6.5px] size-[13px] rounded-full border-[3px] border-surface',
                  event.today && 'ring-2 ring-ink/70',
                )}
                style={{ background: event.today ? 'var(--t-ink)' : TONE_VAR[event.tone] ?? 'var(--t-brand)' }}
              />
              <span
                aria-hidden="true"
                className="absolute top-[22px] w-px bg-line-strong"
                style={{ height: `${12 + event.row * 44}px` }}
              />
              <div
                className={cn('absolute w-max max-w-[11rem] -translate-x-1/2 text-center', event.left > 88 && '-translate-x-[90%] text-right', event.left < 12 && '-translate-x-[10%] text-left')}
                style={{ top: `${34 + event.row * 44}px` }}
              >
                <p className={cn('text-[12px] leading-tight font-semibold', event.today ? 'text-ink' : 'text-ink-2')}>{event.label}</p>
                <p className="text-[11.5px] leading-tight text-ink-3" title={event.today ? undefined : formatDateTime(new Date(event.time))}>
                  {formatDate(new Date(event.time))}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Narrow layout: the same events as a dated list. */}
      <ol className="flex flex-col gap-2.5 border-l-2 border-line pl-4 @min-[36rem]:hidden">
        {all.map((event) => (
          <li key={event.key} className="relative">
            <span
              aria-hidden="true"
              className="absolute top-1.5 -left-[22px] size-2.5 rounded-full"
              style={{ background: event.today ? 'var(--t-ink)' : TONE_VAR[event.tone] ?? 'var(--t-brand)' }}
            />
            <p className="text-[13px] font-medium text-ink">{event.label}</p>
            <p className="text-[12px] text-ink-3">{formatDate(new Date(event.time))}</p>
          </li>
        ))}
        {gaps
          .filter((gap) => gap.label)
          .map((gap) => (
            <li key={gap.label} className="text-[12.5px] font-semibold" style={{ color: TONE_VAR[gap.tone] ?? TONE_VAR.medium }}>
              {gap.label}
            </li>
          ))}
      </ol>

      {missing.length > 0 && (
        <p className="mt-3 text-[12px] text-ink-3">
          Not recorded: {missing.map((event) => event.label.toLowerCase()).join(', ')}.
        </p>
      )}
    </div>
  );
}
