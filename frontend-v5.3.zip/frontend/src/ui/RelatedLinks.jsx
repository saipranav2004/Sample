import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

/**
 * One-click views a reader is likely to want next from a record: the same
 * owner, the same account, the same type. Each is a list filter the API
 * supports, so the count is whatever that list shows.
 * links: [{ to, label, hint? }]
 */
export function RelatedLinks({ links }) {
  const shown = links.filter(Boolean);
  if (shown.length === 0) return null;
  return (
    <ul className="flex flex-col">
      {shown.map((link) => (
        <li key={link.to} className="border-b border-line last:border-b-0">
          <Link
            to={link.to}
            className="group flex items-center gap-3 rounded-md px-1 py-2 text-[13px] text-ink-2 transition-colors hover:bg-surface-2 hover:text-ink focus-visible:bg-surface-2"
          >
            <span className="min-w-0 flex-1">
              <span className="block truncate font-medium">{link.label}</span>
              {link.hint && <span className="block truncate text-[11.5px] text-ink-3">{link.hint}</span>}
            </span>
            <ArrowRight aria-hidden="true" className="size-3.5 shrink-0 text-ink-3 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </li>
      ))}
    </ul>
  );
}
