import { useId, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { formatNumber } from '../lib/format';
import { Select } from './Field';
import { cn } from './cn';

const PAGE_SIZES = [25, 50, 100];

/**
 * Numbered pagination over a known total (docs/RESEARCH.md, "Pagination").
 *
 *   Showing 26-50 of 197 identities   Rows per page [25]   < 1 2 [3] 4 ... 8 >   Go to [ ]
 *
 * - Numbered pages so a reader can go straight to a page and see where they
 *   are; first and last pages stay visible, the gap is an ellipsis.
 * - "Go to page" only once there are more than nine pages, when the numbers
 *   are truncated and stepping through them would take many clicks.
 * - On a phone the numbers collapse to "3 of 8" between the arrows.
 * - Changing page scrolls the table's top back into view, so the reader is
 *   not left looking at the footer of a page they have not read.
 */
export function Pagination({
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizes = PAGE_SIZES,
  unit = 'records',
  scrollTarget,
  className,
}) {
  const totalPages = Math.max(1, Math.ceil((total || 0) / (pageSize || 1)));
  const current = Math.min(Math.max(1, page), totalPages);
  const from = total === 0 ? 0 : (current - 1) * pageSize + 1;
  const to = Math.min(total, current * pageSize);

  const go = (next) => {
    const target = Math.min(Math.max(1, next), totalPages);
    if (target === current) return;
    onPageChange(target);
    const element = scrollTarget?.current;
    if (element && element.getBoundingClientRect().top < 72) {
      element.scrollIntoView({ block: 'start', behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
    }
  };

  return (
    <nav
      aria-label={`${unit} pages`}
      className={cn(
        'flex flex-wrap items-center justify-between gap-x-5 gap-y-3 border-t border-line bg-surface-2/50 px-4 py-2.5',
        className,
      )}
    >
      <p className="text-[12.5px] text-ink-3" data-numeric="" aria-live="polite">
        Showing{' '}
        <span className="font-semibold text-ink">
          {formatNumber(from)}-{formatNumber(to)}
        </span>{' '}
        of <span className="font-semibold text-ink">{formatNumber(total)}</span> {unit}
      </p>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        {onPageSizeChange && (
          <label className="flex items-center gap-2 text-[12.5px] text-ink-3">
            <span className="hidden sm:inline">Rows per page</span>
            <Select
              size="sm"
              value={String(pageSize)}
              onChange={(event) => onPageSizeChange(Number(event.target.value))}
              options={pageSizes.map((size) => ({ value: String(size), label: String(size) }))}
              className="w-[4.5rem]"
              aria-label="Rows per page"
            />
          </label>
        )}

        <div className="flex items-center gap-1">
          <StepButton label="Previous page" disabled={current <= 1} onClick={() => go(current - 1)}>
            <ChevronLeft aria-hidden="true" className="size-4" />
          </StepButton>

          <ol className="hidden items-center gap-1 sm:flex">
            {pageItems(current, totalPages).map((item, index) =>
              item === 'gap' ? (
                <li key={`gap-${index}`} aria-hidden="true" className="w-6 text-center text-[13px] text-ink-3">
                  ...
                </li>
              ) : (
                <li key={item}>
                  <button
                    type="button"
                    onClick={() => go(item)}
                    aria-label={`Page ${item}`}
                    aria-current={item === current ? 'page' : undefined}
                    data-numeric=""
                    className={cn(
                      'grid h-8 min-w-8 place-items-center rounded-[var(--radius-control)] px-2 text-[13px] font-medium transition-colors',
                      'focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand',
                      item === current
                        ? 'bg-brand text-white shadow-sm dark:text-ink-inverse'
                        : 'text-ink-2 hover:bg-surface-3 hover:text-ink',
                    )}
                  >
                    {item}
                  </button>
                </li>
              ),
            )}
          </ol>
          <span className="px-2 text-[13px] font-medium text-ink-2 sm:hidden" data-numeric="">
            {current} of {totalPages}
          </span>

          <StepButton label="Next page" disabled={current >= totalPages} onClick={() => go(current + 1)}>
            <ChevronRight aria-hidden="true" className="size-4" />
          </StepButton>
        </div>

        {totalPages > 9 && <JumpToPage totalPages={totalPages} onJump={go} />}
      </div>
    </nav>
  );
}

function StepButton({ label, disabled, onClick, children }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'grid size-8 place-items-center rounded-[var(--radius-control)] border border-line-strong bg-surface text-ink-2 transition-colors',
        'hover:bg-surface-2 hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand',
        'disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:bg-surface',
      )}
    >
      {children}
    </button>
  );
}

function JumpToPage({ totalPages, onJump }) {
  const id = useId();
  const [draft, setDraft] = useState('');
  const submit = (event) => {
    event.preventDefault();
    const n = Number(draft);
    if (Number.isInteger(n) && n >= 1) onJump(Math.min(n, totalPages));
    setDraft('');
  };
  return (
    <form onSubmit={submit} className="hidden items-center gap-2 text-[12.5px] text-ink-3 md:flex">
      <label htmlFor={id}>Go to</label>
      <input
        id={id}
        inputMode="numeric"
        pattern="[0-9]*"
        value={draft}
        onChange={(event) => setDraft(event.target.value.replace(/\D/g, '').slice(0, 6))}
        placeholder={`1-${totalPages}`}
        aria-label={`Go to page, 1 to ${totalPages}`}
        className="h-8 w-16 rounded-[var(--radius-control)] border border-line-strong bg-surface px-2 text-center text-[13px] text-ink placeholder:text-ink-3/70 focus:border-brand focus:outline-none"
      />
    </form>
  );
}

/**
 * The page numbers to show: every page up to seven, otherwise the first and
 * last pages, the current one and its neighbours, with gaps between.
 *   1 2 3 4 5 ... 20   |   1 ... 9 10 11 ... 20   |   1 ... 16 17 18 19 20
 */
export function pageItems(current, totalPages) {
  if (totalPages <= 7) return Array.from({ length: totalPages }, (_, index) => index + 1);
  if (current <= 4) return [1, 2, 3, 4, 5, 'gap', totalPages];
  if (current >= totalPages - 3) return [1, 'gap', ...Array.from({ length: 5 }, (_, index) => totalPages - 4 + index)];
  return [1, 'gap', current - 1, current, current + 1, 'gap', totalPages];
}

function prefersReducedMotion() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
}
