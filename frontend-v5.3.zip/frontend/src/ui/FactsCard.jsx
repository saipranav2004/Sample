import { cn } from './cn';

/**
 * The record at a glance, in one grouped card (reference console): six or so
 * facts in a grid, each a label, a value and a quieter line under it.
 * facts: [{ label, value, sub?, tone?, mono? }]
 */
export function FactsCard({ facts, className }) {
  return (
    <dl
      className={cn(
        'grid gap-x-6 gap-y-4 rounded-[var(--radius-panel)] border border-line bg-surface-2 px-4 py-3.5 @min-[34rem]:grid-cols-2 @min-[56rem]:grid-cols-3',
        className,
      )}
    >
      {facts.filter(Boolean).map((fact) => (
        <div key={fact.label} className="min-w-0">
          <dt className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{fact.label}</dt>
          <dd
            className={cn('mt-1 text-[13px] break-words text-ink', fact.mono && 'font-mono text-[12.5px]', fact.tone && 'font-semibold')}
            style={fact.tone ? { color: `var(--t-${fact.tone})` } : undefined}
          >
            {fact.value ?? <span className="font-normal text-ink-3">Not recorded</span>}
          </dd>
          {fact.sub && <dd className="mt-0.5 text-[11.5px] break-words text-ink-3">{fact.sub}</dd>}
        </div>
      ))}
    </dl>
  );
}
