import { cn } from './cn';

/**
 * The square badge at the start of a row or a record header: a short code
 * for what the thing is, tinted with its category colour. The letters are
 * mixed toward the ink so they clear 4.5:1 on the tint in both themes.
 */
export function TypeBadge({ code, color, size = 'md', title, className }) {
  return (
    <span
      aria-hidden={title ? undefined : 'true'}
      title={title}
      className={cn(
        'grid shrink-0 place-items-center border font-bold tracking-tight',
        size === 'lg' ? 'size-12 rounded-[12px] text-[12px]' : 'size-8 rounded-[9px] text-[10px]',
        className,
      )}
      style={{
        borderColor: `color-mix(in srgb, ${color} 34%, transparent)`,
        background: `color-mix(in srgb, ${color} 10%, transparent)`,
        color: `color-mix(in srgb, ${color} 62%, var(--t-ink))`,
      }}
    >
      {code}
    </span>
  );
}

/** A small meter beside a value: how fresh, how close, how covered. */
export function MiniMeter({ value, tone, width = 64, label }) {
  const pct = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <span
      role="img"
      aria-label={label}
      className="inline-block h-1 shrink-0 overflow-hidden rounded-full bg-[var(--t-track)] align-middle"
      style={{ width }}
    >
      <span className="block h-full rounded-full" style={{ width: `${pct}%`, background: tone ?? 'var(--t-brand)' }} />
    </span>
  );
}
