import { ArrowDown, ArrowRight } from 'lucide-react';
import { TONE_VAR, cn } from './cn';

/**
 * Relationships read left to right as a chain: who can reach this record,
 * the record itself, and what it can reach (docs/RESEARCH.md - the Entro
 * lineage map and Datadog's access path). Each column is a step; the record
 * the page is about is marked, and a step that carries risk is drawn in its
 * severity colour where the risk is.
 *
 * steps: [{
 *   key, label,            the column heading ("Who can assume it")
 *   self?,                 this record
 *   tone?,                 severity of this step, if any
 *   items: [{ title, meta?, mono?, tone? }],
 *   empty?,                text when items is empty
 *   footer?,               a node (link, button) under the items
 * }]
 * links: the verb on each connector, between step i and i+1 ("assumes", "grants")
 */
export function AccessChain({ steps, links = [] }) {
  return (
    <ol className="flex flex-col items-stretch gap-1 @min-[52rem]:flex-row @min-[52rem]:gap-0">
      {steps.map((step, index) => (
        <li key={step.key} className="contents">
          <Step step={step} />
          {index < steps.length - 1 && <Connector label={links[index]} />}
        </li>
      ))}
    </ol>
  );
}

function Step({ step }) {
  const tone = step.tone ? TONE_VAR[step.tone] : null;
  return (
    <section
      className={cn(
        'relative flex min-w-0 flex-1 flex-col rounded-[var(--radius-control)] border bg-surface px-3.5 py-3',
        step.self ? 'border-brand/50 shadow-[0_0_0_3px_color-mix(in_srgb,var(--t-brand)_12%,transparent)]' : 'border-line',
      )}
      style={tone && !step.self ? { borderColor: `color-mix(in srgb, ${tone} 55%, transparent)`, boxShadow: `inset 3px 0 0 ${tone}` } : undefined}
    >
      <h3 className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{step.label}</h3>
      {step.items.length === 0 ? (
        <p className="mt-1.5 text-[12.5px] text-ink-3">{step.empty ?? 'None'}</p>
      ) : (
        <ul className="mt-1.5 flex flex-col gap-1.5">
          {step.items.map((item, index) => (
            <li key={`${item.title}-${index}`} className="min-w-0">
              <p
                className={cn('line-clamp-2 text-[13px] font-semibold break-words text-ink', item.mono && 'font-mono text-[12px] break-all')}
                title={typeof item.title === 'string' ? item.title : undefined}
                style={item.tone ? { color: TONE_VAR[item.tone] } : undefined}
              >
                {item.title}
              </p>
              {item.meta && <p className="truncate text-[11.5px] text-ink-3" title={typeof item.meta === 'string' ? item.meta : undefined}>{item.meta}</p>}
            </li>
          ))}
        </ul>
      )}
      {step.footer && <div className="mt-auto pt-2">{step.footer}</div>}
    </section>
  );
}

function Connector({ label }) {
  return (
    <div aria-hidden={!label} className="flex shrink-0 items-center justify-center gap-1.5 py-0.5 text-ink-3 @min-[52rem]:w-[4.5rem] @min-[52rem]:flex-col @min-[52rem]:py-0">
      {label && <span className="text-[10.5px] font-medium whitespace-nowrap">{label}</span>}
      <ArrowDown className="size-3.5 @min-[52rem]:hidden" />
      <ArrowRight className="hidden size-4 @min-[52rem]:block" />
    </div>
  );
}
