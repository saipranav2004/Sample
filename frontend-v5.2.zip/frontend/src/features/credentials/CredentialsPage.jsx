import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarClock, Copy, Download, FileJson, Hourglass, KeyRound, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchCredentialCounts, fetchCredentials, fetchExpiringCredentials, fetchStaleCredentials } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { formatNumber } from '../../lib/format';
import { credentialTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { Page, Reveal } from '../../lib/motion';
import { useExport } from '../../lib/useExport';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { FilterBar, FilterSelect, LinkedFilters } from '../../ui/FilterBar';
import { SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { Tabs } from '../../ui/Tabs';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { StatusText } from '../../ui/Tag';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar } from '../../ui/WorkArea';
import { copyText } from '../identities/IdentitiesPage';
import { ClockView } from './ClockView';
import { ExpiryCell, LastUsedCell, PrivilegeCell, RotationCell } from './parts';
import { EXPORT_SORTABLE, FILTER_KEYS, PAGE_SIZES, appliedCount, readListState } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const LABELS = {
  search: 'Search',
  credential_type: 'Type',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  rotation_enabled: 'Rotation',
  expiring_within_days: 'Expires within',
  stale_days: 'Unused for',
  privilege_level_min: 'Privilege',
  privilege_level_max: 'Privilege',
  owner_principal_arn: 'Owner',
};

/* Privilege is scored for IAM roles only; other credentials have none. */
const PRIVILEGE_BANDS = [
  { value: '8-10', label: 'Critical', hint: 'Level 8-10, IAM roles' },
  { value: '6-7', label: 'High', hint: 'Level 6-7, IAM roles' },
  { value: '4-5', label: 'Medium', hint: 'Level 4-5, IAM roles' },
  { value: '0-3', label: 'Low', hint: 'Level 0-3, IAM roles' },
];

/* Filters a link can carry (the dashboard, a credential's owner) that the
   filter row does not offer. They show as removable chips. */
const VIEW_KEYS = ['all', 'expiring', 'stale'];

const LINKED = ['region', 'expiring_within_days', 'stale_days', 'rotation_enabled', 'owner_principal_arn'];

/**
 * Credential inventory: GET /api/v1/inventory/credentials, filtered, sorted
 * and paged on the server. All state lives in the URL.
 */
export default function CredentialsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => {
    try {
      return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
    } catch {
      return 'comfortable';
    }
  });

  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const listKey = JSON.stringify([filters, page, limit, sort]);
  const inventoryView = !['expiring', 'stale'].includes(searchParams.get('view'));
  const list = useQuery(
    (signal) => fetchCredentials({ ...filters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
    { enabled: inventoryView },
  );
  const counts = useQuery(
    (signal) => fetchCredentialCounts({ account_id: filters.account_id, region: filters.region }, signal),
    [filters.account_id, filters.region],
  );
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('credentials');
  const onExport = (format) =>
    exporter.run(format, {
      ...filters,
      ...(EXPORT_SORTABLE.has(sort.key) ? { sort_by: sort.key, sort_order: sort.direction } : {}),
    });

  const byType = counts.data?.by_type ?? {};
  const typeOptions = [...new Set([...options.credentialTypes, ...Object.keys(byType)])]
    .sort((x, y) => (byType[y] ?? 0) - (byType[x] ?? 0))
    .map((value) => ({ value, label: credentialTypeLabel(value), count: byType[value] }));
  const accountOptions = options.accounts.map((value) => ({ value, label: value, mono: true }));
  const band = filters.privilege_level_min || filters.privilege_level_max ? `${filters.privilege_level_min || 0}-${filters.privilege_level_max || 10}` : '';
  const setBand = (value) => {
    if (!value) update({ privilege_level_min: '', privilege_level_max: '' });
    else {
      const [min, max] = value.split('-');
      update({ privilege_level_min: min, privilege_level_max: max === '10' ? '' : max });
    }
  };
  const bandOptions = PRIVILEGE_BANDS.some((option) => option.value === band) || !band ? PRIVILEGE_BANDS : [...PRIVILEGE_BANDS, { value: band, label: `Level ${band}` }];

  const offered = ['status', 'credential_type', 'account_id'].filter((key) => filters[key]).length + (band ? 1 : 0);
  const clearOffered = () => update({ status: '', credential_type: '', account_id: '', privilege_level_min: '', privilege_level_max: '' });
  const linked = LINKED.filter((key) => filters[key]).map((key) => ({
    key,
    label: LABELS[key],
    value: describe(key, filters),
    mono: key === 'owner_principal_arn' || key === 'region',
  }));

  const statusOptions = [
    { value: 'active', label: 'Active', count: counts.data?.active },
    { value: 'inactive', label: 'Inactive', count: counts.data?.inactive },
    { value: 'expired', label: 'Expired', count: counts.data?.expired },
    { value: 'pending_deletion', label: 'Pending deletion' },
  ];

  /* The view tabs: the whole inventory, and the two clocks people act on.
     Each count is the same request its view makes, at the window in use. */
  const view = VIEW_KEYS.includes(searchParams.get('view')) ? searchParams.get('view') : 'all';
  const windowDays = (key, fallback) => {
    const n = Number(searchParams.get('days'));
    return view === key && Number.isInteger(n) && n >= 1 ? n : fallback;
  };
  const expiringDays = windowDays('expiring', 30);
  const staleDays = windowDays('stale', 90);
  const expiringCount = useQuery((signal) => fetchExpiringCredentials({ days: expiringDays, limit: 1 }, signal), [expiringDays]);
  const staleCount = useQuery((signal) => fetchStaleCredentials({ days: staleDays, limit: 1 }, signal), [staleDays]);
  const viewTabs = [
    { value: 'all', label: 'All credentials', icon: KeyRound, count: counts.data ? formatNumber(counts.data.total) : undefined },
    { value: 'expiring', label: `Expiring in ${expiringDays} days`, icon: CalendarClock, count: expiringCount.data ? formatNumber(expiringCount.data.total_expiring) : undefined },
    { value: 'stale', label: `Unused ${staleDays}+ days`, icon: Hourglass, count: staleCount.data ? formatNumber(staleCount.data.total_stale) : undefined },
  ];
  const setView = (next) => {
    /* Each view has its own filters and window; a switch starts clean. */
    setSearchDraft('');
    setSearchParams(next === 'all' ? {} : { view: next });
  };


  const columns = [
    {
      key: 'name',
      header: 'Credential',
      primary: true,
      sortable: true,
      cell: (row) => <CellStack title={row.name || row.arn} mono={row.credential_type === 'access_key'} />,
    },
    {
      key: 'credential_type',
      header: 'Type',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => <span className="block truncate" title={credentialTypeLabel(row.credential_type)}>{credentialTypeLabel(row.credential_type)}</span>,
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '122px',
      priority: 'xl',
      cell: (row) => <span className="block font-mono text-[12px]">{row.account_id}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '118px',
      mobile: true,
      cell: (row) => {
        const meta = statusMeta(row.status);
        return <StatusText tone={meta.tone}>{meta.label}</StatusText>;
      },
    },
    {
      key: 'privilege_level',
      header: 'Privilege',
      sortable: true,
      width: '112px',
      priority: 'wide',
      cell: (row) => <PrivilegeCell level={row.privilege_level} credentialType={row.credential_type} />,
    },
    {
      key: 'last_used_at',
      header: 'Last used',
      sortable: true,
      width: '100px',
      priority: 'wide',
      cell: (row) => <LastUsedCell value={row.last_used_at} />,
    },
    {
      key: 'expires_at',
      header: 'Expires',
      sortable: true,
      width: '142px',
      mobile: true,
      cell: (row) => <ExpiryCell value={row.expires_at} />,
    },
    {
      key: 'rotation',
      header: 'Rotation',
      width: '92px',
      priority: 'xl',
      cell: (row) => <RotationCell value={row.rotation_enabled} />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Credentials"
          lede="Roles, access keys, secrets, certificates and parameters the scanner found. Open one for its hygiene, trust policy and permissions."
          tabs={<Tabs size="sm" tabs={viewTabs} value={view} onChange={setView} />}
          actions={
            <Button
              variant="secondary"
              icon={Download}
              loading={exporter.exporting === 'csv'}
              disabled={Boolean(exporter.exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          }
        />
      </Reveal>

      {view !== 'all' ? (
        <ClockView view={view} />
      ) : (
      <Reveal>
        <div ref={tableTop} className="scroll-mt-20">
          <Panel flush className="overflow-hidden">
            <RecordBar
              trailing={
                <TableToolbar>
                  <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                  <TableSettings
                    density={density}
                    onDensityChange={(value) => {
                      setDensity(value);
                      try {
                        localStorage.setItem(DENSITY_KEY, value);
                      } catch {
                        /* a reading preference; safe to lose */
                      }
                    }}
                  />
                  <OverflowMenu
                    items={[
                      {
                        key: 'json',
                        label: 'Export as JSON',
                        hint: 'Every credential matching these filters, with full records',
                        icon: FileJson,
                        onSelect: () => onExport('json'),
                        disabled: Boolean(exporter.exporting) || !can('data.export'),
                        disabledHint: exporter.exporting ? 'An export is already running' : lock('data.export'),
                      },
                    ]}
                  />
                </TableToolbar>
              }
            >
              <SearchInput
                size="sm"
                value={searchDraft}
                onChange={setSearchDraft}
                maxLength={256}
                placeholder="Search name or ARN"
                className="w-full min-w-0 sm:w-64"
              />
              <FilterBar appliedCount={offered} onClearAll={clearOffered}>
                <FilterSelect label="Status" value={filters.status} options={statusOptions} onChange={(value) => update({ status: value })} />
                <FilterSelect
                  label="Type"
                  value={filters.credential_type}
                  options={typeOptions}
                  loading={counts.isLoading || filterQuery.isLoading}
                  onChange={(value) => update({ credential_type: value })}
                />
                <FilterSelect
                  label="Account"
                  value={filters.account_id}
                  options={accountOptions}
                  loading={filterQuery.isLoading}
                  onChange={(value) => update({ account_id: value })}
                />
                <FilterSelect label="Privilege" value={band} options={bandOptions} onChange={setBand} />
              </FilterBar>
            </RecordBar>

            <LinkedFilters
              filters={linked}
              onRemove={(key) => update({ [key]: '' })}
            />

            {list.isError && !list.data ? (
              <ErrorState error={list.error} onRetry={list.refetch} />
            ) : (
              <>
                {list.isError && (
                  <div className="p-3">
                    <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                  </div>
                )}
                <DataGrid
                  caption="Credentials"
                  columns={columns}
                  rows={rows}
                  rowKey={(row) => row.id}
                  loading={list.isLoading && !list.data}
                  refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                  onRowClick={(row, event) => {
                    if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                    else setPeek(rows.indexOf(row));
                  }}
                  selectedKey={peek !== null ? rows[peek]?.id : undefined}
                  rowLabel={(row) => `Preview ${row.name || row.arn}`}
                  sort={sort}
                  onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction })}
                  density={density}
                  skeletonRows={10}
                  rowActions={(row) => (
                    <IconButton
                      icon={Copy}
                      label={`Copy ARN for ${row.name || row.arn}`}
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation();
                        copyText(row.arn).then((ok) =>
                          notify(
                            ok
                              ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                              : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                          ),
                        );
                      }}
                    />
                  )}
                  emptyState={
                    applied > 0 ? (
                      <EmptyState
                        icon={SearchX}
                        title="No credentials match these filters"
                        description="Remove a filter or change the search to widen the list."
                        action={
                          <Button variant="secondary" size="sm" onClick={clearAll}>
                            Clear all filters
                          </Button>
                        }
                      />
                    ) : (
                      <EmptyState title="No credentials discovered yet" description="Credentials appear here after the scanner completes a discovery run." />
                    )
                  }
                />
                {total > 0 && (
                  <Pagination
                    page={page}
                    pageSize={limit}
                    total={total}
                    pageSizes={PAGE_SIZES}
                    unit={total === 1 ? 'credential' : 'credentials'}
                    scrollTarget={tableTop}
                    onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                    onPageSizeChange={(size) => update({ limit: size })}
                  />
                )}
              </>
            )}
          </Panel>
        </div>
      </Reveal>
      )}
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

function describe(key, filters) {
  const value = filters[key];
  switch (key) {
    case 'credential_type':
      return credentialTypeLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'rotation_enabled':
      return value === 'true' ? 'On' : 'Off';
    case 'expiring_within_days':
      return `${value} days`;
    case 'stale_days':
      return `${value} days`;
    case 'privilege_level_min':
      return `${value}-${filters.privilege_level_max || 10}`;
    default:
      return value;
  }
}
