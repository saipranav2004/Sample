import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Copy, Download, FileJson, Fingerprint, Globe2, LayoutGrid, Moon, Rows3, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchDormantIdentities, fetchIdentities, fetchIdentitiesByAccount, fetchIdentityCounts } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { useExport } from '../../lib/useExport';
import { Page, Reveal } from '../../lib/motion';
import { SegmentedControl, Tabs } from '../../ui/Tabs';
import { DormantView } from './DormantView';
import { GroupedByClass } from './GroupedByClass';
import { formatDateTime, formatNumber, formatRelativeShort } from '../../lib/format';
import { functionalClassLabel, identityTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { FilterBar, FilterSelect, LinkedFilters } from '../../ui/FilterBar';
import { SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { StatusText } from '../../ui/Tag';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar } from '../../ui/WorkArea';
import { FILTER_KEYS, PAGE_SIZES, appliedCount, readListState, toApiFilters } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const FILTER_LABELS = {
  search: 'Search',
  identity_type: 'Type',
  functional_class: 'Class',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  owner: 'Owner',
  environment: 'Environment',
  is_public: 'Public',
  last_active_before: 'Last active before',
};

/**
 * Identity inventory: `GET /api/v1/inventory/identities`, filtered, sorted and
 * paged on the server. All state lives in the URL, so a dashboard drill-down,
 * a bookmark and a shared link resolve to the same list.
 */
export default function IdentitiesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => readDensity());

  /* Apply URL changes: every filter change returns to page one. */
  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next, { replace: false });
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  /* Back/forward or a link can change the search in the URL underneath. */
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const apiFilters = toApiFilters(filters);
  const listKey = JSON.stringify([apiFilters, page, limit, sort]);
  const list = useQuery(
    (signal) =>
      fetchIdentities({ ...apiFilters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
    { enabled: searchParams.get('view') !== 'dormant' },
  );
  const counts = useQuery((signal) => fetchIdentityCounts({}, signal), []);
  const accounts = useQuery((signal) => fetchIdentitiesByAccount({}, signal), []);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  /* A page past the end (rows removed since the link was made) goes back to
     the last page that exists rather than showing an empty table. */
  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const typeOptions = Object.entries(counts.data?.by_type ?? {})
    .filter(([, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([value, count]) => ({ value, label: identityTypeLabel(value), count }));
  const accountOptions = (accounts.data?.breakdown ?? [])
    .filter((row) => row.identity_count > 0)
    .map((row) => ({ value: row.account_id, label: row.account_id, count: row.identity_count, mono: true }));

  const offered = OFFERED.filter((key) => filters[key]).length;
  const linked = FILTER_KEYS.filter((key) => filters[key] && !OFFERED.includes(key) && !STATUS_AND_SEARCH.includes(key)).map((key) => ({
    key,
    label: FILTER_LABELS[key],
    value: describeValue(key, filters[key]),
    mono: key === 'region',
  }));
  const clearOffered = () => update(Object.fromEntries(OFFERED.map((key) => [key, ''])));

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('identities');
  const exporting = exporter.exporting;
  /* Export takes the list filters; page and limit are left off so the file
     holds every match, not the page on screen. */
  const onExport = (format) => exporter.run(format, { ...apiFilters, sort_by: sort.key, sort_order: sort.direction });
  const view = searchParams.get('view') === 'class' ? 'class' : 'table';

  const columns = [
    {
      key: 'name',
      header: 'Identity',
      primary: true,
      sortable: true,
      cell: (row) => <CellStack title={row.name || row.arn} />,
    },
    {
      key: 'identity_type',
      header: 'Type',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => <span className="block truncate" title={identityTypeLabel(row.identity_type)}>{identityTypeLabel(row.identity_type)}</span>,
    },
    {
      key: 'functional_class',
      header: 'Class',
      sortable: true,
      width: '112px',
      priority: 'wide',
      cell: (row) => <span className="block truncate" title={functionalClassLabel(row.functional_class)}>{functionalClassLabel(row.functional_class)}</span>,
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '122px',
      priority: 'wide',
      cell: (row) => <span className="block font-mono text-[12px]">{row.account_id}</span>,
    },
    {
      key: 'region',
      header: 'Region',
      sortable: true,
      width: '104px',
      priority: 'xl',
      cell: (row) => <span className="block truncate font-mono text-[12px]">{regionLabel(row.region)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '112px',
      mobile: true,
      cell: (row) => {
        const meta = statusMeta(row.status);
        return (
          <span className="inline-flex max-w-full items-center gap-2">
            <StatusText tone={meta.tone}>{meta.label}</StatusText>
            {row.is_publicly_accessible === true && (
              <Globe2 aria-label="Publicly accessible" className="size-3.5 shrink-0 text-critical">
                <title>Publicly accessible</title>
              </Globe2>
            )}
          </span>
        );
      },
    },
    {
      key: 'owner',
      header: 'Owner',
      width: '120px',
      priority: 'xl',
      cell: (row) => (row.owner ? <span className="block truncate" title={row.owner}>{row.owner}</span> : <span className="block truncate text-ink-3">None</span>),
    },
    {
      key: 'last_activity_at',
      header: 'Last active',
      sortable: true,
      width: '104px',
      mobile: true,
      cell: (row) =>
        row.last_activity_at ? (
          <span className="block truncate" title={formatDateTime(row.last_activity_at)}>{formatRelativeShort(row.last_activity_at)}</span>
        ) : (
          <span className="block truncate text-ink-3" title="AWS records no last-used time for this identity">
            Not tracked
          </span>
        ),
    },
  ];

  const statusOptions = [
    { value: 'active', label: 'Active', count: counts.data?.active },
    { value: 'stopped', label: 'Stopped', count: counts.data?.stopped },
    { value: 'terminated', label: 'Terminated', count: counts.data?.terminated },
  ];

  /* View tabs: the inventory, and the two conditions people act on. */
  const pageView = searchParams.get('view') === 'dormant' ? 'dormant' : filters.is_public === 'true' && !searchParams.get('view') ? 'exposed' : 'all';
  const dormantDays = (() => {
    const n = Number(searchParams.get('days'));
    return pageView === 'dormant' && [30, 60, 90, 180, 365].includes(n) ? n : 90;
  })();
  const exposedCount = useQuery((signal) => fetchIdentities({ is_public: 'true', limit: 1 }, signal), []);
  const dormantCount = useQuery((signal) => fetchDormantIdentities({ days: dormantDays, limit: 1 }, signal), [dormantDays]);
  const viewTabs = [
    { value: 'all', label: 'All identities', icon: Fingerprint, count: counts.data ? formatNumber(counts.data.total) : undefined },
    { value: 'exposed', label: 'Internet-exposed', icon: Globe2, count: exposedCount.data ? formatNumber(exposedCount.data.total) : undefined },
    { value: 'dormant', label: `Dormant ${dormantDays}+ days`, icon: Moon, count: dormantCount.data ? formatNumber(dormantCount.data.total_dormant) : undefined },
  ];
  const setPageView = (next) => {
    setSearchDraft('');
    setSearchParams(next === 'dormant' ? { view: 'dormant' } : next === 'exposed' ? { is_public: 'true' } : {});
  };


  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Identities"
          lede="Every non-human identity discovered in your AWS accounts. Open one for its full record, timeline and type-specific attributes."
          tabs={<Tabs size="sm" tabs={viewTabs} value={pageView} onChange={setPageView} />}
          actions={
            <Button
              variant="secondary"
              icon={Download}
              loading={exporting === 'csv'}
              disabled={Boolean(exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          }
        />
      </Reveal>

      {pageView === 'dormant' ? (
        <DormantView />
      ) : (
      <Reveal>
        <div ref={tableTop} className="scroll-mt-20">
          <Panel flush className="overflow-hidden">
            <RecordBar
              trailing={
                <TableToolbar>
                  {pageView === 'all' && (
                    <SegmentedControl
                      label="View"
                      value={view}
                      onChange={(next) => update({ view: next === 'class' ? 'class' : '' }, { keepPage: true })}
                      options={[
                        { value: 'table', label: 'Table', icon: Rows3 },
                        { value: 'class', label: 'By class', icon: LayoutGrid },
                      ]}
                    />
                  )}
                  <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                  <TableSettings
                    density={density}
                    onDensityChange={(value) => {
                      setDensity(value);
                      writeDensity(value);
                    }}
                  />
                  <OverflowMenu
                    items={[
                      {
                        key: 'json',
                        label: 'Export as JSON',
                        hint: 'Every identity matching these filters, with full records',
                        icon: FileJson,
                        onSelect: () => onExport('json'),
                        disabled: Boolean(exporting) || !can('data.export'),
                        disabledHint: exporting ? 'An export is already running' : lock('data.export'),
                      },
                    ]}
                  />
                </TableToolbar>
              }
            >
              <SearchInput
                size="sm"
                value={searchDraft}
                onChange={setSearchDraft}
                maxLength={256}
                placeholder="Search name or ARN"
                className="w-full min-w-0 sm:w-64"
              />
              <FilterBar appliedCount={offered} onClearAll={clearOffered}>
                <FilterSelect label="Status" value={filters.status} options={statusOptions} onChange={(value) => update({ status: value })} />
                <FilterSelect
                  label="Type"
                  value={filters.identity_type}
                  options={typeOptions}
                  loading={counts.isLoading}
                  onChange={(value) => update({ identity_type: value })}
                />
                <FilterSelect
                  label="Account"
                  value={filters.account_id}
                  options={accountOptions}
                  loading={accounts.isLoading}
                  onChange={(value) => update({ account_id: value })}
                />
                {pageView !== 'exposed' && (
                  <FilterSelect
                    label="Internet exposure"
                    value={filters.is_public}
                    options={EXPOSURE_OPTIONS}
                    onChange={(value) => update({ is_public: value })}
                  />
                )}
              </FilterBar>
            </RecordBar>

            <LinkedFilters filters={linked} onRemove={(key) => update({ [key]: '' })} />

            {view === 'class' ? (
              <GroupedByClass accountId={filters.account_id} region={filters.region} />
            ) : list.isError && !list.data ? (
              <ErrorState
                error={list.error}
                onRetry={list.error?.status === 400 ? undefined : list.refetch}
                title={list.error?.status === 400 ? 'These filters were not accepted' : undefined}
              />
            ) : (
              <>
                {list.isError && (
                  <div className="p-3">
                    <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                  </div>
                )}
                <DataGrid
                  caption="Discovered identities"
                  columns={columns}
                  rows={rows}
                  rowKey={(row) => row.id}
                  loading={list.isLoading && !list.data}
                  refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                  onRowClick={(row, event) => {
                    if (event?.metaKey || event?.ctrlKey) window.open(`/identities/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                    else setPeek(rows.indexOf(row));
                  }}
                  selectedKey={peek !== null ? rows[peek]?.id : undefined}
                  rowLabel={(row) => `Preview ${row.name || row.arn}`}
                  sort={sort}
                  onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction }, { keepPage: false })}
                  density={density}
                  skeletonRows={10}
                  rowActions={(row) => (
                    <IconButton
                      icon={Copy}
                      label={`Copy ARN for ${row.name || row.arn}`}
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation();
                        copyText(row.arn).then((ok) =>
                          notify(
                            ok
                              ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                              : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                          ),
                        );
                      }}
                    />
                  )}
                  emptyState={
                    applied > 0 ? (
                      <EmptyState
                        icon={SearchX}
                        title="No identities match these filters"
                        description="Remove a filter or change the search to widen the list."
                        action={
                          <Button variant="secondary" size="sm" onClick={clearAll}>
                            Clear all filters
                          </Button>
                        }
                      />
                    ) : (
                      <EmptyState
                        title="No identities discovered yet"
                        description="Identities appear here after the scanner completes a discovery run on a connected AWS account."
                      />
                    )
                  }
                />
                {total > 0 && (
                  <Pagination
                    page={page}
                    pageSize={limit}
                    total={total}
                    pageSizes={PAGE_SIZES}
                    unit={total === 1 ? 'identity' : 'identities'}
                    scrollTarget={tableTop}
                    onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                    onPageSizeChange={(size) => update({ limit: size })}
                  />
                )}
              </>
            )}
          </Panel>
        </div>
      </Reveal>
      )}
      <RecordPreview kind="identity" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

/* ── Filters ─────────────────────────────────────────────────────────────── */

/* The categories offered in the filter row. Everything else in FILTER_KEYS
   can still arrive on a link and shows as a removable chip. */
const OFFERED = ['status', 'identity_type', 'account_id', 'is_public'];
const STATUS_AND_SEARCH = ['search'];

const EXPOSURE_OPTIONS = [
  { value: 'true', label: 'Publicly accessible', hint: 'Reachable from the internet' },
  { value: 'false', label: 'Not public' },
];

function describeValue(key, value) {
  switch (key) {
    case 'identity_type':
      return identityTypeLabel(value);
    case 'functional_class':
      return functionalClassLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'is_public':
      return value === 'true' ? 'Yes' : 'No';
    default:
      return value;
  }
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */

function readDensity() {
  try {
    return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
  } catch {
    return 'comfortable';
  }
}

function writeDensity(value) {
  try {
    localStorage.setItem(DENSITY_KEY, value);
  } catch {
    /* a reading preference; safe to lose */
  }
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
