import { useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Braces, Clock, Fingerprint, Globe2, ListTree, Pencil, ScrollText, ShieldAlert } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchIdentity, fetchIdentityAttributes, fetchIdentityTimeline } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import { functionalClassLabel, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { DetailList, DetailRow, Panel, PanelHeader } from '../../ui/Panel';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { AccessChain } from '../../ui/AccessChain';
import { LifeTimeline } from '../../ui/LifeTimeline';
import { EditIdentityDialog } from './EditIdentityDialog';
import { AttributeList, JsonBlock, tagEntries } from './JsonView';
import { SignalList, identitySignals } from './signals';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const TABS = [
  { value: 'overview', label: 'Overview', icon: Fingerprint },
  { value: 'attributes', label: 'Attributes', icon: ListTree },
  { value: 'timeline', label: 'Timeline', icon: Clock },
  { value: 'raw', label: 'Raw record', icon: Braces },
];

/**
 * One identity: `GET /api/v1/inventory/identities/{id}`, with its
 * type-specific attributes and timeline from their own endpoints. The tab is
 * in the URL so a link can land on the part that matters.
 */
export default function IdentityPage() {
  const { id } = useParams();
  const validId = UUID.test(id ?? '');
  const [searchParams, setSearchParams] = useSearchParams();
  const { can, lock } = useAccess();
  const [editing, setEditing] = useState(false);

  const detail = useQuery((signal) => fetchIdentity(id, signal), [id], { enabled: validId });
  const requested = searchParams.get('tab') || 'overview';
  const tab = TABS.some((entry) => entry.value === requested) ? requested : 'overview';
  const attributes = useQuery((signal) => fetchIdentityAttributes(id, signal), [id], {
    enabled: validId && tab === 'attributes',
  });
  const timeline = useQuery((signal) => fetchIdentityTimeline(id, signal), [id], {
    enabled: validId && tab === 'timeline',
  });

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/identities" icon={ArrowLeft}>
      Identities
    </Button>
  );

  const identity = detail.data;

  if (!validId || (detail.isError && !identity)) {
    const missing = !validId || detail.error?.status === 404 || detail.error?.status === 400;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Identity" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={Fingerprint}
              title="No identity with that id"
              description="It may have been removed by a later discovery run, or the link is incomplete. Find it again from Identities."
              action={back}
            />
          ) : (
            <ErrorState error={detail.error} onRetry={detail.refetch} />
          )}
        </Panel>
      </div>
    );
  }

  if (!identity) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} />
        <Panel prominence="lead">
          <DetailSkeleton rows={8} />
        </Panel>
        <span role="status" className="sr-only">
          Loading identity
        </span>
      </div>
    );
  }

  const status = statusMeta(identity.status);
  const tags = tagEntries(identity.ownership?.tags);

  return (
    <Page className="flex flex-col gap-6">
      <Reveal>
      <PageHeader
        title={<span className="block min-w-0 truncate font-mono">{identity.name || identity.arn}</span>}
        lede={identitySummary(identity)}
        actions={
          <>
            <Button
              variant="primary"
              icon={Pencil}
              onClick={() => setEditing(true)}
              locked={lock('identity.edit')}
              disabled={Boolean(identity.deleted_at)}
              title={identity.deleted_at ? 'A deleted identity cannot be edited' : undefined}
            >
              Edit ownership
            </Button>
          </>
        }
        meta={
          <div className="flex flex-wrap items-center gap-2">
            <Tag tone={status.tone} dot>
              {status.label}
            </Tag>
            {identity.network?.is_publicly_accessible === true && (
              <Tag tone="critical" icon={Globe2}>
                Publicly accessible
              </Tag>
            )}
            {identity.deleted_at && <Tag tone="neutral">Deleted {formatRelative(identity.deleted_at)}</Tag>}
            <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
              <CopyableValue value={identity.arn} />
            </span>
          </div>
        }
        tabs={<Tabs size="sm" tabs={TABS} value={tab} onChange={setTab} />}
      />
      </Reveal>
      <Reveal key={tab}>

      {tab === 'overview' && <OverviewTab identity={identity} tags={tags} />}

      {tab === 'attributes' && (
        <Panel>
          <PanelHeader
            title={`${identityTypeLabel(identity.identity_type)} attributes`}
            subtitle="Fields AWS reports for this kind of resource, as the scanner recorded them."
          />
          <div className="mt-3">
            {attributes.isError ? (
              <ErrorState compact error={attributes.error} onRetry={attributes.refetch} />
            ) : !attributes.data ? (
              <DetailSkeleton rows={6} />
            ) : (
              <AttributeList
                value={attributes.data.type_attributes}
                emptyTitle="No type-specific attributes"
                emptyText="The scanner recorded no extra attributes for this identity."
              />
            )}
          </div>
        </Panel>
      )}

      {tab === 'timeline' && <TimelineTab query={timeline} />}

      {tab === 'raw' && (
        <Panel>
          <PanelHeader
            title="Raw AWS response"
            subtitle="Exactly what the AWS API returned when the scanner discovered this identity."
          />
          <div className="mt-3">
            {identity.raw_api_response === null || identity.raw_api_response === undefined ? (
              <EmptyState compact icon={ScrollText} title="No raw response stored" description="The scanner did not keep the AWS response for this identity." />
            ) : (
              <JsonBlock value={identity.raw_api_response} copyLabel="Copy JSON" />
            )}
          </div>
        </Panel>
      )}

      </Reveal>

      <EditIdentityDialog
        open={editing && can('identity.edit')}
        identity={identity}
        onClose={() => setEditing(false)}
        onSaved={() => {
          setEditing(false);
          detail.refetch();
        }}
      />
    </Page>
  );
}

function Missing({ children = 'Not recorded' }) {
  return <span className="text-ink-3">{children}</span>;
}

const DAY = 86_400_000;

/** One plain sentence: what it is, who owns it, how exposed and how used. */
function identitySummary(identity) {
  const owner = identity.ownership?.owner;
  const env = identity.ownership?.environment;
  const pub = identity.network?.is_publicly_accessible;
  const head = `${identityTypeLabel(identity.identity_type)} (${functionalClassLabel(identity.functional_class)}) in account ${identity.account_id}, ${regionLabel(identity.region)}`;
  const who = owner ? `owned by ${owner}${env ? ` in ${env}` : ''}` : 'with no owner recorded';
  const facts = [
    pub === true ? 'reachable from the internet' : pub === false ? 'not publicly reachable' : null,
    identity.last_activity_at ? `last active ${formatRelative(identity.last_activity_at)}` : 'no activity recorded by AWS',
  ].filter(Boolean);
  return `${head}, ${who}. ${facts.join(', ').replace(/^./, (c) => c.toUpperCase())}.`;
}

/** The last segment of an ARN, and the AWS service it belongs to. */
function arnParts(arn) {
  const text = String(arn ?? '');
  const parts = text.split(':');
  const resource = parts.slice(5).join(':');
  const segments = resource.split('/').filter(Boolean);
  /* CloudFormation stacks are stack/<name>/<id>; the id says nothing to a reader. */
  const name = parts[2] === 'cloudformation' && segments[0] === 'stack' && segments[1] ? segments[1] : segments.pop();
  return { service: parts[2] ?? '', account: parts[4] ?? '', name: name || resource || text };
}

const SERVICE_NAMES = { cloudformation: 'CloudFormation stack', iam: 'IAM', ecs: 'ECS', eks: 'EKS', lambda: 'Lambda', ec2: 'EC2', sagemaker: 'SageMaker', bedrock: 'Bedrock', apprunner: 'App Runner' };

function OverviewTab({ identity, tags }) {
  const network = identity.network ?? {};
  const ownership = identity.ownership ?? {};
  const lineage = identity.lineage ?? {};
  const discovery = identity.discovery ?? {};
  const groups = Array.isArray(network.security_group_ids) ? network.security_group_ids.map(String) : [];
  const [now] = useState(() => Date.now());
  const lastActive = parseDate(identity.last_activity_at);
  const inactiveDays = lastActive ? Math.floor((now - lastActive.getTime()) / DAY) : null;
  const creator = lineage.cloudtrail_creator_arn ? arnParts(lineage.cloudtrail_creator_arn) : null;
  const parent = lineage.parent_arn ? arnParts(lineage.parent_arn) : null;
  const isPublic = network.is_publicly_accessible === true;

  return (
    <div className="flex flex-col gap-4">
      {/* 1. What is wrong, with the next step for each. */}
      <Panel prominence="lead">
        <PanelHeader title="What needs attention" subtitle="Exposure, use and ownership checks on this identity, with the next step for each." icon={ShieldAlert} />
        <div className="mt-3">
          <SignalList signals={identitySignals(identity)} />
        </div>
      </Panel>

      {/* 2. Is it in use: its life on one line. */}
      <Panel>
        <PanelHeader
          title="Activity"
          subtitle="Its life on one line. A long gap since it was last active is the case for removing it."
          icon={Clock}
        />
        <div className="mt-5">
          <LifeTimeline
            now={now}
            events={[
              { key: 'created', label: 'Created in AWS', at: identity.created_at_aws },
              { key: 'discovered', label: 'First discovered', at: identity.first_seen_at, tone: 'neutral' },
              { key: 'active', label: 'Last active', at: identity.last_activity_at, tone: 'low' },
              { key: 'confirmed', label: 'Last confirmed', at: identity.last_seen_at, tone: 'info' },
              ...(identity.deleted_at ? [{ key: 'deleted', label: 'Deleted', at: identity.deleted_at, tone: 'critical' }] : []),
            ]}
            gaps={
              inactiveDays !== null && inactiveDays >= 30
                ? [{ from: identity.last_activity_at, to: 'now', label: `Inactive for ${inactiveDays} days`, tone: inactiveDays >= 90 ? 'high' : 'medium' }]
                : []
            }
          />
          {lastActive && parseDate(identity.created_at_aws) && lastActive < parseDate(identity.created_at_aws) && (
            <p className="mt-3 rounded-[var(--radius-control)] border border-medium/30 bg-medium-soft px-3 py-2 text-[12px] text-ink-2">
              AWS reports this identity as last active before it was created. One of the two dates is wrong in the source data, so treat the inactive period as approximate.
            </p>
          )}
        </div>
      </Panel>

      {/* 3. Where it came from and who can reach it. */}
      <Panel>
        <PanelHeader title="Origin and reach" subtitle="Who created it, what it belongs to, and where it can be reached from." icon={Globe2} />
        <div className="mt-3">
          <AccessChain
            links={['created', 'runs in']}
            steps={[
              {
                key: 'creator',
                label: 'Created by',
                empty: 'Not found in CloudTrail',
                items: creator ? [{ title: creator.name, meta: `${SERVICE_NAMES[creator.service] ?? creator.service} · account ${creator.account}`, mono: true }] : [],
                footer: lineage.cloudtrail_creator_arn ? <CopyableValue value={lineage.cloudtrail_creator_arn} className="text-[11px]" /> : null,
              },
              {
                key: 'self',
                label: 'This identity',
                self: true,
                items: [
                  { title: identity.name || identity.arn, meta: `${identityTypeLabel(identity.identity_type)} · ${statusMeta(identity.status).label}` },
                  parent
                    ? { title: `Part of ${parent.name}`, meta: SERVICE_NAMES[parent.service] ?? parent.service }
                    : { title: 'No parent resource', meta: 'Not part of a stack or group' },
                ],
              },
              {
                key: 'network',
                label: 'Network',
                tone: isPublic ? 'critical' : undefined,
                items: [
                  isPublic
                    ? { title: 'Reachable from the internet', meta: 'Publicly accessible', tone: 'critical' }
                    : network.is_publicly_accessible === false
                      ? { title: 'Not publicly reachable', meta: 'Private' }
                      : { title: 'Exposure not determined', meta: 'The scanner could not tell' },
                  { title: network.vpc_id || 'No VPC recorded', meta: network.subnet_id ? `subnet ${network.subnet_id}` : 'No subnet recorded', mono: Boolean(network.vpc_id) },
                  { title: groups.length ? `${groups.length} security group${groups.length === 1 ? '' : 's'}` : 'No security groups', meta: groups.join(', ') || undefined },
                ],
              },
            ]}
          />
        </div>
      </Panel>

      {/* 4. Who answers for it, then the reference record. */}
      <div className="grid gap-4 @min-[60rem]:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <Panel>
          <PanelHeader title="Ownership" subtitle="Who is responsible for this identity, and where it runs." />
          <DetailList className="mt-2">
            <DetailRow label="Owner">{ownership.owner || <Missing>No owner tag</Missing>}</DetailRow>
            <DetailRow label="Environment">{ownership.environment || <Missing>No environment tag</Missing>}</DetailRow>
            <DetailRow label="Tags">
              {tags.length === 0 ? (
                <Missing>No tags</Missing>
              ) : (
                <span className="flex flex-wrap gap-1.5">
                  {tags.map(([key, value]) => (
                    <span key={key} className="inline-flex max-w-full items-center rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px]">
                      <span className="text-ink-3">{key}</span>
                      {value !== '' && value !== null && (
                        <span className="truncate text-ink">={typeof value === 'object' ? JSON.stringify(value) : String(value)}</span>
                      )}
                    </span>
                  ))}
                </span>
              )}
            </DetailRow>
          </DetailList>
        </Panel>

        <Panel prominence="quiet">
          <PanelHeader title="Record" prominence="quiet" />
          <DetailList className="mt-2">
            <DetailRow label="ID" mono>
              <CopyableValue value={identity.id} />
            </DetailRow>
            <DetailRow label="Source">{tokenLabel(discovery.discovery_source)}</DetailRow>
            <DetailRow label="Scan" mono>
              {discovery.scan_id || <Missing />}
            </DetailRow>
            {parent && (
              <DetailRow label="Parent ARN" mono>
                <CopyableValue value={lineage.parent_arn} />
              </DetailRow>
            )}
          </DetailList>
        </Panel>
      </div>
    </div>
  );
}

const EVENT_LABELS = {
  first_discovered: { label: 'First discovered', hint: 'The scanner saw this identity for the first time.' },
  last_activity: { label: 'Last active', hint: 'The most recent use AWS has recorded.' },
  last_confirmed: { label: 'Last confirmed', hint: 'The latest scan that still found it.' },
};

function TimelineTab({ query }) {
  if (query.isError) {
    return (
      <Panel>
        <ErrorState error={query.error} onRetry={query.refetch} />
      </Panel>
    );
  }
  if (!query.data) {
    return (
      <Panel>
        <ListSkeleton rows={3} />
      </Panel>
    );
  }
  const data = query.data;
  const events = [...(data.events ?? [])].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
  /* The API reports 0 days when there is no activity at all; only a
     last_activity event makes the figure meaningful. */
  const tracked = events.some((event) => event.event === 'last_activity');
  return (
    <Panel>
      <PanelHeader title="Timeline" />
      <dl className="mt-3 grid grid-cols-2 gap-3 border-b border-line pb-4">
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Known for</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {formatNumber(data.age_days)} <span className="text-[12px] font-medium text-ink-3">days</span>
          </dd>
        </div>
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Since last activity</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {!tracked || data.days_since_last_activity === null || data.days_since_last_activity === undefined ? (
              <span className="text-[13px] font-medium text-ink-3">Not tracked</span>
            ) : (
              <>
                {formatNumber(data.days_since_last_activity)} <span className="text-[12px] font-medium text-ink-3">days</span>
              </>
            )}
          </dd>
        </div>
      </dl>
      <ol className="mt-4 flex flex-col gap-4 border-l border-line pl-5">
        {events.map((event) => {
          const meta = EVENT_LABELS[event.event] ?? { label: tokenLabel(event.event), hint: '' };
          return (
            <li key={`${event.event}-${event.timestamp}`} className="relative">
              <span aria-hidden="true" className="absolute top-1.5 -left-[25px] size-2.5 rounded-full border-2 border-surface bg-brand" />
              <p className="text-[13px] font-medium text-ink">{meta.label}</p>
              <p className="text-[12px] text-ink-3">
                <time dateTime={event.timestamp}>{formatDateTime(event.timestamp)}</time> · {formatRelative(event.timestamp)}
              </p>
              {meta.hint && <p className="mt-0.5 text-[12px] text-ink-3">{meta.hint}</p>}
            </li>
          );
        })}
      </ol>
    </Panel>
  );
}
