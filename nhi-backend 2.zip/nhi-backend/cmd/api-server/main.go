package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/handlers/credential_exposure"
	handlerv1 "nhi-backend-api/internal/handlers/v1"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	repoce "nhi-backend-api/internal/repository/credential_exposure"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/scope"
	"nhi-backend-api/internal/services"
	svcce "nhi-backend-api/internal/services/credential_exposure"
	svcv1 "nhi-backend-api/internal/services/v1"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load configuration: %v", err)
	}

	// DB is the global authentication/tenant registry pool. Tenant pools are
	// opened only through the registry-validated db_name in a signed token.
	db, err := repository.NewPostgresDB(cfg)
	if err != nil {
		log.Fatalf("connect to global database: %v", err)
	}
	defer func() {
		if err := db.Close(); err != nil {
			log.Printf("close database pools: %v", err)
		}
	}()

	userRepo := repository.NewUserRepository(db)
	resolver := scope.NewResolver(db, db.DataSchema())

	authService := services.NewAuthService(userRepo, cfg.JWT)
	authHandler := handlers.NewAuthHandler(authService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT, userRepo)

	filterHandler := handlerv1.NewFilterHandler(svcv1.NewFilterService(repov1.NewFilterRepository(), resolver))
	settingsHandler := handlerv1.NewSettingsHandler(svcv1.NewSettingsService(repov1.NewSettingsRepository(), db, resolver))
	dashboardHandler := handlerv1.NewDashboardOverviewHandler(svcv1.NewDashboardOverviewService(repov1.NewDashboardOverviewRepository(), resolver))
	identitiesHandler := handlerv1.NewIdentitiesListHandler(svcv1.NewIdentitiesListService(repov1.NewIdentitiesListRepository(), resolver))
	identityDetailHandler := handlerv1.NewIdentityDetailHandler(svcv1.NewIdentityDetailService(repov1.NewIdentityDetailRepository(), resolver))
	credentialsHandler := handlerv1.NewCredentialsHandler(svcv1.NewCredentialsService(repov1.NewCredentialsRepository(), resolver))
	credentialDetailHandler := handlerv1.NewCredentialDetailHandler(svcv1.NewCredentialDetailService(repov1.NewCredentialDetailRepository(), resolver))

	// Credential Exposure — tenant-isolated, admin-only
	ceFindingsRepo := repoce.NewFindingsRepository()
	ceAllowlistRepo := repoce.NewAllowlistRepository()
	ceDecisionRepo := repoce.NewDecisionRepository()
	ceDeepScanRepo := repoce.NewDeepScanRepository()

	ceFindingsService := svcce.NewFindingsService(ceFindingsRepo, resolver)
	ceAllowlistService := svcce.NewAllowlistService(ceAllowlistRepo, resolver)
	ceDecisionService := svcce.NewDecisionService(ceDecisionRepo, resolver)
	ceDeepScanService := svcce.NewDeepScanService(ceDeepScanRepo, resolver, cfg.Scanner.BaseURL, cfg.Scanner.DashboardKey)

	ceFindingsHandler := credential_exposure.NewFindingsHandler(ceFindingsService)
	ceAllowlistHandler := credential_exposure.NewAllowlistHandler(ceAllowlistService)
	ceDecisionHandler := credential_exposure.NewDecisionHandler(ceDecisionService)
	ceDeepScanHandler := credential_exposure.NewDeepScanHandler(ceDeepScanService)

	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                    authHandler,
		AuthMiddleware:                 authMiddleware,
		NewAPIFilterHandler:            filterHandler,
		NewAPISettingsHandler:          settingsHandler,
		NewAPIDashboardOverviewHandler: dashboardHandler,
		NewAPIIdentitiesListHandler:    identitiesHandler,
		NewAPIIdentityDetailHandler:    identityDetailHandler,
		NewAPICredentialsHandler:       credentialsHandler,
		NewAPICredentialDetailHandler:  credentialDetailHandler,

		CredentialExposureFindingsHandler:  ceFindingsHandler,
		CredentialExposureAllowlistHandler: ceAllowlistHandler,
		CredentialExposureDecisionHandler:  ceDecisionHandler,
		CredentialExposureDeepScanHandler:  ceDeepScanHandler,
	})

	server := &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
		Handler:      middleware.SetupCORS(cfg.CORS)(router),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}
	log.Printf("NHI API server listening on %s", server.Addr)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("API server: %v", err)
	}
}
