package config

import (
	"fmt"
	"net"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

var databaseNameRE = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_-]{0,62}$`)



type Config struct {
	Server         ServerConfig   `yaml:"server"`
	GlobalDatabase DatabaseConfig `yaml:"global_database"`
	Database       DatabaseConfig `yaml:"database"` // Shared connection settings for tenant data DBs.
	JWT            JWTConfig      `yaml:"jwt"`
	CORS           CORSConfig     `yaml:"cors"`
	Scanner        ScannerConfig  `yaml:"scanner"`
}

type ServerConfig struct {
	Port int    `yaml:"port"`
	Host string `yaml:"host"`
}

type ScannerConfig struct {
	BaseURL      string `yaml:"base_url"`
	DashboardKey string `yaml:"dashboard_key"`
}

type DatabaseConfig struct {
	Host         string `yaml:"host"`
	DatabaseName string `yaml:"database_name"`
	LegacyName   string `yaml:"name"`
	User         string `yaml:"user"`
	Password     string `yaml:"password"`
	Schema       string `yaml:"schema"`
}

func (d DatabaseConfig) DBName() string {
	if name := strings.TrimSpace(d.DatabaseName); name != "" {
		return name
	}
	return strings.TrimSpace(d.LegacyName)
}

func (d DatabaseConfig) WithDBName(name string) DatabaseConfig {
	d.DatabaseName = strings.TrimSpace(name)
	d.LegacyName = ""
	return d
}

func (d DatabaseConfig) GetConnectionString() string {
	// Port and SSL are fixed in code — RDS and local both use 5432 + require.
	// No auto-upgrade, no fallback, no hints.
	const port = 5432
	const sslmode = "require"
	u := url.URL{
		Scheme:   "postgres",
		User:     url.UserPassword(d.User, d.Password),
		Host:     net.JoinHostPort(d.Host, strconv.Itoa(port)),
		Path:     "/" + d.DBName(),
		RawQuery: url.Values{"sslmode": []string{sslmode}}.Encode(),
	}
	return u.String()
}

type JWTConfig struct {
	Secret      string `yaml:"secret"`
	ExpiryHours int    `yaml:"expiry_hours"`
}

type CORSConfig struct {
	AllowedOrigins []string `yaml:"allowed_origins"`
}

func Load() (*Config, error) {
	path := strings.TrimSpace(os.Getenv("NHI_CONFIG_FILE"))
	if path == "" {
		path = "configs/config.yaml"
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %q: %w", path, err)
	}
	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parse config %q: %w", path, err)
	}
	if err := cfg.applyEnvironment(); err != nil {
		return nil, err
	}
	cfg.applyDefaults()
	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) applyEnvironment() error {
	setString := func(dst *string, key string) {
		if value, ok := os.LookupEnv(key); ok && strings.TrimSpace(value) != "" {
			*dst = strings.TrimSpace(value)
		}
	}
	setInt := func(dst *int, key string) error {
		if value, ok := os.LookupEnv(key); ok && strings.TrimSpace(value) != "" {
			parsed, err := strconv.Atoi(strings.TrimSpace(value))
			if err != nil {
				return fmt.Errorf("config: %s must be an integer", key)
			}
			*dst = parsed
		}
		return nil
	}

	setString(&c.Server.Host, "NHI_SERVER_HOST")
	if err := setInt(&c.Server.Port, "NHI_SERVER_PORT"); err != nil {
		return err
	}

	setString(&c.GlobalDatabase.Host, "NHI_GLOBAL_DB_HOST")
	setString(&c.GlobalDatabase.DatabaseName, "NHI_GLOBAL_DB_NAME")
	setString(&c.GlobalDatabase.User, "NHI_GLOBAL_DB_USER")
	setString(&c.GlobalDatabase.Password, "NHI_GLOBAL_DB_PASSWORD")
	setString(&c.GlobalDatabase.Schema, "NHI_GLOBAL_DB_SCHEMA")

	setString(&c.Database.Host, "NHI_TENANT_DB_HOST")
	setString(&c.Database.User, "NHI_TENANT_DB_USER")
	setString(&c.Database.Password, "NHI_TENANT_DB_PASSWORD")
	setString(&c.Database.Schema, "NHI_TENANT_DB_SCHEMA")

	setString(&c.JWT.Secret, "NHI_JWT_SECRET")
	if err := setInt(&c.JWT.ExpiryHours, "NHI_JWT_EXPIRY_HOURS"); err != nil {
		return err
	}
	setString(&c.Scanner.BaseURL, "SECRET_SCANNER_BASE_URL")
	setString(&c.Scanner.DashboardKey, "SECRET_SCANNER_DASHBOARD_KEY")
	setString(&c.Scanner.BaseURL, "NHI_SCANNER_BASE_URL")
	setString(&c.Scanner.DashboardKey, "NHI_SCANNER_DASHBOARD_KEY")
	if origins := strings.TrimSpace(os.Getenv("NHI_CORS_ALLOWED_ORIGINS")); origins != "" {
		c.CORS.AllowedOrigins = make([]string, 0)
		for _, origin := range strings.Split(origins, ",") {
			origin = strings.TrimSpace(origin)
			if origin != "" {
				c.CORS.AllowedOrigins = append(c.CORS.AllowedOrigins, origin)
			}
		}
	}
	return nil
}

func (c *Config) applyDefaults() {
	if c.Server.Host == "" {
		c.Server.Host = "0.0.0.0"
	}
	if c.Server.Port == 0 {
		c.Server.Port = 8080
	}
	if c.GlobalDatabase.Schema == "" {
		c.GlobalDatabase.Schema = "nhi_schema"
	}
	if c.Database.Schema == "" {
		c.Database.Schema = "nhi_scanner"
	}
}

func (c *Config) validate() error {
	if c.Server.Port < 1 || c.Server.Port > 65535 {
		return fmt.Errorf("config: server.port must be between 1 and 65535")
	}
	if strings.TrimSpace(c.Server.Host) == "" {
		return fmt.Errorf("config: server.host is required")
	}
	if c.GlobalDatabase.DBName() == "" || !databaseNameRE.MatchString(c.GlobalDatabase.DBName()) {
		return fmt.Errorf("config: global_database.database_name must be a valid PostgreSQL database name")
	}
	if strings.TrimSpace(c.GlobalDatabase.Host) == "" || strings.TrimSpace(c.GlobalDatabase.User) == "" {
		return fmt.Errorf("config: global_database host and user are required")
	}
	if strings.TrimSpace(c.Database.Host) == "" || strings.TrimSpace(c.Database.User) == "" {
		return fmt.Errorf("config: database.host and database.user are required")
	}
	if c.Database.DBName() != "" {
		return fmt.Errorf("config: omit database.database_name; tenant database names must come from tenants registry")
	}
	if strings.TrimSpace(c.JWT.Secret) == "" || len(c.JWT.Secret) < 32 {
		return fmt.Errorf("config: jwt.secret must be at least 32 characters")
	}
	if c.JWT.ExpiryHours < 1 || c.JWT.ExpiryHours > 24*30 {
		return fmt.Errorf("config: jwt.expiry_hours must be between 1 and 720")
	}
	if !databaseNameRE.MatchString(c.GlobalDatabase.Schema) || !databaseNameRE.MatchString(c.Database.Schema) {
		return fmt.Errorf("config: schema must be valid identifiers")
	}
	return nil
}

// ValidateDatabaseName rejects unsafe or malformed names before a tenant pool is opened.
func ValidateDatabaseName(name string) error {
	if !databaseNameRE.MatchString(strings.TrimSpace(name)) {
		return fmt.Errorf("invalid tenant database name")
	}
	return nil
}
