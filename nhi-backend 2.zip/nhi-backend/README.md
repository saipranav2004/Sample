# NHI Backend API — merged build

A hardened merge of the two candidate backends, validated against
`AWS-NHI Updated API.pdf` and against a real PostgreSQL instance.

**Base:** the `read.txt` tree — chosen because the tenant/account/region boundary is
enforced in one place (`internal/scope`), not re-implemented per endpoint.
**Harvested from:** the `b1.txt` tree — richer detail-tab payloads, concurrent dashboard
loading, and strict `time_range` handling, all re-expressed on top of the scoped base.

```
go build ./...            # clean
go vet ./...              # clean
go test ./...             # clean (also under -race)
```

---

## Tenant architecture

Three tiers, exactly as the document specifies:

```
nhi_global (config: global_database)
  └── nhi_schema.tenants     tenant_id (uuid) → db_name
  └── nhi_schema.nhi_users   email, bcrypt hash, role, tenant_id, status, last_login_at

nhi_tenant_<name>  (opened on demand, name comes from the JWT — never from config)
  └── nhi_scanner.*          identities, credentials, trust_edges, user_settings, …
```

**One choke point.** Every data request resolves through `scope.Resolver.Resolve()`,
which returns a `DataScope` carrying the tenant's pool *and* the effective
`AccountIDs / Regions / ScanID`:

```go
resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
// every repository entry point takes the scope, never a bare *sql.DB
rows, err := s.repo.List(ctx, resolved, filter)
// DataScope.Predicates("i") → i.scan_id = $1 AND i.account_id = ANY($2) AND i.region = ANY($3)
```

Because the repositories cannot be called without a `DataScope`, steps 3–7 of the
document's "Every Data API" flow are structurally impossible to skip.
`user_settings` appears in exactly one non-test file in the repository.

**No fallback.** `Manager.Tenant("")` returns `ErrTenantDBNotConfigured`. A tenant with no
`db_name` is an error, never a silent switch to another database.

---

## What changed relative to the two inputs

### Correctness / security

| Change | Why |
|---|---|
| **Scoped graph traversal** (`internal/repository/v1/graph_scope.go`) | A graph BFS cannot be constrained by a SQL predicate: hop 2 walks out of the selected accounts. The traversal now prunes every hop against the caller's account/region before expanding the frontier, and fails closed on unparseable ARNs. |
| **`relationships` tab enabled** on both detail endpoints | It was implemented but gated off in `read.txt` ("disabled until graph scope is enforced") and enabled-but-unscoped in `b1.txt`. It is now both enabled and safe — 6/6 tabs per the document. |
| **De-duplicated BFS edges** | Found against the live database: `loadEdgesTouching` matches `source = ANY(frontier) OR target = ANY(frontier)`, so an edge was re-emitted on every hop that touched it. A depth-2 walk reported the same edge twice. |
| **Consolidated `errScopeRequired` sentinel** | Four repositories each built their own `fmt.Errorf("tenant scope is required")`, so callers could not use `errors.Is`. |
| **`page_size` capped at 100**, **`depth` bounded to 1–3** | The document's stated limits were not enforced; `depth` accepted any value and `page_size` was unbounded. |
| **Strict `?time_range=`** (ported from `b1.txt`) | `"banana"` used to silently become 90 days. It is now a 400 with an actionable message, and the response echoes a canonical label rather than raw client input. |
| **Dead legacy code removed** | 301 → 43 Go files. Removed the unrouted dashboard/inventory/credential-exposure packages, which also cleared a genuine `go vet` failure (`fmt.Sprintf` arity bug in `shared_credentials_repo.go`). |
| **`migrations/tenant/001` creates its schema** | It assumed `nhi_scanner` already existed and failed on a fresh tenant database. |

### Performance

**Concurrent dashboard overview.** The four independent loaders (KPIs, identity charts,
credential charts, growth charts) now run in parallel with first-error cancellation of the
remaining queries, instead of sequentially. They write disjoint fields of the response
struct, verified under `-race`.

### Tests

Unit coverage for the parts where a mistake is a tenant-isolation bug:

| Package | Covers |
|---|---|
| `internal/repository/v1` | ARN account/region parsing, scope allow/deny including fail-closed, edge pruning, frontier never leaving scope, BFS de-duplication |
| `internal/scope` | `Predicates()` / `QueryArgs()` shape, empty-scope safety |
| `internal/database` | Identifier quoting, `Tenant()` has no fallback, validation rejects injection attempts |
| `internal/config` | Rejects a tenant `database_name` in config, unsafe schema identifiers, weak JWT secret, out-of-range expiry |
| `pkg/jwt` | Claim round-trip, tamper rejection, wrong-secret rejection, weak-secret rejection |
| `internal/routes` | All seven data endpoints return 401 without a token; 404/405 always return JSON |

---

## Running it locally

```bash
# 1. Postgres, then seed two tenants in two databases
export PGHOST=127.0.0.1 PGPORT=5432 PGUSER=postgres
./scripts/seed_two_tenants.sh

# 2. Point configs/config.yaml at that Postgres and run
NHI_CONFIG_FILE=configs/config.yaml go run ./cmd/api-server

# 3. Verify the tenant guarantees end to end
./scripts/e2e_tenant_scope.sh          # 16 assertions
```

`scripts/test_schema.sql` is a stand-in for the scanner's schema, which this repository
does not own. It is only for local verification — column names were derived from the
queries in `internal/repository/v1`, so treat it as a harness, not as the real schema.

### Endpoints

| # | Endpoint | Notes |
|---|---|---|
| — | `POST /api/v1/login`, `/api/auth/login` | bcrypt; rejects `status != 'active'`; updates `last_login_at` |
| 1a | `GET /api/v1/settings` | `user_settings` → `accounts.is_default` → latest completed scan |
| 1b | `PUT /api/v1/settings` | upsert; JWT is unchanged |
| 2 | `GET /api/v1/filters` | all dropdown options |
| 3 | `GET /api/v1/dashboard/overview` | KPIs + 13 charts, loaded concurrently |
| 4 | `GET /api/v1/identities` | paginated (max 100), searchable, filterable, sortable |
| 5 | `GET /api/v1/identities/{id}?tab=` | overview, permissions, activity, relationships, credentials, raw |
| 6 | `GET /api/v1/credentials` | |
| 7 | `GET /api/v1/credentials/{id}?tab=` | overview, trust, activity, rotation, relationships, raw |

---

## Known gaps

- **Endpoint 7 `trust` / `rotation` payloads** are thinner than endpoint 5's.
  `b1.txt` had richer bodies; porting them is mechanical (same
  `(ctx, resolved, id)` signature) but was not completed here.
- **`start_date` / `end_date`** — the document lists a `custom` value for
  `time_range`. `ResolveTimeRange` supports rolling windows only; adding fixed
  windows means threading start/end into the activity repositories.
- **`resources` in the graph** is not account-scoped at the SQL level (the pruning
  in `traverseGraph` still applies, so nothing leaks — it just costs one query).
- **`scripts/test_schema.sql`** is a local harness, not the production schema.
