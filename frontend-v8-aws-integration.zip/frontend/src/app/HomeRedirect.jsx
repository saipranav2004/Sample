import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { fetchAwsIntegration } from '../lib/api/endpoints';
import { homeFor } from '../lib/roles';
import { RouteFallback } from '../shell/RouteFallback';

/**
 * Where "/" - and so every fresh sign-in - lands.
 *
 * Until the workspace has a connected AWS account there is no data to show,
 * so it opens on Integrations, where the account gets connected. Once one is
 * connected it opens on the dashboard. If the check itself fails (API down,
 * platform not set up) it falls back to the dashboard, which explains its
 * own empty state, rather than holding the user on a spinner.
 */
export function HomeRedirect() {
  const [target, setTarget] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    fetchAwsIntegration(controller.signal)
      .then((integration) => setTarget(integration.status === 'connected' ? homeFor() : '/integrations'))
      .catch((error) => {
        if (!controller.signal.aborted && error?.code !== 'CANCELLED') setTarget(homeFor());
      });
    return () => controller.abort();
  }, []);

  if (!target) return <RouteFallback />;
  return <Navigate to={target} replace />;
}
