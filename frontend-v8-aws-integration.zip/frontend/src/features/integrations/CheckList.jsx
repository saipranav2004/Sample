import { AlertTriangle, CheckCircle2, CircleDashed, Loader2, XCircle } from 'lucide-react';
import { cn } from '../../ui/cn';
import { AWS_CHECKS } from './awsSetup';

const STATE = {
  pass: { icon: CheckCircle2, color: 'text-low', word: 'Passed' },
  fail: { icon: XCircle, color: 'text-critical', word: 'Failed' },
  error: { icon: AlertTriangle, color: 'text-medium', word: 'Not run' },
  skipped: { icon: CircleDashed, color: 'text-ink-3', word: 'Waiting' },
  running: { icon: Loader2, color: 'text-brand', word: 'Checking' },
};

/**
 * The three connection checks, always in the order they run. A failed check
 * names the one change that fixes it, and - where the setup is on screen -
 * opens the step that makes that change.
 *
 * `checks` null means a check is running: every row spins, since the API
 * answers for all three at once.
 */
export function CheckList({ checks, onShowStep, compact = false }) {
  const byKey = new Map((checks ?? []).map((check) => [check.key, check]));
  const running = checks === null;
  const passed = (checks ?? []).filter((check) => check.state === 'pass').length;
  const allPassed = !running && passed === AWS_CHECKS.length;
  const eventsFailed = byKey.get('events')?.state === 'fail';

  return (
    <div aria-live="polite" aria-busy={running || undefined}>
      {!running && checks && !compact && (
        <p className={cn('mb-2 text-[13px] font-semibold', allPassed ? 'text-low' : 'text-ink')}>
          {allPassed ? 'All checks passed. Your account is connected.' : `${passed} of ${AWS_CHECKS.length} checks passed`}
        </p>
      )}
      <ul className="flex flex-col">
        {AWS_CHECKS.map((meta) => {
          const check = byKey.get(meta.key);
          const state = running ? 'running' : check && Object.hasOwn(STATE, check.state) ? check.state : 'skipped';
          const { icon: Icon, color, word } = STATE[state];
          return (
            <li key={meta.key} className={cn('flex items-start gap-2.5 border-b border-line last:border-b-0', compact ? 'py-1.5' : 'py-2.5')}>
              <Icon aria-hidden="true" className={cn('mt-0.5 size-4 shrink-0', color, state === 'running' && 'animate-spin')} />
              <div className="min-w-0 flex-1">
                <p className="text-[13px] text-ink">
                  {check?.label || meta.label}
                  <span className="sr-only">: {word}</span>
                </p>
                {!running && check?.message && !compact && <p className="mt-0.5 text-[12px] text-ink-3">{check.message}</p>}
                {!running && state === 'fail' && check?.fix && (
                  <p className="mt-1 text-[12.5px] text-ink-2">
                    <span className="font-semibold text-critical">Fix:</span> {check.fix}
                    {onShowStep && (
                      <>
                        {' · '}
                        <button
                          type="button"
                          onClick={() => onShowStep(meta.step)}
                          className="font-medium text-brand hover:underline"
                        >
                          Show step {meta.step}
                        </button>
                      </>
                    )}
                  </p>
                )}
              </div>
              <span className={cn('shrink-0 text-[12px] font-medium', color)} aria-hidden="true">
                {word}
              </span>
            </li>
          );
        })}
      </ul>
      {!running && eventsFailed && !compact && (
        <p className="mt-2 rounded-[var(--radius-control)] bg-surface-2 px-3 py-2 text-[12px] leading-relaxed text-ink-2">
          Rule just created? Events only flow when something changes. Make a small change in that region (for
          example, add a tag to an EC2 instance), wait a minute, then verify again.
        </p>
      )}
    </div>
  );
}
