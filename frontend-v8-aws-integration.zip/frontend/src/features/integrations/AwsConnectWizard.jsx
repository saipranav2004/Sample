import { useId, useRef, useState } from 'react';
import { ArrowRight, ChevronDown, ExternalLink, Info, ShieldCheck } from 'lucide-react';
import { verifyAwsConnection } from '../../lib/api/endpoints';
import { formatRelative } from '../../lib/format';
import { Button } from '../../ui/Button';
import { CopyButton, CopyChip, CopyField } from '../../ui/Copyable';
import { Field, Input } from '../../ui/Field';
import { Panel, PanelHeader, SectionLabel } from '../../ui/Panel';
import { InlineError } from '../../ui/States';
import { cn } from '../../ui/cn';
import { AWS_CONSOLE, eventPatternJson, exampleRoleArn, roleArnProblem, trustPolicyJson } from './awsSetup';
import { CheckList } from './CheckList';

const STEPS = [
  { number: 1, title: 'Create a read-only role' },
  { number: 2, title: 'Forward events' },
  { number: 3, title: 'Verify' },
];

const reducedMotion = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/**
 * "Connect AWS Account": copy four values, do two things in the AWS console,
 * paste one ARN, verify.
 *
 * Every value in the instructions is the tenant's own, placed exactly where
 * the console asks for it and copyable in one click, so nothing is retyped.
 * The steps are collapsible because a returning admin only needs the verify
 * box; a failed check opens the step that fixes it.
 *
 * `previous` is the account last checked and not yet connected, if any: its
 * ARN and stored checks are shown so a reload does not lose where the admin
 * got to.
 */
export function AwsConnectWizard({ setup, previous, onVerified, onCancel }) {
  const [openStep, setOpenStep] = useState(previous ? null : 1);
  const [progress, setProgress] = useState(previous ? 3 : 1);
  const [roleArn, setRoleArn] = useState(previous?.roleArn ?? '');
  const [touched, setTouched] = useState(false);
  const [serverProblem, setServerProblem] = useState('');
  const [requestError, setRequestError] = useState(null);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(
    previous ? { status: previous.status, checks: previous.checks, verifiedAt: previous.lastVerifiedAt, stored: true } : null,
  );
  const sectionRefs = useRef({});
  const inputRef = useRef(null);

  /* A step opened from a button below it (a failed check, "Next") is brought
     into view. Its header is always mounted, so it can be scrolled to now. */
  const scrollToStep = (number) =>
    sectionRefs.current[number]?.scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' });

  const showStep = (number) => {
    setOpenStep(number);
    setProgress((value) => Math.max(value, number));
    scrollToStep(number);
  };

  const goToVerify = () => {
    setOpenStep(null);
    setProgress(3);
    scrollToStep(3);
    inputRef.current?.focus({ preventScroll: true });
  };

  const localProblem = roleArnProblem(roleArn, setup.accountId);
  const fieldError = serverProblem || (touched ? localProblem : '');

  const verify = async (event) => {
    event.preventDefault();
    setTouched(true);
    setProgress(3);
    if (localProblem) {
      inputRef.current?.focus();
      return;
    }
    setRunning(true);
    setServerProblem('');
    setRequestError(null);
    try {
      const outcome = await verifyAwsConnection({ roleArn: roleArn.trim() });
      setResult(outcome);
      onVerified?.(outcome);
    } catch (error) {
      /* 400 is about the ARN itself, so it belongs under the field. */
      if (error?.status === 400) setServerProblem(error.message);
      else setRequestError(error);
    } finally {
      setRunning(false);
    }
  };

  const connected = result?.status === 'connected';

  return (
    <Panel prominence="lead" aria-labelledby="aws-connect-title">
      <PanelHeader
        prominence="lead"
        id="aws-connect-title"
        title="Connect an AWS account"
        subtitle="Read-only access through a role you create. No access keys are shared."
        actions={
          <span className="text-[12px] font-medium text-ink-3" data-numeric="">
            {connected ? 'Done' : `Step ${progress} of 3`}
          </span>
        }
      />

      <ol className="mt-4 grid grid-cols-3 gap-2" aria-label="Progress">
        {STEPS.map((step) => {
          const done = connected || progress > step.number;
          const current = !connected && progress === step.number;
          return (
            <li key={step.number} aria-current={current ? 'step' : undefined} className="min-w-0">
              <span className={cn('block h-1 rounded-full', done ? 'bg-low' : current ? 'bg-brand' : 'bg-surface-3')} />
              <span
                className={cn(
                  'mt-1.5 block truncate text-[11.5px]',
                  current ? 'font-semibold text-ink' : done ? 'text-ink-2' : 'text-ink-3',
                )}
              >
                {step.number}. {step.title}
              </span>
            </li>
          );
        })}
      </ol>

      <div className="mt-5">
        <SectionLabel>Copy these values</SectionLabel>
        <div className="mt-2 grid gap-2.5 @min-[44rem]:grid-cols-2 @min-[64rem]:grid-cols-3">
          <CopyField label="Our account ID" value={setup.accountId} hint="The account you will trust." />
          <CopyField label="External ID" value={setup.externalId} hint="Unique to your workspace. Do not share it." />
          <CopyField label="Region" value={setup.region} hint="Where our event bus lives." className="@min-[44rem]:col-span-2 @min-[64rem]:col-span-1" />
          <CopyField label="Event bus ARN" value={setup.eventBusArn} className="@min-[44rem]:col-span-2 @min-[64rem]:col-span-3" />
        </div>
      </div>

      <div className="mt-5 flex flex-col gap-2.5">
        <StepSection
          number={1}
          title="Create the read-only IAM role"
          summary={`${setup.roleName} with ${setup.managedPolicies.join(' + ')}`}
          open={openStep === 1}
          onToggle={() => (openStep === 1 ? setOpenStep(null) : showStep(1))}
          sectionRef={(node) => {
            sectionRefs.current[1] = node;
          }}
          consoleLink={{ href: AWS_CONSOLE.iamRoles, label: 'Open IAM' }}
          next={{ label: 'Next: forward events', onClick: () => showStep(2) }}
        >
          <Instructions>
            <li>
              In <b>IAM → Roles</b>, choose <b>Create role</b>.
            </li>
            <li>
              Trusted entity: <b>AWS account</b> → <b>Another AWS account</b>.
            </li>
            <li>
              Account ID: <CopyChip value={setup.accountId} label="our account ID" />
            </li>
            <li>
              Tick <b>Require external ID</b> and paste: <CopyChip value={setup.externalId} label="External ID" />
            </li>
            <li>
              Search for and tick these policies:{' '}
              <span className="inline-flex flex-wrap gap-1.5 align-middle">
                {setup.managedPolicies.map((policy) => (
                  <CopyChip key={policy} value={policy} />
                ))}
              </span>
            </li>
            <li>
              Role name: <CopyChip value={setup.roleName} label="role name" /> then <b>Create role</b>.
            </li>
            <li>
              Open the role and copy its <b>ARN</b>. You will paste it in step 3.
            </li>
          </Instructions>
          <JsonDisclosure
            label="Prefer JSON? Trust policy for “Edit trust relationship”"
            json={trustPolicyJson(setup)}
            copyLabel="Copy trust policy"
          />
        </StepSection>

        <StepSection
          number={2}
          title="Forward CloudTrail events"
          summary={`EventBridge rule ${setup.ruleName} to our event bus`}
          open={openStep === 2}
          onToggle={() => (openStep === 2 ? setOpenStep(null) : showStep(2))}
          sectionRef={(node) => {
            sectionRefs.current[2] = node;
          }}
          consoleLink={{ href: AWS_CONSOLE.eventBridgeRules, label: 'Open EventBridge' }}
          next={{ label: 'Next: verify', onClick: goToVerify }}
        >
          <Instructions>
            <li>
              In <b>EventBridge → Rules</b>, choose <b>Create rule</b>.
            </li>
            <li>
              Name: <CopyChip value={setup.ruleName} label="rule name" />. Event bus: <b>default</b>. Rule type:{' '}
              <b>Rule with an event pattern</b>.
            </li>
            <li>
              Event pattern → <b>Custom pattern (JSON)</b>, and paste:
              <CodeBlock json={eventPatternJson(setup)} copyLabel="Copy event pattern" />
            </li>
            <li>
              Target: <b>EventBridge event bus in a different account or Region</b>.
            </li>
            <li>
              Event bus ARN: <CopyChip value={setup.eventBusArn} label="event bus ARN" />
            </li>
            <li>
              Keep <b>Create a new role for this specific resource</b>, then <b>Create rule</b>.
            </li>
          </Instructions>
          <p className="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-ink-3">
            <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
            Create this rule in every region you use, and in us-east-1 for IAM events.
          </p>
        </StepSection>

        <section
          ref={(node) => {
            sectionRefs.current[3] = node;
          }}
          aria-labelledby="aws-verify-title"
          className="scroll-mt-24 rounded-[var(--radius-control)] border border-line bg-surface p-3.5 sm:p-4"
        >
          <div className="flex items-center gap-3">
            <StepNumber number={3} done={connected} />
            <h3 id="aws-verify-title" className="text-[13.5px] font-semibold text-ink">
              Verify the connection
            </h3>
          </div>

          <form onSubmit={verify} noValidate className="mt-3 flex flex-col gap-3">
            <Field
              label="Role ARN"
              htmlFor="aws-role-arn"
              error={fieldError || undefined}
              hint="The ARN of the role from step 1."
            >
              <Input
                ref={inputRef}
                id="aws-role-arn"
                name="role_arn"
                autoComplete="off"
                spellCheck={false}
                value={roleArn}
                placeholder={exampleRoleArn(setup)}
                onFocus={() => setProgress(3)}
                onChange={(event) => {
                  setRoleArn(event.target.value);
                  setServerProblem('');
                }}
                onBlur={() => roleArn.trim() && setTouched(true)}
                invalid={Boolean(fieldError)}
                className="font-mono text-[12.5px]"
              />
            </Field>
            <div className="flex flex-wrap items-center gap-2">
              <Button type="submit" variant="primary" icon={ShieldCheck} loading={running}>
                {running ? 'Checking…' : 'Verify connection'}
              </Button>
              {onCancel && (
                <Button variant="ghost" onClick={onCancel} disabled={running}>
                  Cancel
                </Button>
              )}
              {running && <span className="text-[12px] text-ink-3">This takes up to 15 seconds.</span>}
            </div>
          </form>

          {requestError && (
            <div className="mt-3">
              <InlineError error={requestError} label="Could not verify" />
            </div>
          )}

          {(running || result) && (
            <div className="mt-4 border-t border-line pt-3">
              {!running && result?.stored && result.verifiedAt && (
                <p className="mb-1 text-[12px] text-ink-3">Last checked {formatRelative(result.verifiedAt)}</p>
              )}
              <CheckList checks={running ? null : result?.checks} onShowStep={showStep} />
            </div>
          )}
        </section>
      </div>
    </Panel>
  );
}

function StepNumber({ number, done }) {
  return (
    <span
      aria-hidden="true"
      data-numeric=""
      className={cn(
        'grid size-6 shrink-0 place-items-center rounded-full text-[12px] font-semibold',
        done ? 'bg-low text-white' : 'bg-surface-3 text-ink-2',
      )}
    >
      {number}
    </span>
  );
}

/** One collapsible setup step. The header says what it creates even when closed. */
function StepSection({ number, title, summary, open, onToggle, sectionRef, consoleLink, next, children }) {
  const panelId = useId();
  return (
    <section ref={sectionRef} className="scroll-mt-24 rounded-[var(--radius-control)] border border-line bg-surface">
      <h3>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          aria-controls={panelId}
          className="flex w-full items-center gap-3 rounded-[var(--radius-control)] px-3.5 py-3 text-left transition-colors hover:bg-surface-2 sm:px-4"
        >
          <StepNumber number={number} />
          <span className="min-w-0 flex-1">
            <span className="block text-[13.5px] font-semibold text-ink">
              Step {number}: {title}
            </span>
            <span className="block truncate text-[12px] text-ink-3">{summary}</span>
          </span>
          <span className="hidden text-[12px] font-medium text-brand sm:inline">{open ? 'Hide' : 'Show instructions'}</span>
          <ChevronDown
            aria-hidden="true"
            className={cn('size-4 shrink-0 text-ink-3 transition-transform duration-200', open ? 'rotate-180' : 'rotate-0')}
          />
        </button>
      </h3>
      {open && (
        <div id={panelId} className="border-t border-line px-3.5 pt-3 pb-3.5 sm:px-4">
          {consoleLink && (
            <a
              href={consoleLink.href}
              target="_blank"
              rel="noopener noreferrer"
              className="mb-3 inline-flex items-center gap-1.5 text-[12.5px] font-medium text-brand hover:underline"
            >
              {consoleLink.label}
              <ExternalLink aria-hidden="true" className="size-3.5" />
              <span className="sr-only">(opens the AWS console in a new tab)</span>
            </a>
          )}
          {children}
          {next && (
            <div className="mt-4 flex justify-end">
              <Button variant="secondary" size="sm" iconRight={ArrowRight} onClick={next.onClick}>
                {next.label}
              </Button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}

function Instructions({ children }) {
  return (
    <ol className="flex list-decimal flex-col gap-2 pl-5 text-[13px] leading-relaxed text-ink-2 marker:text-ink-3 [&_b]:font-semibold [&_b]:text-ink">
      {children}
    </ol>
  );
}

function CodeBlock({ json, copyLabel }) {
  return (
    <div className="relative mt-2">
      <pre className="overflow-x-auto rounded-[var(--radius-control)] border border-line bg-inset p-3 pr-10 font-mono text-[11.5px] leading-relaxed text-ink-2">
        {json}
      </pre>
      <CopyButton value={json} label={copyLabel} className="absolute top-2 right-2 bg-surface" />
    </div>
  );
}

function JsonDisclosure({ label, json, copyLabel }) {
  const [open, setOpen] = useState(false);
  const id = useId();
  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-controls={id}
        className="inline-flex items-center gap-1 text-[12.5px] font-medium text-brand hover:underline"
      >
        <ChevronDown aria-hidden="true" className={cn('size-3.5 transition-transform', open ? 'rotate-180' : '-rotate-90')} />
        {label}
      </button>
      {open && (
        <div id={id}>
          <CodeBlock json={json} copyLabel={copyLabel} />
        </div>
      )}
    </div>
  );
}
