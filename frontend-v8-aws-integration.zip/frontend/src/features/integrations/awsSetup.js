/**
 * The AWS connection, as data: the documents the client pastes and the
 * checks the API runs. Every value comes from `GET /api/v1/integrations/aws`,
 * so what the page tells the client to type is exactly what the API verifies.
 */

export const AWS_CONSOLE = {
  iamRoles: 'https://console.aws.amazon.com/iam/home#/roles',
  eventBridgeRules: 'https://console.aws.amazon.com/events/home#/rules',
};

/** The trust policy for "Edit trust relationship", as an alternative to the clicks. */
export function trustPolicyJson(setup) {
  return JSON.stringify(
    {
      Version: '2012-10-17',
      Statement: [
        {
          Effect: 'Allow',
          Principal: { AWS: setup.assumerRoleArn },
          Action: 'sts:AssumeRole',
          Condition: { StringEquals: { 'sts:ExternalId': setup.externalId } },
        },
      ],
    },
    null,
    2,
  );
}

/** The EventBridge rule's custom event pattern. */
export function eventPatternJson(setup) {
  /* Four sources to a line: the same JSON as JSON.stringify, laid out to be
     read at a glance rather than one value per line. */
  const quoted = setup.eventSources.map((source) => JSON.stringify(source));
  const lines = [];
  for (let i = 0; i < quoted.length; i += 4) lines.push(quoted.slice(i, i + 4).join(', '));
  return `{\n  "source": [\n    ${lines.join(',\n    ')}\n  ]\n}`;
}

/** What a pasted role ARN should look like, with the client's account left open. */
export function exampleRoleArn(setup) {
  return `arn:aws:iam::<your-account-id>:role/${setup?.roleName || 'NHIPlatformCollector'}`;
}

const ROLE_ARN = /^arn:aws:iam::(\d{12}):role\/(?:[\x21-\x7E]+\/)?[\w+=,.@-]{1,64}$/;
const OTHER_IAM = /^arn:aws[\w-]*:iam::\d{12}:(user|group|policy|instance-profile|oidc-provider|saml-provider)\//;

/**
 * Checks a pasted role ARN before it is sent, with the same rules as the API
 * (`internal/awsconnect/arn.go`), so the common slips are caught as they are
 * typed. Returns '' when it looks right. The API checks again.
 */
export function roleArnProblem(value, platformAccountId) {
  const arn = String(value ?? '').trim();
  if (!arn) return 'Paste the ARN of the role you created.';
  const other = OTHER_IAM.exec(arn);
  if (other) return `That is an IAM ${other[1].replace('-', ' ')} ARN. Paste the role's ARN - it contains ":role/".`;
  const match = ROLE_ARN.exec(arn);
  if (!match) {
    if (arn.startsWith('arn:aws-')) return 'Only accounts in the standard AWS partition can be connected.';
    return 'That is not a role ARN. It looks like arn:aws:iam::123456789012:role/RoleName.';
  }
  if (platformAccountId && match[1] === platformAccountId) {
    return `That ARN is in our account (${platformAccountId}). Paste the ARN of the role you created in your own AWS account.`;
  }
  return '';
}

/** The account id inside a role ARN, or ''. */
export function accountOfRoleArn(value) {
  return ROLE_ARN.exec(String(value ?? '').trim())?.[1] ?? '';
}

/**
 * The three checks, in the order the API runs them, and the setup step that
 * fixes each one - so a failed check can open the step it points at.
 */
export const AWS_CHECKS = [
  { key: 'assume_role', label: 'Assume your role', step: 1 },
  { key: 'read_access', label: 'Read your account', step: 1 },
  { key: 'events', label: 'Receive your events', step: 2 },
];

export const AWS_STATUS = {
  not_connected: { label: 'Not connected', tone: 'neutral' },
  action_needed: { label: 'Needs attention', tone: 'medium' },
  connected: { label: 'Connected', tone: 'low' },
};
