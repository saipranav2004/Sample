import { useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, useReducedMotion } from 'motion/react';
import {
  CheckCircle2,
  ChevronDown,
  Clock3,
  KeyRound,
  LayoutDashboard,
  Plus,
  RotateCw,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useAuth } from '../../app/AuthContext';
import { hasConnectedAccount, useConnectionGate } from '../../app/ConnectionGate';
import { fetchAwsIntegration, verifyAwsConnection } from '../../lib/api/endpoints';
import { formatDateTime, formatRelative } from '../../lib/format';
import { useQuery } from '../../lib/hooks';
import { EASE_OUT, SPRING } from '../../lib/motion';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { CopyButton } from '../../ui/Copyable';
import { Panel } from '../../ui/Panel';
import { Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { useToast } from '../../ui/Toast';
import { cn } from '../../ui/cn';
import { AWS_STATUS } from './awsSetup';
import { AwsConnectWizard } from './AwsConnectWizard';
import { AwsMark } from './AwsMark';
import { CheckDots, CheckList } from './CheckList';

const reducedMotion = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/**
 * Integrations: where a workspace connects the AWS accounts its data comes
 * from. Three situations, one screen:
 *
 *   Onboarding  No account has ever connected. `ConnectionGate` reduces the
 *               console to this page; a successful check opens the dashboard.
 *   Setup       Same, inside the full console (only if the gate could not
 *               check, e.g. the API was briefly down).
 *   Manage      At least one account connected: account health, re-checks,
 *               and "Connect another account" (?add=1 opens it directly).
 */
export default function IntegrationsPage() {
  const { user } = useAuth();
  const gate = useConnectionGate();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const query = useQuery((signal) => fetchAwsIntegration(signal), []);
  const data = query.data;

  const adding = searchParams.get('add') === '1';
  const setAdding = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set('add', '1');
    else next.delete('add');
    setSearchParams(next, { replace: true });
  };
  /* A new key per opening: every account needs its own role and rule, so the
     setup for the next account starts from step 1. */
  const [wizardKey, setWizardKey] = useState(0);
  const [justAdded, setJustAdded] = useState('');
  const [onboardingDone, setOnboardingDone] = useState('');
  const storageKey = `nhi.awsSetup.${user?.tenant_id ?? 'workspace'}`;
  const anotherKey = `${storageKey}.another`;

  const addSectionRef = useRef(null);
  useEffect(() => {
    if (adding && data) addSectionRef.current?.scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' });
  }, [adding, data]);

  const manage = data ? hasConnectedAccount(data) : false;

  const onVerified = (outcome) => {
    if (outcome.status === 'connected') {
      if (gate.gated) {
        setOnboardingDone(outcome.accountId);
      } else {
        setJustAdded(outcome.accountId);
        setAdding(false);
        setWizardKey((value) => value + 1);
        try {
          localStorage.removeItem(anotherKey);
        } catch {
          /* progress is a convenience */
        }
      }
    }
    if (outcome.saved) query.refetch();
  };

  const openDashboard = () => {
    gate.markConnected();
    navigate('/overview', { replace: true });
  };
  const connectAnother = () => {
    gate.markConnected();
    navigate('/integrations?add=1', { replace: true });
  };

  /* Previous unconnected attempt, so the setup reopens where it was left. */
  const previous = !manage ? ((data?.accounts ?? []).find((account) => account.status !== 'connected') ?? null) : null;

  if (gate.gated && onboardingDone) {
    return <OnboardingSuccess accountId={onboardingDone} onOpen={openDashboard} onAnother={connectAnother} />;
  }

  return (
    <div className="flex flex-col gap-6">
      {gate.gated ? (
        <OnboardingIntro name={user?.full_name} canManage={data?.canManage ?? true} />
      ) : (
        <PageHeader
          title="Integrations"
          lede="Connect the cloud accounts this console discovers non-human identities in."
          actions={
            manage ? (
              <Button variant="secondary" icon={RotateCw} onClick={query.refetch} loading={query.isLoading && Boolean(data)}>
                Refresh
              </Button>
            ) : null
          }
        />
      )}

      {!data && query.isLoading && <PageSkeleton />}

      {!data && query.isError && (
        <Panel>
          <ErrorState
            error={query.error}
            onRetry={query.refetch}
            title={query.error?.code === 'AWS_PLATFORM_NOT_CONFIGURED' ? 'AWS connections are not available yet' : undefined}
          />
        </Panel>
      )}

      {data && (
        <>
          <ProviderHero data={data} manage={manage} />

          {manage && justAdded && <AddedBanner accountId={justAdded} onDismiss={() => setJustAdded('')} />}

          {manage && (
            <AccountsPanel
              accounts={data.accounts}
              canManage={data.canManage}
              onChanged={query.refetch}
              onAdd={data.canManage && data.setup && !adding ? () => setAdding(true) : null}
            />
          )}

          {manage && adding && data.setup && (
            <section ref={addSectionRef} className="scroll-mt-24" aria-label="Connect another AWS account">
              <AwsConnectWizard
                key={wizardKey}
                setup={data.setup}
                storageKey={anotherKey}
                title="Connect another AWS account"
                onVerified={onVerified}
                onCancel={() => setAdding(false)}
              />
            </section>
          )}

          {!manage &&
            (data.canManage && data.setup ? (
              <AwsConnectWizard setup={data.setup} previous={previous} storageKey={storageKey} onVerified={onVerified} />
            ) : (
              <Panel>
                <EmptyState
                  icon={Clock3}
                  title="Waiting for an admin to connect AWS"
                  description="Connecting an account needs the admin role. Once an admin has connected one, your dashboard opens."
                  action={
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={RotateCw}
                      loading={query.isLoading}
                      onClick={() => {
                        query.refetch();
                        gate.recheck();
                      }}
                    >
                      Check again
                    </Button>
                  }
                />
              </Panel>
            ))}
        </>
      )}
    </div>
  );
}

/* ── Onboarding ──────────────────────────────────────────────────────────── */

function OnboardingIntro({ name, canManage }) {
  const first = String(name ?? '').trim().split(/\s+/)[0];
  return (
    <header className="pt-2">
      <p className="text-[12.5px] font-medium text-brand">{first ? `Welcome, ${first}` : 'Welcome'}</p>
      <h1 className="mt-1 text-[26px] leading-tight font-extrabold tracking-[-0.026em] text-ink sm:text-[28px]">
        {canManage ? 'Connect your first AWS account' : 'Your workspace is almost ready'}
      </h1>
      <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-ink-2">
        {canManage
          ? 'We discover the non-human identities and credentials in your AWS accounts. Connect one to begin - your dashboard opens as soon as the connection is verified.'
          : 'Your dashboard opens once an AWS account is connected to this workspace.'}
      </p>
    </header>
  );
}

/**
 * The moment the first account connects. Opens the dashboard on its own after
 * a short, visible countdown that can be stopped; "Connect another account"
 * is offered here because teams with several accounts usually do them in one
 * sitting.
 */
function OnboardingSuccess({ accountId, onOpen, onAnother }) {
  const reduce = useReducedMotion();
  const [remaining, setRemaining] = useState(6);
  const [paused, setPaused] = useState(false);
  const openRef = useRef(onOpen);
  useEffect(() => {
    openRef.current = onOpen;
  });

  useEffect(() => {
    if (paused) return undefined;
    const id = setInterval(() => setRemaining((value) => Math.max(0, value - 1)), 1000);
    return () => clearInterval(id);
  }, [paused]);

  useEffect(() => {
    if (!paused && remaining === 0) openRef.current();
  }, [remaining, paused]);

  return (
    <div className="grid min-h-[calc(100dvh-10rem)] place-items-center">
      <motion.section
        role="status"
        initial={reduce ? false : { opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: EASE_OUT }}
        className="w-full max-w-xl rounded-[var(--radius-panel)] border border-line-strong bg-surface p-6 text-center shadow-[var(--t-shadow-lg)] sm:p-8"
      >
        <motion.span
          initial={reduce ? false : { scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ ...SPRING, delay: 0.15 }}
          className="mx-auto grid size-16 place-items-center rounded-full bg-low-soft shadow-[0_0_0_8px_color-mix(in_srgb,var(--t-low)_10%,transparent)]"
        >
          <CheckCircle2 aria-hidden="true" className="size-8 text-low" />
        </motion.span>
        <h1 className="mt-5 text-[22px] font-extrabold tracking-[-0.02em] text-ink">AWS is connected</h1>
        <p className="mt-1.5 text-[13.5px] text-ink-2">
          Account <span className="font-mono font-semibold text-ink">{accountId}</span> passed all three checks. We will now discover
          its identities and credentials; your dashboard fills in after the first scan.
        </p>
        <div className="mt-6 flex flex-col items-stretch justify-center gap-2 sm:flex-row sm:items-center">
          <Button variant="primary" size="lg" icon={LayoutDashboard} onClick={onOpen}>
            Open the dashboard
          </Button>
          <Button variant="secondary" size="lg" icon={Plus} onClick={onAnother}>
            Connect another account
          </Button>
        </div>
        <p className="mt-4 text-[12px] text-ink-3" aria-live="off">
          {paused ? (
            'Staying on this page.'
          ) : (
            <>
              Opening the dashboard in <span data-numeric="">{remaining}</span>s ·{' '}
              <button type="button" onClick={() => setPaused(true)} className="font-medium text-brand hover:underline">
                Stay here
              </button>
            </>
          )}
        </p>
      </motion.section>
    </div>
  );
}

/* ── Provider header ─────────────────────────────────────────────────────── */

function StatusPill({ status }) {
  const meta = AWS_STATUS[status] ?? AWS_STATUS.not_connected;
  const live = status === 'connected';
  const dot = { low: 'bg-low', medium: 'bg-medium', neutral: 'bg-ink-3' }[meta.tone] ?? 'bg-ink-3';
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[12px] font-medium',
        meta.tone === 'low'
          ? 'border-low/30 bg-low-soft text-low'
          : meta.tone === 'medium'
            ? 'border-medium/30 bg-medium-soft text-medium'
            : 'border-line-strong bg-surface-2 text-ink-2',
      )}
    >
      <span className="relative flex size-2">
        {live && <span className={cn('absolute inline-flex size-full rounded-full opacity-60 motion-safe:animate-ping', dot)} />}
        <span className={cn('relative inline-flex size-2 rounded-full', dot)} />
      </span>
      {meta.label}
    </span>
  );
}

/**
 * Which provider, its state, and the three facts a reviewer asks about first.
 * Once connected, the right side carries the account health at a glance.
 */
function ProviderHero({ data, manage }) {
  const total = data.accounts.length;
  const healthy = data.accounts.filter((account) => account.status === 'connected').length;
  const lastChecked = data.accounts
    .map((account) => account.lastVerifiedAt)
    .filter(Boolean)
    .sort()
    .at(-1);

  return (
    <section
      aria-label="Amazon Web Services"
      className="relative overflow-hidden rounded-[var(--radius-panel)] border border-line-strong bg-surface shadow-[var(--t-shadow-md)]"
    >
      {/* Ambient light from the top right and a dot grid fading in from the
          right edge: depth without a second accent colour. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(90%_140%_at_100%_0%,color-mix(in_srgb,var(--t-brand)_11%,transparent)_0%,transparent_60%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 right-0 w-1/2 bg-[radial-gradient(var(--t-line-strong)_1px,transparent_1px)] [mask-image:linear-gradient(to_left,black,transparent)] bg-[size:14px_14px] opacity-50"
      />
      <div className="relative flex flex-wrap items-center gap-x-6 gap-y-5 p-5 sm:p-6">
        <AwsMark size="lg" />
        <div className="min-w-0 flex-1 basis-[22rem]">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <h2 className="text-[19px] font-bold tracking-[-0.015em] text-ink">Amazon Web Services</h2>
            <StatusPill status={data.status} />
          </div>
          <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-ink-2">
            Discovers the non-human identities and credentials in your accounts.
          </p>
          <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 text-[12px] text-ink-2">
            <li className="inline-flex items-center gap-1.5">
              <ShieldCheck aria-hidden="true" className="size-3.5 text-low" />
              Read-only access
            </li>
            <li className="inline-flex items-center gap-1.5">
              <KeyRound aria-hidden="true" className="size-3.5 text-low" />
              No access keys shared
            </li>
            <li className="inline-flex items-center gap-1.5">
              <Clock3 aria-hidden="true" className="size-3.5 text-ink-3" />
              About 10 minutes per account
            </li>
          </ul>
        </div>

        {manage && total > 0 && (
          <dl className="flex shrink-0 divide-x divide-line rounded-[var(--radius-control)] border border-line bg-surface/80 backdrop-blur-sm">
            <HeroStat label="Accounts" value={total} />
            <HeroStat label="Healthy" value={`${healthy}/${total}`} tone={healthy === total ? 'text-low' : 'text-medium'} />
            <HeroStat label="Last checked" value={lastChecked ? formatRelative(lastChecked) : '-'} small title={formatDateTime(lastChecked)} />
          </dl>
        )}
      </div>
    </section>
  );
}

function HeroStat({ label, value, tone, small, title }) {
  return (
    <div className="flex min-w-[92px] flex-col gap-1 px-4 py-2.5" title={title}>
      <dt className="text-[11px] text-ink-3">{label}</dt>
      <dd
        data-numeric=""
        className={cn('leading-none font-bold tracking-[-0.02em] text-ink', small ? 'text-[14px]' : 'text-[22px]', tone)}
      >
        {value}
      </dd>
    </div>
  );
}

/* ── Connected ───────────────────────────────────────────────────────────── */

/** Shown after an additional account connects; the first one gets the onboarding success screen. */
function AddedBanner({ accountId, onDismiss }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      role="status"
      initial={reduce ? false : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: EASE_OUT }}
      className="flex items-center gap-3 rounded-[var(--radius-panel)] border border-low/35 bg-low-soft px-4 py-3"
    >
      <CheckCircle2 aria-hidden="true" className="size-5 shrink-0 text-low" />
      <p className="min-w-0 flex-1 text-[13px] text-ink-2">
        <span className="font-semibold text-ink">
          Account <span className="font-mono">{accountId}</span> connected.
        </span>{' '}
        It is included from the next scan.
      </p>
      <IconButton icon={X} label="Dismiss" size="sm" onClick={onDismiss} />
    </motion.div>
  );
}

/** Every checked account, healthy first. Admins can re-run the checks. */
function AccountsPanel({ accounts, canManage, onChanged, onAdd }) {
  return (
    <Panel flush className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3.5 sm:px-5">
        <div>
          <h2 className="text-[14.5px] font-semibold text-ink">Connected accounts</h2>
          <p className="mt-0.5 text-[12px] text-ink-3">Read-only access through the role you created in each account.</p>
        </div>
        {onAdd && (
          <Button variant="primary" size="sm" icon={Plus} onClick={onAdd}>
            Connect another account
          </Button>
        )}
      </div>
      <div
        aria-hidden="true"
        className="hidden grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_minmax(0,0.9fr)_auto] gap-4 border-b border-line bg-surface-2 px-5 py-2 text-[11px] font-medium text-ink-3 @min-[52rem]:grid"
      >
        <span>Account</span>
        <span>Checks</span>
        <span>Last checked</span>
        <span className="w-[104px]" />
      </div>
      <ul className="divide-y divide-line">
        {accounts.map((account) => (
          <AccountRow key={account.accountId} account={account} canManage={canManage} onChanged={onChanged} />
        ))}
      </ul>
    </Panel>
  );
}

function AccountRow({ account, canManage, onChanged }) {
  const { notify } = useToast();
  const [running, setRunning] = useState(false);
  const attention = account.status !== 'connected';
  const [open, setOpen] = useState(attention);
  const meta = AWS_STATUS[account.status] ?? AWS_STATUS.action_needed;

  const recheck = async () => {
    setRunning(true);
    try {
      const outcome = await verifyAwsConnection({ roleArn: account.roleArn });
      const failing = outcome.checks.find((check) => check.state !== 'pass');
      notify(
        outcome.status === 'connected'
          ? { variant: 'success', title: `${account.accountId} is healthy`, description: 'All three checks passed.' }
          : {
              variant: 'error',
              title: `${account.accountId}: ${failing?.label ?? 'a check'} did not pass`,
              description: failing?.fix || failing?.message,
            },
      );
      if (outcome.saved) onChanged?.();
    } catch (error) {
      notify({ variant: 'error', title: 'Could not run the checks', description: error?.message });
    } finally {
      setRunning(false);
    }
  };

  return (
    <li className="px-4 py-3.5 transition-colors hover:bg-surface-2/60 sm:px-5">
      <div className="grid items-center gap-x-4 gap-y-2.5 @min-[52rem]:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_minmax(0,0.9fr)_auto]">
        <div className="flex min-w-0 items-center gap-3">
          <AwsMark size="sm" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[13.5px] font-semibold text-ink">{account.accountId}</span>
              <span className={cn('text-[11.5px] font-medium', meta.tone === 'low' ? 'text-low' : 'text-medium')}>{meta.label}</span>
            </div>
            <div className="mt-0.5 flex min-w-0 items-center gap-1">
              <span className="truncate font-mono text-[11.5px] text-ink-3" title={account.roleArn}>
                {account.roleArn}
              </span>
              <CopyButton value={account.roleArn} label="Copy role ARN" size="sm" />
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          className="inline-flex w-fit items-center gap-2 rounded-md px-1.5 py-1 text-[12px] text-ink-2 transition-colors hover:bg-surface-3"
        >
          <CheckDots checks={account.checks} />
          {account.checks.length
            ? `${account.checks.filter((check) => check.state === 'pass').length}/3 passed`
            : 'No results yet'}
          <ChevronDown aria-hidden="true" className={cn('size-3.5 text-ink-3 transition-transform', open && 'rotate-180')} />
        </button>

        <span className="text-[12px] text-ink-3" title={formatDateTime(account.lastVerifiedAt)}>
          {account.lastVerifiedAt ? formatRelative(account.lastVerifiedAt) : '-'}
          {account.lastVerifiedBy && <span className="block truncate text-[11px]">by {account.lastVerifiedBy}</span>}
        </span>

        <div className="@min-[52rem]:w-[104px] @min-[52rem]:text-right">
          {canManage && (
            <Button variant="secondary" size="sm" icon={ShieldCheck} loading={running} onClick={recheck}>
              {running ? 'Checking' : 'Re-check'}
            </Button>
          )}
        </div>
      </div>
      {open && (
        <div className="mt-3 rounded-[var(--radius-control)] border border-line bg-surface-2 px-3 py-1 @min-[52rem]:ml-11">
          <CheckList checks={account.checks} />
        </div>
      )}
    </li>
  );
}

function PageSkeleton() {
  return (
    <div className="flex flex-col gap-5" aria-busy="true">
      <div className="flex items-center gap-5 rounded-[var(--radius-panel)] border border-line bg-surface p-6">
        <Skeleton className="size-14 rounded-[14px]" />
        <div className="flex-1">
          <Skeleton className="h-5 w-56 rounded" />
          <Skeleton className="mt-2.5 h-3 w-96 max-w-full rounded" />
          <Skeleton className="mt-3 h-3 w-72 max-w-full rounded" />
        </div>
      </div>
      <div className="grid gap-5 @min-[56rem]:grid-cols-[minmax(0,1fr)_288px] @min-[80rem]:grid-cols-[minmax(0,1fr)_336px]">
        <div className="flex flex-col gap-4">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="flex gap-3">
              <Skeleton className="size-8 shrink-0 rounded-full" />
              <Skeleton className="h-16 flex-1 rounded-[var(--radius-panel)]" />
            </div>
          ))}
        </div>
        <Skeleton className="h-72 rounded-[var(--radius-panel)]" />
      </div>
      <span role="status" className="sr-only">
        Loading your AWS connection
      </span>
    </div>
  );
}

export { IntegrationsPage };
