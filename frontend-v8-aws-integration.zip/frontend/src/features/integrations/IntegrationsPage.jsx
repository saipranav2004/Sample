import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Cloud, EyeOff, KeyRound, Plus, RotateCw, ShieldCheck, Unplug } from 'lucide-react';
import { fetchAwsIntegration, verifyAwsConnection } from '../../lib/api/endpoints';
import { formatDateTime, formatRelative } from '../../lib/format';
import { useQuery } from '../../lib/hooks';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Panel, PanelHeader } from '../../ui/Panel';
import { Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import { useToast } from '../../ui/Toast';
import { AWS_STATUS } from './awsSetup';
import { AwsConnectWizard } from './AwsConnectWizard';
import { CheckList } from './CheckList';

/**
 * Integrations: where a workspace connects the AWS account its data comes
 * from. A tenant that has not connected one lands here after signing in (see
 * `HomeRedirect`), because until then every other screen is empty.
 *
 *   Not connected   admins get the setup; everyone else is told who can do it
 *   Connected       the accounts, each re-checkable, and "Connect another"
 */
export default function IntegrationsPage() {
  const query = useQuery((signal) => fetchAwsIntegration(signal), []);
  const data = query.data;
  const [adding, setAdding] = useState(false);
  const [justConnected, setJustConnected] = useState('');

  const onVerified = (outcome) => {
    if (outcome.status === 'connected') {
      setJustConnected(outcome.accountId);
      setAdding(false);
    }
    if (outcome.saved) query.refetch();
  };

  const status = AWS_STATUS[data?.status] ?? AWS_STATUS.not_connected;
  const connected = data?.status === 'connected';
  /* The account last checked and not connected, so the setup reopens on it. */
  const previous = !connected ? (data?.accounts ?? []).find((account) => account.status !== 'connected') ?? null : null;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Integrations"
        lede="Connect your AWS account so we can discover the non-human identities and credentials in it."
        meta={
          data ? (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[12px] text-ink-3">Amazon Web Services</span>
              <Tag tone={status.tone} size="sm" dot>
                {status.label}
              </Tag>
            </div>
          ) : null
        }
        actions={
          connected ? (
            <Button variant="secondary" icon={RotateCw} onClick={query.refetch} loading={query.isLoading && Boolean(data)}>
              Refresh
            </Button>
          ) : null
        }
      />

      {!data && query.isLoading && <PageSkeleton />}

      {!data && query.isError && (
        <Panel>
          <ErrorState
            error={query.error}
            onRetry={query.refetch}
            title={query.error?.code === 'AWS_PLATFORM_NOT_CONFIGURED' ? 'AWS connections are not available yet' : undefined}
          />
        </Panel>
      )}

      {justConnected && connected && <ConnectedBanner accountId={justConnected} onDismiss={() => setJustConnected('')} />}

      {data && connected && (
        <>
          <AccountsPanel accounts={data.accounts} canManage={data.canManage} onChanged={query.refetch} />
          {data.canManage &&
            data.setup &&
            (adding ? (
              <AwsConnectWizard setup={data.setup} onVerified={onVerified} onCancel={() => setAdding(false)} />
            ) : (
              <div>
                <Button variant="secondary" icon={Plus} onClick={() => setAdding(true)}>
                  Connect another account
                </Button>
              </div>
            ))}
        </>
      )}

      {data && !connected && (
        data.canManage && data.setup ? (
          <>
            <AwsConnectWizard setup={data.setup} previous={previous} onVerified={onVerified} />
            <AccessSummary setup={data.setup} />
          </>
        ) : (
          <Panel>
            <EmptyState
              icon={Cloud}
              title="AWS is not connected yet"
              description="An admin in your workspace needs to connect your AWS account. Your dashboard fills in once it is connected."
              action={
                <Button as={Link} to="/overview" variant="secondary" size="sm">
                  Go to the dashboard
                </Button>
              }
            />
          </Panel>
        )
      )}
    </div>
  );
}

function ConnectedBanner({ accountId, onDismiss }) {
  return (
    <div
      role="status"
      className="flex flex-wrap items-center gap-x-4 gap-y-3 rounded-[var(--radius-panel)] border border-low/40 bg-low-soft px-4 py-3.5"
    >
      <CheckCircle2 aria-hidden="true" className="size-5 shrink-0 text-low" />
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-semibold text-ink">
          AWS account <span className="font-mono">{accountId}</span> is connected
        </p>
        <p className="mt-0.5 text-[12.5px] text-ink-2">
          We will now discover the identities and credentials in it. Your dashboard fills in after the first scan.
        </p>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" onClick={onDismiss}>
          Dismiss
        </Button>
        <Button as={Link} to="/overview" variant="primary" size="sm" iconRight={ArrowRight}>
          Go to the dashboard
        </Button>
      </div>
    </div>
  );
}

/** Every account that has been checked, connected first. Admins can re-run the checks. */
function AccountsPanel({ accounts, canManage, onChanged }) {
  return (
    <Panel flush className="overflow-hidden">
      <div className="border-b border-line px-4 py-3">
        <h2 className="text-[13.5px] font-semibold text-ink">AWS accounts</h2>
        <p className="mt-0.5 text-[12px] text-ink-3">Read-only access through the role you created in each account.</p>
      </div>
      <ul className="divide-y divide-line">
        {accounts.map((account) => (
          <AccountRow key={account.accountId} account={account} canManage={canManage} onChanged={onChanged} />
        ))}
      </ul>
    </Panel>
  );
}

function AccountRow({ account, canManage, onChanged }) {
  const { notify } = useToast();
  const [running, setRunning] = useState(false);
  const meta = AWS_STATUS[account.status] ?? AWS_STATUS.action_needed;

  const recheck = async () => {
    setRunning(true);
    try {
      const outcome = await verifyAwsConnection({ roleArn: account.roleArn });
      const failing = outcome.checks.find((check) => check.state !== 'pass');
      notify(
        outcome.status === 'connected'
          ? { variant: 'success', title: `${account.accountId}: all checks passed` }
          : { variant: 'error', title: `${account.accountId}: ${failing?.label ?? 'a check'} did not pass`, description: failing?.fix || failing?.message },
      );
      if (outcome.saved) onChanged?.();
    } catch (error) {
      notify({ variant: 'error', title: 'Could not run the checks', description: error?.message });
    } finally {
      setRunning(false);
    }
  };

  return (
    <li className="px-4 py-3.5">
      <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2.5">
        <div className="flex min-w-0 gap-3">
          <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-[var(--radius-control)] border border-line bg-surface-2 text-ink-2">
            <Cloud aria-hidden="true" className="size-4" />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-mono text-[13px] font-semibold text-ink">{account.accountId}</p>
              <Tag tone={meta.tone} size="sm" dot>
                {meta.label}
              </Tag>
            </div>
            <div className="mt-1 text-[12px] text-ink-2">
              <CopyableValue value={account.roleArn} />
            </div>
            {account.lastVerifiedAt && (
              <p className="mt-1 text-[11.5px] text-ink-3" title={formatDateTime(account.lastVerifiedAt)}>
                Last checked {formatRelative(account.lastVerifiedAt)}
                {account.lastVerifiedBy ? ` by ${account.lastVerifiedBy}` : ''}
              </p>
            )}
          </div>
        </div>
        {canManage && (
          <Button variant="secondary" size="sm" icon={ShieldCheck} loading={running} onClick={recheck}>
            {running ? 'Checking…' : 'Re-check'}
          </Button>
        )}
      </div>
      {account.status !== 'connected' && account.checks.length > 0 && (
        <div className="mt-2.5 ml-12 rounded-[var(--radius-control)] border border-line bg-surface-2 px-3 py-1">
          <CheckList checks={running ? null : account.checks} compact />
        </div>
      )}
    </li>
  );
}

/** What the client is granting, in three lines - the questions a security reviewer asks first. */
function AccessSummary({ setup }) {
  const items = [
    { icon: EyeOff, title: 'Read-only', text: `${setup.managedPolicies.join(' and ')} are AWS-managed, read-only policies.` },
    { icon: KeyRound, title: 'No keys shared', text: 'We get short-lived access through your role, and only with your External ID.' },
    { icon: Unplug, title: 'Revoke any time', text: `Delete the ${setup.roleName} role and the ${setup.ruleName} rule.` },
  ];
  return (
    <Panel prominence="quiet">
      <PanelHeader prominence="quiet" title="What you are granting" />
      <ul className="mt-3 grid gap-3 @min-[48rem]:grid-cols-3">
        {items.map(({ icon: Icon, title, text }) => (
          <li key={title} className="flex gap-2.5">
            <Icon aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-brand" />
            <span className="min-w-0">
              <span className="block text-[13px] font-semibold text-ink">{title}</span>
              <span className="block text-[12px] leading-relaxed text-ink-3">{text}</span>
            </span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function PageSkeleton() {
  return (
    <div className="flex flex-col gap-4" aria-busy="true">
      <div className="rounded-[var(--radius-panel)] border border-line bg-surface p-5">
        <Skeleton className="h-5 w-56 rounded" />
        <Skeleton className="mt-3 h-3 w-80 max-w-full rounded" />
        <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <Skeleton key={index} className="h-16 rounded-[var(--radius-control)]" />
          ))}
        </div>
        <Skeleton className="mt-5 h-14 rounded-[var(--radius-control)]" />
        <Skeleton className="mt-2.5 h-14 rounded-[var(--radius-control)]" />
      </div>
      <span role="status" className="sr-only">
        Loading your AWS connection
      </span>
    </div>
  );
}

export { IntegrationsPage };
