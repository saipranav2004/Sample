# NHI Console - Deep Algorithms

Operator console for AWS non-human identity discovery: the identities acting in
your accounts, the credentials they hold, which of those need attention, and
(for admins) secrets committed to source code.

React 19, Vite, Tailwind v4, React Router 7. Motion (motion.dev) for interface
movement, anime.js for the sign-in illustration. Charts are hand-built SVG.

## What it talks to

One backend: the Go NHI API (`nhi-backend-api`, multi-tenant). Every call
carries the signed-in user's bearer token; the tenant comes from that token.
There is no key or secret of any kind in this app.

| Screen | Endpoints |
|---|---|
| Sign-in | `POST /api/auth/login`, `GET /api/auth/me` |
| Dashboard | `GET /api/v1/dashboard/overview`, `GET /api/v1/postures/categories`, `GET`/`PUT /api/v1/settings`, `GET /api/v1/filters`; admins also `GET /api/findings/summary` |
| Identities | `GET /api/v1/identities` (filters, sort, pages) |
| Identity page | `GET /api/v1/identities/{id}?tab=overview \| permissions \| activity \| relationships \| credentials \| raw` |
| Credentials | `GET /api/v1/credentials` (filters, sort, pages) |
| Credential page | `GET /api/v1/credentials/{id}?tab=overview \| trust \| activity \| rotation \| relationships \| raw` |
| Search (Ctrl/Cmd+K) | `GET /api/v1/identities?search=` and `GET /api/v1/credentials?search=` (top five of each) |
| Exposed credentials (admin) | `GET /api/findings`, `GET /api/findings/ml-flagged`, `POST /api/findings/decision`, `POST /api/deep-scan`, `GET /api/deep-scan-status` |
| Accepted (admin) | `GET`/`POST`/`DELETE /api/allowlist` |
| Integrations | `GET /api/v1/integrations/aws`; admins also `POST /api/v1/integrations/aws/verify` |
| Connection gate (every signed-in screen) | `GET /api/v1/integrations/aws` — the console shows only Integrations until an AWS account is connected |

Each tab of a detail page is its own request, made when the tab is opened. The
tab is kept in the URL (`?tab=trust`), so a link lands on the part that matters.

## Running it

```bash
cp .env.example .env     # optional: only if the API is not on localhost:8080
npm install
npm run dev              # http://localhost:3000
```

Start the Go API first. The dev server proxies `/api/*` to `API_UPSTREAM`.

`npm run build` emits `dist/`. `npm run lint` runs oxlint.

| Variable | Side | Meaning |
|---|---|---|
| `VITE_API_URL` | client | Base URL of the API. Leave empty so the browser calls same-origin `/api`. Set it only when the API is on another origin, and allow that origin in the API's CORS settings. |
| `API_UPSTREAM` | dev server | Where `npm run dev` proxies `/api/*`. Default `http://localhost:8080`. |

The credential exposure screens need the API started with
`SECRET_SCANNER_BASE_URL` and `SECRET_SCANNER_DASHBOARD_KEY` for deep scans.
Without them, `POST /api/deep-scan` answers 503 and the console says the
scanner is not connected. The key stays on the server.

## Roles

The roles are the API's own (`nhi_users.role`).

| Role | Can |
|---|---|
| `admin` | everything, including secrets found in code: review findings, record verdicts, accept and restore, start deep scans |
| `team_lead`, `developer`, `auditor` | the dashboard, identities and credentials (read-only) |

The API enforces the admin rule on the exposure routes (403 `FORBIDDEN` for
anyone else). The console hides those screens from other roles and, if one is
opened by address, explains it is admin-only without calling the API. The API
checks no role on the inventory routes, which are all read-only.

## Deploying it

```bash
docker build -t nhi-console:latest .
docker run --rm -p 8080:8080 -e API_UPSTREAM=http://nhi-api:8080 nhi-console:latest
```

The image is nginx serving the built files. nginx proxies `/api/*` to
`API_UPSTREAM` (resolved at container start, so one image serves every
environment), sets security headers including a CSP with `connect-src 'self'`,
and answers `/healthz` itself. See `Dockerfile` and `nginx/`.

## Behaviour worth knowing

- **Connect AWS first.** Until a workspace has connected an AWS account
  (`app/ConnectionGate.jsx`), the console is reduced to one focused screen -
  no navigation, every address redirects to `/integrations`. Admins get the
  setup: values to copy, two steps with every value inline and copyable, then
  the role ARN and Verify; each failed check shows its fix and opens the step
  that fixes it. Other roles see that an admin has to connect it. The first
  successful check opens the dashboard (after a short countdown that can be
  stopped) or goes straight on to connecting another account. "Connected"
  means connected at least once, so a later failing re-check never locks a
  workspace out; if the check itself fails, the console opens as usual.
- **Several accounts.** Once connected, Integrations lists every account with
  its check results and Re-check; "Connect another account" (`?add=1`) opens
  a fresh setup for the next one.

- **Every screen leads with the decision.** The dashboard opens on "Fix first"
  (open risks, worst first) and the posture score per category; a detail page
  opens on a summary strip (risk, owner, last active, exposure, access used)
  and "Needs attention" (each failing check with its next step), with the
  reference details in a sidebar and dates on one timeline.
- **First run is explained, not shown as zeros.** Until a tenant's first scan
  completes, the dashboard says whether a scan is running, failed or has not
  started, and what happens next.
- **The dashboard has a scope; the lists do not.** The dashboard shows the
  accounts, regions and scan saved to your profile (`/settings`). The identity
  and credential lists, detail pages and search always cover the latest
  completed scan across every account, because that is what those endpoints
  return. Each list says so when your dashboard scope is narrower.
- **Counts link only where definitions match.** A dashboard figure opens a list
  only when that list, filtered, returns the same set.
- **"global" is never sent as a region.** Saved settings can hold it, the API
  rejects it with a 400, and the API counts global resources anyway.
- **Rows open a preview, not a page.** J/K or the arrow keys step through rows;
  Ctrl/Cmd-click opens the full page.
- **Filters live in the URL**, and old links (`/dormant`, `/hygiene`,
  `?view=expiring`) become the filters they stood for.
- **Each panel fails on its own**, with Retry; loading states are skeletons.
- **Server internals are never shown**, and malformed ids never reach the API.
- **Reduced motion is respected** everywhere.

## Tenant onboarding

The backend has no onboarding API: a tenant exists once its row and users are
in the global database (`tenants`, `nhi_users`) and its tenant database exists.
Tested stage by stage with a second tenant: registered with no database (sign-in
works; data calls answer 500, and the console says the data store may not be
ready), empty database (first-run page), first scan running, first scan
completed (dashboard fills in). Neither tenant can see the other's records.

## Backend changes in this delivery

Only `internal/routes/routes.go` and `cmd/api-server/main.go` changed. They wire
the existing Credential Exposure handlers (`/api/findings`, `/api/findings/summary`,
`/api/findings/ml-flagged`, `/api/findings/decision`, `/api/allowlist`,
`/api/deep-scan`, `/api/deep-scan-status`) behind the JWT, admin only, each
request served from the caller's tenant database. The scanner URL and key come
from `SECRET_SCANNER_BASE_URL` and `SECRET_SCANNER_DASHBOARD_KEY` on the server.
`configs/config.yaml` was not opened or changed.

## Backend issues (for the backend team)

1. No onboarding API; a tenant without a database gets generic 500s, not a "not provisioned" code.
2. Lists and details ignore saved settings (accounts, regions, scan); lists have no account or region filter.
3. The overview ignores the saved scan.
4. Region validation rejects `global`, which settings can hold (the console strips it).
5. Postures read `nhi_identities_aws`, not `identities` (totals differ), ignore account and region, ship no migration for the `ispm_*` tables, and do not filter findings by scan.
6. Credentials list: binding counts and `is_orphaned` span every scan; deleted rows are included; `idle_days` is null when never used.
7. "Stale" differs between dashboard and lists; `max_days_until_expiry` includes expired credentials.
8. Identity relationships with `edge_type` return 500.
9. Activity: `source_ip`, `user_agent`, `error_code` and the error rate are hard-coded empty or 0; IP and region counts ignore `time_range`; a credential's `active_regions` is its home region; credential activity has no paging.
10. Descending sorts put empty values first.
11. Exposure: routes were not wired (done here); repositories hard-code the `nhi_scanner` schema; the decision and allowlist record the actor from the request body, so it can be spoofed.
12. Login and `/me` return `db_name` to the browser.
13. `credentials_expiring_soon` has no id.
14. `go vet` fails on `shared_credentials_repo.go` (Sprintf arguments), so `go test ./...` fails to build that package.
15. `dashboard_overview_service.go` carries about 285 lines of commented-out duplicate code.

## Structure

```
src/
  app/        providers, auth, route guards, role checks
  shell/      top bar, sidebar, breadcrumbs, command palette
  features/   overview, identities, credentials, detail (shared tabs), exposure, preview, auth
  lib/api/    the HTTP client, session storage and every endpoint call
  lib/        labels, formatting, roles, scope store, motion, hooks
  ui/         design-system primitives (panels, grids, dialogs, fields)
  charts/     line, column, bar and donut charts
```
