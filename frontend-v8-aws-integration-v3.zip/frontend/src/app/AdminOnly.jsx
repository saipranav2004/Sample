import { Link } from 'react-router-dom';
import { ShieldOff } from 'lucide-react';
import { Button } from '../ui/Button';
import { Panel } from '../ui/Panel';
import { EmptyState } from '../ui/States';
import { useAccess } from './useAccess';

/**
 * The credential exposure screens. The API answers them for admins only
 * (403 FORBIDDEN otherwise), so other roles get this explanation instead of
 * a request that is bound to fail.
 */
export function AdminOnly({ children }) {
  const { can, lock } = useAccess();
  if (can('exposure.view')) return children;
  return (
    <Panel className="animate-rise">
      <EmptyState
        icon={ShieldOff}
        title="Secrets found in code are visible to admins only"
        description={`${lock('exposure.view')} Ask an admin if you need a finding reviewed.`}
        action={
          <Button as={Link} to="/overview" variant="secondary" size="sm">
            Go to the dashboard
          </Button>
        }
      />
    </Panel>
  );
}
