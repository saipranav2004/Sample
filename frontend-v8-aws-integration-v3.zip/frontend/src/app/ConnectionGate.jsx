import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { fetchAwsIntegration } from '../lib/api/endpoints';
import { AppShell } from '../shell/AppShell';
import { OnboardingShell } from '../shell/OnboardingShell';
import { Loader2 } from 'lucide-react';
import { useAuth } from './AuthContext';

const ConnectionGateContext = createContext(null);

/** Whether this workspace has ever had an AWS account pass all three checks. */
export function hasConnectedAccount(integration) {
  return integration?.status === 'connected' || (integration?.accounts ?? []).some((account) => account.connectedAt);
}

/**
 * Until a workspace has connected an AWS account there is nothing for any
 * other screen to show, so the console is reduced to one screen: connect an
 * account. No navigation, no empty dashboard - just the setup, in a focused
 * layout. The first successful connection opens the full console.
 *
 * "Connected" means connected at least once (an account has a connected_at).
 * A later re-check that fails does not lock a workspace out of the data it
 * already has; the Integrations page reports that account as needing
 * attention instead.
 *
 * If the check itself fails (API down, platform not configured) the console
 * opens as usual: every screen has its own error state, and a gate that
 * fails closed would leave people staring at a spinner.
 */
export function ConnectionGate() {
  const { token } = useAuth();
  const { pathname } = useLocation();
  const [state, setState] = useState('checking'); // checking | gated | open
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!token) return undefined;
    const controller = new AbortController();
    fetchAwsIntegration(controller.signal)
      .then((integration) => setState(hasConnectedAccount(integration) ? 'open' : 'gated'))
      .catch((error) => {
        if (!controller.signal.aborted && error?.code !== 'CANCELLED') setState('open');
      });
    return () => controller.abort();
  }, [token, attempt]);

  const markConnected = useCallback(() => setState('open'), []);
  const recheck = useCallback(() => setAttempt((value) => value + 1), []);
  const value = useMemo(() => ({ gated: state === 'gated', markConnected, recheck }), [state, markConnected, recheck]);

  if (state === 'checking') {
    return (
      <div className="grid min-h-dvh place-items-center bg-canvas" aria-busy="true">
        <span className="inline-flex items-center gap-2.5 text-[13px] text-ink-3">
          <Loader2 aria-hidden="true" className="size-4 animate-spin" />
          <span role="status">Opening your workspace…</span>
        </span>
      </div>
    );
  }

  if (state === 'gated') {
    /* One address for the setup, so a deep link or a bookmark to any other
       screen lands here, and the browser's back button has nowhere empty to go. */
    if (pathname !== '/integrations') return <Navigate to="/integrations" replace />;
    return (
      <ConnectionGateContext.Provider value={value}>
        <OnboardingShell />
      </ConnectionGateContext.Provider>
    );
  }

  return (
    <ConnectionGateContext.Provider value={value}>
      <AppShell />
    </ConnectionGateContext.Provider>
  );
}

/** `{ gated, markConnected, recheck }` - gated is true while the console is reduced to the setup. */
export function useConnectionGate() {
  return useContext(ConnectionGateContext) ?? { gated: false, markConnected: () => {}, recheck: () => {} };
}
