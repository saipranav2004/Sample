import { Outlet } from 'react-router-dom';
import { LogOut, Moon, Sun } from 'lucide-react';
import { useAuth } from '../app/AuthContext';
import { useThemeMode } from '../app/ThemeContext';
import { initialsOf } from '../lib/format';
import { BrandLockup } from './Brand';

/**
 * The console before its first AWS account is connected: the brand, the
 * theme, who is signed in and a way out - and the setup. No navigation,
 * because every place it would lead is empty until an account is connected.
 */
export function OnboardingShell() {
  const { user, logout } = useAuth();
  const { theme, setPreference } = useThemeMode();
  const nextTheme = theme === 'dark' ? 'light' : 'dark';
  /* /auth/me carries the signed-in address as user_id; sign-in returns email. */
  const who = user?.email || user?.user_id || '';
  const iconButton =
    'grid size-10 shrink-0 place-items-center rounded-[var(--radius-control)] text-topbar-muted transition-colors hover:bg-topbar-hover hover:text-topbar-ink';

  return (
    <div className="min-h-dvh bg-canvas">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[90] focus:rounded-md focus:bg-surface focus:px-3 focus:py-2 focus:text-[13px] focus:font-medium focus:text-ink focus:shadow-lg"
      >
        Skip to content
      </a>
      <header className="topbar-surface fixed inset-x-0 top-0 z-40 flex h-16 items-center gap-2 border-b border-topbar-line px-3 sm:px-4 lg:px-5">
        <span className="hidden shrink-0 px-1 sm:block">
          <BrandLockup height={34} />
        </span>
        <img src="/brand/mark.png" alt="Deep Algorithms" className="block size-8 object-contain sm:hidden" draggable="false" />
        <div aria-hidden="true" className="flex-1" />
        <button
          type="button"
          onClick={() => setPreference(nextTheme)}
          aria-label={`Switch to ${nextTheme} theme`}
          title={`Switch to ${nextTheme} theme`}
          className={iconButton}
        >
          {nextTheme === 'light' ? <Sun aria-hidden="true" className="size-5" /> : <Moon aria-hidden="true" className="size-5" />}
        </button>
        {who && (
          <span className="hidden items-center gap-2 pl-1 md:flex">
            <span
              aria-hidden="true"
              className="grid size-8 place-items-center rounded-full bg-[linear-gradient(135deg,var(--t-brand)_0%,var(--t-accent)_100%)] text-[12px] font-bold text-white"
            >
              {initialsOf(user?.full_name || who)}
            </span>
            <span className="max-w-[220px] truncate text-[13px] text-topbar-ink">{who}</span>
          </span>
        )}
        <button
          type="button"
          onClick={logout}
          className="ml-1 inline-flex h-9 items-center gap-2 rounded-[var(--radius-control)] px-3 text-[13px] font-medium text-topbar-muted transition-colors hover:bg-topbar-hover hover:text-topbar-ink"
        >
          <LogOut aria-hidden="true" className="size-4" />
          Sign out
        </button>
      </header>

      <main id="main" className="px-3 pt-20 pb-14 sm:px-5 lg:px-6">
        <div className="@container mx-auto w-full max-w-[1320px]">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
