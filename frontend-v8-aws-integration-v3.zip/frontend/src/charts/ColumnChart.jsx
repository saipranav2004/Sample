import { useId, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { formatNumber } from '../lib/format';
import { cn } from '../ui/cn';
import { niceMax, useWidth } from './useWidth';

/**
 * One measure over ordered buckets (days, scans): columns from a zero
 * baseline with rounded tops, a 2px gap between them, a recessive grid and a
 * per-column tooltip. A column may carry its own `color` (a failed scan, say)
 * and a `note` for the tooltip; anything coloured is also named in `note`, so
 * colour is never the only signal. A `flag` ("Failed", "Running") is written
 * above the column, so a run that found nothing is still visible.
 *
 * items: [{ key, label, tick?, value, color?, note?, flag?, flagColor? }]
 */
export function ColumnChart({ items, height = 180, title, color = 'var(--t-series-1)', unit, className, onSelect }) {
  const [ref, width] = useWidth(640);
  const [hover, setHover] = useState(null);
  const reduced = useReducedMotion();
  const titleId = useId();

  const pad = { top: items.some((item) => item.flag) ? 22 : 10, right: 8, bottom: 24, left: 40 };
  const innerW = Math.max(40, width - pad.left - pad.right);
  const innerH = height - pad.top - pad.bottom;
  const top = niceMax(Math.max(0, ...items.map((item) => Number(item.value) || 0)));
  const slot = items.length ? innerW / items.length : innerW;
  const gap = Math.min(6, Math.max(2, slot * 0.18));
  const barW = Math.max(2, slot - gap);
  const y = (value) => pad.top + innerH - (Math.max(0, value) / top) * innerH;
  const ticks = [0, 0.5, 1].map((f) => Math.round(top * f));
  const labelEvery = Math.max(1, Math.ceil(items.length / Math.max(2, Math.floor(innerW / 56))));
  const current = hover !== null ? items[hover] : null;

  return (
    <div ref={ref} className={cn('relative w-full', className)}>
      <svg width={width} height={height} role="img" aria-labelledby={titleId} className="block overflow-visible" onMouseLeave={() => setHover(null)}>
        <title id={titleId}>{`${title ?? 'Columns'}: ${items.map((item) => `${item.label} ${formatNumber(item.value)}`).join(', ')}`}</title>
        {ticks.map((tick) => (
          <g key={tick}>
            <line x1={pad.left} x2={pad.left + innerW} y1={y(tick)} y2={y(tick)} stroke="var(--t-chart-grid)" strokeWidth={1} />
            <text x={pad.left - 8} y={y(tick)} dy="0.32em" textAnchor="end" className="fill-[var(--t-ink-3)] text-[10.5px]" style={{ fontVariantNumeric: 'tabular-nums' }}>
              {formatNumber(tick)}
            </text>
          </g>
        ))}
        {items.map((item, index) => {
          const value = Number(item.value) || 0;
          const x0 = pad.left + index * slot + gap / 2;
          const h = Math.max(value > 0 ? 2 : 0, pad.top + innerH - y(value));
          const r = Math.min(4, barW / 2, h);
          const yTop = pad.top + innerH - h;
          /* Rounded top, square base on the baseline. */
          const d = h <= 0 ? '' : `M${x0},${pad.top + innerH} V${yTop + r} Q${x0},${yTop} ${x0 + r},${yTop} H${x0 + barW - r} Q${x0 + barW},${yTop} ${x0 + barW},${yTop + r} V${pad.top + innerH} Z`;
          const dim = hover !== null && hover !== index;
          return (
            <g key={item.key}>
              <motion.path
                d={d}
                fill={item.color ?? color}
                initial={reduced ? false : { opacity: 0, scaleY: 0 }}
                animate={{ opacity: dim ? 0.4 : 1, scaleY: 1 }}
                style={{ transformOrigin: `0px ${pad.top + innerH}px` }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1], delay: reduced ? 0 : Math.min(index * 0.012, 0.35) }}
              />
              {item.flag && (
                <>
                  {h <= 0 && <rect x={x0} y={pad.top + innerH - 3} width={barW} height={3} rx={1.5} fill={item.color ?? color} />}
                  <text x={x0 + barW / 2} y={yTop - 6} textAnchor="middle" className="text-[10.5px] font-semibold" fill={item.flagColor ?? 'var(--t-ink-2)'}>
                    {item.flag}
                  </text>
                </>
              )}
              <rect
                x={pad.left + index * slot}
                y={pad.top}
                width={slot}
                height={innerH}
                fill="transparent"
                onMouseEnter={() => setHover(index)}
                onClick={onSelect ? () => onSelect(item) : undefined}
                style={{ cursor: onSelect ? 'pointer' : 'default' }}
              />
              {(index % labelEvery === 0 || index === items.length - 1) && (
                <text x={x0 + barW / 2} y={height - 8} textAnchor="middle" className="fill-[var(--t-ink-3)] text-[10.5px]">
                  {item.tick ?? item.label}
                </text>
              )}
            </g>
          );
        })}
        <line x1={pad.left} x2={pad.left + innerW} y1={pad.top + innerH} y2={pad.top + innerH} stroke="var(--t-chart-axis)" strokeWidth={1} />
      </svg>
      {current && (
        <div
          role="status"
          className="pointer-events-none absolute top-0 z-10 rounded-lg border border-line bg-surface px-3 py-2 text-[12px] shadow-[var(--t-shadow-md)]"
          style={(pad.left + hover * slot) > width / 2 ? { right: width - (pad.left + hover * slot) + 6 } : { left: pad.left + (hover + 1) * slot + 6 }}
        >
          <p className="font-semibold text-ink">{current.label}</p>
          <p className="text-ink-2">
            <span data-numeric="" className="font-semibold text-ink">{formatNumber(current.value)}</span>
            {unit ? ` ${unit}` : ''}
          </p>
          {current.note && <p className="text-ink-3">{current.note}</p>}
        </div>
      )}
    </div>
  );
}
