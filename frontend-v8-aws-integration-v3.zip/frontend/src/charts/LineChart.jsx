import { useId, useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { formatNumber } from '../lib/format';
import { cn } from '../ui/cn';
import { DATE_FULL, DATE_MONTH, niceMax, useWidth } from './useWidth';

/**
 * Change over time for one to four series that share a unit (a count), on one
 * axis. Thin 2px lines, a recessive grid, the series named in a legend and at
 * the end of each line, and a crosshair that reads every series out at the
 * date under the pointer.
 *
 * series: [{ key, label, color, points: [{ date: 'YYYY-MM-DD', value }] }]
 */
export function LineChart({ series, height = 220, title, format = DATE_MONTH, className }) {
  const [ref, width] = useWidth(640);
  const [hover, setHover] = useState(null);
  const reduced = useReducedMotion();
  const titleId = useId();

  const dates = useMemo(
    () => [...new Set(series.flatMap((s) => s.points.map((p) => p.date)))].sort(),
    [series],
  );
  const pad = { top: 12, right: 92, bottom: 26, left: 40 };
  const innerW = Math.max(40, width - pad.left - pad.right);
  const innerH = height - pad.top - pad.bottom;
  const top = niceMax(Math.max(0, ...series.flatMap((s) => s.points.map((p) => Number(p.value) || 0))));
  const x = (date) => pad.left + (dates.length < 2 ? innerW / 2 : (dates.indexOf(date) / (dates.length - 1)) * innerW);
  const y = (value) => pad.top + innerH - (Math.max(0, value) / top) * innerH;
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(top * f));
  const labelEvery = Math.max(1, Math.ceil(dates.length / Math.max(2, Math.floor(innerW / 64))));

  const paths = series.map((s) => {
    const pts = [...s.points].sort((a, b) => (a.date < b.date ? -1 : 1));
    const d = pts.map((p, i) => `${i ? 'L' : 'M'}${x(p.date).toFixed(1)},${y(Number(p.value) || 0).toFixed(1)}`).join(' ');
    return { ...s, pts, d, last: pts.at(-1) };
  });

  /* End labels sit at the last point; when two would overlap, nudge apart. */
  const ends = paths.filter((p) => p.last).map((p) => ({ key: p.key, y: y(Number(p.last.value) || 0), path: p })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < ends.length; i += 1) if (ends[i].y - ends[i - 1].y < 14) ends[i].y = ends[i - 1].y + 14;

  const onMove = (event) => {
    if (dates.length === 0) return;
    const box = event.currentTarget.getBoundingClientRect();
    const px = event.clientX - box.left - pad.left;
    const index = dates.length < 2 ? 0 : Math.round((px / innerW) * (dates.length - 1));
    setHover(dates[Math.min(dates.length - 1, Math.max(0, index))]);
  };

  const hoverX = hover ? x(hover) : null;
  const readings = hover
    ? paths.map((p) => ({ key: p.key, label: p.label, color: p.color, value: p.pts.find((pt) => pt.date === hover)?.value })).filter((r) => r.value !== undefined)
    : [];

  return (
    <div ref={ref} className={cn('relative w-full', className)}>
      <svg
        width={width}
        height={height}
        role="img"
        aria-labelledby={titleId}
        className="block overflow-visible"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
      >
        <title id={titleId}>
          {`${title ?? 'Over time'}: ${paths.map((p) => `${p.label} ${p.last ? formatNumber(p.last.value) : 'no data'}`).join(', ')}`}
        </title>
        {ticks.map((tick) => (
          <g key={tick}>
            <line x1={pad.left} x2={pad.left + innerW} y1={y(tick)} y2={y(tick)} stroke="var(--t-chart-grid)" strokeWidth={1} />
            <text x={pad.left - 8} y={y(tick)} dy="0.32em" textAnchor="end" className="fill-[var(--t-ink-3)] text-[10.5px]" style={{ fontVariantNumeric: 'tabular-nums' }}>
              {formatNumber(tick)}
            </text>
          </g>
        ))}
        {dates.map((date, i) =>
          i % labelEvery === 0 || i === dates.length - 1 ? (
            <text key={date} x={x(date)} y={height - 8} textAnchor="middle" className="fill-[var(--t-ink-3)] text-[10.5px]">
              {format.format(new Date(`${date}T00:00:00Z`))}
            </text>
          ) : null,
        )}
        {paths.map((p) => (
          <motion.path
            key={p.key}
            d={p.d}
            fill="none"
            stroke={p.color}
            strokeWidth={2}
            strokeLinejoin="round"
            strokeLinecap="round"
            initial={reduced ? false : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          />
        ))}
        {ends.map((end) => (
          <g key={end.key}>
            <circle cx={x(end.path.last.date)} cy={y(Number(end.path.last.value) || 0)} r={3.5} fill={end.path.color} stroke="var(--t-surface)" strokeWidth={2} />
            <text x={pad.left + innerW + 10} y={end.y} dy="0.32em" className="fill-[var(--t-ink-2)] text-[11px] font-semibold">
              {end.path.label}
            </text>
          </g>
        ))}
        {hoverX !== null && (
          <g pointerEvents="none">
            <line x1={hoverX} x2={hoverX} y1={pad.top} y2={pad.top + innerH} stroke="var(--t-line-strong)" strokeWidth={1} />
            {readings.map((r) => (
              <circle key={r.key} cx={hoverX} cy={y(Number(r.value) || 0)} r={4} fill={r.color} stroke="var(--t-surface)" strokeWidth={2} />
            ))}
          </g>
        )}
      </svg>
      {hover && readings.length > 0 && (
        <div
          role="status"
          className="pointer-events-none absolute top-1 z-10 min-w-36 rounded-lg border border-line bg-surface px-3 py-2 text-[12px] shadow-[var(--t-shadow-md)]"
          style={hoverX > width / 2 ? { right: width - hoverX + 10 } : { left: hoverX + 10 }}
        >
          <p className="mb-1 font-semibold text-ink">{DATE_FULL.format(new Date(`${hover}T00:00:00Z`))}</p>
          {readings.map((r) => (
            <p key={r.key} className="flex items-center justify-between gap-4 text-ink-2">
              <span className="flex items-center gap-1.5">
                <span aria-hidden="true" className="size-2 rounded-full" style={{ background: r.color }} />
                {r.label}
              </span>
              <span data-numeric="" className="font-semibold text-ink">{formatNumber(r.value)}</span>
            </p>
          ))}
        </div>
      )}
    </div>
  );
}
