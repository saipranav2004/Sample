import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { fetchCredentialTab, fetchIdentityTab } from '../../lib/api/endpoints';
import { Verdict } from '../../ui/Verdict';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatRelative } from '../../lib/format';
import { credentialTypeLabel, environmentLabel, functionalClassLabel, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { EASE_OUT } from '../../lib/motion';
import { Button, IconButton } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Drawer } from '../../ui/Overlay';
import { FactsCard } from '../../ui/FactsCard';
import { DetailSkeleton, ListSkeleton } from '../../ui/Skeleton';
import { ErrorState } from '../../ui/States';
import { checkSummary } from '../../ui/StatusChecks';
import { Tag } from '../../ui/Tag';
import { TagChips } from '../credentials/parts';
import { riskChecks, riskFindings } from '../detail/riskSignals';

/**
 * Quick look at one row without leaving the list: what is wrong with it,
 * who owns it, and the dates that matter. Up and down (or J and K) step
 * through the rows behind it; the full page is one click away.
 *
 * Triage is "check ten rows in a row". Opening each one as a page costs a
 * load and the reader's place in the list every time.
 */
export function RecordPreview({ kind, rows, index, onIndexChange, onClose }) {
  const open = index !== null && index >= 0 && index < rows.length;
  const row = open ? rows[index] : null;
  const total = rows.length;

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      const tag = event.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((event.key === 'ArrowDown' || event.key === 'j') && index < total - 1) {
        event.preventDefault();
        onIndexChange(index + 1);
      }
      if ((event.key === 'ArrowUp' || event.key === 'k') && index > 0) {
        event.preventDefault();
        onIndexChange(index - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, index, total, onIndexChange]);

  const href = row ? `/${kind === 'identity' ? 'identities' : 'credentials'}/${encodeURIComponent(row.id)}` : '#';
  const typeLabel = row ? (kind === 'identity' ? identityTypeLabel(row.identity_type) : credentialTypeLabel(row.credential_type)) : '';

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="lg"
      eyebrow={row ? (kind === 'identity' ? `${functionalClassLabel(row.functional_class)} identity` : 'Credential') : ''}
      title={row ? row.name || row.arn : ''}
      subtitle={row ? [typeLabel, row.account_id && `account ${row.account_id}`, row.region && regionLabel(row.region)].filter(Boolean).join(' · ') : null}
      footer={
        <>
          <span className="mr-auto flex items-center gap-1">
            <IconButton icon={ChevronUp} label="Previous row (K)" size="sm" variant="secondary" disabled={!open || index === 0} onClick={() => onIndexChange(index - 1)} />
            <IconButton icon={ChevronDown} label="Next row (J)" size="sm" variant="secondary" disabled={!open || index >= total - 1} onClick={() => onIndexChange(index + 1)} />
            <span data-numeric="" className="ml-1.5 text-[12px] text-ink-3">
              {open ? `${index + 1} of ${total}` : ''}
            </span>
          </span>
          <Button as={Link} to={href} variant="primary" iconRight={ArrowRight}>
            Open {kind === 'identity' ? 'identity' : 'credential'}
          </Button>
        </>
      }
    >
      {/* Stepping between rows swaps the body with a short cross-fade, so the
          change of record is visible without the panel moving. */}
      <AnimatePresence mode="wait" initial={false}>
        {row && (
          <motion.div
            key={row.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_OUT }}
            className="@container flex flex-col gap-5 p-4 sm:p-5"
          >
            {kind === 'identity' ? <IdentityBody id={row.id} /> : <CredentialBody id={row.id} />}
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}

function Section({ title, aside, children }) {
  return (
    <section>
      <div className="mb-1.5 flex items-baseline justify-between gap-3">
        <h3 className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{title}</h3>
        {aside && <span className="text-[11.5px] text-ink-3">{aside}</span>}
      </div>
      {children}
    </section>
  );
}

function Loading() {
  return (
    <>
      <DetailSkeleton rows={6} />
      <ListSkeleton rows={3} />
    </>
  );
}

function Head({ status, arn }) {
  const meta = statusMeta(status);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Tag size="sm" tone={meta.tone} dot>
        {meta.label}
      </Tag>
      {arn && (
        <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
          <CopyableValue value={arn} />
        </span>
      )}
    </div>
  );
}

function Links({ items, more }) {
  return (
    <ul className="flex flex-col divide-y divide-line rounded-[var(--radius-control)] border border-line">
      {items.map((item) => (
        <li key={item.key}>
          <Link to={item.to} className="flex items-center justify-between gap-3 px-3 py-2 hover:bg-surface-2">
            <span className="min-w-0">
              <span className="block truncate text-[13px] font-medium text-ink">{item.title}</span>
              <span className="block truncate text-[11.5px] text-ink-3">{item.sub}</span>
            </span>
            {item.aside}
          </Link>
        </li>
      ))}
      {more > 0 && <li className="px-3 py-2 text-[12px] text-ink-3">+{more} more on the full record</li>}
    </ul>
  );
}

/** `GET /credentials/{id}?tab=overview`: the API's own risk signals, the facts, who holds it. */
function CredentialBody({ id }) {
  const detail = useQuery((signal) => fetchCredentialTab(id, 'overview', {}, signal), [id]);
  const data = detail.data;
  if (detail.isError && !data) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!data?.credential) return <Loading />;
  const c = data.credential;
  const checks = riskChecks(data.risk_signals);
  const holders = data.bound_identities ?? [];
  const owner = c.owner_principal_arn;
  const expires = c.expires_at;
  const days = c.days_until_expiry;
  return (
    <>
      <Head status={c.status} arn={c.arn} />
      <Verdict findings={riskFindings(data.risk_signals)} cleanText={`${checkSummary(checks)}. Nothing to act on.`} moreText={(n) => `+${n} more on the full record`} />
      <FactsCard
        facts={[
          { label: 'Owner principal', value: owner ? String(owner).split(/[/:]/).pop() : 'None recorded', mono: Boolean(owner), tone: owner ? undefined : 'medium' },
          {
            label: 'Rotation',
            value: !c.last_rotated_at ? 'Never rotated' : c.rotation_status === 'Overdue' ? 'Overdue' : `${c.days_since_rotation} days ago`,
            tone: !c.last_rotated_at || c.rotation_status === 'Overdue' ? 'high' : undefined,
            sub: c.rotation_enabled ? 'Automatic' : 'Rotation off',
          },
          { label: 'Last used', value: c.last_used_at ? formatRelative(c.last_used_at) : 'No use recorded', tone: c.idle_days >= 90 ? 'high' : undefined, sub: c.last_used_at ? formatDateTime(c.last_used_at) : undefined },
          {
            label: 'Expires',
            value: !expires ? (String(c.status).toLowerCase() === 'expired' ? 'Expired' : 'Does not expire') : days < 0 ? `Expired ${formatRelative(expires)}` : `In ${days} day${days === 1 ? '' : 's'}`,
            tone: (expires && days <= 30) || String(c.status).toLowerCase() === 'expired' ? 'critical' : undefined,
            sub: expires ? formatDateTime(expires) : String(c.status).toLowerCase() === 'expired' ? 'No expiry date recorded' : undefined,
          },
        ]}
      />
      <Section title="Held by" aside={`${holders.length} identit${holders.length === 1 ? 'y' : 'ies'}`}>
        {holders.length === 0 ? (
          <p className="text-[12.5px] text-ink-3">No identity is bound to it in the latest scan.</p>
        ) : (
          <Links
            more={holders.length - 3}
            items={holders.slice(0, 3).map((h) => ({
              key: `${h.identity_id}-${h.binding_type}`,
              to: `/identities/${encodeURIComponent(h.identity_id)}`,
              title: h.name || h.identity_id,
              sub: `${identityTypeLabel(h.identity_type)} · ${tokenLabel(h.binding_type)}`,
              aside: h.last_activity_at ? <span className="shrink-0 text-[11.5px] text-ink-3">{formatRelative(h.last_activity_at)}</span> : null,
            }))}
          />
        )}
      </Section>
    </>
  );
}

/** `GET /identities/{id}?tab=overview`: the API's own risk signals, the facts, what it holds. */
function IdentityBody({ id }) {
  const detail = useQuery((signal) => fetchIdentityTab(id, 'overview', {}, signal), [id]);
  const data = detail.data;
  if (detail.isError && !data) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!data?.identity) return <Loading />;
  const identity = data.identity;
  const checks = riskChecks(data.risk_signals);
  const held = data.bound_credentials ?? [];
  const tags = data.tags && typeof data.tags === 'object' && !Array.isArray(data.tags) ? data.tags : {};
  return (
    <>
      <Head status={identity.status} arn={identity.arn} />
      <Verdict findings={riskFindings(data.risk_signals)} cleanText={`${checkSummary(checks)}. Nothing to act on.`} moreText={(n) => `+${n} more on the full record`} />
      <FactsCard
        facts={[
          { label: 'Owner', value: identity.owner || 'No owner', tone: identity.owner ? undefined : 'medium', sub: environmentLabel(identity.environment) },
          {
            label: 'Last active',
            value: identity.last_activity_at ? formatRelative(identity.last_activity_at) : 'No activity recorded',
            tone: identity.last_activity_at && identity.idle_days >= 90 ? 'high' : undefined,
            sub: identity.last_activity_at ? formatDateTime(identity.last_activity_at) : undefined,
          },
          {
            label: 'Reachable from',
            value: identity.is_publicly_accessible ? 'The internet' : 'Private network only',
            tone: identity.is_publicly_accessible ? 'critical' : undefined,
            sub: identity.vpc_id ? `VPC ${identity.vpc_id}` : 'No VPC',
          },
          { label: 'Class', value: functionalClassLabel(identity.functional_class), sub: identity.category || undefined },
        ]}
      />
      <Section title="Credentials it holds" aside={`${held.length} total`}>
        {held.length === 0 ? (
          <p className="text-[12.5px] text-ink-3">No credential is bound to it in the latest scan.</p>
        ) : (
          <Links
            more={held.length - 3}
            items={held.slice(0, 3).map((c) => ({
              key: c.credential_id,
              to: `/credentials/${encodeURIComponent(c.credential_id)}`,
              title: c.name || c.credential_id,
              sub: `${credentialTypeLabel(c.credential_type)} · ${tokenLabel(c.binding_type)}`,
              aside: c.granted_actions_count ? (
                <span data-numeric="" className={`shrink-0 text-[11.5px] ${c.utilization_pct < 50 ? 'font-semibold text-high' : 'text-ink-3'}`}>
                  {c.used_actions_count} of {c.granted_actions_count} used
                </span>
              ) : null,
            }))}
          />
        )}
      </Section>
      {Object.keys(tags).length > 0 && (
        <Section title="Tags">
          <TagChips tags={tags} />
        </Section>
      )}
    </>
  );
}
