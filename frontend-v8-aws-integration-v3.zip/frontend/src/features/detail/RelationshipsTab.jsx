import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Network } from 'lucide-react';
import { fetchCredentialTab, fetchIdentityTab } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative } from '../../lib/format';
import { tokenLabel } from '../../lib/labels';
import { DataGrid } from '../../ui/DataGrid';
import { Panel, PanelHeader } from '../../ui/Panel';
import { ListSkeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { cn } from '../../ui/cn';

const DEPTHS = [
  { value: '1', label: '1 hop' },
  { value: '2', label: '2 hops' },
  { value: '3', label: '3 hops' },
];

const KIND_COLOR = { identity: 'var(--t-series-1)', credential: 'var(--t-series-2)', resource: 'var(--t-series-3)', unknown: 'var(--t-series-8)' };
const KIND_LABEL = { identity: 'Identities', credential: 'Credentials', resource: 'Resources', unknown: 'Outside the inventory' };

/** Where a related record opens: the list, searched by name (the graph carries ARNs, not ids). */
function hrefFor(type, name) {
  if (!name) return null;
  if (type === 'identity') return `/identities?search=${encodeURIComponent(name)}`;
  if (type === 'credential') return `/credentials?search=${encodeURIComponent(name)}`;
  return null;
}

/**
 * Relationships of one record: `?tab=relationships&depth=`. The direct links
 * are drawn as a map, inbound on the left and outbound on the right, grouped
 * by kind of link; the reach within the chosen number of hops is counted by
 * kind (what a leak of this record could get to); the full list follows.
 * Relationship filtering is done here: the identity endpoint's edge_type
 * filter fails on the server.
 */
export function RelationshipsTab({ kind, id, name }) {
  const [depth, setDepth] = useState('1');
  const [only, setOnly] = useState('');
  const query = useQuery(
    (signal) => (kind === 'identity' ? fetchIdentityTab(id, 'relationships', { depth }, signal) : fetchCredentialTab(id, 'relationships', { depth }, signal)),
    [kind, id, depth],
  );
  const data = query.data;
  const table = useMemo(() => data?.relationship_table ?? [], [data]);
  const nodes = useMemo(() => data?.graph?.nodes ?? [], [data]);

  const groups = useMemo(() => {
    const by = new Map();
    for (const row of table) {
      const key = `${row.direction}|${row.relationship}`;
      if (!by.has(key)) by.set(key, { key, direction: row.direction, relationship: row.relationship, rows: [] });
      by.get(key).rows.push(row);
    }
    return [...by.values()];
  }, [table]);
  const reach = useMemo(() => {
    const counts = { identity: 0, credential: 0, resource: 0, unknown: 0 };
    for (const node of nodes) if (!node.is_current) counts[node.type in counts ? node.type : 'unknown'] += 1;
    return counts;
  }, [nodes]);
  const relationships = [...new Set(table.map((row) => row.relationship))];
  const rows = (only ? table.filter((row) => row.relationship === only) : table).map((row, index) => ({ ...row, _key: index }));

  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Relationships could not be loaded" /></Panel>;

  const inbound = groups.filter((g) => g.direction === 'inbound');
  const outbound = groups.filter((g) => g.direction !== 'inbound');
  const reached = Object.values(reach).reduce((a, b) => a + b, 0);

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <PanelHeader
          icon={Network}
          title="Relationship map"
          subtitle="What points at this record, and what it reaches, from the trust and binding edges in the latest scan."
          actions={<SegmentedControl label="Reach" value={depth} onChange={setDepth} options={DEPTHS} />}
        />
        {!data ? (
          <div className="mt-4">
            <ListSkeleton rows={4} />
          </div>
        ) : table.length === 0 ? (
          <div className="mt-4">
            <EmptyState compact icon={Network} title="No relationships recorded" description="The scan found no binding, trust or access edge for this record." />
          </div>
        ) : (
          <>
            <div className="mt-4 grid items-center gap-3 @min-[52rem]:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)]">
              <Column title="Points at it" groups={inbound} empty="Nothing points at it." />
              <div className="flex justify-center">
                <span className="max-w-[16rem] truncate rounded-[var(--radius-panel)] border-2 border-brand bg-info-soft/60 px-4 py-3 text-center text-[13px] font-semibold text-ink" title={name}>
                  {name}
                </span>
              </div>
              <Column title="It reaches" groups={outbound} empty="It reaches nothing." outbound />
            </div>
            <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-line pt-3 @min-[40rem]:grid-cols-4">
              {Object.entries(reach).map(([type, count]) => (
                <div key={type} className="min-w-0">
                  <dt className="flex items-center gap-1.5 text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
                    <span aria-hidden="true" className="size-2 rounded-full" style={{ background: KIND_COLOR[type] }} />
                    {KIND_LABEL[type]}
                  </dt>
                  <dd data-numeric="" className="text-[17px] font-bold text-ink">{formatNumber(count)}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-2 text-[11.5px] text-ink-3">
              {formatNumber(reached)} record{reached === 1 ? '' : 's'} within {depth} hop{depth === '1' ? '' : 's'}. Widen the reach to see what a misuse of this record could get to.
            </p>
          </>
        )}
      </Panel>

      <Panel flush className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
          <div>
            <h2 className="text-[14px] font-semibold text-ink">Direct relationships</h2>
            <p className="mt-0.5 text-[12.5px] text-ink-3">{data ? `${formatNumber(table.length)} links` : 'Loading…'}</p>
          </div>
          {relationships.length > 1 && (
            <div className="flex flex-wrap gap-1.5" role="group" aria-label="Show relationship">
              {['', ...relationships].map((value) => (
                <button
                  key={value || 'all'}
                  type="button"
                  aria-pressed={only === value}
                  onClick={() => setOnly(value)}
                  className={cn(
                    'rounded-full border px-2.5 py-0.5 text-[12px]',
                    only === value ? 'border-brand/40 bg-info-soft font-semibold text-brand' : 'border-line-strong text-ink-2 hover:bg-surface-2',
                  )}
                >
                  {value || 'All'}
                </button>
              ))}
            </div>
          )}
        </div>
        <DataGrid
          caption="Direct relationships"
          density="compact"
          loading={!data}
          skeletonRows={5}
          rows={rows}
          rowKey={(row) => row._key}
          columns={[
            {
              key: 'relationship',
              header: 'Relationship',
              width: '170px',
              cell: (row) => (
                <span className="flex items-center gap-1.5 text-ink-2">
                  {row.direction === 'inbound' ? <ArrowLeft aria-hidden="true" className="size-3.5 text-ink-3" /> : <ArrowRight aria-hidden="true" className="size-3.5 text-ink-3" />}
                  {row.relationship}
                </span>
              ),
            },
            {
              key: 'target_name',
              header: 'Record',
              primary: true,
              cell: (row) => {
                const href = hrefFor(row.target_type, row.target_name);
                const label = row.target_name || row.target_arn;
                return href ? (
                  <Link to={href} className="block truncate font-medium text-brand hover:underline" title={row.target_arn}>
                    {label}
                  </Link>
                ) : (
                  <span className="block truncate font-mono text-[12px] text-ink" title={row.target_arn}>
                    {label}
                  </span>
                );
              },
            },
            { key: 'target_type', header: 'Kind', width: '130px', cell: (row) => <span className="text-ink-2">{row.target_type === 'unknown' ? 'Outside the inventory' : tokenLabel(row.target_type)}</span> },
            {
              key: 'last_active',
              header: 'Last seen',
              width: '140px',
              cell: (row) => (row.last_active ? <span title={formatDateTime(row.last_active)}>{formatRelative(row.last_active)}</span> : <span className="text-ink-3">-</span>),
            },
          ]}
          emptyState={<EmptyState compact title="No relationships" description="Nothing links to or from this record." />}
        />
      </Panel>
    </div>
  );
}

function Column({ title, groups, empty, outbound = false }) {
  return (
    <section className="min-w-0">
      <h3 className={cn('mb-2 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase', outbound && '@min-[52rem]:text-right')}>{title}</h3>
      {groups.length === 0 ? (
        <p className={cn('text-[12.5px] text-ink-3', outbound && '@min-[52rem]:text-right')}>{empty}</p>
      ) : (
        <div className="flex flex-col gap-2">
          {groups.map((group) => (
            <div key={group.key} className="rounded-[var(--radius-control)] border border-line bg-surface-2/60 px-3 py-2">
              <p className="flex items-center justify-between gap-2 text-[11.5px] font-semibold text-ink-2">
                <span className="flex items-center gap-1">
                  {outbound ? null : <ArrowRight aria-hidden="true" className="size-3 text-ink-3" />}
                  {group.relationship}
                  {outbound ? <ArrowRight aria-hidden="true" className="size-3 text-ink-3" /> : null}
                </span>
                <span data-numeric="" className="text-ink-3">{group.rows.length}</span>
              </p>
              <ul className="mt-1 flex flex-wrap gap-1">
                {group.rows.slice(0, 6).map((row, index) => (
                  <li
                    key={`${row.target_arn}-${index}`}
                    className="flex max-w-full items-center gap-1 rounded border border-line bg-surface px-1.5 py-0.5 text-[11.5px] text-ink"
                    title={row.target_arn}
                  >
                    <span aria-hidden="true" className="size-1.5 shrink-0 rounded-full" style={{ background: KIND_COLOR[row.target_type] ?? KIND_COLOR.unknown }} />
                    <span className="truncate">{row.target_name || row.target_arn}</span>
                  </li>
                ))}
                {group.rows.length > 6 && <li className="px-1 text-[11.5px] text-ink-3">+{group.rows.length - 6} more</li>}
              </ul>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
