import { Braces } from 'lucide-react';
import { fetchCredentialTab, fetchIdentityTab } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { tokenLabel } from '../../lib/labels';
import { Panel, PanelHeader } from '../../ui/Panel';
import { DetailSkeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { JsonBlock } from '../identities/JsonView';

const empty = (value) =>
  value === null || value === undefined || value === '' || (Array.isArray(value) && value.length === 0) || (typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === 0);

/**
 * `?tab=raw`: the stored record and what AWS returned, section by section.
 * Sections with nothing stored are listed as empty rather than shown as
 * blank boxes. Rendered as text, never as HTML.
 */
export function RawTab({ kind, id }) {
  const query = useQuery((signal) => (kind === 'identity' ? fetchIdentityTab(id, 'raw', {}, signal) : fetchCredentialTab(id, 'raw', {}, signal)), [kind, id]);
  const data = query.data;
  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="The raw record could not be loaded" /></Panel>;
  if (!data) return <Panel><DetailSkeleton rows={8} /></Panel>;
  const sections = Object.entries(data).filter(([key]) => key !== 'tab');
  const filled = sections.filter(([, value]) => !empty(value));
  const blank = sections.filter(([, value]) => empty(value));
  return (
    <div className="flex flex-col gap-4">
      {filled.length === 0 && (
        <Panel>
          <EmptyState compact icon={Braces} title="Nothing stored" description="The scanner kept no raw data for this record." />
        </Panel>
      )}
      {filled.map(([key, value]) => (
        <Panel key={key}>
          <PanelHeader icon={Braces} title={tokenLabel(key)} />
          <div className="mt-3">
            <JsonBlock value={value} copyLabel={`Copy ${tokenLabel(key).toLowerCase()}`} />
          </div>
        </Panel>
      ))}
      {blank.length > 0 && <p className="text-[12px] text-ink-3">Empty: {blank.map(([key]) => tokenLabel(key).toLowerCase()).join(', ')}.</p>}
    </div>
  );
}
