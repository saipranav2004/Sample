import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, AlertTriangle, Globe2, Server } from 'lucide-react';
import { fetchCredentialTab, fetchIdentityTab } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative } from '../../lib/format';
import { identityTypeLabel, regionLabel, tokenLabel } from '../../lib/labels';
import { BarChart } from '../../charts/BarChart';
import { ColumnChart } from '../../charts/ColumnChart';
import { DATE_DAY } from '../../charts/useWidth';
import { DataGrid } from '../../ui/DataGrid';
import { FilterSelect } from '../../ui/FilterBar';
import { Pagination } from '../../ui/Pagination';
import { Panel, PanelHeader } from '../../ui/Panel';
import { ChartSkeleton, ListSkeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { cn } from '../../ui/cn';

const RANGES = [
  { value: '7', label: '7 days' },
  { value: '30', label: '30 days' },
  { value: '90', label: '90 days' },
  { value: 'all', label: 'All' },
];
const PAGE_SIZE = 25;
const DAY = 86_400_000;

/* RFC 1918 and other private ranges; anything else came from the internet. */
function isPrivateIp(ip) {
  return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|169\.254\.|fc|fd|::1)/i.test(String(ip || ''));
}

/**
 * Activity for one identity or credential: `?tab=activity` with time_range
 * (and, for identities, service and paging). Calls per day as columns, with
 * days that saw nothing drawn as gaps so a quiet week is visible; then what
 * it called, from where, and the events themselves. Fields the API leaves
 * empty for this record (credential events carry no source IP, region or
 * agent) are not given columns.
 */
export function ActivityTab({ kind, id }) {
  const [range, setRange] = useState('90');
  const [service, setService] = useState('');
  const [page, setPage] = useState(1);
  const identity = kind === 'identity';
  const query = useQuery(
    (signal) =>
      identity
        ? fetchIdentityTab(id, 'activity', { time_range: range, service, page, page_size: PAGE_SIZE }, signal)
        : fetchCredentialTab(id, 'activity', { time_range: range }, signal),
    [kind, id, range, service, page],
  );
  const data = query.data;
  const a = data?.analytics ?? {};

  const volume = useMemo(() => fillDays(data?.volume_chart ?? [], range), [data, range]);
  const totalCalls = volume.reduce((sum, d) => sum + d.value, 0);
  const activeDays = volume.filter((d) => d.value > 0).length;
  const errorsKnown = Number(a.error_rate_pct) > 0 || Number(a.access_denied_rate_pct) > 0 || (data?.error_events ?? []).length > 0;
  const events = data?.recent_events ?? [];
  const paging = data?.events_pagination;
  const services = (a.top_services ?? []).map((s) => ({ value: s.service, label: tokenLabel(s.service) }));

  const changeRange = (next) => {
    setRange(next);
    setPage(1);
  };

  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Activity could not be loaded" /></Panel>;

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <PanelHeader
          icon={Activity}
          title="Calls per day"
          subtitle={
            data
              ? totalCalls
                ? `${formatNumber(totalCalls)} calls on ${activeDays} of ${volume.length} days${a.usage_pattern ? ` · ${a.usage_pattern.toLowerCase()} use` : ''}.`
                : 'No calls recorded in this period.'
              : 'Loading…'
          }
          actions={
            <div className="flex flex-wrap items-center gap-2">
              {identity && services.length > 0 && (
                <FilterSelect label="Service" value={service} options={services} onChange={(value) => { setService(value); setPage(1); }} />
              )}
              <SegmentedControl label="Period" value={range} onChange={changeRange} options={RANGES} />
            </div>
          }
        />
        <div className="mt-4">
          {!data ? (
            <ChartSkeleton height={170} />
          ) : volume.length === 0 || totalCalls === 0 ? (
            <EmptyState compact icon={Activity} title="No activity in this period" description="AWS recorded no calls for this record in the chosen window. Try a longer period." />
          ) : (
            <ColumnChart
              items={volume.map((d) => ({ key: d.date, label: DATE_DAY.format(new Date(`${d.date}T00:00:00Z`)), value: d.value }))}
              height={170}
              unit="calls"
              title="Calls per day"
            />
          )}
        </div>
        {data && (identity ? Number.isFinite(a.error_rate_pct) : a.error_rate_pct !== null && a.error_rate_pct !== undefined) && (
          <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-3 @min-[40rem]:grid-cols-4">
            {/* The API records no call errors today (it reports 0 or null), so a
                0% would read as a clean record. It is shown only when it says something. */}
            <Stat label="Error rate" value={errorsKnown ? `${a.error_rate_pct ?? 0}%` : 'Not recorded'} tone={errorsKnown ? undefined : 'text-ink-3'} />
            {identity && (
              <Stat
                label="Access denied"
                value={errorsKnown ? `${a.access_denied_rate_pct ?? 0}%` : 'Not recorded'}
                tone={!errorsKnown ? 'text-ink-3' : a.access_denied_rate_pct > 0 ? 'text-high' : undefined}
              />
            )}
            {a.usage_pattern && <Stat label="Pattern" value={a.usage_pattern} />}
            {identity && a.peak_hours?.length > 0 && <Stat label="Busiest hours (UTC)" value={a.peak_hours.slice(0, 3).map((h) => `${String(h.hour).padStart(2, '0')}:00`).join(', ')} />}
          </dl>
        )}
      </Panel>

      <div className={cn('grid gap-4', identity && '@min-[60rem]:grid-cols-2')}>
        <Panel>
          <PanelHeader icon={Server} title="What it calls" subtitle="Calls by AWS service in this period." />
          <div className="mt-3">
            {!data ? <ListSkeleton rows={4} /> : (a.top_services ?? []).length === 0 ? (
              <p className="text-[12.5px] text-ink-3">No calls to show.</p>
            ) : (
              <BarChart items={a.top_services.map((s) => ({ key: s.service, label: tokenLabel(s.service), value: s.count }))} color="var(--t-series-1)" label="Calls by service" />
            )}
            {identity && (a.top_actions ?? []).length > 0 && (
              <>
                <h3 className="mt-4 mb-1 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Top actions</h3>
                <ul className="flex flex-wrap gap-1.5">
                  {a.top_actions.map((act) => (
                    <li key={act.action} className="rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px] text-ink-2">
                      {act.action} <span className="text-ink-3">{formatNumber(act.count)}</span>
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </Panel>

        {/* Identities only: for a credential the API reports its home region with every
            call counted against it, which says nothing about where calls came from. */}
        {identity && (
        <Panel>
          <PanelHeader
            icon={Globe2}
            title="Where it calls from"
            subtitle="From its credentials' usage records over the last 90 days, whatever the period above. Public addresses are flagged."
          />
          <div className="mt-3 flex flex-col gap-4">
            {identity && (
              <section>
                <h3 className="mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Source addresses</h3>
                {!data ? <ListSkeleton rows={3} /> : (a.source_ips ?? []).length === 0 ? (
                  <p className="text-[12.5px] text-ink-3">No source addresses recorded.</p>
                ) : (
                  <ul className="flex flex-col divide-y divide-line">
                    {a.source_ips.map((row) => (
                      <li key={row.ip} className="flex items-center justify-between gap-3 py-1.5">
                        <span className="font-mono text-[12.5px] text-ink">{row.ip}</span>
                        {isPrivateIp(row.ip) ? <Tag size="sm" tone="neutral">Private</Tag> : <Tag size="sm" tone="high" dot>Public internet</Tag>}
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            )}
            <section>
              <h3 className="mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Regions</h3>
              {!data ? <ListSkeleton rows={2} /> : (a.active_regions ?? []).length === 0 ? (
                <p className="text-[12.5px] text-ink-3">No regions recorded.</p>
              ) : (
                <ul className="flex flex-wrap gap-1.5">
                  {a.active_regions.map((r) => (
                    <li key={r.region} className="rounded-md border border-line bg-surface-2 px-2 py-0.5 text-[12px] text-ink-2">
                      {regionLabel(r.region)}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        </Panel>
        )}
      </div>

      {!identity && (data?.identities_using_this_credential ?? []).length > 0 && (
        <Panel>
          <PanelHeader title="Identities using it" subtitle="Identities bound to this credential in the latest scan." />
          <ul className="mt-3 grid gap-2 @min-[40rem]:grid-cols-2 @min-[70rem]:grid-cols-3">
            {data.identities_using_this_credential.map((row) => (
              <li key={row.identity_id}>
                <Link to={`/identities/${encodeURIComponent(row.identity_id)}`} className="block rounded-[var(--radius-control)] border border-line px-3 py-2 hover:bg-surface-2">
                  <span className="block truncate text-[13px] font-medium text-ink">{row.name || row.identity_id}</span>
                  <span className="block truncate text-[11.5px] text-ink-3">{identityTypeLabel(row.identity_type)}</span>
                </Link>
              </li>
            ))}
          </ul>
        </Panel>
      )}

      {/* Keyed by period for credentials, so their in-page paging restarts with new data. */}
      <EventsPanel key={identity ? 'identity' : range} events={events} paging={paging} loading={!data} identity={identity} page={page} onPage={setPage} />

      {identity && (data?.error_events ?? []).length > 0 && (
        <Panel flush className="overflow-hidden">
          <div className="border-b border-line px-4 py-3">
            <h2 className="flex items-center gap-2 text-[14px] font-semibold text-ink">
              <AlertTriangle aria-hidden="true" className="size-4 text-high" />
              Failed calls
            </h2>
            <p className="mt-0.5 text-[12.5px] text-ink-3">Calls AWS refused, newest first. Repeated access-denied errors can mean a probe or a misconfiguration.</p>
          </div>
          <DataGrid
            caption="Failed calls"
            density="compact"
            rows={data.error_events.map((row, index) => ({ ...row, _key: index }))}
            rowKey={(row) => row._key}
            columns={[
              { key: 'event_time', header: 'When', width: '170px', cell: (row) => <span title={formatDateTime(row.event_time)}>{formatRelative(row.event_time)}</span> },
              { key: 'event_name', header: 'Call', primary: true, cell: (row) => <span className="font-mono text-[12px]">{row.service}:{row.event_name}</span> },
              { key: 'error_code', header: 'Error', width: '160px', cell: (row) => <span className="font-semibold text-high">{row.error_code}</span> },
              { key: 'error_message', header: 'Message', priority: 'wide', cell: (row) => <span className="block truncate text-ink-2" title={row.error_message}>{row.error_message}</span> },
            ]}
          />
        </Panel>
      )}
    </div>
  );
}

/** The calls themselves. Columns the API left empty for every row are dropped. */
function EventsPanel({ events, paging, loading, identity, page, onPage }) {
  /* Identities page on the server; the credential API returns its latest 50 at once, paged here. */
  const [localPage, setLocalPage] = useState(1);
  const shown = identity ? events : events.slice((localPage - 1) * PAGE_SIZE, localPage * PAGE_SIZE);
  const has = (field) => events.some((e) => e[field] !== null && e[field] !== undefined && e[field] !== '');
  const columns = [
    { key: 'event_time', header: 'When', width: '160px', cell: (row) => (row.event_time ? <span title={formatDateTime(row.event_time)}>{formatRelative(row.event_time)}</span> : <span className="text-ink-3">-</span>) },
    { key: 'event_name', header: 'Call', primary: true, width: '220px', cell: (row) => <span className="font-mono text-[12px] text-ink">{row.service}:{row.event_name}</span> },
    { key: 'resource_arn', header: 'Resource', cell: (row) => (row.resource_arn ? <span className="block truncate font-mono text-[11.5px] text-ink-2" title={row.resource_arn}>{row.resource_arn}</span> : <span className="text-ink-3">-</span>) },
    has('event_count') && { key: 'event_count', header: 'Calls', width: '80px', cell: (row) => <span data-numeric="">{formatNumber(row.event_count)}</span> },
    has('source_ip') && { key: 'source_ip', header: 'From', width: '130px', priority: 'wide', cell: (row) => <span className="font-mono text-[12px]">{row.source_ip || '-'}</span> },
    has('region') && { key: 'region', header: 'Region', width: '110px', priority: 'wide', cell: (row) => regionLabel(row.region) },
    has('user_agent') && { key: 'user_agent', header: 'Agent', width: '150px', priority: 'xl', cell: (row) => <span className="block truncate text-ink-3" title={row.user_agent}>{row.user_agent || '-'}</span> },
    has('error_code') && { key: 'error_code', header: 'Result', width: '120px', cell: (row) => (row.error_code ? <span className="font-semibold text-high">{row.error_code}</span> : <span className="text-low">OK</span>) },
  ].filter(Boolean);
  const total = paging?.total_count ?? events.length;
  return (
    <Panel flush className="overflow-hidden">
      <div className="border-b border-line px-4 py-3">
        <h2 className="text-[14px] font-semibold text-ink">Recent calls</h2>
        <p className="mt-0.5 text-[12.5px] text-ink-3">
          {loading
            ? 'Loading…'
            : identity
              ? `${formatNumber(total)} entries in this period, newest first. Each entry is the calls of one action on one day.`
              : `The latest ${formatNumber(events.length)} of ${formatNumber(total)} entries in this period, newest first. Each entry is the calls of one action on one day.`}
        </p>
      </div>
      <DataGrid
        caption="Recent calls"
        density="compact"
        loading={loading}
        skeletonRows={6}
        rows={shown.map((row, index) => ({ ...row, _key: index }))}
        rowKey={(row) => row._key}
        columns={columns}
        emptyState={<EmptyState compact title="No calls in this period" description="Choose a longer period to see older activity." />}
      />
      {identity && total > PAGE_SIZE && <Pagination page={page} pageSize={PAGE_SIZE} total={total} pageSizes={[PAGE_SIZE]} unit="entries" onPageChange={onPage} onPageSizeChange={() => {}} />}
      {!identity && events.length > PAGE_SIZE && (
        <Pagination page={localPage} pageSize={PAGE_SIZE} total={events.length} pageSizes={[PAGE_SIZE]} unit="entries" onPageChange={setLocalPage} onPageSizeChange={() => {}} />
      )}
    </Panel>
  );
}

function Stat({ label, value, tone }) {
  return (
    <div className="min-w-0">
      <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{label}</dt>
      <dd className={`truncate text-[14px] font-semibold ${tone ?? 'text-ink'}`}>{value}</dd>
    </div>
  );
}

/**
 * The API lists only days with calls. Every day in the window is drawn, the
 * missing ones as zero, so a week of silence shows as a gap rather than
 * being squeezed out of the chart. "All" spans first to last recorded day.
 */
function fillDays(points, range) {
  const map = new Map(points.map((p) => [String(p.date).slice(0, 10), Number(p.count) || 0]));
  const today = new Date();
  const end = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  const dates = [...map.keys()].sort();
  const first = dates.length ? Date.parse(`${dates[0]}T00:00:00Z`) : null;
  const last = dates.length ? Date.parse(`${dates.at(-1)}T00:00:00Z`) : null;
  if (range === 'all' && first === null) return [];
  /* The API's window can start a day earlier than "N days back" (it counts
     both ends), so the axis starts at whichever is earlier: no day it
     returned is ever dropped. */
  const start = range === 'all' ? first : Math.min(end - (Number(range) - 1) * DAY, first ?? Infinity);
  const stop = Math.max(end, last ?? -Infinity);
  const out = [];
  for (let t = start; t <= stop; t += DAY) {
    const date = new Date(t).toISOString().slice(0, 10);
    out.push({ date, value: map.get(date) ?? 0 });
  }
  return out;
}
