import { useState } from 'react';
import { AlertTriangle, CheckCircle2, ChevronDown, ShieldCheck } from 'lucide-react';
import { Panel } from '../../ui/Panel';
import { TONE_FG, TONE_VAR, cn } from '../../ui/cn';
import { riskChecks, riskFindings } from './riskSignals';

const SEVERITY = { critical: 'Critical', high: 'High', medium: 'Medium' };

/**
 * The first thing on a record: what is wrong with it, worst first, and the
 * next step for each, from the API's own risk signals. The checks that pass
 * are folded underneath (they matter for audit, not for action), so the
 * panel's height is set by the problems, not by the rule book.
 */
export function NeedsAttention({ signals, className }) {
  const [showPassing, setShowPassing] = useState(false);
  const findings = riskFindings(signals);
  const passing = riskChecks(signals).filter((check) => check.result === 'clear');
  const total = findings.length + passing.length;

  return (
    <Panel prominence="lead" aria-label="Needs attention" className={className}>
      <header className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h2 className="flex items-center gap-2 text-[17px] font-bold tracking-[-0.012em] text-ink">
          {findings.length ? (
            <AlertTriangle aria-hidden="true" className={cn('size-[18px]', TONE_FG[findings[0].tone])} />
          ) : (
            <ShieldCheck aria-hidden="true" className="size-[18px] text-low" />
          )}
          {findings.length ? 'Needs attention' : 'No open risks'}
        </h2>
        <p className="text-[12.5px] text-ink-3">
          {findings.length ? `${findings.length} of ${total} checks failing` : total ? `All ${total} checks pass` : 'No checks were reported for this record'}
        </p>
      </header>

      {findings.length > 0 && (
        <ol className="mt-3 flex flex-col divide-y divide-line">
          {findings.map((finding, index) => (
            <li key={finding.key} className="grid grid-cols-[1.5rem_minmax(0,1fr)] gap-x-2 py-3 first:pt-1 last:pb-1 @min-[40rem]:grid-cols-[1.5rem_minmax(0,1fr)_auto]">
              <span data-numeric="" className="pt-px text-[12.5px] font-semibold text-ink-3">
                {index + 1}.
              </span>
              <div className="min-w-0">
                <p className="text-[13.5px] font-semibold text-ink">{finding.label}</p>
                {finding.next && <p className="mt-0.5 text-[12.5px] text-ink-2">{finding.next}</p>}
              </div>
              <span
                className="col-start-2 mt-1.5 inline-flex w-fit items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold @min-[40rem]:col-start-auto @min-[40rem]:mt-0 @min-[40rem]:self-start"
                style={{ color: TONE_VAR[finding.tone], borderColor: `color-mix(in srgb, ${TONE_VAR[finding.tone]} 35%, transparent)` }}
              >
                <span aria-hidden="true" className="size-1.5 rounded-full" style={{ background: TONE_VAR[finding.tone] }} />
                {SEVERITY[finding.tone]}
              </span>
            </li>
          ))}
        </ol>
      )}

      {passing.length > 0 && (
        <div className={cn(findings.length ? 'mt-3 border-t border-line pt-3' : 'mt-3')}>
          <button
            type="button"
            aria-expanded={showPassing}
            onClick={() => setShowPassing((open) => !open)}
            className="flex items-center gap-1.5 text-[12.5px] font-medium text-ink-2 hover:text-ink"
          >
            <CheckCircle2 aria-hidden="true" className="size-4 text-low" />
            {passing.length} check{passing.length === 1 ? '' : 's'} pass
            <ChevronDown aria-hidden="true" className={cn('size-3.5 transition-transform', showPassing && 'rotate-180')} />
          </button>
          {showPassing && (
            <ul className="mt-2 grid gap-x-6 gap-y-1 @min-[36rem]:grid-cols-2">
              {passing.map((check) => (
                <li key={check.key} className="flex items-center gap-2 text-[12.5px] text-ink-2">
                  <CheckCircle2 aria-hidden="true" className="size-3.5 shrink-0 text-low" />
                  {check.label}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Panel>
  );
}
