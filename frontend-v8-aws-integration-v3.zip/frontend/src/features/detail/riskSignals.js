/**
 * The detail endpoints return their own risk signals:
 *   [{ signal: "Publicly accessible", status: true, severity: "critical" }]
 * `status: true` means the signal fires. These helpers turn them into the
 * verdict (what is wrong, worst first, and what to do) and the full
 * checklist. The API's wording is kept as the label; the next step is the
 * console's advice for that signal, and an unknown signal simply has none.
 */
const NEXT_STEP = {
  /* identity */
  'Publicly accessible': 'Confirm it must be public; if not, close its endpoint or tighten its security groups.',
  'Stale (no activity > 90d)': 'Confirm with the owner, then remove it if it is no longer needed.',
  'No owner attribution': 'Add an Owner tag so someone is answerable for it.',
  'Credential never rotated': 'Rotate the credentials it uses, and turn on automatic rotation where the type allows.',
  'Credential expired/expiring': 'Renew the credential before this workload breaks, or retire both if unused.',
  'Cross-account trust': 'Check each trusted account still needs access, and require an external ID.',
  'Wildcard resource scope': 'Replace * resources in its policies with the resources it actually uses.',
  'No VPC': 'Run it inside a VPC so network controls apply to it.',
  /* credential */
  'Orphaned (no identity bound)': 'Confirm nothing outside AWS uses it, then retire it.',
  'Overshared (3+ identities)': 'Give each workload its own credential, so one leak reaches less.',
  'Never rotated': 'Rotate it, and turn on automatic rotation where the type allows.',
  'Rotation overdue': 'Rotate it now; its rotation schedule has lapsed.',
  'Expiring soon (< 30 days)': 'Renew it before it lapses, or let it lapse if nothing needs it.',
  'Already expired': 'Renew it, or remove it if nothing depends on it.',
  'Stale (unused > 90 days)': 'Confirm with the owner, then disable it.',
  'External trust (cross-account)': 'Check the other account still needs to assume it, and require an external ID.',
  'Wildcard trust (Principal: *)': 'Restrict the trust policy to named principals.',
  'No condition on trust policy': 'Add conditions (external ID, source account or MFA) to the trust policy.',
  'No permission boundary': 'Attach a permission boundary to cap what it can ever be granted.',
  'Wildcard resource in policies': 'Scope its policies to named resources instead of *.',
};

const WEIGHT = { critical: 4, high: 3, medium: 2, low: 1 };
/* Green means clear on this console; a firing signal is never green. */
const TONE = { critical: 'critical', high: 'high', medium: 'medium', low: 'medium' };

const valid = (list) => (Array.isArray(list) ? list.filter((s) => s && typeof s.signal === 'string') : []);
const severity = (s) => String(s.severity || '').toLowerCase();

/** Firing signals as verdict findings, worst first. */
export function riskFindings(list) {
  return valid(list)
    .filter((s) => s.status === true)
    .sort((a, b) => (WEIGHT[severity(b)] ?? 0) - (WEIGHT[severity(a)] ?? 0))
    .map((s) => ({ key: s.signal, tone: TONE[severity(s)] ?? 'medium', label: s.signal, next: NEXT_STEP[s.signal] ?? null }));
}

/** Every signal the API checked, as a checklist (failing first). */
export function riskChecks(list) {
  return valid(list).map((s) => ({
    key: s.signal,
    label: s.signal,
    result: s.status === true ? 'failing' : 'clear',
    severity: TONE[severity(s)] ?? 'medium',
    next: s.status === true ? NEXT_STEP[s.signal] : undefined,
  }));
}

/** Firing signals as chips for a list preview: { key, label, tone }. */
export function riskChips(list) {
  return riskFindings(list).map(({ key, label, tone }) => ({ key, label, tone }));
}

/** The worst severity among firing signals ('critical' | 'high' | 'medium'), or null when none fires. */
export function worstTone(list) {
  return riskFindings(list)[0]?.tone ?? null;
}

const RISK_LABEL = { critical: 'Critical risk', high: 'High risk', medium: 'Medium risk' };

/** The record's overall risk, named for its worst open signal. */
export function riskLevel(list) {
  const tone = worstTone(list);
  return tone ? { tone, label: RISK_LABEL[tone] } : { tone: 'low', label: 'No open risks' };
}
