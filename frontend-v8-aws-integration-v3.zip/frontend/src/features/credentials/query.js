/**
 * The credential list's URL state, read and validated against the rules
 * `GET /api/v1/credentials` enforces, under the API's own parameter names.
 * A hand-edited link with a value the API would reject is dropped here.
 */

/* sort_by values the API accepts (CredentialsListSortColumnAllowed). */
export const SORTABLE = [
  'name',
  'credential_type',
  'status',
  'last_used_at',
  'last_rotated_at',
  'age_days',
  'idle_days',
  'days_until_expiry',
  'bound_identities_count',
];

export const PAGE_SIZES = [25, 50, 100];
export const DEFAULT_LIMIT = 25;
/* Name order: predictable, and the API sorts empty dates first when descending. */
export const DEFAULT_SORT = { key: 'name', direction: 'asc' };

const TOKEN = /^[a-zA-Z0-9_.:-]{1,100}$/;
const BOOL = ['true', 'false'];

function cleanText(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  return text.length > 512 || /[\0\r\n]/.test(text) ? '' : text;
}

function positiveInt(value, fallback, max) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1 && n <= max ? n : fallback;
}

function intText(value, min, max) {
  if (value === '') return '';
  const n = Number(value);
  return Number.isInteger(n) && n >= min && n <= max ? String(n) : '';
}

export const MULTI_KEYS = ['credential_type', 'status'];
export const BOOL_KEYS = ['is_orphaned', 'rotation_enabled', 'rotation_overdue', 'has_external_trust'];

/** Every filter the screen supports, as it appears in the URL and the API. */
export const FILTER_KEYS = ['search', ...MULTI_KEYS, ...BOOL_KEYS, 'min_idle_days', 'max_days_until_expiry', 'owner_principal_arn'];

export function splitList(value) {
  return cleanText(value)
    .split(',')
    .map((part) => part.trim())
    .filter((part) => TOKEN.test(part));
}

export function readListState(searchParams) {
  const get = (key) => cleanText(searchParams.get(key) ?? '');
  const owner = get('owner_principal_arn');
  const filters = {
    search: get('search').slice(0, 256),
    credential_type: splitList(get('credential_type')),
    status: splitList(get('status')),
    ...Object.fromEntries(BOOL_KEYS.map((key) => [key, BOOL.includes(get(key)) ? get(key) : ''])),
    min_idle_days: intText(get('min_idle_days'), 0, 36500),
    max_days_until_expiry: intText(get('max_days_until_expiry'), -36500, 36500),
    owner_principal_arn: owner.startsWith('arn:') ? owner : '',
  };
  const sortBy = SORTABLE.includes(get('sort_by')) ? get('sort_by') : DEFAULT_SORT.key;
  const sortOrder = get('sort_order') === 'asc' ? 'asc' : get('sort_order') === 'desc' ? 'desc' : DEFAULT_SORT.direction;
  return {
    filters,
    page: positiveInt(get('page'), 1, 1_000_000),
    limit: PAGE_SIZES.includes(Number(get('page_size'))) ? Number(get('page_size')) : DEFAULT_LIMIT,
    sort: { key: sortBy, direction: sortOrder },
  };
}

export function appliedCount(filters) {
  return FILTER_KEYS.filter((key) => (Array.isArray(filters[key]) ? filters[key].length > 0 : Boolean(filters[key]))).length;
}
