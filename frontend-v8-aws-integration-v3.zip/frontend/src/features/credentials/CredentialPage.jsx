import { useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowLeft, Braces, CalendarClock, FileLock2, KeyRound, Network, RefreshCw, ShieldCheck, Users } from 'lucide-react';
import { fetchCredentialTab, isUuid } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatDate, formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import { classColor, credentialBadge, credentialTypeLabel, identityBadge, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { DataGrid } from '../../ui/DataGrid';
import { KeyDates } from '../../ui/KeyDates';
import { DetailList, DetailRow, Panel, PanelHeader } from '../../ui/Panel';
import { PropertyList } from '../../ui/PropertyList';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { SummaryStrip } from '../../ui/SummaryStrip';
import { Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { TypeBadge } from '../../ui/TypeBadge';
import { cn } from '../../ui/cn';
import { Unbroken } from '../../ui/Unbroken';
import { ActivityTab } from '../detail/ActivityTab';
import { NeedsAttention } from '../detail/NeedsAttention';
import { RawTab } from '../detail/RawTab';
import { RelationshipsTab } from '../detail/RelationshipsTab';
import { riskLevel } from '../detail/riskSignals';
import { AttributeList, JsonBlock, hasAttributes } from '../identities/JsonView';


const TABS = [
  { value: 'overview', label: 'Overview', icon: KeyRound },
  { value: 'trust', label: 'Trust and policies', icon: FileLock2 },
  { value: 'activity', label: 'Activity', icon: Activity },
  { value: 'rotation', label: 'Rotation', icon: RefreshCw },
  { value: 'relationships', label: 'Relationships', icon: Network },
  { value: 'raw', label: 'Raw record', icon: Braces },
];

/**
 * One credential: `GET /api/v1/credentials/{id}?tab=`, one request per tab.
 * The overview loads with the page (the header needs it); the other tabs load
 * when opened. The tab is kept in the URL so a link lands on the right part.
 *
 * Read top-down: what it is and how risky (header and summary), what is
 * wrong and what to do (needs attention), who would be exposed if it leaked
 * (held by), then its dates and the reference material in the sidebar.
 */
export default function CredentialPage() {
  const { id } = useParams();
  const validId = isUuid(id);
  const [searchParams, setSearchParams] = useSearchParams();
  const requested = searchParams.get('tab') || 'overview';
  const tab = TABS.some((entry) => entry.value === requested) ? requested : 'overview';

  const overview = useQuery((signal) => fetchCredentialTab(id, 'overview', {}, signal), [id], { enabled: validId });
  const data = overview.data;
  const credential = data?.credential;

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/credentials" icon={ArrowLeft}>
      Credentials
    </Button>
  );

  if (!validId || (overview.isError && !data)) {
    const missing = !validId || overview.error?.status === 404;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Credential" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={KeyRound}
              title="No credential with that id"
              description="It is not in the latest completed scan, or the link is incomplete. Find it again from Credentials."
              action={back}
            />
          ) : (
            <ErrorState error={overview.error} onRetry={overview.refetch} title="This credential could not be loaded" />
          )}
        </Panel>
      </div>
    );
  }

  if (!credential) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} meta={<Skeleton className="h-11 w-full max-w-3xl rounded" />} />
        <div className="grid gap-4 @min-[64rem]:grid-cols-[minmax(0,1fr)_22rem]">
          <Panel prominence="lead">
            <DetailSkeleton rows={6} />
          </Panel>
          <Panel>
            <DetailSkeleton rows={6} />
          </Panel>
        </div>
        <span role="status" className="sr-only">
          Loading credential
        </span>
      </div>
    );
  }

  const status = statusMeta(credential.status);
  const badge = credentialBadge(credential.credential_type);
  const bound = data.bound_identities ?? [];
  const risk = riskLevel(data.risk_signals);
  const rotation = rotationText(credential);
  const expiry = expiryText(credential);

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title={
            <span className="flex min-w-0 items-center gap-3">
              <TypeBadge size="lg" code={badge.code} color={badge.color} title={credentialTypeLabel(credential.credential_type)} />
              <span className="min-w-0">
                <span className="block truncate font-mono">{credential.name || credential.arn}</span>
                <span className="mt-0.5 block text-[12.5px] font-medium tracking-normal text-ink-3">
                  <Unbroken text={`${credentialTypeLabel(credential.credential_type)} · account ${credential.account_id} · ${regionLabel(credential.region)}`} />
                </span>
              </span>
            </span>
          }
          actions={back}
          meta={
            <div className="flex flex-col gap-4">
              <div className="flex flex-wrap items-center gap-2">
                <Tag tone={status.tone} dot>
                  {status.label}
                </Tag>
                {credential.arn && (
                  <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
                    <CopyableValue value={credential.arn} />
                  </span>
                )}
              </div>
              <SummaryStrip
                items={[
                  { key: 'risk', label: 'Risk', value: risk.label, tone: risk.tone },
                  {
                    key: 'held',
                    label: 'Held by',
                    value: bound.length ? `${bound.length} identit${bound.length === 1 ? 'y' : 'ies'}` : 'No identity',
                    tone: bound.length === 0 ? 'high' : undefined,
                    sub: bound.length === 0 ? 'Orphaned' : bound.length >= 3 ? 'Shared widely' : undefined,
                  },
                  {
                    key: 'used',
                    label: 'Last used',
                    value: credential.last_used_at ? formatRelative(credential.last_used_at) : 'No use recorded',
                    tone: credential.idle_days >= 90 ? 'high' : undefined,
                    sub: credential.last_used_at ? formatDate(credential.last_used_at) : undefined,
                  },
                  { key: 'rotation', label: 'Rotation', value: rotation.value, tone: rotation.tone, sub: rotation.short },
                  { key: 'expiry', label: 'Expires', value: expiry.value, tone: expiry.tone, sub: expiry.sub },
                ]}
              />
            </div>
          }
          tabs={<Tabs size="sm" tabs={TABS} value={tab} onChange={setTab} />}
        />
      </Reveal>

      <Reveal key={tab}>
        {tab === 'overview' && <OverviewTab data={data} onOpen={setTab} />}
        {tab === 'trust' && <TrustTab id={id} />}
        {tab === 'activity' && <ActivityTab kind="credential" id={id} />}
        {tab === 'rotation' && <RotationTab id={id} />}
        {tab === 'relationships' && <RelationshipsTab kind="credential" id={id} name={credential.name || credential.arn} />}
        {tab === 'raw' && <RawTab kind="credential" id={id} />}
      </Reveal>
    </Page>
  );
}

function rotationText(c) {
  if (!c.last_rotated_at) return { value: 'Never rotated', tone: 'high', short: c.rotation_enabled ? 'Automatic, not yet run' : 'Rotation off' };
  return {
    value: c.rotation_status === 'Overdue' ? 'Overdue' : `${formatNumber(c.days_since_rotation)} days ago`,
    tone: c.rotation_status === 'Overdue' ? 'high' : undefined,
    short: c.rotation_enabled ? `Automatic${c.rotation_interval_days ? `, every ${c.rotation_interval_days} days` : ''}` : 'Rotation off',
  };
}

function expiryText(c) {
  const days = c.days_until_expiry;
  if (!c.expires_at && String(c.status).toLowerCase() === 'expired') return { value: 'Expired', tone: 'critical', sub: 'No expiry date recorded' };
  if (!c.expires_at) return { value: 'Does not expire', sub: c.max_session_duration ? `Sessions last up to ${duration(c.max_session_duration)}` : undefined };
  if (days !== null && days !== undefined && days < 0) return { value: `Expired ${formatRelative(c.expires_at)}`, tone: 'critical', sub: formatDate(c.expires_at) };
  return { value: `In ${formatNumber(days)} day${days === 1 ? '' : 's'}`, tone: days <= 30 ? 'critical' : days <= 90 ? 'high' : undefined, sub: formatDate(c.expires_at) };
}

function duration(seconds) {
  const s = Number(seconds);
  if (!Number.isFinite(s) || s <= 0) return '-';
  const hours = Math.floor(s / 3600);
  const minutes = Math.round((s % 3600) / 60);
  if (hours && minutes) return `${hours} h ${minutes} min`;
  if (hours) return `${hours} hour${hours === 1 ? '' : 's'}`;
  return `${minutes} min`;
}

/* ── Overview ────────────────────────────────────────────────────────────── */

function OverviewTab({ data, onOpen }) {
  const c = data.credential;
  const [now] = useState(() => Date.now());
  const bound = data.bound_identities ?? [];
  const expired = String(c.status).toLowerCase() === 'expired' || (c.days_until_expiry !== null && c.days_until_expiry !== undefined && c.days_until_expiry < 0);

  return (
    <div className="grid items-start gap-4 @min-[64rem]:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="flex min-w-0 flex-col gap-4">
        {/* 1. What is wrong, worst first, with the next step for each. */}
        <NeedsAttention signals={data.risk_signals} />

        {/* 2. Who would be exposed if it leaked. */}
        <Panel flush className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[14.5px] font-semibold text-ink">Held by</h2>
              <p className="mt-0.5 text-[12.5px] text-ink-3">
                {bound.length
                  ? 'The identities that authenticate with it. Each one is exposed if it leaks.'
                  : 'No identity uses it in the latest scan. Confirm nothing outside AWS does, then retire it.'}
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => onOpen('trust')}>
              What it can do
            </Button>
          </div>
          <DataGrid
            caption="Identities holding this credential"
            density="compact"
            rows={bound}
            rowKey={(row) => `${row.identity_id}-${row.binding_type}`}
            columns={[
              {
                key: 'name',
                header: 'Identity',
                primary: true,
                cell: (row) => (
                  <Link to={`/identities/${encodeURIComponent(row.identity_id)}`} className="flex min-w-0 items-center gap-2.5 hover:underline">
                    <TypeBadge code={identityBadge(row.identity_type)} color={classColor()} />
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-ink">{row.name || row.identity_id}</span>
                      <span className="block truncate text-[11px] text-ink-3">{identityTypeLabel(row.identity_type)}</span>
                    </span>
                  </Link>
                ),
              },
              { key: 'binding_type', header: 'How it holds it', width: '160px', priority: 'wide', cell: (row) => <span className="text-ink-2">{tokenLabel(row.binding_type)}</span> },
              { key: 'account_id', header: 'Account', width: '130px', priority: 'xl', cell: (row) => <span className="font-mono text-[12px] text-ink-2">{row.account_id}</span> },
              {
                key: 'last_activity_at',
                header: 'Last active',
                width: '140px',
                cell: (row) =>
                  row.last_activity_at ? (
                    <span className="text-ink-2" title={formatDateTime(row.last_activity_at)}>
                      {formatRelative(row.last_activity_at)}
                    </span>
                  ) : (
                    <span className="text-ink-3">No activity</span>
                  ),
              },
              {
                key: 'status',
                header: 'Status',
                width: '110px',
                cell: (row) => {
                  const meta = statusMeta(row.status);
                  return (
                    <Tag size="sm" tone={meta.tone} dot>
                      {meta.label}
                    </Tag>
                  );
                },
              },
            ]}
            emptyState={<EmptyState compact icon={Users} title="Held by no identity" description="Orphaned: nothing in the inventory authenticates with it." />}
          />
        </Panel>

        {/* 3. Settings AWS reports for this kind of credential, when it reports any. */}
        {hasAttributes(data.type_attributes) && (
          <Panel>
            <PanelHeader title={`${credentialTypeLabel(c.credential_type)} settings`} subtitle="Fields AWS reports for this kind of credential." />
            <div className="mt-3">
              <AttributeList value={data.type_attributes} />
            </div>
          </Panel>
        )}
      </div>

      {/* Reference: the sidebar. */}
      <aside className="flex min-w-0 flex-col gap-4" aria-label="Credential details">
        <Panel>
          <PanelHeader title="Details" />
          <PropertyList
            className="mt-2"
            rows={[
              { key: 'type', label: 'Type', value: credentialTypeLabel(c.credential_type) },
              { key: 'category', label: 'Category', value: c.category },
              { key: 'account', label: 'Account', value: c.account_id, mono: true },
              { key: 'region', label: 'Region', value: regionLabel(c.region) },
              { key: 'owner', label: 'Owner principal', value: c.owner_principal_arn ? <CopyableValue value={c.owner_principal_arn} /> : null },
              { key: 'boundary', label: 'Permission boundary', value: c.permission_boundary_arn ? <CopyableValue value={c.permission_boundary_arn} /> : 'None', tone: c.permission_boundary_arn ? undefined : 'medium' },
              { key: 'session', label: 'Max session', value: c.max_session_duration ? duration(c.max_session_duration) : null },
              { key: 'rotation', label: 'Rotation', value: c.rotation_enabled ? `Automatic${c.rotation_interval_days ? `, every ${c.rotation_interval_days} days` : ''}` : 'Off' },
              { key: 'age', label: 'Age', value: c.age_days !== null && c.age_days !== undefined ? `${formatNumber(c.age_days)} days` : null },
              hasAttributes(data.type_attributes) ? null : { key: 'settings', label: 'Type settings', value: 'None reported' },
              { key: 'id', label: 'ID', value: <CopyableValue value={c.id} />, mono: true },
            ]}
          />
        </Panel>
        <Panel>
          <PanelHeader icon={CalendarClock} title="Key dates" />
          <KeyDates
            className="mt-3"
            now={now}
            dates={[
              { key: 'created', label: 'Created in AWS', at: c.created_at_aws },
              { key: 'rotated', label: 'Last rotated', at: c.last_rotated_at, tone: c.rotation_status === 'Overdue' ? 'high' : undefined },
              { key: 'used', label: 'Last used', at: c.last_used_at, tone: c.idle_days >= 90 ? 'high' : undefined },
              ...(c.expires_at ? [{ key: 'expires', label: expired ? 'Expired' : 'Expires', at: c.expires_at, tone: expired || c.days_until_expiry <= 30 ? 'critical' : undefined }] : []),
            ]}
          />
        </Panel>
      </aside>
    </div>
  );
}

/* ── Trust and policies ──────────────────────────────────────────────────── */

const SECTION = 'mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase';

/**
 * `?tab=trust`: who may use it (the trust policy, with what the API warns
 * about), what it can do (effective permissions by service), and where that
 * comes from (attached and inline policies, the permission boundary).
 */
function TrustTab({ id }) {
  const query = useQuery((signal) => fetchCredentialTab(id, 'trust', {}, signal), [id]);
  const data = query.data;
  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Trust and policies could not be loaded" /></Panel>;
  if (!data) return <Panel><DetailSkeleton rows={8} /></Panel>;

  const trust = data.trust_policy ?? {};
  const principals = Array.isArray(trust.principals) ? trust.principals : [];
  const warnings = Array.isArray(trust.warnings) ? trust.warnings : [];
  const boundary = data.permission_boundary ?? {};
  const blocked = Array.isArray(boundary.actions_blocked) ? boundary.actions_blocked : [];
  const assumable = Array.isArray(data.assumable_roles) ? data.assumable_roles : [];
  const hasTrustDoc = trust.raw && typeof trust.raw === 'object' && Object.keys(trust.raw).length > 0;

  return (
    <div className="flex flex-col gap-4">
      {warnings.length > 0 && (
        <Panel>
          <PanelHeader icon={AlertTriangle} title="Trust policy warnings" subtitle="What the API found wrong with who may use it." />
          <ul className="mt-3 flex flex-col gap-1.5">
            {warnings.map((w) => (
              <li key={w} className="flex items-start gap-2 text-[13px] text-ink">
                <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-high" />
                <span className="min-w-0 break-words">{w}</span>
              </li>
            ))}
          </ul>
        </Panel>
      )}

      <div className="grid gap-4 @min-[60rem]:grid-cols-2">
        <Panel>
          <PanelHeader icon={Users} title="Who may use it" subtitle="Principals its trust policy allows, and the condition on each." />
          <div className="mt-3">
            {principals.length === 0 ? (
              <p className="text-[12.5px] text-ink-3">{hasTrustDoc ? 'The trust policy names no principal.' : 'No trust policy. Only the identities holding it use it.'}</p>
            ) : (
              <ul className="flex flex-col divide-y divide-line">
                {principals.map((p, index) => (
                  <li key={`${p.type}-${p.principal}-${index}`} className="flex items-center justify-between gap-3 py-2">
                    <span className="min-w-0">
                      <span className="block truncate font-mono text-[12px] text-ink" title={p.principal}>
                        {p.principal}
                      </span>
                      <span className="block text-[11px] text-ink-3">
                        {p.type}
                        {p.condition ? ` · if ${p.condition}` : ' · no condition'}
                      </span>
                    </span>
                    <span className="flex shrink-0 gap-1.5">
                      {p.principal === '*' && (
                        <Tag size="sm" tone="critical" dot>
                          Anyone
                        </Tag>
                      )}
                      {p.is_external && (
                        <Tag size="sm" tone="medium" dot>
                          Other account
                        </Tag>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            {assumable.length > 0 && (
              <>
                <h3 className={`mt-4 ${SECTION}`}>Roles it can assume</h3>
                <ul className="flex flex-col gap-1">
                  {assumable.map((r, index) => {
                    const arn = typeof r === 'string' ? r : r.target_role_arn ?? r.arn ?? JSON.stringify(r);
                    return (
                      <li key={`${arn}-${index}`} className="truncate font-mono text-[12px] text-ink-2" title={arn}>
                        {arn}
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>
        </Panel>
        <Panel>
          <PanelHeader icon={ShieldCheck} title="Permission boundary" subtitle="The ceiling on what it can ever be granted." />
          <div className="mt-3">
            {boundary.boundary_arn ? (
              <DetailList>
                <DetailRow label="Boundary" mono>
                  <CopyableValue value={boundary.boundary_arn} />
                </DetailRow>
                <DetailRow label="Restriction">{boundary.effective_restriction || <span className="text-ink-3">Not recorded (only the boundary ARN is stored)</span>}</DetailRow>
                <DetailRow label="Actions blocked">{blocked.length ? blocked.join(', ') : <span className="text-ink-3">None recorded</span>}</DetailRow>
              </DetailList>
            ) : (
              <p className="flex items-start gap-2 text-[12.5px] text-ink-2">
                <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-medium" />
                No permission boundary. Its policies alone decide what it can do.
              </p>
            )}
          </div>
        </Panel>
      </div>

      <EffectivePermissions rows={data.effective_permissions_summary} />

      <Policies attached={data.attached_policies} inline={data.inline_policies} />

      {hasTrustDoc && (
        <Panel prominence="quiet">
          <PanelHeader title="Trust policy document" prominence="quiet" />
          <div className="mt-3">
            <JsonBlock value={trust.raw} copyLabel="Copy trust policy" />
          </div>
        </Panel>
      )}
    </div>
  );
}

/** Actions allowed per service, longest first, with the resource scope; `*` is flagged. */
function EffectivePermissions({ rows }) {
  const list = useMemo(() => (Array.isArray(rows) ? [...rows].sort((a, b) => b.allowed_actions - a.allowed_actions || a.service.localeCompare(b.service)) : []), [rows]);
  const max = Math.max(1, ...list.map((r) => r.allowed_actions + r.denied_actions));
  const allowed = list.reduce((s, r) => s + r.allowed_actions, 0);
  const wildcard = list.filter((r) => r.resource_scope === '*').length;
  return (
    <Panel>
      <PanelHeader
        icon={ShieldCheck}
        title="What it can do"
        subtitle={
          list.length
            ? `${formatNumber(allowed)} allowed action${allowed === 1 ? '' : 's'} across ${list.length} service${list.length === 1 ? '' : 's'}${wildcard ? `; ${wildcard} on every resource (*)` : ''}.`
            : 'Effective permissions from its policies, by service.'
        }
      />
      {list.length === 0 ? (
        <p className="mt-3 text-[12.5px] text-ink-3">No permissions recorded for this credential.</p>
      ) : (
        <>
          <ul className="mt-4 flex flex-col gap-2.5">
            {list.map((r) => (
              <li key={r.service} className="grid grid-cols-[7.5rem_minmax(0,1fr)] items-center gap-x-3 gap-y-0.5 @min-[44rem]:grid-cols-[9rem_minmax(0,1fr)_minmax(0,16rem)]">
                <span className="truncate text-[12.5px] font-medium text-ink">{tokenLabel(r.service)}</span>
                <span className="flex items-center gap-2">
                  <span aria-hidden="true" className="flex h-2 overflow-hidden rounded-full" style={{ width: `${((r.allowed_actions + r.denied_actions) / max) * 100}%`, minWidth: 6 }}>
                    <span className="h-full" style={{ flex: r.allowed_actions, background: 'var(--t-series-1)' }} />
                    {r.denied_actions > 0 && <span className="h-full border-l-2 border-surface" style={{ flex: r.denied_actions, background: 'var(--t-ink-3)' }} />}
                  </span>
                  <span data-numeric="" className="shrink-0 text-[12px] text-ink-2">
                    {r.allowed_actions}
                    {r.denied_actions > 0 && <span className="text-ink-3"> · {r.denied_actions} denied</span>}
                  </span>
                </span>
                <span
                  className={cn(
                    'col-start-2 truncate text-[11.5px] @min-[44rem]:col-start-auto',
                    r.resource_scope === 'Multiple' ? 'text-ink-3' : 'font-mono',
                    r.resource_scope === '*' ? 'font-semibold text-high' : 'text-ink-3',
                  )}
                  title={r.resource_scope}
                >
                  {r.resource_scope === '*' ? '* (every resource)' : r.resource_scope === 'Multiple' ? 'Several resources' : r.resource_scope}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11.5px] text-ink-3">
            <span className="flex items-center gap-1.5">
              <span aria-hidden="true" className="size-2 rounded-full bg-[var(--t-series-1)]" />
              Allowed actions
            </span>
            <span className="flex items-center gap-1.5">
              <span aria-hidden="true" className="size-2 rounded-full bg-[var(--t-ink-3)]" />
              Denied actions
            </span>
          </p>
        </>
      )}
    </Panel>
  );
}

function Policies({ attached, inline }) {
  const [open, setOpen] = useState(null);
  const managed = Array.isArray(attached) ? attached : [];
  const inlineList = Array.isArray(inline) ? inline : [];
  return (
    <Panel>
      <PanelHeader icon={FileLock2} title="Policies" subtitle={`${managed.length} attached, ${inlineList.length} inline.`} />
      {managed.length === 0 && inlineList.length === 0 ? (
        <p className="mt-3 text-[12.5px] text-ink-3">No policies attached.</p>
      ) : (
        <ul className="mt-2 flex flex-col divide-y divide-line">
          {managed.map((p) => {
            const key = p.arn ?? p.name;
            return (
              <li key={key} className="py-2">
                <div className="flex items-center justify-between gap-3">
                  <span className="min-w-0">
                    <span className="block truncate text-[13px] font-medium text-ink">{p.name}</span>
                    {p.arn && <span className="block truncate font-mono text-[11px] text-ink-3">{p.arn}</span>}
                  </span>
                  {p.document ? (
                    <Button variant="ghost" size="sm" aria-expanded={open === key} onClick={() => setOpen(open === key ? null : key)}>
                      {open === key ? 'Hide document' : 'Show document'}
                    </Button>
                  ) : (
                    <span className="shrink-0 text-[11.5px] text-ink-3">No document stored</span>
                  )}
                </div>
                {open === key && p.document && (
                  <div className="mt-2">
                    <JsonBlock value={p.document} compact copyLabel={`Copy ${p.name}`} />
                  </div>
                )}
              </li>
            );
          })}
          {inlineList.map((p, index) => {
            const name = typeof p === 'string' ? p : p.name ?? JSON.stringify(p);
            return (
              <li key={`inline-${name}-${index}`} className="flex items-center justify-between gap-3 py-2 text-[13px]">
                <span className="min-w-0 truncate text-ink">{name}</span>
                <Tag size="sm">Inline</Tag>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ── Rotation ────────────────────────────────────────────────────────────── */

const ROTATION_TONE = { Enabled: 'low', Overdue: 'high', Disabled: 'medium' };

/**
 * `?tab=rotation`: whether it rotates, how far through its interval it is,
 * and the dated events (creation, last rotation, the next one due, expiry).
 */
function RotationTab({ id }) {
  const query = useQuery((signal) => fetchCredentialTab(id, 'rotation', {}, signal), [id]);
  const data = query.data;
  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Rotation could not be loaded" /></Panel>;
  if (!data) {
    return (
      <Panel>
        <ListSkeleton rows={5} />
      </Panel>
    );
  }
  const config = data.configuration ?? {};
  const life = data.lifecycle ?? {};
  const interval = config.rotation_interval_days;
  const since = life.days_since_rotation;
  const neverRotated = !config.last_rotation;
  const pct = interval && since !== null && since !== undefined ? Math.min(100, (since / interval) * 100) : null;
  const statusTone = ROTATION_TONE[config.status] ?? 'neutral';

  const events = [
    ...(Array.isArray(data.timeline) ? data.timeline : []).map((e) => ({ ...e, past: true })),
    ...(config.next_expected ? [{ date: config.next_expected, event: 'Next rotation due', details: `Every ${interval} days`, past: false }] : []),
    ...(life.expires_at ? [{ date: life.expires_at, event: life.days_until_expiry < 0 ? 'Expired' : 'Expires', details: life.days_until_expiry < 0 ? 'No longer valid' : 'Stops working unless renewed', past: life.days_until_expiry < 0 }] : []),
  ]
    .filter((e) => parseDate(e.date))
    .sort((a, b) => parseDate(a.date) - parseDate(b.date));

  return (
    <div className="flex flex-col gap-4">
      <div className="grid items-start gap-4 @min-[60rem]:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Panel prominence="lead">
          <PanelHeader
            icon={RefreshCw}
            title="Rotation"
            subtitle={
              config.status === 'Overdue'
                ? 'Its schedule has lapsed. Rotate it now.'
                : config.auto_rotation
                  ? 'Rotated automatically on a schedule.'
                  : 'Not rotated automatically. Someone has to remember.'
            }
            actions={
              <Tag tone={statusTone} dot>
                {config.status || 'Unknown'}
              </Tag>
            }
          />
          <div className="mt-4">
            <p className="flex items-baseline gap-2">
              <span data-numeric="" className="font-display text-[34px] leading-none font-extrabold text-ink">
                {since === null || since === undefined ? '-' : formatNumber(since)}
              </span>
              <span className="text-[12.5px] text-ink-3">{neverRotated ? 'days since it was created, never rotated' : 'days since the last rotation'}</span>
            </p>
            {pct !== null ? (
              <>
                <div aria-hidden="true" className="mt-3 h-2.5 overflow-hidden rounded-full bg-track">
                  <span
                    className="block h-full rounded-full"
                    style={{ width: `${pct}%`, background: pct >= 100 ? 'var(--t-high)' : pct >= 80 ? 'var(--t-medium)' : 'var(--t-series-3)' }}
                  />
                </div>
                <p className="mt-1.5 text-[12px] text-ink-3">
                  {since >= interval ? `${formatNumber(since - interval)} days past its ${interval}-day interval.` : `${formatNumber(interval - since)} days left of its ${interval}-day interval.`}
                </p>
              </>
            ) : (
              <p className="mt-2 text-[12px] text-ink-3">{config.auto_rotation ? 'No interval recorded, so it cannot be measured against one.' : 'No interval: rotation is off.'}</p>
            )}
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Configuration" />
          <DetailList className="mt-2">
            <DetailRow label="Automatic rotation">{config.auto_rotation ? 'On' : 'Off'}</DetailRow>
            <DetailRow label="Interval">{interval ? `${interval} days` : '-'}</DetailRow>
            <DetailRow label="Last rotated">{config.last_rotation ? `${formatDateTime(config.last_rotation)} (${formatRelative(config.last_rotation)})` : 'Never'}</DetailRow>
            <DetailRow label="Next due">{config.next_expected ? `${formatDate(config.next_expected)} (${formatRelative(config.next_expected)})` : '-'}</DetailRow>
            <DetailRow label="Rotation function" mono>
              {config.rotation_lambda_arn ? <CopyableValue value={config.rotation_lambda_arn} /> : '-'}
            </DetailRow>
            <DetailRow label="Age">{life.age_days !== null && life.age_days !== undefined ? `${formatNumber(life.age_days)} days` : '-'}</DetailRow>
            <DetailRow label="Expires">
              {life.expires_at ? `${formatDate(life.expires_at)} (${life.days_until_expiry < 0 ? `expired ${formatRelative(life.expires_at)}` : `in ${life.days_until_expiry} days`})` : 'Never'}
            </DetailRow>
          </DetailList>
        </Panel>
      </div>

      <Panel>
        <PanelHeader icon={CalendarClock} title="Timeline" subtitle="Dated events on record, with what is due next." />
        {events.length === 0 ? (
          <p className="mt-3 text-[12.5px] text-ink-3">No dated events on record.</p>
        ) : (
          <ol className="mt-4 flex flex-col">
            {events.map((e, index) => (
              <li key={`${e.event}-${e.date}`} className="relative flex gap-3 pb-4 last:pb-0">
                {index < events.length - 1 && <span aria-hidden="true" className="absolute top-4 bottom-0 left-[5px] w-px bg-line-strong" />}
                <span
                  aria-hidden="true"
                  className={`relative mt-1 size-[11px] shrink-0 rounded-full border-2 ${e.past ? 'border-brand bg-brand' : 'border-brand bg-surface'}`}
                />
                <span className="min-w-0">
                  <span className="block text-[13px] font-medium text-ink">
                    {e.event} <span className="font-normal text-ink-3">· {formatDate(e.date)} ({formatRelative(e.date)})</span>
                  </span>
                  {e.details && <span className="block text-[12px] text-ink-3">{e.details}</span>}
                </span>
              </li>
            ))}
          </ol>
        )}
      </Panel>
    </div>
  );
}
