import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarClock, Copy, Hourglass, KeyRound, Link2Off, RefreshCwOff, SearchX } from 'lucide-react';
import { fetchCredentials } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelativeShort } from '../../lib/format';
import { credentialBadge, credentialTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { Page, Reveal } from '../../lib/motion';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { credentialSignals } from '../../lib/signals';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Freshness } from '../../ui/Freshness';
import { ListScopeNote } from '../../ui/ListScopeNote';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { RiskCell } from '../../ui/RiskCell';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { Tabs } from '../../ui/Tabs';
import { useToast } from '../../ui/Toast';
import { MiniMeter, TypeBadge } from '../../ui/TypeBadge';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { TONE_VAR, cn } from '../../ui/cn';
import { RecordPreview } from '../preview/RecordPreview';
import { copyText } from '../identities/IdentitiesPage';
import { ExpiryCell } from './parts';
import { FILTER_KEYS, PAGE_SIZES, appliedCount, readListState } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const LABELS = {
  search: 'Search',
  credential_type: 'Type',
  status: 'Status',
  is_orphaned: 'Holder',
  rotation_enabled: 'Rotation',
  rotation_overdue: 'Rotation overdue',
  has_external_trust: 'External trust',
  min_idle_days: 'Unused for',
  max_days_until_expiry: 'Expires within',
  owner_principal_arn: 'Owner principal',
};

/* Statuses a credential can have. The filter endpoint lists identity
   statuses only, so these carry no counts. */
const CREDENTIAL_STATUSES = ['active', 'inactive', 'expired', 'pending_deletion'];

/* The saved views: each is exactly the filter set it shows. */
const VIEWS = {
  all: {},
  expiring: { max_days_until_expiry: '30', sort_by: 'days_until_expiry', sort_order: 'asc' },
  unused: { min_idle_days: '90' },
  orphaned: { is_orphaned: 'true' },
  overdue: { rotation_overdue: 'true' },
};

/**
 * Credential inventory: GET /api/v1/credentials, filtered, sorted and paged on
 * the server, from the latest completed scan across every account. All state
 * lives in the URL under the API's own parameter names.
 */
export default function CredentialsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { railOpen, toggleRail } = useFacetRail();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);
  /* What an empty filter group says: still loading, failed, or genuinely nothing to pick. */
  const optionsNote = filterQuery.isError && !filterQuery.data ? 'Options could not be loaded.' : !filterQuery.data ? 'Loading…' : 'None in the latest scan.';

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => {
    try {
      return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
    } catch {
      return 'comfortable';
    }
  });

  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      const text = Array.isArray(value) ? value.join(',') : value;
      if (text === '' || text === null || text === undefined) next.delete(key);
      else next.set(key, String(text));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  /* Older links (`?view=expiring`, from the dashboard and bookmarks) become
     the filters they stand for. */
  useEffect(() => {
    const legacy = searchParams.get('view');
    if (!legacy) return;
    /* `stale` is the old name of the unused view; anything unknown is dropped, never left blocking the list. */
    const view = VIEWS[legacy === 'stale' ? 'unused' : legacy];
    if (view) {
      setSearchParams(view, { replace: true });
    } else {
      const next = new URLSearchParams(searchParams);
      next.delete('view');
      setSearchParams(next, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const listKey = JSON.stringify([filters, page, limit, sort]);
  const list = useQuery(
    (signal) => fetchCredentials({ ...filters, page, page_size: limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
    { enabled: !searchParams.get('view') },
  );

  const rows = list.data?.data ?? [];
  const total = list.data?.pagination?.total_count ?? 0;
  const applied = appliedCount(filters);

  const [peek, setPeek] = useState(null);
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }

  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const chips = FILTER_KEYS.flatMap((key) =>
    Array.isArray(filters[key])
      ? filters[key].length
        ? [{ key, label: LABELS[key], value: filters[key].map((value) => describe(key, value)).join(', ') }]
        : []
      : filters[key]
        ? [{ key, label: LABELS[key], value: describe(key, filters[key]) }]
        : [],
  );
  const facetGroups = useFacets({ filters, options, update, optionsNote });

  /* The saved views, each counted with the request it makes. */
  const counts = {
    all: useQuery((signal) => fetchCredentials({ page_size: 1 }, signal), []),
    expiring: useQuery((signal) => fetchCredentials({ max_days_until_expiry: 30, page_size: 1 }, signal), []),
    unused: useQuery((signal) => fetchCredentials({ min_idle_days: 90, page_size: 1 }, signal), []),
    orphaned: useQuery((signal) => fetchCredentials({ is_orphaned: 'true', page_size: 1 }, signal), []),
    overdue: useQuery((signal) => fetchCredentials({ rotation_overdue: 'true', page_size: 1 }, signal), []),
  };
  const countOf = (key) => (counts[key].data ? formatNumber(counts[key].data.pagination.total_count) : undefined);
  const view =
    Object.entries(VIEWS).find(([, preset]) => {
      const keys = Object.keys(preset).filter((key) => FILTER_KEYS.includes(key));
      return FILTER_KEYS.every((key) => {
        const value = filters[key];
        const has = Array.isArray(value) ? value.length > 0 : Boolean(value);
        return keys.includes(key) ? String(value) === String(preset[key]) : !has;
      });
    })?.[0] ?? '';
  const viewTabs = [
    { value: 'all', label: 'All credentials', icon: KeyRound, count: countOf('all') },
    { value: 'expiring', label: 'Expired or expiring in 30 days', icon: CalendarClock, count: countOf('expiring') },
    { value: 'unused', label: 'Unused 90+ days', icon: Hourglass, count: countOf('unused') },
    { value: 'orphaned', label: 'No holder', icon: Link2Off, count: countOf('orphaned') },
    { value: 'overdue', label: 'Rotation overdue', icon: RefreshCwOff, count: countOf('overdue') },
  ];
  const setView = (next) => {
    setSearchDraft('');
    setSearchParams(VIEWS[next] ?? {});
  };

  const columns = [
    {
      key: 'name',
      header: 'Credential',
      primary: true,
      sortable: true,
      width: '24%',
      cell: (row) => {
        const badge = credentialBadge(row.credential_type);
        return (
          <span className="flex min-w-0 items-center gap-3">
            <TypeBadge code={badge.code} color={badge.color} />
            <span className="min-w-0">
              <span className={cn('block truncate text-[13px] font-semibold text-ink', row.credential_type === 'access_key' && 'font-mono text-[12.5px]')} title={row.name || row.arn}>
                {row.name || row.arn}
              </span>
              <span className="block truncate text-[11px] text-ink-3">
                {credentialTypeLabel(row.credential_type)} · {regionLabel(row.region)}
              </span>
            </span>
          </span>
        );
      },
    },
    {
      key: 'bound_identities_count',
      header: 'Held by',
      sortable: true,
      width: '118px',
      priority: 'wide',
      cell: (row) =>
        row.is_orphaned ? (
          <span className="text-medium">No holder</span>
        ) : (
          <span className="text-ink">
            {formatNumber(row.bound_identities_count)} <span className="text-ink-3">identit{row.bound_identities_count === 1 ? 'y' : 'ies'}</span>
          </span>
        ),
    },
    {
      key: 'risk',
      header: 'Needs attention',
      width: '196px',
      mobile: true,
      cell: (row) => <RiskCell signals={credentialSignals(row)} />,
    },
    {
      key: 'last_used_at',
      header: 'Last used',
      sortable: true,
      width: '140px',
      mobile: true,
      cell: (row) => <Freshness value={row.last_used_at} empty="No use recorded" emptyTitle="No recorded use, or AWS does not report use for this type" />,
    },
    {
      key: 'days_until_expiry',
      header: 'Expires',
      sortable: true,
      width: '128px',
      mobile: true,
      cell: (row) => <ExpiryCell value={row.expires_at} status={row.status} />,
    },
    {
      key: 'last_rotated_at',
      header: 'Rotated',
      sortable: true,
      width: '128px',
      priority: 'wide',
      cell: (row) => <RotatedCell row={row} />,
    },
    {
      key: 'age_days',
      header: 'Age',
      sortable: true,
      width: '104px',
      priority: 'xl',
      cell: (row) => <AgeDaysCell days={row.age_days} />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Credentials"
          lede="Roles, access keys, secrets, certificates and parameters in the latest completed scan, across every account. Open one for its trust, activity, rotation and relationships."
          tabs={<Tabs size="sm" tabs={viewTabs} value={view} onChange={setView} />}
        />
      </Reveal>

      <Reveal>
        <div ref={tableTop} className="scroll-mt-20">
          <WorkArea railOpen={railOpen} rail={<FacetRail groups={facetGroups} appliedCount={applied} onClearAll={clearAll} onClose={toggleRail} />}>
            <Panel flush className="overflow-hidden">
              <RecordBar
                trailing={
                  <TableToolbar>
                    {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                    <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                    <TableSettings
                      density={density}
                      onDensityChange={(value) => {
                        setDensity(value);
                        try {
                          localStorage.setItem(DENSITY_KEY, value);
                        } catch {
                          /* a reading preference; safe to lose */
                        }
                      }}
                    />
                  </TableToolbar>
                }
              >
                <SearchInput size="sm" value={searchDraft} onChange={setSearchDraft} maxLength={256} placeholder="Search name or ARN…" className="w-full min-w-0 sm:max-w-sm" />
                <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'credential' : 'credentials'} loading={list.isLoading && !list.data} />
              </RecordBar>

              <ListScopeNote />

              <AppliedFilters
                filters={chips}
                onRemove={(key) => {
                  if (key === 'search') setSearchDraft('');
                  update({ [key]: '' });
                }}
                onClearAll={clearAll}
              />

              {list.isError && !list.data ? (
                <ErrorState
                  error={list.error}
                  onRetry={list.error?.status === 400 ? undefined : list.refetch}
                  title={list.error?.status === 400 ? 'These filters were not accepted' : undefined}
                />
              ) : (
                <>
                  {list.isError && (
                    <div className="p-3">
                      <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                    </div>
                  )}
                  <DataGrid
                    caption="Credentials"
                    columns={columns}
                    rows={rows}
                    rowKey={(row) => row.id}
                    loading={list.isLoading && !list.data}
                    refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                    onRowClick={(row, event) => {
                      if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                      else setPeek(rows.indexOf(row));
                    }}
                    selectedKey={peek !== null ? rows[peek]?.id : undefined}
                    rowLabel={(row) => `Preview ${row.name || row.arn}`}
                    sort={sort}
                    onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction })}
                    density={density}
                    skeletonRows={10}
                    rowActions={(row) => (
                      <IconButton
                        icon={Copy}
                        label={`Copy ARN for ${row.name || row.arn}`}
                        size="sm"
                        onClick={(event) => {
                          event.stopPropagation();
                          copyText(row.arn).then((ok) =>
                            notify(ok ? { variant: 'success', title: 'ARN copied', duration: 2200 } : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' }),
                          );
                        }}
                      />
                    )}
                    emptyState={
                      applied > 0 ? (
                        <EmptyState
                          icon={SearchX}
                          title="No credentials match these filters"
                          description="Remove a filter or change the search to widen the list."
                          action={
                            <Button variant="secondary" size="sm" onClick={clearAll}>
                              Clear all filters
                            </Button>
                          }
                        />
                      ) : (
                        <EmptyState title="No credentials discovered yet" description="Credentials appear here after the scanner completes a discovery run." />
                      )
                    }
                  />
                  {total > 0 && (
                    <Pagination
                      page={page}
                      pageSize={limit}
                      total={total}
                      pageSizes={PAGE_SIZES}
                      unit={total === 1 ? 'credential' : 'credentials'}
                      scrollTarget={tableTop}
                      onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                      onPageSizeChange={(size) => update({ page_size: size })}
                    />
                  )}
                </>
              )}
            </Panel>
          </WorkArea>
        </div>
      </Reveal>
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

/** Last rotation as distance; overdue in amber, never rotated said plainly. */
function RotatedCell({ row }) {
  if (row.rotation_overdue) {
    return (
      <span className="block truncate font-semibold text-high" title={row.last_rotated_at ? formatDateTime(row.last_rotated_at) : 'Never rotated'}>
        Overdue
      </span>
    );
  }
  return (
    <span className="block min-w-0" title={row.last_rotated_at ? formatDateTime(row.last_rotated_at) : 'Never rotated'}>
      <span className={cn('block truncate', row.last_rotated_at ? 'text-ink-2' : 'text-ink-3')}>{row.last_rotated_at ? formatRelativeShort(row.last_rotated_at) : 'Never'}</span>
      <span className="block truncate text-[11px] text-ink-3">{row.rotation_enabled ? 'Automatic' : 'Manual'}</span>
    </span>
  );
}

/** How long the credential has existed, with a bar that fills over two years. */
function AgeDaysCell({ days }) {
  const n = Number(days);
  if (!Number.isFinite(n)) return <span className="text-ink-3">Unknown</span>;
  const tone = n >= 365 ? 'high' : n >= 180 ? 'medium' : 'brand';
  return (
    <span className="block">
      <span data-numeric="" className="block text-[12.5px] text-ink-2">
        {formatNumber(n)} days
      </span>
      <MiniMeter value={Math.min(100, (n / 730) * 100)} tone={TONE_VAR[tone]} width={56} label={`${n} days old`} />
    </span>
  );
}

function describe(key, value) {
  switch (key) {
    case 'credential_type':
      return credentialTypeLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'is_orphaned':
      return value === 'true' ? 'No holder' : 'Held';
    case 'rotation_enabled':
      return value === 'true' ? 'On' : 'Off';
    case 'rotation_overdue':
    case 'has_external_trust':
      return value === 'true' ? 'Yes' : 'No';
    case 'min_idle_days':
      return `${value}+ days`;
    case 'max_days_until_expiry':
      return `${value} days (or expired)`;
    default:
      return value;
  }
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacets({ filters, options, update, optionsNote }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner_principal_arn);
  useEffect(() => setOwnerDraft(filters.owner_principal_arn), [filters.owner_principal_arn]);

  const toggleList = (key, value) => update({ [key]: filters[key].includes(value) ? filters[key].filter((v) => v !== value) : [...filters[key], value] });
  const single = (key, label, choices, extra = {}) => ({
    key,
    label,
    single: true,
    options: choices.map((choice) => ({ ...choice, active: filters[key] === choice.value })),
    onToggle: (value) => update({ [key]: value }),
    ...extra,
  });
  const yesNo = (key, label, yes, no, extra) => single(key, label, [{ value: 'true', label: yes }, { value: 'false', label: no }], extra);

  const types = [...options.credentialTypes];
  for (const value of filters.credential_type) if (!types.some((row) => row.value === value)) types.push({ value, count: undefined });
  const statuses = [...new Set([...CREDENTIAL_STATUSES, ...filters.status])];

  const presets = (values, current, suffix) => {
    const list = values.map((days) => ({ value: String(days), label: `${days}${suffix}` }));
    if (current && !values.map(String).includes(current)) list.push({ value: current, label: `${current}${suffix}` });
    return list;
  };

  /* Ordered by how a reviewer narrows: what it is, the clocks, who holds it,
     then rotation and trust, state, and the exact owner last. */
  return [
    {
      key: 'credential_type',
      label: 'Type',
      options: types.map((row) => ({ value: row.value, label: credentialTypeLabel(row.value), count: row.count, active: filters.credential_type.includes(row.value) })),
      onToggle: (value) => toggleList('credential_type', value),
      emptyText: optionsNote,
    },
    single('max_days_until_expiry', 'Expires within', presets([7, 30, 90], filters.max_days_until_expiry, ' days'), {
      note: 'Includes credentials that have already expired.',
    }),
    single('min_idle_days', 'Unused for', presets([30, 90, 180, 365], filters.min_idle_days, '+ days'), {
      note: 'Only credentials with a recorded last use; never-used ones are not counted.',
    }),
    yesNo('is_orphaned', 'Holder', 'No identity holds it', 'Held by an identity'),
    yesNo('rotation_enabled', 'Rotation', 'Automatic rotation on', 'Automatic rotation off', { defaultOpen: false }),
    yesNo('rotation_overdue', 'Rotation overdue', 'Overdue', 'On schedule', { defaultOpen: false }),
    yesNo('has_external_trust', 'External trust', 'Trusts another account', 'Same account only', { defaultOpen: false }),
    {
      key: 'status',
      label: 'Status',
      defaultOpen: false,
      options: statuses.map((value) => ({ value, label: statusMeta(value).label, active: filters.status.includes(value) })),
      onToggle: (value) => toggleList('status', value),
    },
    {
      key: 'owner_principal_arn',
      label: 'Owner principal',
      defaultOpen: Boolean(filters.owner_principal_arn),
      activeCount: filters.owner_principal_arn ? 1 : 0,
      content: (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            const value = ownerDraft.trim();
            update({ owner_principal_arn: value.startsWith('arn:') ? value : '' });
          }}
          className="flex flex-col gap-1.5"
        >
          <Input
            size="sm"
            value={ownerDraft}
            onChange={(event) => setOwnerDraft(event.target.value)}
            placeholder="arn:aws:iam::123456789012:role/…"
            aria-label="Owner principal ARN"
            spellCheck={false}
          />
          <span className="text-[11px] text-ink-3">Exact ARN. Press Enter to apply.</span>
        </form>
      ),
    },
  ];
}

