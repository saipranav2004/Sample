import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  FileWarning,
  Fingerprint,
  Gauge,
  History,
  KeyRound,
  LineChart as LineIcon,
  PieChart,
  RotateCw,
  ShieldAlert,
  Users,
} from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchCredentials, fetchFindingsSummary, fetchOverview, fetchPostureCategories } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDate, formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import { Page, Reveal } from '../../lib/motion';
import { credentialTypeLabel, environmentLabel, functionalClassLabel, identityTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { useScope } from '../../lib/useScope';
import { PageHeader } from '../../shell/PageHeader';
import { BarChart } from '../../charts/BarChart';
import { ColumnChart } from '../../charts/ColumnChart';
import { Donut } from '../../charts/Donut';
import { LineChart } from '../../charts/LineChart';
import { DATE_DAY } from '../../charts/useWidth';
import { Button } from '../../ui/Button';
import { FilterSelect, MultiFilterSelect } from '../../ui/FilterBar';
import { Panel, PanelHeader } from '../../ui/Panel';
import { ChartSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { ClearState, EmptyState, ErrorState, InlineError } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { useToast } from '../../ui/Toast';
import { TONE_FG, TONE_VAR, cn } from '../../ui/cn';

/**
 * Dashboard: GET /api/v1/dashboard/overview for the user's saved scope
 * (accounts, regions and scan from /api/v1/settings). It answers, in order:
 *
 *   1. What am I looking at?            scope bar: accounts, regions, scan
 *   2. How big is it, is it growing?    tiles, how the inventory built up
 *   3. Where is the risk?               risk signals, expiring credentials
 *   4. Have secrets leaked into code?   credential exposure (admins)
 *   5. What is it made of, who owns it? breakdown, environment and status, owners
 *   6. Is scanning healthy?             scan history
 *
 * Counts are the API's. A count links to a list only where the list's filter
 * means the same thing; the lists cover every account in the latest scan, so
 * a narrower dashboard scope is called out wherever it could differ.
 */
export default function OverviewPage() {
  const scope = useScope();
  const filterOptions = useFilterOptions();
  const options = optionsOf(filterOptions);
  const { can } = useAccess();
  const admin = can('exposure.view');

  const s = scope.data;
  const key = s ? `${s.scanId}|${s.accounts.join(',')}|${s.regions.join(',')}` : 'pending';
  /* The API applies the saved scope itself; the key refetches when it changes. */
  const overview = useQuery(
    (signal) => fetchOverview(signal),
    [key],
    { enabled: scope.status === 'ready' || scope.status === 'error' },
  );
  const findings = useQuery((signal) => fetchFindingsSummary(signal), [], { enabled: admin });
  /* Posture follows the chosen scan (latest completed when none is chosen); it has no account filter. */
  const postureScan = s?.selectedScanId || undefined;
  const posture = useQuery((signal) => fetchPostureCategories({ scanId: postureScan }, signal), [postureScan ?? 'latest'], {
    enabled: scope.status === 'ready' || scope.status === 'error',
  });

  const accountIds = options.accounts.map((account) => account.id);
  const regionIds = options.regions.map((region) => region.value).filter((region) => region !== 'global');
  const narrowed = Boolean(
    s && ((accountIds.length > 0 && accountIds.some((id) => !s.accounts.includes(id))) || (s.scanId && options.scans[0] && s.scanId !== options.scans[0].scan_id)),
  );

  const refresh = () => {
    overview.refetch();
    posture.refetch();
    if (admin) findings.refetch();
    scope.retry();
  };

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Dashboard"
          lede="Non-human identities and the credentials they hold, for the accounts, regions and scan you choose. Your choice is saved to your profile."
          actions={
            <Button variant="secondary" size="sm" icon={RotateCw} onClick={refresh} loading={overview.isRefreshing}>
              Refresh
            </Button>
          }
          meta={<ScopeBar scope={scope} options={options} optionsLoading={filterOptions.isLoading} accountIds={accountIds} regionIds={regionIds} />}
        />
      </Reveal>

      {overview.isError && !overview.data ? (
        <Reveal>
          <Panel>
            <ErrorState
              error={overview.error}
              onRetry={overview.refetch}
              title="The dashboard could not be loaded"
              hint={
                overview.error?.status >= 500
                  ? "The API could not read your organisation's data. If your organisation was set up recently, its data store may not be ready yet; otherwise try again in a moment."
                  : undefined
              }
            />
          </Panel>
        </Reveal>
      ) : (
        <Dashboard data={overview.data} loading={!overview.data} findings={admin ? findings : null} narrowed={narrowed} posture={posture} />
      )}
    </Page>
  );
}

/* ── Scope ───────────────────────────────────────────────────────────────── */

/**
 * Accounts, regions and scan, saved with PUT /api/v1/settings. An empty
 * selection would fall back to the tenant defaults rather than mean "all", so
 * "Select all" sends every account. Global resources (IAM roles, keys) have no
 * region and are always counted; the region list is the regional ones.
 */
function ScopeBar({ scope, options, optionsLoading, accountIds, regionIds }) {
  const { notify } = useToast();
  const s = scope.data;
  if (!s && scope.status !== 'error') return <Skeleton className="h-[38px] w-full max-w-3xl rounded-lg" />;
  if (!s) {
    return (
      <p className="flex flex-wrap items-center gap-2 text-[12.5px] text-ink-3">
        Your saved scope could not be loaded, so the API's defaults apply.
        <button type="button" onClick={scope.retry} className="font-medium text-brand hover:underline">
          Try again
        </button>
      </p>
    );
  }

  const apply = async (next, what) => {
    const result = await scope.save({ accounts: s.accounts, regions: s.regions, scanId: s.selectedScanId, ...next });
    notify(
      result.ok
        ? { variant: 'success', title: `${what} saved`, description: 'The dashboard now shows your new scope.', duration: 2400 }
        : { variant: 'error', title: `${what} not saved`, description: result.error?.message },
    );
    return result.ok;
  };

  const accountOptions = options.accounts.map((account) => ({
    value: account.id,
    label: account.id,
    mono: true,
    hint: `${formatNumber(account.identities)} identities · ${formatNumber(account.credentials)} credentials${account.isDefault ? ' · default' : ''}`,
  }));
  const regionOptions = options.regions
    .filter((region) => region.value !== 'global')
    .map((region) => ({ value: region.value, label: regionLabel(region.value), count: region.count }));
  const scanOptions = options.scans.map((scan, index) => ({
    value: scan.scan_id,
    label: scan.scan_id,
    mono: true,
    hint: `${scan.scan_end ? formatDate(scan.scan_end) : 'No end time'} · ${formatNumber(scan.total_identities)} identities${index === 0 ? ' · latest' : ''}`,
  }));

  /* Only values the filter list still offers are shown as selected. */
  const accounts = s.accounts.filter((id) => accountIds.length === 0 || accountIds.includes(id));
  const regions = s.regions.filter((region) => regionIds.length === 0 || regionIds.includes(region));

  return (
    <div className="flex flex-col gap-2.5">
      <div className="flex flex-wrap items-center gap-2">
        <MultiFilterSelect
          label="Accounts"
          values={accounts}
          options={accountOptions}
          busy={scope.saving}
          disabled={optionsLoading && accountOptions.length === 0}
          onApply={(next) => apply({ accounts: next }, 'Accounts')}
        />
        <MultiFilterSelect
          label="Regions"
          values={regions}
          options={regionOptions}
          busy={scope.saving}
          disabled={optionsLoading && regionOptions.length === 0}
          onApply={(next) => apply({ regions: next }, 'Regions')}
        />
        <FilterSelect
          label="Scan"
          value={s.selectedScanId ?? ''}
          anyLabel="Latest completed"
          options={scanOptions}
          loading={optionsLoading}
          onChange={(value) => apply({ scanId: value || null }, 'Scan')}
        />
        {scope.saving && <span className="text-[12px] text-ink-3">Saving…</span>}
      </div>
      <p className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[12px] text-ink-3">
        <History aria-hidden="true" className="size-3.5" />
        {s.scanId ? (
          <span>
            Showing scan <span className="font-mono text-[11.5px] text-ink-2">{s.scanId}</span>
            {s.scanTime && (
              <>
                , completed <time dateTime={s.scanTime} title={formatDateTime(s.scanTime)}>{formatRelative(s.scanTime)}</time>
              </>
            )}
            {s.scanDefault ? ' (the latest).' : '.'}
          </span>
        ) : (
          <span>No completed scan yet.</span>
        )}
        <span>
          {s.source === 'user_settings' ? 'Scope saved to your profile.' : 'Using your organisation\'s default accounts.'} Global resources such as IAM roles are always included.
        </span>
      </p>
    </div>
  );
}

/* ── Body ────────────────────────────────────────────────────────────────── */

/**
 * The page in three tiers, so the eye lands where the work is:
 *   1. Act: what to fix first, and how each posture category scores.
 *   2. Size: what the scan found, and how the inventory built up.
 *   3. Shape: what it is made of, who owns it, what expires, how scans run.
 */
function Dashboard({ data, loading, findings, narrowed, posture }) {
  const k = data?.kpis;
  const c = data?.charts;
  /* A workspace whose first scan has not completed has nothing to chart: say what happens next instead. */
  if (data && !k.last_scan_time) return <FirstRun history={c?.scan_history} findings={findings} />;
  return (
    <>
      <Reveal className="grid gap-4 @min-[64rem]:grid-cols-12">
        <FixFirstPanel kpis={k} loading={loading} findings={findings} narrowed={narrowed} className="@min-[64rem]:col-span-7" />
        <PosturePanel query={posture} className="@min-[64rem]:col-span-5" />
      </Reveal>

      <Reveal>
        <InventoryPanel kpis={k} charts={c} loading={loading} />
      </Reveal>

      <Reveal className="grid gap-4 @min-[64rem]:grid-cols-12">
        <BreakdownPanel charts={c} loading={loading} className="@min-[64rem]:col-span-7" />
        <ExpiringPanel items={c?.credentials_expiring_soon} loading={loading} className="@min-[64rem]:col-span-5" />
      </Reveal>

      <Reveal className="grid gap-4 @min-[64rem]:grid-cols-12">
        <MixPanel charts={c} loading={loading} className="@min-[64rem]:col-span-7" />
        <OwnersPanel charts={c} kpis={k} loading={loading} className="@min-[64rem]:col-span-5" />
      </Reveal>

      <Reveal className="grid gap-4 @min-[64rem]:grid-cols-12">
        <ScanHistoryPanel history={c?.scan_history} loading={loading} className={findings ? '@min-[64rem]:col-span-7' : '@min-[64rem]:col-span-12'} />
        {findings && <ExposurePanel query={findings} className="@min-[64rem]:col-span-5" />}
      </Reveal>
    </>
  );
}

/* ── First run ───────────────────────────────────────────────────────────── */

/**
 * Before the first completed scan. The scan history says which of three
 * situations this is (running, failed, not started), each with what to
 * expect; the panels appear on their own once a scan completes.
 */
function FirstRun({ history, findings }) {
  const all = Array.isArray(history) ? history : [];
  /* A lone running scan has nothing to chart yet. */
  const scans = all.some((scan) => String(scan.status).toUpperCase() !== 'RUNNING') ? all : [];
  const running = all.find((scan) => String(scan.status).toUpperCase() === 'RUNNING');
  const failed = all.find((scan) => String(scan.status).toUpperCase() === 'FAILED');
  const state = running
    ? {
        tone: 'info',
        title: 'Your first scan is running',
        text: `Scan ${running.scan_id} is discovering the identities and credentials in your connected AWS accounts. This page fills in when it completes; use Refresh to check.`,
      }
    : failed
      ? {
          tone: 'critical',
          title: 'Your first scan did not complete',
          text: `Scan ${failed.scan_id} failed${failed.scan_end ? ` ${formatRelative(failed.scan_end)}` : ''}. Check the scanner's access to your AWS accounts, then run it again. This page fills in once a scan completes.`,
        }
      : {
          tone: 'neutral',
          title: 'No scan has run yet',
          text: 'Once your AWS accounts are connected and the scanner has completed its first scan, this page shows what it found and what to fix first.',
        };
  return (
    <>
      <Reveal>
        <Panel prominence="lead" aria-label="Getting started">
          <div className="flex flex-col items-start gap-3 @min-[40rem]:flex-row @min-[40rem]:items-center @min-[40rem]:gap-5">
            <span className="grid size-12 shrink-0 place-items-center rounded-full border" style={{ color: TONE_VAR[state.tone], borderColor: `color-mix(in srgb, ${TONE_VAR[state.tone]} 35%, transparent)` }}>
              <History aria-hidden="true" className="size-5" />
            </span>
            <div className="min-w-0">
              <h2 className="text-[18px] font-bold tracking-[-0.012em] text-ink">{state.title}</h2>
              <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-ink-2">{state.text}</p>
            </div>
          </div>
          <ol className="mt-5 grid gap-3 border-t border-line pt-4 @min-[48rem]:grid-cols-3">
            {[
              [
                'Connect',
                <>
                  Your AWS account is connected on{' '}
                  <Link to="/integrations" className="font-medium text-brand hover:underline">
                    Integrations
                  </Link>{' '}
                  (by an admin).
                </>,
              ],
              ['Scan', 'The scanner discovers every non-human identity and the credentials each holds.'],
              ['Review', 'This dashboard ranks what to fix first; Identities and Credentials list every record.'],
            ].map(([title, text], index) => (
              <li key={title} className="flex gap-3">
                <span data-numeric="" className="grid size-6 shrink-0 place-items-center rounded-full bg-surface-3 text-[12px] font-semibold text-ink-2">
                  {index + 1}
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-semibold text-ink">{title}</span>
                  <span className="block text-[12px] text-ink-3">{text}</span>
                </span>
              </li>
            ))}
          </ol>
        </Panel>
      </Reveal>
      {(scans.length > 0 || findings) && (
        <Reveal className="grid gap-4 @min-[64rem]:grid-cols-12">
          {scans.length > 0 && <ScanHistoryPanel history={scans} loading={false} className={findings ? '@min-[64rem]:col-span-7' : '@min-[64rem]:col-span-12'} />}
          {findings && <ExposurePanel query={findings} className={scans.length > 0 ? '@min-[64rem]:col-span-5' : '@min-[64rem]:col-span-12'} />}
        </Reveal>
      )}
    </>
  );
}

/* ── Fix first ───────────────────────────────────────────────────────────── */

const SEVERITY = { critical: 'Critical', high: 'High', medium: 'Medium' };
const RANK = { critical: 0, high: 1, medium: 2 };

/**
 * The open risks in this scope, worst first: severity, what it is, why it
 * matters, how many and what share. A row opens the matching records only
 * where the list's filter means exactly the same thing; the others say where
 * to look instead. Risks at zero fold into one "Clear" line.
 */
function FixFirstPanel({ kpis, loading, findings, narrowed, className }) {
  const secrets = findings?.data;
  const unusedPct = kpis ? Math.max(0, Math.round(100 - (Number(kpis.permission_utilization_pct) || 0))) : 0;
  const items = kpis
    ? [
        {
          key: 'public',
          tone: 'critical',
          label: 'Identities reachable from the internet',
          why: 'A public endpoint or address: anyone can try them.',
          value: kpis.publicly_accessible,
          base: kpis.total_identities,
          to: '/identities?is_publicly_accessible=true',
        },
        findings && {
          key: 'secrets',
          tone: 'critical',
          label: 'High-risk secrets committed to code',
          why: secrets ? `Found in ${formatNumber(secrets.affected_repositories)} repositor${secrets.affected_repositories === 1 ? 'y' : 'ies'}. Rotate them, then remove them from history.` : 'Loading from the secret scanner.',
          value: secrets ? secrets.high_count : null,
          to: '/exposure',
        },
        {
          key: 'orphaned',
          tone: 'high',
          label: 'Credentials held by no identity',
          why: 'Nothing in the inventory uses them. Confirm, then retire them.',
          value: kpis.orphaned_credentials,
          base: kpis.total_credentials,
          to: '/credentials?is_orphaned=true',
        },
        {
          key: 'stale',
          tone: 'high',
          label: 'Identities inactive for 90 days',
          why: 'Idle workloads that keep their access. Remove the ones nobody needs.',
          value: kpis.stale_identities,
          base: kpis.total_identities,
        },
        {
          key: 'unused',
          tone: 'medium',
          label: 'Credentials unused for 90 days',
          why: 'No call recorded with them. Disable them, or confirm with the owner.',
          value: kpis.stale_credentials,
          base: kpis.total_credentials,
        },
        {
          key: 'owner',
          tone: 'medium',
          label: 'Identities with no owner',
          why: 'Nobody is answerable for them. Add an Owner tag.',
          value: kpis.shadow_identities,
          base: kpis.total_identities,
        },
        kpis.total_credentials > 0 && {
          key: 'perms',
          tone: 'medium',
          label: 'Granted permissions never used',
          why: 'Access held but not used in 90 days: the excess to trim.',
          value: unusedPct,
          unit: '%',
          share: unusedPct,
        },
      ].filter(Boolean)
    : [];
  const open = items.filter((item) => item.value === null || Number(item.value) > 0).sort((a, b) => RANK[a.tone] - RANK[b.tone]);
  const clear = items.filter((item) => item.value !== null && !(Number(item.value) > 0));

  return (
    <Panel prominence="lead" className={className} aria-label="Fix first">
      <PanelHeader prominence="lead" icon={ShieldAlert} title="Fix first" subtitle="Open risks in this scope, worst first." />
      {loading ? (
        <div className="mt-4">
          <ListSkeleton rows={6} />
        </div>
      ) : open.length === 0 ? (
        <div className="mt-4">
          <ClearState title="Nothing to fix in this scope" description="Every risk the dashboard tracks reads zero." />
        </div>
      ) : (
        <ol className="mt-3 flex flex-col divide-y divide-line">
          {open.map((item) => (
            <li key={item.key}>
              <FixRow item={item} />
            </li>
          ))}
        </ol>
      )}
      {!loading && clear.length > 0 && (
        <p className="mt-3 flex items-start gap-1.5 border-t border-line pt-3 text-[12px] text-ink-3">
          <CheckCircle2 aria-hidden="true" className="mt-px size-3.5 shrink-0 text-low" />
          <span>
            <span className="font-medium text-ink-2">Clear:</span> {clear.map((item) => item.label.toLowerCase()).join('; ')}.
          </span>
        </p>
      )}
      {!loading && narrowed && (
        <p className="mt-2 text-[11.5px] text-ink-3">Lists cover every account in the latest scan, so a list opened from here can hold more than this scope counts.</p>
      )}
    </Panel>
  );
}

function FixRow({ item }) {
  const share = item.share ?? (item.base ? (Number(item.value) / item.base) * 100 : null);
  const body = (
    <span className="grid grid-cols-[4.75rem_minmax(0,1fr)_auto] items-start gap-x-3 py-3">
      <span
        className="mt-px inline-flex w-fit items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold"
        style={{ color: TONE_VAR[item.tone], borderColor: `color-mix(in srgb, ${TONE_VAR[item.tone]} 35%, transparent)` }}
      >
        <span aria-hidden="true" className="size-1.5 rounded-full" style={{ background: TONE_VAR[item.tone] }} />
        {SEVERITY[item.tone]}
      </span>
      <span className="min-w-0">
        <span className="block text-[13.5px] font-semibold text-ink">{item.label}</span>
        <span className="mt-0.5 block text-[12px] text-ink-3">{item.why}</span>
        {share !== null && (
          <span aria-hidden="true" className="mt-1.5 block h-1 max-w-[18rem] overflow-hidden rounded-full bg-[var(--t-track)]">
            <span className="block h-full rounded-full" style={{ width: `${Math.max(1.5, Math.min(100, share))}%`, background: TONE_VAR[item.tone] }} />
          </span>
        )}
      </span>
      <span className="flex items-center gap-1.5 text-right">
        <span>
          <span data-numeric="" className="block font-display text-[20px] leading-none font-bold text-ink">
            {item.value === null ? '-' : `${formatNumber(item.value)}${item.unit ?? ''}`}
          </span>
          {item.base ? (
            <span data-numeric="" className="mt-1 block text-[11px] text-ink-3">
              of {formatNumber(item.base)}
            </span>
          ) : null}
        </span>
        {item.to && <ChevronRight aria-hidden="true" className="size-4 text-ink-3" />}
      </span>
    </span>
  );
  return item.to ? (
    <Link to={item.to} className="-mx-2 block rounded-md px-2 transition-colors hover:bg-surface-2" aria-label={`${item.label}: ${item.value ?? 'loading'}. Open the list.`}>
      {body}
    </Link>
  ) : (
    body
  );
}

/* ── Posture by category ─────────────────────────────────────────────────── */

const POSTURE_TONE = { fail: 'critical', warn: 'medium', pass: 'low' };
const POSTURE_LABEL = { fail: 'Failing', warn: 'At risk', pass: 'Passing' };

/**
 * GET /api/v1/postures/categories: each posture category's score (0-100)
 * and how many identities fail it, worst score first. It covers every
 * account in the scan, whatever the dashboard's account choice.
 */
function PosturePanel({ query, className }) {
  const data = query.data;
  const categories = useMemo(() => [...(data?.categories ?? [])].sort((a, b) => a.score - b.score || b.weight - a.weight), [data]);
  const failing = categories.filter((cat) => cat.status !== 'pass').length;
  return (
    <Panel prominence="lead" className={className}>
      <PanelHeader
        prominence="lead"
        icon={Gauge}
        title="Posture by category"
        subtitle={
          data
            ? categories.length
              ? `${failing ? `${failing} of ${categories.length} categories below 90` : `All ${categories.length} categories at 90 or above`}. ${formatNumber(data.total_identities)} identities scored, every account.`
              : 'No posture results for this scan yet.'
            : 'Scores from the posture engine for the scan.'
        }
      />
      <div className="mt-3">
        {query.isError && !data ? (
          <InlineError error={query.error} onRetry={query.refetch} label="Posture scores could not load" />
        ) : !data ? (
          <ListSkeleton rows={5} />
        ) : categories.length === 0 ? (
          <EmptyState compact icon={Gauge} title="No posture scores yet" description="Scores appear once the posture engine has evaluated a completed scan." />
        ) : (
          <ul className="flex flex-col gap-3">
            {categories.map((cat) => {
              const tone = POSTURE_TONE[cat.status] ?? 'neutral';
              return (
                <li key={cat.category_code} title={cat.description || undefined}>
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="min-w-0 truncate text-[13px] font-semibold text-ink">{cat.name}</span>
                    <span className="flex shrink-0 items-baseline gap-2">
                      <span className="text-[11px] font-semibold" style={{ color: TONE_VAR[tone] }}>
                        {POSTURE_LABEL[cat.status] ?? cat.status}
                      </span>
                      <span data-numeric="" className="font-display text-[16px] leading-none font-bold text-ink">
                        {Math.round(cat.score)}
                      </span>
                    </span>
                  </div>
                  <span aria-hidden="true" className="mt-1.5 block h-1.5 overflow-hidden rounded-full bg-[var(--t-track)]">
                    <span className="block h-full rounded-full" style={{ width: `${Math.max(1, Math.min(100, cat.score))}%`, background: TONE_VAR[tone] }} />
                  </span>
                  <span className="mt-1 block text-[11.5px] text-ink-3">
                    {cat.total_failing ? `${formatNumber(cat.total_failing)} of ${formatNumber(cat.total_evaluated)} identities failing` : `None of ${formatNumber(cat.total_evaluated)} identities failing`}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
        {data && categories.length > 0 && (
          <p className="mt-4 border-t border-line pt-3 text-[11.5px] leading-relaxed text-ink-3">
            Each identity starts at 100 and loses the risk score of its open findings in the category; the category score is the average. 90 and above passes, 60 to 89 is at risk, below 60 fails. A passing category can still have identities failing it.
          </p>
        )}
      </div>
    </Panel>
  );
}

/* ── Inventory ───────────────────────────────────────────────────────────── */

function lastStep(points) {
  if (!Array.isArray(points) || points.length < 2) return null;
  return Number(points.at(-1).count) - Number(points.at(-2).count);
}

/**
 * What the scan found in this scope, and how it built up. The totals open the
 * lists; the line is the records in this scan by the month each was first
 * seen (not a history of past scans, which the API does not keep).
 */
function InventoryPanel({ kpis, charts, loading }) {
  const series = [
    { key: 'identities', label: 'Identities', color: 'var(--t-series-1)', points: (charts?.identity_growth ?? []).map((p) => ({ date: p.date, value: p.count })) },
    { key: 'credentials', label: 'Credentials', color: 'var(--t-series-2)', points: (charts?.credential_growth ?? []).map((p) => ({ date: p.date, value: p.count })) },
  ].filter((s) => s.points.length > 0);
  const idStep = lastStep(charts?.identity_growth);
  const crStep = lastStep(charts?.credential_growth);
  const pct = Number(kpis?.permission_utilization_pct) || 0;
  return (
    <Panel>
      <PanelHeader icon={LineIcon} title="Inventory" subtitle="What the scan found in this scope, and the month each record was first seen." />
      {loading ? (
        <div className="mt-4 grid gap-6 @min-[52rem]:grid-cols-[17rem_minmax(0,1fr)]">
          <ListSkeleton rows={4} />
          <ChartSkeleton height={200} />
        </div>
      ) : (
        <div className="mt-4 grid gap-6 @min-[52rem]:grid-cols-[17rem_minmax(0,1fr)]">
          <dl className="grid grid-cols-2 gap-x-4 gap-y-4 @min-[52rem]:grid-cols-1 @min-[52rem]:content-start">
            <InventoryStat to="/identities" icon={Fingerprint} label="Identities" value={kpis.total_identities} sub={idStep ? `+${formatNumber(idStep)} first seen this month` : 'None new this month'} />
            <InventoryStat to="/credentials" icon={KeyRound} label="Credentials" value={kpis.total_credentials} sub={crStep ? `+${formatNumber(crStep)} first seen this month` : 'None new this month'} />
            <InventoryStat icon={Users} label="Accounts scanned" value={kpis.accounts_scanned} sub="In this scope" />
            <div className="min-w-0">
              <dt className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Permissions used</dt>
              <dd data-numeric="" className="mt-0.5 font-display text-[22px] leading-none font-bold" style={{ color: pct < 50 ? 'var(--t-high)' : 'var(--t-ink)' }}>
                {pct}%
              </dd>
              <dd className="mt-1.5 max-w-[12rem]">
                <span aria-hidden="true" className="block h-1.5 overflow-hidden rounded-full bg-[var(--t-track)]">
                  <span className="block h-full rounded-full" style={{ width: `${Math.min(100, pct)}%`, background: pct < 50 ? 'var(--t-high)' : 'var(--t-series-3)' }} />
                </span>
              </dd>
              <dd className="mt-1 text-[11.5px] text-ink-3">of granted actions, used in 90 days</dd>
            </div>
          </dl>
          <div className="min-w-0">
            {series.length === 0 ? (
              <EmptyState compact title="No first-seen dates" description="The scan recorded no first-seen dates to plot." />
            ) : (
              <>
                <Legend items={series} />
                <LineChart series={series} height={210} title="Identities and credentials by first-seen month" />
              </>
            )}
          </div>
        </div>
      )}
    </Panel>
  );
}

function InventoryStat({ to, icon: Icon, label, value, sub }) {
  const content = (
    <>
      <dt className="flex items-center gap-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">
        <Icon aria-hidden="true" className="size-3.5" />
        {label}
      </dt>
      <dd data-numeric="" className="mt-0.5 font-display text-[22px] leading-none font-bold text-ink">
        {formatNumber(value)}
      </dd>
      <dd className="mt-1 text-[11.5px] text-ink-3">{sub}</dd>
    </>
  );
  return to ? (
    <Link to={to} className="-m-1.5 block min-w-0 rounded-md p-1.5 transition-colors hover:bg-surface-2">
      {content}
    </Link>
  ) : (
    <div className="min-w-0">{content}</div>
  );
}

/* ── Expiring soon ───────────────────────────────────────────────────────── */

/** The API's ten nearest expiries within 30 days (not yet expired). */
const EXPIRING_SHOWN = 6;

/**
 * The expiring list names credentials but carries no id, so a click looks the
 * name up and opens the record when exactly one credential has that name and
 * expiry; otherwise it opens the list searched by name. The link's own href
 * is that search, so a new tab or a failed lookup still lands somewhere useful.
 */
function useOpenByName() {
  const navigate = useNavigate();
  return async (event, row) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return;
    event.preventDefault();
    const fallback = `/credentials?search=${encodeURIComponent(row.credential_name)}`;
    try {
      const found = await fetchCredentials({ search: row.credential_name, page: 1, page_size: 100 });
      const exact = found.data.filter((c) => c.name === row.credential_name && (!row.expires_at || !c.expires_at || parseDate(c.expires_at)?.getTime() === parseDate(row.expires_at)?.getTime()));
      navigate(exact.length === 1 ? `/credentials/${encodeURIComponent(exact[0].id)}` : fallback);
    } catch {
      navigate(fallback);
    }
  };
}

function ExpiringPanel({ items, loading, className }) {
  const rows = Array.isArray(items) ? items : [];
  const openByName = useOpenByName();
  return (
    <Panel className={className}>
      <PanelHeader
        icon={CalendarClock}
        title="Expiring in 30 days"
        subtitle="The nearest expiries in this scope, soonest first."
        actions={
          <Button as={Link} to="/credentials?view=expiring" variant="ghost" size="sm" iconRight={ArrowRight}>
            All
          </Button>
        }
      />
      <div className="mt-3">
        {loading ? (
          <ListSkeleton rows={5} />
        ) : rows.length === 0 ? (
          <ClearState compact title="Nothing expires in the next 30 days" description="No credential in this scope reaches its end date within a month." />
        ) : (
          <ul className="flex flex-col divide-y divide-line">
            {rows.slice(0, EXPIRING_SHOWN).map((row) => {
              const days = Number(row.days_remaining);
              const tone = days < 7 ? 'critical' : 'high';
              return (
                <li key={`${row.credential_name}-${row.expires_at}`}>
                  <Link
                    to={`/credentials?search=${encodeURIComponent(row.credential_name)}`}
                    onClick={(event) => openByName(event, row)}
                    className="-mx-2 flex items-center gap-3 rounded-md px-2 py-2 hover:bg-surface-2"
                    title={`Expires ${formatDateTime(row.expires_at)}`}
                  >
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-medium text-ink">{row.credential_name}</span>
                      <span className="block text-[11.5px] text-ink-3">{formatDate(row.expires_at)}</span>
                    </span>
                    <span data-numeric="" className={cn('shrink-0 text-[12.5px] font-semibold', TONE_FG[tone])}>
                      {days <= 0 ? 'Today' : `${days} day${days === 1 ? '' : 's'}`}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </Panel>
  );
}

/* ── Credential exposure ─────────────────────────────────────────────────── */

const TIERS = [
  ['high_count', 'High', 'high'],
  ['medium_count', 'Medium', 'medium'],
  ['low_count', 'Low', 'info'],
];

/** GET /api/findings/summary (admins). */
function ExposurePanel({ query, className }) {
  const data = query.data;
  const max = data ? Math.max(1, ...TIERS.map(([key]) => Number(data[key]) || 0)) : 1;
  return (
    <Panel className={className}>
      <PanelHeader
        icon={FileWarning}
        title="Credential exposure"
        subtitle="Secrets committed to connected repositories, by risk."
        actions={
          <Button as={Link} to="/exposure" variant="secondary" size="sm" iconRight={ArrowRight}>
            Review
          </Button>
        }
      />
      <div className="mt-4">
        {query.isError && !data ? (
          <InlineError error={query.error} onRetry={query.refetch} label="Findings could not load" />
        ) : !data ? (
          <ListSkeleton rows={4} />
        ) : data.total_findings === 0 ? (
          <ClearState compact title="No secrets exposed in code" description="The scanner found nothing outstanding in the connected repositories." />
        ) : (
          <div className="flex flex-col gap-4">
            <ul className="flex flex-col gap-2.5">
              {TIERS.map(([key, label, tone]) => (
                <li key={key} className="grid grid-cols-[5.5rem_minmax(0,1fr)_2.5rem] items-center gap-3">
                  <Tag size="sm" tone={tone} dot>
                    {label}
                  </Tag>
                  <span className="h-2 overflow-hidden rounded-full bg-[var(--t-track)]">
                    <span className="block h-full rounded-full" style={{ width: `${((Number(data[key]) || 0) / max) * 100}%`, background: TONE_VAR[tone] }} />
                  </span>
                  <span data-numeric="" className="text-right text-[15px] font-bold text-ink">
                    {formatNumber(data[key])}
                  </span>
                </li>
              ))}
            </ul>
            <dl className="grid grid-cols-2 gap-3 border-t border-line pt-3">
              <div>
                <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Findings</dt>
                <dd data-numeric="" className="text-[17px] font-bold text-ink">{formatNumber(data.total_findings)}</dd>
              </div>
              <div>
                <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Repositories</dt>
                <dd data-numeric="" className="text-[17px] font-bold text-ink">{formatNumber(data.affected_repositories)}</dd>
              </div>
            </dl>
          </div>
        )}
      </div>
    </Panel>
  );
}

function Legend({ items }) {
  return (
    <ul className="mb-2 flex flex-wrap gap-x-4 gap-y-1">
      {items.map((item) => (
        <li key={item.key} className="flex items-center gap-1.5 text-[12px] text-ink-2">
          <span aria-hidden="true" className="h-0.5 w-4 rounded-full" style={{ background: item.color }} />
          {item.label}
        </li>
      ))}
    </ul>
  );
}

/* ── Breakdown ───────────────────────────────────────────────────────────── */

const BREAKDOWNS = [
  { value: 'type', label: 'Type' },
  { value: 'class', label: 'Class' },
  { value: 'account', label: 'Account' },
  { value: 'region', label: 'Region' },
  { value: 'credential', label: 'Credentials' },
];

/**
 * One ranked bar list with a switch, rather than five charts competing for
 * attention: a reader compares within a breakdown, not across them. A bar
 * opens the matching list where the list can filter by it.
 */
function BreakdownPanel({ charts, loading, className }) {
  const [view, setView] = useState('type');
  const navigate = useNavigate();
  const items = useMemo(() => {
    if (!charts) return [];
    const rows = {
      type: (charts.identities_by_type ?? []).map((r) => ({ key: r.type, label: identityTypeLabel(r.type), value: r.count, to: `/identities?identity_type=${encodeURIComponent(r.type)}` })),
      class: (charts.identities_by_functional_class ?? []).map((r) => ({
        key: r.class,
        label: functionalClassLabel(r.class),
        value: r.count,
        to: r.class && r.class !== 'unknown' ? `/identities?functional_class=${encodeURIComponent(r.class)}` : null,
      })),
      account: (charts.identities_by_account ?? []).map((r) => ({ key: r.account_id, label: r.account_id, value: r.count })),
      region: (charts.identities_by_region ?? []).map((r) => ({ key: r.region, label: regionLabel(r.region), value: r.count })),
      credential: (charts.credential_types ?? []).map((r) => ({ key: r.type, label: credentialTypeLabel(r.type), value: r.count, to: `/credentials?credential_type=${encodeURIComponent(r.type)}` })),
    }[view];
    return rows.sort((a, b) => b.value - a.value);
  }, [charts, view]);
  const total = items.reduce((sum, item) => sum + (Number(item.value) || 0), 0);
  const color = view === 'credential' ? 'var(--t-series-2)' : 'var(--t-series-1)';
  const linkable = items.some((item) => item.to);
  return (
    <Panel className={className}>
      <PanelHeader
        icon={PieChart}
        title="What the inventory is made of"
        subtitle={view === 'credential' ? `${formatNumber(total)} credentials by type` : `${formatNumber(total)} identities by ${BREAKDOWNS.find((b) => b.value === view)?.label.toLowerCase()}`}
        actions={<SegmentedControl label="Break down by" value={view} onChange={setView} options={BREAKDOWNS} />}
      />
      <div className="mt-3">
        {loading ? (
          <ListSkeleton rows={6} />
        ) : items.length === 0 ? (
          <EmptyState compact title="Nothing in this scope" description="No records match the selected accounts and regions." />
        ) : (
          <BarChart
            items={items}
            total={total}
            color={color}
            label={BREAKDOWNS.find((b) => b.value === view)?.label}
            onSelect={linkable ? (item) => item.to && navigate(item.to) : undefined}
          />
        )}
        {!loading && (view === 'account' || view === 'region') && items.length > 0 && (
          <p className="mt-2 text-[11.5px] text-ink-3">The identity list cannot filter by {view} yet, so these bars do not open it.</p>
        )}
      </div>
    </Panel>
  );
}

/* ── Environment and status ──────────────────────────────────────────────── */

const ENV_COLORS = { production: 'var(--t-series-2)', staging: 'var(--t-series-4)', development: 'var(--t-series-3)', test: 'var(--t-series-5)', unknown: 'var(--t-series-8)' };
const STATUS_COLORS = { active: 'var(--t-series-3)', stopped: 'var(--t-series-6)', terminated: 'var(--t-series-8)', inactive: 'var(--t-series-8)', unknown: 'var(--t-series-8)' };

/**
 * Parts of a whole with a handful of slices each: the one job a donut does
 * better than a bar. Environment first (where production sits), then
 * lifecycle status.
 */
function MixPanel({ charts, loading, className }) {
  const navigate = useNavigate();
  const env = (charts?.identities_by_environment ?? []).map((r, i) => ({
    key: r.environment,
    /* Under the Environment heading, "Not set" says it without truncating. */
    label: !r.environment || r.environment === 'unknown' ? 'Not set' : environmentLabel(r.environment),
    value: r.count,
    color: ENV_COLORS[r.environment] ?? `var(--t-series-${(i % 7) + 1})`,
    to: r.environment && r.environment !== 'unknown' ? `/identities?environment=${encodeURIComponent(r.environment)}` : null,
  }));
  const status = (charts?.identities_by_status ?? []).map((r, i) => ({
    key: r.status,
    label: statusMeta(r.status).label,
    value: r.count,
    color: STATUS_COLORS[r.status] ?? `var(--t-series-${(i % 7) + 1})`,
    to: r.status && r.status !== 'unknown' ? `/identities?status=${encodeURIComponent(r.status)}` : null,
  }));
  const open = (slice) => slice.to && navigate(slice.to);
  return (
    <Panel className={className}>
      <PanelHeader icon={Users} title="Environment and status" subtitle="Where identities run, and whether they still do." />
      {loading ? (
        <div className="mt-4 grid gap-4">
          <Skeleton className="mx-auto size-32 rounded-full" />
          <ListSkeleton rows={3} />
        </div>
      ) : (
        <div className="mt-4 grid gap-6 @min-[34rem]:grid-cols-2">
          <section className="min-w-0">
            <h3 className="mb-2 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Environment</h3>
            {env.length ? <Donut slices={env} size={132} thickness={18} totalLabel="identities" title="Identities by environment" onSelect={open} /> : <p className="text-[12.5px] text-ink-3">Nothing recorded.</p>}
          </section>
          <section className="min-w-0">
            <h3 className="mb-2 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Status</h3>
            {status.length ? <Donut slices={status} size={132} thickness={18} totalLabel="identities" title="Identities by status" onSelect={open} /> : <p className="text-[12.5px] text-ink-3">Nothing recorded.</p>}
          </section>
        </div>
      )}
    </Panel>
  );
}

/* ── Owners ──────────────────────────────────────────────────────────────── */

/** top_owners (the five largest) and, beside them, how many have none. */
function OwnersPanel({ charts, kpis, loading, className }) {
  const navigate = useNavigate();
  const owners = (charts?.top_owners ?? []).map((r) => ({ key: r.owner, label: r.owner, value: r.count, to: `/identities?owner=${encodeURIComponent(r.owner)}` }));
  const total = kpis?.total_identities ?? 0;
  return (
    <Panel className={className}>
      <PanelHeader icon={Users} title="Who owns them" subtitle="The teams named as owner most often, and the identities with no owner." />
      <div className="mt-3">
        {loading ? (
          <ListSkeleton rows={5} />
        ) : owners.length === 0 ? (
          <EmptyState compact title="No owners recorded" description="No identity in this scope names an owner." />
        ) : (
          <BarChart items={owners} total={total} color="var(--t-series-3)" label="Identities by owner" onSelect={(item) => navigate(item.to)} />
        )}
        {!loading && kpis && (
          <p className="mt-3 flex items-center justify-between gap-3 border-t border-line pt-3 text-[12.5px]">
            <span className={cn('font-semibold', kpis.shadow_identities ? 'text-medium' : 'text-ink-3')}>No owner</span>
            <span data-numeric="" className="font-semibold text-ink">
              {formatNumber(kpis.shadow_identities)}
              <span className="ml-1.5 font-normal text-ink-3">of {formatNumber(total)}</span>
            </span>
          </p>
        )}
      </div>
    </Panel>
  );
}

/* ── Scan history ────────────────────────────────────────────────────────── */

/** The last ten scans, oldest to newest: identities found, failures marked. */
function ScanHistoryPanel({ history, loading, className }) {
  /* The API does not promise an order: sort by finish time, unfinished last. */
  const ordered = [...(history ?? [])].sort((a, b) => (parseDate(a.scan_end)?.getTime() ?? Infinity) - (parseDate(b.scan_end)?.getTime() ?? Infinity));
  const items = ordered.map((scan) => {
    const status = String(scan.status || '').toUpperCase();
    const failed = status === 'FAILED';
    const running = status !== 'COMPLETED' && !failed;
    return {
      key: scan.scan_id,
      label: scan.scan_id,
      tick: scan.scan_end ? DATE_DAY.format(new Date(scan.scan_end)) : 'Now',
      value: scan.total_identities,
      failed,
      flag: failed ? 'Failed' : running ? statusMeta(scan.status).label : undefined,
      flagColor: failed ? 'var(--t-critical)' : undefined,
      color: failed ? 'var(--t-critical)' : running ? 'var(--t-series-8)' : undefined,
      note: [
        scan.scan_end ? formatDateTime(scan.scan_end) : 'Not finished',
        failed ? 'Failed' : running ? statusMeta(scan.status).label : `${formatNumber(scan.total_credentials)} credentials`,
      ].join(' · '),
    };
  });
  const failures = items.filter((item) => item.failed).length;
  return (
    <Panel className={className}>
      <PanelHeader
        icon={History}
        title="Scan history"
        subtitle={`Identities found by each of the last ${items.length} scans, across every account.${failures ? ` ${failures} failed.` : ''}`}
      />
      <div className="mt-4">
        {loading ? (
          <ChartSkeleton height={180} />
        ) : items.length === 0 ? (
          <EmptyState compact title="No scans yet" description="Scans appear here once the scanner has run." />
        ) : (
          <ColumnChart items={items} height={180} unit="identities" title="Identities per scan" />
        )}
      </div>
    </Panel>
  );
}
