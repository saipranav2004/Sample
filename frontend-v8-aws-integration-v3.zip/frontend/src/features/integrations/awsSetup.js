/**
 * The AWS connection, as data: the documents the client pastes and the
 * checks the API runs. Every value comes from `GET /api/v1/integrations/aws`,
 * so what the page tells the client to type is exactly what the API verifies.
 */

export const AWS_CONSOLE = {
  iamRoles: 'https://console.aws.amazon.com/iam/home#/roles',
  eventBridgeRules: 'https://console.aws.amazon.com/events/home#/rules',
};

/** The trust policy for "Edit trust relationship", as an alternative to the clicks. */
export function trustPolicyJson(setup) {
  return JSON.stringify(
    {
      Version: '2012-10-17',
      Statement: [
        {
          Effect: 'Allow',
          Principal: { AWS: setup.assumerRoleArn },
          Action: 'sts:AssumeRole',
          Condition: { StringEquals: { 'sts:ExternalId': setup.externalId } },
        },
      ],
    },
    null,
    2,
  );
}

/** The EventBridge rule's custom event pattern. */
export function eventPatternJson(setup) {
  /* Four sources to a line: the same JSON as JSON.stringify, laid out to be
     read at a glance rather than one value per line. */
  const quoted = setup.eventSources.map((source) => JSON.stringify(source));
  const lines = [];
  for (let i = 0; i < quoted.length; i += 4) lines.push(quoted.slice(i, i + 4).join(', '));
  return `{\n  "source": [\n    ${lines.join(',\n    ')}\n  ]\n}`;
}

/** What a pasted role ARN should look like, with the client's account left open. */
export function exampleRoleArn(setup) {
  return `arn:aws:iam::<your-account-id>:role/${setup?.roleName || 'NHIPlatformCollector'}`;
}

const ROLE_ARN = /^arn:aws:iam::(\d{12}):role\/(?:[\x21-\x7E]+\/)?[\w+=,.@-]{1,64}$/;
const OTHER_IAM = /^arn:aws[\w-]*:iam::\d{12}:(user|group|policy|instance-profile|oidc-provider|saml-provider)\//;

/**
 * Checks a pasted role ARN before it is sent, with the same rules as the API
 * (`internal/awsconnect/arn.go`), so the common slips are caught as they are
 * typed. Returns '' when it looks right. The API checks again.
 */
export function roleArnProblem(value, platformAccountId) {
  const arn = String(value ?? '').trim();
  if (!arn) return 'Paste the ARN of the role you created.';
  const other = OTHER_IAM.exec(arn);
  if (other) return `That is an IAM ${other[1].replace('-', ' ')} ARN. Paste the role's ARN - it contains ":role/".`;
  const match = ROLE_ARN.exec(arn);
  if (!match) {
    if (arn.startsWith('arn:aws-')) return 'Only accounts in the standard AWS partition can be connected.';
    return 'That is not a role ARN. It looks like arn:aws:iam::123456789012:role/RoleName.';
  }
  if (platformAccountId && match[1] === platformAccountId) {
    return `That ARN is in our account (${platformAccountId}). Paste the ARN of the role you created in your own AWS account.`;
  }
  return '';
}

/** The account id inside a role ARN, or ''. */
export function accountOfRoleArn(value) {
  return ROLE_ARN.exec(String(value ?? '').trim())?.[1] ?? '';
}

/**
 * The three checks, in the order the API runs them, and the setup step that
 * fixes each one - so a failed check can open the step it points at.
 */
export const AWS_CHECKS = [
  { key: 'assume_role', label: 'Assume your role', step: 1 },
  { key: 'read_access', label: 'Read your account', step: 1 },
  { key: 'events', label: 'Receive your events', step: 2 },
];

export const AWS_STATUS = {
  not_connected: { label: 'Not connected', tone: 'neutral' },
  action_needed: { label: 'Needs attention', tone: 'medium' },
  connected: { label: 'Connected', tone: 'low' },
};

/**
 * The whole setup as Markdown, with this workspace's values filled in - for
 * the common case where the admin connecting the account is not the person
 * with access to that AWS account.
 */
export function setupGuideMarkdown(setup, regions = []) {
  const ruleRegions = regions.length
    ? `Create this rule in each of these regions: ${regions.map((code) => `\`${code}\``).join(', ')}${regions.includes('us-east-1') ? '' : ', and in `us-east-1` for IAM events'}.`
    : 'Create this rule in every region you use, and in us-east-1 for IAM events.';
  return `# Connect AWS to the NHI console

Two read-only changes in the AWS account you want to connect. About 10 minutes.

| Value | |
|---|---|
| Our account ID | \`${setup.accountId}\` |
| External ID | \`${setup.externalId}\` (unique to this workspace; keep it within your team) |
| Event bus ARN | \`${setup.eventBusArn}\` |
| Region | \`${setup.region}\` |

## Step 1 - Create the read-only IAM role

1. IAM → Roles → **Create role**.
2. Trusted entity: **AWS account** → **Another AWS account**.
3. Account ID: \`${setup.accountId}\`
4. Tick **Require external ID** and paste \`${setup.externalId}\`
5. Attach the AWS-managed policies: ${setup.managedPolicies.map((policy) => `\`${policy}\``).join(' and ')}
6. Role name: \`${setup.roleName}\` → **Create role**.
7. Open the role and copy its **ARN**. Send it back to whoever is connecting the account.

Alternatively, paste this trust policy under **Trust relationships → Edit trust policy**:

\`\`\`json
${trustPolicyJson(setup)}
\`\`\`

## Step 2 - Forward CloudTrail events

1. EventBridge → Rules → **Create rule**.
2. Name: \`${setup.ruleName}\`. Event bus: **default**. Rule type: **Rule with an event pattern**.
3. Event pattern → **Custom pattern (JSON)**:

\`\`\`json
${eventPatternJson(setup)}
\`\`\`

4. Target: **EventBridge event bus in a different account or Region**.
5. Event bus ARN: \`${setup.eventBusArn}\`
6. Keep **Create a new role for this specific resource** → **Create rule**.

${ruleRegions}

## Step 3 - Verify

On the console's Integrations page, paste the role ARN, choose the regions to read${regions.length ? ` (${regions.join(', ')})` : ''}, and choose **Verify connection**.
`;
}

/** The three setup steps: what each produces and roughly how long it takes. */
export const SETUP_STEPS = [
  { number: 1, title: 'Create the read-only IAM role', where: 'IAM console', minutes: 4 },
  { number: 2, title: 'Forward CloudTrail events', where: 'EventBridge console', minutes: 4 },
  { number: 3, title: 'Verify the connection', where: 'This page', minutes: 1 },
];
