import { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { AlertTriangle, ArrowRight, CheckCircle2, CircleDashed, Loader2, XCircle } from 'lucide-react';
import { EASE_OUT, SPRING } from '../../lib/motion';
import { formatRelative } from '../../lib/format';
import { CopyChip } from '../../ui/Copyable';
import { cn } from '../../ui/cn';
import { AWS_CHECKS } from './awsSetup';

const STATE = {
  pass: { icon: CheckCircle2, color: 'text-low', dot: 'bg-low', word: 'Passed' },
  fail: { icon: XCircle, color: 'text-critical', dot: 'bg-critical', word: 'Failed' },
  error: { icon: AlertTriangle, color: 'text-medium', dot: 'bg-medium', word: 'Not run' },
  skipped: { icon: CircleDashed, color: 'text-ink-3', dot: 'bg-surface-3', word: 'Waiting' },
  running: { icon: Loader2, color: 'text-brand', dot: 'bg-brand', word: 'Checking' },
};

const stateOf = (check) => (check && Object.hasOwn(STATE, check.state) ? check.state : 'skipped');

/** What each check proves, in one line - shown while it runs. */
const PROVES = {
  assume_role: 'sts:AssumeRole with your External ID',
  read_access: 'One read: iam:ListRoles',
  events: 'An event from your account reached our bus',
};

/**
 * Three dots, one per check, for a dense row. Hovering names each result.
 */
export function CheckDots({ checks }) {
  const byKey = new Map((checks ?? []).map((check) => [check.key, check]));
  return (
    <span className="inline-flex items-center gap-1" role="img" aria-label={AWS_CHECKS.map((meta) => `${meta.label}: ${STATE[stateOf(byKey.get(meta.key))].word}`).join(', ')}>
      {AWS_CHECKS.map((meta) => {
        const state = stateOf(byKey.get(meta.key));
        return (
          <span
            key={meta.key}
            title={`${meta.label}: ${STATE[state].word}`}
            className={cn('h-1.5 w-4 rounded-full', STATE[state].dot)}
          />
        );
      })}
    </span>
  );
}

/** Compact list for an account row: label and state, plus the fix when failed. */
export function CheckList({ checks }) {
  const byKey = new Map((checks ?? []).map((check) => [check.key, check]));
  return (
    <ul className="flex flex-col">
      {AWS_CHECKS.map((meta) => {
        const check = byKey.get(meta.key);
        const state = stateOf(check);
        const { icon: Icon, color, word } = STATE[state];
        return (
          <li key={meta.key} className="flex items-start gap-2.5 border-b border-line py-1.5 last:border-b-0">
            <Icon aria-hidden="true" className={cn('mt-0.5 size-4 shrink-0', color)} />
            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] text-ink">{check?.label || meta.label}</p>
              {state === 'fail' && check?.fix && (
                <p className="mt-0.5 text-[12px] text-ink-2">
                  <span className="font-semibold text-critical">Fix:</span> {check.fix}
                </p>
              )}
            </div>
            <span className={cn('shrink-0 text-[12px] font-medium', color)}>{word}</span>
          </li>
        );
      })}
    </ul>
  );
}

function Elapsed() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const started = Date.now();
    const id = setInterval(() => setSeconds(Math.floor((Date.now() - started) / 1000)), 250);
    return () => clearInterval(id);
  }, []);
  return <span data-numeric="">{seconds}s</span>;
}

/**
 * The outcome of "Verify connection".
 *
 * While the request runs, every check shows what it is about to prove and an
 * elapsed timer counts - the API answers for all three at once, so nothing
 * pretends to know which one it is on. Results then arrive one by one, and a
 * failed check opens with the exact place to fix it, the values filled in.
 *
 * `result` null with `running` false renders nothing.
 */
export function VerifyResult({ running, result, setup, onShowStep }) {
  const reduce = useReducedMotion();
  if (!running && !result) return null;
  const byKey = new Map((result?.checks ?? []).map((check) => [check.key, check]));
  const passed = (result?.checks ?? []).filter((check) => check.state === 'pass').length;
  const connected = !running && result?.status === 'connected';
  const tone = running ? 'running' : connected ? 'success' : 'attention';

  return (
    <div
      aria-live="polite"
      aria-busy={running || undefined}
      className={cn(
        'overflow-hidden rounded-[var(--radius-panel)] border',
        tone === 'success' ? 'border-low/40' : tone === 'attention' ? 'border-medium/40' : 'border-line',
      )}
    >
      <div
        className={cn(
          'flex items-center gap-3 px-4 py-3',
          tone === 'success' ? 'bg-low-soft' : tone === 'attention' ? 'bg-medium-soft' : 'bg-surface-2',
        )}
      >
        {running ? (
          <Loader2 aria-hidden="true" className="size-5 shrink-0 animate-spin text-brand" />
        ) : connected ? (
          <motion.span initial={reduce ? false : { scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={SPRING}>
            <CheckCircle2 aria-hidden="true" className="size-5 shrink-0 text-low" />
          </motion.span>
        ) : (
          <AlertTriangle aria-hidden="true" className="size-5 shrink-0 text-medium" />
        )}
        <div className="min-w-0 flex-1">
          <p className="text-[13.5px] font-semibold text-ink">
            {running ? 'Checking your account…' : connected ? 'Connection verified' : `${passed} of ${AWS_CHECKS.length} checks passed`}
          </p>
          <p className="text-[12px] text-ink-2">
            {running ? (
              <>
                Usually under 10 seconds · <Elapsed />
              </>
            ) : connected ? (
              'Read access works and your events are arriving.'
            ) : (
              <>
                Fix the {AWS_CHECKS.length - passed === 1 ? 'item' : 'items'} below, then verify again
                {result?.verifiedAt ? ` · checked ${formatRelative(result.verifiedAt)}` : ''}.
              </>
            )}
          </p>
        </div>
      </div>

      <ol className="divide-y divide-line bg-surface">
        {AWS_CHECKS.map((meta, index) => {
          const check = byKey.get(meta.key);
          const state = running ? 'running' : stateOf(check);
          const { icon: Icon, color, word } = STATE[state];
          return (
            <motion.li
              key={`${meta.key}-${running ? 'r' : 'd'}`}
              initial={reduce ? false : { opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.32, ease: EASE_OUT, delay: running ? 0 : index * 0.12 }}
              className="px-4 py-3"
            >
              <div className="flex items-start gap-3">
                <Icon aria-hidden="true" className={cn('mt-0.5 size-[18px] shrink-0', color, state === 'running' && 'animate-spin')} />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium text-ink">{meta.label}</p>
                  <p className="mt-0.5 text-[12px] text-ink-3">{running || !check?.message ? PROVES[meta.key] : check.message}</p>
                </div>
                <span className={cn('shrink-0 text-[12px] font-semibold', color)}>{word}</span>
              </div>
              {state === 'fail' && (
                <FixGuide check={check} meta={meta} setup={setup} onShowStep={onShowStep} />
              )}
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}

/** The one change that fixes a failed check, with where to make it. */
function FixGuide({ check, meta, setup, onShowStep }) {
  return (
    <div className="mt-2.5 ml-[30px] rounded-[var(--radius-control)] border border-critical/20 bg-critical-soft/50 px-3 py-2.5">
      <p className="text-[12.5px] font-semibold text-ink">{check.fix}</p>
      {setup && <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">{fixDetail(meta.key, setup)}</div>}
      {onShowStep && (
        <button
          type="button"
          onClick={() => onShowStep(meta.step)}
          className="mt-2 inline-flex items-center gap-1 text-[12.5px] font-medium text-brand hover:underline"
        >
          Open step {meta.step}
          <ArrowRight aria-hidden="true" className="size-3.5" />
        </button>
      )}
    </div>
  );
}

function fixDetail(key, setup) {
  switch (key) {
    case 'assume_role':
      return (
        <>
          In IAM, open <b className="font-semibold text-ink">{setup.roleName}</b> → Trust relationships. It must trust{' '}
          <CopyChip value={setup.accountId} label="our account ID" /> and require External ID{' '}
          <CopyChip value={setup.externalId} label="External ID" />. Also check you pasted the role&rsquo;s ARN.
        </>
      );
    case 'read_access':
      return (
        <>
          Open the role → Permissions → Add permissions, and attach{' '}
          {setup.managedPolicies.map((policy, index) => (
            <span key={policy}>
              {index > 0 && ' and '}
              <CopyChip value={policy} />
            </span>
          ))}
          .
        </>
      );
    case 'events':
      return (
        <>
          In EventBridge, open rule <CopyChip value={setup.ruleName} label="rule name" /> on the default bus. Its target must be{' '}
          <CopyChip value={setup.eventBusArn} label="event bus ARN" />. Just created it? Make a small change in that region (for
          example, tag an EC2 instance), wait a minute, then verify again.
        </>
      );
    default:
      return null;
  }
}
