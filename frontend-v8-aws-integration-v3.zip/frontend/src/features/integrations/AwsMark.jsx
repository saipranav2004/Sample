import { cn } from '../../ui/cn';

/**
 * The provider tile. AWS's own squid-ink and smile colours, so the tile reads
 * the same in light and dark themes and is recognised before it is read.
 */
export function AwsMark({ size = 'md', className }) {
  const box = size === 'lg' ? 'size-14 rounded-[14px]' : size === 'sm' ? 'size-8 rounded-[8px]' : 'size-10 rounded-[10px]';
  return (
    <span
      className={cn(
        'grid shrink-0 place-items-center bg-[#232f3e] shadow-[inset_0_0_0_1px_rgba(255,255,255,0.08),0_6px_16px_-8px_rgba(35,47,62,0.7)]',
        box,
        className,
      )}
    >
      <svg viewBox="0 0 64 40" aria-hidden="true" className="w-[72%]">
        <text
          x="32"
          y="22"
          textAnchor="middle"
          fill="#ffffff"
          fontFamily="Arial, Helvetica, sans-serif"
          fontWeight="700"
          fontSize="21"
          letterSpacing="-0.5"
        >
          aws
        </text>
        <path d="M13 28.5c11 6.5 27 6.5 37 0" fill="none" stroke="#ff9900" strokeWidth="3" strokeLinecap="round" />
        <path d="M45.5 26.2l5.2 1.9-2.1 5" fill="none" stroke="#ff9900" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="sr-only">Amazon Web Services</span>
    </span>
  );
}
