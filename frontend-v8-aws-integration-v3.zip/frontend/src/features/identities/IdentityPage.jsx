import { useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Activity, ArrowLeft, Braces, CalendarClock, Fingerprint, KeyRound, Network, Radar, ShieldCheck, Tags } from 'lucide-react';
import { fetchIdentityTab } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatDate, formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import {
  classColor,
  credentialBadge,
  credentialTypeLabel,
  environmentLabel,
  functionalClassLabel,
  identityBadge,
  identityTypeLabel,
  regionLabel,
  statusMeta,
  tokenLabel,
} from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { DataGrid } from '../../ui/DataGrid';
import { FactsCard } from '../../ui/FactsCard';
import { FilterSelect } from '../../ui/FilterBar';
import { gapText, KeyDates } from '../../ui/KeyDates';
import { Panel, PanelHeader } from '../../ui/Panel';
import { PropertyList } from '../../ui/PropertyList';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { SummaryStrip } from '../../ui/SummaryStrip';
import { SegmentedControl, Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { TypeBadge } from '../../ui/TypeBadge';
import { Unbroken } from '../../ui/Unbroken';
import { TagChips } from '../credentials/parts';
import { ActivityTab } from '../detail/ActivityTab';
import { NeedsAttention } from '../detail/NeedsAttention';
import { RawTab } from '../detail/RawTab';
import { RelationshipsTab } from '../detail/RelationshipsTab';
import { riskLevel } from '../detail/riskSignals';
import { AttributeList, JsonBlock, hasAttributes } from './JsonView';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DAY = 86_400_000;

const TABS = [
  { value: 'overview', label: 'Overview', icon: Fingerprint },
  { value: 'permissions', label: 'Permissions', icon: ShieldCheck },
  { value: 'activity', label: 'Activity', icon: Activity },
  { value: 'relationships', label: 'Relationships', icon: Network },
  { value: 'credentials', label: 'Credentials', icon: KeyRound },
  { value: 'raw', label: 'Raw record', icon: Braces },
];

/**
 * One identity: `GET /api/v1/identities/{id}?tab=`, one request per tab.
 * The overview loads with the page (the header needs it); every other tab
 * loads when opened. The tab is in the URL so a link lands on the part that
 * matters.
 *
 * The page reads top-down in the order an operator decides: what it is and
 * how risky (header and summary), what is wrong and what to do (needs
 * attention), what it can reach (credentials and their use), then the
 * reference material in the sidebar.
 */
export default function IdentityPage() {
  const { id } = useParams();
  const validId = UUID.test(id ?? '');
  const [searchParams, setSearchParams] = useSearchParams();
  const requested = searchParams.get('tab') || 'overview';
  const tab = TABS.some((entry) => entry.value === requested) ? requested : 'overview';

  const overview = useQuery((signal) => fetchIdentityTab(id, 'overview', {}, signal), [id], { enabled: validId });
  const data = overview.data;
  const identity = data?.identity;

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/identities" icon={ArrowLeft}>
      Identities
    </Button>
  );

  if (!validId || (overview.isError && !data)) {
    const missing = !validId || overview.error?.status === 404;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Identity" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={Fingerprint}
              title="No identity with that id"
              description="It is not in the latest completed scan, or the link is incomplete. Find it again from Identities."
              action={back}
            />
          ) : (
            <ErrorState error={overview.error} onRetry={overview.refetch} title="This identity could not be loaded" />
          )}
        </Panel>
      </div>
    );
  }

  if (!identity) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} meta={<Skeleton className="h-11 w-full max-w-3xl rounded" />} />
        <div className="grid gap-4 @min-[64rem]:grid-cols-[minmax(0,1fr)_22rem]">
          <Panel prominence="lead">
            <DetailSkeleton rows={6} />
          </Panel>
          <Panel>
            <DetailSkeleton rows={6} />
          </Panel>
        </div>
        <span role="status" className="sr-only">
          Loading identity
        </span>
      </div>
    );
  }

  const status = statusMeta(identity.status);
  const bound = data.bound_credentials ?? [];
  const risk = riskLevel(data.risk_signals);
  const granted = bound.reduce((sum, c) => sum + (Number(c.granted_actions_count) || 0), 0);
  const used = bound.reduce((sum, c) => sum + (Number(c.used_actions_count) || 0), 0);
  const tabs = TABS.map((entry) => (entry.value === 'credentials' ? { ...entry, count: bound.length } : entry));

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title={
            <span className="flex min-w-0 items-center gap-3">
              <TypeBadge size="lg" code={identityBadge(identity.identity_type)} color={classColor(identity.functional_class)} title={identityTypeLabel(identity.identity_type)} />
              <span className="min-w-0">
                <span className="block truncate font-mono">{identity.name || identity.arn}</span>
                <span className="mt-0.5 block text-[12.5px] font-medium tracking-normal text-ink-3">
                  <Unbroken text={`${identityTypeLabel(identity.identity_type)} · ${functionalClassLabel(identity.functional_class)} · account ${identity.account_id} · ${regionLabel(identity.region)}`} />
                </span>
              </span>
            </span>
          }
          actions={back}
          meta={
            <div className="flex flex-col gap-4">
              <div className="flex flex-wrap items-center gap-2">
                <Tag tone={status.tone} dot>
                  {status.label}
                </Tag>
                <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
                  <CopyableValue value={identity.arn} />
                </span>
              </div>
              <SummaryStrip
                items={[
                  { key: 'risk', label: 'Risk', value: risk.label, tone: risk.tone },
                  { key: 'owner', label: 'Owner', value: identity.owner || 'No owner', tone: identity.owner ? undefined : 'medium', sub: environmentLabel(identity.environment) },
                  {
                    key: 'active',
                    label: 'Last active',
                    value: identity.last_activity_at ? formatRelative(identity.last_activity_at) : 'No activity recorded',
                    tone: identity.last_activity_at && identity.idle_days >= 90 ? 'high' : undefined,
                    sub: identity.last_activity_at ? formatDate(identity.last_activity_at) : undefined,
                  },
                  {
                    key: 'reach',
                    label: 'Reachable from',
                    value: identity.is_publicly_accessible ? 'The internet' : 'Private network',
                    tone: identity.is_publicly_accessible ? 'critical' : undefined,
                    sub: identity.vpc_id ? identity.vpc_id : 'No VPC',
                  },
                  {
                    key: 'access',
                    label: 'Access used',
                    value: granted ? `${Math.round((used / granted) * 100)}% of granted` : 'Nothing granted',
                    tone: granted && used / granted < 0.5 ? 'high' : undefined,
                    sub: `${bound.length} credential${bound.length === 1 ? '' : 's'} · ${formatNumber(used)} of ${formatNumber(granted)} actions`,
                  },
                ]}
              />
            </div>
          }
          tabs={<Tabs size="sm" tabs={tabs} value={tab} onChange={setTab} />}
        />
      </Reveal>

      <Reveal key={tab}>
        {tab === 'overview' && <OverviewTab data={data} onOpen={setTab} />}
        {tab === 'permissions' && <PermissionsTab id={id} />}
        {tab === 'activity' && <ActivityTab kind="identity" id={id} />}
        {tab === 'relationships' && <RelationshipsTab kind="identity" id={id} name={identity.name || identity.arn} />}
        {tab === 'credentials' && <CredentialsTab id={id} />}
        {tab === 'raw' && <RawTab kind="identity" id={id} />}
      </Reveal>
    </Page>
  );
}

/* ── Overview ────────────────────────────────────────────────────────────── */

function OverviewTab({ data, onOpen }) {
  const identity = data.identity;
  const discovery = data.discovery ?? {};
  const [now] = useState(() => Date.now());
  const bound = data.bound_credentials ?? [];
  const groups = Array.isArray(identity.security_group_ids) ? identity.security_group_ids : [];
  const tags = data.tags && typeof data.tags === 'object' && !Array.isArray(data.tags) ? data.tags : {};
  const missingTags = Array.isArray(data.missing_tags) ? data.missing_tags : [];
  const created = parseDate(identity.created_at_aws);
  const found = parseDate(identity.first_seen_at);
  const unseen = created && found && found - created > DAY ? found - created : null;

  return (
    <div className="grid items-start gap-4 @min-[64rem]:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="flex min-w-0 flex-col gap-4">
        {/* 1. What is wrong, worst first, with the next step for each. */}
        <NeedsAttention signals={data.risk_signals} />

        {/* 2. What it can reach: the credentials it holds and how much of each it uses. */}
        <Panel flush className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[14.5px] font-semibold text-ink">Credentials it holds</h2>
              <p className="mt-0.5 text-[12.5px] text-ink-3">What it authenticates with, and how much of what each grants it actually used in 90 days.</p>
            </div>
            {bound.length > 0 && (
              <Button variant="ghost" size="sm" onClick={() => onOpen('permissions')}>
                See every permission
              </Button>
            )}
          </div>
          <DataGrid
            caption="Credentials it holds"
            density="compact"
            rows={bound}
            rowKey={(row) => row.credential_id}
            columns={[
              {
                key: 'name',
                header: 'Credential',
                primary: true,
                cell: (row) => {
                  const badge = credentialBadge(row.credential_type);
                  return (
                    <Link to={`/credentials/${encodeURIComponent(row.credential_id)}`} className="flex min-w-0 items-center gap-2.5 hover:underline">
                      <TypeBadge code={badge.code} color={badge.color} />
                      <span className="min-w-0">
                        <span className="block truncate font-medium text-ink">{row.name || row.credential_id}</span>
                        <span className="block truncate text-[11px] text-ink-3">{credentialTypeLabel(row.credential_type)}</span>
                      </span>
                    </Link>
                  );
                },
              },
              {
                key: 'binding_type',
                header: 'How it holds it',
                width: '180px',
                priority: 'wide',
                cell: (row) => (
                  <span className="flex items-center gap-1.5">
                    <span className="text-ink-2">{tokenLabel(row.binding_type)}</span>
                    {row.is_primary && <Tag size="sm" tone="neutral">Primary</Tag>}
                  </span>
                ),
              },
              {
                key: 'utilization',
                header: 'Actions used',
                width: '170px',
                cell: (row) =>
                  row.granted_actions_count ? (
                    <span className="flex items-center gap-2">
                      <span aria-hidden="true" className="h-1.5 w-16 overflow-hidden rounded-full bg-track">
                        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, row.utilization_pct)}%`, background: row.utilization_pct < 50 ? 'var(--t-high)' : 'var(--t-series-3)' }} />
                      </span>
                      <span data-numeric="" className="text-[12px] text-ink-2">
                        {row.used_actions_count} of {row.granted_actions_count}
                      </span>
                    </span>
                  ) : (
                    <span className="text-ink-3">No permissions</span>
                  ),
              },
            ]}
            emptyState={<EmptyState compact icon={KeyRound} title="Holds no credential" description="No credential is bound to this identity in the latest scan." />}
          />
        </Panel>

        {/* 3. Its dates, and the settings AWS reports for this kind of resource. */}
        <div className="grid items-start gap-4 @min-[44rem]:grid-cols-2">
          <Panel>
            <PanelHeader icon={CalendarClock} title="Key dates" subtitle={unseen ? `It existed for ${gapText(unseen)} before the scanner found it.` : undefined} />
            <KeyDates
              className="mt-3"
              now={now}
              dates={[
                { key: 'created', label: 'Created in AWS', at: identity.created_at_aws },
                { key: 'found', label: 'Discovered by the scanner', at: identity.first_seen_at, tone: unseen && unseen > 30 * DAY ? 'medium' : undefined },
                { key: 'active', label: 'Last active', at: identity.last_activity_at, tone: identity.idle_days >= 90 ? 'high' : undefined },
                { key: 'seen', label: 'Last seen by a scan', at: identity.last_seen_at },
              ]}
            />
          </Panel>
          {hasAttributes(data.type_attributes) ? (
            <Panel>
              <PanelHeader title={`${identityTypeLabel(identity.identity_type)} settings`} subtitle="Fields AWS reports for this kind of resource." />
              <div className="mt-3">
                <AttributeList value={data.type_attributes} />
              </div>
            </Panel>
          ) : (
            <Panel prominence="quiet">
              <PanelHeader title={`${identityTypeLabel(identity.identity_type)} settings`} prominence="quiet" subtitle="AWS reported no type-specific settings for this identity." />
            </Panel>
          )}
        </div>
      </div>

      {/* Reference: the sidebar. */}
      <aside className="flex min-w-0 flex-col gap-4" aria-label="Identity details">
        <Panel>
          <PanelHeader title="Details" />
          <PropertyList
            className="mt-2"
            rows={[
              { key: 'type', label: 'Type', value: identityTypeLabel(identity.identity_type) },
              { key: 'class', label: 'Class', value: functionalClassLabel(identity.functional_class) },
              { key: 'category', label: 'Category', value: identity.category },
              { key: 'owner', label: 'Owner', value: identity.owner || 'No owner', tone: identity.owner ? undefined : 'medium' },
              { key: 'env', label: 'Environment', value: environmentLabel(identity.environment) },
              { key: 'account', label: 'Account', value: identity.account_id, mono: true },
              { key: 'region', label: 'Region', value: regionLabel(identity.region) },
              { key: 'public', label: 'Internet', value: identity.is_publicly_accessible ? 'Publicly reachable' : 'Not reachable', tone: identity.is_publicly_accessible ? 'critical' : undefined },
              { key: 'vpc', label: 'VPC', value: identity.vpc_id, mono: true },
              { key: 'subnet', label: 'Subnet', value: identity.subnet_id, mono: true },
              { key: 'sg', label: 'Security groups', value: groups.length ? groups.join(', ') : null, mono: true },
              { key: 'creator', label: 'Created by', value: identity.created_by ? <CopyableValue value={identity.created_by} /> : null },
              identity.parent_arn ? { key: 'parent', label: 'Part of', value: <CopyableValue value={identity.parent_arn} /> } : null,
            ]}
          />
        </Panel>


        <Panel>
          <PanelHeader icon={Tags} title="Tags" subtitle={missingTags.length ? `Missing: ${missingTags.join(', ')}.` : 'Every expected tag is present.'} />
          <div className="mt-3">
            <TagChips tags={tags} />
          </div>
        </Panel>

        <Panel prominence="quiet">
          <PanelHeader icon={Radar} title="How it was found" prominence="quiet" />
          <PropertyList
            className="mt-2"
            rows={[
              { key: 'source', label: 'Source', value: discovery.discovery_source ? tokenLabel(discovery.discovery_source) : null },
              { key: 'resolved', label: 'Credential via', value: discovery.credential_resolution ? tokenLabel(discovery.credential_resolution) : null },
              { key: 'data', label: 'Data sources', value: discovery.data_sources },
              { key: 'scan', label: 'Scan', value: discovery.scan_id, mono: true },
              { key: 'id', label: 'ID', value: <CopyableValue value={identity.id} />, mono: true },
            ]}
          />
        </Panel>
      </aside>
    </div>
  );
}

/* ── Permissions ─────────────────────────────────────────────────────────── */

const SHOW = [
  { value: 'all', label: 'All' },
  { value: 'unused', label: 'Unused' },
  { value: 'used', label: 'Used' },
];

/**
 * `?tab=permissions`: every action its credentials grant, whether it was used
 * in the last 90 days, and which policy grants it. Unused grants are the
 * point: they are access to remove. The table filters in the page (the API
 * returns the whole set), so switching is instant.
 */
function PermissionsTab({ id }) {
  const query = useQuery((signal) => fetchIdentityTab(id, 'permissions', {}, signal), [id]);
  const [show, setShow] = useState('unused');
  const [service, setService] = useState('');
  const data = query.data;
  const permissions = useMemo(() => data?.permissions ?? [], [data]);
  const services = useMemo(() => {
    const counts = new Map();
    for (const p of permissions) counts.set(p.service, (counts.get(p.service) ?? 0) + 1);
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([value, count]) => ({ value, label: tokenLabel(value), count }));
  }, [permissions]);
  const rows = permissions
    .filter((p) => (show === 'all' ? true : show === 'used' ? p.used : !p.used))
    .filter((p) => !service || p.service === service)
    .map((p, index) => ({ ...p, _key: `${p.action}|${p.resource_arn}|${p.policy_source}|${index}` }));

  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Permissions could not be loaded" /></Panel>;
  const s = data?.summary;
  const policies = data?.policy_breakdown ?? [];
  const maxPolicy = Math.max(1, ...policies.map((p) => p.total_permissions));

  return (
    <div className="flex flex-col gap-4">
      <div className="grid items-start gap-4 @min-[60rem]:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        <Panel>
          <PanelHeader icon={ShieldCheck} title="Granted against used" subtitle="Actions its credentials allow, and how many it called in the last 90 days." />
          {!s ? (
            <div className="mt-4">
              <ListSkeleton rows={3} />
            </div>
          ) : (
            <div className="mt-4">
              <p className="flex items-baseline gap-2">
                <span data-numeric="" className="font-display text-[34px] leading-none font-extrabold text-ink">{Math.round(s.utilization_pct)}%</span>
                <span className="text-[12.5px] text-ink-3">used</span>
              </p>
              <div aria-hidden="true" className="mt-3 flex h-3 overflow-hidden rounded-full bg-track">
                <span className="h-full" style={{ width: `${s.granted_count ? (s.used_count / s.granted_count) * 100 : 0}%`, background: 'var(--t-series-3)' }} />
                <span className="h-full border-l-2 border-surface" style={{ width: `${s.granted_count ? (s.unused_count / s.granted_count) * 100 : 0}%`, background: 'var(--t-high)' }} />
              </div>
              <dl className="mt-3 grid grid-cols-3 gap-3">
                <div>
                  <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Granted</dt>
                  <dd data-numeric="" className="text-[17px] font-bold text-ink">{formatNumber(s.granted_count)}</dd>
                </div>
                <div>
                  <dt className="flex items-center gap-1.5 text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
                    <span aria-hidden="true" className="size-2 rounded-full bg-[var(--t-series-3)]" />
                    Used
                  </dt>
                  <dd data-numeric="" className="text-[17px] font-bold text-ink">{formatNumber(s.used_count)}</dd>
                </div>
                <div>
                  <dt className="flex items-center gap-1.5 text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">
                    <span aria-hidden="true" className="size-2 rounded-full bg-high" />
                    Unused
                  </dt>
                  <dd data-numeric="" className="text-[17px] font-bold text-high">{formatNumber(s.unused_count)}</dd>
                </div>
              </dl>
            </div>
          )}
        </Panel>
        <Panel>
          <PanelHeader title="By policy" subtitle="Each policy's actions, and how many of them were used." />
          <div className="mt-3">
            {!data ? (
              <ListSkeleton rows={4} />
            ) : policies.length === 0 ? (
              <p className="text-[12.5px] text-ink-3">No policies grant this identity anything.</p>
            ) : (
              <ul className="flex flex-col gap-2.5">
                {policies.map((p) => (
                  <li key={`${p.policy_type}-${p.policy_name}`}>
                    <p className="flex items-baseline justify-between gap-3 text-[12.5px]">
                      <span className="min-w-0 truncate font-medium text-ink" title={p.policy_name}>
                        {p.policy_name} <span className="font-normal text-ink-3">{tokenLabel(p.policy_type)}</span>
                      </span>
                      <span data-numeric="" className="shrink-0 text-ink-2">
                        {p.used_permissions} of {p.total_permissions} used
                      </span>
                    </p>
                    <span aria-hidden="true" className="mt-1 flex h-1.5 overflow-hidden rounded-full bg-track" style={{ width: `${(p.total_permissions / maxPolicy) * 100}%` }}>
                      <span className="h-full" style={{ width: `${p.total_permissions ? (p.used_permissions / p.total_permissions) * 100 : 0}%`, background: 'var(--t-series-3)' }} />
                      <span className="h-full flex-1" style={{ background: 'var(--t-high)' }} />
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Panel>
      </div>

      <Panel flush className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
          <div>
            <h2 className="text-[14px] font-semibold text-ink">Actions</h2>
            <p className="mt-0.5 text-[12.5px] text-ink-3">{data ? `${formatNumber(rows.length)} of ${formatNumber(permissions.length)} shown` : 'Loading…'}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <FilterSelect label="Service" value={service} options={services} onChange={setService} />
            <SegmentedControl label="Show" value={show} onChange={setShow} options={SHOW} />
          </div>
        </div>
        <DataGrid
          caption="Granted actions"
          density="compact"
          loading={!data}
          skeletonRows={8}
          rows={rows}
          rowKey={(row) => row._key}
          columns={[
            { key: 'action', header: 'Action', primary: true, width: '240px', cell: (row) => <span className="font-mono text-[12px] text-ink">{row.action}</span> },
            {
              key: 'resource_arn',
              header: 'On',
              cell: (row) => (
                /* A wildcard is flagged only where it grants: a Deny on * restricts. */
                <span className={`block truncate font-mono text-[11.5px] ${row.resource_arn === '*' && row.effect !== 'Deny' ? 'font-semibold text-high' : 'text-ink-2'}`} title={row.resource_arn}>
                  {row.resource_arn === '*' ? '* (every resource)' : row.resource_arn}
                </span>
              ),
            },
            { key: 'policy_source', header: 'Granted by', width: '190px', priority: 'wide', cell: (row) => <span className="block truncate text-ink-2" title={row.policy_source}>{row.policy_source}</span> },
            {
              key: 'used',
              header: 'Used',
              width: '160px',
              cell: (row) =>
                row.effect === 'Deny' ? (
                  <span className="text-ink-3">Denied</span>
                ) : row.used ? (
                  <span className="text-ink-2" title={row.last_used_at ? formatDateTime(row.last_used_at) : undefined}>
                    {row.last_used_at ? formatRelative(row.last_used_at) : 'Yes'}
                  </span>
                ) : (
                  <span className="whitespace-nowrap font-semibold text-high">Never in 90 days</span>
                ),
            },
          ]}
          emptyState={<EmptyState compact title={show === 'unused' ? 'Every granted action was used' : 'Nothing to show'} description={show === 'unused' ? 'Nothing here is excess: each action was called in the last 90 days.' : 'Change the filters to see more.'} />}
        />
      </Panel>
    </div>
  );
}

/* ── Credentials ─────────────────────────────────────────────────────────── */

/**
 * `?tab=credentials`: each credential it holds, with how it is bound, its
 * lifecycle, who may assume it and the policies attached to it.
 */
function CredentialsTab({ id }) {
  const query = useQuery((signal) => fetchIdentityTab(id, 'credentials', {}, signal), [id]);
  const data = query.data;
  if (query.isError && !data) return <Panel><ErrorState error={query.error} onRetry={query.refetch} title="Credentials could not be loaded" /></Panel>;
  if (!data) return <Panel><DetailSkeleton rows={6} /></Panel>;
  const list = data.credentials ?? [];
  if (list.length === 0) {
    return (
      <Panel>
        <EmptyState icon={KeyRound} title="Holds no credential" description="No credential is bound to this identity in the latest scan." />
      </Panel>
    );
  }
  return (
    <div className="flex flex-col gap-4">
      {list.map((c) => (
        <CredentialCard key={c.credential_id} credential={c} />
      ))}
    </div>
  );
}

function CredentialCard({ credential: c }) {
  const [showPolicy, setShowPolicy] = useState(null);
  const badge = credentialBadge(c.credential_type);
  const life = c.lifecycle ?? {};
  const principals = Array.isArray(c.trust_principals) ? c.trust_principals : [];
  const attached = Array.isArray(c.attached_policies) ? c.attached_policies : [];
  const inline = Array.isArray(c.inline_policies) ? c.inline_policies : [];
  const assumable = Array.isArray(c.assumable_roles) ? c.assumable_roles : [];
  const expires = parseDate(life.expires_at);
  return (
    <Panel>
      <header className="flex flex-wrap items-start justify-between gap-3">
        <Link to={`/credentials/${encodeURIComponent(c.credential_id)}`} className="flex min-w-0 items-center gap-3 hover:underline">
          <TypeBadge code={badge.code} color={badge.color} />
          <span className="min-w-0">
            <span className="block truncate text-[14px] font-semibold text-ink">{c.name || c.arn}</span>
            <span className="block truncate text-[12px] text-ink-3">
              {credentialTypeLabel(c.credential_type)} · {tokenLabel(c.binding_type)}
              {c.binding_source ? ` · found via ${c.binding_source}` : ''}
            </span>
          </span>
        </Link>
        {c.is_primary && <Tag tone="neutral">Primary credential</Tag>}
      </header>

      <FactsCard
        className="mt-3"
        facts={[
          { label: 'Last used', value: life.last_used_at ? formatRelative(life.last_used_at) : 'No use recorded', sub: life.last_used_at ? formatDateTime(life.last_used_at) : undefined },
          {
            label: 'Rotation',
            value: life.rotation_overdue ? 'Overdue' : life.rotation_enabled ? 'Automatic' : 'Off',
            tone: life.rotation_overdue ? 'high' : undefined,
            sub: life.last_rotated_at ? `Last ${formatDate(life.last_rotated_at)} (${life.days_since_rotation} days)` : 'Never rotated',
          },
          {
            label: 'Expires',
            value: expires ? formatRelative(life.expires_at) : 'Does not expire',
            tone: expires && expires.getTime() < Date.now() + 30 * DAY ? 'critical' : undefined,
            sub: expires ? formatDate(life.expires_at) : life.max_session_duration ? `Sessions up to ${Math.round(life.max_session_duration / 60)} min` : undefined,
          },
          { label: 'Permission boundary', value: life.permission_boundary_arn ? String(life.permission_boundary_arn).split('/').pop() : 'None', tone: life.permission_boundary_arn ? undefined : 'medium', mono: Boolean(life.permission_boundary_arn) },
          { label: 'Age', value: `${formatNumber(life.age_days)} days`, sub: life.created_at_aws ? `Created ${formatDate(life.created_at_aws)}` : undefined },
        ]}
      />

      <div className="mt-4 grid gap-4 @min-[56rem]:grid-cols-2">
        <section className="min-w-0">
          <h3 className="mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Who may use it</h3>
          {principals.length === 0 ? (
            <p className="text-[12.5px] text-ink-3">No trust principals recorded.</p>
          ) : (
            <ul className="flex flex-col divide-y divide-line">
              {principals.map((p) => (
                <li key={`${p.type}-${p.principal}`} className="flex items-center justify-between gap-3 py-1.5">
                  <span className="min-w-0">
                    <span className="block truncate font-mono text-[12px] text-ink" title={p.principal}>{p.principal}</span>
                    <span className="block text-[11px] text-ink-3">{p.type}{p.condition ? ` · if ${p.condition}` : ' · no condition'}</span>
                  </span>
                  {p.is_external && <Tag size="sm" tone="medium" dot>Other account</Tag>}
                </li>
              ))}
            </ul>
          )}
          {assumable.length > 0 && (
            <>
              <h3 className="mt-4 mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Roles it can assume</h3>
              <ul className="flex flex-col gap-1">
                {assumable.map((r) => (
                  <li key={r.target_role_arn ?? JSON.stringify(r)} className="truncate font-mono text-[12px] text-ink-2" title={r.target_role_arn}>
                    {r.target_role_arn ?? JSON.stringify(r)}
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>
        <section className="min-w-0">
          <h3 className="mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Policies</h3>
          {attached.length === 0 && inline.length === 0 ? (
            <p className="text-[12.5px] text-ink-3">No policies attached.</p>
          ) : (
            <ul className="flex flex-col divide-y divide-line">
              {attached.map((p) => (
                <li key={p.arn ?? p.name} className="py-1.5">
                  <button type="button" onClick={() => setShowPolicy(showPolicy === p.name ? null : p.name)} className="flex w-full items-center justify-between gap-3 text-left">
                    <span className="min-w-0 truncate text-[12.5px] font-medium text-ink">{p.name}</span>
                    <span className="shrink-0 text-[11.5px] text-brand">{showPolicy === p.name ? 'Hide' : 'Show'} document</span>
                  </button>
                  {showPolicy === p.name && p.document && (
                    <div className="mt-2">
                      <JsonBlock value={p.document} compact />
                    </div>
                  )}
                </li>
              ))}
              {inline.map((p) => (
                <li key={typeof p === 'string' ? p : p.name} className="flex items-center justify-between gap-3 py-1.5 text-[12.5px]">
                  <span className="truncate text-ink">{typeof p === 'string' ? p : p.name}</span>
                  <span className="shrink-0 text-[11.5px] text-ink-3">Inline</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </Panel>
  );
}
