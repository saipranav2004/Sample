import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Copy, Fingerprint, Globe2, Moon, SearchX } from 'lucide-react';
import { fetchIdentities } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatNumber } from '../../lib/format';
import { classColor, environmentLabel, functionalClassLabel, identityBadge, identityTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { identitySignals } from '../../lib/signals';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Freshness } from '../../ui/Freshness';
import { ListScopeNote } from '../../ui/ListScopeNote';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { RiskCell } from '../../ui/RiskCell';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { Tabs } from '../../ui/Tabs';
import { useToast } from '../../ui/Toast';
import { TypeBadge } from '../../ui/TypeBadge';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { cn } from '../../ui/cn';
import { RecordPreview } from '../preview/RecordPreview';
import { FILTER_KEYS, PAGE_SIZES, appliedCount, readListState } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const FILTER_LABELS = {
  search: 'Search',
  identity_type: 'Type',
  functional_class: 'Class',
  environment: 'Environment',
  status: 'Status',
  owner: 'Owner',
  vpc_id: 'VPC',
  is_publicly_accessible: 'Internet exposure',
  min_idle_days: 'Inactive for',
};

const IDLE_PRESETS = [30, 90, 180, 365];

/**
 * Identity inventory: `GET /api/v1/identities`, filtered, sorted and paged on
 * the server, from the latest completed scan across every account. All state
 * lives in the URL under the API's own parameter names, so a dashboard
 * drill-down, a bookmark and a shared link resolve to the same list.
 */
export default function IdentitiesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { railOpen, toggleRail } = useFacetRail();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);
  /* What an empty filter group says: still loading, failed, or genuinely nothing to pick. */
  const optionsNote = filterQuery.isError && !filterQuery.data ? 'Options could not be loaded.' : !filterQuery.data ? 'Loading…' : 'None in the latest scan.';

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => readDensity());

  /* Apply URL changes: every filter change returns to page one. */
  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      const text = Array.isArray(value) ? value.join(',') : value;
      if (text === '' || text === null || text === undefined) next.delete(key);
      else next.set(key, String(text));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next, { replace: false });
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);
  /* Back/forward or a link can change the search in the URL underneath. */
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const listKey = JSON.stringify([filters, page, limit, sort]);
  const list = useQuery(
    (signal) => fetchIdentities({ ...filters, page, page_size: limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
  );

  const rows = list.data?.data ?? [];
  const total = list.data?.pagination?.total_count ?? 0;
  const applied = appliedCount(filters);

  /* Index of the row open in the preview drawer. A new page of results closes
     it: its index would point at a different record. */
  const [peek, setPeek] = useState(null);
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }

  /* A page past the end (rows removed since the link was made) goes back to
     the last page that exists rather than showing an empty table. */
  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const facetGroups = useFacetGroups({ filters, options, update, optionsNote });
  const chips = FILTER_KEYS.flatMap((key) =>
    Array.isArray(filters[key])
      ? filters[key].length
        ? [{ key, label: FILTER_LABELS[key], value: filters[key].map((value) => describeValue(key, value)).join(', ') }]
        : []
      : filters[key]
        ? [{ key, label: FILTER_LABELS[key], value: describeValue(key, filters[key]) }]
        : [],
  );

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  /* View tabs: the inventory, and the two conditions people act on. Each count
     is the same request its tab makes. */
  const allCount = useQuery((signal) => fetchIdentities({ page_size: 1 }, signal), []);
  const exposedCount = useQuery((signal) => fetchIdentities({ is_publicly_accessible: 'true', page_size: 1 }, signal), []);
  const idleCount = useQuery((signal) => fetchIdentities({ min_idle_days: 90, page_size: 1 }, signal), []);
  const onlyKeys = (keys) => FILTER_KEYS.every((key) => keys.includes(key) || (Array.isArray(filters[key]) ? filters[key].length === 0 : !filters[key]));
  const view =
    filters.is_publicly_accessible === 'true' && onlyKeys(['is_publicly_accessible'])
      ? 'exposed'
      : filters.min_idle_days === '90' && onlyKeys(['min_idle_days'])
        ? 'idle'
        : applied === 0
          ? 'all'
          : '';
  const countOf = (query) => (query.data ? formatNumber(query.data.pagination.total_count) : undefined);
  const viewTabs = [
    { value: 'all', label: 'All identities', icon: Fingerprint, count: countOf(allCount) },
    { value: 'exposed', label: 'Internet-exposed', icon: Globe2, count: countOf(exposedCount) },
    { value: 'idle', label: 'Inactive 90+ days', icon: Moon, count: countOf(idleCount) },
  ];
  const setView = (next) => {
    setSearchDraft('');
    setSearchParams(next === 'exposed' ? { is_publicly_accessible: 'true' } : next === 'idle' ? { min_idle_days: '90' } : {});
  };

  const columns = [
    {
      key: 'name',
      header: 'Identity',
      primary: true,
      sortable: true,
      width: '24%',
      cell: (row) => (
        <span className="flex min-w-0 items-center gap-3">
          <TypeBadge code={identityBadge(row.identity_type)} color={classColor(row.functional_class)} className={cn(String(row.status).toLowerCase() !== 'active' && 'opacity-55 grayscale')} />
          <span className="min-w-0">
            <span className="block truncate text-[13px] font-semibold text-ink" title={row.name || row.arn}>
              {row.name || row.arn}
            </span>
            <span className="block truncate text-[11px] text-ink-3">
              {identityTypeLabel(row.identity_type)} · {functionalClassLabel(row.functional_class)}
            </span>
          </span>
        </span>
      ),
    },
    {
      /* The worst thing about the identity, read off the row itself. */
      key: 'risk',
      header: 'Needs attention',
      width: '190px',
      mobile: true,
      cell: (row) => <RiskCell signals={identitySignals(row)} />,
    },
    {
      key: 'functional_class',
      header: 'Class',
      sortable: true,
      width: '140px',
      /* Also on the identity line, so it is the first column to go. */
      priority: 'xl',
      cell: (row) => (
        <span className="flex min-w-0 items-center gap-2">
          <span aria-hidden="true" className="size-2 shrink-0 rounded-[3px]" style={{ background: classColor(row.functional_class) }} />
          <span className="truncate text-ink-2">{functionalClassLabel(row.functional_class)}</span>
        </span>
      ),
    },
    {
      key: 'owner',
      header: 'Owner',
      sortable: true,
      width: '150px',
      mobile: true,
      cell: (row) => (
        <span className="block min-w-0">
          {row.owner ? (
            <span className="block truncate text-ink" title={row.owner}>{row.owner}</span>
          ) : (
            <span className="block truncate text-high italic">No owner</span>
          )}
          <span className="block truncate text-[11px] text-ink-3">{environmentLabel(row.environment)}</span>
        </span>
      ),
    },
    {
      /* How many credentials it holds, and how much of what they grant it uses. */
      key: 'bound_credentials_count',
      header: 'Credentials',
      sortable: true,
      width: '132px',
      priority: 'wide',
      cell: (row) => <CredentialsCell count={row.bound_credentials_count} pct={row.permission_utilization_pct} />,
    },
    {
      key: 'account_id',
      header: 'Account',
      sortable: true,
      width: '128px',
      priority: 'xl',
      cell: (row) => (
        <span className="block min-w-0">
          <span className="block font-mono text-[12px]">{row.account_id}</span>
          <span className="block truncate text-[11px] text-ink-3">{regionLabel(row.region)}</span>
        </span>
      ),
    },
    {
      key: 'last_activity_at',
      header: 'Last active',
      sortable: true,
      width: '140px',
      mobile: true,
      cell: (row) => <Freshness value={row.last_activity_at} empty="No activity" emptyTitle="AWS records no activity for this identity" />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Identities"
          lede="Every non-human identity in the latest completed scan, across every account. Open one for its permissions, activity, relationships and the credentials it holds."
          tabs={<Tabs size="sm" tabs={viewTabs} value={view} onChange={setView} />}
        />
      </Reveal>

      <Reveal>
        <div ref={tableTop} className="scroll-mt-20">
          <WorkArea railOpen={railOpen} rail={<FacetRail groups={facetGroups} appliedCount={applied} onClearAll={clearAll} onClose={toggleRail} />}>
            <Panel flush className="overflow-hidden">
              <RecordBar
                trailing={
                  <TableToolbar>
                    {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                    <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                    <TableSettings
                      density={density}
                      onDensityChange={(value) => {
                        setDensity(value);
                        writeDensity(value);
                      }}
                    />
                  </TableToolbar>
                }
              >
                <SearchInput size="sm" value={searchDraft} onChange={setSearchDraft} maxLength={256} placeholder="Search name, ARN or tag…" className="w-full min-w-0 sm:max-w-sm" />
                <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'identity' : 'identities'} loading={list.isLoading && !list.data} />
              </RecordBar>

              <ListScopeNote />

              <AppliedFilters
                filters={chips}
                onRemove={(key) => {
                  if (key === 'search') setSearchDraft('');
                  update({ [key]: '' });
                }}
                onClearAll={clearAll}
              />

              {list.isError && !list.data ? (
                <ErrorState
                  error={list.error}
                  onRetry={list.error?.status === 400 ? undefined : list.refetch}
                  title={list.error?.status === 400 ? 'These filters were not accepted' : undefined}
                />
              ) : (
                <>
                  {list.isError && (
                    <div className="p-3">
                      <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                    </div>
                  )}
                  <DataGrid
                    caption="Identities"
                    columns={columns}
                    rows={rows}
                    rowKey={(row) => row.id}
                    loading={list.isLoading && !list.data}
                    refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                    onRowClick={(row, event) => {
                      if (event?.metaKey || event?.ctrlKey) window.open(`/identities/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                      else setPeek(rows.indexOf(row));
                    }}
                    selectedKey={peek !== null ? rows[peek]?.id : undefined}
                    rowLabel={(row) => `Preview ${row.name || row.arn}`}
                    sort={sort}
                    onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction })}
                    density={density}
                    skeletonRows={10}
                    rowActions={(row) => (
                      <IconButton
                        icon={Copy}
                        label={`Copy ARN for ${row.name || row.arn}`}
                        size="sm"
                        onClick={(event) => {
                          event.stopPropagation();
                          copyText(row.arn).then((ok) =>
                            notify(ok ? { variant: 'success', title: 'ARN copied', duration: 2200 } : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' }),
                          );
                        }}
                      />
                    )}
                    emptyState={
                      applied > 0 ? (
                        <EmptyState
                          icon={SearchX}
                          title="No identities match these filters"
                          description="Remove a filter or change the search to widen the list."
                          action={
                            <Button variant="secondary" size="sm" onClick={clearAll}>
                              Clear all filters
                            </Button>
                          }
                        />
                      ) : (
                        <EmptyState title="No identities discovered yet" description="Identities appear here after the scanner completes a discovery run on a connected AWS account." />
                      )
                    }
                  />
                  {total > 0 && (
                    <Pagination
                      page={page}
                      pageSize={limit}
                      total={total}
                      pageSizes={PAGE_SIZES}
                      unit={total === 1 ? 'identity' : 'identities'}
                      scrollTarget={tableTop}
                      onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                      onPageSizeChange={(size) => update({ page_size: size })}
                    />
                  )}
                </>
              )}
            </Panel>
          </WorkArea>
        </div>
      </Reveal>
      <RecordPreview kind="identity" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

/** Credentials held, and the share of their granted actions used in 90 days. */
function CredentialsCell({ count, pct }) {
  const n = Number(count) || 0;
  if (n === 0) return <span className="text-ink-3">None</span>;
  const used = Math.round(Number(pct) || 0);
  return (
    <span className="block min-w-0" title={`${n} credential${n === 1 ? '' : 's'}; ${used}% of their granted actions used in the last 90 days`}>
      <span className="block text-ink">
        {formatNumber(n)} <span className="text-ink-3">held</span>
      </span>
      <span className="mt-0.5 flex items-center gap-1.5 text-[11px] text-ink-3">
        <span aria-hidden="true" className="h-1 w-10 overflow-hidden rounded-full bg-track">
          <span className="block h-full rounded-full" style={{ width: `${Math.max(used ? 4 : 0, used)}%`, background: used < 50 ? 'var(--t-high)' : 'var(--t-series-3)' }} />
        </span>
        {used}% used
      </span>
    </span>
  );
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacetGroups({ filters, options, update, optionsNote }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner);
  const [vpcDraft, setVpcDraft] = useState(filters.vpc_id);
  useEffect(() => setOwnerDraft(filters.owner), [filters.owner]);
  useEffect(() => setVpcDraft(filters.vpc_id), [filters.vpc_id]);

  /* A multi-value group: ticking toggles one value in the comma list. A value
     that came in on a link but holds no records now still shows, so it can be
     cleared. */
  const multi = (key, label, rows, describe) => {
    const selected = filters[key];
    const known = rows.map((row) => row.value);
    const all = [...rows, ...selected.filter((value) => !known.includes(value)).map((value) => ({ value, count: undefined }))];
    return {
      key,
      label,
      options: all.map((row) => ({ value: row.value, label: describe(row.value), count: row.count, active: selected.includes(row.value) })),
      onToggle: (value) => update({ [key]: selected.includes(value) ? selected.filter((v) => v !== value) : [...selected, value] }),
      emptyText: optionsNote,
    };
  };

  const textFilter = (key, draft, setDraft, placeholder, hint) => (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        update({ [key]: draft.trim().slice(0, 256) });
      }}
      className="flex flex-col gap-1.5"
    >
      <Input
        size="sm"
        value={draft}
        maxLength={256}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={() => {
          if (draft.trim() !== filters[key]) update({ [key]: draft.trim().slice(0, 256) });
        }}
        placeholder={placeholder}
        aria-label={FILTER_LABELS[key]}
        spellCheck={false}
      />
      <span className="text-[11px] text-ink-3">{hint}</span>
    </form>
  );

  const idle = IDLE_PRESETS.map((days) => ({ value: String(days), label: `${days}+ days`, active: filters.min_idle_days === String(days) }));
  if (filters.min_idle_days && !IDLE_PRESETS.map(String).includes(filters.min_idle_days)) {
    idle.push({ value: filters.min_idle_days, label: `${filters.min_idle_days}+ days`, active: true });
  }

  /* Ordered by how a reviewer narrows the inventory: what it is, the risk
     questions (exposed, idle), where it runs and its state, then the exact
     ownership and network fields. */
  return [
    multi('identity_type', 'Type', options.identityTypes, identityTypeLabel),
    multi('functional_class', 'Class', options.functionalClasses, functionalClassLabel),
    {
      key: 'is_publicly_accessible',
      label: 'Internet exposure',
      single: true,
      options: [
        { value: 'true', label: 'Publicly accessible', active: filters.is_publicly_accessible === 'true' },
        { value: 'false', label: 'Not public', active: filters.is_publicly_accessible === 'false' },
      ],
      onToggle: (value) => update({ is_publicly_accessible: value }),
    },
    {
      key: 'min_idle_days',
      label: 'Inactive for',
      single: true,
      options: idle,
      onToggle: (value) => update({ min_idle_days: value }),
      note: 'Counted from the last recorded activity, or from creation when AWS records none.',
    },
    { ...multi('environment', 'Environment', options.environments, environmentLabel), defaultOpen: false },
    { ...multi('status', 'Status', options.statuses, (value) => statusMeta(value).label), defaultOpen: false },
    {
      key: 'owner',
      label: 'Owner',
      defaultOpen: Boolean(filters.owner),
      activeCount: filters.owner ? 1 : 0,
      content: textFilter('owner', ownerDraft, setOwnerDraft, 'e.g. platform-team', 'Exact owner. Press Enter to apply.'),
    },
    {
      key: 'vpc_id',
      label: 'VPC',
      defaultOpen: Boolean(filters.vpc_id),
      activeCount: filters.vpc_id ? 1 : 0,
      content: textFilter('vpc_id', vpcDraft, setVpcDraft, 'vpc-0abc123', 'Exact VPC id. Press Enter to apply.'),
    },
  ];
}

function describeValue(key, value) {
  switch (key) {
    case 'identity_type':
      return identityTypeLabel(value);
    case 'functional_class':
      return functionalClassLabel(value);
    case 'environment':
      return environmentLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'is_publicly_accessible':
      return value === 'true' ? 'Public' : 'Not public';
    case 'min_idle_days':
      return `${value}+ days`;
    default:
      return value;
  }
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */

function readDensity() {
  try {
    return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
  } catch {
    return 'comfortable';
  }
}

function writeDensity(value) {
  try {
    localStorage.setItem(DENSITY_KEY, value);
  } catch {
    /* a reading preference; safe to lose */
  }
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
