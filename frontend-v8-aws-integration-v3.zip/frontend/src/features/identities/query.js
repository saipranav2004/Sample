/**
 * The identity list's URL state, read and validated against the rules
 * `GET /api/v1/identities` enforces. The URL uses the API's own parameter
 * names, so a link, a bookmark and the request are the same thing. A
 * hand-edited link with a value the API would reject is dropped here instead
 * of turning the screen into a 400.
 */

/* sort_by values the API accepts (identitiesSortColumns). */
export const SORTABLE = [
  'name',
  'identity_type',
  'functional_class',
  'account_id',
  'region',
  'environment',
  'owner',
  'status',
  'last_activity_at',
  'created_at_aws',
  'age_days',
  'idle_days',
  'bound_credentials_count',
];

export const PAGE_SIZES = [25, 50, 100];
export const DEFAULT_LIMIT = 25;
/* Name order: predictable, and the API sorts empty dates first when descending. */
export const DEFAULT_SORT = { key: 'name', direction: 'asc' };

const TOKEN = /^[a-zA-Z0-9_.:-]{1,100}$/;
const VPC = /^vpc-[a-z0-9]{1,32}$/;

function cleanText(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  return text.length > 256 || /[\0\r\n]/.test(text) ? '' : text;
}

function positiveInt(value, fallback, max) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1 && n <= max ? n : fallback;
}

/** Multi-value filters travel comma-separated. */
export const MULTI_KEYS = ['identity_type', 'functional_class', 'environment', 'status'];

/** Every filter the screen supports, as it appears in the URL and the API. */
export const FILTER_KEYS = ['search', ...MULTI_KEYS, 'owner', 'vpc_id', 'is_publicly_accessible', 'min_idle_days'];

export function splitList(value) {
  return cleanText(value)
    .split(',')
    .map((part) => part.trim())
    .filter((part) => TOKEN.test(part));
}

export function readListState(searchParams) {
  const get = (key) => cleanText(searchParams.get(key) ?? '');
  const idle = Number(get('min_idle_days'));
  const filters = {
    search: get('search'),
    identity_type: splitList(get('identity_type')),
    functional_class: splitList(get('functional_class')),
    environment: splitList(get('environment')),
    status: splitList(get('status')),
    owner: get('owner'),
    vpc_id: VPC.test(get('vpc_id')) ? get('vpc_id') : '',
    is_publicly_accessible: ['true', 'false'].includes(get('is_publicly_accessible')) ? get('is_publicly_accessible') : '',
    min_idle_days: Number.isInteger(idle) && idle >= 0 && idle <= 36500 && get('min_idle_days') !== '' ? String(idle) : '',
  };
  const sortBy = SORTABLE.includes(get('sort_by')) ? get('sort_by') : DEFAULT_SORT.key;
  const sortOrder = get('sort_order') === 'asc' ? 'asc' : get('sort_order') === 'desc' ? 'desc' : DEFAULT_SORT.direction;
  return {
    filters,
    page: positiveInt(get('page'), 1, 1_000_000),
    limit: PAGE_SIZES.includes(Number(get('page_size'))) ? Number(get('page_size')) : DEFAULT_LIMIT,
    sort: { key: sortBy, direction: sortOrder },
  };
}

export function appliedCount(filters) {
  return FILTER_KEYS.filter((key) => (Array.isArray(filters[key]) ? filters[key].length > 0 : Boolean(filters[key]))).length;
}
