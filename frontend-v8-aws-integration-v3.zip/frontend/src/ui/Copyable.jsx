import { useEffect, useRef, useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { cn } from './cn';

/**
 * Writes text to the clipboard. The async Clipboard API needs a secure
 * context (https or localhost) and can be refused by policy; the selection
 * fallback covers a console opened over plain http on an internal host.
 */
export async function copyText(value) {
  const text = String(value ?? '');
  try {
    if (navigator.clipboard?.writeText && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to the selection fallback */
  }
  try {
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand('copy');
    area.remove();
    return ok;
  } catch {
    return false;
  }
}

/** `copied` turns true for a moment after a successful `copy()`. */
function useCopy(value) {
  const [copied, setCopied] = useState(false);
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);
  const copy = async (event) => {
    event?.stopPropagation();
    const ok = await copyText(value);
    setCopied(ok);
    clearTimeout(timer.current);
    if (ok) timer.current = setTimeout(() => setCopied(false), 1600);
  };
  return { copied, copy };
}

/**
 * ARNs, commit hashes and file paths are copied far more often than they are
 * read, so every one of them gets a one-click copy affordance.
 */
export function CopyButton({ value, label = 'Copy', className, size = 'md' }) {
  const { copied, copy } = useCopy(value);

  if (!value) return null;

  return (
    <button
      type="button"
      onClick={copy}
      aria-label={copied ? 'Copied to clipboard' : label}
      title={copied ? 'Copied' : label}
      className={cn(
        'grid shrink-0 place-items-center rounded-md transition-colors',
        size === 'sm' ? 'size-6' : 'size-7',
        copied ? 'text-low' : 'text-ink-3 hover:bg-surface-3 hover:text-ink-2',
        className,
      )}
    >
      {copied ? (
        <Check aria-hidden="true" className="size-3.5" />
      ) : (
        <Copy aria-hidden="true" className="size-3.5" />
      )}
    </button>
  );
}

/** Monospace value plus copy control, aligned for use inside detail lists. */
export function CopyableValue({ value, mono = true, className, children }) {
  if (!value) return <span className="text-ink-3">-</span>;
  return (
    <span className={cn('inline-flex min-w-0 max-w-full items-center gap-1.5', className)}>
      <span className={cn('min-w-0 truncate', mono && 'font-mono text-[12.5px]')} title={value}>
        {children ?? value}
      </span>
      <CopyButton value={value} size="sm" />
    </span>
  );
}

/**
 * A value inside running instructions ("Account ID: [123456789012]") that
 * copies itself when clicked. The whole chip is the target, because in a
 * step-by-step guide the value is the thing the hand is reaching for.
 */
export function CopyChip({ value, label, className }) {
  const { copied, copy } = useCopy(value);
  if (!value) return null;
  return (
    <button
      type="button"
      onClick={copy}
      title={copied ? 'Copied' : 'Click to copy'}
      aria-label={copied ? `Copied ${label ?? value}` : `Copy ${label ?? value}`}
      className={cn(
        'inline-flex max-w-full min-w-0 items-center gap-1.5 rounded-md border px-1.5 py-0.5 align-middle font-mono text-[12px] transition-colors',
        copied
          ? 'border-low/40 bg-low-soft text-low'
          : 'border-line bg-inset text-ink hover:border-line-strong hover:bg-surface-3',
        className,
      )}
    >
      <span className="min-w-0 break-all text-left">{value}</span>
      {copied ? (
        <Check aria-hidden="true" className="size-3 shrink-0" />
      ) : (
        <Copy aria-hidden="true" className="size-3 shrink-0 text-ink-3" />
      )}
    </button>
  );
}

/** A labelled value in a box, with a copy button that says what it does. */
export function CopyField({ label, value, hint, className }) {
  const { copied, copy } = useCopy(value);
  return (
    <div className={cn('flex min-w-0 flex-col gap-1 rounded-[var(--radius-control)] border border-line bg-surface-2 px-3 py-2.5', className)}>
      <span className="text-[11px] font-semibold tracking-wide text-ink-3 uppercase">{label}</span>
      <div className="flex min-w-0 items-start gap-2">
        <span className="min-w-0 flex-1 font-mono text-[12.5px] leading-relaxed break-all text-ink">{value || '-'}</span>
        {value && (
          <button
            type="button"
            onClick={copy}
            aria-label={copied ? `${label} copied` : `Copy ${label}`}
            className={cn(
              'inline-flex h-7 shrink-0 items-center gap-1 rounded-md border px-2 text-[11.5px] font-medium transition-colors',
              copied ? 'border-low/40 bg-low-soft text-low' : 'border-line-strong bg-surface text-ink-2 hover:bg-surface-3 hover:text-ink',
            )}
          >
            {copied ? <Check aria-hidden="true" className="size-3.5" /> : <Copy aria-hidden="true" className="size-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        )}
      </div>
      {hint && <span className="text-[11.5px] text-ink-3">{hint}</span>}
    </div>
  );
}
