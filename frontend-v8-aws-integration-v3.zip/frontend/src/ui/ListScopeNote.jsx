import { Info } from 'lucide-react';
import { formatRelative } from '../lib/format';
import { optionsOf, useFilterOptions } from '../lib/useFilterOptions';
import { useScope } from '../lib/useScope';

/**
 * The identity and credential lists always read the latest completed scan
 * across every account; the API applies no saved scope to them. This line
 * says so, and when the dashboard is set to fewer accounts or an older scan
 * it says that too, so a count that differs between the two is explained
 * where it is seen.
 */
export function ListScopeNote() {
  const options = optionsOf(useFilterOptions());
  const scope = useScope();
  const latest = options.scans[0];
  const s = scope.data;
  const accountIds = options.accounts.map((account) => account.id);
  const fewerAccounts = s && accountIds.length > 0 && accountIds.some((id) => !s.accounts.includes(id));
  const olderScan = s && latest && s.scanId && s.scanId !== latest.scan_id;
  if (!latest) return null;
  return (
    <p className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 border-b border-line bg-surface px-3 py-1.5 text-[11.5px] text-ink-3">
      <Info aria-hidden="true" className="size-3.5 shrink-0" />
      <span>
        Latest completed scan, <span className="font-mono text-[11px] text-ink-2">{latest.scan_id}</span>
        {latest.scan_end ? ` (${formatRelative(latest.scan_end)})` : ''}, every account.
      </span>
      {(fewerAccounts || olderScan) && (
        <span>
          Your dashboard is set to {fewerAccounts ? `${s.accounts.length} of ${accountIds.length} accounts` : 'all accounts'}
          {olderScan ? ` and scan ${s.scanId}` : ''}, so its counts can differ.
        </span>
      )}
    </p>
  );
}
