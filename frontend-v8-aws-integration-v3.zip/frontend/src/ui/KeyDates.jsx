import { formatDate, formatDateTime, formatRelative, parseDate } from '../lib/format';
import { TONE_VAR, cn } from './cn';

const DAY = 86_400_000;

/** "3 days", "5 months", "1 year 2 months": the gap between two dates, in words. */
export function gapText(ms) {
  const days = Math.round(Math.abs(ms) / DAY);
  if (days < 1) return 'Same day';
  if (days < 60) return `${days} day${days === 1 ? '' : 's'}`;
  const months = Math.round(days / 30.44);
  if (months < 24) return `${months} month${months === 1 ? '' : 's'}`;
  const years = Math.floor(months / 12);
  const rest = months % 12;
  return `${years} year${years === 1 ? '' : 's'}${rest ? ` ${rest} month${rest === 1 ? '' : 's'}` : ''}`;
}

/**
 * The dates that matter on a record, oldest first, on one vertical line.
 * Between two dates the time that passed is written on the line, so a long
 * silence reads without arithmetic. Today sits where it falls, so a future
 * date (an expiry, a rotation due) is visibly ahead of it. Dates the API does
 * not have are listed under the line as not recorded, never drawn.
 *
 * dates: [{ key, label, at, note?, tone? }]. A tone colours the dot and marks
 * a date to notice (expired, overdue, long idle).
 */
export function KeyDates({ dates, now, className }) {
  const dated = dates
    .map((item) => ({ ...item, time: parseDate(item.at)?.getTime() ?? null }))
    .filter((item) => item.time !== null)
    .sort((a, b) => a.time - b.time);
  const missing = dates.filter((item) => !parseDate(item.at));
  const points = [...dated];
  const ahead = points.findIndex((item) => item.time > now);
  points.splice(ahead === -1 ? points.length : ahead, 0, { key: '__today', label: 'Today', time: now, today: true });

  /* Dates and the gaps between them alternate as rows; the line runs through all of them. */
  const rows = [];
  points.forEach((point, index) => {
    if (index > 0) {
      const gap = point.time - points[index - 1].time;
      rows.push({ key: `gap-${point.key}`, gap: gap >= DAY ? gapText(gap) : null });
    }
    rows.push({ ...point, first: index === 0, last: index === points.length - 1 });
  });

  return (
    <div className={className}>
      <ol>
        {rows.map((row) =>
          'gap' in row ? (
            <li key={row.key} aria-hidden={row.gap ? undefined : 'true'} className="grid grid-cols-[11px_minmax(0,1fr)] gap-x-3">
              <span className="flex justify-center">
                <span className="w-px bg-line-strong" />
              </span>
              <span className="py-1 text-[11px] text-ink-3">{row.gap ? `${row.gap} later` : ' '}</span>
            </li>
          ) : (
            <li key={row.key} className="grid grid-cols-[11px_minmax(0,1fr)] gap-x-3">
              <span className="relative flex justify-center">
                {/* The line through the dot, stopping at the first and last dates. */}
                <span aria-hidden="true" className={cn('absolute w-px bg-line-strong', row.first ? 'top-2 bottom-0' : row.last ? 'top-0 h-2' : 'inset-y-0')} />
                <span
                  aria-hidden="true"
                  className={cn('relative mt-[3px] size-[11px] rounded-full border-2', row.today ? 'border-ink-3 bg-surface' : 'border-surface')}
                  style={row.today ? undefined : { background: TONE_VAR[row.tone] ?? 'var(--t-brand)' }}
                />
              </span>
              {row.today ? (
                <p className="text-[12px] font-medium text-ink-3">Today</p>
              ) : (
                <div className="min-w-0">
                  <p className="text-[13px] leading-snug font-semibold text-ink">{row.label}</p>
                  <p className="text-[12px] text-ink-3" title={formatDateTime(row.at)}>
                    {formatDate(row.at)} · {formatRelative(row.at)}
                  </p>
                  {row.note && <p className="text-[12px] text-ink-2">{row.note}</p>}
                </div>
              )}
            </li>
          ),
        )}
      </ol>
      {missing.length > 0 && (
        <p className="mt-3 border-t border-line pt-2 text-[11.5px] text-ink-3">Not recorded: {missing.map((item) => item.label.toLowerCase()).join(', ')}.</p>
      )}
    </div>
  );
}
