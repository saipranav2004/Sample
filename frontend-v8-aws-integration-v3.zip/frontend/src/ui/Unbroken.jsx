/**
 * Text whose hyphenated words (regions like us-west-2, team and resource
 * names) never wrap at the hyphen. The characters are left as typed, so
 * copied text still searches.
 */
export function Unbroken({ text }) {
  return String(text)
    .split(/(\S+-\S+)/)
    .map((part, index) =>
      index % 2 ? (
        <span key={index} className="whitespace-nowrap">
          {part}
        </span>
      ) : (
        part
      ),
    );
}
