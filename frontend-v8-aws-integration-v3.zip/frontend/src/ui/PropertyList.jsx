import { cn } from './cn';

/**
 * Label and value pairs for a record's sidebar: a narrow label column so the
 * value gets the width. A row without a value says "Not recorded" rather than
 * disappearing, so the reader knows the field exists and is empty.
 * rows: [{ key, label, value, mono?, tone? }]
 */
export function PropertyList({ rows, className }) {
  return (
    <dl className={cn('divide-y divide-line', className)}>
      {rows.filter(Boolean).map((row) => (
        <div key={row.key ?? row.label} className="grid grid-cols-[7.5rem_minmax(0,1fr)] gap-3 py-2">
          <dt className="text-[12px] text-ink-3">{row.label}</dt>
          <dd
            className={cn('min-w-0 text-[12.5px] break-words text-ink', row.mono && 'font-mono text-[12px]', row.tone && 'font-semibold')}
            style={row.tone ? { color: `var(--t-${row.tone})` } : undefined}
          >
            {row.value === null || row.value === undefined || row.value === '' ? <span className="font-normal text-ink-3">Not recorded</span> : row.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
