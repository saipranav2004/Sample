import { cn } from './cn';

/**
 * The few facts that decide what to do with a record, in one row under its
 * title: label above, value below, separated by hairlines. Wraps into a grid
 * on narrow screens. items: [{ key, label, value, sub?, tone? }]
 */
export function SummaryStrip({ items, className }) {
  return (
    <dl className={cn('grid grid-cols-2 gap-x-6 gap-y-3 sm:flex sm:flex-wrap sm:gap-0 sm:divide-x sm:divide-line', className)}>
      {items.filter(Boolean).map((item) => (
        <div key={item.key} className="min-w-0 sm:px-5 sm:first:pl-0">
          <dt className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{item.label}</dt>
          <dd className={cn('mt-0.5 truncate text-[14px] font-semibold', item.tone ? '' : 'text-ink')} style={item.tone ? { color: `var(--t-${item.tone})` } : undefined}>
            {item.value}
          </dd>
          {item.sub && <dd className="truncate text-[11.5px] text-ink-3">{item.sub}</dd>}
        </div>
      ))}
    </dl>
  );
}
