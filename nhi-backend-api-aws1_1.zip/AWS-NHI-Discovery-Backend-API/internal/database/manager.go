// // Package database owns every PostgreSQL connection pool used by the API.
// //
// //   - Global()  → the authentication / tenant-registry database (config: global_database)
// //   - Tenant(n) → the DATA database named n, opened lazily and cached
// //
// // Database names are never hard-coded: the global name and the default data
// // name come from configs/config.yaml, and per-tenant names come from the
// // db_name claim of the (signed) JWT, which in turn comes from the tenants
// // table of the global database.
// package database

// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"
// 	"regexp"
// 	"strings"
// 	"sync"
// 	"time"

// 	_ "github.com/jackc/pgx/v5/stdlib"

// 	"nhi-backend-api/internal/config"
// )

// const driverName = "pgx"

// // PostgreSQL identifiers we are willing to connect to / reference.
// var identRe = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_\-]{0,62}$`)

// // ErrInvalidDBName is returned when a database name fails validation.
// var ErrInvalidDBName = errors.New("invalid database name")

// type Manager struct {
// 	global      *sql.DB
// 	globalCfg   config.DatabaseConfig
// 	dataCfg     config.DatabaseConfig // template for every tenant data DB
// 	defaultData string
// 	mu          sync.RWMutex
// 	tenantPools map[string]*sql.DB
// }

// // NewManager connects to the global database (fail-fast) and verifies that the
// // default data database is reachable. Other tenant databases are opened on demand.
// func NewManager(cfg *config.Config) (*Manager, error) {
// 	if err := ValidateName(cfg.GlobalDatabase.DBName()); err != nil {
// 		return nil, fmt.Errorf("global_database.database_name: %w", err)
// 	}
// 	if err := ValidateName(cfg.Database.DBName()); err != nil {
// 		return nil, fmt.Errorf("database.database_name: %w", err)
// 	}

// 	m := &Manager{
// 		globalCfg:   cfg.GlobalDatabase,
// 		dataCfg:     cfg.Database,
// 		defaultData: cfg.Database.DBName(),
// 		tenantPools: make(map[string]*sql.DB),
// 	}

// 	g, err := openPool(&m.globalCfg, 20, 10)
// 	if err != nil {
// 		return nil, fmt.Errorf("global database: %w", err)
// 	}
// 	m.global = g
// 	fmt.Printf("✅ Global (auth) DB connected → db=%s\n", m.globalCfg.DBName())

// 	// Warm + verify the default data DB so mis-configuration is caught at start-up.
// 	if _, err := m.Tenant(m.defaultData); err != nil {
// 		_ = g.Close()
// 		return nil, fmt.Errorf("default data database: %w", err)
// 	}
// 	return m, nil
// }

// // Global returns the pool for the authentication / tenant-registry database.
// func (m *Manager) Global() *sql.DB { return m.global }

// // GlobalSchema is the optional schema holding the global tables ("" if unset).
// func (m *Manager) GlobalSchema() string { return strings.TrimSpace(m.globalCfg.Schema) }

// // DataSchema is the optional schema holding the tenant data tables ("" if unset).
// func (m *Manager) DataSchema() string { return strings.TrimSpace(m.dataCfg.Schema) }

// // DefaultDataDBName is the data DB used when a tenant has no db_name of its own.
// func (m *Manager) DefaultDataDBName() string { return m.defaultData }

// // Tenant returns the pool for the data database dbName. An empty name resolves
// // to the default data database from config. Pools are created once and reused.
// func (m *Manager) Tenant(dbName string) (*sql.DB, error) {
// 	dbName = strings.TrimSpace(dbName)
// 	if dbName == "" {
// 		dbName = m.defaultData
// 	}
// 	if err := ValidateName(dbName); err != nil {
// 		return nil, err
// 	}

// 	m.mu.RLock()
// 	pool, ok := m.tenantPools[dbName]
// 	m.mu.RUnlock()
// 	if ok {
// 		return pool, nil
// 	}

// 	m.mu.Lock()
// 	defer m.mu.Unlock()
// 	if pool, ok = m.tenantPools[dbName]; ok { // someone else opened it meanwhile
// 		return pool, nil
// 	}

// 	cfg := m.dataCfg // copy: same host/credentials, different database
// 	cfg.DatabaseName = dbName
// 	cfg.LegacyName = ""

// 	pool, err := openPool(&cfg, 10, 5)
// 	if err != nil {
// 		return nil, fmt.Errorf("open tenant database %q: %w", dbName, err)
// 	}
// 	m.tenantPools[dbName] = pool
// 	fmt.Printf("✅ Tenant data DB connected → db=%s\n", dbName)
// 	return pool, nil
// }

// // Close releases every pool.
// func (m *Manager) Close() {
// 	if m == nil {
// 		return
// 	}
// 	m.mu.Lock()
// 	defer m.mu.Unlock()
// 	for name, p := range m.tenantPools {
// 		_ = p.Close()
// 		delete(m.tenantPools, name)
// 	}
// 	if m.global != nil {
// 		_ = m.global.Close()
// 	}
// }

// // ValidateName checks that name is a safe PostgreSQL database identifier.
// func ValidateName(name string) error {
// 	if !identRe.MatchString(name) {
// 		return fmt.Errorf("%w: %q", ErrInvalidDBName, name)
// 	}
// 	return nil
// }

// // Table returns a safely quoted, optionally schema-qualified table reference,
// // e.g. Table("nhi_schema", "accounts") → "nhi_schema"."accounts".
// // An empty schema yields just "accounts" (resolved through search_path).
// func Table(schema, table string) string {
// 	if strings.TrimSpace(schema) == "" {
// 		return quoteIdent(table)
// 	}
// 	return quoteIdent(schema) + "." + quoteIdent(table)
// }

// func quoteIdent(s string) string {
// 	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
// }

// func openPool(cfg *config.DatabaseConfig, maxOpen, maxIdle int) (*sql.DB, error) {
// 	connStr := strings.TrimSpace(cfg.GetConnectionString())
// 	if cfg.DBName() == "" || connStr == "" {
// 		return nil, errors.New("empty database name / connection string")
// 	}

// 	db, err := sql.Open(driverName, connStr)
// 	if err != nil {
// 		return nil, fmt.Errorf("open postgres: %w", err)
// 	}
// 	db.SetMaxOpenConns(maxOpen)
// 	db.SetMaxIdleConns(maxIdle)
// 	db.SetConnMaxLifetime(30 * time.Minute)

// 	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	defer cancel()
// 	if err := db.PingContext(ctx); err != nil {
// 		_ = db.Close()
// 		return nil, fmt.Errorf("ping postgres: %w", err)
// 	}
// 	return db, nil
// }
















// Package database owns every PostgreSQL connection pool used by the API.
//
//   - Global()  → the authentication / tenant-registry database (config: global_database)
//   - Tenant(n) → the DATA database named n, opened lazily and cached
//
// The only database name in config is the global one. Every tenant's data
// database name comes from the tenants table (db_name) of the global database,
// travels in the signed JWT, and is opened on demand. There is NO default
// data database: a tenant without a db_name is an error, never a fallback.
package database

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"sync"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"

	"nhi-backend-api/internal/config"
)

const driverName = "pgx"

// PostgreSQL identifiers we are willing to connect to / reference.
var identRe = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_\-]{0,62}$`)

// ErrInvalidDBName is returned when a database name fails validation.
var ErrInvalidDBName = errors.New("invalid database name")

// ErrTenantDBNotConfigured is returned when a tenant has no db_name.
var ErrTenantDBNotConfigured = errors.New("tenant database is not configured")

type Manager struct {
	global      *sql.DB
	globalCfg   config.DatabaseConfig
	dataCfg     config.DatabaseConfig // server settings template (host/user/password/schema) for tenant DBs
	mu          sync.RWMutex
	tenantPools map[string]*sql.DB
}

// NewManager connects to the global database (fail-fast). Tenant databases are
// opened on demand the first time a request for that tenant arrives.
func NewManager(cfg *config.Config) (*Manager, error) {
	if err := ValidateName(cfg.GlobalDatabase.DBName()); err != nil {
		return nil, fmt.Errorf("global_database.database_name: %w", err)
	}

	m := &Manager{
		globalCfg:   cfg.GlobalDatabase,
		dataCfg:     cfg.Database,
		tenantPools: make(map[string]*sql.DB),
	}

	g, err := openPool(&m.globalCfg, 20, 10)
	if err != nil {
		return nil, fmt.Errorf("global database: %w", err)
	}
	m.global = g
	fmt.Printf("✅ Global (auth) DB connected → db=%s\n", m.globalCfg.DBName())
	return m, nil
}

// Global returns the pool for the authentication / tenant-registry database.
func (m *Manager) Global() *sql.DB { return m.global }

// GlobalSchema is the optional schema holding the global tables ("" if unset).
func (m *Manager) GlobalSchema() string { return strings.TrimSpace(m.globalCfg.Schema) }

// DataSchema is the optional schema holding the tenant data tables ("" if unset).
func (m *Manager) DataSchema() string { return strings.TrimSpace(m.dataCfg.Schema) }

// Tenant returns the pool for the data database dbName. An empty name is an
// error (ErrTenantDBNotConfigured) — there is no default database.
// Pools are created once and reused.
func (m *Manager) Tenant(dbName string) (*sql.DB, error) {
	dbName = strings.TrimSpace(dbName)
	if dbName == "" {
		return nil, ErrTenantDBNotConfigured
	}
	if err := ValidateName(dbName); err != nil {
		return nil, err
	}

	m.mu.RLock()
	pool, ok := m.tenantPools[dbName]
	m.mu.RUnlock()
	if ok {
		return pool, nil
	}

	m.mu.Lock()
	defer m.mu.Unlock()
	if pool, ok = m.tenantPools[dbName]; ok { // someone else opened it meanwhile
		return pool, nil
	}

	cfg := m.dataCfg // copy: same host/credentials, different database
	cfg.DatabaseName = dbName
	cfg.LegacyName = ""

	pool, err := openPool(&cfg, 10, 5)
	if err != nil {
		return nil, fmt.Errorf("open tenant database %q: %w", dbName, err)
	}
	m.tenantPools[dbName] = pool
	fmt.Printf("✅ Tenant data DB connected → db=%s\n", dbName)
	return pool, nil
}

// Close releases every pool.
func (m *Manager) Close() {
	if m == nil {
		return
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	for name, p := range m.tenantPools {
		_ = p.Close()
		delete(m.tenantPools, name)
	}
	if m.global != nil {
		_ = m.global.Close()
	}
}

// ValidateName checks that name is a safe PostgreSQL database identifier.
func ValidateName(name string) error {
	if !identRe.MatchString(name) {
		return fmt.Errorf("%w: %q", ErrInvalidDBName, name)
	}
	return nil
}

// Table returns a safely quoted, optionally schema-qualified table reference,
// e.g. Table("nhi_schema", "accounts") → "nhi_schema"."accounts".
// An empty schema yields just "accounts" (resolved through search_path).
func Table(schema, table string) string {
	if strings.TrimSpace(schema) == "" {
		return quoteIdent(table)
	}
	return quoteIdent(schema) + "." + quoteIdent(table)
}

func quoteIdent(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func openPool(cfg *config.DatabaseConfig, maxOpen, maxIdle int) (*sql.DB, error) {
	connStr := strings.TrimSpace(cfg.GetConnectionString())
	if cfg.DBName() == "" || connStr == "" {
		return nil, errors.New("empty database name / connection string")
	}

	db, err := sql.Open(driverName, connStr)
	if err != nil {
		return nil, fmt.Errorf("open postgres: %w", err)
	}
	db.SetMaxOpenConns(maxOpen)
	db.SetMaxIdleConns(maxIdle)
	db.SetConnMaxLifetime(30 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}
	return db, nil
}