package newapi

// ── Endpoint 4: Identities List ─────────────────────────────────────────────
// Body of GET /api/v1/identities.

type IdentitiesListResponse struct {
	Pagination Pagination         `json:"pagination"`
	Data       []IdentityListItem `json:"data"`
}

type Pagination struct {
	Page       int `json:"page"`
	PageSize   int `json:"page_size"`
	TotalCount int `json:"total_count"`
	TotalPages int `json:"total_pages"`
}

type IdentityListItem struct {
	ID                       string  `json:"id"`
	Name                     string  `json:"name"`
	ARN                      string  `json:"arn"`
	IdentityType             string  `json:"identity_type"`
	FunctionalClass          string  `json:"functional_class"`
	AccountID                string  `json:"account_id"`
	Region                   string  `json:"region"`
	Environment              string  `json:"environment"`
	Owner                    string  `json:"owner"`
	Status                   string  `json:"status"`
	IsPubliclyAccessible     bool    `json:"is_publicly_accessible"`
	VpcID                    *string `json:"vpc_id"`
	BoundCredentialsCount    int     `json:"bound_credentials_count"`
	LastActivityAt           *string `json:"last_activity_at"` // RFC3339 UTC, null if never active
	CreatedAtAWS             *string `json:"created_at_aws"`   // RFC3339 UTC
	AgeDays                  int     `json:"age_days"`
	IdleDays                 int     `json:"idle_days"`
	CreatedBy                string  `json:"created_by"`
	PermissionUtilizationPct float64 `json:"permission_utilization_pct"`
}