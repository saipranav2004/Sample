package newapi

// UpdateSettingsRequest is the body of PUT /api/v1/settings.
type UpdateSettingsRequest struct {
	SelectedAccountIDs []string `json:"selected_account_ids"`
	SelectedRegions    []string `json:"selected_regions"`
	SelectedScanID     *string  `json:"selected_scan_id"`
}

// SavedSettings is what was stored, echoed back in the response.
type SavedSettings struct {
	SelectedAccountIDs []string `json:"selected_account_ids"`
	SelectedRegions    []string `json:"selected_regions"`
	SelectedScanID     *string  `json:"selected_scan_id"`
}

// UpdateSettingsResponse matches the spec's response shape exactly:
// { "success": true, "settings": { ... } }
type UpdateSettingsResponse struct {
	Success  bool          `json:"success"`
	Settings SavedSettings `json:"settings"`
}