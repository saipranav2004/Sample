// package newapi

// // ─────────────────────────────────────────────────────────────────────────
// // GET /api/v1/credentials/:id?tab=  (Endpoint 7: Credential Detail)
// // Six tabs: overview, trust, activity, rotation, relationships, raw.
// // Types are prefixed Cred/Credential to avoid collisions with Identity
// // Detail's models (OverviewResponse, RiskSignal, etc. already exist in
// // this package for identities).
// // ─────────────────────────────────────────────────────────────────────────

// // ── tab=overview ────────────────────────────────────────────────────────

// type CredentialOverviewResponse struct {
// 	Tab             string                 `json:"tab"`
// 	Credential      CredentialOverviewCore `json:"credential"`
// 	BoundIdentities []CredBoundIdentity    `json:"bound_identities"`
// 	RiskSignals     []CredRiskSignal       `json:"risk_signals"`
// 	TypeAttributes  interface{}            `json:"type_attributes"`
// }

// type CredentialOverviewCore struct {
// 	ID                    string  `json:"id"`
// 	Name                  string  `json:"name"`
// 	ARN                   string  `json:"arn"`
// 	CredentialType        string  `json:"credential_type"`
// 	Category              string  `json:"category"`
// 	AccountID             string  `json:"account_id"`
// 	Region                string  `json:"region"`
// 	Status                string  `json:"status"`
// 	OwnerPrincipalARN     *string `json:"owner_principal_arn"`
// 	CreatedAtAWS          *string `json:"created_at_aws"`
// 	AgeDays               *int    `json:"age_days"`
// 	LastUsedAt            *string `json:"last_used_at"`
// 	IdleDays              *int    `json:"idle_days"`
// 	LastRotatedAt         *string `json:"last_rotated_at"`
// 	DaysSinceRotation     *int    `json:"days_since_rotation"`
// 	RotationEnabled       bool    `json:"rotation_enabled"`
// 	RotationIntervalDays  *int    `json:"rotation_interval_days"`
// 	RotationStatus        string  `json:"rotation_status"`
// 	ExpiresAt             *string `json:"expires_at"`
// 	DaysUntilExpiry       *int    `json:"days_until_expiry"`
// 	MaxSessionDuration    *int    `json:"max_session_duration"`
// 	PermissionBoundaryARN *string `json:"permission_boundary_arn"`
// }

// type CredBoundIdentity struct {
// 	IdentityID     string  `json:"identity_id"`
// 	Name           string  `json:"name"`
// 	IdentityType   string  `json:"identity_type"`
// 	AccountID      string  `json:"account_id"`
// 	Status         string  `json:"status"`
// 	LastActivityAt *string `json:"last_activity_at"`
// 	BindingType    string  `json:"binding_type"`
// }

// type CredRiskSignal struct {
// 	Signal   string `json:"signal"`
// 	Status   bool   `json:"status"`
// 	Severity string `json:"severity"`
// }

// // ── tab=trust ───────────────────────────────────────────────────────────

// type CredentialTrustResponse struct {
// 	Tab                         string                     `json:"tab"`
// 	TrustPolicy                 CredTrustPolicyBlock       `json:"trust_policy"`
// 	AttachedPolicies            interface{}                `json:"attached_policies"`
// 	InlinePolicies              interface{}                `json:"inline_policies"`
// 	EffectivePermissionsSummary []CredEffectivePermSummary `json:"effective_permissions_summary"`
// 	AssumableRoles              []CredAssumableRole        `json:"assumable_roles"`
// 	PermissionBoundary          CredPermissionBoundary     `json:"permission_boundary"`
// }

// type CredTrustPolicyBlock struct {
// 	Raw        interface{}          `json:"raw"`
// 	Principals []CredTrustPrincipal `json:"principals"`
// 	Warnings   []string             `json:"warnings"`
// }

// type CredTrustPrincipal struct {
// 	Principal  string  `json:"principal"`
// 	Type       string  `json:"type"`
// 	Condition  *string `json:"condition"`
// 	IsExternal bool    `json:"is_external"`
// }

// type CredEffectivePermSummary struct {
// 	Service        string `json:"service"`
// 	AllowedActions int    `json:"allowed_actions"`
// 	DeniedActions  int    `json:"denied_actions"`
// 	ResourceScope  string `json:"resource_scope"`
// }

// type CredAssumableRole struct {
// 	TargetRoleARN string  `json:"target_role_arn"`
// 	TargetAccount string  `json:"target_account"`
// 	Conditions    *string `json:"conditions"`
// 	LastAssumed   *string `json:"last_assumed"`
// }

// type CredPermissionBoundary struct {
// 	BoundaryARN          *string  `json:"boundary_arn"`
// 	EffectiveRestriction *string  `json:"effective_restriction"`
// 	ActionsBlocked       []string `json:"actions_blocked"`
// }

// // ── tab=activity ────────────────────────────────────────────────────────

// type CredentialActivityResponse struct {
// 	Tab                           string                `json:"tab"`
// 	TimeRange                     string                `json:"time_range"`
// 	VolumeChart                   []CredVolumePoint     `json:"volume_chart"`
// 	RecentEvents                  []CredRecentEvent     `json:"recent_events"`
// 	IdentitiesUsingThisCredential []CredUsingIdentity   `json:"identities_using_this_credential"`
// 	Analytics                     CredActivityAnalytics `json:"analytics"`
// 	EventsPagination              CredEventsPagination  `json:"events_pagination"`
// }

// type CredVolumePoint struct {
// 	Date  string `json:"date"`
// 	Count int    `json:"count"`
// }

// type CredRecentEvent struct {
// 	EventTime   *string `json:"event_time"`
// 	EventName   string  `json:"event_name"`
// 	Service     string  `json:"service"`
// 	ResourceARN *string `json:"resource_arn"`
// 	SourceIP    *string `json:"source_ip"`  // identity_usage has no source_ip column — always null
// 	Region      *string `json:"region"`     // identity_usage has no region column — always null
// 	UserAgent   *string `json:"user_agent"` // identity_usage has no user_agent column — always null
// 	ErrorCode   *string `json:"error_code"` // identity_usage has no error_code column — always null
// 	EventCount  int     `json:"event_count"` // extra field: identity_usage is pre-aggregated
// }

// type CredUsingIdentity struct {
// 	IdentityID     string  `json:"identity_id"`
// 	Name           string  `json:"name"`
// 	IdentityType   string  `json:"identity_type"`
// 	SourceIP       *string `json:"source_ip"`        // not available — always null
// 	LastAction     *string `json:"last_action"`      // not reliably attributable per-identity — always null
// 	LastActionTime *string `json:"last_action_time"` // same limitation — always null
// }

// type CredActivityAnalytics struct {
// 	SourceIPs     []CredIPPct      `json:"source_ips"` // always empty — no source_ip column
// 	ActiveRegions []CredRegionCnt  `json:"active_regions"`
// 	TopServices   []CredServicePct `json:"top_services"`
// 	UsagePattern  string           `json:"usage_pattern"`
// 	ErrorRatePct  *float64         `json:"error_rate_pct"` // always null — no error tracking column
// }

// type CredIPPct struct {
// 	IP  string  `json:"ip"`
// 	Pct float64 `json:"pct"`
// }

// type CredRegionCnt struct {
// 	Region string `json:"region"`
// 	Count  int    `json:"count"`
// }

// type CredServicePct struct {
// 	Service string  `json:"service"`
// 	Pct     float64 `json:"pct"`
// 	Count   int     `json:"count"`
// }

// type CredEventsPagination struct {
// 	Page       int `json:"page"`
// 	PageSize   int `json:"page_size"`
// 	TotalCount int `json:"total_count"`
// 	TotalPages int `json:"total_pages"`
// }

// // ── tab=rotation ────────────────────────────────────────────────────────

// type CredentialRotationResponse struct {
// 	Tab           string                `json:"tab"`
// 	Timeline      []CredRotationEvent   `json:"timeline"`
// 	Configuration CredRotationConfig    `json:"configuration"`
// 	Lifecycle     CredRotationLifecycle `json:"lifecycle"`
// }

// type CredRotationEvent struct {
// 	Date    string `json:"date"`
// 	Event   string `json:"event"`
// 	Details string `json:"details"`
// }

// type CredRotationConfig struct {
// 	AutoRotation         bool    `json:"auto_rotation"`
// 	RotationIntervalDays *int    `json:"rotation_interval_days"`
// 	LastRotation         *string `json:"last_rotation"`
// 	NextExpected         *string `json:"next_expected"`
// 	Status               string  `json:"status"`
// 	RotationLambdaARN    *string `json:"rotation_lambda_arn"` // not tracked in this schema — always null
// }

// type CredRotationLifecycle struct {
// 	CreatedAtAWS      *string `json:"created_at_aws"`
// 	AgeDays           *int    `json:"age_days"`
// 	DaysSinceRotation *int    `json:"days_since_rotation"`
// 	ExpiresAt         *string `json:"expires_at"`
// 	DaysUntilExpiry   *int    `json:"days_until_expiry"`
// }

// // ── tab=relationships ───────────────────────────────────────────────────

// type CredentialRelationshipsResponse struct {
// 	Tab               string                `json:"tab"`
// 	Graph             CredRelationshipGraph `json:"graph"`
// 	RelationshipTable []CredRelationshipRow `json:"relationship_table"`
// }

// type CredRelationshipGraph struct {
// 	Nodes []CredGraphNode `json:"nodes"`
// 	Edges []CredGraphEdge `json:"edges"`
// }

// type CredGraphNode struct {
// 	ARN       string `json:"arn"`
// 	Name      string `json:"name"`
// 	Type      string `json:"type"` // credential | identity | resource | unknown
// 	Subtype   string `json:"subtype"`
// 	IsCurrent bool   `json:"is_current"`
// }

// type CredGraphEdge struct {
// 	Source         string  `json:"source"`
// 	Target         string  `json:"target"`
// 	EdgeType       string  `json:"edge_type"`
// 	LastObservedAt *string `json:"last_observed_at"`
// }

// type CredRelationshipRow struct {
// 	Relationship string  `json:"relationship"`
// 	Direction    string  `json:"direction"` // inbound | outbound
// 	TargetARN    string  `json:"target_arn"`
// 	TargetName   string  `json:"target_name"`
// 	TargetType   string  `json:"target_type"`
// 	LastActive   *string `json:"last_active"`
// }

// // ── tab=raw ─────────────────────────────────────────────────────────────

// type CredentialRawResponse struct {
// 	Tab                  string                 `json:"tab"`
// 	CredentialRecord     map[string]interface{} `json:"credential_record"`
// 	RawAPIResponse       interface{}            `json:"raw_api_response"`
// 	TrustPolicy          interface{}            `json:"trust_policy"`
// 	AttachedPolicies     interface{}            `json:"attached_policies"`
// 	InlinePolicies       interface{}            `json:"inline_policies"`
// 	TypeAttributes       interface{}            `json:"type_attributes"`
// 	EffectivePermissions interface{}            `json:"effective_permissions"`
// }








































package newapi

// ─────────────────────────────────────────────────────────────────────────
// GET /api/v1/credentials/:id?tab=  (Endpoint 7: Credential Detail)
// Six tabs: overview, trust, activity, rotation, relationships, raw.
// Types are prefixed Cred/Credential to avoid collisions with Identity
// Detail's models (OverviewResponse, RiskSignal, etc. already exist in
// this package for identities).
// ─────────────────────────────────────────────────────────────────────────

// ── tab=overview ────────────────────────────────────────────────────────

type CredentialOverviewResponse struct {
	Tab             string                 `json:"tab"`
	Credential      CredentialOverviewCore `json:"credential"`
	BoundIdentities []CredBoundIdentity    `json:"bound_identities"`
	RiskSignals     []CredRiskSignal       `json:"risk_signals"`
	TypeAttributes  interface{}            `json:"type_attributes"`
}

type CredentialOverviewCore struct {
	ID                    string  `json:"id"`
	Name                  string  `json:"name"`
	ARN                   string  `json:"arn"`
	CredentialType        string  `json:"credential_type"`
	Category              string  `json:"category"`
	AccountID             string  `json:"account_id"`
	Region                string  `json:"region"`
	Status                string  `json:"status"`
	OwnerPrincipalARN     *string `json:"owner_principal_arn"`
	CreatedAtAWS          *string `json:"created_at_aws"`
	AgeDays               *int    `json:"age_days"`
	LastUsedAt            *string `json:"last_used_at"`
	IdleDays              *int    `json:"idle_days"`
	LastRotatedAt         *string `json:"last_rotated_at"`
	DaysSinceRotation     *int    `json:"days_since_rotation"`
	RotationEnabled       bool    `json:"rotation_enabled"`
	RotationIntervalDays  *int    `json:"rotation_interval_days"`
	RotationStatus        string  `json:"rotation_status"`
	ExpiresAt             *string `json:"expires_at"`
	DaysUntilExpiry       *int    `json:"days_until_expiry"`
	MaxSessionDuration    *int    `json:"max_session_duration"`
	PermissionBoundaryARN *string `json:"permission_boundary_arn"`
}

type CredBoundIdentity struct {
	IdentityID     string  `json:"identity_id"`
	Name           string  `json:"name"`
	IdentityType   string  `json:"identity_type"`
	AccountID      string  `json:"account_id"`
	Status         string  `json:"status"`
	LastActivityAt *string `json:"last_activity_at"`
	BindingType    string  `json:"binding_type"`
}

type CredRiskSignal struct {
	Signal   string `json:"signal"`
	Status   bool   `json:"status"`
	Severity string `json:"severity"`
}

// ── tab=trust ───────────────────────────────────────────────────────────

type CredentialTrustResponse struct {
	Tab                         string                     `json:"tab"`
	TrustPolicy                 CredTrustPolicyBlock       `json:"trust_policy"`
	AttachedPolicies            interface{}                `json:"attached_policies"`
	InlinePolicies              interface{}                `json:"inline_policies"`
	EffectivePermissionsSummary []CredEffectivePermSummary `json:"effective_permissions_summary"`
	AssumableRoles              []CredAssumableRole        `json:"assumable_roles"`
	PermissionBoundary          CredPermissionBoundary     `json:"permission_boundary"`
}

type CredTrustPolicyBlock struct {
	Raw        interface{}          `json:"raw"`
	Principals []CredTrustPrincipal `json:"principals"`
	Warnings   []string             `json:"warnings"`
}

type CredTrustPrincipal struct {
	Principal  string  `json:"principal"`
	Type       string  `json:"type"`
	Condition  *string `json:"condition"`
	IsExternal bool    `json:"is_external"`
}

type CredEffectivePermSummary struct {
	Service        string `json:"service"`
	AllowedActions int    `json:"allowed_actions"`
	DeniedActions  int    `json:"denied_actions"`
	ResourceScope  string `json:"resource_scope"`
}

type CredAssumableRole struct {
	TargetRoleARN string  `json:"target_role_arn"`
	TargetAccount string  `json:"target_account"`
	Conditions    *string `json:"conditions"`
	LastAssumed   *string `json:"last_assumed"`
}

type CredPermissionBoundary struct {
	BoundaryARN          *string  `json:"boundary_arn"`
	EffectiveRestriction *string  `json:"effective_restriction"`
	ActionsBlocked       []string `json:"actions_blocked"`
}

// ── tab=activity ────────────────────────────────────────────────────────

type CredentialActivityResponse struct {
	Tab                           string                `json:"tab"`
	TimeRange                     string                `json:"time_range"`
	VolumeChart                   []CredVolumePoint     `json:"volume_chart"`
	RecentEvents                  []CredRecentEvent     `json:"recent_events"`
	IdentitiesUsingThisCredential []CredUsingIdentity   `json:"identities_using_this_credential"`
	Analytics                     CredActivityAnalytics `json:"analytics"`
	EventsPagination              CredEventsPagination  `json:"events_pagination"`
}

type CredVolumePoint struct {
	Date  string `json:"date"`
	Count int    `json:"count"`
}

type CredRecentEvent struct {
	EventTime   *string `json:"event_time"`
	EventName   string  `json:"event_name"`
	Service     string  `json:"service"`
	ResourceARN *string `json:"resource_arn"`
	SourceIP    *string `json:"source_ip"`  // identity_usage has no source_ip column — always null
	Region      *string `json:"region"`     // identity_usage has no region column — always null
	UserAgent   *string `json:"user_agent"` // identity_usage has no user_agent column — always null
	ErrorCode   *string `json:"error_code"` // identity_usage has no error_code column — always null
	EventCount  int     `json:"event_count"` // extra field: identity_usage is pre-aggregated
}

type CredUsingIdentity struct {
	IdentityID     string  `json:"identity_id"`
	Name           string  `json:"name"`
	IdentityType   string  `json:"identity_type"`
	SourceIP       *string `json:"source_ip"`        // not available — always null
	LastAction     *string `json:"last_action"`      // not reliably attributable per-identity — always null
	LastActionTime *string `json:"last_action_time"` // same limitation — always null
}

type CredActivityAnalytics struct {
	SourceIPs     []CredIPPct      `json:"source_ips"` // always empty — no source_ip column
	ActiveRegions []CredRegionCnt  `json:"active_regions"`
	TopServices   []CredServicePct `json:"top_services"`
	UsagePattern  string           `json:"usage_pattern"`
	ErrorRatePct  *float64         `json:"error_rate_pct"` // always null — no error tracking column
}

type CredIPPct struct {
	IP  string  `json:"ip"`
	Pct float64 `json:"pct"`
}

type CredRegionCnt struct {
	Region string `json:"region"`
	Count  int    `json:"count"`
}

type CredServicePct struct {
	Service string  `json:"service"`
	Pct     float64 `json:"pct"`
	Count   int     `json:"count"`
}

type CredEventsPagination struct {
	Page       int `json:"page"`
	PageSize   int `json:"page_size"`
	TotalCount int `json:"total_count"`
	TotalPages int `json:"total_pages"`
}

// ── tab=rotation ────────────────────────────────────────────────────────

type CredentialRotationResponse struct {
	Tab           string                `json:"tab"`
	Timeline      []CredRotationEvent   `json:"timeline"`
	Configuration CredRotationConfig    `json:"configuration"`
	Lifecycle     CredRotationLifecycle `json:"lifecycle"`
}

type CredRotationEvent struct {
	Date    string `json:"date"`
	Event   string `json:"event"`
	Details string `json:"details"`
}

type CredRotationConfig struct {
	AutoRotation         bool    `json:"auto_rotation"`
	RotationIntervalDays *int    `json:"rotation_interval_days"`
	LastRotation         *string `json:"last_rotation"`
	NextExpected         *string `json:"next_expected"`
	Status               string  `json:"status"`
	RotationLambdaARN    *string `json:"rotation_lambda_arn"` // not tracked in this schema — always null
}

type CredRotationLifecycle struct {
	CreatedAtAWS      *string `json:"created_at_aws"`
	AgeDays           *int    `json:"age_days"`
	DaysSinceRotation *int    `json:"days_since_rotation"`
	ExpiresAt         *string `json:"expires_at"`
	DaysUntilExpiry   *int    `json:"days_until_expiry"`
}

// ── tab=relationships ───────────────────────────────────────────────────

type CredentialRelationshipsResponse struct {
	Tab               string                `json:"tab"`
	Graph             CredRelationshipGraph `json:"graph"`
	RelationshipTable []CredRelationshipRow `json:"relationship_table"`
}

type CredRelationshipGraph struct {
	Nodes []CredGraphNode `json:"nodes"`
	Edges []CredGraphEdge `json:"edges"`
}

type CredGraphNode struct {
	ARN       string `json:"arn"`
	Name      string `json:"name"`
	Type      string `json:"type"` // credential | identity | resource | unknown
	Subtype   string `json:"subtype"`
	IsCurrent bool   `json:"is_current"`
}

type CredGraphEdge struct {
	Source         string  `json:"source"`
	Target         string  `json:"target"`
	EdgeType       string  `json:"edge_type"`
	LastObservedAt *string `json:"last_observed_at"`
}

type CredRelationshipRow struct {
	Relationship string  `json:"relationship"`
	Direction    string  `json:"direction"` // inbound | outbound
	TargetARN    string  `json:"target_arn"`
	TargetName   string  `json:"target_name"`
	TargetType   string  `json:"target_type"`
	LastActive   *string `json:"last_active"`
}

// ── tab=raw ─────────────────────────────────────────────────────────────

type CredentialRawResponse struct {
	Tab                  string                 `json:"tab"`
	CredentialRecord     map[string]interface{} `json:"credential_record"`
	RawAPIResponse       interface{}            `json:"raw_api_response"`
	TrustPolicy          interface{}            `json:"trust_policy"`
	AttachedPolicies     interface{}            `json:"attached_policies"`
	InlinePolicies       interface{}            `json:"inline_policies"`
	TypeAttributes       interface{}            `json:"type_attributes"`
	EffectivePermissions interface{}            `json:"effective_permissions"`
}