package newapi

// ── Endpoint 3: Dashboard Overview ──────────────────────────────────────────
// Body of GET /api/v1/dashboard/overview. Field names match the API contract.

type DashboardOverviewResponse struct {
	KPIs   OverviewKPIs   `json:"kpis"`
	Charts OverviewCharts `json:"charts"`
}

type OverviewKPIs struct {
	TotalIdentities       int     `json:"total_identities"`
	TotalCredentials      int     `json:"total_credentials"`
	OrphanedCredentials   int     `json:"orphaned_credentials"`
	StaleIdentities       int     `json:"stale_identities"`
	StaleCredentials      int     `json:"stale_credentials"`
	PubliclyAccessible    int     `json:"publicly_accessible"`
	ShadowIdentities      int     `json:"shadow_identities"`
	AccountsScanned       int     `json:"accounts_scanned"`
	LastScanTime          *string `json:"last_scan_time"` // RFC3339 UTC, null when no scan
	PermissionUtilization float64 `json:"permission_utilization_pct"`
}

type OverviewCharts struct {
	IdentitiesByType            []TypeCount          `json:"identities_by_type"`
	IdentitiesByFunctionalClass []ClassCount         `json:"identities_by_functional_class"`
	IdentitiesByAccount         []AccountCount       `json:"identities_by_account"`
	IdentitiesByRegion          []RegionCount        `json:"identities_by_region"`
	IdentitiesByEnvironment     []EnvironmentCount   `json:"identities_by_environment"`
	IdentitiesByStatus          []StatusCount        `json:"identities_by_status"`
	IdentityGrowth              []DateCount          `json:"identity_growth"`
	CredentialGrowth            []DateCount          `json:"credential_growth"`
	StaleVsActive               StaleVsActive        `json:"stale_vs_active"`
	CredentialTypes             []TypeCount          `json:"credential_types"`
	TopOwners                   []OwnerCount         `json:"top_owners"`
	CredentialsExpiringSoon     []ExpiringCredential `json:"credentials_expiring_soon"`
	ScanHistory                 []ScanHistoryItem    `json:"scan_history"`
}

type TypeCount struct {
	Type  string `json:"type"`
	Count int    `json:"count"`
}
type ClassCount struct {
	Class string `json:"class"`
	Count int    `json:"count"`
}
type AccountCount struct {
	AccountID string `json:"account_id"`
	Count     int    `json:"count"`
}
type RegionCount struct {
	Region string `json:"region"`
	Count  int    `json:"count"`
}
type EnvironmentCount struct {
	Environment string `json:"environment"`
	Count       int    `json:"count"`
}
type StatusCount struct {
	Status string `json:"status"`
	Count  int    `json:"count"`
}
type OwnerCount struct {
	Owner string `json:"owner"`
	Count int    `json:"count"`
}

// DateCount is one point of a cumulative growth line (date = first day of month).
type DateCount struct {
	Date  string `json:"date"`
	Count int    `json:"count"`
}

type StaleVsActive struct {
	Active int `json:"active"`
	Stale  int `json:"stale"`
}

type ExpiringCredential struct {
	CredentialName string `json:"credential_name"`
	ExpiresAt      string `json:"expires_at"` // RFC3339 UTC
	DaysRemaining  int    `json:"days_remaining"`
}

type ScanHistoryItem struct {
	ScanID           string  `json:"scan_id"`
	ScanEnd          *string `json:"scan_end"` // RFC3339 UTC
	Status           string  `json:"status"`
	TotalIdentities  int     `json:"total_identities"`
	TotalCredentials int     `json:"total_credentials"`
}