// package newapi

// import "encoding/json"

// // ── Endpoint 5: Identity Detail ─────────────────────────────────────────────
// // Body of GET /api/v1/identities/:id. Shape depends entirely on `tab`;
// // exactly one of the tab-specific response types below is ever returned.

// // ---- ?tab=overview ---------------------------------------------------------

// type IdentityOverviewResponse struct {
// 	Tab              string                   `json:"tab"`
// 	Identity         IdentityOverviewCore     `json:"identity"`
// 	Discovery        IdentityDiscovery        `json:"discovery"`
// 	TypeAttributes   json.RawMessage          `json:"type_attributes"`
// 	BoundCredentials []BoundCredentialSummary `json:"bound_credentials"`
// 	Tags             json.RawMessage          `json:"tags"`
// 	MissingTags      []string                 `json:"missing_tags"`
// 	RiskSignals      []RiskSignal             `json:"risk_signals"`
// }

// type IdentityOverviewCore struct {
// 	ID                   string   `json:"id"`
// 	Name                 string   `json:"name"`
// 	ARN                  string   `json:"arn"`
// 	IdentityType         string   `json:"identity_type"`
// 	FunctionalClass      string   `json:"functional_class"`
// 	Category             string   `json:"category"`
// 	AccountID            string   `json:"account_id"`
// 	Region               string   `json:"region"`
// 	VpcID                *string  `json:"vpc_id"`
// 	SubnetID             *string  `json:"subnet_id"`
// 	SecurityGroupIDs     []string `json:"security_group_ids"`
// 	Environment          string   `json:"environment"`
// 	Owner                string   `json:"owner"`
// 	Status               string   `json:"status"`
// 	IsPubliclyAccessible bool     `json:"is_publicly_accessible"`
// 	CreatedAtAWS         *string  `json:"created_at_aws"`
// 	AgeDays              int      `json:"age_days"`
// 	FirstSeenAt          *string  `json:"first_seen_at"`
// 	LastSeenAt           *string  `json:"last_seen_at"`
// 	LastActivityAt       *string  `json:"last_activity_at"`
// 	IdleDays             int      `json:"idle_days"`
// 	ParentARN            *string  `json:"parent_arn"`
// 	CreatedBy            string   `json:"created_by"`
// }

// type IdentityDiscovery struct {
// 	DiscoverySource      string  `json:"discovery_source"`
// 	CredentialResolution string  `json:"credential_resolution"`
// 	ScanID               string  `json:"scan_id"`
// 	LastScanned          *string `json:"last_scanned"`
// 	DataSources          string  `json:"data_sources"`
// }

// type BoundCredentialSummary struct {
// 	CredentialID          string  `json:"credential_id"`
// 	Name                  string  `json:"name"`
// 	CredentialType        string  `json:"credential_type"`
// 	BindingType            string  `json:"binding_type"`
// 	IsPrimary             bool    `json:"is_primary"`
// 	TrustPrincipal        string  `json:"trust_principal"`
// 	AttachedPoliciesCount int     `json:"attached_policies_count"`
// 	InlinePoliciesCount   int     `json:"inline_policies_count"`
// 	GrantedActionsCount   int     `json:"granted_actions_count"`
// 	UsedActionsCount      int     `json:"used_actions_count"`
// 	UtilizationPct        float64 `json:"utilization_pct"`
// }

// type RiskSignal struct {
// 	Signal   string `json:"signal"`
// 	Status   bool   `json:"status"`
// 	Severity string `json:"severity"`
// }

// // ---- ?tab=permissions -------------------------------------------------------

// type IdentityPermissionsResponse struct {
// 	Tab             string               `json:"tab"`
// 	Summary         PermissionsSummary   `json:"summary"`
// 	Permissions     []PermissionItem     `json:"permissions"`
// 	PolicyBreakdown []PolicyBreakdownRow `json:"policy_breakdown"`
// }

// type PermissionsSummary struct {
// 	GrantedCount   int     `json:"granted_count"`
// 	UsedCount      int     `json:"used_count"`
// 	UnusedCount    int     `json:"unused_count"`
// 	UtilizationPct float64 `json:"utilization_pct"`
// }

// type PermissionItem struct {
// 	Service      string   `json:"service"`
// 	Action       string   `json:"action"`
// 	ResourceARN  string   `json:"resource_arn"`
// 	Effect       string   `json:"effect"`
// 	PolicySource string   `json:"policy_source"`
// 	PolicyType   string   `json:"policy_type"`
// 	Used         bool     `json:"used"`
// 	LastUsedAt   *string  `json:"last_used_at"`
// 	SourceIPs    []string `json:"source_ips"`
// }

// type PolicyBreakdownRow struct {
// 	PolicyName      string `json:"policy_name"`
// 	PolicyType      string `json:"policy_type"`
// 	TotalPermissions int   `json:"total_permissions"`
// 	UsedPermissions  int   `json:"used_permissions"`
// }

// // ---- ?tab=activity -----------------------------------------------------------

// type IdentityActivityResponse struct {
// 	Tab               string             `json:"tab"`
// 	TimeRange         string             `json:"time_range"`
// 	VolumeChart       []VolumeChartPoint `json:"volume_chart"`
// 	RecentEvents      []ActivityEvent    `json:"recent_events"`
// 	Analytics         ActivityAnalytics  `json:"analytics"`
// 	ErrorEvents       []ErrorEvent       `json:"error_events"`
// 	EventsPagination  EventsPagination   `json:"events_pagination"`
// }

// type VolumeChartPoint struct {
// 	Date  string `json:"date"`
// 	Count int    `json:"count"`
// }

// type ActivityEvent struct {
// 	EventTime   string  `json:"event_time"`
// 	EventName   string  `json:"event_name"`
// 	Service     string  `json:"service"`
// 	ResourceARN string  `json:"resource_arn"`
// 	SourceIP    string  `json:"source_ip"`
// 	Region      string  `json:"region"`
// 	UserAgent   string  `json:"user_agent"`
// 	ErrorCode   *string `json:"error_code"`
// 	RequestID   string  `json:"request_id"`
// }

// type ActivityAnalytics struct {
// 	SourceIPs          []SourceIPStat `json:"source_ips"`
// 	ActiveRegions      []RegionStat   `json:"active_regions"`
// 	TopServices        []ServiceStat  `json:"top_services"`
// 	TopActions         []ActionStat   `json:"top_actions"`
// 	ErrorRatePct       float64        `json:"error_rate_pct"`
// 	AccessDeniedRatePct float64       `json:"access_denied_rate_pct"`
// 	PeakHours          []HourStat     `json:"peak_hours"`
// 	UsagePattern       string         `json:"usage_pattern"`
// }

// type SourceIPStat struct {
// 	IP  string  `json:"ip"`
// 	Pct float64 `json:"pct"`
// }
// type RegionStat struct {
// 	Region string `json:"region"`
// 	Count  int    `json:"count"`
// }
// type ServiceStat struct {
// 	Service string  `json:"service"`
// 	Pct     float64 `json:"pct"`
// 	Count   int     `json:"count"`
// }
// type ActionStat struct {
// 	Action string `json:"action"`
// 	Count  int    `json:"count"`
// }
// type HourStat struct {
// 	Hour  int `json:"hour"`
// 	Count int `json:"count"`
// }

// type ErrorEvent struct {
// 	EventTime    string `json:"event_time"`
// 	EventName    string `json:"event_name"`
// 	Service      string `json:"service"`
// 	ResourceARN  string `json:"resource_arn"`
// 	SourceIP     string `json:"source_ip"`
// 	ErrorCode    string `json:"error_code"`
// 	ErrorMessage string `json:"error_message"`
// }

// type EventsPagination struct {
// 	Page       int `json:"page"`
// 	PageSize   int `json:"page_size"`
// 	TotalCount int `json:"total_count"`
// 	TotalPages int `json:"total_pages"`
// }

// // ---- ?tab=relationships -------------------------------------------------------

// type IdentityRelationshipsResponse struct {
// 	Tab                string                 `json:"tab"`
// 	Graph              RelationshipGraph      `json:"graph"`
// 	RelationshipTable  []RelationshipTableRow `json:"relationship_table"`
// }

// type RelationshipGraph struct {
// 	Nodes []GraphNode `json:"nodes"`
// 	Edges []GraphEdge `json:"edges"`
// }

// type GraphNode struct {
// 	ARN       string `json:"arn"`
// 	Name      string `json:"name"`
// 	Type      string `json:"type"`
// 	Subtype   string `json:"subtype"`
// 	IsCurrent bool   `json:"is_current"`
// }

// type GraphEdge struct {
// 	Source         string          `json:"source"`
// 	Target         string          `json:"target"`
// 	EdgeType       string          `json:"edge_type"`
// 	LastObservedAt string          `json:"last_observed_at"`
// 	Metadata       json.RawMessage `json:"metadata,omitempty"`
// }

// type RelationshipTableRow struct {
// 	Relationship string `json:"relationship"`
// 	Direction    string `json:"direction"`
// 	TargetARN    string `json:"target_arn"`
// 	TargetName   string `json:"target_name"`
// 	TargetType   string `json:"target_type"`
// 	LastActive   string `json:"last_active"`
// }

// // ---- ?tab=credentials -------------------------------------------------------

// type IdentityCredentialsResponse struct {
// 	Tab         string             `json:"tab"`
// 	Credentials []CredentialDetail `json:"credentials"`
// }

// type CredentialDetail struct {
// 	CredentialID       string          `json:"credential_id"`
// 	Name               string          `json:"name"`
// 	ARN                string          `json:"arn"`
// 	CredentialType     string          `json:"credential_type"`
// 	BindingType        string          `json:"binding_type"`
// 	BindingSource      string          `json:"binding_source"`
// 	IsPrimary          bool            `json:"is_primary"`
// 	TrustPolicy        json.RawMessage `json:"trust_policy"`
// 	TrustPrincipals    json.RawMessage `json:"trust_principals"`
// 	AttachedPolicies   json.RawMessage `json:"attached_policies"`
// 	InlinePolicies     json.RawMessage `json:"inline_policies"`
// 	Lifecycle          CredentialLifecycle `json:"lifecycle"`
// 	AssumableRoles     json.RawMessage `json:"assumable_roles"`
// }

// type CredentialLifecycle struct {
// 	CreatedAtAWS         *string `json:"created_at_aws"`
// 	LastUsedAt           *string `json:"last_used_at"`
// 	LastRotatedAt        *string `json:"last_rotated_at"`
// 	AgeDays              int     `json:"age_days"`
// 	DaysSinceRotation    *int    `json:"days_since_rotation"`
// 	RotationEnabled      bool    `json:"rotation_enabled"`
// 	RotationIntervalDays *int    `json:"rotation_interval_days"`
// 	RotationOverdue      bool    `json:"rotation_overdue"`
// 	ExpiresAt            *string `json:"expires_at"`
// 	MaxSessionDuration   *int    `json:"max_session_duration"`
// 	PermissionBoundaryARN *string `json:"permission_boundary_arn"`
// }

// // ---- ?tab=raw -------------------------------------------------------

// type IdentityRawResponse struct {
// 	Tab                string          `json:"tab"`
// 	IdentityRecord     json.RawMessage `json:"identity_record"`
// 	RawAPIResponse     json.RawMessage `json:"raw_api_response"`
// 	ResolvedCredential *ResolvedCredential `json:"resolved_credential"`
// 	TypeAttributes     json.RawMessage `json:"type_attributes"`
// }

// type ResolvedCredential struct {
// 	RoleARN          string `json:"roleArn"`
// 	AssumedVia       string `json:"assumedVia"`
// 	AttachedPolicies int    `json:"attachedPolicies"`
// 	InlinePolicies   int    `json:"inlinePolicies"`
// }


































package newapi

import "encoding/json"

// ── Endpoint 5: Identity Detail ─────────────────────────────────────────────
// Body of GET /api/v1/identities/:id. Shape depends entirely on `tab`;
// exactly one of the tab-specific response types below is ever returned.

// ---- ?tab=overview ---------------------------------------------------------

type IdentityOverviewResponse struct {
	Tab              string                   `json:"tab"`
	Identity         IdentityOverviewCore     `json:"identity"`
	Discovery        IdentityDiscovery        `json:"discovery"`
	TypeAttributes   json.RawMessage          `json:"type_attributes"`
	BoundCredentials []BoundCredentialSummary `json:"bound_credentials"`
	Tags             json.RawMessage          `json:"tags"`
	MissingTags      []string                 `json:"missing_tags"`
	RiskSignals      []RiskSignal             `json:"risk_signals"`
}

type IdentityOverviewCore struct {
	ID                   string   `json:"id"`
	Name                 string   `json:"name"`
	ARN                  string   `json:"arn"`
	IdentityType         string   `json:"identity_type"`
	FunctionalClass      string   `json:"functional_class"`
	Category             string   `json:"category"`
	AccountID            string   `json:"account_id"`
	Region               string   `json:"region"`
	VpcID                *string  `json:"vpc_id"`
	SubnetID             *string  `json:"subnet_id"`
	SecurityGroupIDs     []string `json:"security_group_ids"`
	Environment          string   `json:"environment"`
	Owner                string   `json:"owner"`
	Status               string   `json:"status"`
	IsPubliclyAccessible bool     `json:"is_publicly_accessible"`
	CreatedAtAWS         *string  `json:"created_at_aws"`
	AgeDays              int      `json:"age_days"`
	FirstSeenAt          *string  `json:"first_seen_at"`
	LastSeenAt           *string  `json:"last_seen_at"`
	LastActivityAt       *string  `json:"last_activity_at"`
	IdleDays             int      `json:"idle_days"`
	ParentARN            *string  `json:"parent_arn"`
	CreatedBy            string   `json:"created_by"`
}

type IdentityDiscovery struct {
	DiscoverySource      string  `json:"discovery_source"`
	CredentialResolution string  `json:"credential_resolution"`
	ScanID               string  `json:"scan_id"`
	LastScanned          *string `json:"last_scanned"`
	DataSources          string  `json:"data_sources"`
}

type BoundCredentialSummary struct {
	CredentialID          string  `json:"credential_id"`
	Name                  string  `json:"name"`
	CredentialType        string  `json:"credential_type"`
	BindingType            string  `json:"binding_type"`
	IsPrimary             bool    `json:"is_primary"`
	TrustPrincipal        string  `json:"trust_principal"`
	AttachedPoliciesCount int     `json:"attached_policies_count"`
	InlinePoliciesCount   int     `json:"inline_policies_count"`
	GrantedActionsCount   int     `json:"granted_actions_count"`
	UsedActionsCount      int     `json:"used_actions_count"`
	UtilizationPct        float64 `json:"utilization_pct"`
}

type RiskSignal struct {
	Signal   string `json:"signal"`
	Status   bool   `json:"status"`
	Severity string `json:"severity"`
}

// ---- ?tab=permissions -------------------------------------------------------

type IdentityPermissionsResponse struct {
	Tab             string               `json:"tab"`
	Summary         PermissionsSummary   `json:"summary"`
	Permissions     []PermissionItem     `json:"permissions"`
	PolicyBreakdown []PolicyBreakdownRow `json:"policy_breakdown"`
}

type PermissionsSummary struct {
	GrantedCount   int     `json:"granted_count"`
	UsedCount      int     `json:"used_count"`
	UnusedCount    int     `json:"unused_count"`
	UtilizationPct float64 `json:"utilization_pct"`
}

type PermissionItem struct {
	Service      string   `json:"service"`
	Action       string   `json:"action"`
	ResourceARN  string   `json:"resource_arn"`
	Effect       string   `json:"effect"`
	PolicySource string   `json:"policy_source"`
	PolicyType   string   `json:"policy_type"`
	Used         bool     `json:"used"`
	LastUsedAt   *string  `json:"last_used_at"`
	SourceIPs    []string `json:"source_ips"`
}

type PolicyBreakdownRow struct {
	PolicyName      string `json:"policy_name"`
	PolicyType      string `json:"policy_type"`
	TotalPermissions int   `json:"total_permissions"`
	UsedPermissions  int   `json:"used_permissions"`
}

// ---- ?tab=activity -----------------------------------------------------------

type IdentityActivityResponse struct {
	Tab               string             `json:"tab"`
	TimeRange         string             `json:"time_range"`
	VolumeChart       []VolumeChartPoint `json:"volume_chart"`
	RecentEvents      []ActivityEvent    `json:"recent_events"`
	Analytics         ActivityAnalytics  `json:"analytics"`
	ErrorEvents       []ErrorEvent       `json:"error_events"`
	EventsPagination  EventsPagination   `json:"events_pagination"`
}

type VolumeChartPoint struct {
	Date  string `json:"date"`
	Count int    `json:"count"`
}

type ActivityEvent struct {
	EventTime   string  `json:"event_time"`
	EventName   string  `json:"event_name"`
	Service     string  `json:"service"`
	ResourceARN string  `json:"resource_arn"`
	SourceIP    string  `json:"source_ip"`
	Region      string  `json:"region"`
	UserAgent   string  `json:"user_agent"`
	ErrorCode   *string `json:"error_code"`
	RequestID   string  `json:"request_id"`
}

type ActivityAnalytics struct {
	SourceIPs          []SourceIPStat `json:"source_ips"`
	ActiveRegions      []RegionStat   `json:"active_regions"`
	TopServices        []ServiceStat  `json:"top_services"`
	TopActions         []ActionStat   `json:"top_actions"`
	ErrorRatePct       float64        `json:"error_rate_pct"`
	AccessDeniedRatePct float64       `json:"access_denied_rate_pct"`
	PeakHours          []HourStat     `json:"peak_hours"`
	UsagePattern       string         `json:"usage_pattern"`
}

type SourceIPStat struct {
	IP  string  `json:"ip"`
	Pct float64 `json:"pct"`
}
type RegionStat struct {
	Region string `json:"region"`
	Count  int    `json:"count"`
}
type ServiceStat struct {
	Service string  `json:"service"`
	Pct     float64 `json:"pct"`
	Count   int     `json:"count"`
}
type ActionStat struct {
	Action string `json:"action"`
	Count  int    `json:"count"`
}
type HourStat struct {
	Hour  int `json:"hour"`
	Count int `json:"count"`
}

type ErrorEvent struct {
	EventTime    string `json:"event_time"`
	EventName    string `json:"event_name"`
	Service      string `json:"service"`
	ResourceARN  string `json:"resource_arn"`
	SourceIP     string `json:"source_ip"`
	ErrorCode    string `json:"error_code"`
	ErrorMessage string `json:"error_message"`
}

type EventsPagination struct {
	Page       int `json:"page"`
	PageSize   int `json:"page_size"`
	TotalCount int `json:"total_count"`
	TotalPages int `json:"total_pages"`
}

// ---- ?tab=relationships -------------------------------------------------------

type IdentityRelationshipsResponse struct {
	Tab                string                 `json:"tab"`
	Graph              RelationshipGraph      `json:"graph"`
	RelationshipTable  []RelationshipTableRow `json:"relationship_table"`
}

type RelationshipGraph struct {
	Nodes []GraphNode `json:"nodes"`
	Edges []GraphEdge `json:"edges"`
}

type GraphNode struct {
	ARN       string `json:"arn"`
	Name      string `json:"name"`
	Type      string `json:"type"`
	Subtype   string `json:"subtype"`
	IsCurrent bool   `json:"is_current"`
}

type GraphEdge struct {
	Source         string          `json:"source"`
	Target         string          `json:"target"`
	EdgeType       string          `json:"edge_type"`
	LastObservedAt string          `json:"last_observed_at"`
	Metadata       json.RawMessage `json:"metadata,omitempty"`
}

type RelationshipTableRow struct {
	Relationship string `json:"relationship"`
	Direction    string `json:"direction"`
	TargetARN    string `json:"target_arn"`
	TargetName   string `json:"target_name"`
	TargetType   string `json:"target_type"`
	LastActive   string `json:"last_active"`
}

// ---- ?tab=credentials -------------------------------------------------------

type IdentityCredentialsResponse struct {
	Tab         string             `json:"tab"`
	Credentials []CredentialDetail `json:"credentials"`
}

type CredentialDetail struct {
	CredentialID       string          `json:"credential_id"`
	Name               string          `json:"name"`
	ARN                string          `json:"arn"`
	CredentialType     string          `json:"credential_type"`
	BindingType        string          `json:"binding_type"`
	BindingSource      string          `json:"binding_source"`
	IsPrimary          bool            `json:"is_primary"`
	TrustPolicy        json.RawMessage `json:"trust_policy"`
	TrustPrincipals    json.RawMessage `json:"trust_principals"`
	AttachedPolicies   json.RawMessage `json:"attached_policies"`
	InlinePolicies     json.RawMessage `json:"inline_policies"`
	Lifecycle          CredentialLifecycle `json:"lifecycle"`
	AssumableRoles     json.RawMessage `json:"assumable_roles"`
}

type CredentialLifecycle struct {
	CreatedAtAWS         *string `json:"created_at_aws"`
	LastUsedAt           *string `json:"last_used_at"`
	LastRotatedAt        *string `json:"last_rotated_at"`
	AgeDays              int     `json:"age_days"`
	DaysSinceRotation    *int    `json:"days_since_rotation"`
	RotationEnabled      bool    `json:"rotation_enabled"`
	RotationIntervalDays *int    `json:"rotation_interval_days"`
	RotationOverdue      bool    `json:"rotation_overdue"`
	ExpiresAt            *string `json:"expires_at"`
	MaxSessionDuration   *int    `json:"max_session_duration"`
	PermissionBoundaryARN *string `json:"permission_boundary_arn"`
}

// ---- ?tab=raw -------------------------------------------------------

type IdentityRawResponse struct {
	Tab                string          `json:"tab"`
	IdentityRecord     json.RawMessage `json:"identity_record"`
	RawAPIResponse     json.RawMessage `json:"raw_api_response"`
	ResolvedCredential *ResolvedCredential `json:"resolved_credential"`
	TypeAttributes     json.RawMessage `json:"type_attributes"`
}

type ResolvedCredential struct {
	RoleARN          string `json:"roleArn"`
	AssumedVia       string `json:"assumedVia"`
	AttachedPolicies int    `json:"attachedPolicies"`
	InlinePolicies   int    `json:"inlinePolicies"`
}