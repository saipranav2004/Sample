package newapi

// CredentialListItem is one row of GET /api/v1/credentials.
type CredentialListItem struct {
	ID                    string  `json:"id"`
	Name                  string  `json:"name"`
	ARN                   string  `json:"arn"`
	CredentialType        string  `json:"credential_type"`
	AccountID             string  `json:"account_id"`
	Region                string  `json:"region"`
	Status                string  `json:"status"`
	OwnerPrincipalARN     *string `json:"owner_principal_arn"`
	BoundIdentitiesCount  int     `json:"bound_identities_count"`
	IsOrphaned            bool    `json:"is_orphaned"`
	LastUsedAt            *string `json:"last_used_at"`
	LastRotatedAt         *string `json:"last_rotated_at"`
	RotationEnabled       bool    `json:"rotation_enabled"`
	RotationOverdue       bool    `json:"rotation_overdue"`
	AgeDays               int     `json:"age_days"`
	IdleDays              *int    `json:"idle_days"`
	ExpiresAt             *string `json:"expires_at"`
	DaysUntilExpiry       *int    `json:"days_until_expiry"`
	HasExternalTrust      bool    `json:"has_external_trust"`
	PermissionBoundaryARN *string `json:"permission_boundary_arn"`
}

// Pagination matches the shape already used by other list endpoints.
type CredentialsPagination struct {
	Page       int `json:"page"`
	PageSize   int `json:"page_size"`
	TotalCount int `json:"total_count"`
	TotalPages int `json:"total_pages"`
}

// CredentialsListResponse is the full response body for GET /api/v1/credentials.
type CredentialsListResponse struct {
	Pagination CredentialsPagination `json:"pagination"`
	Data       []CredentialListItem  `json:"data"`
}