package newapi

// ── Endpoint 2: Filter Options ──────────────────────────────────────────────
// Body of GET /api/v1/filters.

type FilterOptionsResponse struct {
	Accounts          []AccountOption    `json:"accounts"`
	Regions           []RegionOption     `json:"regions"`
	Scans             []ScanOption       `json:"scans"`
	IdentityTypes     []TypeCount        `json:"identity_types"`
	FunctionalClasses []ClassCount       `json:"functional_classes"`
	CredentialTypes   []TypeCount        `json:"credential_types"`
	Environments      []EnvironmentCount `json:"environments"`
	Statuses          []StatusCount      `json:"statuses"`
}

type AccountOption struct {
	AccountID       string `json:"account_id"`
	IdentityCount   int    `json:"identity_count"`
	CredentialCount int    `json:"credential_count"`
	IsDefault       bool   `json:"is_default"`
}

type RegionOption struct {
	Region string `json:"region"`
	Count  int    `json:"count"`
}

type ScanOption struct {
	ScanID           string  `json:"scan_id"`
	ScanEnd          *string `json:"scan_end"` // RFC3339 UTC, null if never completed
	Status           string  `json:"status"`
	TotalIdentities  int     `json:"total_identities"`
	TotalCredentials int     `json:"total_credentials"`
}

