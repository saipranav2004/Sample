// Package newapi (models) holds the request/response shapes of the NEW API endpoints.
package newapi

// SelectionSetting is a list-type preference (accounts or regions).
type SelectionSetting struct {
	Selected  []string `json:"selected"`
	IsDefault bool     `json:"is_default"` // true = came from accounts defaults, not from the user
}

// ScanSetting describes which scan the dashboards should use.
type ScanSetting struct {
	SelectedScanID    *string `json:"selected_scan_id"`    // what the user saved (null if nothing / invalid)
	EffectiveScanID   *string `json:"effective_scan_id"`   // what will really be used
	EffectiveScanTime *string `json:"effective_scan_time"` // scan_end of the effective scan, RFC3339 UTC
	IsDefault         bool    `json:"is_default"`          // true = latest completed scan
}

type Settings struct {
	Accounts SelectionSetting `json:"accounts"`
	Regions  SelectionSetting `json:"regions"`
	Scan     ScanSetting      `json:"scan"`
}

// SettingsResponse is the body of GET /api/v1/settings (Endpoint 1A).
type SettingsResponse struct {
	Settings Settings `json:"settings"`
	// Source is "user_settings" when the user has saved preferences that were
	// applied, otherwise "accounts" (everything fell back to accounts defaults).
	Source string `json:"source"`
}
