package models

type GrantedAction struct {
	Action    string `json:"action"`
	RoleCount int    `json:"role_count"`
}

type PermissionDistributionResponse struct {
	TopGrantedActions    []GrantedAction `json:"top_granted_actions"`
	WildcardActionsCount int             `json:"wildcard_actions_count"`
	AdminAccessCount     int             `json:"admin_access_count"`
	TotalUniqueActions   int             `json:"total_unique_actions"`
}

