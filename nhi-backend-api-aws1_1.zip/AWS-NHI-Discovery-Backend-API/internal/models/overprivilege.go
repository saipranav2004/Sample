package models
type OverprivilegeSeverity struct {
	Severity    string `json:"severity"`
	Count       int    `json:"count"`
	Description string `json:"description"`
}

type OverprivilegedRoles struct {
	Total      int                     `json:"total"`
	BySeverity []OverprivilegeSeverity `json:"by_severity"`
}

type TopOverprivilegedRole struct {
	CredentialID       string  `json:"credential_id"`
	Name               string  `json:"name"`
	GrantedPermissions int     `json:"granted_permissions"`
	UsedPermissions    int     `json:"used_permissions"`
	UnusedPercentage   float64 `json:"unused_percentage"`
}

type OverprivilegeResponse struct {
	TotalRolesAnalyzed  int                     `json:"total_roles_analyzed"`
	OverprivilegedRoles OverprivilegedRoles     `json:"overprivileged_roles"`
	AvgUnusedPercentage float64                 `json:"avg_unused_percentage"`
	TopOverprivileged   []TopOverprivilegedRole `json:"top_overprivileged"`
}
