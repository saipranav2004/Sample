package models

import "time"

type ActivityHour struct {
	Hour      time.Time `json:"hour"`
	CallCount int64     `json:"call_count"`
}

type ActivityService struct {
	Service   string `json:"service"`
	CallCount int64  `json:"call_count"`
}

type ActivityHeatmapResponse struct {
	PeriodDays    int               `json:"period_days"`
	TotalAPICalls int64             `json:"total_api_calls"`
	ByHour        []ActivityHour    `json:"by_hour"`
	ByService     []ActivityService `json:"by_service"`
	PeakHour      *time.Time        `json:"peak_hour"`
	PeakCount     int64             `json:"peak_count"`
}
