package inventory

type IdentityBlastRadiusSharedCredential struct {
	CredentialName          string `json:"credential_name"`
	AlsoUsedByIdentityCount int64  `json:"also_used_by_identity_count"`
}

type IdentityBlastRadiusResponse struct {
	IdentityID                  string                                `json:"identity_id"`
	TotalCredentialsExposed     int64                                 `json:"total_credentials_exposed"`
	HighPrivilegeCredentials    int64                                 `json:"high_privilege_credentials"`
	CredentialsSharedWithOthers []IdentityBlastRadiusSharedCredential `json:"credentials_shared_with_others"`
}
