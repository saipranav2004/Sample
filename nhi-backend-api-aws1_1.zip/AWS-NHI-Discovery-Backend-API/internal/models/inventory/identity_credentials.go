package inventory

import "time"

type IdentityCredentialItem struct {
	CredentialID   string     `json:"credential_id"`
	CredentialARN  string     `json:"credential_arn"`
	CredentialName string     `json:"credential_name"`
	CredentialType string     `json:"credential_type"`
	BindingType    string     `json:"binding_type"`
	IsPrimary      bool       `json:"is_primary"`
	IsActive       bool       `json:"is_active"`
	LastUsedAt     *time.Time `json:"last_used_at,omitempty"`
	PrivilegeLevel *int       `json:"privilege_level,omitempty"`
}

type IdentityCredentialsResponse struct {
	IdentityID      string                   `json:"identity_id"`
	IdentityName    string                   `json:"identity_name"`
	Credentials     []IdentityCredentialItem `json:"credentials"`
	CredentialCount int                      `json:"credential_count"`
}
