package inventory

import "time"

type IdentityActivityTopAction struct {
	EventName string    `json:"event_name"`
	Service   string    `json:"service"`
	Count     int64     `json:"count"`
	LastSeen  time.Time `json:"last_seen"`
}

type IdentityActivityResponse struct {
	IdentityID     string                        `json:"identity_id"`
	PeriodDays     int                           `json:"period_days"`
	TotalAPICalls  int64                         `json:"total_api_calls"`
	UniqueActions  int                           `json:"unique_actions"`
	UniqueServices int                           `json:"unique_services"`
	TopActions     []IdentityActivityTopAction  `json:"top_actions"`
	ServicesCalled []string                      `json:"services_called"`
	LastActivityAt *time.Time                    `json:"last_activity_at"`
}
