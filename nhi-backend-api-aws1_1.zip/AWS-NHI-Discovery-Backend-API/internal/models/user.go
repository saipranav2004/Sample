// package models

// import "time"

// type User struct {
// 	ID        int       `json:"id"`
// 	Email     string    `json:"email"`
// 	Password  string    `json:"-"` // Never expose in JSON
// 	FullName  string    `json:"full_name"`
// 	Team      string    `json:"team"`
// 	Role      string    `json:"role"` // admin, team_lead, developer, auditor
// 	CreatedAt time.Time `json:"created_at"`
// }

// type LoginRequest struct {
// 	Email    string `json:"email"`
// 	Password string `json:"password"`
// }

// type LoginResponse struct {
// 	Token     string `json:"token"`
// 	User      User   `json:"user"`
// 	ExpiresIn int    `json:"expires_in"`
// }

























package models

import "time"

// User is a row of the GLOBAL (authentication) database, joined with the
// tenant it belongs to.
type User struct {
	ID       string `json:"id"`        // users.id (UUID)
	TenantID string `json:"tenant_id"` // users.tenant_id (UUID)
	Email    string `json:"email"`
	Password string `json:"-"` // bcrypt hash — never expose in JSON
	FullName string `json:"full_name"`
	Role     string `json:"role"` // admin, team_lead, developer, auditor
	Status   string `json:"status"`

	DBName string `json:"db_name"`

	CreatedAt time.Time `json:"created_at"`
}

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type LoginResponse struct {
	Token     string `json:"token"`
	User      User   `json:"user"`
	ExpiresIn int    `json:"expires_in"`
}
