package models

type UnusedPermissionAction struct {
	Action             string `json:"action"`
	GrantedToRoleCount int    `json:"granted_to_role_count"`
	EverUsed           bool   `json:"ever_used"`
}

type UnusedPermissionsResponse struct {
	TotalUnusedPermissions    int                      `json:"total_unused_permissions"`
	AffectedRoles             int                      `json:"affected_roles"`
	TopUnusedActions          []UnusedPermissionAction `json:"top_unused_actions"`
	PotentialDownscopeSavings string                   `json:"potential_downscope_savings"`
}
