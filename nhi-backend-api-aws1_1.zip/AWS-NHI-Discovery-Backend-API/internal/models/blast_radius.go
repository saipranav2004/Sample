package models


type SharedCredential struct {
	CredentialID   string `json:"credential_id"`
	CredentialName string `json:"credential_name"`
	CredentialType string `json:"credential_type"`
	IdentityCount  int    `json:"identity_count"`
	BlastRadius    string `json:"blast_radius"`
}

type OrphanedCredentialType struct {
	CredentialType string `json:"credential_type"`
	Count          int    `json:"count"`
}

type OrphanedCredentials struct {
	Total  int                      `json:"total"`
	ByType []OrphanedCredentialType `json:"by_type"`
}

type BlastRadiusResponse struct {
	SharedCredentials        []SharedCredential  `json:"shared_credentials"`
	OrphanedCredentials      OrphanedCredentials `json:"orphaned_credentials"`
	CredentialsWithNoBinding int                 `json:"credentials_with_no_binding"`
}
