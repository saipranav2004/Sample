package models

type CrossAccountTrusts struct {
	Total             int `json:"total"`
	WithoutExternalID int `json:"without_external_id"`
	ToExternalVendors int `json:"to_external_vendors"`
}

type FederatedTrusts struct {
	OIDC          int `json:"oidc"`
	SAML          int `json:"saml"`
	RolesAnywhere int `json:"roles_anywhere"`
}

type PublicTrusts struct {
	Total    int `json:"total"`
	Critical int `json:"critical"`
}

type TrustRiskResponse struct {
	CrossAccountTrusts       CrossAccountTrusts `json:"cross_account_trusts"`
	FederatedTrusts          FederatedTrusts    `json:"federated_trusts"`
	PublicTrusts             PublicTrusts       `json:"public_trusts"`
	ServiceTrusts            int                `json:"service_trusts"`
	PassRoleGrants           int                `json:"pass_role_grants"`
	PrivilegeEscalationPaths int                `json:"privilege_escalation_paths"`
}
