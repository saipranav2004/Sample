package models

type CategoryResponse struct {
	GeneratedAt     string     `json:"generated_at"`
	TotalIdentities int        `json:"total_identities"`
	Categories      []Category `json:"categories"`
}

type Category struct {
	CategoryCode   string  `json:"category_code"`
	Name           string  `json:"name"`
	Description    string  `json:"description"`
	Weight         float64 `json:"weight"`
	Score          float64 `json:"score"`
	TotalEvaluated int     `json:"total_evaluated"`
	TotalFailing   int     `json:"total_failing"`
	Status         string  `json:"status"`
}
