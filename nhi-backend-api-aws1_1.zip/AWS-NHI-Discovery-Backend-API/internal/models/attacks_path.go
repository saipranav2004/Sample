package models

type AttackPathStep struct {
	Step     int    `json:"step"`
	From     string `json:"from"`
	To       string `json:"to"`
	EdgeType string `json:"edge_type"`
}

type AttackPath struct {
	PathID         string           `json:"path_id"`
	Hops           int              `json:"hops"`
	Source         string           `json:"source"`
	SourceName     string           `json:"source_name"`
	Path           []AttackPathStep `json:"path"`
	FinalPrivilege string           `json:"final_privilege"`
	Severity       string           `json:"severity"`
}

type AttackPathsResponse struct {
	AttackPaths   []AttackPath `json:"attack_paths"`
	TotalPaths    int          `json:"total_paths"`
	CriticalPaths int          `json:"critical_paths"`
}
