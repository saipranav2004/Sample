package models

type SharedCredentialItem struct {
	CredentialID   string   `json:"credential_id"`
	Name           string   `json:"name"`
	CredentialType string   `json:"credential_type"`
	IdentityCount  int      `json:"identity_count"`
	IdentityTypes  []string `json:"identity_types"`
	BlastRadius    string   `json:"blast_radius"`
}

type SharedCredentialsResponse struct {
	SharedCredentials []SharedCredentialItem `json:"shared_credentials"`
	TotalShared       int                    `json:"total_shared"`
	TotalCritical     int                    `json:"total_critical"`
}
