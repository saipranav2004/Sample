package credentialexposure

type FindingsSummary struct {
	TotalFindings       int `json:"total_findings"`
	HighCount           int `json:"high_count"`
	MediumCount         int `json:"medium_count"`
	LowCount            int `json:"low_count"`
	AffectedRepositories int `json:"affected_repositories"`
}

type FindingsSummaryFilter struct {
	ClientID  string
	Platform  string
	MLFlagged bool
}
