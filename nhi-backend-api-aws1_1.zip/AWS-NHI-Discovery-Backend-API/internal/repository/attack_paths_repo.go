package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
)

type AttackPathsFilter struct {
	AccountID  string
	SourceType string
	MaxHops    int
}

type AttackPathsRepository struct {
	db *PostgresDB
}

func NewAttackPathsRepository(db *PostgresDB) *AttackPathsRepository {
	return &AttackPathsRepository{db: db}
}

type attackEdge struct {
	from     string
	to       string
	edgeType string
}

type attackCredential struct {
	id        string
	name      string
	privilege sql.NullInt64
	actions   map[string]bool
}

func (r *AttackPathsRepository) Find(ctx context.Context, f AttackPathsFilter) (*models.AttackPathsResponse, error) {
	if f.MaxHops <= 0 {
		f.MaxHops = 3
	}
	if f.MaxHops > 10 {
		f.MaxHops = 10
	}

	edges, err := r.loadEdges(ctx, f)
	if err != nil {
		return nil, err
	}
	credentials, err := r.loadCredentials(ctx)
	if err != nil {
		return nil, err
	}
	if err := r.loadActions(ctx, credentials); err != nil {
		return nil, err
	}

	byFrom := make(map[string][]attackEdge)
	indegree := make(map[string]int)
	nodes := make(map[string]bool)
	for _, edge := range edges {
		from, to := canonical(edge.from), canonical(edge.to)
		if from == "" || to == "" {
			continue
		}
		edge.from, edge.to = from, to
		byFrom[from] = append(byFrom[from], edge)
		indegree[to]++
		nodes[from], nodes[to] = true, true
	}

	starts := make([]string, 0)
	for node := range nodes {
		if f.SourceType != "" {
			needle := strings.ToLower(f.SourceType)
			if !strings.Contains(node, needle) {
				continue
			}
		} else if indegree[node] != 0 {
			continue
		}
		starts = append(starts, node)
	}
	if f.SourceType != "" && len(starts) == 0 {
		for node := range nodes {
			if strings.Contains(node, strings.ToLower(f.SourceType)) {
				starts = append(starts, node)
			}
		}
	}

	response := &models.AttackPathsResponse{AttackPaths: make([]models.AttackPath, 0)}
	seen := make(map[string]bool)
	for _, start := range starts {
		r.walk(start, start, nil, byFrom, credentials, f.MaxHops, seen, response)
	}
	return response, nil
}

func (r *AttackPathsRepository) loadEdges(ctx context.Context, f AttackPathsFilter) ([]attackEdge, error) {
	where := "WHERE scan_id = " + LatestScanIDSubquery() + " AND is_active IS TRUE"
	args := []interface{}{}
	if f.AccountID != "" {
		where += " AND (source_arn ILIKE '%' || $1 || '%' OR target_arn ILIKE '%' || $1 || '%')"
		args = append(args, f.AccountID)
	}
	query := fmt.Sprintf(`SELECT COALESCE(source_arn, ''), COALESCE(target_arn, ''), COALESCE(edge_type, '') FROM %s.trust_edges %s`, Schema, where)
	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("load attack path trust edges: %w", err)
	}
	defer rows.Close()
	result := make([]attackEdge, 0)
	for rows.Next() {
		var edge attackEdge
		if err := rows.Scan(&edge.from, &edge.to, &edge.edgeType); err != nil {
			return nil, fmt.Errorf("scan attack path edge: %w", err)
		}
		result = append(result, edge)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate attack path edges: %w", err)
	}
	return result, nil
}

func (r *AttackPathsRepository) loadCredentials(ctx context.Context) (map[string]*attackCredential, error) {
	query := fmt.Sprintf(`SELECT id::text, COALESCE(name, ''), privilege_level FROM %s.credentials WHERE scan_id = %s AND deleted_at IS NULL`, Schema, LatestScanIDSubquery())
	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("load attack path credentials: %w", err)
	}
	defer rows.Close()
	result := make(map[string]*attackCredential)
	for rows.Next() {
		item := &attackCredential{actions: make(map[string]bool)}
		if err := rows.Scan(&item.id, &item.name, &item.privilege); err != nil {
			return nil, fmt.Errorf("scan attack path credential: %w", err)
		}
		result[canonical(item.id)] = item
		if name := canonical(item.name); name != "" {
			result[name] = item
		}
		if tail := arnTail(item.name); tail != "" {
			result[tail] = item
		}
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate attack path credentials: %w", err)
	}
	return result, nil
}

func (r *AttackPathsRepository) loadActions(ctx context.Context, credentials map[string]*attackCredential) error {
	query := fmt.Sprintf(`SELECT credential_id::text, COALESCE(action, '') FROM %s.effective_permissions WHERE scan_id = %s`, Schema, LatestScanIDSubquery())
	rows, err := r.db.DB.QueryContext(ctx, query)
	if err != nil {
		return fmt.Errorf("load attack path permissions: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var id, action string
		if err := rows.Scan(&id, &action); err != nil {
			return fmt.Errorf("scan attack path permission: %w", err)
		}
		if credential := credentials[canonical(id)]; credential != nil {
			credential.actions[strings.ToLower(strings.TrimSpace(action))] = true
		}
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("iterate attack path permissions: %w", err)
	}
	return nil
}

func (r *AttackPathsRepository) walk(start, current string, path []attackEdge, graph map[string][]attackEdge, credentials map[string]*attackCredential, maxHops int, seen map[string]bool, response *models.AttackPathsResponse) {
	if len(path) > 0 {
		if credential := credentials[current]; credential != nil && len(path) >= 2 {
			privilege, severity := classifyPrivilege(credential)
			if severity != "low" {
				key := current + "|" + pathKey(path)
				if !seen[key] {
					seen[key] = true
					steps := make([]models.AttackPathStep, len(path))
					for i, edge := range path {
						steps[i] = models.AttackPathStep{Step: i + 1, From: displayNode(edge.from, credentials), To: displayNode(edge.to, credentials), EdgeType: edge.edgeType}
					}
					response.AttackPaths = append(response.AttackPaths, models.AttackPath{PathID: fmt.Sprintf("p%d", len(response.AttackPaths)+1), Hops: len(path), Source: start, SourceName: displayNode(start, credentials), Path: steps, FinalPrivilege: privilege, Severity: severity})
					response.TotalPaths++
					if severity == "critical" {
						response.CriticalPaths++
					}
				}
			}
		}
	}
	if len(path) >= maxHops || len(response.AttackPaths) >= 1000 {
		return
	}
	for _, edge := range graph[current] {
		already := edge.to == start
		for _, prior := range path {
			if prior.from == edge.to || prior.to == edge.to {
				already = true
				break
			}
		}
		if already {
			continue
		}
		r.walk(start, edge.to, append(path, edge), graph, credentials, maxHops, seen, response)
	}
}

func classifyPrivilege(c *attackCredential) (string, string) {
	level := int64(0)
	if c.privilege.Valid {
		level = c.privilege.Int64
	}
	if c.actions["*"] || c.actions["*:*"] || c.actions["iam:*"] {
		if level < 10 {
			level = 10
		}
	}
	if c.actions["iam:passrole"] && level < 6 {
		level = 6
	}
	switch {
	case level >= 8:
		return "admin", "critical"
	case level >= 6:
		return "high", "high"
	case level >= 3:
		return "medium", "medium"
	default:
		return "low", "low"
	}
}

func canonical(value string) string { return strings.ToLower(strings.TrimSpace(value)) }
func arnTail(value string) string {
	parts := strings.Split(strings.TrimSpace(value), "/")
	if len(parts) == 0 {
		return ""
	}
	return canonical(parts[len(parts)-1])
}
func displayNode(value string, credentials map[string]*attackCredential) string {
	if c := credentials[value]; c != nil && strings.TrimSpace(c.name) != "" {
		return c.name
	}
	return value
}
func pathKey(path []attackEdge) string {
	var b strings.Builder
	for _, edge := range path {
		b.WriteString(edge.from)
		b.WriteByte('>')
		b.WriteString(edge.to)
		b.WriteByte('|')
	}
	return b.String()
}
