// // Package repository contains the SQL of the NEW API endpoints.
// //
// // Two databases are involved and they are NEVER joined in SQL:
// //
// //	GLOBAL DB (config: global_database) → user_settings, accounts
// //	TENANT DB (JWT claim db_name)       → nhi_scans_aws
// //
// // The service layer combines the two results in Go.
// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/database"
// )

// const (
// 	userSettingsTable = "user_settings"
// 	accountsTable     = "accounts"
// 	scansTable        = "nhi_scans_aws"
// )

// // ── GLOBAL database ─────────────────────────────────────────────────────────

// type UserSettingsRow struct {
// 	SelectedAccountIDs []string
// 	SelectedRegions    []string
// 	SelectedScanID     *string
// }

// type DefaultAccountRow struct {
// 	AccountID string
// 	Region    string
// }

// type SettingsRepository struct {
// 	global *sql.DB
// 	schema string
// }

// func NewSettingsRepository(globalDB *sql.DB, globalSchema string) *SettingsRepository {
// 	return &SettingsRepository{global: globalDB, schema: globalSchema}
// }

// // GetUserSettings returns the saved preferences of a user, or nil if none exist.
// func (r *SettingsRepository) GetUserSettings(ctx context.Context, userID string) (*UserSettingsRow, error) {
// 	q := `
// 		SELECT selected_account_ids, selected_regions, selected_scan_id
// 		FROM ` + database.Table(r.schema, userSettingsTable) + `
// 		WHERE user_id = $1
// 		ORDER BY updated_at DESC NULLS LAST
// 		LIMIT 1`

// 	var accountsJSON, regionsJSON []byte
// 	var scanID sql.NullString
// 	err := r.global.QueryRowContext(ctx, q, userID).Scan(&accountsJSON, &regionsJSON, &scanID)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, nil
// 		}
// 		return nil, fmt.Errorf("query user_settings: %w", err)
// 	}

// 	row := &UserSettingsRow{
// 		SelectedAccountIDs: decodeStringList(accountsJSON),
// 		SelectedRegions:    decodeStringList(regionsJSON),
// 	}
// 	if scanID.Valid && strings.TrimSpace(scanID.String) != "" {
// 		v := strings.TrimSpace(scanID.String)
// 		row.SelectedScanID = &v
// 	}
// 	return row, nil
// }

// // GetDefaultAccounts returns the tenant's accounts flagged is_default = true.
// func (r *SettingsRepository) GetDefaultAccounts(ctx context.Context, tenantID string) ([]DefaultAccountRow, error) {
// 	q := `
// 		SELECT account_id, COALESCE(region, '')
// 		FROM ` + database.Table(r.schema, accountsTable) + `
// 		WHERE tenant_id = $1::uuid AND is_default = true
// 		ORDER BY account_id, region`

// 	rows, err := r.global.QueryContext(ctx, q, tenantID)
// 	if err != nil {
// 		return nil, fmt.Errorf("query default accounts: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []DefaultAccountRow
// 	for rows.Next() {
// 		var a DefaultAccountRow
// 		if err := rows.Scan(&a.AccountID, &a.Region); err != nil {
// 			return nil, fmt.Errorf("scan default account: %w", err)
// 		}
// 		out = append(out, a)
// 	}
// 	return out, rows.Err()
// }

// // decodeStringList turns a jsonb array into []string. It tolerates NULL, '[]',
// // and numeric elements (AWS account ids are sometimes stored as numbers).
// func decodeStringList(raw []byte) []string {
// 	if len(raw) == 0 {
// 		return nil
// 	}
// 	var items []interface{}
// 	if err := json.Unmarshal(raw, &items); err != nil {
// 		return nil
// 	}
// 	out := make([]string, 0, len(items))
// 	for _, it := range items {
// 		var s string
// 		switch v := it.(type) {
// 		case string:
// 			s = v
// 		case float64:
// 			s = fmt.Sprintf("%.0f", v)
// 		default:
// 			continue
// 		}
// 		if s = strings.TrimSpace(s); s != "" {
// 			out = append(out, s)
// 		}
// 	}
// 	return out
// }

// // ── TENANT (data) database ──────────────────────────────────────────────────

// type ScanInfo struct {
// 	ScanID  string
// 	ScanEnd *time.Time
// }

// type ScanRepository struct {
// 	schema string
// }

// func NewScanRepository(dataSchema string) *ScanRepository {
// 	return &ScanRepository{schema: dataSchema}
// }

// // GetCompletedScan returns the COMPLETED scan with this id, or nil if absent.
// // db is the tenant's data database, resolved per request from the JWT.
// func (r *ScanRepository) GetCompletedScan(ctx context.Context, db *sql.DB, scanID string) (*ScanInfo, error) {
// 	q := `
// 		SELECT scan_id, scan_end
// 		FROM ` + database.Table(r.schema, scansTable) + `
// 		WHERE scan_id = $1 AND status = 'COMPLETED'
// 		ORDER BY scan_end DESC NULLS LAST
// 		LIMIT 1`
// 	return r.queryScan(ctx, db, q, scanID)
// }

// // GetLatestCompletedScan returns the most recent COMPLETED scan, or nil if none.
// func (r *ScanRepository) GetLatestCompletedScan(ctx context.Context, db *sql.DB) (*ScanInfo, error) {
// 	q := `
// 		SELECT scan_id, scan_end
// 		FROM ` + database.Table(r.schema, scansTable) + `
// 		WHERE status = 'COMPLETED'
// 		ORDER BY scan_end DESC NULLS LAST, id DESC
// 		LIMIT 1`
// 	return r.queryScan(ctx, db, q)
// }

// func (r *ScanRepository) queryScan(ctx context.Context, db *sql.DB, q string, args ...interface{}) (*ScanInfo, error) {
// 	var id string
// 	var end sql.NullTime
// 	if err := db.QueryRowContext(ctx, q, args...).Scan(&id, &end); err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, nil
// 		}
// 		return nil, fmt.Errorf("query %s: %w", scansTable, err)
// 	}
// 	info := &ScanInfo{ScanID: id}
// 	if end.Valid {
// 		t := end.Time.UTC()
// 		info.ScanEnd = &t
// 	}
// 	return info, nil
// }





















package repository

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
)

const (
	userSettingsTable = "user_settings"
	accountsTable     = "accounts"
	scansTable        = "nhi_scans_aws"
)

// ── user_settings / accounts (data DB) ──────────────────────────────────────

type UserSettingsRow struct {
	SelectedAccountIDs []string
	SelectedRegions    []string
	SelectedScanID     *string
}

type DefaultAccountRow struct {
	AccountID string
	Region    string
}

type SettingsRepository struct {
	schema string // data schema from config (database.schema), e.g. nhi_scanner
}

func NewSettingsRepository(dataSchema string) *SettingsRepository {
	return &SettingsRepository{schema: dataSchema}
}

// GetUserSettings returns the saved preferences of a user, or nil if none exist.
// db is the tenant's data database.
func (r *SettingsRepository) GetUserSettings(ctx context.Context, db *sql.DB, userID string) (*UserSettingsRow, error) {
	q := `
		SELECT selected_account_ids, selected_regions, selected_scan_id
		FROM ` + database.Table(r.schema, userSettingsTable) + `
		WHERE user_id = $1
		ORDER BY updated_at DESC NULLS LAST
		LIMIT 1`

	var accountsJSON, regionsJSON []byte
	var scanID sql.NullString
	err := db.QueryRowContext(ctx, q, userID).Scan(&accountsJSON, &regionsJSON, &scanID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("query user_settings: %w", err)
	}

	row := &UserSettingsRow{
		SelectedAccountIDs: decodeStringList(accountsJSON),
		SelectedRegions:    decodeStringList(regionsJSON),
	}
	if scanID.Valid && strings.TrimSpace(scanID.String) != "" {
		v := strings.TrimSpace(scanID.String)
		row.SelectedScanID = &v
	}
	return row, nil
}

// GetDefaultAccounts returns the tenant's accounts flagged is_default = true.
// db is the tenant's data database.
func (r *SettingsRepository) GetDefaultAccounts(ctx context.Context, db *sql.DB, tenantID string) ([]DefaultAccountRow, error) {
	q := `
		SELECT account_id, COALESCE(region, '')
		FROM ` + database.Table(r.schema, accountsTable) + `
		WHERE tenant_id = $1::uuid AND is_default = true
		ORDER BY account_id, region`

	rows, err := db.QueryContext(ctx, q, tenantID)
	if err != nil {
		return nil, fmt.Errorf("query default accounts: %w", err)
	}
	defer rows.Close()

	var out []DefaultAccountRow
	for rows.Next() {
		var a DefaultAccountRow
		if err := rows.Scan(&a.AccountID, &a.Region); err != nil {
			return nil, fmt.Errorf("scan default account: %w", err)
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// decodeStringList turns a jsonb array into []string. It tolerates NULL, '[]',
// and numeric elements (AWS account ids are sometimes stored as numbers).
func decodeStringList(raw []byte) []string {
	if len(raw) == 0 {
		return nil
	}
	var items []interface{}
	if err := json.Unmarshal(raw, &items); err != nil {
		return nil
	}
	out := make([]string, 0, len(items))
	for _, it := range items {
		var s string
		switch v := it.(type) {
		case string:
			s = v
		case float64:
			s = fmt.Sprintf("%.0f", v)
		default:
			continue
		}
		if s = strings.TrimSpace(s); s != "" {
			out = append(out, s)
		}
	}
	return out
}

// ── nhi_scans_aws (data DB) ─────────────────────────────────────────────────

type ScanInfo struct {
	ScanID  string
	ScanEnd *time.Time
}

type ScanRepository struct {
	schema string
}

func NewScanRepository(dataSchema string) *ScanRepository {
	return &ScanRepository{schema: dataSchema}
}

// GetCompletedScan returns the COMPLETED scan with this id, or nil if absent.
func (r *ScanRepository) GetCompletedScan(ctx context.Context, db *sql.DB, scanID string) (*ScanInfo, error) {
	q := `
		SELECT scan_id, scan_end
		FROM ` + database.Table(r.schema, scansTable) + `
		WHERE scan_id = $1 AND UPPER(status) = 'COMPLETED'
		ORDER BY scan_end DESC NULLS LAST
		LIMIT 1`
	return r.queryScan(ctx, db, q, scanID)
}

// GetLatestCompletedScan returns the most recent COMPLETED scan, or nil if none.
func (r *ScanRepository) GetLatestCompletedScan(ctx context.Context, db *sql.DB) (*ScanInfo, error) {
	q := `
		SELECT scan_id, scan_end
		FROM ` + database.Table(r.schema, scansTable) + `
		WHERE UPPER(status) = 'COMPLETED'
		ORDER BY scan_end DESC NULLS LAST, id DESC
		LIMIT 1`
	return r.queryScan(ctx, db, q)
}

func (r *ScanRepository) queryScan(ctx context.Context, db *sql.DB, q string, args ...interface{}) (*ScanInfo, error) {
	var id string
	var end sql.NullTime
	if err := db.QueryRowContext(ctx, q, args...).Scan(&id, &end); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("query %s: %w", scansTable, err)
	}
	info := &ScanInfo{ScanID: id}
	if end.Valid {
		t := end.Time.UTC()
		info.ScanEnd = &t
	}
	return info, nil
}