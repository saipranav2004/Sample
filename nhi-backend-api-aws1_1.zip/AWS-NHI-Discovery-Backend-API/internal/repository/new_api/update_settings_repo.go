package repository

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"

	"nhi-backend-api/internal/database"
)

// UpdateSettingsRepository saves user preferences in the tenant DATA database,
// table user_settings(user_id, selected_account_ids, selected_regions,
// selected_scan_id, updated_at) — per spec's "Tables & Columns" section.
type UpdateSettingsRepository struct {
	schema string // data schema from config (database.schema), e.g. nhi_scanner
}

func NewUpdateSettingsRepository(dataSchema string) *UpdateSettingsRepository {
	return &UpdateSettingsRepository{schema: dataSchema}
}

// Upsert updates the user's row in user_settings, or inserts one if none exists.
// db is the tenant's data database (resolved from the JWT db_name).
func (r *UpdateSettingsRepository) Upsert(
	ctx context.Context, db *sql.DB, userID string,
	accountIDs, regions []string, scanID *string,
) error {
	accJSON, err := json.Marshal(accountIDs)
	if err != nil {
		return fmt.Errorf("encode selected_account_ids: %w", err)
	}
	regJSON, err := json.Marshal(regions)
	if err != nil {
		return fmt.Errorf("encode selected_regions: %w", err)
	}
	var scan sql.NullString
	if scanID != nil {
		scan = sql.NullString{String: *scanID, Valid: true}
	}

	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin user_settings save: %w", err)
	}
	defer tx.Rollback()

	table := database.Table(r.schema, userSettingsTable) // const from settings_repo.go

	res, err := tx.ExecContext(ctx, `
		UPDATE `+table+`
		SET selected_account_ids = $2::jsonb,
		    selected_regions     = $3::jsonb,
		    selected_scan_id     = $4,
		    updated_at           = NOW()
		WHERE user_id = $1`,
		userID, string(accJSON), string(regJSON), scan)
	if err != nil {
		return fmt.Errorf("update user_settings: %w", err)
	}

	n, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("check user_settings update: %w", err)
	}
	if n == 0 {
		_, err = tx.ExecContext(ctx, `
			INSERT INTO `+table+`
				(id, user_id, selected_account_ids, selected_regions, selected_scan_id, created_at, updated_at)
			VALUES (gen_random_uuid(), $1, $2::jsonb, $3::jsonb, $4, NOW(), NOW())`,
			userID, string(accJSON), string(regJSON), scan)
		if err != nil {
			return fmt.Errorf("insert user_settings: %w", err)
		}
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit user_settings save: %w", err)
	}
	return nil
}