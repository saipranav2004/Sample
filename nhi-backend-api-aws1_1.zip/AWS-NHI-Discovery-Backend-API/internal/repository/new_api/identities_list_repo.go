package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/database"
)

// identitiesSortColumns whitelists sort_by values → their SQL expression.
// MUST stay a fixed whitelist — sort_by is interpolated directly into
// ORDER BY and must never accept raw user input.
var identitiesSortColumns = map[string]string{
	"id":                      "i.id",
	"name":                    "i.name",
	"arn":                     "i.arn",
	"identity_type":           "i.identity_type",
	"functional_class":        "i.functional_class",
	"account_id":              "i.account_id",
	"region":                  "i.region",
	"environment":             "i.environment",
	"owner":                   "i.owner",
	"status":                  "i.status",
	"is_publicly_accessible":  "i.is_publicly_accessible",
	"vpc_id":                  "i.vpc_id",
	"last_activity_at":        "i.last_activity_at",
	"created_at_aws":          "i.created_at_aws",
	"age_days":                "age_days",
	"idle_days":               "idle_days",
	"bound_credentials_count": "bound_credentials_count",
}

// IdentitiesSortColumnAllowed reports whether sort_by is a recognized column
// (exported so the service layer can validate before querying).
func IdentitiesSortColumnAllowed(col string) (string, bool) {
	sql, ok := identitiesSortColumns[col]
	return sql, ok
}

// IdentitiesListFilter is the fully-validated set of query params for
// GET /api/v1/identities.
type IdentitiesListFilter struct {
	ScanID               string
	Search               string
	IdentityTypes        []string
	FunctionalClasses    []string
	Environments         []string
	Statuses             []string
	Owner                string
	VpcID                string
	IsPubliclyAccessible *bool
	MinIdleDays          *int
	SortColumn           string // already resolved SQL expression (via IdentitiesSortColumnAllowed)
	SortOrder            string // "ASC" or "DESC", already validated
	Page                 int
	PageSize             int
}

type IdentitiesListRepository struct {
	schema string
}

func NewIdentitiesListRepository(dataSchema string) *IdentitiesListRepository {
	return &IdentitiesListRepository{schema: dataSchema}
}

func (r *IdentitiesListRepository) t(name string) string { return database.Table(r.schema, name) }

type IdentityListRow struct {
	ID                    string
	Name                  string
	ARN                   string
	IdentityType          string
	FunctionalClass       string
	AccountID             string
	Region                string
	Environment           string
	Owner                 string
	Status                string
	IsPubliclyAccessible  bool
	VpcID                 sql.NullString
	BoundCredentialsCount int
	LastActivityAt        *time.Time
	CreatedAtAWS          *time.Time
	AgeDays               int
	IdleDays              int
	CreatedBy             string
	GrantedCount          int64
	UsedCount             int64
}

// buildWhere returns the WHERE clause (without "WHERE") and its positional
// args, starting at $1 (scan_id). Caller appends sort/limit/offset args after.
func (r *IdentitiesListRepository) buildWhere(f IdentitiesListFilter) (string, []interface{}) {
	args := []interface{}{f.ScanID}
	where := []string{
		"i.scan_id = $1",
		"i.deleted_at IS NULL",
	}
	next := func(v interface{}) string {
		args = append(args, v)
		return fmt.Sprintf("$%d", len(args))
	}

	if s := strings.TrimSpace(f.Search); s != "" {
		ph := next("%" + s + "%")
		where = append(where, fmt.Sprintf(
			"(i.name ILIKE %[1]s OR i.arn ILIKE %[1]s OR i.tags::text ILIKE %[1]s)", ph))
	}
	if len(f.IdentityTypes) > 0 {
		where = append(where, fmt.Sprintf("i.identity_type = ANY(%s::text[])", next(pq.Array(f.IdentityTypes))))
	}
	if len(f.FunctionalClasses) > 0 {
		where = append(where, fmt.Sprintf("i.functional_class = ANY(%s::text[])", next(pq.Array(f.FunctionalClasses))))
	}
	if len(f.Environments) > 0 {
		where = append(where, fmt.Sprintf("i.environment = ANY(%s::text[])", next(pq.Array(f.Environments))))
	}
	if len(f.Statuses) > 0 {
		where = append(where, fmt.Sprintf("i.status = ANY(%s::text[])", next(pq.Array(f.Statuses))))
	}
	if o := strings.TrimSpace(f.Owner); o != "" {
		where = append(where, fmt.Sprintf("i.owner = %s", next(o)))
	}
	if v := strings.TrimSpace(f.VpcID); v != "" {
		where = append(where, fmt.Sprintf("i.vpc_id = %s", next(v)))
	}
	if f.IsPubliclyAccessible != nil {
		where = append(where, fmt.Sprintf("i.is_publicly_accessible = %s", next(*f.IsPubliclyAccessible)))
	}
	if f.MinIdleDays != nil {
		where = append(where, fmt.Sprintf(
			"COALESCE(i.last_activity_at, i.created_at_aws) <= NOW() - make_interval(days => %s::int)",
			next(*f.MinIdleDays)))
	}

	return strings.Join(where, " AND "), args
}

// Count returns the total number of identities matching the filter
// (no joins needed — every filter column lives on identities itself).
func (r *IdentitiesListRepository) Count(ctx context.Context, db *sql.DB, f IdentitiesListFilter) (int, error) {
	whereClause, args := r.buildWhere(f)
	q := fmt.Sprintf(`SELECT COUNT(*) FROM %s i WHERE %s`, r.t(identitiesTable), whereClause)

	var total int
	if err := db.QueryRowContext(ctx, q, args...).Scan(&total); err != nil {
		return 0, fmt.Errorf("count identities: %w", err)
	}
	return total, nil
}

// List returns one page of identities, with bound-credential count and
// granted/used permission sums (identity → identity_credentials →
// effective_permissions / permission_usage).
func (r *IdentitiesListRepository) List(ctx context.Context, db *sql.DB, f IdentitiesListFilter) ([]IdentityListRow, error) {
	whereClause, args := r.buildWhere(f)

	limitPH := fmt.Sprintf("$%d", len(args)+1)
	offsetPH := fmt.Sprintf("$%d", len(args)+2)
	args = append(args, f.PageSize, (f.Page-1)*f.PageSize)

	orderDir := "DESC"
	if strings.EqualFold(f.SortOrder, "ASC") {
		orderDir = "ASC"
	}

	q := fmt.Sprintf(`
		SELECT
			i.id::text,
			COALESCE(i.name, ''),
			COALESCE(i.arn, ''),
			COALESCE(i.identity_type, ''),
			COALESCE(i.functional_class, ''),
			COALESCE(i.account_id, ''),
			COALESCE(i.region, ''),
			COALESCE(i.environment, ''),
			COALESCE(i.owner, ''),
			COALESCE(i.status, ''),
			COALESCE(i.is_publicly_accessible, false),
			i.vpc_id,
			COALESCE(bc.cnt, 0) AS bound_credentials_count,
			i.last_activity_at,
			i.created_at_aws,
			COALESCE(FLOOR(EXTRACT(EPOCH FROM (NOW() - i.created_at_aws)) / 86400), 0)::int AS age_days,
			COALESCE(FLOOR(EXTRACT(EPOCH FROM (NOW() - COALESCE(i.last_activity_at, i.created_at_aws))) / 86400), 0)::int AS idle_days,
			COALESCE(i.cloudtrail_creator_arn, '') AS created_by,
			COALESCE(perm.granted, 0) AS granted_count,
			COALESCE(perm.used, 0)    AS used_count
		FROM %[1]s i
		LEFT JOIN LATERAL (
			SELECT COUNT(*) AS cnt
			FROM %[2]s ic
			WHERE ic.identity_id = i.id AND ic.scan_id = i.scan_id
		) bc ON TRUE
		LEFT JOIN LATERAL (
			SELECT
				COALESCE(SUM(ep.granted_count), 0) AS granted,
				COALESCE((
					SELECT COUNT(*) FROM (
						SELECT DISTINCT pu.credential_id, pu.action
						FROM %[4]s pu
						JOIN %[2]s ic2 ON ic2.credential_id = pu.credential_id AND ic2.scan_id = pu.scan_id
						WHERE ic2.identity_id = i.id AND ic2.scan_id = i.scan_id
						  AND COALESCE(pu.usage_count_90d, 0) > 0
					) x
				), 0) AS used
			FROM %[3]s ep
			JOIN %[2]s ic3 ON ic3.credential_id = ep.credential_id AND ic3.scan_id = ep.scan_id
			WHERE ic3.identity_id = i.id AND ic3.scan_id = i.scan_id
		) perm ON TRUE
		WHERE %[5]s
		ORDER BY %[6]s %[7]s, i.id
		LIMIT %[8]s OFFSET %[9]s`,
		r.t(identitiesTable),        // %1
		r.t(identityCredentialsTable), // %2
		r.t(effectivePermsTable),    // %3
		r.t(permissionUsageTable),   // %4
		whereClause,                 // %5
		f.SortColumn,                // %6
		orderDir,                    // %7
		limitPH,                     // %8
		offsetPH,                    // %9
	)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("list identities: %w", err)
	}
	defer rows.Close()

	out := []IdentityListRow{}
	for rows.Next() {
		var row IdentityListRow
		if err := rows.Scan(
			&row.ID, &row.Name, &row.ARN, &row.IdentityType, &row.FunctionalClass,
			&row.AccountID, &row.Region, &row.Environment, &row.Owner, &row.Status,
			&row.IsPubliclyAccessible, &row.VpcID, &row.BoundCredentialsCount,
			&row.LastActivityAt, &row.CreatedAtAWS, &row.AgeDays, &row.IdleDays,
			&row.CreatedBy, &row.GrantedCount, &row.UsedCount,
		); err != nil {
			return nil, fmt.Errorf("scan identity row: %w", err)
		}
		out = append(out, row)
	}
	return out, rows.Err()
}