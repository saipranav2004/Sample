package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/database"
)

// Table names assumed NOT yet declared elsewhere in this package.
// credentialsTable already exists (dashboard_overview_repo.go) — do NOT
// redeclare it here.
const (
	identityUsageTable = "identity_usage"
	trustEdgesTable    = "trust_edges"
	resourcesTable     = "resources"
)

type IdentityDetailRepository struct {
	schema string
}

func NewIdentityDetailRepository(dataSchema string) *IdentityDetailRepository {
	return &IdentityDetailRepository{schema: dataSchema}
}

func (r *IdentityDetailRepository) t(name string) string { return database.Table(r.schema, name) }

// ── Existence check ──────────────────────────────────────────────────────

func (r *IdentityDetailRepository) IdentityExists(ctx context.Context, db *sql.DB, scanID, identityID string) (bool, error) {
	q := fmt.Sprintf(`SELECT EXISTS(SELECT 1 FROM %s WHERE scan_id = $1 AND id = $2 AND deleted_at IS NULL)`, r.t(identitiesTable))
	var exists bool
	if err := db.QueryRowContext(ctx, q, scanID, identityID).Scan(&exists); err != nil {
		return false, fmt.Errorf("check identity exists: %w", err)
	}
	return exists, nil
}

// ── tab=overview ─────────────────────────────────────────────────────────

type OverviewRow struct {
	ID                   string
	Name                 string
	ARN                  string
	IdentityType         string
	FunctionalClass      string
	AccountID            string
	Region               string
	VpcID                sql.NullString
	SubnetID             sql.NullString
	SecurityGroupIDs     []byte // jsonb array of strings
	Environment          string
	Owner                string
	Status               string
	IsPubliclyAccessible bool
	CreatedAtAWS         *time.Time
	AgeDays              int
	FirstSeenAt          *time.Time
	LastSeenAt           *time.Time
	LastActivityAt       *time.Time
	IdleDays             int
	ParentARN            sql.NullString
	CreatedBy            string
	DiscoverySource      sql.NullString
	ScanID               string
	UpdatedAt            *time.Time // used as a "last scanned" proxy — see service layer
	TypeAttributes       []byte
	Tags                 []byte
}

func (r *IdentityDetailRepository) GetOverview(ctx context.Context, db *sql.DB, scanID, identityID string) (*OverviewRow, error) {
	q := fmt.Sprintf(`
		SELECT
			i.id::text, COALESCE(i.name,''), COALESCE(i.arn,''), COALESCE(i.identity_type,''),
			COALESCE(i.functional_class,''), COALESCE(i.account_id,''), COALESCE(i.region,''),
			i.vpc_id, i.subnet_id, COALESCE(i.security_group_ids,'[]'::jsonb),
			COALESCE(i.environment,''), COALESCE(i.owner,''), COALESCE(i.status,''),
			COALESCE(i.is_publicly_accessible,false), i.created_at_aws,
			COALESCE(FLOOR(EXTRACT(EPOCH FROM (NOW()-i.created_at_aws))/86400),0)::int,
			i.first_seen_at, i.last_seen_at, i.last_activity_at,
			COALESCE(FLOOR(EXTRACT(EPOCH FROM (NOW()-COALESCE(i.last_activity_at, i.created_at_aws)))/86400),0)::int,
			i.parent_arn, COALESCE(i.cloudtrail_creator_arn,''),
			i.discovery_source, i.scan_id, i.updated_at,
			COALESCE(i.type_attributes,'{}'::jsonb), COALESCE(i.tags,'{}'::jsonb)
		FROM %s i
		WHERE i.scan_id = $1 AND i.id = $2 AND i.deleted_at IS NULL`, r.t(identitiesTable))

	var row OverviewRow
	err := db.QueryRowContext(ctx, q, scanID, identityID).Scan(
		&row.ID, &row.Name, &row.ARN, &row.IdentityType, &row.FunctionalClass,
		&row.AccountID, &row.Region, &row.VpcID, &row.SubnetID, &row.SecurityGroupIDs,
		&row.Environment, &row.Owner, &row.Status, &row.IsPubliclyAccessible, &row.CreatedAtAWS,
		&row.AgeDays, &row.FirstSeenAt, &row.LastSeenAt, &row.LastActivityAt, &row.IdleDays,
		&row.ParentARN, &row.CreatedBy, &row.DiscoverySource, &row.ScanID, &row.UpdatedAt,
		&row.TypeAttributes, &row.Tags,
	)
	if err != nil {
		return nil, err // sql.ErrNoRows bubbles up to the service layer
	}
	return &row, nil
}

type BoundCredentialRow struct {
	CredentialID          string
	Name                  string
	CredentialType        string
	BindingType           string
	IsPrimary             bool
	TrustPrincipal        string // sourced from credentials.owner_principal_arn (closest available field)
	AttachedPoliciesCount int
	InlinePoliciesCount   int
	GrantedCount          int64
	UsedCount             int64
}

func (r *IdentityDetailRepository) GetBoundCredentials(ctx context.Context, db *sql.DB, scanID, identityID string) ([]BoundCredentialRow, error) {
	q := fmt.Sprintf(`
		SELECT
			c.id::text, COALESCE(c.name,''), COALESCE(c.credential_type,''),
			COALESCE(ic.binding_type,''), COALESCE(ic.is_primary,false), COALESCE(c.owner_principal_arn,''),
			jsonb_array_length(COALESCE(c.attached_policies,'[]'::jsonb)),
			jsonb_array_length(COALESCE(c.inline_policies,'[]'::jsonb)),
			COALESCE(ep.granted,0), COALESCE(pu.used,0)
		FROM %[1]s ic
		JOIN %[2]s c ON c.id = ic.credential_id AND c.scan_id = ic.scan_id
		LEFT JOIN LATERAL (
			SELECT COALESCE(SUM(ep.granted_count),0) AS granted
			FROM %[3]s ep WHERE ep.credential_id = c.id AND ep.scan_id = c.scan_id
		) ep ON TRUE
		LEFT JOIN LATERAL (
			SELECT COUNT(DISTINCT pu.action) AS used
			FROM %[4]s pu
			WHERE pu.credential_id = c.id AND pu.scan_id = c.scan_id AND COALESCE(pu.usage_count_90d,0) > 0
		) pu ON TRUE
		WHERE ic.identity_id = $1 AND ic.scan_id = $2
		ORDER BY ic.is_primary DESC, c.name`,
		r.t(identityCredentialsTable), r.t(credentialsTable), r.t(effectivePermsTable), r.t(permissionUsageTable))

	rows, err := db.QueryContext(ctx, q, identityID, scanID)
	if err != nil {
		return nil, fmt.Errorf("get bound credentials: %w", err)
	}
	defer rows.Close()

	out := []BoundCredentialRow{}
	for rows.Next() {
		var b BoundCredentialRow
		if err := rows.Scan(&b.CredentialID, &b.Name, &b.CredentialType, &b.BindingType, &b.IsPrimary,
			&b.TrustPrincipal, &b.AttachedPoliciesCount, &b.InlinePoliciesCount, &b.GrantedCount, &b.UsedCount); err != nil {
			return nil, fmt.Errorf("scan bound credential: %w", err)
		}
		out = append(out, b)
	}
	return out, rows.Err()
}

func (r *IdentityDetailRepository) HasWildcardResourceScope(ctx context.Context, db *sql.DB, scanID, identityID string) (bool, error) {
	q := fmt.Sprintf(`
		SELECT EXISTS (
			SELECT 1
			FROM %[1]s ic
			JOIN %[2]s ep ON ep.credential_id = ic.credential_id AND ep.scan_id = ic.scan_id
			CROSS JOIN LATERAL jsonb_array_elements(COALESCE(ep.permissions,'[]'::jsonb)) perm
			WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND perm->>'resource_arn' = '*'
		)`, r.t(identityCredentialsTable), r.t(effectivePermsTable))

	var exists bool
	if err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&exists); err != nil {
		return false, fmt.Errorf("check wildcard resource scope: %w", err)
	}
	return exists, nil
}

type PrimaryCredentialRiskRow struct {
	ExpiresAt         *time.Time
	LastRotatedAt     *time.Time
	TrustPolicy       []byte
	OwnerPrincipalARN string
}

// GetPrimaryCredentialRisk fetches the fields needed to evaluate the
// "expired/expiring", "never rotated" and "cross-account trust" risk
// signals on the overview tab. Returns (nil, nil) if no primary credential
// is bound — that's a valid state, not an error.
func (r *IdentityDetailRepository) GetPrimaryCredentialRisk(ctx context.Context, db *sql.DB, scanID, identityID string) (*PrimaryCredentialRiskRow, error) {
	q := fmt.Sprintf(`
		SELECT c.expires_at, c.last_rotated_at, COALESCE(c.trust_policy,'{}'::jsonb), COALESCE(c.owner_principal_arn,'')
		FROM %[1]s ic
		JOIN %[2]s c ON c.id = ic.credential_id AND c.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND ic.is_primary = true
		LIMIT 1`, r.t(identityCredentialsTable), r.t(credentialsTable))

	var row PrimaryCredentialRiskRow
	err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&row.ExpiresAt, &row.LastRotatedAt, &row.TrustPolicy, &row.OwnerPrincipalARN)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get primary credential risk: %w", err)
	}
	return &row, nil
}

// ── tab=permissions ─────────────────────────────────────────────────────

type PermissionsFilter struct {
	Service  string
	UsedOnly *bool
}

type PermissionSummaryRow struct {
	GrantedCount int
	UsedCount    int
}

func (r *IdentityDetailRepository) GetPermissionsSummary(ctx context.Context, db *sql.DB, scanID, identityID string) (*PermissionSummaryRow, error) {
	q := fmt.Sprintf(`
		SELECT COUNT(*) AS granted,
			COUNT(*) FILTER (WHERE pu.credential_id IS NOT NULL) AS used
		FROM %[1]s ic
		JOIN %[2]s ep ON ep.credential_id = ic.credential_id AND ep.scan_id = ic.scan_id
		CROSS JOIN LATERAL jsonb_array_elements(COALESCE(ep.permissions,'[]'::jsonb)) perm
		LEFT JOIN %[3]s pu ON pu.credential_id = ic.credential_id AND pu.scan_id = ic.scan_id
			AND pu.action = perm->>'action' AND COALESCE(pu.usage_count_90d,0) > 0
		WHERE ic.identity_id = $1 AND ic.scan_id = $2`,
		r.t(identityCredentialsTable), r.t(effectivePermsTable), r.t(permissionUsageTable))

	var s PermissionSummaryRow
	if err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&s.GrantedCount, &s.UsedCount); err != nil {
		return nil, fmt.Errorf("get permissions summary: %w", err)
	}
	return &s, nil
}

type PermissionRow struct {
	Service      string
	Action       string
	ResourceARN  string
	Effect       string
	PolicySource string
	PolicyType   string
	Used         bool
	LastUsedAt   *time.Time
	SourceIPs    []byte // jsonb array of strings — unmarshal in service
}

func (r *IdentityDetailRepository) ListPermissions(ctx context.Context, db *sql.DB, scanID, identityID string, f PermissionsFilter) ([]PermissionRow, error) {
	args := []interface{}{identityID, scanID}
	next := func(v interface{}) string { args = append(args, v); return fmt.Sprintf("$%d", len(args)) }

	where := ""
	if s := strings.TrimSpace(f.Service); s != "" {
		where += fmt.Sprintf(" AND perm->>'service' = %s", next(s))
	}
	if f.UsedOnly != nil && *f.UsedOnly {
		where += " AND pu.credential_id IS NOT NULL"
	}

	q := fmt.Sprintf(`
		SELECT
			COALESCE(perm->>'service',''), COALESCE(perm->>'action',''), COALESCE(perm->>'resource_arn',''),
			COALESCE(perm->>'effect',''), COALESCE(perm->>'policy_source',''), COALESCE(perm->>'policy_type',''),
			(pu.credential_id IS NOT NULL) AS used, pu.last_used_at, COALESCE(pu.source_ips,'[]'::jsonb)
		FROM %[1]s ic
		JOIN %[2]s ep ON ep.credential_id = ic.credential_id AND ep.scan_id = ic.scan_id
		CROSS JOIN LATERAL jsonb_array_elements(COALESCE(ep.permissions,'[]'::jsonb)) perm
		LEFT JOIN %[3]s pu ON pu.credential_id = ic.credential_id AND pu.scan_id = ic.scan_id
			AND pu.action = perm->>'action' AND COALESCE(pu.usage_count_90d,0) > 0
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 %[4]s
		ORDER BY perm->>'service', perm->>'action'`,
		r.t(identityCredentialsTable), r.t(effectivePermsTable), r.t(permissionUsageTable), where)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("list permissions: %w", err)
	}
	defer rows.Close()

	out := []PermissionRow{}
	for rows.Next() {
		var p PermissionRow
		if err := rows.Scan(&p.Service, &p.Action, &p.ResourceARN, &p.Effect, &p.PolicySource,
			&p.PolicyType, &p.Used, &p.LastUsedAt, &p.SourceIPs); err != nil {
			return nil, fmt.Errorf("scan permission: %w", err)
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

type PolicyBreakdownRowDB struct {
	PolicyName       string
	PolicyType       string
	TotalPermissions int
	UsedPermissions  int
}

func (r *IdentityDetailRepository) GetPolicyBreakdown(ctx context.Context, db *sql.DB, scanID, identityID string) ([]PolicyBreakdownRowDB, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(perm->>'policy_source',''), COALESCE(perm->>'policy_type',''),
			COUNT(*) AS total, COUNT(*) FILTER (WHERE pu.credential_id IS NOT NULL) AS used
		FROM %[1]s ic
		JOIN %[2]s ep ON ep.credential_id = ic.credential_id AND ep.scan_id = ic.scan_id
		CROSS JOIN LATERAL jsonb_array_elements(COALESCE(ep.permissions,'[]'::jsonb)) perm
		LEFT JOIN %[3]s pu ON pu.credential_id = ic.credential_id AND pu.scan_id = ic.scan_id
			AND pu.action = perm->>'action' AND COALESCE(pu.usage_count_90d,0) > 0
		WHERE ic.identity_id = $1 AND ic.scan_id = $2
		GROUP BY 1,2
		ORDER BY total DESC`,
		r.t(identityCredentialsTable), r.t(effectivePermsTable), r.t(permissionUsageTable))

	rows, err := db.QueryContext(ctx, q, identityID, scanID)
	if err != nil {
		return nil, fmt.Errorf("get policy breakdown: %w", err)
	}
	defer rows.Close()

	out := []PolicyBreakdownRowDB{}
	for rows.Next() {
		var p PolicyBreakdownRowDB
		if err := rows.Scan(&p.PolicyName, &p.PolicyType, &p.TotalPermissions, &p.UsedPermissions); err != nil {
			return nil, fmt.Errorf("scan policy breakdown: %w", err)
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

// ── tab=activity ─────────────────────────────────────────────────────────
//
// NOTE: identity_usage is a PRE-AGGREGATED table (event_name, service,
// resource_arn, event_count, first_seen, last_seen, window_start/end) — it
// has no per-call source_ip / user_agent / error_code / request_id, and its
// identity_id column is bigint (not comparable to identities.id uuid). All
// queries below therefore join via identity_credentials.credential_id
// (uuid ↔ uuid) instead of identity_usage.identity_id.

type ActivityFilter struct {
	Start, End time.Time
	Service    string
	Page       int
	PageSize   int
}

type VolumeChartRow struct {
	Day   time.Time
	Count int
}

func (r *IdentityDetailRepository) GetVolumeChart(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter) ([]VolumeChartRow, error) {
	args := []interface{}{identityID, scanID, f.Start, f.End}
	svcFilter := ""
	if s := strings.TrimSpace(f.Service); s != "" {
		args = append(args, s)
		svcFilter = fmt.Sprintf(" AND iu.service = $%d", len(args))
	}
	q := fmt.Sprintf(`
		SELECT date_trunc('day', iu.last_seen)::date, COALESCE(SUM(iu.event_count),0)::int
		FROM %[1]s ic
		JOIN %[2]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND iu.last_seen BETWEEN $3 AND $4 %[3]s
		GROUP BY 1 ORDER BY 1`, r.t(identityCredentialsTable), r.t(identityUsageTable), svcFilter)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("get volume chart: %w", err)
	}
	defer rows.Close()
	out := []VolumeChartRow{}
	for rows.Next() {
		var v VolumeChartRow
		if err := rows.Scan(&v.Day, &v.Count); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

// ActivityEventRow represents one aggregated usage row (NOT a single API
// call — see note above). Service layer maps these onto the ActivityEvent
// JSON shape, leaving source_ip/region/user_agent/error_code/request_id
// empty since that granularity doesn't exist in this schema.
type ActivityEventRow struct {
	LastSeen    time.Time
	EventName   string
	Service     string
	ResourceARN string
	EventCount  int
}

func (r *IdentityDetailRepository) ListRecentEvents(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter) ([]ActivityEventRow, int, error) {
	args := []interface{}{identityID, scanID, f.Start, f.End}
	svcFilter := ""
	if s := strings.TrimSpace(f.Service); s != "" {
		args = append(args, s)
		svcFilter = fmt.Sprintf(" AND iu.service = $%d", len(args))
	}

	countQ := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM %[1]s ic
		JOIN %[2]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id=$1 AND ic.scan_id=$2 AND iu.last_seen BETWEEN $3 AND $4 %[3]s`,
		r.t(identityCredentialsTable), r.t(identityUsageTable), svcFilter)
	var total int
	if err := db.QueryRowContext(ctx, countQ, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count events: %w", err)
	}

	limitPH := fmt.Sprintf("$%d", len(args)+1)
	offsetPH := fmt.Sprintf("$%d", len(args)+2)
	args = append(args, f.PageSize, (f.Page-1)*f.PageSize)

	q := fmt.Sprintf(`
		SELECT iu.last_seen, COALESCE(iu.event_name,''), COALESCE(iu.service,''),
			COALESCE(iu.resource_arn,''), COALESCE(iu.event_count,0)
		FROM %[1]s ic
		JOIN %[2]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND iu.last_seen BETWEEN $3 AND $4 %[3]s
		ORDER BY iu.last_seen DESC
		LIMIT %[4]s OFFSET %[5]s`, r.t(identityCredentialsTable), r.t(identityUsageTable), svcFilter, limitPH, offsetPH)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("list recent events: %w", err)
	}
	defer rows.Close()

	out := []ActivityEventRow{}
	for rows.Next() {
		var e ActivityEventRow
		if err := rows.Scan(&e.LastSeen, &e.EventName, &e.Service, &e.ResourceARN, &e.EventCount); err != nil {
			return nil, 0, fmt.Errorf("scan event: %w", err)
		}
		out = append(out, e)
	}
	return out, total, rows.Err()
}

type ActivityTotalsRow struct {
	TotalEvents int
}

func (r *IdentityDetailRepository) GetActivityTotals(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter) (*ActivityTotalsRow, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(SUM(iu.event_count),0)::int
		FROM %[1]s ic
		JOIN %[2]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND iu.last_seen BETWEEN $3 AND $4`,
		r.t(identityCredentialsTable), r.t(identityUsageTable))

	var a ActivityTotalsRow
	if err := db.QueryRowContext(ctx, q, identityID, scanID, f.Start, f.End).Scan(&a.TotalEvents); err != nil {
		return nil, fmt.Errorf("get activity totals: %w", err)
	}
	return &a, nil
}

type KeyCount struct {
	Key   string
	Count int
}

func (r *IdentityDetailRepository) TopServices(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	return r.topUsageGroupBy(ctx, db, "service", scanID, identityID, f, limit)
}
func (r *IdentityDetailRepository) TopActions(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	return r.topUsageGroupBy(ctx, db, "event_name", scanID, identityID, f, limit)
}

// topUsageGroupBy groups identity_usage by a hardcoded column (never user
// input — only "service" or "event_name" ever get passed in above).
func (r *IdentityDetailRepository) topUsageGroupBy(ctx context.Context, db *sql.DB, col, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(iu.%[1]s,'') AS k, COALESCE(SUM(iu.event_count),0)::int AS c
		FROM %[2]s ic
		JOIN %[3]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND iu.last_seen BETWEEN $3 AND $4
		GROUP BY 1 ORDER BY c DESC LIMIT $5`, col, r.t(identityCredentialsTable), r.t(identityUsageTable))

	rows, err := db.QueryContext(ctx, q, identityID, scanID, f.Start, f.End, limit)
	if err != nil {
		return nil, fmt.Errorf("top %s: %w", col, err)
	}
	defer rows.Close()
	out := []KeyCount{}
	for rows.Next() {
		var k KeyCount
		if err := rows.Scan(&k.Key, &k.Count); err != nil {
			return nil, err
		}
		out = append(out, k)
	}
	return out, rows.Err()
}

func (r *IdentityDetailRepository) PeakHours(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter, limit int) ([]HourCount, error) {
	q := fmt.Sprintf(`
		SELECT EXTRACT(HOUR FROM iu.last_seen)::int AS h, COALESCE(SUM(iu.event_count),0)::int AS c
		FROM %[1]s ic
		JOIN %[2]s iu ON iu.credential_id = ic.credential_id AND iu.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND iu.last_seen BETWEEN $3 AND $4
		GROUP BY 1 ORDER BY c DESC LIMIT $5`, r.t(identityCredentialsTable), r.t(identityUsageTable))

	rows, err := db.QueryContext(ctx, q, identityID, scanID, f.Start, f.End, limit)
	if err != nil {
		return nil, fmt.Errorf("peak hours: %w", err)
	}
	defer rows.Close()
	out := []HourCount{}
	for rows.Next() {
		var h HourCount
		if err := rows.Scan(&h.Hour, &h.Count); err != nil {
			return nil, err
		}
		out = append(out, h)
	}
	return out, rows.Err()
}

type HourCount struct {
	Hour  int
	Count int
}

// TopSourceIPs / TopActiveRegions pull from permission_usage (which has
// source_ips / regions jsonb arrays) since identity_usage has neither.
func (r *IdentityDetailRepository) TopSourceIPs(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	return r.topPermissionUsageArray(ctx, db, "source_ips", scanID, identityID, f, limit)
}
func (r *IdentityDetailRepository) TopActiveRegions(ctx context.Context, db *sql.DB, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	return r.topPermissionUsageArray(ctx, db, "regions", scanID, identityID, f, limit)
}

// topPermissionUsageArray unnests a jsonb array column on permission_usage
// (col is always "source_ips" or "regions" — never user input).
func (r *IdentityDetailRepository) topPermissionUsageArray(ctx context.Context, db *sql.DB, col, scanID, identityID string, f ActivityFilter, limit int) ([]KeyCount, error) {
	args := []interface{}{identityID, scanID, f.Start, f.End}
	svcFilter := ""
	if s := strings.TrimSpace(f.Service); s != "" {
		args = append(args, s)
		svcFilter = fmt.Sprintf(" AND pu.service = $%d", len(args))
	}
	args = append(args, limit)
	limitPH := fmt.Sprintf("$%d", len(args))

	q := fmt.Sprintf(`
		SELECT elem AS k, COALESCE(SUM(pu.usage_count_90d),0)::int AS c
		FROM %[1]s ic
		JOIN %[2]s pu ON pu.credential_id = ic.credential_id AND pu.scan_id = ic.scan_id
		CROSS JOIN LATERAL jsonb_array_elements_text(COALESCE(pu.%[3]s,'[]'::jsonb)) AS elem
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND pu.last_used_at BETWEEN $3 AND $4 %[4]s
		GROUP BY 1 ORDER BY c DESC LIMIT %[5]s`,
		r.t(identityCredentialsTable), r.t(permissionUsageTable), col, svcFilter, limitPH)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("top %s: %w", col, err)
	}
	defer rows.Close()
	out := []KeyCount{}
	for rows.Next() {
		var k KeyCount
		if err := rows.Scan(&k.Key, &k.Count); err != nil {
			return nil, err
		}
		out = append(out, k)
	}
	return out, rows.Err()
}

// ── tab=relationships ─────────────────────────────────────────────────────

func (r *IdentityDetailRepository) GetIdentityARN(ctx context.Context, db *sql.DB, scanID, identityID string) (string, error) {
	q := fmt.Sprintf(`SELECT arn FROM %s WHERE id=$1 AND scan_id=$2 AND deleted_at IS NULL`, r.t(identitiesTable))
	var arn string
	if err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&arn); err != nil {
		return "", err
	}
	return arn, nil
}

func (r *IdentityDetailRepository) GetIdentityAccountID(ctx context.Context, db *sql.DB, scanID, identityID string) (string, error) {
	q := fmt.Sprintf(`SELECT COALESCE(account_id,'') FROM %s WHERE id=$1 AND scan_id=$2 AND deleted_at IS NULL`, r.t(identitiesTable))
	var accountID string
	if err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&accountID); err != nil {
		return "", err
	}
	return accountID, nil
}

type TrustEdgeRow struct {
	SourceARN string
	TargetARN string
	EdgeType  string
	CreatedAt *time.Time
	Metadata  []byte // sourced from trust_edges.conditions
	Hop       int
}

func (r *IdentityDetailRepository) GetTrustEdges(ctx context.Context, db *sql.DB, scanID, rootARN string, depth int, edgeType string) ([]TrustEdgeRow, error) {
	args := []interface{}{scanID, rootARN, depth}
	edgeFilter := ""
	if e := strings.TrimSpace(edgeType); e != "" {
		args = append(args, e)
		edgeFilter = fmt.Sprintf(" AND edge_type = $%d", len(args))
	}

	q := fmt.Sprintf(`
		WITH RECURSIVE edges AS (
			SELECT source_arn, target_arn, edge_type, created_at, conditions, 1 AS hop
			FROM %[1]s
			WHERE scan_id = $1 AND source_arn = $2 AND is_active = true %[2]s
			UNION
			SELECT te.source_arn, te.target_arn, te.edge_type, te.created_at, te.conditions, e.hop + 1
			FROM %[1]s te
			JOIN edges e ON te.source_arn = e.target_arn AND te.scan_id = $1 AND te.is_active = true
			WHERE e.hop < $3 %[2]s
		)
		SELECT DISTINCT source_arn, target_arn, edge_type, created_at, conditions, hop
		FROM edges ORDER BY hop, source_arn, target_arn`, r.t(trustEdgesTable), edgeFilter)

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("get trust edges: %w", err)
	}
	defer rows.Close()
	out := []TrustEdgeRow{}
	for rows.Next() {
		var e TrustEdgeRow
		if err := rows.Scan(&e.SourceARN, &e.TargetARN, &e.EdgeType, &e.CreatedAt, &e.Metadata, &e.Hop); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

type NodeRow struct {
	ARN       string
	Name      string
	Type      string
	Subtype   string
	IsCurrent bool
}

func (r *IdentityDetailRepository) ResolveNodes(ctx context.Context, db *sql.DB, scanID string, arns []string) ([]NodeRow, error) {
	if len(arns) == 0 {
		return nil, nil
	}
	q := fmt.Sprintf(`
		SELECT arn, COALESCE(name,''), 'identity', COALESCE(identity_type,''), true
		FROM %[1]s WHERE scan_id = $1 AND arn = ANY($2::text[])
		UNION ALL
		SELECT arn, COALESCE(name,''), 'credential', COALESCE(credential_type,''), true
		FROM %[2]s WHERE scan_id = $1 AND arn = ANY($2::text[])
		UNION ALL
		SELECT arn, COALESCE(name,''), 'resource', COALESCE(resource_type,''), true
		FROM %[3]s WHERE scan_id = $1 AND arn = ANY($2::text[])`,
		r.t(identitiesTable), r.t(credentialsTable), r.t(resourcesTable))

	rows, err := db.QueryContext(ctx, q, scanID, pq.Array(arns))
	if err != nil {
		return nil, fmt.Errorf("resolve nodes: %w", err)
	}
	defer rows.Close()
	out := []NodeRow{}
	for rows.Next() {
		var n NodeRow
		if err := rows.Scan(&n.ARN, &n.Name, &n.Type, &n.Subtype, &n.IsCurrent); err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

// ── tab=credentials ─────────────────────────────────────────────────────

type CredentialDetailRow struct {
	CredentialID          string
	Name                  string
	ARN                   string
	CredentialType        string
	BindingType           string
	BindingSource         string
	IsPrimary             bool
	TrustPolicy           []byte
	AttachedPolicies      []byte
	InlinePolicies        []byte
	CreatedAtAWS          *time.Time
	LastUsedAt            *time.Time
	LastRotatedAt         *time.Time
	RotationEnabled       bool
	RotationIntervalDays  sql.NullInt64
	ExpiresAt             *time.Time
	MaxSessionDuration    sql.NullInt64
	PermissionBoundaryARN sql.NullString
	AssumableRoleARNs     []byte
	OwnerPrincipalARN     string
}

func (r *IdentityDetailRepository) GetCredentials(ctx context.Context, db *sql.DB, scanID, identityID string) ([]CredentialDetailRow, error) {
	q := fmt.Sprintf(`
		SELECT
			c.id::text, COALESCE(c.name,''), COALESCE(c.arn,''), COALESCE(c.credential_type,''),
			COALESCE(ic.binding_type,''), COALESCE(ic.binding_source,''), COALESCE(ic.is_primary,false),
			COALESCE(c.trust_policy,'{}'::jsonb),
			COALESCE(c.attached_policies,'[]'::jsonb), COALESCE(c.inline_policies,'[]'::jsonb),
			c.created_at_aws, c.last_used_at, c.last_rotated_at,
			COALESCE(c.rotation_enabled,false), c.rotation_interval_days, c.expires_at,
			c.max_session_duration, c.permission_boundary_arn, COALESCE(c.assumable_role_arns,'[]'::jsonb),
			COALESCE(c.owner_principal_arn,'')
		FROM %[1]s ic
		JOIN %[2]s c ON c.id = ic.credential_id AND c.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2
		ORDER BY ic.is_primary DESC, c.name`, r.t(identityCredentialsTable), r.t(credentialsTable))

	rows, err := db.QueryContext(ctx, q, identityID, scanID)
	if err != nil {
		return nil, fmt.Errorf("get credentials: %w", err)
	}
	defer rows.Close()

	out := []CredentialDetailRow{}
	for rows.Next() {
		var c CredentialDetailRow
		if err := rows.Scan(
			&c.CredentialID, &c.Name, &c.ARN, &c.CredentialType, &c.BindingType, &c.BindingSource, &c.IsPrimary,
			&c.TrustPolicy, &c.AttachedPolicies, &c.InlinePolicies,
			&c.CreatedAtAWS, &c.LastUsedAt, &c.LastRotatedAt, &c.RotationEnabled, &c.RotationIntervalDays,
			&c.ExpiresAt, &c.MaxSessionDuration, &c.PermissionBoundaryARN, &c.AssumableRoleARNs,
			&c.OwnerPrincipalARN,
		); err != nil {
			return nil, fmt.Errorf("scan credential: %w", err)
		}
		out = append(out, c)
	}
	return out, rows.Err()
}

// ── tab=raw ─────────────────────────────────────────────────────────────

type RawRow struct {
	IdentityRecord []byte
	RawAPIResponse []byte
	TypeAttributes []byte
}

func (r *IdentityDetailRepository) GetRaw(ctx context.Context, db *sql.DB, scanID, identityID string) (*RawRow, error) {
	q := fmt.Sprintf(`
		SELECT to_jsonb(i), COALESCE(i.raw_api_response,'{}'::jsonb), COALESCE(i.type_attributes,'{}'::jsonb)
		FROM %s i WHERE i.id = $1 AND i.scan_id = $2 AND i.deleted_at IS NULL`, r.t(identitiesTable))

	var row RawRow
	if err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&row.IdentityRecord, &row.RawAPIResponse, &row.TypeAttributes); err != nil {
		return nil, err
	}
	return &row, nil
}

type ResolvedCredentialRow struct {
	RoleARN          string
	BindingType      string
	AttachedPolicies int
	InlinePolicies   int
}

func (r *IdentityDetailRepository) GetResolvedCredential(ctx context.Context, db *sql.DB, scanID, identityID string) (*ResolvedCredentialRow, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(c.arn,''), COALESCE(ic.binding_type,''),
			jsonb_array_length(COALESCE(c.attached_policies,'[]'::jsonb)),
			jsonb_array_length(COALESCE(c.inline_policies,'[]'::jsonb))
		FROM %[1]s ic
		JOIN %[2]s c ON c.id = ic.credential_id AND c.scan_id = ic.scan_id
		WHERE ic.identity_id = $1 AND ic.scan_id = $2 AND ic.is_primary = true
		LIMIT 1`, r.t(identityCredentialsTable), r.t(credentialsTable))

	var row ResolvedCredentialRow
	err := db.QueryRowContext(ctx, q, identityID, scanID).Scan(&row.RoleARN, &row.BindingType, &row.AttachedPolicies, &row.InlinePolicies)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get resolved credential: %w", err)
	}
	return &row, nil
}