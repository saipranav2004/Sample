// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"
// 	"time"

// 	"github.com/lib/pq"

// 	"nhi-backend-api/internal/database"
// )

// // NOTE: credentialsTable, identityCredentialsTable, identitiesTable,
// // effectivePermsTable, permissionUsageTable, identityUsageTable,
// // trustEdgesTable, resourcesTable are assumed to already exist as
// // package-level consts elsewhere in internal/repository/new_api
// // (established by identity_detail.go and credentials_list_repo.go).
// // Do NOT redeclare them here.

// type CredentialDetailRepository struct {
// 	schema string
// }

// func NewCredentialDetailRepository(dataSchema string) *CredentialDetailRepository {
// 	return &CredentialDetailRepository{schema: dataSchema}
// }

// // ── core row (all columns needed across every tab) ──────────────────────

// type CredentialCoreRow struct {
// 	ID                    string
// 	ARN                   string
// 	Name                  string
// 	CredentialType        string
// 	AccountID             string
// 	Region                string
// 	Status                string
// 	CreatedAtAWS          sql.NullTime
// 	FirstSeenAt           sql.NullTime
// 	LastSeenAt            sql.NullTime
// 	DeletedAt             sql.NullTime
// 	LastUsedAt            sql.NullTime
// 	LastRotatedAt         sql.NullTime
// 	ExpiresAt             sql.NullTime
// 	RotationEnabled       bool
// 	RotationIntervalDays  sql.NullInt64
// 	Tags                  []byte
// 	OwnerPrincipalARN     sql.NullString
// 	TrustPolicy           []byte
// 	AttachedPolicies      []byte
// 	InlinePolicies        []byte
// 	PermissionBoundaryARN sql.NullString
// 	MaxSessionDuration    sql.NullInt64
// 	PrivilegeLevel        sql.NullInt64
// 	AssumableRoleARNs     []byte
// 	DiscoverySource       sql.NullString
// 	ScanID                string
// 	TypeAttributes        []byte
// 	RawAPIResponse        []byte
// 	CreatedAt             sql.NullTime
// 	UpdatedAt             sql.NullTime
// }

// // GetCore fetches one credential scoped to a given scan. Returns (nil, nil)
// // if not found — the service decides whether that's a 404.
// func (r *CredentialDetailRepository) GetCore(ctx context.Context, db *sql.DB, credentialID, scanID string) (*CredentialCoreRow, error) {
// 	table := database.Table(r.schema, credentialsTable)
// 	q := `
// 		SELECT id::text, arn, name, credential_type, account_id, region, status,
// 		       created_at_aws, first_seen_at, last_seen_at, deleted_at,
// 		       last_used_at, last_rotated_at, expires_at,
// 		       COALESCE(rotation_enabled, false), rotation_interval_days,
// 		       tags, owner_principal_arn, trust_policy, attached_policies, inline_policies,
// 		       permission_boundary_arn, max_session_duration, privilege_level,
// 		       assumable_role_arns, discovery_source, scan_id, type_attributes,
// 		       raw_api_response, created_at, updated_at
// 		FROM ` + table + `
// 		WHERE id = $1::uuid AND scan_id = $2 AND deleted_at IS NULL
// 		LIMIT 1`

// 	var c CredentialCoreRow
// 	err := db.QueryRowContext(ctx, q, credentialID, scanID).Scan(
// 		&c.ID, &c.ARN, &c.Name, &c.CredentialType, &c.AccountID, &c.Region, &c.Status,
// 		&c.CreatedAtAWS, &c.FirstSeenAt, &c.LastSeenAt, &c.DeletedAt,
// 		&c.LastUsedAt, &c.LastRotatedAt, &c.ExpiresAt,
// 		&c.RotationEnabled, &c.RotationIntervalDays,
// 		&c.Tags, &c.OwnerPrincipalARN, &c.TrustPolicy, &c.AttachedPolicies, &c.InlinePolicies,
// 		&c.PermissionBoundaryARN, &c.MaxSessionDuration, &c.PrivilegeLevel,
// 		&c.AssumableRoleARNs, &c.DiscoverySource, &c.ScanID, &c.TypeAttributes,
// 		&c.RawAPIResponse, &c.CreatedAt, &c.UpdatedAt,
// 	)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, nil
// 	}
// 	if err != nil {
// 		return nil, fmt.Errorf("get credential core: %w", err)
// 	}
// 	return &c, nil
// }

// // ── bound identities (overview + activity tabs) ──────────────────────────

// type CredBoundIdentityRow struct {
// 	IdentityID     string
// 	Name           sql.NullString
// 	IdentityType   sql.NullString
// 	AccountID      sql.NullString
// 	Status         sql.NullString
// 	LastActivityAt sql.NullTime
// 	BindingType    sql.NullString
// }

// // GetBoundIdentities joins through identity_credentials (uuid↔uuid — safe,
// // unlike identity_usage.identity_id which is bigint).
// func (r *CredentialDetailRepository) GetBoundIdentities(ctx context.Context, db *sql.DB, credentialID, scanID string) ([]CredBoundIdentityRow, error) {
// 	icTable := database.Table(r.schema, identityCredentialsTable)
// 	idTable := database.Table(r.schema, identitiesTable)

// 	q := `
// 		SELECT i.id::text, i.name, i.identity_type, i.account_id, i.status,
// 		       i.last_activity_at, ic.binding_type
// 		FROM ` + icTable + ` ic
// 		JOIN ` + idTable + ` i ON i.id = ic.identity_id
// 		WHERE ic.credential_id = $1::uuid AND ic.scan_id = $2 AND i.deleted_at IS NULL
// 		ORDER BY i.name NULLS LAST`

// 	rows, err := db.QueryContext(ctx, q, credentialID, scanID)
// 	if err != nil {
// 		return nil, fmt.Errorf("query bound identities: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []CredBoundIdentityRow
// 	for rows.Next() {
// 		var b CredBoundIdentityRow
// 		if err := rows.Scan(&b.IdentityID, &b.Name, &b.IdentityType, &b.AccountID, &b.Status, &b.LastActivityAt, &b.BindingType); err != nil {
// 			return nil, fmt.Errorf("scan bound identity: %w", err)
// 		}
// 		out = append(out, b)
// 	}
// 	return out, rows.Err()
// }

// // ── trust tab ─────────────────────────────────────────────────────────────

// // GetEffectivePermissionsRaw returns the raw permissions jsonb array, or nil
// // if the credential has no effective_permissions row for this scan.
// func (r *CredentialDetailRepository) GetEffectivePermissionsRaw(ctx context.Context, db *sql.DB, credentialID, scanID string) ([]byte, error) {
// 	table := database.Table(r.schema, effectivePermsTable)
// 	var raw []byte
// 	q := `SELECT permissions FROM ` + table + ` WHERE credential_id = $1::uuid AND scan_id = $2 LIMIT 1`
// 	err := db.QueryRowContext(ctx, q, credentialID, scanID).Scan(&raw)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, nil
// 	}
// 	if err != nil {
// 		return nil, fmt.Errorf("get effective_permissions: %w", err)
// 	}
// 	return raw, nil
// }

// // GetTrustEdgeConditions returns the conditions jsonb for the most recent
// // trust_edges row from sourceARN to targetARN, or nil if none found.
// func (r *CredentialDetailRepository) GetTrustEdgeConditions(ctx context.Context, db *sql.DB, sourceARN, targetARN, scanID string) ([]byte, error) {
// 	table := database.Table(r.schema, trustEdgesTable)
// 	var raw []byte
// 	q := `
// 		SELECT conditions FROM ` + table + `
// 		WHERE source_arn = $1 AND target_arn = $2 AND scan_id = $3
// 		ORDER BY created_at DESC LIMIT 1`
// 	err := db.QueryRowContext(ctx, q, sourceARN, targetARN, scanID).Scan(&raw)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, nil
// 	}
// 	if err != nil {
// 		return nil, fmt.Errorf("get trust_edges conditions: %w", err)
// 	}
// 	return raw, nil
// }

// // GetLastAssumedAt returns the most recent sts:AssumeRole-ish usage of this
// // credential against targetARN, from permission_usage.
// func (r *CredentialDetailRepository) GetLastAssumedAt(ctx context.Context, db *sql.DB, credentialID, targetARN, scanID string) (sql.NullTime, error) {
// 	table := database.Table(r.schema, permissionUsageTable)
// 	var t sql.NullTime
// 	q := `
// 		SELECT MAX(last_used_at) FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND resource_arn = $2 AND scan_id = $3
// 		  AND (action ILIKE '%assumerole%' OR service ILIKE 'sts')`
// 	if err := db.QueryRowContext(ctx, q, credentialID, targetARN, scanID).Scan(&t); err != nil {
// 		return sql.NullTime{}, fmt.Errorf("get last assumed at: %w", err)
// 	}
// 	return t, nil
// }

// // ── activity tab ───────────────────────────────────────────────────────

// type CredVolumePointRow struct {
// 	Date  time.Time
// 	Count int
// }

// func (r *CredentialDetailRepository) GetVolumeChart(ctx context.Context, db *sql.DB, credentialID, scanID string, since time.Time) ([]CredVolumePointRow, error) {
// 	table := database.Table(r.schema, identityUsageTable)
// 	q := `
// 		SELECT DATE(COALESCE(window_start, first_seen)) AS d, COALESCE(SUM(event_count),0)::int
// 		FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND scan_id = $2
// 		  AND COALESCE(window_start, first_seen) >= $3
// 		GROUP BY d
// 		ORDER BY d`
// 	rows, err := db.QueryContext(ctx, q, credentialID, scanID, since)
// 	if err != nil {
// 		return nil, fmt.Errorf("query volume chart: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []CredVolumePointRow
// 	for rows.Next() {
// 		var v CredVolumePointRow
// 		if err := rows.Scan(&v.Date, &v.Count); err != nil {
// 			return nil, fmt.Errorf("scan volume point: %w", err)
// 		}
// 		out = append(out, v)
// 	}
// 	return out, rows.Err()
// }

// func (r *CredentialDetailRepository) CountRecentEvents(ctx context.Context, db *sql.DB, credentialID, scanID string, since time.Time) (int, error) {
// 	table := database.Table(r.schema, identityUsageTable)
// 	var total int
// 	q := `
// 		SELECT COUNT(*) FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3`
// 	if err := db.QueryRowContext(ctx, q, credentialID, scanID, since).Scan(&total); err != nil {
// 		return 0, fmt.Errorf("count identity_usage: %w", err)
// 	}
// 	return total, nil
// }

// type CredRecentEventRow struct {
// 	EventTime   sql.NullTime
// 	EventName   string
// 	Service     string
// 	ResourceARN sql.NullString
// 	EventCount  int
// }

// // GetRecentEvents returns identity_usage rows (newest first, capped). This
// // table is pre-aggregated (counts per window), not a raw event log, so
// // source_ip/region/user_agent/error_code cannot be populated.
// func (r *CredentialDetailRepository) GetRecentEvents(ctx context.Context, db *sql.DB, credentialID, scanID string, since time.Time, limit int) ([]CredRecentEventRow, error) {
// 	table := database.Table(r.schema, identityUsageTable)
// 	q := `
// 		SELECT last_seen, COALESCE(event_name,''), COALESCE(service,''), resource_arn, COALESCE(event_count,0)
// 		FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3
// 		ORDER BY last_seen DESC NULLS LAST
// 		LIMIT $4`
// 	rows, err := db.QueryContext(ctx, q, credentialID, scanID, since, limit)
// 	if err != nil {
// 		return nil, fmt.Errorf("query recent events: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []CredRecentEventRow
// 	for rows.Next() {
// 		var e CredRecentEventRow
// 		if err := rows.Scan(&e.EventTime, &e.EventName, &e.Service, &e.ResourceARN, &e.EventCount); err != nil {
// 			return nil, fmt.Errorf("scan recent event: %w", err)
// 		}
// 		out = append(out, e)
// 	}
// 	return out, rows.Err()
// }

// type CredServiceCountRow struct {
// 	Service string
// 	Count   int
// }

// func (r *CredentialDetailRepository) GetTopServices(ctx context.Context, db *sql.DB, credentialID, scanID string, since time.Time) ([]CredServiceCountRow, error) {
// 	table := database.Table(r.schema, identityUsageTable)
// 	q := `
// 		SELECT COALESCE(service,'unknown'), COALESCE(SUM(event_count),0)::int
// 		FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) >= $3
// 		GROUP BY service
// 		ORDER BY SUM(event_count) DESC`
// 	rows, err := db.QueryContext(ctx, q, credentialID, scanID, since)
// 	if err != nil {
// 		return nil, fmt.Errorf("query top services: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []CredServiceCountRow
// 	for rows.Next() {
// 		var s CredServiceCountRow
// 		if err := rows.Scan(&s.Service, &s.Count); err != nil {
// 			return nil, fmt.Errorf("scan top service: %w", err)
// 		}
// 		out = append(out, s)
// 	}
// 	return out, rows.Err()
// }

// func (r *CredentialDetailRepository) CountDistinctActiveDays(ctx context.Context, db *sql.DB, credentialID, scanID string, since time.Time) (int, error) {
// 	table := database.Table(r.schema, identityUsageTable)
// 	var n int
// 	q := `
// 		SELECT COUNT(DISTINCT DATE(COALESCE(window_start, first_seen)))
// 		FROM ` + table + `
// 		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(window_start, first_seen) >= $3`
// 	if err := db.QueryRowContext(ctx, q, credentialID, scanID, since).Scan(&n); err != nil {
// 		return 0, fmt.Errorf("count distinct active days: %w", err)
// 	}
// 	return n, nil
// }

// // ── relationships tab ──────────────────────────────────────────────────

// type CredGraphEdgeRow struct {
// 	Source    string
// 	Target    string
// 	EdgeType  sql.NullString
// 	CreatedAt sql.NullTime
// }

// func (r *CredentialDetailRepository) GetEdgesTouching(ctx context.Context, db *sql.DB, scanID string, arns []string, edgeTypes []string) ([]CredGraphEdgeRow, error) {
// 	if len(arns) == 0 {
// 		return nil, nil
// 	}
// 	table := database.Table(r.schema, trustEdgesTable)
// 	args := []interface{}{scanID, pq.Array(arns)}
// 	typeFilter := ""
// 	if len(edgeTypes) > 0 {
// 		args = append(args, pq.Array(edgeTypes))
// 		typeFilter = "AND edge_type = ANY($3)"
// 	}
// 	q := `
// 		SELECT source_arn, target_arn, edge_type, created_at
// 		FROM ` + table + `
// 		WHERE scan_id = $1 AND (source_arn = ANY($2) OR target_arn = ANY($2)) ` + typeFilter

// 	rows, err := db.QueryContext(ctx, q, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("query trust_edges: %w", err)
// 	}
// 	defer rows.Close()

// 	var out []CredGraphEdgeRow
// 	for rows.Next() {
// 		var e CredGraphEdgeRow
// 		if err := rows.Scan(&e.Source, &e.Target, &e.EdgeType, &e.CreatedAt); err != nil {
// 			return nil, fmt.Errorf("scan trust_edge: %w", err)
// 		}
// 		out = append(out, e)
// 	}
// 	return out, rows.Err()
// }

// type CredNodeInfoRow struct {
// 	Name           sql.NullString
// 	NodeType       string // credential | identity | resource | unknown
// 	Subtype        sql.NullString
// 	LastActivityAt sql.NullTime
// }

// // ResolveNodes classifies each ARN as credential, identity, or resource
// // (checked in that order), scoped to the same scan. Anything unmatched
// // falls back to type "unknown".
// func (r *CredentialDetailRepository) ResolveNodes(ctx context.Context, db *sql.DB, scanID string, arns []string) (map[string]CredNodeInfoRow, error) {
// 	result := make(map[string]CredNodeInfoRow, len(arns))
// 	if len(arns) == 0 {
// 		return result, nil
// 	}
// 	arnArray := pq.Array(arns)

// 	credTable := database.Table(r.schema, credentialsTable)
// 	credQ := `SELECT arn, name, credential_type FROM ` + credTable + ` WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL`
// 	if rows, err := db.QueryContext(ctx, credQ, scanID, arnArray); err == nil {
// 		for rows.Next() {
// 			var arn string
// 			var name, subtype sql.NullString
// 			if rows.Scan(&arn, &name, &subtype) == nil {
// 				result[arn] = CredNodeInfoRow{Name: name, NodeType: "credential", Subtype: subtype}
// 			}
// 		}
// 		rows.Close()
// 	}

// 	idTable := database.Table(r.schema, identitiesTable)
// 	idQ := `SELECT arn, name, identity_type, last_activity_at FROM ` + idTable + ` WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL`
// 	if rows, err := db.QueryContext(ctx, idQ, scanID, arnArray); err == nil {
// 		for rows.Next() {
// 			var arn string
// 			var name, subtype sql.NullString
// 			var lastActivity sql.NullTime
// 			if rows.Scan(&arn, &name, &subtype, &lastActivity) == nil {
// 				if _, exists := result[arn]; !exists {
// 					result[arn] = CredNodeInfoRow{Name: name, NodeType: "identity", Subtype: subtype, LastActivityAt: lastActivity}
// 				}
// 			}
// 		}
// 		rows.Close()
// 	}

// 	resTable := database.Table(r.schema, resourcesTable)
// 	resQ := `SELECT arn, name, resource_type FROM ` + resTable + ` WHERE scan_id=$1 AND arn = ANY($2)`
// 	if rows, err := db.QueryContext(ctx, resQ, scanID, arnArray); err == nil {
// 		for rows.Next() {
// 			var arn string
// 			var name, subtype sql.NullString
// 			if rows.Scan(&arn, &name, &subtype) == nil {
// 				if _, exists := result[arn]; !exists {
// 					result[arn] = CredNodeInfoRow{Name: name, NodeType: "resource", Subtype: subtype}
// 				}
// 			}
// 		}
// 		rows.Close()
// 	}

// 	for _, arn := range arns {
// 		if _, ok := result[arn]; !ok {
// 			result[arn] = CredNodeInfoRow{NodeType: "unknown"}
// 		}
// 	}
// 	return result, nil
// }






























package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/database"
)

// NOTE: credentialsTable, identityCredentialsTable, identitiesTable,
// effectivePermsTable, permissionUsageTable, identityUsageTable,
// trustEdgesTable, resourcesTable are assumed to already exist as
// package-level consts elsewhere in internal/repository/new_api
// (established by identity_detail.go and credentials_list_repo.go).
// Do NOT redeclare them here.

type CredentialDetailRepository struct {
	schema string
}

func NewCredentialDetailRepository(dataSchema string) *CredentialDetailRepository {
	return &CredentialDetailRepository{schema: dataSchema}
}

// ── core row (all columns needed across every tab) ──────────────────────

type CredentialCoreRow struct {
	ID                    string
	ARN                   string
	Name                  string
	CredentialType        string
	AccountID             string
	Region                string
	Status                string
	CreatedAtAWS          sql.NullTime
	FirstSeenAt           sql.NullTime
	LastSeenAt            sql.NullTime
	DeletedAt             sql.NullTime
	LastUsedAt            sql.NullTime
	LastRotatedAt         sql.NullTime
	ExpiresAt             sql.NullTime
	RotationEnabled       bool
	RotationIntervalDays  sql.NullInt64
	Tags                  []byte
	OwnerPrincipalARN     sql.NullString
	TrustPolicy           []byte
	AttachedPolicies      []byte
	InlinePolicies        []byte
	PermissionBoundaryARN sql.NullString
	MaxSessionDuration    sql.NullInt64
	PrivilegeLevel        sql.NullInt64
	AssumableRoleARNs     []byte
	DiscoverySource       sql.NullString
	ScanID                string
	TypeAttributes        []byte
	RawAPIResponse        []byte
	CreatedAt             sql.NullTime
	UpdatedAt             sql.NullTime
}

// GetCore fetches one credential scoped to a given scan. Returns (nil, nil)
// if not found — the service decides whether that's a 404.
func (r *CredentialDetailRepository) GetCore(ctx context.Context, db *sql.DB, credentialID, scanID string) (*CredentialCoreRow, error) {
	table := database.Table(r.schema, credentialsTable)
	q := `
		SELECT id::text, arn, name, credential_type, account_id, region, status,
		       created_at_aws, first_seen_at, last_seen_at, deleted_at,
		       last_used_at, last_rotated_at, expires_at,
		       COALESCE(rotation_enabled, false), rotation_interval_days,
		       tags, owner_principal_arn, trust_policy, attached_policies, inline_policies,
		       permission_boundary_arn, max_session_duration, privilege_level,
		       assumable_role_arns, discovery_source, scan_id, type_attributes,
		       raw_api_response, created_at, updated_at
		FROM ` + table + `
		WHERE id = $1::uuid AND scan_id = $2 AND deleted_at IS NULL
		LIMIT 1`

	var c CredentialCoreRow
	err := db.QueryRowContext(ctx, q, credentialID, scanID).Scan(
		&c.ID, &c.ARN, &c.Name, &c.CredentialType, &c.AccountID, &c.Region, &c.Status,
		&c.CreatedAtAWS, &c.FirstSeenAt, &c.LastSeenAt, &c.DeletedAt,
		&c.LastUsedAt, &c.LastRotatedAt, &c.ExpiresAt,
		&c.RotationEnabled, &c.RotationIntervalDays,
		&c.Tags, &c.OwnerPrincipalARN, &c.TrustPolicy, &c.AttachedPolicies, &c.InlinePolicies,
		&c.PermissionBoundaryARN, &c.MaxSessionDuration, &c.PrivilegeLevel,
		&c.AssumableRoleARNs, &c.DiscoverySource, &c.ScanID, &c.TypeAttributes,
		&c.RawAPIResponse, &c.CreatedAt, &c.UpdatedAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get credential core: %w", err)
	}
	return &c, nil
}

// ── bound identities (overview + activity tabs) ──────────────────────────

type CredBoundIdentityRow struct {
	IdentityID     string
	Name           sql.NullString
	IdentityType   sql.NullString
	AccountID      sql.NullString
	Status         sql.NullString
	LastActivityAt sql.NullTime
	BindingType    sql.NullString
}

// GetBoundIdentities joins through identity_credentials (uuid↔uuid — safe,
// unlike identity_usage.identity_id which is bigint).
func (r *CredentialDetailRepository) GetBoundIdentities(ctx context.Context, db *sql.DB, credentialID, scanID string) ([]CredBoundIdentityRow, error) {
	icTable := database.Table(r.schema, identityCredentialsTable)
	idTable := database.Table(r.schema, identitiesTable)

	q := `
		SELECT i.id::text, i.name, i.identity_type, i.account_id, i.status,
		       i.last_activity_at, ic.binding_type
		FROM ` + icTable + ` ic
		JOIN ` + idTable + ` i ON i.id = ic.identity_id
		WHERE ic.credential_id = $1::uuid AND ic.scan_id = $2 AND i.deleted_at IS NULL
		ORDER BY i.name NULLS LAST`

	rows, err := db.QueryContext(ctx, q, credentialID, scanID)
	if err != nil {
		return nil, fmt.Errorf("query bound identities: %w", err)
	}
	defer rows.Close()

	var out []CredBoundIdentityRow
	for rows.Next() {
		var b CredBoundIdentityRow
		if err := rows.Scan(&b.IdentityID, &b.Name, &b.IdentityType, &b.AccountID, &b.Status, &b.LastActivityAt, &b.BindingType); err != nil {
			return nil, fmt.Errorf("scan bound identity: %w", err)
		}
		out = append(out, b)
	}
	return out, rows.Err()
}

// ── trust tab ─────────────────────────────────────────────────────────────

// GetEffectivePermissionsRaw returns the raw permissions jsonb array, or nil
// if the credential has no effective_permissions row for this scan.
func (r *CredentialDetailRepository) GetEffectivePermissionsRaw(ctx context.Context, db *sql.DB, credentialID, scanID string) ([]byte, error) {
	table := database.Table(r.schema, effectivePermsTable)
	var raw []byte
	q := `SELECT permissions FROM ` + table + ` WHERE credential_id = $1::uuid AND scan_id = $2 LIMIT 1`
	err := db.QueryRowContext(ctx, q, credentialID, scanID).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get effective_permissions: %w", err)
	}
	return raw, nil
}

// GetTrustEdgeConditions returns the conditions jsonb for the most recent
// trust_edges row from sourceARN to targetARN, or nil if none found.
func (r *CredentialDetailRepository) GetTrustEdgeConditions(ctx context.Context, db *sql.DB, sourceARN, targetARN, scanID string) ([]byte, error) {
	table := database.Table(r.schema, trustEdgesTable)
	var raw []byte
	q := `
		SELECT conditions FROM ` + table + `
		WHERE source_arn = $1 AND target_arn = $2 AND scan_id = $3
		ORDER BY created_at DESC LIMIT 1`
	err := db.QueryRowContext(ctx, q, sourceARN, targetARN, scanID).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get trust_edges conditions: %w", err)
	}
	return raw, nil
}

// GetLastAssumedAt returns the most recent sts:AssumeRole-ish usage of this
// credential against targetARN, from permission_usage.
func (r *CredentialDetailRepository) GetLastAssumedAt(ctx context.Context, db *sql.DB, credentialID, targetARN, scanID string) (sql.NullTime, error) {
	table := database.Table(r.schema, permissionUsageTable)
	var t sql.NullTime
	q := `
		SELECT MAX(last_used_at) FROM ` + table + `
		WHERE credential_id = $1::uuid AND resource_arn = $2 AND scan_id = $3
		  AND (action ILIKE '%assumerole%' OR service ILIKE 'sts')`
	if err := db.QueryRowContext(ctx, q, credentialID, targetARN, scanID).Scan(&t); err != nil {
		return sql.NullTime{}, fmt.Errorf("get last assumed at: %w", err)
	}
	return t, nil
}

// ── activity tab ───────────────────────────────────────────────────────

type CredVolumePointRow struct {
	Date  time.Time
	Count int
}

func (r *CredentialDetailRepository) GetVolumeChart(ctx context.Context, db *sql.DB, credentialID, scanID string, start, end time.Time) ([]CredVolumePointRow, error) {
	table := database.Table(r.schema, identityUsageTable)
	q := `
		SELECT DATE(COALESCE(last_seen, first_seen)) AS d, COALESCE(SUM(event_count),0)::int
		FROM ` + table + `
		WHERE credential_id = $1::uuid AND scan_id = $2
		  AND COALESCE(last_seen, first_seen) BETWEEN $3 AND $4
		GROUP BY d
		ORDER BY d`
	rows, err := db.QueryContext(ctx, q, credentialID, scanID, start, end)
	if err != nil {
		return nil, fmt.Errorf("query volume chart: %w", err)
	}
	defer rows.Close()

	var out []CredVolumePointRow
	for rows.Next() {
		var v CredVolumePointRow
		if err := rows.Scan(&v.Date, &v.Count); err != nil {
			return nil, fmt.Errorf("scan volume point: %w", err)
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

func (r *CredentialDetailRepository) CountRecentEvents(ctx context.Context, db *sql.DB, credentialID, scanID string, start, end time.Time) (int, error) {
	table := database.Table(r.schema, identityUsageTable)
	var total int
	q := `
		SELECT COUNT(*) FROM ` + table + `
		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) BETWEEN $3 AND $4`
	if err := db.QueryRowContext(ctx, q, credentialID, scanID, start, end).Scan(&total); err != nil {
		return 0, fmt.Errorf("count identity_usage: %w", err)
	}
	return total, nil
}

type CredRecentEventRow struct {
	EventTime   sql.NullTime
	EventName   string
	Service     string
	ResourceARN sql.NullString
	EventCount  int
}

// GetRecentEvents returns identity_usage rows (newest first, capped). This
// table is pre-aggregated (counts per window), not a raw event log, so
// source_ip/region/user_agent/error_code cannot be populated.
func (r *CredentialDetailRepository) GetRecentEvents(ctx context.Context, db *sql.DB, credentialID, scanID string, start, end time.Time, limit int) ([]CredRecentEventRow, error) {
	table := database.Table(r.schema, identityUsageTable)
	q := `
		SELECT last_seen, COALESCE(event_name,''), COALESCE(service,''), resource_arn, COALESCE(event_count,0)
		FROM ` + table + `
		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) BETWEEN $3 AND $4
		ORDER BY last_seen DESC NULLS LAST
		LIMIT $5`
	rows, err := db.QueryContext(ctx, q, credentialID, scanID, start, end, limit)
	if err != nil {
		return nil, fmt.Errorf("query recent events: %w", err)
	}
	defer rows.Close()

	var out []CredRecentEventRow
	for rows.Next() {
		var e CredRecentEventRow
		if err := rows.Scan(&e.EventTime, &e.EventName, &e.Service, &e.ResourceARN, &e.EventCount); err != nil {
			return nil, fmt.Errorf("scan recent event: %w", err)
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

type CredServiceCountRow struct {
	Service string
	Count   int
}

func (r *CredentialDetailRepository) GetTopServices(ctx context.Context, db *sql.DB, credentialID, scanID string, start, end time.Time) ([]CredServiceCountRow, error) {
	table := database.Table(r.schema, identityUsageTable)
	q := `
		SELECT COALESCE(service,'unknown'), COALESCE(SUM(event_count),0)::int
		FROM ` + table + `
		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) BETWEEN $3 AND $4
		GROUP BY service
		ORDER BY SUM(event_count) DESC`
	rows, err := db.QueryContext(ctx, q, credentialID, scanID, start, end)
	if err != nil {
		return nil, fmt.Errorf("query top services: %w", err)
	}
	defer rows.Close()

	var out []CredServiceCountRow
	for rows.Next() {
		var s CredServiceCountRow
		if err := rows.Scan(&s.Service, &s.Count); err != nil {
			return nil, fmt.Errorf("scan top service: %w", err)
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

func (r *CredentialDetailRepository) CountDistinctActiveDays(ctx context.Context, db *sql.DB, credentialID, scanID string, start, end time.Time) (int, error) {
	table := database.Table(r.schema, identityUsageTable)
	var n int
	q := `
		SELECT COUNT(DISTINCT DATE(COALESCE(last_seen, first_seen)))
		FROM ` + table + `
		WHERE credential_id = $1::uuid AND scan_id = $2 AND COALESCE(last_seen, first_seen) BETWEEN $3 AND $4`
	if err := db.QueryRowContext(ctx, q, credentialID, scanID, start, end).Scan(&n); err != nil {
		return 0, fmt.Errorf("count distinct active days: %w", err)
	}
	return n, nil
}

// ── relationships tab ──────────────────────────────────────────────────

type CredGraphEdgeRow struct {
	Source    string
	Target    string
	EdgeType  sql.NullString
	CreatedAt sql.NullTime
}

func (r *CredentialDetailRepository) GetEdgesTouching(ctx context.Context, db *sql.DB, scanID string, arns []string, edgeTypes []string) ([]CredGraphEdgeRow, error) {
	if len(arns) == 0 {
		return nil, nil
	}
	table := database.Table(r.schema, trustEdgesTable)
	args := []interface{}{scanID, pq.Array(arns)}
	typeFilter := ""
	if len(edgeTypes) > 0 {
		args = append(args, pq.Array(edgeTypes))
		typeFilter = "AND edge_type = ANY($3)"
	}
	q := `
		SELECT source_arn, target_arn, edge_type, created_at
		FROM ` + table + `
		WHERE scan_id = $1 AND (source_arn = ANY($2) OR target_arn = ANY($2)) ` + typeFilter

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("query trust_edges: %w", err)
	}
	defer rows.Close()

	var out []CredGraphEdgeRow
	for rows.Next() {
		var e CredGraphEdgeRow
		if err := rows.Scan(&e.Source, &e.Target, &e.EdgeType, &e.CreatedAt); err != nil {
			return nil, fmt.Errorf("scan trust_edge: %w", err)
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

type CredNodeInfoRow struct {
	Name           sql.NullString
	NodeType       string // credential | identity | resource | unknown
	Subtype        sql.NullString
	LastActivityAt sql.NullTime
}

// ResolveNodes classifies each ARN as credential, identity, or resource
// (checked in that order), scoped to the same scan. Anything unmatched
// falls back to type "unknown".
func (r *CredentialDetailRepository) ResolveNodes(ctx context.Context, db *sql.DB, scanID string, arns []string) (map[string]CredNodeInfoRow, error) {
	result := make(map[string]CredNodeInfoRow, len(arns))
	if len(arns) == 0 {
		return result, nil
	}
	arnArray := pq.Array(arns)

	credTable := database.Table(r.schema, credentialsTable)
	credQ := `SELECT arn, name, credential_type FROM ` + credTable + ` WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL`
	if rows, err := db.QueryContext(ctx, credQ, scanID, arnArray); err == nil {
		for rows.Next() {
			var arn string
			var name, subtype sql.NullString
			if rows.Scan(&arn, &name, &subtype) == nil {
				result[arn] = CredNodeInfoRow{Name: name, NodeType: "credential", Subtype: subtype}
			}
		}
		rows.Close()
	}

	idTable := database.Table(r.schema, identitiesTable)
	idQ := `SELECT arn, name, identity_type, last_activity_at FROM ` + idTable + ` WHERE scan_id=$1 AND arn = ANY($2) AND deleted_at IS NULL`
	if rows, err := db.QueryContext(ctx, idQ, scanID, arnArray); err == nil {
		for rows.Next() {
			var arn string
			var name, subtype sql.NullString
			var lastActivity sql.NullTime
			if rows.Scan(&arn, &name, &subtype, &lastActivity) == nil {
				if _, exists := result[arn]; !exists {
					result[arn] = CredNodeInfoRow{Name: name, NodeType: "identity", Subtype: subtype, LastActivityAt: lastActivity}
				}
			}
		}
		rows.Close()
	}

	resTable := database.Table(r.schema, resourcesTable)
	resQ := `SELECT arn, name, resource_type FROM ` + resTable + ` WHERE scan_id=$1 AND arn = ANY($2)`
	if rows, err := db.QueryContext(ctx, resQ, scanID, arnArray); err == nil {
		for rows.Next() {
			var arn string
			var name, subtype sql.NullString
			if rows.Scan(&arn, &name, &subtype) == nil {
				if _, exists := result[arn]; !exists {
					result[arn] = CredNodeInfoRow{Name: name, NodeType: "resource", Subtype: subtype}
				}
			}
		}
		rows.Close()
	}

	for _, arn := range arns {
		if _, ok := result[arn]; !ok {
			result[arn] = CredNodeInfoRow{NodeType: "unknown"}
		}
	}
	return result, nil
}