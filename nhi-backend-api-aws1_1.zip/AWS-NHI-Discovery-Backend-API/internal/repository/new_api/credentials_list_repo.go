package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/database"
)

// NOTE: credentialsTable and identityCredentialsTable are assumed to already
// exist as package-level consts elsewhere in internal/repository/new_api.
// Do NOT redeclare them here. If they don't exist yet, uncomment:
// const (
// 	credentialsTable         = "credentials"
// 	identityCredentialsTable = "identity_credentials"
// )

// CredentialRow is the DB-shaped row for the credentials list endpoint.
// All "derived" fields are computed in SQL from real columns — see the
// inner SELECT in innerSelect() for the exact formulas.
type CredentialRow struct {
	ID                    string
	Name                  string
	ARN                   string
	CredentialType        string
	AccountID             string
	Region                string
	Status                string
	OwnerPrincipalARN     sql.NullString
	BoundIdentitiesCount  int
	IsOrphaned            bool
	LastUsedAt            sql.NullTime
	LastRotatedAt         sql.NullTime
	RotationEnabled       bool
	RotationOverdue       bool
	AgeDays               int
	IdleDays              sql.NullInt64
	ExpiresAt             sql.NullTime
	DaysUntilExpiry       sql.NullInt64
	HasExternalTrust      bool
	PermissionBoundaryARN sql.NullString
}

// CredentialsListSortColumnAllowed whitelists sortable columns (outer alias x.*).
var CredentialsListSortColumnAllowed = map[string]string{
	"last_used_at":           "x.last_used_at",
	"last_rotated_at":        "x.last_rotated_at",
	"name":                   "x.name",
	"age_days":               "x.age_days",
	"idle_days":              "x.idle_days",
	"days_until_expiry":      "x.days_until_expiry",
	"bound_identities_count": "x.bound_identities_count",
	"status":                 "x.status",
	"credential_type":        "x.credential_type",
}

// CredentialsListFilters holds the already-validated filter values.
type CredentialsListFilters struct {
	ScanID             string // scopes to one scan — set by the service to the latest COMPLETED scan
	Search             string
	CredentialTypes    []string
	Statuses           []string
	OwnerPrincipalARN  string
	RotationEnabled    *bool
	RotationOverdue    *bool
	IsOrphaned         *bool
	HasExternalTrust   *bool
	MinIdleDays        *int
	MaxDaysUntilExpiry *int
}

type CredentialsListRepository struct {
	schema string
}

func NewCredentialsListRepository(dataSchema string) *CredentialsListRepository {
	return &CredentialsListRepository{schema: dataSchema}
}

// innerSelect computes all derived columns once, from real columns only.
//
// Derivation notes (flagged as approximate — correct to your real business
// rules if these don't match):
//   - age_days: NOW() - COALESCE(created_at_aws, first_seen_at)
//   - idle_days: NULL if never used, else NOW() - last_used_at
//   - days_until_expiry: NULL if no expiry, else expires_at - NOW()
//   - rotation_overdue: rotation_enabled=true AND rotation_interval_days set,
//     AND either never rotated, or last_rotated_at older than the interval
//   - has_external_trust: crude heuristic — trust_policy mentions an AWS
//     principal whose text does not contain this credential's own account_id.
//     Not full JSON principal parsing (see identity_detail's
//     buildTrustPrincipals/isCrossAccountTrust for the precise version).
//   - is_orphaned: bound_identities_count = 0 (from identity_credentials)
//   - rotation_enabled is wrapped in COALESCE(..., false) because the real
//     column is nullable and a raw NULL cannot scan into a Go bool.
//   - c.scan_id is now exposed so the outer query can scope to exactly one
//     scan (the latest COMPLETED one, resolved by the service) — without
//     this, credentials from every historical scan run accumulate.
func (r *CredentialsListRepository) innerSelect() string {
	credTable := database.Table(r.schema, credentialsTable)
	icTable := database.Table(r.schema, identityCredentialsTable)

	return `
		SELECT
			c.id,
			c.scan_id,
			c.name,
			c.arn,
			c.credential_type,
			c.account_id,
			c.region,
			c.status,
			c.owner_principal_arn,
			c.last_used_at,
			c.last_rotated_at,
			COALESCE(c.rotation_enabled, false) AS rotation_enabled,
			c.expires_at,
			c.permission_boundary_arn,
			COALESCE(bic.cnt, 0) AS bound_identities_count,
			CASE WHEN COALESCE(bic.cnt, 0) = 0 THEN true ELSE false END AS is_orphaned,
			EXTRACT(DAY FROM NOW() - COALESCE(c.created_at_aws, c.first_seen_at))::int AS age_days,
			CASE WHEN c.last_used_at IS NULL THEN NULL
			     ELSE EXTRACT(DAY FROM NOW() - c.last_used_at)::int END AS idle_days,
			CASE WHEN c.expires_at IS NULL THEN NULL
			     ELSE EXTRACT(DAY FROM c.expires_at - NOW())::int END AS days_until_expiry,
			CASE
				WHEN COALESCE(c.rotation_enabled, false) = true AND c.rotation_interval_days IS NOT NULL AND c.last_rotated_at IS NULL THEN true
				WHEN COALESCE(c.rotation_enabled, false) = true AND c.rotation_interval_days IS NOT NULL AND c.last_rotated_at IS NOT NULL
				     AND (NOW() - c.last_rotated_at) > (c.rotation_interval_days || ' days')::interval THEN true
				ELSE false
			END AS rotation_overdue,
			CASE
				WHEN c.trust_policy IS NULL THEN false
				WHEN c.trust_policy::text ILIKE '%"AWS"%'
				     AND c.trust_policy::text NOT ILIKE '%' || c.account_id || '%' THEN true
				ELSE false
			END AS has_external_trust
		FROM ` + credTable + ` c
		LEFT JOIN LATERAL (
			SELECT COUNT(*) AS cnt
			FROM ` + icTable + ` ic
			WHERE ic.credential_id = c.id
		) bic ON true`
}

// buildWhere builds the outer WHERE clause against the inner query's aliases
// (x.*), using the next(v) positional-placeholder closure pattern.
func (r *CredentialsListRepository) buildWhere(f CredentialsListFilters) (string, []interface{}) {
	var conds []string
	var args []interface{}

	next := func(v interface{}) string {
		args = append(args, v)
		return fmt.Sprintf("$%d", len(args))
	}

	// Scope to one scan — mandatory, resolved by the service as the latest
	// COMPLETED scan (same pattern as other list endpoints). Without this,
	// rows from every historical scan accumulate and massively over-count.
	if f.ScanID != "" {
		conds = append(conds, fmt.Sprintf("x.scan_id = %s", next(f.ScanID)))
	}

	if s := strings.TrimSpace(f.Search); s != "" {
		p := next("%" + s + "%")
		conds = append(conds, fmt.Sprintf("(x.name ILIKE %s OR x.arn ILIKE %s)", p, p))
	}
	if len(f.CredentialTypes) > 0 {
		var ph []string
		for _, v := range f.CredentialTypes {
			ph = append(ph, next(v))
		}
		conds = append(conds, fmt.Sprintf("x.credential_type IN (%s)", strings.Join(ph, ",")))
	}
	if len(f.Statuses) > 0 {
		var ph []string
		for _, v := range f.Statuses {
			ph = append(ph, next(v))
		}
		conds = append(conds, fmt.Sprintf("x.status IN (%s)", strings.Join(ph, ",")))
	}
	if s := strings.TrimSpace(f.OwnerPrincipalARN); s != "" {
		conds = append(conds, fmt.Sprintf("x.owner_principal_arn = %s", next(s)))
	}
	if f.RotationEnabled != nil {
		conds = append(conds, fmt.Sprintf("x.rotation_enabled = %s", next(*f.RotationEnabled)))
	}
	if f.RotationOverdue != nil {
		conds = append(conds, fmt.Sprintf("x.rotation_overdue = %s", next(*f.RotationOverdue)))
	}
	if f.IsOrphaned != nil {
		conds = append(conds, fmt.Sprintf("x.is_orphaned = %s", next(*f.IsOrphaned)))
	}
	if f.HasExternalTrust != nil {
		conds = append(conds, fmt.Sprintf("x.has_external_trust = %s", next(*f.HasExternalTrust)))
	}
	if f.MinIdleDays != nil {
		conds = append(conds, fmt.Sprintf("x.idle_days >= %s", next(*f.MinIdleDays)))
	}
	if f.MaxDaysUntilExpiry != nil {
		conds = append(conds, fmt.Sprintf("x.days_until_expiry IS NOT NULL AND x.days_until_expiry <= %s", next(*f.MaxDaysUntilExpiry)))
	}

	if len(conds) == 0 {
		return "", args
	}
	return "WHERE " + strings.Join(conds, " AND "), args
}

// Count returns the total number of credentials matching the filters.
func (r *CredentialsListRepository) Count(ctx context.Context, db *sql.DB, f CredentialsListFilters) (int, error) {
	where, args := r.buildWhere(f)
	q := `SELECT COUNT(*) FROM (` + r.innerSelect() + `) x ` + where

	var total int
	if err := db.QueryRowContext(ctx, q, args...).Scan(&total); err != nil {
		return 0, fmt.Errorf("count credentials: %w", err)
	}
	return total, nil
}

// List returns one page of credentials matching the filters, sorted and limited.
func (r *CredentialsListRepository) List(
	ctx context.Context, db *sql.DB, f CredentialsListFilters,
	sortCol, sortDir string, limit, offset int,
) ([]CredentialRow, error) {
	where, args := r.buildWhere(f)

	limitPH := fmt.Sprintf("$%d", len(args)+1)
	offsetPH := fmt.Sprintf("$%d", len(args)+2)
	args = append(args, limit, offset)

	q := `
		SELECT
			x.id, x.name, x.arn, x.credential_type, x.account_id, x.region, x.status,
			x.owner_principal_arn, x.bound_identities_count, x.is_orphaned,
			x.last_used_at, x.last_rotated_at, x.rotation_enabled, x.rotation_overdue,
			x.age_days, x.idle_days, x.expires_at, x.days_until_expiry,
			x.has_external_trust, x.permission_boundary_arn
		FROM (` + r.innerSelect() + `) x
		` + where + `
		ORDER BY ` + sortCol + ` ` + sortDir + `, x.id ASC
		LIMIT ` + limitPH + ` OFFSET ` + offsetPH

	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("list credentials: %w", err)
	}
	defer rows.Close()

	var out []CredentialRow
	for rows.Next() {
		var c CredentialRow
		if err := rows.Scan(
			&c.ID, &c.Name, &c.ARN, &c.CredentialType, &c.AccountID, &c.Region, &c.Status,
			&c.OwnerPrincipalARN, &c.BoundIdentitiesCount, &c.IsOrphaned,
			&c.LastUsedAt, &c.LastRotatedAt, &c.RotationEnabled, &c.RotationOverdue,
			&c.AgeDays, &c.IdleDays, &c.ExpiresAt, &c.DaysUntilExpiry,
			&c.HasExternalTrust, &c.PermissionBoundaryARN,
		); err != nil {
			return nil, fmt.Errorf("scan credential row: %w", err)
		}
		out = append(out, c)
	}
	return out, rows.Err()
}