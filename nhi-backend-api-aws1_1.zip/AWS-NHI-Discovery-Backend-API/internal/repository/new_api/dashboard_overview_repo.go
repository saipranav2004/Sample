// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// 	"time"

// 	"github.com/lib/pq"

// 	"nhi-backend-api/internal/database"
// )

// const (
// 	identitiesTable          = "identities"
// 	credentialsTable         = "credentials"
// 	identityCredentialsTable = "identity_credentials"
// 	effectivePermsTable      = "effective_permissions"
// 	permissionUsageTable     = "permission_usage"

// 	staleAfterDays     = 90 // no activity / no usage for this long = stale
// 	expiringWithinDays = 30 // "expiring soon" window
// 	expiringListLimit  = 10
// 	topOwnersLimit     = 5
// 	growthMonths       = 12
// 	scanHistoryLimit   = 10
// )

// // OverviewFilter is the scope of every dashboard query.
// // Empty Accounts / Regions mean "no filter".
// type OverviewFilter struct {
// 	ScanID   string
// 	Accounts []string
// 	Regions  []string
// }

// // scopeArgs are bound to $1 (scan), $2 (accounts) and $3 (regions).
// func (f OverviewFilter) scopeArgs() []interface{} {
// 	acc, reg := f.Accounts, f.Regions
// 	if acc == nil {
// 		acc = []string{}
// 	}
// 	if reg == nil {
// 		reg = []string{}
// 	}
// 	return []interface{}{f.ScanID, pq.Array(acc), pq.Array(reg)}
// }

// // scope is the WHERE fragment shared by identities and credentials.
// // func scope(alias string) string {
// // 	return fmt.Sprintf(`%[1]s.scan_id = $1::text
// // 		AND %[1]s.deleted_at IS NULL
// // 		AND (cardinality($2::text[]) = 0 OR %[1]s.account_id = ANY($2::text[]))
// // 		AND (cardinality($3::text[]) = 0 OR %[1]s.region = ANY($3::text[]))`, alias)
// // }



// // scope is the WHERE fragment shared by identities and credentials.
// // Region filter: global resources (IAM etc. — region is 'global', empty or NULL)
// // are not tied to any region, so they must always pass the region filter.
// func scope(alias string) string {
// 	return fmt.Sprintf(`%[1]s.scan_id = $1::text
// 		AND %[1]s.deleted_at IS NULL
// 		AND (cardinality($2::text[]) = 0 OR %[1]s.account_id = ANY($2::text[]))
// 		AND (
// 			cardinality($3::text[]) = 0
// 			OR %[1]s.region = ANY($3::text[])
// 			OR %[1]s.region IS NULL
// 			OR BTRIM(%[1]s.region) = ''
// 			OR LOWER(BTRIM(%[1]s.region)) = 'global'
// 		)`, alias)
// }

// type DashboardOverviewRepository struct {
// 	schema string
// }

// func NewDashboardOverviewRepository(dataSchema string) *DashboardOverviewRepository {
// 	return &DashboardOverviewRepository{schema: dataSchema}
// }

// func (r *DashboardOverviewRepository) t(name string) string { return database.Table(r.schema, name) }

// // ── KPIs ────────────────────────────────────────────────────────────────────

// type IdentityKPIs struct {
// 	Total, Stale, PubliclyAccessible, Shadow, Accounts int
// }

// func (r *DashboardOverviewRepository) IdentityKPIs(ctx context.Context, db *sql.DB, f OverviewFilter) (IdentityKPIs, error) {
// 	q := `
// 		SELECT
// 			COUNT(*),
// 			COUNT(*) FILTER (WHERE COALESCE(i.last_activity_at, i.first_seen_at) < NOW() - make_interval(days => $4::int)),
// 			COUNT(*) FILTER (WHERE i.is_publicly_accessible IS TRUE),
// 			COUNT(*) FILTER (WHERE i.owner IS NULL OR BTRIM(i.owner) = ''),
// 			COUNT(DISTINCT i.account_id)
// 		FROM ` + r.t(identitiesTable) + ` i
// 		WHERE ` + scope("i")

// 	var k IdentityKPIs
// 	err := db.QueryRowContext(ctx, q, append(f.scopeArgs(), staleAfterDays)...).
// 		Scan(&k.Total, &k.Stale, &k.PubliclyAccessible, &k.Shadow, &k.Accounts)
// 	if err != nil {
// 		return k, fmt.Errorf("identity kpis: %w", err)
// 	}
// 	return k, nil
// }

// type CredentialKPIs struct {
// 	Total, Orphaned, Stale int
// }

// // Orphaned = bound to no identity. Stale = no permission used in the last 90 days.
// func (r *DashboardOverviewRepository) CredentialKPIs(ctx context.Context, db *sql.DB, f OverviewFilter) (CredentialKPIs, error) {
// 	q := `
// 		SELECT COUNT(*), COUNT(*) FILTER (WHERE orphaned), COUNT(*) FILTER (WHERE stale)
// 		FROM (
// 			SELECT
// 				NOT EXISTS (
// 					SELECT 1 FROM ` + r.t(identityCredentialsTable) + ` ic
// 					WHERE ic.credential_id = c.id AND ic.scan_id = c.scan_id
// 				) AS orphaned,
// 				NOT EXISTS (
// 					SELECT 1 FROM ` + r.t(permissionUsageTable) + ` pu
// 					WHERE pu.credential_id = c.id AND pu.scan_id = c.scan_id
// 					  AND COALESCE(pu.usage_count_90d, 0) > 0
// 				) AS stale
// 			FROM ` + r.t(credentialsTable) + ` c
// 			WHERE ` + scope("c") + `
// 		) t`

// 	var k CredentialKPIs
// 	if err := db.QueryRowContext(ctx, q, f.scopeArgs()...).Scan(&k.Total, &k.Orphaned, &k.Stale); err != nil {
// 		return k, fmt.Errorf("credential kpis: %w", err)
// 	}
// 	return k, nil
// }

// // PermissionCounts returns (granted, used): granted = SUM(effective_permissions.granted_count),
// // used = distinct (credential, service, action) with usage_count_90d > 0.
// func (r *DashboardOverviewRepository) PermissionCounts(ctx context.Context, db *sql.DB, f OverviewFilter) (granted, used int64, err error) {
// 	q := `
// 		SELECT
// 			COALESCE((
// 				SELECT SUM(ep.granted_count)
// 				FROM ` + r.t(effectivePermsTable) + ` ep
// 				JOIN ` + r.t(credentialsTable) + ` c ON c.id = ep.credential_id AND c.scan_id = ep.scan_id
// 				WHERE ` + scope("c") + `
// 			), 0),
// 			COALESCE((
// 				SELECT COUNT(*) FROM (
// 					SELECT DISTINCT pu.credential_id, pu.service, pu.action
// 					FROM ` + r.t(permissionUsageTable) + ` pu
// 					JOIN ` + r.t(credentialsTable) + ` c ON c.id = pu.credential_id AND c.scan_id = pu.scan_id
// 					WHERE ` + scope("c") + ` AND COALESCE(pu.usage_count_90d, 0) > 0
// 				) x
// 			), 0)`
// 	if err = db.QueryRowContext(ctx, q, f.scopeArgs()...).Scan(&granted, &used); err != nil {
// 		return 0, 0, fmt.Errorf("permission counts: %w", err)
// 	}
// 	return granted, used, nil
// }

// // ── Charts: group-by counts ────────────────────────────────────────────────

// type LabelCount struct {
// 	Label string
// 	Count int
// }

// // groupCount counts rows per column. column MUST be a constant from this package
// // (never user input) because it is interpolated into the SQL.
// func (r *DashboardOverviewRepository) groupCount(ctx context.Context, db *sql.DB, table, alias, column string, f OverviewFilter, limit int) ([]LabelCount, error) {
// 	q := fmt.Sprintf(`
// 		SELECT COALESCE(NULLIF(BTRIM(%[1]s.%[2]s::text), ''), 'unknown') AS k, COUNT(*)
// 		FROM %[3]s %[1]s
// 		WHERE %[4]s
// 		GROUP BY k
// 		ORDER BY COUNT(*) DESC, k`, alias, column, r.t(table), scope(alias))
// 	args := f.scopeArgs()
// 	if limit > 0 {
// 		q += " LIMIT $4"
// 		args = append(args, limit)
// 	}
// 	return scanLabelCounts(ctx, db, q, args, table+"."+column)
// }

// func scanLabelCounts(ctx context.Context, db *sql.DB, q string, args []interface{}, what string) ([]LabelCount, error) {
// 	rows, err := db.QueryContext(ctx, q, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("group %s: %w", what, err)
// 	}
// 	defer rows.Close()
// 	out := []LabelCount{}
// 	for rows.Next() {
// 		var lc LabelCount
// 		if err := rows.Scan(&lc.Label, &lc.Count); err != nil {
// 			return nil, fmt.Errorf("scan group %s: %w", what, err)
// 		}
// 		out = append(out, lc)
// 	}
// 	return out, rows.Err()
// }

// func (r *DashboardOverviewRepository) IdentitiesByType(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "identity_type", f, 0)
// }
// func (r *DashboardOverviewRepository) IdentitiesByFunctionalClass(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "functional_class", f, 0)
// }
// func (r *DashboardOverviewRepository) IdentitiesByAccount(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "account_id", f, 0)
// }
// func (r *DashboardOverviewRepository) IdentitiesByRegion(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "region", f, 0)
// }
// func (r *DashboardOverviewRepository) IdentitiesByEnvironment(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "environment", f, 0)
// }
// func (r *DashboardOverviewRepository) IdentitiesByStatus(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, identitiesTable, "i", "status", f, 0)
// }
// func (r *DashboardOverviewRepository) CredentialTypes(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	return r.groupCount(ctx, db, credentialsTable, "c", "credential_type", f, 0)
// }

// // TopOwners ignores identities without an owner (those are the "shadow" KPI).
// func (r *DashboardOverviewRepository) TopOwners(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
// 	q := `
// 		SELECT BTRIM(i.owner) AS k, COUNT(*)
// 		FROM ` + r.t(identitiesTable) + ` i
// 		WHERE ` + scope("i") + ` AND i.owner IS NOT NULL AND BTRIM(i.owner) <> ''
// 		GROUP BY k
// 		ORDER BY COUNT(*) DESC, k
// 		LIMIT $4`
// 	return scanLabelCounts(ctx, db, q, append(f.scopeArgs(), topOwnersLimit), "top owners")
// }

// // ── Charts: growth (cumulative, per month, gap-free, last 12 months) ───────

// type DatePoint struct {
// 	Date  time.Time
// 	Count int
// }

// func (r *DashboardOverviewRepository) Growth(ctx context.Context, db *sql.DB, table, alias string, f OverviewFilter) ([]DatePoint, error) {
// 	q := fmt.Sprintf(`
// 		WITH per AS (
// 			SELECT date_trunc('month', %[1]s.first_seen_at)::date AS d, COUNT(*) AS c
// 			FROM %[2]s %[1]s
// 			WHERE %[3]s AND %[1]s.first_seen_at IS NOT NULL
// 			GROUP BY 1
// 		),
// 		series AS (
// 			SELECT gs::date AS d
// 			FROM generate_series((SELECT MIN(d) FROM per), date_trunc('month', NOW())::date, interval '1 month') gs
// 		)
// 		SELECT s.d, (SUM(COALESCE(p.c, 0)) OVER (ORDER BY s.d))::int
// 		FROM series s
// 		LEFT JOIN per p ON p.d = s.d
// 		ORDER BY s.d`, alias, r.t(table), scope(alias))

// 	rows, err := db.QueryContext(ctx, q, f.scopeArgs()...)
// 	if err != nil {
// 		return nil, fmt.Errorf("growth %s: %w", table, err)
// 	}
// 	defer rows.Close()

// 	all := []DatePoint{}
// 	for rows.Next() {
// 		var p DatePoint
// 		if err := rows.Scan(&p.Date, &p.Count); err != nil {
// 			return nil, fmt.Errorf("scan growth %s: %w", table, err)
// 		}
// 		all = append(all, p)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, err
// 	}
// 	if len(all) > growthMonths {
// 		all = all[len(all)-growthMonths:]
// 	}
// 	return all, nil
// }

// // ── Charts: expiring credentials ───────────────────────────────────────────

// type ExpiringRow struct {
// 	Name          string
// 	ExpiresAt     time.Time
// 	DaysRemaining int
// }

// func (r *DashboardOverviewRepository) ExpiringSoon(ctx context.Context, db *sql.DB, f OverviewFilter) ([]ExpiringRow, error) {
// 	q := `
// 		SELECT COALESCE(NULLIF(BTRIM(c.name), ''), NULLIF(BTRIM(c.arn), ''), c.id::text),
// 		       c.expires_at,
// 		       CEIL(EXTRACT(EPOCH FROM (c.expires_at - NOW())) / 86400)::int
// 		FROM ` + r.t(credentialsTable) + ` c
// 		WHERE ` + scope("c") + `
// 		  AND c.expires_at IS NOT NULL
// 		  AND c.expires_at >= NOW()
// 		  AND c.expires_at <= NOW() + make_interval(days => $4::int)
// 		ORDER BY c.expires_at ASC, c.id
// 		LIMIT $5`

// 	rows, err := db.QueryContext(ctx, q, append(f.scopeArgs(), expiringWithinDays, expiringListLimit)...)
// 	if err != nil {
// 		return nil, fmt.Errorf("expiring credentials: %w", err)
// 	}
// 	defer rows.Close()

// 	out := []ExpiringRow{}
// 	for rows.Next() {
// 		var e ExpiringRow
// 		if err := rows.Scan(&e.Name, &e.ExpiresAt, &e.DaysRemaining); err != nil {
// 			return nil, fmt.Errorf("scan expiring credential: %w", err)
// 		}
// 		out = append(out, e)
// 	}
// 	return out, rows.Err()
// }

// // ── Charts: scan history (not filtered by scan/account — it IS the scan list) ─

// type ScanHistoryRow struct {
// 	ScanID           string
// 	ScanEnd          *time.Time
// 	Status           string
// 	TotalIdentities  int
// 	TotalCredentials int
// }

// func (r *DashboardOverviewRepository) ScanHistory(ctx context.Context, db *sql.DB) ([]ScanHistoryRow, error) {
// 	q := `
// 		SELECT scan_id, scan_end, COALESCE(status, ''),
// 		       COALESCE(total_identities, 0), COALESCE(total_credentials, 0)
// 		FROM ` + r.t(scansTable) + `
// 		ORDER BY scan_end DESC NULLS LAST, id DESC
// 		LIMIT $1`

// 	rows, err := db.QueryContext(ctx, q, scanHistoryLimit)
// 	if err != nil {
// 		return nil, fmt.Errorf("scan history: %w", err)
// 	}
// 	defer rows.Close()

// 	out := []ScanHistoryRow{}
// 	for rows.Next() {
// 		var (
// 			s   ScanHistoryRow
// 			end sql.NullTime
// 		)
// 		if err := rows.Scan(&s.ScanID, &end, &s.Status, &s.TotalIdentities, &s.TotalCredentials); err != nil {
// 			return nil, fmt.Errorf("scan scan-history row: %w", err)
// 		}
// 		if end.Valid {
// 			t := end.Time.UTC()
// 			s.ScanEnd = &t
// 		}
// 		out = append(out, s)
// 	}
// 	return out, rows.Err()
// }























package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/database"
)

const (
	identitiesTable          = "identities"
	credentialsTable         = "credentials"
	identityCredentialsTable = "identity_credentials"
	effectivePermsTable      = "effective_permissions"
	permissionUsageTable     = "permission_usage"

	staleAfterDays     = 90 // no activity / no usage for this long = stale
	expiringWithinDays = 30 // "expiring soon" window
	expiringListLimit  = 10
	topOwnersLimit     = 5
	growthMonths       = 12
	scanHistoryLimit   = 10
)

// OverviewFilter is the scope of every dashboard query.
// Empty Accounts / Regions mean "no filter".
type OverviewFilter struct {
	ScanID   string
	Accounts []string
	Regions  []string
}

// scopeArgs are bound to $1 (scan), $2 (accounts) and $3 (regions).
func (f OverviewFilter) scopeArgs() []interface{} {
	acc, reg := f.Accounts, f.Regions
	if acc == nil {
		acc = []string{}
	}
	if reg == nil {
		reg = []string{}
	}
	return []interface{}{f.ScanID, pq.Array(acc), pq.Array(reg)}
}

// scope is the WHERE fragment shared by identities and credentials.
// Region filter: global resources (IAM etc. — region is 'global', empty or NULL)
// are not tied to any region, so they must always pass the region filter.
func scope(alias string) string {
	return fmt.Sprintf(`%[1]s.scan_id = $1::text
		AND %[1]s.deleted_at IS NULL
		AND (cardinality($2::text[]) = 0 OR %[1]s.account_id = ANY($2::text[]))
		AND (
			cardinality($3::text[]) = 0
			OR %[1]s.region = ANY($3::text[])
			OR %[1]s.region IS NULL
			OR BTRIM(%[1]s.region) = ''
			OR LOWER(BTRIM(%[1]s.region)) = 'global'
		)`, alias)
}

type DashboardOverviewRepository struct {
	schema string
}

func NewDashboardOverviewRepository(dataSchema string) *DashboardOverviewRepository {
	return &DashboardOverviewRepository{schema: dataSchema}
}

func (r *DashboardOverviewRepository) t(name string) string { return database.Table(r.schema, name) }

// ── KPIs ────────────────────────────────────────────────────────────────────

type IdentityKPIs struct {
	Total, Stale, PubliclyAccessible, Shadow, Accounts int
}

func (r *DashboardOverviewRepository) IdentityKPIs(ctx context.Context, db *sql.DB, f OverviewFilter) (IdentityKPIs, error) {
	q := `
		SELECT
			COUNT(*),
			COUNT(*) FILTER (WHERE COALESCE(i.last_activity_at, i.first_seen_at) < NOW() - make_interval(days => $4::int)),
			COUNT(*) FILTER (WHERE i.is_publicly_accessible IS TRUE),
			COUNT(*) FILTER (WHERE i.owner IS NULL OR BTRIM(i.owner) = ''),
			COUNT(DISTINCT i.account_id)
		FROM ` + r.t(identitiesTable) + ` i
		WHERE ` + scope("i")

	var k IdentityKPIs
	err := db.QueryRowContext(ctx, q, append(f.scopeArgs(), staleAfterDays)...).
		Scan(&k.Total, &k.Stale, &k.PubliclyAccessible, &k.Shadow, &k.Accounts)
	if err != nil {
		return k, fmt.Errorf("identity kpis: %w", err)
	}
	return k, nil
}

type CredentialKPIs struct {
	Total, Orphaned, Stale int
}

// Orphaned = bound to no identity. Stale = no permission used in the last 90 days.
func (r *DashboardOverviewRepository) CredentialKPIs(ctx context.Context, db *sql.DB, f OverviewFilter) (CredentialKPIs, error) {
	q := `
		SELECT COUNT(*), COUNT(*) FILTER (WHERE orphaned), COUNT(*) FILTER (WHERE stale)
		FROM (
			SELECT
				NOT EXISTS (
					SELECT 1 FROM ` + r.t(identityCredentialsTable) + ` ic
					WHERE ic.credential_id = c.id AND ic.scan_id = c.scan_id
				) AS orphaned,
				NOT EXISTS (
					SELECT 1 FROM ` + r.t(permissionUsageTable) + ` pu
					WHERE pu.credential_id = c.id AND pu.scan_id = c.scan_id
					  AND COALESCE(pu.usage_count_90d, 0) > 0
				) AS stale
			FROM ` + r.t(credentialsTable) + ` c
			WHERE ` + scope("c") + `
		) t`

	var k CredentialKPIs
	if err := db.QueryRowContext(ctx, q, f.scopeArgs()...).Scan(&k.Total, &k.Orphaned, &k.Stale); err != nil {
		return k, fmt.Errorf("credential kpis: %w", err)
	}
	return k, nil
}

// PermissionCounts returns (granted, used): granted = SUM(effective_permissions.granted_count),
// used = distinct (credential, service, action) with usage_count_90d > 0.
func (r *DashboardOverviewRepository) PermissionCounts(ctx context.Context, db *sql.DB, f OverviewFilter) (granted, used int64, err error) {
	q := `
		SELECT
			COALESCE((
				SELECT SUM(ep.granted_count)
				FROM ` + r.t(effectivePermsTable) + ` ep
				JOIN ` + r.t(credentialsTable) + ` c ON c.id = ep.credential_id AND c.scan_id = ep.scan_id
				WHERE ` + scope("c") + `
			), 0),
			COALESCE((
				SELECT COUNT(*) FROM (
					SELECT DISTINCT pu.credential_id, pu.service, pu.action
					FROM ` + r.t(permissionUsageTable) + ` pu
					JOIN ` + r.t(credentialsTable) + ` c ON c.id = pu.credential_id AND c.scan_id = pu.scan_id
					WHERE ` + scope("c") + ` AND COALESCE(pu.usage_count_90d, 0) > 0
				) x
			), 0)`
	if err = db.QueryRowContext(ctx, q, f.scopeArgs()...).Scan(&granted, &used); err != nil {
		return 0, 0, fmt.Errorf("permission counts: %w", err)
	}
	return granted, used, nil
}

// ── Charts: group-by counts ────────────────────────────────────────────────

type LabelCount struct {
	Label string
	Count int
}

// groupCount counts rows per column. column MUST be a constant from this package
// (never user input) because it is interpolated into the SQL.
func (r *DashboardOverviewRepository) groupCount(ctx context.Context, db *sql.DB, table, alias, column string, f OverviewFilter, limit int) ([]LabelCount, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(NULLIF(BTRIM(%[1]s.%[2]s::text), ''), 'unknown') AS k, COUNT(*)
		FROM %[3]s %[1]s
		WHERE %[4]s
		GROUP BY k
		ORDER BY COUNT(*) DESC, k`, alias, column, r.t(table), scope(alias))
	args := f.scopeArgs()
	if limit > 0 {
		q += " LIMIT $4"
		args = append(args, limit)
	}
	return scanLabelCounts(ctx, db, q, args, table+"."+column)
}

func scanLabelCounts(ctx context.Context, db *sql.DB, q string, args []interface{}, what string) ([]LabelCount, error) {
	rows, err := db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("group %s: %w", what, err)
	}
	defer rows.Close()
	out := []LabelCount{}
	for rows.Next() {
		var lc LabelCount
		if err := rows.Scan(&lc.Label, &lc.Count); err != nil {
			return nil, fmt.Errorf("scan group %s: %w", what, err)
		}
		out = append(out, lc)
	}
	return out, rows.Err()
}

func (r *DashboardOverviewRepository) IdentitiesByType(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "identity_type", f, 0)
}
func (r *DashboardOverviewRepository) IdentitiesByFunctionalClass(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "functional_class", f, 0)
}
func (r *DashboardOverviewRepository) IdentitiesByAccount(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "account_id", f, 0)
}
func (r *DashboardOverviewRepository) IdentitiesByRegion(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "region", f, 0)
}
func (r *DashboardOverviewRepository) IdentitiesByEnvironment(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "environment", f, 0)
}
func (r *DashboardOverviewRepository) IdentitiesByStatus(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, identitiesTable, "i", "status", f, 0)
}
func (r *DashboardOverviewRepository) CredentialTypes(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	return r.groupCount(ctx, db, credentialsTable, "c", "credential_type", f, 0)
}

// TopOwners ignores identities without an owner (those are the "shadow" KPI).
func (r *DashboardOverviewRepository) TopOwners(ctx context.Context, db *sql.DB, f OverviewFilter) ([]LabelCount, error) {
	q := `
		SELECT BTRIM(i.owner) AS k, COUNT(*)
		FROM ` + r.t(identitiesTable) + ` i
		WHERE ` + scope("i") + ` AND i.owner IS NOT NULL AND BTRIM(i.owner) <> ''
		GROUP BY k
		ORDER BY COUNT(*) DESC, k
		LIMIT $4`
	return scanLabelCounts(ctx, db, q, append(f.scopeArgs(), topOwnersLimit), "top owners")
}

// ── Charts: growth (cumulative, per month, gap-free, last 12 months) ───────

type DatePoint struct {
	Date  time.Time
	Count int
}

func (r *DashboardOverviewRepository) Growth(ctx context.Context, db *sql.DB, table, alias string, f OverviewFilter) ([]DatePoint, error) {
	q := fmt.Sprintf(`
		WITH per AS (
			SELECT date_trunc('month', %[1]s.first_seen_at)::date AS d, COUNT(*) AS c
			FROM %[2]s %[1]s
			WHERE %[3]s AND %[1]s.first_seen_at IS NOT NULL
			GROUP BY 1
		),
		series AS (
			SELECT gs::date AS d
			FROM generate_series((SELECT MIN(d) FROM per), date_trunc('month', NOW())::date, interval '1 month') gs
		)
		SELECT s.d, (SUM(COALESCE(p.c, 0)) OVER (ORDER BY s.d))::int
		FROM series s
		LEFT JOIN per p ON p.d = s.d
		ORDER BY s.d`, alias, r.t(table), scope(alias))

	rows, err := db.QueryContext(ctx, q, f.scopeArgs()...)
	if err != nil {
		return nil, fmt.Errorf("growth %s: %w", table, err)
	}
	defer rows.Close()

	all := []DatePoint{}
	for rows.Next() {
		var p DatePoint
		if err := rows.Scan(&p.Date, &p.Count); err != nil {
			return nil, fmt.Errorf("scan growth %s: %w", table, err)
		}
		all = append(all, p)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(all) > growthMonths {
		all = all[len(all)-growthMonths:]
	}
	return all, nil
}

// ── Charts: expiring credentials ───────────────────────────────────────────

type ExpiringRow struct {
	Name          string
	ExpiresAt     time.Time
	DaysRemaining int
}

func (r *DashboardOverviewRepository) ExpiringSoon(ctx context.Context, db *sql.DB, f OverviewFilter) ([]ExpiringRow, error) {
	q := `
		SELECT COALESCE(NULLIF(BTRIM(c.name), ''), NULLIF(BTRIM(c.arn), ''), c.id::text),
		       c.expires_at,
		       CEIL(EXTRACT(EPOCH FROM (c.expires_at - NOW())) / 86400)::int
		FROM ` + r.t(credentialsTable) + ` c
		WHERE ` + scope("c") + `
		  AND c.expires_at IS NOT NULL
		  AND c.expires_at >= NOW()
		  AND c.expires_at <= NOW() + make_interval(days => $4::int)
		ORDER BY c.expires_at ASC, c.id
		LIMIT $5`

	rows, err := db.QueryContext(ctx, q, append(f.scopeArgs(), expiringWithinDays, expiringListLimit)...)
	if err != nil {
		return nil, fmt.Errorf("expiring credentials: %w", err)
	}
	defer rows.Close()

	out := []ExpiringRow{}
	for rows.Next() {
		var e ExpiringRow
		if err := rows.Scan(&e.Name, &e.ExpiresAt, &e.DaysRemaining); err != nil {
			return nil, fmt.Errorf("scan expiring credential: %w", err)
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// ── Charts: scan history (not filtered by scan/account — it IS the scan list) ─

type ScanHistoryRow struct {
	ScanID           string
	ScanEnd          *time.Time
	Status           string
	TotalIdentities  int
	TotalCredentials int
}

func (r *DashboardOverviewRepository) ScanHistory(ctx context.Context, db *sql.DB) ([]ScanHistoryRow, error) {
	q := `
		SELECT scan_id, scan_end, COALESCE(status, ''),
		       COALESCE(total_identities, 0), COALESCE(total_credentials, 0)
		FROM ` + r.t(scansTable) + `
		ORDER BY scan_end DESC NULLS LAST, id DESC
		LIMIT $1`

	rows, err := db.QueryContext(ctx, q, scanHistoryLimit)
	if err != nil {
		return nil, fmt.Errorf("scan history: %w", err)
	}
	defer rows.Close()

	out := []ScanHistoryRow{}
	for rows.Next() {
		var (
			s   ScanHistoryRow
			end sql.NullTime
		)
		if err := rows.Scan(&s.ScanID, &end, &s.Status, &s.TotalIdentities, &s.TotalCredentials); err != nil {
			return nil, fmt.Errorf("scan scan-history row: %w", err)
		}
		if end.Valid {
			t := end.Time.UTC()
			s.ScanEnd = &t
		}
		out = append(out, s)
	}
	return out, rows.Err()
}


















