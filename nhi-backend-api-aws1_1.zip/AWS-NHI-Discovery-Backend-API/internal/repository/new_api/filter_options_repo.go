package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"nhi-backend-api/internal/database"
)


type FilterOptionsRepository struct {
	schema string
}

func NewFilterOptionsRepository(dataSchema string) *FilterOptionsRepository {
	return &FilterOptionsRepository{schema: dataSchema}
}

func (r *FilterOptionsRepository) t(name string) string { return database.Table(r.schema, name) }


func filterScope(alias string) string {
	return fmt.Sprintf(`%[1]s.scan_id = $1::text AND %[1]s.deleted_at IS NULL`, alias)
}

type AccountRow struct {
	AccountID       string
	IdentityCount   int
	CredentialCount int
	IsDefault       bool
}

func (r *FilterOptionsRepository) Accounts(ctx context.Context, db *sql.DB, scanID string) ([]AccountRow, error) {
	q := `
		SELECT
			acc.account_id,
			COALESCE(ic.cnt, 0),
			COALESCE(cc.cnt, 0),
			acc.is_default
		FROM (
			SELECT account_id, BOOL_OR(COALESCE(is_default, false)) AS is_default
			FROM ` + r.t("accounts") + `
			GROUP BY account_id
		) acc
		LEFT JOIN (
			SELECT account_id, COUNT(*) AS cnt
			FROM ` + r.t(identitiesTable) + ` i
			WHERE ` + filterScope("i") + `
			GROUP BY account_id
		) ic ON ic.account_id = acc.account_id
		LEFT JOIN (
			SELECT account_id, COUNT(*) AS cnt
			FROM ` + r.t(credentialsTable) + ` c
			WHERE ` + filterScope("c") + `
			GROUP BY account_id
		) cc ON cc.account_id = acc.account_id
		ORDER BY acc.account_id`

	rows, err := db.QueryContext(ctx, q, scanID)
	if err != nil {
		return nil, fmt.Errorf("filter accounts: %w", err)
	}
	defer rows.Close()

	out := []AccountRow{}
	for rows.Next() {
		var a AccountRow
		if err := rows.Scan(&a.AccountID, &a.IdentityCount, &a.CredentialCount, &a.IsDefault); err != nil {
			return nil, fmt.Errorf("scan filter account: %w", err)
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// ── Generic "count rows per distinct column value" for a single table ─────
// (reuses the LabelCount type already declared in dashboard_overview_repo.go)

func (r *FilterOptionsRepository) groupByScanOnly(ctx context.Context, db *sql.DB, table, alias, column, scanID string) ([]LabelCount, error) {
	q := fmt.Sprintf(`
		SELECT COALESCE(NULLIF(BTRIM(%[1]s.%[2]s::text), ''), 'unknown') AS k, COUNT(*)
		FROM %[3]s %[1]s
		WHERE %[4]s
		GROUP BY k
		ORDER BY COUNT(*) DESC, k`, alias, column, r.t(table), filterScope(alias))
	return scanLabelCounts(ctx, db, q, []interface{}{scanID}, table+"."+column)
}

// Regions — ASSUMPTION: sourced from identities (same source Endpoint 3 used
// for identities_by_region). Flag if this should instead be credentials-based
// or a union of identities + credentials + accounts regions.
func (r *FilterOptionsRepository) Regions(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, identitiesTable, "i", "region", scanID)
}

func (r *FilterOptionsRepository) IdentityTypes(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, identitiesTable, "i", "identity_type", scanID)
}

func (r *FilterOptionsRepository) FunctionalClasses(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, identitiesTable, "i", "functional_class", scanID)
}

func (r *FilterOptionsRepository) Environments(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, identitiesTable, "i", "environment", scanID)
}

func (r *FilterOptionsRepository) Statuses(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, identitiesTable, "i", "status", scanID)
}

func (r *FilterOptionsRepository) CredentialTypes(ctx context.Context, db *sql.DB, scanID string) ([]LabelCount, error) {
	return r.groupByScanOnly(ctx, db, credentialsTable, "c", "credential_type", scanID)
}

// ── Scans ───────────────────────────────────────────────────────────────
// Deliberately unscoped by scan_id — this IS the scan picker. Lists every
// COMPLETED scan (a scan you can't query data for shouldn't be selectable).

type ScanRow struct {
	ScanID           string
	ScanEnd          *time.Time
	Status           string
	TotalIdentities  int
	TotalCredentials int
}

func (r *FilterOptionsRepository) Scans(ctx context.Context, db *sql.DB) ([]ScanRow, error) {
	q := `
		SELECT scan_id, scan_end, COALESCE(status, ''),
		       COALESCE(total_identities, 0), COALESCE(total_credentials, 0)
		FROM ` + r.t(scansTable) + `
		WHERE status = 'COMPLETED'
		ORDER BY scan_end DESC NULLS LAST, id DESC`

	rows, err := db.QueryContext(ctx, q)
	if err != nil {
		return nil, fmt.Errorf("filter scans: %w", err)
	}
	defer rows.Close()

	out := []ScanRow{}
	for rows.Next() {
		var (
			s   ScanRow
			end sql.NullTime
		)
		if err := rows.Scan(&s.ScanID, &end, &s.Status, &s.TotalIdentities, &s.TotalCredentials); err != nil {
			return nil, fmt.Errorf("scan filter scan row: %w", err)
		}
		if end.Valid {
			t := end.Time.UTC()
			s.ScanEnd = &t
		}
		out = append(out, s)
	}
	return out, rows.Err()
}