package dashboard

import (
	"context"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type BlastRadiusFilter struct {
	AccountID string
}

type BlastRadiusRepository struct {
	db *repository.PostgresDB
}

func NewBlastRadiusRepository(db *repository.PostgresDB) *BlastRadiusRepository {
	return &BlastRadiusRepository{db: db}
}

func (r *BlastRadiusRepository) Summary(ctx context.Context, f BlastRadiusFilter) (*models.BlastRadiusResponse, error) {
	where := []string{"ic.is_active = TRUE"}
	args := make([]interface{}, 0, 1)
	if f.AccountID != "" {
		where = append(where, fmt.Sprintf("c.account_id = $%d", len(args)+1))
		args = append(args, f.AccountID)
	}
	// Use active bindings from the latest completed scan and de-duplicate
	// credential/identity pairs.
	bindings := fmt.Sprintf(`
		SELECT DISTINCT ic.credential_id, ic.identity_id
		FROM %s.identity_credentials ic
		JOIN %s.credentials c
		  ON c.id = ic.credential_id
		 AND c.deleted_at IS NULL
		 AND c.scan_id = %s
		WHERE %s
		  AND ic.scan_id = %s`, repository.Schema, repository.Schema, repository.LatestScanIDSubquery(), strings.Join(where, " AND "), repository.LatestScanIDSubquery())

	response := &models.BlastRadiusResponse{
		SharedCredentials: make([]models.SharedCredential, 0),
		OrphanedCredentials: models.OrphanedCredentials{
			ByType: make([]models.OrphanedCredentialType, 0),
		},
	}

	sharedQuery := fmt.Sprintf(`
		WITH bindings AS (%s)
		SELECT c.id::text,
		       COALESCE(c.name, '')::text,
		       COALESCE(c.credential_type, 'unknown')::text,
		       COUNT(*)::int AS identity_count,
		       CASE
		           WHEN COUNT(*) >= 20 THEN 'critical'
		           WHEN COUNT(*) >= 10 THEN 'high'
		           WHEN COUNT(*) >= 5 THEN 'medium'
		           ELSE 'low'
		       END AS blast_radius
		FROM bindings b
		JOIN %s.credentials c
		  ON c.id = b.credential_id
		 AND c.deleted_at IS NULL
		 AND c.scan_id = %s
		GROUP BY c.id, c.name, c.credential_type
		HAVING COUNT(*) > 1
		ORDER BY identity_count DESC, c.id::text`, bindings, repository.Schema, repository.LatestScanIDSubquery())
	rows, err := r.db.DB.QueryContext(ctx, sharedQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("load shared credentials: %w", err)
	}
	for rows.Next() {
		var item models.SharedCredential
		if err := rows.Scan(&item.CredentialID, &item.CredentialName, &item.CredentialType, &item.IdentityCount, &item.BlastRadius); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan shared credential: %w", err)
		}
		response.SharedCredentials = append(response.SharedCredentials, item)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate shared credentials: %w", err)
	}
	rows.Close()

	orphanArgs := make([]interface{}, 0, 1)
	orphanFilter := ""
	if f.AccountID != "" {
		orphanFilter = " AND c.account_id = $1"
		orphanArgs = append(orphanArgs, f.AccountID)
	}
	orphanQuery := fmt.Sprintf(`
		WITH bindings AS (%s)
		SELECT COALESCE(c.credential_type, 'unknown')::text, COUNT(*)::int
		FROM %s.credentials c
		LEFT JOIN bindings b ON b.credential_id = c.id
		WHERE c.deleted_at IS NULL
		  AND c.scan_id = %s
		  AND b.credential_id IS NULL%s
		GROUP BY COALESCE(c.credential_type, 'unknown')
		ORDER BY COUNT(*) DESC, COALESCE(c.credential_type, 'unknown')`, bindings, repository.Schema, repository.LatestScanIDSubquery(), orphanFilter)
	orphanRows, err := r.db.DB.QueryContext(ctx, orphanQuery, orphanArgs...)
	if err != nil {
		return nil, fmt.Errorf("load orphaned credentials: %w", err)
	}
	for orphanRows.Next() {
		var item models.OrphanedCredentialType
		if err := orphanRows.Scan(&item.CredentialType, &item.Count); err != nil {
			orphanRows.Close()
			return nil, fmt.Errorf("scan orphaned credential type: %w", err)
		}
		response.OrphanedCredentials.ByType = append(response.OrphanedCredentials.ByType, item)
		response.OrphanedCredentials.Total += item.Count
	}
	if err := orphanRows.Err(); err != nil {
		orphanRows.Close()
		return nil, fmt.Errorf("iterate orphaned credentials: %w", err)
	}
	orphanRows.Close()

	response.CredentialsWithNoBinding = response.OrphanedCredentials.Total
	return response, nil
}
