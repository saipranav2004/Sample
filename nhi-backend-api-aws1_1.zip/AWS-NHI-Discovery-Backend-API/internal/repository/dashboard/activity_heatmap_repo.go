package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type ActivityHeatmapFilter struct {
	AccountID string
	Days      int
}

type ActivityHeatmapRepository struct{ db *repository.PostgresDB }

func NewActivityHeatmapRepository(db *repository.PostgresDB) *ActivityHeatmapRepository {
	return &ActivityHeatmapRepository{db: db}
}

func (r *ActivityHeatmapRepository) Heatmap(ctx context.Context, f ActivityHeatmapFilter) (*models.ActivityHeatmapResponse, error) {
	if f.Days <= 0 {
		f.Days = 7
	}
	args := []interface{}{f.Days}
	accountClause := ""
	if f.AccountID != "" {
		args = append(args, f.AccountID)
		accountClause = " AND c.account_id = $2"
	}
	base := fmt.Sprintf(`FROM %s.identity_usage iu
		JOIN %s.credentials c ON c.id = iu.credential_id AND c.scan_id = %s AND c.deleted_at IS NULL
		WHERE iu.scan_id = %s AND iu.window_start >= NOW() - ($1 * INTERVAL '1 day')%s`, repository.Schema, repository.Schema, repository.LatestScanIDSubquery(), repository.LatestScanIDSubquery(), accountClause)
	response := &models.ActivityHeatmapResponse{PeriodDays: f.Days, ByHour: make([]models.ActivityHour, 0), ByService: make([]models.ActivityService, 0)}
	var total int64
	if err := r.db.DB.QueryRowContext(ctx, "SELECT COALESCE(SUM(event_count), 0)::bigint "+base, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count activity calls: %w", err)
	}
	response.TotalAPICalls = total

	hourQuery := "SELECT date_trunc('hour', iu.window_start) AS hour, COALESCE(SUM(iu.event_count), 0)::bigint " + base + " GROUP BY date_trunc('hour', iu.window_start) ORDER BY hour"
	rows, err := r.db.DB.QueryContext(ctx, hourQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("load activity by hour: %w", err)
	}
	for rows.Next() {
		var item models.ActivityHour
		if err := rows.Scan(&item.Hour, &item.CallCount); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan activity hour: %w", err)
		}
		response.ByHour = append(response.ByHour, item)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate activity hours: %w", err)
	}
	rows.Close()

	serviceQuery := "SELECT COALESCE(NULLIF(TRIM(iu.service), ''), 'unknown'), COALESCE(SUM(iu.event_count), 0)::bigint " + base + " GROUP BY COALESCE(NULLIF(TRIM(iu.service), ''), 'unknown') ORDER BY 2 DESC, 1"
	serviceRows, err := r.db.DB.QueryContext(ctx, serviceQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("load activity by service: %w", err)
	}
	for serviceRows.Next() {
		var item models.ActivityService
		if err := serviceRows.Scan(&item.Service, &item.CallCount); err != nil {
			serviceRows.Close()
			return nil, fmt.Errorf("scan activity service: %w", err)
		}
		response.ByService = append(response.ByService, item)
	}
	if err := serviceRows.Err(); err != nil {
		serviceRows.Close()
		return nil, fmt.Errorf("iterate activity services: %w", err)
	}
	serviceRows.Close()
	if len(response.ByHour) > 0 {
		peak := response.ByHour[0]
		for _, item := range response.ByHour[1:] {
			if item.CallCount > peak.CallCount {
				peak = item
			}
		}
		response.PeakHour = &peak.Hour
		response.PeakCount = peak.CallCount
	}
	return response, nil
}
