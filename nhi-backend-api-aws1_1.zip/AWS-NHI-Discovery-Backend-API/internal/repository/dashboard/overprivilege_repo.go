package dashboard

import (
	"context"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type OverprivilegeFilter struct {
	AccountID string
}

type OverprivilegeRepository struct {
	db *repository.PostgresDB
}

func NewOverprivilegeRepository(db *repository.PostgresDB) *OverprivilegeRepository {
	return &OverprivilegeRepository{db: db}
}

func (r *OverprivilegeRepository) Summary(ctx context.Context, f OverprivilegeFilter) (*models.OverprivilegeResponse, error) {
	conditions := []string{}
	args := make([]interface{}, 0, 1)
	if f.AccountID != "" {
		conditions = append(conditions, fmt.Sprintf("c.account_id = $%d", len(args)+1))
		args = append(args, f.AccountID)
	}
	accountFilter := "WHERE ep.scan_id = " + repository.LatestScanIDSubquery()
	if len(conditions) > 0 {
		accountFilter += " AND " + strings.Join(conditions, " AND ")
	}

	// A permission is granted once per distinct credential/action. A used
	// permission is a granted action observed in identity_usage.event_name for
	// the same credential. No scan timestamp column is required.
	roleQuery := fmt.Sprintf(`
		WITH granted AS (
			SELECT DISTINCT ep.credential_id, ep.action
			FROM %s.effective_permissions ep
			JOIN %s.credentials c ON c.id = ep.credential_id AND c.scan_id = %s AND c.deleted_at IS NULL
			%s
			), usage AS (
				SELECT DISTINCT iu.credential_id, iu.event_name AS action
				FROM %s.identity_usage iu
				WHERE iu.scan_id = %s
			), role_stats AS (
			SELECT
				g.credential_id,
				COUNT(*)::int AS granted_permissions,
				COUNT(*) FILTER (WHERE u.credential_id IS NOT NULL)::int AS used_permissions
			FROM granted g
			LEFT JOIN usage u
				ON u.credential_id = g.credential_id
				AND u.action = g.action
			GROUP BY g.credential_id
		)
		SELECT
			rs.credential_id::text,
			COALESCE(c.name, '')::text,
			rs.granted_permissions,
			rs.used_permissions,
			ROUND((100.0 * (rs.granted_permissions - rs.used_permissions) /
				NULLIF(rs.granted_permissions, 0))::numeric, 1)::float8 AS unused_percentage
		FROM role_stats rs
		JOIN %s.credentials c ON c.id = rs.credential_id AND c.scan_id = %s AND c.deleted_at IS NULL
		ORDER BY unused_percentage DESC, (rs.granted_permissions - rs.used_permissions) DESC, rs.credential_id::text`,
		repository.Schema, repository.Schema, repository.LatestScanIDSubquery(), accountFilter,
		repository.Schema, repository.LatestScanIDSubquery(), repository.Schema, repository.LatestScanIDSubquery())

	rows, err := r.db.DB.QueryContext(ctx, roleQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("load overprivilege role statistics: %w", err)
	}
	defer rows.Close()

	response := &models.OverprivilegeResponse{
		OverprivilegedRoles: models.OverprivilegedRoles{
			BySeverity: make([]models.OverprivilegeSeverity, 0, 3),
		},
		TopOverprivileged: make([]models.TopOverprivilegedRole, 0, 10),
	}

	var totalUnusedPercentage float64
	for rows.Next() {
		var role models.TopOverprivilegedRole
		if err := rows.Scan(
			&role.CredentialID,
			&role.Name,
			&role.GrantedPermissions,
			&role.UsedPermissions,
			&role.UnusedPercentage,
		); err != nil {
			return nil, fmt.Errorf("scan overprivilege role statistics: %w", err)
		}

		response.TotalRolesAnalyzed++
		totalUnusedPercentage += role.UnusedPercentage
		unused := role.GrantedPermissions - role.UsedPermissions
		if unused >= 10 {
			response.OverprivilegedRoles.Total++
			switch {
			case unused >= 100:
				response.OverprivilegedRoles.BySeverity = appendOrIncrementSeverity(response.OverprivilegedRoles.BySeverity, "critical", "100+ unused permissions")
			case unused >= 50:
				response.OverprivilegedRoles.BySeverity = appendOrIncrementSeverity(response.OverprivilegedRoles.BySeverity, "high", "50-99 unused permissions")
			default:
				response.OverprivilegedRoles.BySeverity = appendOrIncrementSeverity(response.OverprivilegedRoles.BySeverity, "medium", "10-49 unused permissions")
			}
		}
		if len(response.TopOverprivileged) < 10 && unused >= 10 {
			response.TopOverprivileged = append(response.TopOverprivileged, role)
		}
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate overprivilege role statistics: %w", err)
	}
	if response.TotalRolesAnalyzed > 0 {
		response.AvgUnusedPercentage = totalUnusedPercentage / float64(response.TotalRolesAnalyzed)
	}
	return response, nil
}

func appendOrIncrementSeverity(items []models.OverprivilegeSeverity, severity, description string) []models.OverprivilegeSeverity {
	for i := range items {
		if items[i].Severity == severity {
			items[i].Count++
			return items
		}
	}
	return append(items, models.OverprivilegeSeverity{
		Severity: severity, Count: 1, Description: description,
	})
}
