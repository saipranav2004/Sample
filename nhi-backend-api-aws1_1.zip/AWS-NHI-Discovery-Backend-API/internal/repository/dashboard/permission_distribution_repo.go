package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type PermissionDistributionFilter struct{ AccountID string }
type PermissionDistributionRepository struct{ db *repository.PostgresDB }

func NewPermissionDistributionRepository(db *repository.PostgresDB) *PermissionDistributionRepository {
	return &PermissionDistributionRepository{db: db}
}

func (r *PermissionDistributionRepository) Distribution(ctx context.Context, f PermissionDistributionFilter) (*models.PermissionDistributionResponse, error) {
	accountJoin := ""
	accountCondition := ""
	args := make([]interface{}, 0, 1)
	if f.AccountID != "" {
		accountJoin = fmt.Sprintf("JOIN %s.credentials c ON c.id = ep.credential_id AND c.scan_id = %s AND c.deleted_at IS NULL", repository.Schema, repository.LatestScanIDSubquery())
		accountCondition = " AND c.account_id = $1"
		args = append(args, f.AccountID)
	}
	condition := "ep.scan_id = " + repository.LatestScanIDSubquery() + accountCondition
	query := fmt.Sprintf(`
		WITH actions AS (
			SELECT DISTINCT ep.credential_id,
				COALESCE(NULLIF(TRIM(ep.action), ''), 'unknown') AS action
			FROM %s.effective_permissions ep
			%s
			WHERE %s
		), counts AS (
			SELECT action, COUNT(*)::int AS role_count
			FROM actions
			GROUP BY action
		)
		SELECT action, role_count,
			(SELECT COUNT(*)::int FROM counts),
			(SELECT COUNT(*)::int FROM counts WHERE action = '*' OR action LIKE '%%:*' OR action LIKE '%%*%%'),
			(SELECT COUNT(*)::int FROM counts WHERE action = '*' OR action = '*:*' OR action LIKE 'iam:%%' OR LOWER(action) LIKE '%%admin%%')
		FROM counts
		ORDER BY role_count DESC, action ASC
		LIMIT 10`, repository.Schema, accountJoin, condition)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("load permission distribution: %w", err)
	}
	defer rows.Close()
	response := &models.PermissionDistributionResponse{TopGrantedActions: make([]models.GrantedAction, 0)}
	for rows.Next() {
		var item models.GrantedAction
		if err := rows.Scan(&item.Action, &item.RoleCount, &response.TotalUniqueActions, &response.WildcardActionsCount, &response.AdminAccessCount); err != nil {
			return nil, fmt.Errorf("scan permission distribution: %w", err)
		}
		response.TopGrantedActions = append(response.TopGrantedActions, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate permission distribution: %w", err)
	}
	return response, nil
}
