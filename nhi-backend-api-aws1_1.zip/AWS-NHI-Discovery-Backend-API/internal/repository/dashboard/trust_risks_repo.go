package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type TrustRisksFilter struct{ AccountID string }
type TrustRisksRepository struct{ db *repository.PostgresDB }

func NewTrustRisksRepository(db *repository.PostgresDB) *TrustRisksRepository {
	return &TrustRisksRepository{db: db}
}

func (r *TrustRisksRepository) Summary(ctx context.Context, f TrustRisksFilter) (*models.TrustRiskResponse, error) {
	where := ""
	args := make([]interface{}, 0, 1)
	if f.AccountID != "" {
		where = " AND (source_arn ILIKE '%' || $1 || '%' OR target_arn ILIKE '%' || $1 || '%')"
		args = append(args, f.AccountID)
	}
	query := fmt.Sprintf(`
		WITH edges AS (
			SELECT
				LOWER(COALESCE(edge_type, '')) AS edge_type,
				LOWER(COALESCE(conditions::text, '')) AS conditions,
				COALESCE(source_arn, '') AS source_arn,
				COALESCE(target_arn, '') AS target_arn,
				SUBSTRING(source_arn FROM 'arn:[^:]*:[^:]*:[^:]*:([0-9]{12}):') AS source_account,
				SUBSTRING(target_arn FROM 'arn:[^:]*:[^:]*:[^:]*:([0-9]{12}):') AS target_account
			FROM %s.trust_edges
			WHERE scan_id = %s AND is_active IS TRUE%s
		)
		SELECT
			COUNT(*) FILTER (WHERE source_account IS NOT NULL AND target_account IS NOT NULL AND source_account <> target_account)::int,
			COUNT(*) FILTER (WHERE source_account IS NOT NULL AND target_account IS NOT NULL AND source_account <> target_account AND conditions NOT LIKE '%%external_id%%' AND conditions NOT LIKE '%%externalid%%')::int,
			COUNT(*) FILTER (WHERE source_account IS NOT NULL AND source_account <> target_account AND (edge_type LIKE '%%vendor%%' OR edge_type LIKE '%%external%%' OR target_arn LIKE '%%vendor%%' OR target_account IS NULL))::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%oidc%%' OR source_arn LIKE '%%oidc%%' OR target_arn LIKE '%%oidc%%')::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%saml%%' OR source_arn LIKE '%%saml%%' OR target_arn LIKE '%%saml%%')::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%roles_anywhere%%' OR edge_type LIKE '%%roles anywhere%%' OR source_arn LIKE '%%rolesanywhere%%' OR target_arn LIKE '%%rolesanywhere%%')::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%public%%' OR target_arn IN ('*', 'public', 'anonymous') OR conditions LIKE '%%anonymous%%' OR conditions LIKE '%%principal%%*%%')::int,
			COUNT(*) FILTER (WHERE (edge_type LIKE '%%public%%' OR target_arn IN ('*', 'public', 'anonymous') OR conditions LIKE '%%anonymous%%' OR conditions LIKE '%%principal%%*%%') AND (edge_type LIKE '%%critical%%' OR conditions LIKE '%%wildcard%%' OR target_arn IN ('*', 'anonymous')))::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%service%%' OR target_arn LIKE '%%.amazonaws.com%%' OR target_arn LIKE '%%:service%%')::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%passrole%%' OR edge_type LIKE '%%pass_role%%' OR conditions LIKE '%%passrole%%' OR conditions LIKE '%%pass_role%%')::int,
			COUNT(*) FILTER (WHERE edge_type LIKE '%%privilege%%' OR edge_type LIKE '%%escalat%%' OR conditions LIKE '%%privilege%%' OR conditions LIKE '%%escalat%%')::int
		FROM edges`, repository.Schema, repository.LatestScanIDSubquery(), where)

	var response models.TrustRiskResponse
	if err := r.db.DB.QueryRowContext(ctx, query, args...).Scan(
		&response.CrossAccountTrusts.Total, &response.CrossAccountTrusts.WithoutExternalID, &response.CrossAccountTrusts.ToExternalVendors,
		&response.FederatedTrusts.OIDC, &response.FederatedTrusts.SAML, &response.FederatedTrusts.RolesAnywhere,
		&response.PublicTrusts.Total, &response.PublicTrusts.Critical, &response.ServiceTrusts,
		&response.PassRoleGrants, &response.PrivilegeEscalationPaths,
	); err != nil {
		return nil, fmt.Errorf("load trust risk summary: %w", err)
	}
	return &response, nil
}
