package dashboard

import (
	"context"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type SharedCredentialsFilter struct {
	MinIdentities int
}

type SharedCredentialsRepository struct {
	db *repository.PostgresDB
}

func NewSharedCredentialsRepository(db *repository.PostgresDB) *SharedCredentialsRepository {
	return &SharedCredentialsRepository{db: db}
}

func (r *SharedCredentialsRepository) List(ctx context.Context, f SharedCredentialsFilter) (*models.SharedCredentialsResponse, error) {
	if f.MinIdentities <= 0 {
		f.MinIdentities = 2
	}
	query := fmt.Sprintf(`
		WITH bindings AS (
			SELECT DISTINCT ic.credential_id, ic.identity_id,
				COALESCE(NULLIF(TRIM(i.identity_type), ''), 'unknown') AS identity_type
			FROM %s.identity_credentials ic
			JOIN %s.credentials c ON c.id::text = ic.credential_id::text AND c.deleted_at IS NULL
			LEFT JOIN %s.identities i ON i.id::text = ic.identity_id::text AND i.scan_id = %s
			WHERE ic.is_active = TRUE
			  AND ic.scan_id = %s
			  AND c.scan_id = %s
		), grouped AS (
			SELECT credential_id,
				COUNT(DISTINCT identity_id)::int AS identity_count,
				array_to_string(array_agg(DISTINCT identity_type ORDER BY identity_type), chr(31)) AS identity_types
			FROM bindings
			GROUP BY credential_id
			HAVING COUNT(DISTINCT identity_id) >= $1
		)
		SELECT g.credential_id::text,
			COALESCE(c.name, '')::text,
			COALESCE(c.credential_type, 'unknown')::text,
			g.identity_count,
			COALESCE(g.identity_types, ''),
			CASE
				WHEN g.identity_count >= 20 THEN 'critical'
				WHEN g.identity_count >= 10 THEN 'high'
				WHEN g.identity_count >= 5 THEN 'medium'
				ELSE 'low'
			END AS blast_radius
		FROM grouped g
		JOIN %s.credentials c ON c.id::text = g.credential_id::text AND c.scan_id = %s AND c.deleted_at IS NULL
		ORDER BY g.identity_count DESC, c.name ASC, g.credential_id::text`,
		repository.Schema, repository.Schema, repository.Schema, repository.LatestScanIDSubquery(),
		repository.LatestScanIDSubquery(), repository.LatestScanIDSubquery(), repository.Schema, repository.LatestScanIDSubquery(), repository.LatestScanIDSubquery())

	rows, err := r.db.DB.QueryContext(ctx, query, f.MinIdentities)
	if err != nil {
		return nil, fmt.Errorf("load shared credentials: %w", err)
	}
	defer rows.Close()
	response := &models.SharedCredentialsResponse{SharedCredentials: make([]models.SharedCredentialItem, 0)}
	for rows.Next() {
		var item models.SharedCredentialItem
		var types string
		if err := rows.Scan(&item.CredentialID, &item.Name, &item.CredentialType, &item.IdentityCount, &types, &item.BlastRadius); err != nil {
			return nil, fmt.Errorf("scan shared credential: %w", err)
		}
		if types == "" {
			item.IdentityTypes = []string{}
		} else {
			item.IdentityTypes = strings.Split(types, string(rune(31)))
		}
		response.SharedCredentials = append(response.SharedCredentials, item)
		response.TotalShared++
		if item.BlastRadius == "critical" {
			response.TotalCritical++
		}
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate shared credentials: %w", err)
	}
	return response, nil
}
