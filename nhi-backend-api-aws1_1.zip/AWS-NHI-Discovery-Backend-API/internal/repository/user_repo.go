// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"

// 	"nhi-backend-api/internal/models"
// )

// type UserRepository struct {
// 	db *PostgresDB
// }

// func NewUserRepository(db *PostgresDB) *UserRepository {
// 	return &UserRepository{db: db}
// }

// // GetByEmail retrieves a user record by email
// func (r *UserRepository) GetByEmail(ctx context.Context, email string) (*models.User, error) {
// 	// Oracle: :1  →  PostgreSQL: $1
// 	query := `
// 		SELECT id, email, password, full_name, team, role, created_at
// 		FROM ` + Schema + `.nhi_users
// 		WHERE LOWER(TRIM(email)) = LOWER(TRIM($1))`

// 	row := r.db.DB.QueryRowContext(ctx, query, email)

// 	var u models.User
// 	err := row.Scan(&u.ID, &u.Email, &u.Password, &u.FullName, &u.Team, &u.Role, &u.CreatedAt)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, nil // No row matched
// 		}
// 		return nil, fmt.Errorf("query user by email: %w", err)
// 	}

// 	return &u, nil
// }

// // GetByID retrieves a user record by ID
// func (r *UserRepository) GetByID(ctx context.Context, id int) (*models.User, error) {
// 	query := `
// 		SELECT id, email, password, full_name, team, role, created_at
// 		FROM ` + Schema + `.nhi_users
// 		WHERE id = $1`

// 	row := r.db.DB.QueryRowContext(ctx, query, id)

// 	var u models.User
// 	err := row.Scan(&u.ID, &u.Email, &u.Password, &u.FullName, &u.Team, &u.Role, &u.CreatedAt)
// 	if err != nil {
// 		if errors.Is(err, sql.ErrNoRows) {
// 			return nil, nil
// 		}
// 		return nil, fmt.Errorf("query user by id: %w", err)
// 	}

// 	return &u, nil
// }

















package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"nhi-backend-api/internal/database"
	"nhi-backend-api/internal/models"
)

// Table names inside the GLOBAL (authentication) database.
// The database itself — and optionally its schema — come from config.yaml.
//
// Expected columns:
//
//	tenants: id (uuid), db_name (text)          ← the tenant's data database
//	users:   id (uuid), tenant_id (uuid), email, password (bcrypt hash),
//	         full_name, role, created_at
const (
	globalUsersTable   = "nhi_users"
	globalTenantsTable = "tenants"
)

// UserRepository reads users from the GLOBAL database (config: global_database).
type UserRepository struct {
	db     *sql.DB
	schema string
}

func NewUserRepository(globalDB *sql.DB, schema string) *UserRepository {
	return &UserRepository{db: globalDB, schema: schema}
}

func (r *UserRepository) baseSelect() string {
	return `
		SELECT u.id::text,
		       u.tenant_id::text,
		       u.email,
		       u.password,
		       COALESCE(u.full_name, ''),
		       COALESCE(u.role, ''),
			    COALESCE(u.status, ''),
		       COALESCE(t.db_name, ''),
		       u.created_at
		FROM ` + database.Table(r.schema, globalUsersTable) + ` u
		LEFT JOIN ` + database.Table(r.schema, globalTenantsTable) + ` t ON t.tenant_id = u.tenant_id`
}

func scanUser(row *sql.Row) (*models.User, error) {
	var u models.User
	err := row.Scan(&u.ID, &u.TenantID, &u.Email, &u.Password, &u.FullName, &u.Role, &u.Status, &u.DBName, &u.CreatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil // no row matched
		}
		return nil, err
	}
	return &u, nil
}

// GetByEmail retrieves a user (with its tenant's db_name) by email.
func (r *UserRepository) GetByEmail(ctx context.Context, email string) (*models.User, error) {
	query := r.baseSelect() + `
		WHERE LOWER(TRIM(u.email)) = LOWER(TRIM($1))`

	u, err := scanUser(r.db.QueryRowContext(ctx, query, email))
	if err != nil {
		return nil, fmt.Errorf("query user by email: %w", err)
	}
	return u, nil
}

// GetByID retrieves a user (with its tenant's db_name) by user UUID.
func (r *UserRepository) GetByID(ctx context.Context, id string) (*models.User, error) {
	query := r.baseSelect() + `
		WHERE u.id::text = $1`

	u, err := scanUser(r.db.QueryRowContext(ctx, query, id))
	if err != nil {
		return nil, fmt.Errorf("query user by id: %w", err)
	}
	return u, nil
}
