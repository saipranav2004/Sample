package repository

import (
	"fmt"
	"os"
	"strconv"
)

// ─────────────────────────────────────────────────────────────────────────────
// Single source of truth for credential business rules.
//
// Every endpoint (inventory counts, hygiene flags, expiring list, stale list,
// dashboard summary, dashboard hygiene summary, list/export filters) MUST build
// its SQL from the helpers below so the same credential is never classified
// differently by two endpoints.
// ─────────────────────────────────────────────────────────────────────────────

// DefaultHighPrivilegeLevel is the privilege_level at (and above) which a
// credential is considered "high privilege".
const DefaultHighPrivilegeLevel = 7

// HighPrivilegeLevel returns the shared high-privilege threshold.
// It can be overridden with the HYGIENE_PRIVILEGE_THRESHOLD env var, but the
// SAME value is then used by every endpoint.
func HighPrivilegeLevel() int {
	if v := os.Getenv("HYGIENE_PRIVILEGE_THRESHOLD"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	return DefaultHighPrivilegeLevel
}

// CredHighPrivilegeSQL: privilege_level >= HighPrivilegeLevel().
func CredHighPrivilegeSQL() string {
	return fmt.Sprintf("(privilege_level IS NOT NULL AND privilege_level >= %d)", HighPrivilegeLevel())
}

// CredExpiredSQL is the ONE definition of "expired": the expiry DATE has passed.
// (The stored status column is not used, so a credential whose date is in the
// past is expired everywhere, even if status still says 'active'.)
const CredExpiredSQL = "(expires_at IS NOT NULL AND expires_at <= NOW())"

// CredExpiringSQL is the ONE definition of "expiring within N days":
//
//	status != 'expired' AND expires_at > NOW() AND expires_at <= NOW() + N days
//
// It is mutually exclusive with CredExpiredSQL (expires_at > NOW() vs <= NOW()),
// so a credential can never be counted as both expired and expiring.
// daysExpr is a SQL expression: a placeholder ("$1", "?") or a literal ("30").
func CredExpiringSQL(daysExpr string) string {
	return fmt.Sprintf(
		"(expires_at IS NOT NULL AND expires_at > NOW() "+
			"AND expires_at <= NOW() + make_interval(days => %s::int) "+
			"AND LOWER(COALESCE(status, '')) <> 'expired')", daysExpr)
}

// CredStaleSQL is the ONE definition of a stale/unused credential:
//
//	status = 'active' AND last_used_at IS NOT NULL AND last_used_at older than N days
//
// The activity column is always last_used_at. (Never-used credentials, i.e.
// last_used_at IS NULL, are tracked separately as "never used".)
func CredStaleSQL(daysExpr string) string {
	return fmt.Sprintf(
		"(last_used_at IS NOT NULL "+
			"AND last_used_at < NOW() - make_interval(days => %s::int) "+
			"AND LOWER(COALESCE(status, '')) = 'active')", daysExpr)
}
