package credentialexposure

import "time"

// dashboardTimestamp matches the scanner's text timestamp representation.
func dashboardTimestamp(t time.Time) string {
	return t.UTC().Format("2006-01-02T15:04:05+00:00")
}
