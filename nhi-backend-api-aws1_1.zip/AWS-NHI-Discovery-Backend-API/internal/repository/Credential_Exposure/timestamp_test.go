package credentialexposure

import (
	"testing"
	"time"
)

func TestDashboardTimestampIsWholeSecondUTC(t *testing.T) {
	input := time.Date(2026, time.October, 7, 12, 34, 56, 987654321, time.FixedZone("offset", 5*60*60+30*60))
	got := dashboardTimestamp(input)
	want := "2026-10-07T07:04:56+00:00"
	if got != want {
		t.Fatalf("dashboardTimestamp() = %q, want %q", got, want)
	}
}
