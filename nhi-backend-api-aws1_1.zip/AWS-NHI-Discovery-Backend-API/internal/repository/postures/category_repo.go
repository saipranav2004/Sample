// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"
// )

// type CategoryRepository struct {
// 	db *PostgresDB
// }

// func NewCategoryRepository(db *PostgresDB) *CategoryRepository {
// 	return &CategoryRepository{db: db}
// }

// type CategoryRow struct {
// 	CategoryCode    string
// 	CategoryName    string
// 	Description     sql.NullString
// 	Weight          float64
// 	TotalIdentities int
// 	TotalFailing    int
// 	Score           float64
// }

// func (r *CategoryRepository) GetAll(ctx context.Context, scanID string) ([]CategoryRow, error) {
// 	fleetFilter := LatestScanFilter
// 	var args []interface{}
// 	if scanID != "" {
// 		fleetFilter = "scan_id = $1"
// 		args = append(args, scanID)
// 	}

// 	query := fmt.Sprintf(`
// 		WITH categories AS (
// 			SELECT category_code, category_name, description, weight
// 			FROM %[1]s.ispm_categories
// 			WHERE enabled = true
// 		),
// 		fleet AS (
// 			SELECT identity_id::text AS identity_id
// 			FROM %[1]s.nhi_identities_aws
// 			WHERE %[2]s
// 		),
// 		identity_scores AS (
// 			SELECT
// 				f.identity_id,
// 				f.rule_category AS category_code,
// 				GREATEST(0, 100 - COALESCE(SUM(CASE WHEN f.status = 'open' THEN f.risk_score ELSE 0 END), 0)) AS identity_score,
// 				BOOL_OR(f.status = 'open') AS is_failing
// 			FROM %[1]s.ispm_nhi_findings f
// 			GROUP BY f.identity_id, f.rule_category
// 		)
// 		SELECT
// 			c.category_code, c.category_name, c.description, c.weight,
// 			(SELECT COUNT(*) FROM fleet) AS total_identities,
// 			COUNT(*) FILTER (WHERE COALESCE(isc.is_failing, false)) AS total_failing,
// 			COALESCE(ROUND(AVG(COALESCE(isc.identity_score, 100))::numeric, 1), 100.0) AS score
// 		FROM categories c
// 		CROSS JOIN fleet fl
// 		LEFT JOIN identity_scores isc
// 		       ON isc.identity_id = fl.identity_id
// 		      AND isc.category_code = c.category_code
// 		GROUP BY c.category_code, c.category_name, c.description, c.weight
// 		ORDER BY c.weight DESC, c.category_name ASC`,
// 		Schema, fleetFilter,
// 	)

// 	rows, err := r.db.DB.QueryContext(ctx, query, args...)
// 	if err != nil {
// 		return nil, fmt.Errorf("category query: %w", err)
// 	}
// 	defer rows.Close()

// 	out := []CategoryRow{}
// 	for rows.Next() {
// 		var c CategoryRow
// 		if err := rows.Scan(&c.CategoryCode, &c.CategoryName, &c.Description, &c.Weight,
// 			&c.TotalIdentities, &c.TotalFailing, &c.Score); err != nil {
// 			return nil, fmt.Errorf("scan category row: %w", err)
// 		}
// 		out = append(out, c)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate category rows: %w", err)
// 	}
// 	return out, nil
// }























// package repository

// import (
// 	"context"
// 	"database/sql"
// 	"fmt"

// 	"nhi-backend-api/internal/database"
// )

// // Table names. The schema is NOT hard-coded: it is injected from config
// // (dbm.DataSchema()) exactly like the other new_api repositories.
// const (
// 	categoriesTable = "ispm_categories"
// 	fleetTable      = "nhi_identities_aws"
// 	findingsTable   = "ispm_nhi_findings"
// )

// // CategoryRepository holds only the schema name. The *sql.DB is passed per
// // call because it is the TENANT database chosen from the JWT db_name.
// type CategoryRepository struct {
// 	schema string
// }

// func NewCategoryRepository(schema string) *CategoryRepository {
// 	return &CategoryRepository{schema: schema}
// }

// type CategoryRow struct {
// 	CategoryCode    string
// 	CategoryName    string
// 	Description     sql.NullString
// 	Weight          float64
// 	TotalIdentities int
// 	TotalFailing    int
// 	Score           float64
// }

// // GetAll scores every enabled category for ONE concrete scan.
// // scanID must already be resolved by the service (never empty here).
// func (r *CategoryRepository) GetAll(ctx context.Context, db *sql.DB, scanID string) ([]CategoryRow, error) {
// 	query := fmt.Sprintf(`
// 		WITH categories AS (
// 			SELECT category_code, category_name, description, weight
// 			FROM %[1]s
// 			WHERE enabled = true
// 		),
// 		fleet AS (
// 			SELECT identity_id::text AS identity_id
// 			FROM %[2]s
// 			WHERE scan_id = $1
// 		),
// 		identity_scores AS (
// 			SELECT
// 				f.identity_id,
// 				f.rule_category AS category_code,
// 				GREATEST(0, 100 - COALESCE(SUM(CASE WHEN f.status = 'open' THEN f.risk_score ELSE 0 END), 0)) AS identity_score,
// 				BOOL_OR(f.status = 'open') AS is_failing
// 			FROM %[3]s f
// 			GROUP BY f.identity_id, f.rule_category
// 		)
// 		SELECT
// 			c.category_code, c.category_name, c.description, c.weight,
// 			(SELECT COUNT(*) FROM fleet) AS total_identities,
// 			COUNT(*) FILTER (WHERE COALESCE(isc.is_failing, false)) AS total_failing,
// 			COALESCE(ROUND(AVG(COALESCE(isc.identity_score, 100))::numeric, 1), 100.0) AS score
// 		FROM categories c
// 		CROSS JOIN fleet fl
// 		LEFT JOIN identity_scores isc
// 		       ON isc.identity_id = fl.identity_id
// 		      AND isc.category_code = c.category_code
// 		GROUP BY c.category_code, c.category_name, c.description, c.weight
// 		ORDER BY c.weight DESC, c.category_name ASC`,
// 		database.Table(r.schema, categoriesTable),
// 		database.Table(r.schema, fleetTable),
// 		database.Table(r.schema, findingsTable),
// 	)

// 	rows, err := db.QueryContext(ctx, query, scanID)
// 	if err != nil {
// 		return nil, fmt.Errorf("category query: %w", err)
// 	}
// 	defer rows.Close()

// 	out := []CategoryRow{}
// 	for rows.Next() {
// 		var c CategoryRow
// 		if err := rows.Scan(&c.CategoryCode, &c.CategoryName, &c.Description, &c.Weight,
// 			&c.TotalIdentities, &c.TotalFailing, &c.Score); err != nil {
// 			return nil, fmt.Errorf("scan category row: %w", err)
// 		}
// 		out = append(out, c)
// 	}
// 	if err := rows.Err(); err != nil {
// 		return nil, fmt.Errorf("iterate category rows: %w", err)
// 	}
// 	return out, nil
// }

















package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/database"
)

// Table names. The schema is NOT hard-coded: it is injected from config
// (dbm.DataSchema()) exactly like the other new_api repositories.
const (
	categoriesTable = "ispm_categories"
	fleetTable      = "nhi_identities_aws"
	findingsTable   = "ispm_nhi_findings"

	// Key columns. nhi_identities_aws names its primary key "id" (the other
	// repositories alias it as identity_id); the findings table points back to
	// it with a column called identity_id. If your findings column has another
	// name, change it here (one place).
	fleetKeyColumn    = "id"
	findingsKeyColumn = "identity_id"
)

// CategoryRepository holds only the schema name. The *sql.DB is passed per
// call because it is the TENANT database chosen from the JWT db_name.
type CategoryRepository struct {
	schema string
}

func NewCategoryRepository(schema string) *CategoryRepository {
	return &CategoryRepository{schema: schema}
}

type CategoryRow struct {
	CategoryCode    string
	CategoryName    string
	Description     sql.NullString
	Weight          float64
	TotalIdentities int
	TotalFailing    int
	Score           float64
}

// GetAll scores every enabled category for ONE concrete scan.
// scanID must already be resolved by the service (never empty here).
func (r *CategoryRepository) GetAll(ctx context.Context, db *sql.DB, scanID string) ([]CategoryRow, error) {
	query := fmt.Sprintf(`
		WITH categories AS (
			SELECT category_code, category_name, description, weight
			FROM %[1]s
			WHERE enabled = true
		),
		fleet AS (
			SELECT %[4]s::text AS identity_id
			FROM %[2]s
			WHERE scan_id = $1
		),
		identity_scores AS (
			SELECT
				f.%[5]s::text AS identity_id,
				f.rule_category AS category_code,
				GREATEST(0, 100 - COALESCE(SUM(CASE WHEN f.status = 'open' THEN f.risk_score ELSE 0 END), 0)) AS identity_score,
				BOOL_OR(f.status = 'open') AS is_failing
			FROM %[3]s f
			GROUP BY f.%[5]s::text, f.rule_category
		)
		SELECT
			c.category_code, c.category_name, c.description, c.weight,
			(SELECT COUNT(*) FROM fleet) AS total_identities,
			COUNT(*) FILTER (WHERE COALESCE(isc.is_failing, false)) AS total_failing,
			COALESCE(ROUND(AVG(COALESCE(isc.identity_score, 100))::numeric, 1), 100.0) AS score
		FROM categories c
		CROSS JOIN fleet fl
		LEFT JOIN identity_scores isc
		       ON isc.identity_id = fl.identity_id
		      AND isc.category_code = c.category_code
		GROUP BY c.category_code, c.category_name, c.description, c.weight
		ORDER BY c.weight DESC, c.category_name ASC`,
		database.Table(r.schema, categoriesTable),
		database.Table(r.schema, fleetTable),
		database.Table(r.schema, findingsTable),
		fleetKeyColumn,
		findingsKeyColumn,
	)

	rows, err := db.QueryContext(ctx, query, scanID)
	if err != nil {
		return nil, fmt.Errorf("category query: %w", err)
	}
	defer rows.Close()

	out := []CategoryRow{}
	for rows.Next() {
		var c CategoryRow
		if err := rows.Scan(&c.CategoryCode, &c.CategoryName, &c.Description, &c.Weight,
			&c.TotalIdentities, &c.TotalFailing, &c.Score); err != nil {
			return nil, fmt.Errorf("scan category row: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate category rows: %w", err)
	}
	return out, nil
}