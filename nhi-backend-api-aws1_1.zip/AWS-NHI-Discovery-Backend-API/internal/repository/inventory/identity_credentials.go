package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

var ErrIdentityCredentialsNotFound = errors.New("identity not found")
type IdentityCredentialsRepository struct{ db *repository.PostgresDB }
func NewIdentityCredentialsRepository(db *repository.PostgresDB) *IdentityCredentialsRepository { return &IdentityCredentialsRepository{db:db} }

func (r *IdentityCredentialsRepository) GetByIdentityID(ctx context.Context, identityID string, allowedAccounts []string, accountFilter string) (*m.IdentityCredentialsResponse,error) {
	if r==nil || r.db==nil || r.db.DB==nil || len(allowedAccounts)==0{return nil,fmt.Errorf("identity credential source unavailable")}
	out:=&m.IdentityCredentialsResponse{Credentials:[]m.IdentityCredentialItem{}}
	qIdentity:=fmt.Sprintf(`SELECT id::text,COALESCE(name,'') FROM %s.identities WHERE id::text=$1 AND deleted_at IS NULL AND %s
 AND account_id::text=ANY($2::text[]) AND ($3::text='' OR account_id::text=$3)`,repository.Schema,repository.LatestScanFilter)
	if err:=r.db.DB.QueryRowContext(ctx,qIdentity,identityID,pq.Array(allowedAccounts),accountFilter).Scan(&out.IdentityID,&out.IdentityName);err!=nil{if errors.Is(err,sql.ErrNoRows){return nil,ErrIdentityCredentialsNotFound};return nil,fmt.Errorf("load authorized identity: %w",err)}
	q:=fmt.Sprintf(`SELECT c.id::text,COALESCE(c.arn,''),COALESCE(c.name,''),COALESCE(c.credential_type,'unknown'),
 COALESCE(ic.binding_type,''),COALESCE(ic.is_primary,FALSE),COALESCE(ic.is_active,FALSE),MAX(iu.window_start),c.privilege_level
FROM %s.identity_credentials ic
JOIN %s.credentials c ON c.id::text=ic.credential_id::text AND c.scan_id=ic.scan_id AND c.deleted_at IS NULL AND c.%s
LEFT JOIN %s.identity_usage iu ON iu.identity_id::text=ic.identity_id::text AND iu.credential_id::text=ic.credential_id::text AND iu.scan_id=ic.scan_id
WHERE ic.identity_id::text=$1 AND ic.scan_id=%s AND ic.is_active IS TRUE
 AND c.account_id::text=ANY($2::text[]) AND ($3::text='' OR c.account_id::text=$3)
GROUP BY c.id,c.arn,c.name,c.credential_type,ic.binding_type,ic.is_primary,ic.is_active,c.privilege_level
ORDER BY c.credential_type,c.name,c.id::text`,repository.Schema,repository.Schema,repository.LatestScanFilter,repository.Schema,repository.LatestScanIDSubquery())
	rows,err:=r.db.DB.QueryContext(ctx,q,out.IdentityID,pq.Array(allowedAccounts),accountFilter);if err!=nil{return nil,fmt.Errorf("query identity credentials: %w",err)};defer rows.Close()
	for rows.Next(){var x m.IdentityCredentialItem;var last sql.NullTime;var privilege sql.NullInt64
		if err:=rows.Scan(&x.CredentialID,&x.CredentialARN,&x.CredentialName,&x.CredentialType,&x.BindingType,&x.IsPrimary,&x.IsActive,&last,&privilege);err!=nil{return nil,fmt.Errorf("scan identity credential: %w",err)}
		if last.Valid{t:=last.Time.UTC().Truncate(time.Second);x.LastUsedAt=&t};if privilege.Valid{v:=int(privilege.Int64);x.PrivilegeLevel=&v};out.Credentials=append(out.Credentials,x)
	}
	if err:=rows.Err();err!=nil{return nil,fmt.Errorf("iterate identity credentials: %w",err)};out.CredentialCount=len(out.Credentials);return out,nil
}
