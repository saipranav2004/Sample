package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

var ErrIdentityActivityNotFound = errors.New("identity not found")

type IdentityActivityFilter struct {
	IdentityID      string
	AllowedAccounts []string
	AccountID       string
	Days            int
}

type IdentityActivityRepository struct{ db *repository.PostgresDB }

func NewIdentityActivityRepository(db *repository.PostgresDB) *IdentityActivityRepository {
	return &IdentityActivityRepository{db: db}
}

func (r *IdentityActivityRepository) GetActivity(ctx context.Context, f IdentityActivityFilter) (*m.IdentityActivityResponse, error) {
	if r == nil || r.db == nil || r.db.DB == nil || len(f.AllowedAccounts) == 0 {
		return nil, fmt.Errorf("identity activity source unavailable")
	}
	if f.Days < 1 { f.Days = 30 }
	var id string
	qIdentity := fmt.Sprintf(`SELECT id::text FROM %s.identities
WHERE id::text=$1 AND deleted_at IS NULL AND %s
 AND account_id::text=ANY($2::text[]) AND ($3::text='' OR account_id::text=$3)`, repository.Schema, repository.LatestScanFilter)
	if err := r.db.DB.QueryRowContext(ctx, qIdentity, f.IdentityID, pq.Array(f.AllowedAccounts), f.AccountID).Scan(&id); err != nil {
		if errors.Is(err, sql.ErrNoRows) { return nil, ErrIdentityActivityNotFound }
		return nil, fmt.Errorf("load authorized identity: %w", err)
	}
	out := &m.IdentityActivityResponse{IdentityID:id, PeriodDays:f.Days, TopActions:[]m.IdentityActivityTopAction{}, ServicesCalled:[]string{}}
	base := fmt.Sprintf(`FROM %s.identity_usage iu
JOIN %s.credentials c ON c.id::text=iu.credential_id::text AND c.scan_id=iu.scan_id
 AND c.deleted_at IS NULL AND c.%s
WHERE iu.identity_id::text=$1 AND iu.scan_id=%s
 AND c.account_id::text=ANY($2::text[]) AND ($3::text='' OR c.account_id::text=$3)
 AND iu.window_start >= NOW()-($4 * INTERVAL '1 day')`, repository.Schema, repository.Schema, repository.LatestScanFilter, repository.LatestScanIDSubquery())
	args := []interface{}{id, pq.Array(f.AllowedAccounts), f.AccountID, f.Days}
	if err := r.db.DB.QueryRowContext(ctx, `SELECT COALESCE(SUM(iu.event_count),0)::bigint,
 COUNT(DISTINCT iu.action)::int, COUNT(DISTINCT NULLIF(BTRIM(iu.service),''))::int `+base, args...).Scan(&out.TotalAPICalls, &out.UniqueActions, &out.UniqueServices); err != nil {
		return nil, fmt.Errorf("summarize identity activity: %w", err)
	}
	var last sql.NullTime
	if err := r.db.DB.QueryRowContext(ctx, `SELECT MAX(iu.window_start) `+base, args...).Scan(&last); err != nil {
		return nil, fmt.Errorf("load last identity activity: %w", err)
	}
	if last.Valid { t:=last.Time.UTC(); out.LastActivityAt=&t }
	rows, err := r.db.DB.QueryContext(ctx, `SELECT COALESCE(NULLIF(BTRIM(iu.action),''),'unknown'),
 COALESCE(NULLIF(BTRIM(iu.service),''),'unknown'), SUM(iu.event_count)::bigint, MAX(iu.window_start)
 `+base+` GROUP BY iu.action,iu.service ORDER BY 3 DESC,1,2 LIMIT 10`, args...)
	if err != nil { return nil, fmt.Errorf("query top identity actions: %w", err) }
	for rows.Next() {
		var item m.IdentityActivityTopAction
		if err := rows.Scan(&item.EventName,&item.Service,&item.Count,&item.LastSeen); err != nil { rows.Close(); return nil, fmt.Errorf("scan identity action: %w", err) }
		item.LastSeen=item.LastSeen.UTC(); out.TopActions=append(out.TopActions,item)
	}
	if err:=rows.Err(); err!=nil { rows.Close(); return nil, fmt.Errorf("iterate identity actions: %w",err) }; rows.Close()
	services, err := r.db.DB.QueryContext(ctx, `SELECT DISTINCT COALESCE(NULLIF(BTRIM(iu.service),''),'unknown') `+base+` ORDER BY 1`, args...)
	if err != nil { return nil, fmt.Errorf("query identity services: %w",err) }
	defer services.Close()
	for services.Next() { var v string; if err:=services.Scan(&v); err!=nil{return nil,fmt.Errorf("scan identity service: %w",err)}; out.ServicesCalled=append(out.ServicesCalled,v) }
	if err:=services.Err(); err!=nil{return nil,fmt.Errorf("iterate identity services: %w",err)}
	return out,nil
}
