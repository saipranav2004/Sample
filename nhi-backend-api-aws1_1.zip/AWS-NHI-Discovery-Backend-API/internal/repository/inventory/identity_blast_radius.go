package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
	"nhi-backend-api/internal/repository"
)

var ErrIdentityBlastRadiusNotFound = errors.New("identity not found")

type IdentityBlastRadiusFilter struct { IdentityID string; AllowedAccounts []string; AccountID string }
type IdentityBlastRadiusRepository struct{ db *repository.PostgresDB }
func NewIdentityBlastRadiusRepository(db *repository.PostgresDB) *IdentityBlastRadiusRepository { return &IdentityBlastRadiusRepository{db:db} }

func (r *IdentityBlastRadiusRepository) GetBlastRadius(ctx context.Context, f IdentityBlastRadiusFilter) (*m.IdentityBlastRadiusResponse,error) {
	if r==nil || r.db==nil || r.db.DB==nil || len(f.AllowedAccounts)==0 { return nil,fmt.Errorf("identity blast-radius source unavailable") }
	var id string
	qIdentity:=fmt.Sprintf(`SELECT id::text FROM %s.identities WHERE id::text=$1 AND deleted_at IS NULL AND %s
 AND account_id::text=ANY($2::text[]) AND ($3::text='' OR account_id::text=$3)`,repository.Schema,repository.LatestScanFilter)
	if err:=r.db.DB.QueryRowContext(ctx,qIdentity,f.IdentityID,pq.Array(f.AllowedAccounts),f.AccountID).Scan(&id); err!=nil { if errors.Is(err,sql.ErrNoRows){return nil,ErrIdentityBlastRadiusNotFound}; return nil,fmt.Errorf("load authorized identity: %w",err) }
	out:=&m.IdentityBlastRadiusResponse{IdentityID:id,CredentialsSharedWithOthers:[]m.IdentityBlastRadiusSharedCredential{}}
	base:=fmt.Sprintf(`FROM %s.identity_credentials ic
JOIN %s.credentials c ON c.id::text=ic.credential_id::text AND c.scan_id=ic.scan_id AND c.deleted_at IS NULL AND c.%s
WHERE ic.scan_id=%s AND ic.identity_id::text=$1 AND ic.is_active IS TRUE
 AND c.account_id::text=ANY($2::text[]) AND ($3::text='' OR c.account_id::text=$3)`,repository.Schema,repository.Schema,repository.LatestScanFilter,repository.LatestScanIDSubquery())
	args:=[]interface{}{id,pq.Array(f.AllowedAccounts),f.AccountID}
	if err:=r.db.DB.QueryRowContext(ctx,`SELECT COUNT(DISTINCT c.id)::bigint,
 COUNT(DISTINCT c.id) FILTER(WHERE c.privilege_level::text ~ '^[0-9]+$' AND c.privilege_level::text::int>=4)::bigint `+base,args...).Scan(&out.TotalCredentialsExposed,&out.HighPrivilegeCredentials); err!=nil{return nil,fmt.Errorf("summarize identity credential exposure: %w",err)}
	q:=fmt.Sprintf(`SELECT COALESCE(NULLIF(BTRIM(c.name),''),c.id::text),COUNT(DISTINCT other.id)::bigint
FROM %s.identity_credentials own
JOIN %s.credentials c ON c.id::text=own.credential_id::text AND c.scan_id=own.scan_id AND c.deleted_at IS NULL AND c.%s
JOIN %s.identity_credentials peer ON peer.credential_id::text=own.credential_id::text AND peer.scan_id=own.scan_id AND peer.is_active IS TRUE AND peer.identity_id::text<>own.identity_id::text
JOIN %s.identities other ON other.id::text=peer.identity_id::text AND other.scan_id=peer.scan_id AND other.deleted_at IS NULL AND other.account_id::text=ANY($2::text[])
WHERE own.identity_id::text=$1 AND own.is_active IS TRUE AND own.scan_id=%s AND c.account_id::text=ANY($2::text[])
 AND ($3::text='' OR c.account_id::text=$3)
GROUP BY c.id,c.name HAVING COUNT(DISTINCT other.id)>0 ORDER BY COUNT(DISTINCT other.id) DESC,c.id::text`,repository.Schema,repository.Schema,repository.LatestScanFilter,repository.Schema,repository.Schema,repository.LatestScanIDSubquery())
	rows,err:=r.db.DB.QueryContext(ctx,q,args...); if err!=nil{return nil,fmt.Errorf("query shared identity credentials: %w",err)}; defer rows.Close()
	for rows.Next(){var x m.IdentityBlastRadiusSharedCredential; if err:=rows.Scan(&x.CredentialName,&x.AlsoUsedByIdentityCount);err!=nil{return nil,fmt.Errorf("scan shared identity credential: %w",err)};out.CredentialsSharedWithOthers=append(out.CredentialsSharedWithOthers,x)}
	if err:=rows.Err();err!=nil{return nil,fmt.Errorf("iterate shared identity credentials: %w",err)}
	return out,nil
}
