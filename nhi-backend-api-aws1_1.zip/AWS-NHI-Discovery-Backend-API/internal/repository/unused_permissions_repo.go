package repository

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"nhi-backend-api/internal/models"
)

type UnusedPermissionsFilter struct {
	AccountID      string
	CredentialType string
}

type UnusedPermissionsRepository struct {
	db *PostgresDB
}

func NewUnusedPermissionsRepository(db *PostgresDB) *UnusedPermissionsRepository {
	return &UnusedPermissionsRepository{db: db}
}

type unusedPermissionRow struct {
	credentialID string
	action       string
	used         bool
}

func (r *UnusedPermissionsRepository) Summary(ctx context.Context, f UnusedPermissionsFilter) (*models.UnusedPermissionsResponse, error) {
	args := make([]interface{}, 0, 2)
	credentialConditions := make([]string, 0, 2)
	if f.AccountID != "" {
		args = append(args, f.AccountID)
		credentialConditions = append(credentialConditions, fmt.Sprintf("c.account_id = $%d", len(args)))
	}
	if f.CredentialType != "" {
		args = append(args, f.CredentialType)
		credentialConditions = append(credentialConditions, fmt.Sprintf("LOWER(c.credential_type) = LOWER($%d)", len(args)))
	}
	credentialFilter := ""
	if len(credentialConditions) > 0 {
		credentialFilter = " AND " + strings.Join(credentialConditions, " AND ")
	}

	query := fmt.Sprintf(`
		WITH granted AS (
			SELECT ep.credential_id::text AS credential_id,
				COALESCE(NULLIF(TRIM(ep.action), ''), 'unknown') AS action,
				MAX(COALESCE(ep.source_name, '')) AS source_name
			FROM %s.effective_permissions ep
			JOIN %s.credentials c ON c.id = ep.credential_id AND c.scan_id = %s AND c.deleted_at IS NULL
			WHERE ep.scan_id = %s%s
			GROUP BY ep.credential_id, COALESCE(NULLIF(TRIM(ep.action), ''), 'unknown')
		), used AS (
			SELECT DISTINCT iu.credential_id::text AS credential_id,
				COALESCE(NULLIF(TRIM(iu.event_name), ''), 'unknown') AS action
			FROM %s.identity_usage iu
			WHERE iu.scan_id = %s
		), matched AS (
			SELECT g.credential_id, g.action,
				EXISTS (
					SELECT 1 FROM used u
					WHERE u.credential_id = g.credential_id
					  AND LOWER(u.action) = LOWER(g.action)
				) AS ever_used
			FROM granted g
		)
		SELECT credential_id, action, ever_used
		FROM matched`, Schema, Schema, LatestScanIDSubquery(), LatestScanIDSubquery(), credentialFilter, Schema, LatestScanIDSubquery())

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("load unused permissions: %w", err)
	}
	defer rows.Close()

	allRows := make([]unusedPermissionRow, 0)
	for rows.Next() {
		var item unusedPermissionRow
		if err := rows.Scan(&item.credentialID, &item.action, &item.used); err != nil {
			return nil, fmt.Errorf("scan unused permission: %w", err)
		}
		allRows = append(allRows, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate unused permissions: %w", err)
	}

	response := &models.UnusedPermissionsResponse{TopUnusedActions: make([]models.UnusedPermissionAction, 0)}
	roleGranted := make(map[string]int)
	roleUnused := make(map[string]int)
	actionRoles := make(map[string]map[string]bool)
	for _, row := range allRows {
		roleGranted[row.credentialID]++
		if row.used {
			continue
		}
		response.TotalUnusedPermissions++
		roleUnused[row.credentialID]++
		if actionRoles[row.action] == nil {
			actionRoles[row.action] = make(map[string]bool)
		}
		actionRoles[row.action][row.credentialID] = true
	}
	response.AffectedRoles = len(roleUnused)
	var totalGranted, totalUnused int
	for role, granted := range roleGranted {
		totalGranted += granted
		totalUnused += roleUnused[role]
	}
	if totalGranted > 0 {
		response.PotentialDownscopeSavings = fmt.Sprintf("%.0f%% average unused", 100*float64(totalUnused)/float64(totalGranted))
	} else {
		response.PotentialDownscopeSavings = "0% average unused"
	}
	for action, roles := range actionRoles {
		response.TopUnusedActions = append(response.TopUnusedActions, models.UnusedPermissionAction{Action: action, GrantedToRoleCount: len(roles), EverUsed: false})
	}
	sort.Slice(response.TopUnusedActions, func(i, j int) bool {
		if response.TopUnusedActions[i].GrantedToRoleCount == response.TopUnusedActions[j].GrantedToRoleCount {
			return response.TopUnusedActions[i].Action < response.TopUnusedActions[j].Action
		}
		return response.TopUnusedActions[i].GrantedToRoleCount > response.TopUnusedActions[j].GrantedToRoleCount
	})
	if len(response.TopUnusedActions) > 10 {
		response.TopUnusedActions = response.TopUnusedActions[:10]
	}
	return response, nil
}
