// package config

// import (
// 	"fmt"
// 	"net"
// 	"net/url"
// 	"os"
// 	"strconv"
// 	"strings"

// 	"gopkg.in/yaml.v3"
// )

// type Config struct {
// 	Server   ServerConfig   `yaml:"server"`
// 	Database DatabaseConfig `yaml:"database"`
// 	JWT      JWTConfig      `yaml:"jwt"`
// 	CORS     CORSConfig     `yaml:"cors"`
// }

// type ServerConfig struct {
// 	Port int    `yaml:"port"`
// 	Host string `yaml:"host"`
// }

// type DatabaseConfig struct {
// 	Host         string `yaml:"host"`
// 	Port         int    `yaml:"port"`
// 	DatabaseName string `yaml:"database_name"` // matches your config.yaml
// 	LegacyName   string `yaml:"name"`          // also accepted, in case an older config uses "name"
// 	User         string `yaml:"user"`
// 	Password     string `yaml:"password"`
// 	SSLMode      string `yaml:"sslmode"` // disable | require | verify-full ... (default: require)
// }

// // DBName returns the configured PostgreSQL database name.
// func (d *DatabaseConfig) DBName() string {
// 	if n := strings.TrimSpace(d.DatabaseName); n != "" {
// 		return n
// 	}
// 	return strings.TrimSpace(d.LegacyName)
// }

// func (d *DatabaseConfig) GetConnectionString() string {
// 	port := d.Port
// 	if port == 0 {
// 		port = 5432
// 	}
// 	sslmode := d.SSLMode
// 	if sslmode == "" {
// 		sslmode = "require"
// 	}

// 	u := url.URL{
// 		Scheme:   "postgres",
// 		User:     url.UserPassword(d.User, d.Password),
// 		Host:     net.JoinHostPort(d.Host, strconv.Itoa(port)),
// 		Path:     "/" + d.DBName(),
// 		RawQuery: url.Values{"sslmode": []string{sslmode}}.Encode(),
// 	}
// 	return u.String()
// }

// type JWTConfig struct {
// 	Secret      string `yaml:"secret"`
// 	ExpiryHours int    `yaml:"expiry_hours"`
// }

// type CORSConfig struct {
// 	AllowedOrigins []string `yaml:"allowed_origins"`
// }

// func Load() (*Config, error) {
// 	data, err := os.ReadFile("configs/config.yaml")
// 	if err != nil {
// 		return nil, fmt.Errorf("read config: %w", err)
// 	}

// 	var cfg Config
// 	if err := yaml.Unmarshal(data, &cfg); err != nil {
// 		return nil, fmt.Errorf("parse config: %w", err)
// 	}

// 	return &cfg, nil
// }


















// package config

// import (
// 	"fmt"
// 	"net"
// 	"net/url"
// 	"os"
// 	"strconv"
// 	"strings"

// 	"gopkg.in/yaml.v3"
// )

// type Config struct {
// 	Server ServerConfig `yaml:"server"`

// 	// GlobalDatabase is the authentication / tenant-registry database
// 	// (users, tenants, accounts, user_settings). Its name comes ONLY from
// 	// config.yaml — nothing in the Go code hard-codes it.
// 	GlobalDatabase DatabaseConfig `yaml:"global_database"`

// 	// Database is the default DATA database (scan data: nhi_scans_aws, identities,
// 	// credentials ...). It is used when a tenant has no db_name of its own.
// 	// Every tenant that DOES have a db_name is opened dynamically (see
// 	// internal/database.Manager), reusing this section's host/credentials.
// 	Database DatabaseConfig `yaml:"database"`

// 	JWT  JWTConfig  `yaml:"jwt"`
// 	CORS CORSConfig `yaml:"cors"`
// }

// type ServerConfig struct {
// 	Port int    `yaml:"port"`
// 	Host string `yaml:"host"`
// }

// type DatabaseConfig struct {
// 	Host         string `yaml:"host"`
// 	Port         int    `yaml:"port"`
// 	DatabaseName string `yaml:"database_name"` // matches your config.yaml
// 	LegacyName   string `yaml:"name"`          // also accepted, in case an older config uses "name"
// 	User         string `yaml:"user"`
// 	Password     string `yaml:"password"`
// 	SSLMode      string `yaml:"sslmode"` // disable | require | verify-full ... (default: require)
// 	Schema       string `yaml:"schema"`  // optional PostgreSQL schema that holds the tables ("" = search_path default)
// }

// // DBName returns the configured PostgreSQL database name.
// func (d *DatabaseConfig) DBName() string {
// 	if n := strings.TrimSpace(d.DatabaseName); n != "" {
// 		return n
// 	}
// 	return strings.TrimSpace(d.LegacyName)
// }

// func (d *DatabaseConfig) GetConnectionString() string {
// 	port := d.Port
// 	if port == 0 {
// 		port = 5432
// 	}
// 	sslmode := d.SSLMode
// 	if sslmode == "" {
// 		sslmode = "require"
// 	}

// 	u := url.URL{
// 		Scheme:   "postgres",
// 		User:     url.UserPassword(d.User, d.Password),
// 		Host:     net.JoinHostPort(d.Host, strconv.Itoa(port)),
// 		Path:     "/" + d.DBName(),
// 		RawQuery: url.Values{"sslmode": []string{sslmode}}.Encode(),
// 	}
// 	return u.String()
// }

// type JWTConfig struct {
// 	Secret      string `yaml:"secret"`
// 	ExpiryHours int    `yaml:"expiry_hours"`
// }

// type CORSConfig struct {
// 	AllowedOrigins []string `yaml:"allowed_origins"`
// }

// func Load() (*Config, error) {
// 	data, err := os.ReadFile("configs/config.yaml")
// 	if err != nil {
// 		return nil, fmt.Errorf("read config: %w", err)
// 	}

// 	var cfg Config
// 	if err := yaml.Unmarshal(data, &cfg); err != nil {
// 		return nil, fmt.Errorf("parse config: %w", err)
// 	}

// 	cfg.applyDefaults()
// 	if err := cfg.validate(); err != nil {
// 		return nil, err
// 	}

// 	return &cfg, nil
// }

// // applyDefaults lets global_database inherit host/port/user/password/sslmode from
// // the data database block when they are left empty, so a single-server setup
// // only has to declare the credentials once.
// func (c *Config) applyDefaults() {
// 	g, d := &c.GlobalDatabase, &c.Database
// 	if strings.TrimSpace(g.Host) == "" {
// 		g.Host = d.Host
// 	}
// 	if g.Port == 0 {
// 		g.Port = d.Port
// 	}
// 	if strings.TrimSpace(g.User) == "" {
// 		g.User = d.User
// 		if g.Password == "" {
// 			g.Password = d.Password
// 		}
// 	}
// 	if strings.TrimSpace(g.SSLMode) == "" {
// 		g.SSLMode = d.SSLMode
// 	}
// }

// func (c *Config) validate() error {
// 	if c.GlobalDatabase.DBName() == "" {
// 		return fmt.Errorf("config: global_database.database_name is required (authentication database)")
// 	}
// 	if c.Database.DBName() == "" {
// 		return fmt.Errorf("config: database.database_name is required (default data database)")
// 	}
// 	if strings.TrimSpace(c.JWT.Secret) == "" {
// 		return fmt.Errorf("config: jwt.secret is required")
// 	}
// 	return nil
// }




















package config

import (
	"fmt"
	"net"
	"net/url"
	"os"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server ServerConfig `yaml:"server"`

	// GlobalDatabase is the authentication / tenant-registry database
	// (users, tenants, accounts, user_settings). It is the ONLY database name
	// that lives in config.yaml.
	GlobalDatabase DatabaseConfig `yaml:"global_database"`

	// Database holds the shared SERVER settings for tenant data databases
	// (host, port, user, password, sslmode, schema). It must NOT contain a
	// database_name: each tenant's database name comes from the tenants table
	// (db_name) and is opened dynamically by internal/database.Manager.
	Database DatabaseConfig `yaml:"database"`

	JWT  JWTConfig  `yaml:"jwt"`
	CORS CORSConfig `yaml:"cors"`
}

type ServerConfig struct {
	Port int    `yaml:"port"`
	Host string `yaml:"host"`
}

type DatabaseConfig struct {
	Host         string `yaml:"host"`
	Port         int    `yaml:"port"`
	DatabaseName string `yaml:"database_name"` // required for global_database only
	LegacyName   string `yaml:"name"`          // also accepted, in case an older config uses "name"
	User         string `yaml:"user"`
	Password     string `yaml:"password"`
	SSLMode      string `yaml:"sslmode"` // disable | require | verify-full ... (default: require)
	Schema       string `yaml:"schema"`  // optional PostgreSQL schema that holds the tables ("" = search_path default)
}

// DBName returns the configured PostgreSQL database name.
func (d *DatabaseConfig) DBName() string {
	if n := strings.TrimSpace(d.DatabaseName); n != "" {
		return n
	}
	return strings.TrimSpace(d.LegacyName)
}

func (d *DatabaseConfig) GetConnectionString() string {
	port := d.Port
	if port == 0 {
		port = 5432
	}
	sslmode := d.SSLMode
	if sslmode == "" {
		sslmode = "require"
	}

	u := url.URL{
		Scheme:   "postgres",
		User:     url.UserPassword(d.User, d.Password),
		Host:     net.JoinHostPort(d.Host, strconv.Itoa(port)),
		Path:     "/" + d.DBName(),
		RawQuery: url.Values{"sslmode": []string{sslmode}}.Encode(),
	}
	return u.String()
}

type JWTConfig struct {
	Secret      string `yaml:"secret"`
	ExpiryHours int    `yaml:"expiry_hours"`
}

type CORSConfig struct {
	AllowedOrigins []string `yaml:"allowed_origins"`
}

func Load() (*Config, error) {
	data, err := os.ReadFile("configs/config.yaml")
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}

	cfg.applyDefaults()
	if err := cfg.validate(); err != nil {
		return nil, err
	}

	return &cfg, nil
}

// applyDefaults lets global_database inherit host/port/user/password/sslmode from
// the database (server settings) block when they are left empty, so a
// single-server setup only has to declare the credentials once.
func (c *Config) applyDefaults() {
	g, d := &c.GlobalDatabase, &c.Database
	if strings.TrimSpace(g.Host) == "" {
		g.Host = d.Host
	}
	if g.Port == 0 {
		g.Port = d.Port
	}
	if strings.TrimSpace(g.User) == "" {
		g.User = d.User
		if g.Password == "" {
			g.Password = d.Password
		}
	}
	if strings.TrimSpace(g.SSLMode) == "" {
		g.SSLMode = d.SSLMode
	}
}

func (c *Config) validate() error {
	if c.GlobalDatabase.DBName() == "" {
		return fmt.Errorf("config: global_database.database_name is required (authentication database)")
	}
	if strings.TrimSpace(c.Database.Host) == "" {
		return fmt.Errorf("config: database.host is required (server that hosts the tenant data databases)")
	}
	if c.Database.DBName() != "" {
		return fmt.Errorf("config: remove database.database_name — tenant database names now come from the tenants table (db_name)")
	}
	if strings.TrimSpace(c.JWT.Secret) == "" {
		return fmt.Errorf("config: jwt.secret is required")
	}
	return nil
}