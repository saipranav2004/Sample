package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type OverprivilegeService struct {
	repo *repodashboard.OverprivilegeRepository
}

func NewOverprivilegeService(repo *repodashboard.OverprivilegeRepository) *OverprivilegeService {
	return &OverprivilegeService{repo: repo}
}

func (s *OverprivilegeService) Summary(ctx context.Context, filter repodashboard.OverprivilegeFilter) (*models.OverprivilegeResponse, error) {
	return s.repo.Summary(ctx, filter)
}
