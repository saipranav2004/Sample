package dashboard

import (
	"context"
	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type PermissionDistributionService struct {
	repo *repodashboard.PermissionDistributionRepository
}

func NewPermissionDistributionService(repo *repodashboard.PermissionDistributionRepository) *PermissionDistributionService {
	return &PermissionDistributionService{repo: repo}
}
func (s *PermissionDistributionService) Distribution(ctx context.Context, filter repodashboard.PermissionDistributionFilter) (*models.PermissionDistributionResponse, error) {
	return s.repo.Distribution(ctx, filter)
}
