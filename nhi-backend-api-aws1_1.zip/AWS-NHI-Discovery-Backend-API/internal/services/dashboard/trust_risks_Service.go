package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type TrustRisksService struct {
	repo *repodashboard.TrustRisksRepository
}

func NewTrustRisksService(repo *repodashboard.TrustRisksRepository) *TrustRisksService {
	return &TrustRisksService{repo: repo}
}

func (s *TrustRisksService) Summary(ctx context.Context, filter repodashboard.TrustRisksFilter) (*models.TrustRiskResponse, error) {
	return s.repo.Summary(ctx, filter)
}
