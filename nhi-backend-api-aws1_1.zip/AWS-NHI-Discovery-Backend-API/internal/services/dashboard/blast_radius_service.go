package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type BlastRadiusService struct {
	repo *repodashboard.BlastRadiusRepository
}

func NewBlastRadiusService(repo *repodashboard.BlastRadiusRepository) *BlastRadiusService {
	return &BlastRadiusService{repo: repo}
}

func (s *BlastRadiusService) Summary(ctx context.Context, filter repodashboard.BlastRadiusFilter) (*models.BlastRadiusResponse, error) {
	return s.repo.Summary(ctx, filter)
}
