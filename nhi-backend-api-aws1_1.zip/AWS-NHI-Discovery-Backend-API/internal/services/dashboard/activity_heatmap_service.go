package dashboard

import (
	"context"
	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type ActivityHeatmapService struct {
	repo *repodashboard.ActivityHeatmapRepository
}

func NewActivityHeatmapService(repo *repodashboard.ActivityHeatmapRepository) *ActivityHeatmapService {
	return &ActivityHeatmapService{repo: repo}
}
func (s *ActivityHeatmapService) Heatmap(ctx context.Context, filter repodashboard.ActivityHeatmapFilter) (*models.ActivityHeatmapResponse, error) {
	return s.repo.Heatmap(ctx, filter)
}
