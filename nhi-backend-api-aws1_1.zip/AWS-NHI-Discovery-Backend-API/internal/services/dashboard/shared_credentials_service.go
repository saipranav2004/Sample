package dashboard

import (
	"context"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
)

type SharedCredentialsService struct {
	repo *repodashboard.SharedCredentialsRepository
}

func NewSharedCredentialsService(repo *repodashboard.SharedCredentialsRepository) *SharedCredentialsService {
	return &SharedCredentialsService{repo: repo}
}

func (s *SharedCredentialsService) List(ctx context.Context, filter repodashboard.SharedCredentialsFilter) (*models.SharedCredentialsResponse, error) {
	return s.repo.List(ctx, filter)
}
