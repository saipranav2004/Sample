// package services

// import (
// 	"context"
// 	"errors"
// 	"fmt"

// 	"golang.org/x/crypto/bcrypt"

// 	"nhi-backend-api/internal/config"
// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// 	"nhi-backend-api/pkg/jwt"
// )

// type AuthService struct {
// 	userRepo *repository.UserRepository
// 	jwtCfg   config.JWTConfig
// }

// func NewAuthService(userRepo *repository.UserRepository, jwtCfg config.JWTConfig) *AuthService {
// 	return &AuthService{
// 		userRepo: userRepo,
// 		jwtCfg:   jwtCfg,
// 	}
// }

// // Login validates user credentials and issues a JWT token
// func (s *AuthService) Login(ctx context.Context, req models.LoginRequest) (*models.LoginResponse, error) {
// 	user, err := s.userRepo.GetByEmail(ctx, req.Email)
// 	if err != nil {
// 		return nil, fmt.Errorf("auth error: %w", err)
// 	}
// 	if user == nil {
// 		return nil, errors.New("please provide email and password")
// 	}

// 	// Verify hashed password
// 	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
// 		return nil, errors.New("invalid email or password")
// 	}

// 	// Generate JWT Token
// 	token, err := jwt.GenerateToken(
// 		user.ID,
// 		user.Email,
// 		user.Role,
// 		user.Team,
// 		s.jwtCfg.Secret,
// 		s.jwtCfg.ExpiryHours,
// 	)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to generate token: %w", err)
// 	}

// 	return &models.LoginResponse{
// 		Token:     token,
// 		User:      *user,
// 		ExpiresIn: s.jwtCfg.ExpiryHours * 3600,
// 	}, nil
// }

// // GetUserByID fetches profile details for /api/auth/me
// func (s *AuthService) GetUserByID(ctx context.Context, id int) (*models.User, error) {
// 	return s.userRepo.GetByID(ctx, id)
// }















// package services

// import (
// 	"context"
// 	"errors"
// 	"fmt"
// 	"strings"
// 	"sync"
// 	"time"

// 	"golang.org/x/crypto/bcrypt"

// 	"nhi-backend-api/internal/config"
// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/internal/repository"
// 	"nhi-backend-api/pkg/jwt"
// )

// // ErrAccountDisabled is returned when the user exists but is not "active".
// var ErrAccountDisabled = errors.New("account is not active")

// // statusEntry is one cached "is this user active?" answer.
// type statusEntry struct {
// 	active  bool
// 	expires time.Time
// }

// const statusCacheTTL = 30 * time.Second

// type AuthService struct {
// 	userRepo *repository.UserRepository
// 	jwtCfg   config.JWTConfig

// 	// defaultDataDB is used when a tenant row has no db_name (comes from config).
// 	defaultDataDB string

// 	// statusCache: userID -> statusEntry (avoids a DB hit on every request).
// 	statusCache sync.Map
// }

// func NewAuthService(userRepo *repository.UserRepository, jwtCfg config.JWTConfig, defaultDataDB string) *AuthService {
// 	return &AuthService{
// 		userRepo:      userRepo,
// 		jwtCfg:        jwtCfg,
// 		defaultDataDB: defaultDataDB,
// 	}
// }

// func isActiveStatus(status string) bool {
// 	return strings.EqualFold(strings.TrimSpace(status), "active")
// }

// // Login validates the user against the GLOBAL database and issues a JWT that
// // carries user_id, tenant_id and db_name (the tenant's data database).
// func (s *AuthService) Login(ctx context.Context, req models.LoginRequest) (*models.LoginResponse, error) {
// 	user, err := s.userRepo.GetByEmail(ctx, req.Email)
// 	if err != nil {
// 		return nil, fmt.Errorf("auth error: %w", err)
// 	}
// 	if user == nil {
// 		return nil, errors.New("invalid email or password")
// 	}

// 	// 1. Verify hashed password
// 	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
// 		return nil, errors.New("invalid email or password")
// 	}

// 	// 2. Only active users get a token (checked AFTER the password so the
// 	//    account status is not revealed to someone who doesn't know the password).
// 	if !isActiveStatus(user.Status) {
// 		return nil, ErrAccountDisabled
// 	}

// 	// 3. Which database holds this tenant's scan data? Tenant row first, config default second.
// 	if strings.TrimSpace(user.DBName) == "" {
// 		user.DBName = s.defaultDataDB
// 	}

// 	token, err := jwt.GenerateToken(
// 		user.ID,
// 		user.TenantID,
// 		user.DBName,
// 		user.Email,
// 		user.Role,
// 		s.jwtCfg.Secret,
// 		s.jwtCfg.ExpiryHours,
// 	)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to generate token: %w", err)
// 	}

// 	// The token was just issued, so remember that this user is active.
// 	s.statusCache.Store(user.ID, statusEntry{active: true, expires: time.Now().Add(statusCacheTTL)})

// 	return &models.LoginResponse{
// 		Token:     token,
// 		User:      *user,
// 		ExpiresIn: s.jwtCfg.ExpiryHours * 3600,
// 	}, nil
// }

// // IsActive reports whether the user may still use the API. The middleware
// // calls it on every request, so a suspended user's old token stops working.
// func (s *AuthService) IsActive(ctx context.Context, userID string) (bool, error) {
// 	if v, ok := s.statusCache.Load(userID); ok {
// 		if e := v.(statusEntry); time.Now().Before(e.expires) {
// 			return e.active, nil
// 		}
// 	}

// 	u, err := s.userRepo.GetByID(ctx, userID)
// 	if err != nil {
// 		return false, err
// 	}
// 	active := u != nil && isActiveStatus(u.Status)

// 	s.statusCache.Store(userID, statusEntry{active: active, expires: time.Now().Add(statusCacheTTL)})
// 	return active, nil
// }

// // GetUserByID fetches profile details for /api/auth/me
// func (s *AuthService) GetUserByID(ctx context.Context, id string) (*models.User, error) {
// 	return s.userRepo.GetByID(ctx, id)
// }























package services

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/bcrypt"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/pkg/jwt"
)

// ErrAccountDisabled is returned when the user exists but is not "active".
var ErrAccountDisabled = errors.New("account is not active")

// ErrTenantNotConfigured is returned when the user's tenant has no db_name.
var ErrTenantNotConfigured = errors.New("tenant database is not configured for this account")

// statusEntry is one cached "is this user active?" answer.
type statusEntry struct {
	active  bool
	expires time.Time
}

const statusCacheTTL = 30 * time.Second

type AuthService struct {
	userRepo *repository.UserRepository
	jwtCfg   config.JWTConfig

	// statusCache: userID -> statusEntry (avoids a DB hit on every request).
	statusCache sync.Map
}

func NewAuthService(userRepo *repository.UserRepository, jwtCfg config.JWTConfig) *AuthService {
	return &AuthService{
		userRepo: userRepo,
		jwtCfg:   jwtCfg,
	}
}

func isActiveStatus(status string) bool {
	return strings.EqualFold(strings.TrimSpace(status), "active")
}

// Login validates the user against the GLOBAL database and issues a JWT that
// carries user_id, tenant_id and db_name (the tenant's data database).
func (s *AuthService) Login(ctx context.Context, req models.LoginRequest) (*models.LoginResponse, error) {
	user, err := s.userRepo.GetByEmail(ctx, req.Email)
	if err != nil {
		return nil, fmt.Errorf("auth error: %w", err)
	}
	if user == nil {
		return nil, errors.New("invalid email or password")
	}

	// 1. Verify hashed password
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return nil, errors.New("invalid email or password")
	}

	// 2. Only active users get a token (checked AFTER the password so the
	//    account status is not revealed to someone who doesn't know the password).
	if !isActiveStatus(user.Status) {
		return nil, ErrAccountDisabled
	}

	// 3. The tenant's data database comes ONLY from the tenants table.
	//    No db_name means the tenant is not set up — refuse instead of guessing.
	user.DBName = strings.TrimSpace(user.DBName)
	if user.DBName == "" {
		return nil, ErrTenantNotConfigured
	}

	token, err := jwt.GenerateToken(
		user.ID,
		user.TenantID,
		user.DBName,
		user.Email,
		user.Role,
		s.jwtCfg.Secret,
		s.jwtCfg.ExpiryHours,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to generate token: %w", err)
	}

	// The token was just issued, so remember that this user is active.
	s.statusCache.Store(user.ID, statusEntry{active: true, expires: time.Now().Add(statusCacheTTL)})

	return &models.LoginResponse{
		Token:     token,
		User:      *user,
		ExpiresIn: s.jwtCfg.ExpiryHours * 3600,
	}, nil
}

// IsActive reports whether the user may still use the API. The middleware
// calls it on every request, so a suspended user's old token stops working.
func (s *AuthService) IsActive(ctx context.Context, userID string) (bool, error) {
	if v, ok := s.statusCache.Load(userID); ok {
		if e := v.(statusEntry); time.Now().Before(e.expires) {
			return e.active, nil
		}
	}

	u, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return false, err
	}
	active := u != nil && isActiveStatus(u.Status)

	s.statusCache.Store(userID, statusEntry{active: active, expires: time.Now().Add(statusCacheTTL)})
	return active, nil
}

// GetUserByID fetches profile details for /api/auth/me
func (s *AuthService) GetUserByID(ctx context.Context, id string) (*models.User, error) {
	return s.userRepo.GetByID(ctx, id)
}