// package services

// import (
// 	"context"
// 	"time"

// 	"nhi-backend-api/internal/models"
// 	repository "nhi-backend-api/internal/repository/postures"
// )

// type CategoryService struct {
// 	repo *repository.CategoryRepository
// }

// func NewCategoryService(repo *repository.CategoryRepository) *CategoryService {
// 	return &CategoryService{repo: repo}
// }

// func scoreStatus(score float64) string {
// 	switch {
// 	case score >= 90:
// 		return "pass"
// 	case score >= 60:
// 		return "warn"
// 	default:
// 		return "fail"
// 	}
// }

// // GetAll — scanID empty means "latest completed scan" (same convention as dashboard service).
// func (s *CategoryService) GetAll(ctx context.Context, scanID string) (*models.CategoryResponse, error) {
// 	rows, err := s.repo.GetAll(ctx, scanID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	resp := &models.CategoryResponse{
// 		GeneratedAt: time.Now().UTC().Format(time.RFC3339),
// 		Categories:  make([]models.Category, 0, len(rows)),
// 	}

// 	for i, r := range rows {
// 		if i == 0 {
// 			resp.TotalIdentities = r.TotalIdentities
// 		}
// 		desc := ""
// 		if r.Description.Valid {
// 			desc = r.Description.String
// 		}
// 		resp.Categories = append(resp.Categories, models.Category{
// 			CategoryCode:   r.CategoryCode,
// 			Name:           r.CategoryName,
// 			Description:    desc,
// 			Weight:         r.Weight,
// 			Score:          r.Score,
// 			TotalEvaluated: r.TotalIdentities,
// 			TotalFailing:   r.TotalFailing,
// 			Status:         scoreStatus(r.Score),
// 		})
// 	}
// 	return resp, nil
// }






















package services

import (
	"context"
	"fmt"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
	modelpostures "nhi-backend-api/internal/models/postures"
	reponewapi "nhi-backend-api/internal/repository/new_api"
	repopostures "nhi-backend-api/internal/repository/postures"
)

type CategoryService struct {
	dbm   *database.Manager
	repo  *repopostures.CategoryRepository
	scans *reponewapi.ScanRepository // the same scan repo the other new_api services use
}

// NewCategoryService takes the DB manager (to open the tenant database named
// in the JWT), the postures repository, and the shared scan repository.
func NewCategoryService(
	dbm *database.Manager,
	repo *repopostures.CategoryRepository,
	scans *reponewapi.ScanRepository,
) *CategoryService {
	return &CategoryService{dbm: dbm, repo: repo, scans: scans}
}

func scoreStatus(score float64) string {
	switch {
	case score >= 90:
		return "pass"
	case score >= 60:
		return "warn"
	default:
		return "fail"
	}
}

// GetAll scores the categories of the caller's tenant.
//
//	dbName : db_name claim from the verified JWT (never from the request)
//	scanID : optional ?scan_id=; empty means "latest COMPLETED scan"
func (s *CategoryService) GetAll(ctx context.Context, dbName, scanID string) (*modelpostures.CategoryResponse, error) {
	tenantDB, err := s.dbm.Tenant(dbName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	resp := &modelpostures.CategoryResponse{
		GeneratedAt: time.Now().UTC().Format(time.RFC3339),
		Categories:  []modelpostures.Category{},
	}

	scanID = strings.TrimSpace(scanID)
	if scanID == "" {
		latest, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
		if err != nil {
			return nil, err
		}
		if latest == nil {
			// No completed scan yet: nothing to score.
			return resp, nil
		}
		scanID = latest.ScanID
	}

	rows, err := s.repo.GetAll(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}

	resp.Categories = make([]modelpostures.Category, 0, len(rows))
	for i, r := range rows {
		if i == 0 {
			resp.TotalIdentities = r.TotalIdentities
		}
		desc := ""
		if r.Description.Valid {
			desc = r.Description.String
		}
		resp.Categories = append(resp.Categories, modelpostures.Category{
			CategoryCode:   r.CategoryCode,
			Name:           r.CategoryName,
			Description:    desc,
			Weight:         r.Weight,
			Score:          r.Score,
			TotalEvaluated: r.TotalIdentities,
			TotalFailing:   r.TotalFailing,
			Status:         scoreStatus(r.Score),
		})
	}
	return resp, nil
}
