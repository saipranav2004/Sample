package inventory

import (
	"context"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityBlastRadiusService struct {
	repo *repoinventory.IdentityBlastRadiusRepository
}

func NewIdentityBlastRadiusService(repo *repoinventory.IdentityBlastRadiusRepository) *IdentityBlastRadiusService {
	return &IdentityBlastRadiusService{repo: repo}
}

func (s *IdentityBlastRadiusService) GetBlastRadius(
	ctx context.Context,
	f repoinventory.IdentityBlastRadiusFilter,
) (*inventorymodels.IdentityBlastRadiusResponse, error) {
	return s.repo.GetBlastRadius(ctx, f)
}
