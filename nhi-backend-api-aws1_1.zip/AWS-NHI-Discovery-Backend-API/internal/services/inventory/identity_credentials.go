package inventory

import (
	"context"

	modelsinventory "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityCredentialsService struct {
	repo *repoinventory.IdentityCredentialsRepository
}

func NewIdentityCredentialsService(repo *repoinventory.IdentityCredentialsRepository) *IdentityCredentialsService {
	return &IdentityCredentialsService{repo: repo}
}

func (s *IdentityCredentialsService) GetByIdentityID(
	ctx context.Context,
	identityID string, allowedAccounts []string, accountID string,
) (*modelsinventory.IdentityCredentialsResponse, error) {
	return s.repo.GetByIdentityID(ctx, identityID, allowedAccounts, accountID)
}