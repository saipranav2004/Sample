package inventory

import (
	"context"

	inventorymodels "nhi-backend-api/internal/models/inventory"
	repoinventory "nhi-backend-api/internal/repository/inventory"
)

type IdentityActivityService struct {
	repo *repoinventory.IdentityActivityRepository
}

func NewIdentityActivityService(repo *repoinventory.IdentityActivityRepository) *IdentityActivityService {
	return &IdentityActivityService{repo: repo}
}

func (s *IdentityActivityService) GetActivity(
	ctx context.Context,
	f repoinventory.IdentityActivityFilter,
) (*inventorymodels.IdentityActivityResponse, error) {
	return s.repo.GetActivity(ctx, f)
}
