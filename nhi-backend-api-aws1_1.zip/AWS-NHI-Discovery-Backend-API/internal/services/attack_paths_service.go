package services

import (
	"context"

	"nhi-backend-api/internal/models"
	repo "nhi-backend-api/internal/repository"
)

type AttackPathsService struct {
	repo *repo.AttackPathsRepository
}

func NewAttackPathsService(repo *repo.AttackPathsRepository) *AttackPathsService {
	return &AttackPathsService{repo: repo}
}

func (s *AttackPathsService) Find(ctx context.Context, filter repo.AttackPathsFilter) (*models.AttackPathsResponse, error) {
	return s.repo.Find(ctx, filter)
}
