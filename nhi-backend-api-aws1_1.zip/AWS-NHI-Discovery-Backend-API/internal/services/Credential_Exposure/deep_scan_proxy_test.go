package credentialexposure

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"

	m "nhi-backend-api/internal/models/Credential_Exposure"
)

func TestDeepScanProxyPreservesScannerClientErrorStatuses(t *testing.T) {
	for _, status := range []int{http.StatusBadRequest, http.StatusNotFound} {
		t.Run(http.StatusText(status), func(t *testing.T) {
			server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Method != http.MethodPost || r.URL.Path != "/api/deep-scan" {
					t.Errorf("unexpected scanner request: %s %s", r.Method, r.URL.Path)
				}
				if status == http.StatusBadRequest {
					w.Header().Set("Content-Type", "application/json")
				}
				w.WriteHeader(status)
				body := `{"error":"scanner rejection"}`
				if status == http.StatusNotFound {
					body = "unknown client"
				}
				_, _ = io.WriteString(w, body)
			}))
			defer server.Close()

			svc := NewDeepScanService(nil, server.URL, "test-key")
			svc.client = server.Client()
			gotStatus, body, err := svc.Trigger(context.Background(), m.DeepScanRequest{ClientID: "client", Repository: "repo"})
			if err != nil {
				t.Fatalf("Trigger() error = %v", err)
			}
			if gotStatus != status {
				t.Fatalf("Trigger() status = %d, want %d", gotStatus, status)
			}
			wantBody := `{"error":"scanner rejection"}`
			if status == http.StatusNotFound {
				wantBody = "unknown client"
			}
			if string(body) != wantBody {
				t.Fatalf("Trigger() body = %q, want %q", body, wantBody)
			}
		})
	}
}
