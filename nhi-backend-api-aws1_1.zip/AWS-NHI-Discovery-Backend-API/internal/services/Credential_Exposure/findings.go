package credentialexposure

import (
	"context"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/Credential_Exposure"
	r "nhi-backend-api/internal/repository/Credential_Exposure"
)

type FindingsService struct{ repo *r.FindingsRepository }

func NewFindingsService(repo *r.FindingsRepository) *FindingsService {
	return &FindingsService{repo: repo}
}

func (s *FindingsService) List(ctx context.Context, filter m.FindingsFilter) ([]m.Finding, int, error) {
	filter.Platform = strings.ToLower(strings.TrimSpace(filter.Platform))
	if filter.Platform != "" && filter.Platform != "github" && filter.Platform != "codecommit" {
		return nil, 0, fmt.Errorf("platform must be codecommit or github")
	}
	if filter.Limit < 1 || filter.Limit > 500 {
		return nil, 0, fmt.Errorf("limit must be between 1 and 500")
	}
	if filter.Offset < 0 {
		return nil, 0, fmt.Errorf("offset cannot be negative")
	}
	return s.repo.List(ctx, filter)
}
func (s *FindingsService) Get(ctx context.Context, id string) (*m.Finding, error) {
	return s.repo.GetByID(ctx, id)
}

func (s *FindingsService) Summary(ctx context.Context, filter m.FindingsSummaryFilter) (m.FindingsSummary, error) {
	filter.ClientID = strings.TrimSpace(filter.ClientID)
	filter.Platform = strings.ToLower(strings.TrimSpace(filter.Platform))
	if filter.Platform != "" && filter.Platform != "github" && filter.Platform != "codecommit" {
		return m.FindingsSummary{}, fmt.Errorf("platform must be codecommit or github")
	}
	if len(filter.ClientID) > 200 {
		return m.FindingsSummary{}, fmt.Errorf("client_id exceeds 200 characters")
	}
	return s.repo.Summary(ctx, filter)
}
