package services

import (
	"context"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
)

type UnusedPermissionsService struct {
	repo *repository.UnusedPermissionsRepository
}

func NewUnusedPermissionsService(repo *repository.UnusedPermissionsRepository) *UnusedPermissionsService {
	return &UnusedPermissionsService{repo: repo}
}

func (s *UnusedPermissionsService) Summary(ctx context.Context, filter repository.UnusedPermissionsFilter) (*models.UnusedPermissionsResponse, error) {
	return s.repo.Summary(ctx, filter)
}
