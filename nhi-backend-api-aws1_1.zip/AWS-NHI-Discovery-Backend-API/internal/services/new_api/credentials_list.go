package newapi

import (
	"context"
	"database/sql"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

// CredentialsListValidationError is a client mistake (HTTP 400).
type CredentialsListValidationError struct{ Msg string }

func (e *CredentialsListValidationError) Error() string { return e.Msg }

// CredentialsListParams holds the raw, unvalidated query string values.
type CredentialsListParams struct {
	Page               string
	PageSize           string
	Search             string
	CredentialType     string // comma-separated
	Status             string // comma-separated
	OwnerPrincipalARN  string
	RotationEnabled    string
	RotationOverdue    string
	IsOrphaned         string
	HasExternalTrust   string
	MinIdleDays        string
	MaxDaysUntilExpiry string
	SortBy             string
	SortOrder          string
}

type CredentialsListService struct {
	dbm   *database.Manager
	repo  *reponewapi.CredentialsListRepository
	scans *reponewapi.ScanRepository
}

func NewCredentialsListService(dbm *database.Manager, repo *reponewapi.CredentialsListRepository, scans *reponewapi.ScanRepository) *CredentialsListService {
	return &CredentialsListService{dbm: dbm, repo: repo, scans: scans}
}

// ── local parsing helpers ────────────────────────────────────────────────
// Prefixed with "cl" to avoid redeclaring shared helpers that may already
// exist elsewhere in this package.

func clSplitCSV(s string) []string {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func clParseBool(field, s string) (*bool, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, nil
	}
	v, err := strconv.ParseBool(s)
	if err != nil {
		return nil, &CredentialsListValidationError{Msg: fmt.Sprintf("%s: must be true or false", field)}
	}
	return &v, nil
}

func clParseInt(field, s string) (*int, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, nil
	}
	v, err := strconv.Atoi(s)
	if err != nil {
		return nil, &CredentialsListValidationError{Msg: fmt.Sprintf("%s: must be an integer", field)}
	}
	return &v, nil
}

// ── null-conversion helpers ──────────────────────────────────────────────
// NOTE: nullStringPtr already exists in identity_detail.go — do not redeclare
// it here. timePtrRFC3339FromNull / nullInt64Ptr are new for this endpoint
// (sql.NullTime / sql.NullInt64 based).

func timePtrRFC3339FromNull(t sql.NullTime) *string {
	if !t.Valid {
		return nil
	}
	s := t.Time.UTC().Format(time.RFC3339)
	return &s
}

func nullInt64Ptr(n sql.NullInt64) *int {
	if !n.Valid {
		return nil
	}
	v := int(n.Int64)
	return &v
}

// List implements Endpoint 6: Credentials List.
func (s *CredentialsListService) List(ctx context.Context, id Identity, p CredentialsListParams) (*modelnewapi.CredentialsListResponse, error) {
	page := 1
	if v := strings.TrimSpace(p.Page); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 {
			return nil, &CredentialsListValidationError{Msg: "page: must be a positive integer"}
		}
		page = n
	}

	pageSize := 25
	if v := strings.TrimSpace(p.PageSize); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 500 {
			return nil, &CredentialsListValidationError{Msg: "page_size: must be between 1 and 500"}
		}
		pageSize = n
	}

	sortBy := strings.TrimSpace(p.SortBy)
	if sortBy == "" {
		sortBy = "last_used_at"
	}
	sortCol, ok := reponewapi.CredentialsListSortColumnAllowed[sortBy]
	if !ok {
		return nil, &CredentialsListValidationError{Msg: fmt.Sprintf("sort_by: invalid value %q", sortBy)}
	}

	sortOrder := strings.ToLower(strings.TrimSpace(p.SortOrder))
	if sortOrder == "" {
		sortOrder = "desc"
	}
	if sortOrder != "asc" && sortOrder != "desc" {
		return nil, &CredentialsListValidationError{Msg: "sort_order: must be asc or desc"}
	}

	rotationEnabled, err := clParseBool("rotation_enabled", p.RotationEnabled)
	if err != nil {
		return nil, err
	}
	rotationOverdue, err := clParseBool("rotation_overdue", p.RotationOverdue)
	if err != nil {
		return nil, err
	}
	isOrphaned, err := clParseBool("is_orphaned", p.IsOrphaned)
	if err != nil {
		return nil, err
	}
	hasExternalTrust, err := clParseBool("has_external_trust", p.HasExternalTrust)
	if err != nil {
		return nil, err
	}
	minIdleDays, err := clParseInt("min_idle_days", p.MinIdleDays)
	if err != nil {
		return nil, err
	}
	maxDaysUntilExpiry, err := clParseInt("max_days_until_expiry", p.MaxDaysUntilExpiry)
	if err != nil {
		return nil, err
	}

	filters := reponewapi.CredentialsListFilters{
		Search:             strings.TrimSpace(p.Search),
		CredentialTypes:    clSplitCSV(p.CredentialType),
		Statuses:           clSplitCSV(p.Status),
		OwnerPrincipalARN:  strings.TrimSpace(p.OwnerPrincipalARN),
		RotationEnabled:    rotationEnabled,
		RotationOverdue:    rotationOverdue,
		IsOrphaned:         isOrphaned,
		HasExternalTrust:   hasExternalTrust,
		MinIdleDays:        minIdleDays,
		MaxDaysUntilExpiry: maxDaysUntilExpiry,
	}

	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	// Scope to the latest COMPLETED scan. Without this, credentials from
	// every historical scan run accumulate (e.g. 73 scans worth), massively
	// over-counting (8445 instead of the real 37). No completed scan yet →
	// empty result, not an error — same convention as other list endpoints.
	latestScan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
	if err != nil {
		return nil, fmt.Errorf("resolve latest completed scan: %w", err)
	}
	if latestScan == nil {
		return &modelnewapi.CredentialsListResponse{
			Pagination: modelnewapi.CredentialsPagination{
				Page:       page,
				PageSize:   pageSize,
				TotalCount: 0,
				TotalPages: 0,
			},
			Data: []modelnewapi.CredentialListItem{},
		}, nil
	}
	filters.ScanID = latestScan.ScanID

	total, err := s.repo.Count(ctx, tenantDB, filters)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.CredentialsListResponse{
		Pagination: modelnewapi.CredentialsPagination{
			Page:       page,
			PageSize:   pageSize,
			TotalCount: total,
			TotalPages: int(math.Ceil(float64(total) / float64(pageSize))),
		},
		Data: []modelnewapi.CredentialListItem{},
	}
	if total == 0 {
		return resp, nil
	}

	offset := (page - 1) * pageSize
	rows, err := s.repo.List(ctx, tenantDB, filters, sortCol, sortOrder, pageSize, offset)
	if err != nil {
		return nil, err
	}

	for _, r := range rows {
		item := modelnewapi.CredentialListItem{
			ID:                    r.ID,
			Name:                  r.Name,
			ARN:                   r.ARN,
			CredentialType:        r.CredentialType,
			AccountID:             r.AccountID,
			Region:                r.Region,
			Status:                r.Status,
			OwnerPrincipalARN:     nullStringPtr(r.OwnerPrincipalARN),
			BoundIdentitiesCount:  r.BoundIdentitiesCount,
			IsOrphaned:            r.IsOrphaned,
			LastUsedAt:            timePtrRFC3339FromNull(r.LastUsedAt),
			LastRotatedAt:         timePtrRFC3339FromNull(r.LastRotatedAt),
			RotationEnabled:       r.RotationEnabled,
			RotationOverdue:       r.RotationOverdue,
			AgeDays:               r.AgeDays,
			IdleDays:              nullInt64Ptr(r.IdleDays),
			ExpiresAt:             timePtrRFC3339FromNull(r.ExpiresAt),
			DaysUntilExpiry:       nullInt64Ptr(r.DaysUntilExpiry),
			HasExternalTrust:      r.HasExternalTrust,
			PermissionBoundaryARN: nullStringPtr(r.PermissionBoundaryARN),
		}
		resp.Data = append(resp.Data, item)
	}

	return resp, nil
}