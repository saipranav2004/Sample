// package newapi

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"fmt"
// 	"regexp"
// 	"sort"
// 	"strconv"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/database"
// 	modelnewapi "nhi-backend-api/internal/models/new_api"
// 	reponewapi "nhi-backend-api/internal/repository/new_api"
// )

// // CredentialDetailValidationError is a client mistake (HTTP 400).
// type CredentialDetailValidationError struct{ Msg string }

// func (e *CredentialDetailValidationError) Error() string { return e.Msg }

// // CredentialDetailNotFoundError covers "no completed scan yet" and
// // "credential id not found within the latest completed scan".
// type CredentialDetailNotFoundError struct{ Msg string }

// func (e *CredentialDetailNotFoundError) Error() string { return e.Msg }

// // CredentialDetailParams holds the raw, unvalidated query string values.
// type CredentialDetailParams struct {
// 	Tab       string
// 	TimeRange string
// 	Depth     string
// 	EdgeType  string
// }

// var credValidTabs = map[string]bool{
// 	"overview":      true,
// 	"trust":         true,
// 	"activity":      true,
// 	"rotation":      true,
// 	"relationships": true,
// 	"raw":           true,
// }

// type CredentialDetailService struct {
// 	dbm   *database.Manager
// 	repo  *reponewapi.CredentialDetailRepository
// 	scans *reponewapi.ScanRepository
// }

// func NewCredentialDetailService(dbm *database.Manager, repo *reponewapi.CredentialDetailRepository, scans *reponewapi.ScanRepository) *CredentialDetailService {
// 	return &CredentialDetailService{dbm: dbm, repo: repo, scans: scans}
// }

// var credUUIDRe = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// // Get implements Endpoint 7: Credential Detail.
// func (s *CredentialDetailService) Get(ctx context.Context, id Identity, credentialID string, p CredentialDetailParams) (interface{}, error) {
// 	credentialID = strings.TrimSpace(credentialID)
// 	if !credUUIDRe.MatchString(credentialID) {
// 		return nil, &CredentialDetailValidationError{Msg: "id: must be a valid UUID"}
// 	}

// 	tab := strings.ToLower(strings.TrimSpace(p.Tab))
// 	if tab == "" {
// 		tab = "overview"
// 	}
// 	if !credValidTabs[tab] {
// 		return nil, &CredentialDetailValidationError{Msg: fmt.Sprintf("tab: invalid value %q", tab)}
// 	}

// 	timeRange := strings.TrimSpace(p.TimeRange)
// 	if timeRange == "" {
// 		timeRange = "90d"
// 	}

// 	depth := 1
// 	if v := strings.TrimSpace(p.Depth); v != "" {
// 		n, err := strconv.Atoi(v)
// 		if err != nil || n < 1 || n > 3 {
// 			return nil, &CredentialDetailValidationError{Msg: "depth: must be 1, 2 or 3"}
// 		}
// 		depth = n
// 	}
// 	edgeType := strings.TrimSpace(p.EdgeType)

// 	tenantDB, err := s.dbm.Tenant(id.DBName)
// 	if err != nil {
// 		return nil, fmt.Errorf("resolve tenant database: %w", err)
// 	}

// 	latestScan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
// 	if err != nil {
// 		return nil, fmt.Errorf("resolve latest completed scan: %w", err)
// 	}
// 	if latestScan == nil {
// 		return nil, &CredentialDetailNotFoundError{Msg: "no completed scan available yet"}
// 	}

// 	core, err := s.repo.GetCore(ctx, tenantDB, credentialID, latestScan.ScanID)
// 	if err != nil {
// 		return nil, err
// 	}
// 	if core == nil {
// 		return nil, &CredentialDetailNotFoundError{Msg: fmt.Sprintf("credential %q not found in the latest completed scan", credentialID)}
// 	}

// 	switch tab {
// 	case "overview":
// 		return s.buildOverview(ctx, tenantDB, core)
// 	case "trust":
// 		return s.buildTrust(ctx, tenantDB, core)
// 	case "activity":
// 		return s.buildActivity(ctx, tenantDB, core, timeRange)
// 	case "rotation":
// 		return s.buildRotation(core), nil
// 	case "relationships":
// 		return s.buildRelationships(ctx, tenantDB, core, depth, edgeType)
// 	case "raw":
// 		return s.buildRaw(ctx, tenantDB, core)
// 	default:
// 		return nil, &CredentialDetailValidationError{Msg: fmt.Sprintf("tab: invalid value %q", tab)}
// 	}
// }

// // ── small local helpers (prefixed cred* to avoid collisions) ─────────────

// func nullStringOrEmpty(s sql.NullString) string {
// 	if !s.Valid {
// 		return ""
// 	}
// 	return s.String
// }

// func credDecodeJSON(raw []byte) interface{} {
// 	if len(raw) == 0 {
// 		return nil
// 	}
// 	var v interface{}
// 	if err := json.Unmarshal(raw, &v); err != nil {
// 		return nil
// 	}
// 	return v
// }

// func credAgeDays(createdAtAWS, firstSeenAt sql.NullTime) *int {
// 	ref := createdAtAWS
// 	if !ref.Valid {
// 		ref = firstSeenAt
// 	}
// 	if !ref.Valid {
// 		return nil
// 	}
// 	d := int(time.Since(ref.Time).Hours() / 24)
// 	return &d
// }

// func credIdleDays(lastUsedAt sql.NullTime) *int {
// 	if !lastUsedAt.Valid {
// 		return nil
// 	}
// 	d := int(time.Since(lastUsedAt.Time).Hours() / 24)
// 	return &d
// }

// func credDaysSinceRotation(lastRotatedAt, createdAtAWS sql.NullTime) *int {
// 	ref := lastRotatedAt
// 	if !ref.Valid {
// 		ref = createdAtAWS
// 	}
// 	if !ref.Valid {
// 		return nil
// 	}
// 	d := int(time.Since(ref.Time).Hours() / 24)
// 	return &d
// }

// func credDaysUntilExpiry(expiresAt sql.NullTime) *int {
// 	if !expiresAt.Valid {
// 		return nil
// 	}
// 	d := int(time.Until(expiresAt.Time).Hours() / 24)
// 	return &d
// }

// func credRotationOverdue(c *reponewapi.CredentialCoreRow) bool {
// 	if !c.RotationEnabled || !c.RotationIntervalDays.Valid {
// 		return false
// 	}
// 	ref := c.LastRotatedAt
// 	if !ref.Valid {
// 		ref = c.CreatedAtAWS
// 	}
// 	if !ref.Valid {
// 		return false
// 	}
// 	return time.Now().After(ref.Time.AddDate(0, 0, int(c.RotationIntervalDays.Int64)))
// }

// func credRotationStatusLabel(enabled, overdue bool) string {
// 	if !enabled {
// 		return "Disabled"
// 	}
// 	if overdue {
// 		return "Overdue"
// 	}
// 	return "Enabled"
// }

// // credDeriveCategory is a presentation-layer heuristic — there is no stored
// // "category" column for credentials in this schema.
// func credDeriveCategory(credentialType string) string {
// 	switch strings.ToLower(strings.TrimSpace(credentialType)) {
// 	case "iam_role", "iam_user", "iam_group", "access_key", "iam_policy":
// 		return "IAM"
// 	case "secret", "secrets_manager_secret", "secretsmanager_secret":
// 		return "Secrets Manager"
// 	case "kms_key", "kms":
// 		return "KMS"
// 	case "service_account", "service_account_key":
// 		return "Service Account"
// 	case "instance_profile":
// 		return "Compute"
// 	case "":
// 		return "Unknown"
// 	default:
// 		return strings.ToUpper(credentialType[:1]) + credentialType[1:]
// 	}
// }

// // ── trust policy parsing ──────────────────────────────────────────────

// type credTrustStatement struct {
// 	Effect         string // "allow" | "deny", lowercased
// 	PrincipalType  string // "AWS", "Service", "Federated", "*"
// 	PrincipalValue string
// 	HasCondition   bool
// 	ConditionDesc  string
// }

// func credParseTrustStatements(trustPolicy []byte) []credTrustStatement {
// 	if len(trustPolicy) == 0 {
// 		return nil
// 	}
// 	var doc struct {
// 		Statement json.RawMessage `json:"Statement"`
// 	}
// 	if err := json.Unmarshal(trustPolicy, &doc); err != nil || len(doc.Statement) == 0 {
// 		return nil
// 	}

// 	var stmts []map[string]interface{}
// 	if err := json.Unmarshal(doc.Statement, &stmts); err != nil {
// 		var single map[string]interface{}
// 		if err := json.Unmarshal(doc.Statement, &single); err == nil {
// 			stmts = []map[string]interface{}{single}
// 		}
// 	}

// 	out := make([]credTrustStatement, 0, len(stmts))
// 	for _, st := range stmts {
// 		cs := credTrustStatement{}
// 		if eff, ok := st["Effect"].(string); ok {
// 			cs.Effect = strings.ToLower(eff)
// 		}
// 		if cond, ok := st["Condition"]; ok {
// 			cs.HasCondition = true
// 			if b, err := json.Marshal(cond); err == nil {
// 				cs.ConditionDesc = string(b)
// 			}
// 		}
// 		switch p := st["Principal"].(type) {
// 		case string:
// 			cs.PrincipalType = "*"
// 			cs.PrincipalValue = p
// 		case map[string]interface{}:
// 			for k, v := range p {
// 				cs.PrincipalType = k
// 				switch vv := v.(type) {
// 				case string:
// 					cs.PrincipalValue = vv
// 				case []interface{}:
// 					var parts []string
// 					for _, item := range vv {
// 						if sv, ok := item.(string); ok {
// 							parts = append(parts, sv)
// 						}
// 					}
// 					cs.PrincipalValue = strings.Join(parts, ",")
// 				}
// 				break
// 			}
// 		}
// 		out = append(out, cs)
// 	}
// 	return out
// }

// var credArnAccountRe = regexp.MustCompile(`arn:aws[a-z0-9-]*:[a-z0-9-]+:[a-z0-9-]*:(\d{12}):`)

// func credArnAccountID(arn string) string {
// 	m := credArnAccountRe.FindStringSubmatch(arn)
// 	if m == nil {
// 		return ""
// 	}
// 	return m[1]
// }

// func credComputeTrustPrincipalsAndWarnings(statements []credTrustStatement, accountID string) ([]modelnewapi.CredTrustPrincipal, []string) {
// 	principals := make([]modelnewapi.CredTrustPrincipal, 0, len(statements))
// 	var warnings []string
// 	for _, st := range statements {
// 		if st.PrincipalValue == "" {
// 			continue
// 		}
// 		var cond *string
// 		if st.HasCondition {
// 			c := st.ConditionDesc
// 			cond = &c
// 		}
// 		isExternal := false
// 		if st.Effect == "allow" && st.PrincipalType == "AWS" {
// 			for _, part := range strings.Split(st.PrincipalValue, ",") {
// 				acct := credArnAccountID(strings.TrimSpace(part))
// 				if acct != "" && accountID != "" && acct != accountID {
// 					isExternal = true
// 				}
// 			}
// 		}
// 		principals = append(principals, modelnewapi.CredTrustPrincipal{
// 			Principal:  st.PrincipalValue,
// 			Type:       st.PrincipalType,
// 			Condition:  cond,
// 			IsExternal: isExternal,
// 		})
// 		if st.Effect == "allow" {
// 			if st.PrincipalValue == "*" {
// 				warnings = append(warnings, "Trust policy allows a wildcard principal (*)")
// 			}
// 			if isExternal {
// 				warnings = append(warnings, fmt.Sprintf("Cross-account trust granted to principal '%s'", st.PrincipalValue))
// 			}
// 			if !st.HasCondition && st.PrincipalType == "AWS" {
// 				warnings = append(warnings, fmt.Sprintf("No condition restricts assumption by '%s'", st.PrincipalValue))
// 			}
// 		}
// 	}
// 	if warnings == nil {
// 		warnings = []string{}
// 	}
// 	return principals, warnings
// }

// func credBuildRiskSignals(c *reponewapi.CredentialCoreRow, boundCount int, hasExternal, hasWildcard, noCondition bool) []modelnewapi.CredRiskSignal {
// 	expired := c.ExpiresAt.Valid && c.ExpiresAt.Time.Before(time.Now())
// 	expSoon := false
// 	if c.ExpiresAt.Valid && !expired {
// 		if d := credDaysUntilExpiry(c.ExpiresAt); d != nil && *d <= 30 {
// 			expSoon = true
// 		}
// 	}
// 	idle := credIdleDays(c.LastUsedAt)
// 	stale := idle != nil && *idle > 90

// 	return []modelnewapi.CredRiskSignal{
// 		{Signal: "Orphaned (no identity bound)", Status: boundCount == 0, Severity: "high"},
// 		{Signal: "Overshared (3+ identities)", Status: boundCount >= 3, Severity: "medium"},
// 		{Signal: "Never rotated", Status: !c.LastRotatedAt.Valid, Severity: "high"},
// 		{Signal: "Rotation overdue", Status: credRotationOverdue(c), Severity: "high"},
// 		{Signal: "Expiring soon (< 30 days)", Status: expSoon, Severity: "high"},
// 		{Signal: "Already expired", Status: expired, Severity: "critical"},
// 		{Signal: "Stale (unused > 90 days)", Status: stale, Severity: "high"},
// 		{Signal: "External trust (cross-account)", Status: hasExternal, Severity: "medium"},
// 		{Signal: "Wildcard trust (Principal: *)", Status: hasWildcard, Severity: "critical"},
// 		{Signal: "No condition on trust policy", Status: noCondition, Severity: "high"},
// 		{Signal: "No permission boundary", Status: !c.PermissionBoundaryARN.Valid || c.PermissionBoundaryARN.String == "", Severity: "medium"},
// 	}
// }

// // ── tab=overview ──────────────────────────────────────────────────────

// func (s *CredentialDetailService) buildOverview(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialOverviewResponse, error) {
// 	boundRows, err := s.repo.GetBoundIdentities(ctx, db, c.ID, c.ScanID)
// 	if err != nil {
// 		return nil, err
// 	}
// 	bound := make([]modelnewapi.CredBoundIdentity, 0, len(boundRows))
// 	for _, b := range boundRows {
// 		bound = append(bound, modelnewapi.CredBoundIdentity{
// 			IdentityID:     b.IdentityID,
// 			Name:           nullStringOrEmpty(b.Name),
// 			IdentityType:   nullStringOrEmpty(b.IdentityType),
// 			AccountID:      nullStringOrEmpty(b.AccountID),
// 			Status:         nullStringOrEmpty(b.Status),
// 			LastActivityAt: timePtrRFC3339FromNull(b.LastActivityAt),
// 			BindingType:    nullStringOrEmpty(b.BindingType),
// 		})
// 	}

// 	statements := credParseTrustStatements(c.TrustPolicy)
// 	hasExternal, hasWildcard, noCondition := false, false, false
// 	for _, st := range statements {
// 		if st.Effect != "allow" {
// 			continue
// 		}
// 		if st.PrincipalValue == "*" {
// 			hasWildcard = true
// 		}
// 		if st.PrincipalType == "AWS" {
// 			for _, part := range strings.Split(st.PrincipalValue, ",") {
// 				acct := credArnAccountID(strings.TrimSpace(part))
// 				if acct != "" && c.AccountID != "" && acct != c.AccountID {
// 					hasExternal = true
// 				}
// 			}
// 			if !st.HasCondition {
// 				noCondition = true
// 			}
// 		}
// 	}

// 	resp := &modelnewapi.CredentialOverviewResponse{
// 		Tab: "overview",
// 		Credential: modelnewapi.CredentialOverviewCore{
// 			ID:                    c.ID,
// 			Name:                  c.Name,
// 			ARN:                   c.ARN,
// 			CredentialType:        c.CredentialType,
// 			Category:              credDeriveCategory(c.CredentialType),
// 			AccountID:             c.AccountID,
// 			Region:                c.Region,
// 			Status:                c.Status,
// 			OwnerPrincipalARN:     nullStringPtr(c.OwnerPrincipalARN),
// 			CreatedAtAWS:          timePtrRFC3339FromNull(c.CreatedAtAWS),
// 			AgeDays:               credAgeDays(c.CreatedAtAWS, c.FirstSeenAt),
// 			LastUsedAt:            timePtrRFC3339FromNull(c.LastUsedAt),
// 			IdleDays:              credIdleDays(c.LastUsedAt),
// 			LastRotatedAt:         timePtrRFC3339FromNull(c.LastRotatedAt),
// 			DaysSinceRotation:     credDaysSinceRotation(c.LastRotatedAt, c.CreatedAtAWS),
// 			RotationEnabled:       c.RotationEnabled,
// 			RotationIntervalDays:  nullInt64Ptr(c.RotationIntervalDays),
// 			RotationStatus:        credRotationStatusLabel(c.RotationEnabled, credRotationOverdue(c)),
// 			ExpiresAt:             timePtrRFC3339FromNull(c.ExpiresAt),
// 			DaysUntilExpiry:       credDaysUntilExpiry(c.ExpiresAt),
// 			MaxSessionDuration:    nullInt64Ptr(c.MaxSessionDuration),
// 			PermissionBoundaryARN: nullStringPtr(c.PermissionBoundaryARN),
// 		},
// 		BoundIdentities: bound,
// 		TypeAttributes:  credDecodeJSON(c.TypeAttributes),
// 	}
// 	resp.RiskSignals = credBuildRiskSignals(c, len(bound), hasExternal, hasWildcard, noCondition)
// 	return resp, nil
// }

// // ── tab=trust ─────────────────────────────────────────────────────────

// func (s *CredentialDetailService) buildTrust(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialTrustResponse, error) {
// 	statements := credParseTrustStatements(c.TrustPolicy)
// 	principals, warnings := credComputeTrustPrincipalsAndWarnings(statements, c.AccountID)

// 	effSummary, err := s.buildEffectivePermissionsSummary(ctx, db, c)
// 	if err != nil {
// 		return nil, err
// 	}
// 	assumableRoles, err := s.buildAssumableRoles(ctx, db, c)
// 	if err != nil {
// 		return nil, err
// 	}

// 	return &modelnewapi.CredentialTrustResponse{
// 		Tab: "trust",
// 		TrustPolicy: modelnewapi.CredTrustPolicyBlock{
// 			Raw:        credDecodeJSON(c.TrustPolicy),
// 			Principals: principals,
// 			Warnings:   warnings,
// 		},
// 		AttachedPolicies:            credDecodeJSON(c.AttachedPolicies),
// 		InlinePolicies:              credDecodeJSON(c.InlinePolicies),
// 		EffectivePermissionsSummary: effSummary,
// 		AssumableRoles:              assumableRoles,
// 		PermissionBoundary: modelnewapi.CredPermissionBoundary{
// 			BoundaryARN:          nullStringPtr(c.PermissionBoundaryARN),
// 			EffectiveRestriction: nil, // only the boundary's ARN is stored, not its document
// 			ActionsBlocked:       []string{},
// 		},
// 	}, nil
// }

// // loadEffectivePermissionsSummary decodes effective_permissions.permissions
// // defensively — tolerates service/Service, effect/Effect, resource_arn/
// // resource/Resource key casing; degrades to empty on any shape mismatch.
// func (s *CredentialDetailService) buildEffectivePermissionsSummary(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) ([]modelnewapi.CredEffectivePermSummary, error) {
// 	raw, err := s.repo.GetEffectivePermissionsRaw(ctx, db, c.ID, c.ScanID)
// 	if err != nil {
// 		return nil, err
// 	}
// 	if len(raw) == 0 {
// 		return []modelnewapi.CredEffectivePermSummary{}, nil
// 	}
// 	var entries []map[string]interface{}
// 	if err := json.Unmarshal(raw, &entries); err != nil {
// 		return []modelnewapi.CredEffectivePermSummary{}, nil
// 	}

// 	type agg struct {
// 		allowed, denied int
// 		resources       map[string]struct{}
// 	}
// 	byService := map[string]*agg{}
// 	var order []string
// 	getStr := func(m map[string]interface{}, keys ...string) string {
// 		for _, k := range keys {
// 			if v, ok := m[k].(string); ok && v != "" {
// 				return v
// 			}
// 		}
// 		return ""
// 	}
// 	for _, e := range entries {
// 		service := getStr(e, "service", "Service")
// 		if service == "" {
// 			service = "unknown"
// 		}
// 		effect := strings.ToLower(getStr(e, "effect", "Effect"))
// 		resource := getStr(e, "resource_arn", "resource", "Resource")
// 		a, ok := byService[service]
// 		if !ok {
// 			a = &agg{resources: map[string]struct{}{}}
// 			byService[service] = a
// 			order = append(order, service)
// 		}
// 		if effect == "deny" {
// 			a.denied++
// 		} else {
// 			a.allowed++
// 		}
// 		if resource != "" {
// 			a.resources[resource] = struct{}{}
// 		}
// 	}
// 	sort.Strings(order)

// 	out := make([]modelnewapi.CredEffectivePermSummary, 0, len(order))
// 	for _, svc := range order {
// 		a := byService[svc]
// 		scopeLabel := "Unknown"
// 		if len(a.resources) == 1 {
// 			for res := range a.resources {
// 				scopeLabel = res
// 			}
// 		} else if len(a.resources) > 1 {
// 			scopeLabel = "Multiple"
// 		}
// 		out = append(out, modelnewapi.CredEffectivePermSummary{
// 			Service: svc, AllowedActions: a.allowed, DeniedActions: a.denied, ResourceScope: scopeLabel,
// 		})
// 	}
// 	return out, nil
// }

// func (s *CredentialDetailService) buildAssumableRoles(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) ([]modelnewapi.CredAssumableRole, error) {
// 	var arns []string
// 	if len(c.AssumableRoleARNs) > 0 {
// 		_ = json.Unmarshal(c.AssumableRoleARNs, &arns)
// 	}
// 	out := make([]modelnewapi.CredAssumableRole, 0, len(arns))
// 	for _, arn := range arns {
// 		role := modelnewapi.CredAssumableRole{TargetRoleARN: arn, TargetAccount: credArnAccountID(arn)}

// 		if condRaw, err := s.repo.GetTrustEdgeConditions(ctx, db, c.ARN, arn, c.ScanID); err == nil && len(condRaw) > 0 {
// 			cs := string(condRaw)
// 			role.Conditions = &cs
// 		}
// 		if lastAssumed, err := s.repo.GetLastAssumedAt(ctx, db, c.ID, arn, c.ScanID); err == nil {
// 			role.LastAssumed = timePtrRFC3339FromNull(lastAssumed)
// 		}
// 		out = append(out, role)
// 	}
// 	return out, nil
// }

// // ── tab=activity ──────────────────────────────────────────────────────

// func credParseTimeRangeDays(tr string) int {
// 	tr = strings.ToLower(strings.TrimSpace(tr))
// 	switch {
// 	case tr == "":
// 		return 90
// 	case tr == "all":
// 		return 36500
// 	case strings.HasSuffix(tr, "d"):
// 		if n, err := strconv.Atoi(strings.TrimSuffix(tr, "d")); err == nil && n > 0 {
// 			return n
// 		}
// 	}
// 	return 90
// }

// func (s *CredentialDetailService) buildActivity(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow, timeRange string) (*modelnewapi.CredentialActivityResponse, error) {
// 	days := credParseTimeRangeDays(timeRange)
// 	since := time.Now().AddDate(0, 0, -days)

// 	volRows, err := s.repo.GetVolumeChart(ctx, db, c.ID, c.ScanID, since)
// 	if err != nil {
// 		return nil, err
// 	}
// 	volumeChart := make([]modelnewapi.CredVolumePoint, 0, len(volRows))
// 	for _, v := range volRows {
// 		volumeChart = append(volumeChart, modelnewapi.CredVolumePoint{Date: v.Date.Format("2006-01-02"), Count: v.Count})
// 	}

// 	totalCount, err := s.repo.CountRecentEvents(ctx, db, c.ID, c.ScanID, since)
// 	if err != nil {
// 		return nil, err
// 	}
// 	const pageSize = 50
// 	evRows, err := s.repo.GetRecentEvents(ctx, db, c.ID, c.ScanID, since, pageSize)
// 	if err != nil {
// 		return nil, err
// 	}
// 	recentEvents := make([]modelnewapi.CredRecentEvent, 0, len(evRows))
// 	for _, e := range evRows {
// 		recentEvents = append(recentEvents, modelnewapi.CredRecentEvent{
// 			EventTime:   timePtrRFC3339FromNull(e.EventTime),
// 			EventName:   e.EventName,
// 			Service:     e.Service,
// 			ResourceARN: nullStringPtr(e.ResourceARN),
// 			EventCount:  e.EventCount,
// 		})
// 	}

// 	boundRows, err := s.repo.GetBoundIdentities(ctx, db, c.ID, c.ScanID)
// 	if err != nil {
// 		return nil, err
// 	}
// 	usingIdentities := make([]modelnewapi.CredUsingIdentity, 0, len(boundRows))
// 	for _, b := range boundRows {
// 		usingIdentities = append(usingIdentities, modelnewapi.CredUsingIdentity{
// 			IdentityID:   b.IdentityID,
// 			Name:         nullStringOrEmpty(b.Name),
// 			IdentityType: nullStringOrEmpty(b.IdentityType),
// 		})
// 	}

// 	svcRows, err := s.repo.GetTopServices(ctx, db, c.ID, c.ScanID, since)
// 	if err != nil {
// 		return nil, err
// 	}
// 	total := 0
// 	for _, sc := range svcRows {
// 		total += sc.Count
// 	}
// 	topServices := make([]modelnewapi.CredServicePct, 0, len(svcRows))
// 	for _, sc := range svcRows {
// 		pct := 0.0
// 		if total > 0 {
// 			pct = (float64(sc.Count) / float64(total)) * 100
// 		}
// 		topServices = append(topServices, modelnewapi.CredServicePct{Service: sc.Service, Pct: roundTo2(pct), Count: sc.Count})
// 	}

// 	activeRegions := []modelnewapi.CredRegionCnt{}
// 	if c.Region != "" && total > 0 {
// 		activeRegions = append(activeRegions, modelnewapi.CredRegionCnt{Region: c.Region, Count: total})
// 	}

// 	distinctDays, err := s.repo.CountDistinctActiveDays(ctx, db, c.ID, c.ScanID, since)
// 	if err != nil {
// 		return nil, err
// 	}
// 	rangeDays := int(time.Since(since).Hours() / 24)
// 	if rangeDays <= 0 {
// 		rangeDays = 1
// 	}
// 	usagePattern := "Intermittent"
// 	switch {
// 	case distinctDays == 0:
// 		usagePattern = "Dormant"
// 	case float64(distinctDays)/float64(rangeDays) >= 0.6:
// 		usagePattern = "Continuous"
// 	}

// 	totalPages := 0
// 	if pageSize > 0 {
// 		totalPages = (totalCount + pageSize - 1) / pageSize
// 	}

// 	return &modelnewapi.CredentialActivityResponse{
// 		Tab:                           "activity",
// 		TimeRange:                     timeRange,
// 		VolumeChart:                   volumeChart,
// 		RecentEvents:                  recentEvents,
// 		IdentitiesUsingThisCredential: usingIdentities,
// 		Analytics: modelnewapi.CredActivityAnalytics{
// 			SourceIPs:     []modelnewapi.CredIPPct{},
// 			ActiveRegions: activeRegions,
// 			TopServices:   topServices,
// 			UsagePattern:  usagePattern,
// 			ErrorRatePct:  nil,
// 		},
// 		EventsPagination: modelnewapi.CredEventsPagination{
// 			Page: 1, PageSize: pageSize, TotalCount: totalCount, TotalPages: totalPages,
// 		},
// 	}, nil
// }

// // ── tab=rotation ──────────────────────────────────────────────────────

// func (s *CredentialDetailService) buildRotation(c *reponewapi.CredentialCoreRow) *modelnewapi.CredentialRotationResponse {
// 	var timeline []modelnewapi.CredRotationEvent
// 	if c.CreatedAtAWS.Valid {
// 		details := "Discovered by scan"
// 		if c.DiscoverySource.Valid && c.DiscoverySource.String != "" {
// 			details = "Discovered via " + c.DiscoverySource.String
// 		}
// 		timeline = append(timeline, modelnewapi.CredRotationEvent{
// 			Date: c.CreatedAtAWS.Time.UTC().Format(time.RFC3339), Event: "Created", Details: details,
// 		})
// 	}
// 	if c.LastRotatedAt.Valid && (!c.CreatedAtAWS.Valid || !c.LastRotatedAt.Time.Equal(c.CreatedAtAWS.Time)) {
// 		timeline = append(timeline, modelnewapi.CredRotationEvent{
// 			Date: c.LastRotatedAt.Time.UTC().Format(time.RFC3339), Event: "Rotated", Details: "Most recent rotation on record",
// 		})
// 	}
// 	if timeline == nil {
// 		timeline = []modelnewapi.CredRotationEvent{}
// 	}

// 	var nextExpected *string
// 	if c.RotationEnabled && c.RotationIntervalDays.Valid {
// 		ref := c.LastRotatedAt
// 		if !ref.Valid {
// 			ref = c.CreatedAtAWS
// 		}
// 		if ref.Valid {
// 			t := ref.Time.AddDate(0, 0, int(c.RotationIntervalDays.Int64)).UTC().Format(time.RFC3339)
// 			nextExpected = &t
// 		}
// 	}

// 	overdue := credRotationOverdue(c)
// 	return &modelnewapi.CredentialRotationResponse{
// 		Tab:      "rotation",
// 		Timeline: timeline,
// 		Configuration: modelnewapi.CredRotationConfig{
// 			AutoRotation:         c.RotationEnabled,
// 			RotationIntervalDays: nullInt64Ptr(c.RotationIntervalDays),
// 			LastRotation:         timePtrRFC3339FromNull(c.LastRotatedAt),
// 			NextExpected:         nextExpected,
// 			Status:               credRotationStatusLabel(c.RotationEnabled, overdue),
// 			RotationLambdaARN:    nil,
// 		},
// 		Lifecycle: modelnewapi.CredRotationLifecycle{
// 			CreatedAtAWS:      timePtrRFC3339FromNull(c.CreatedAtAWS),
// 			AgeDays:           credAgeDays(c.CreatedAtAWS, c.FirstSeenAt),
// 			DaysSinceRotation: credDaysSinceRotation(c.LastRotatedAt, c.CreatedAtAWS),
// 			ExpiresAt:         timePtrRFC3339FromNull(c.ExpiresAt),
// 			DaysUntilExpiry:   credDaysUntilExpiry(c.ExpiresAt),
// 		},
// 	}
// }

// // ── tab=relationships ─────────────────────────────────────────────────

// func credRelationshipLabel(edgeType, direction string) string {
// 	et := strings.ToUpper(strings.TrimSpace(edgeType))
// 	switch {
// 	case et == "BOUND_TO" && direction == "inbound":
// 		return "Used by"
// 	case et == "BOUND_TO" && direction == "outbound":
// 		return "Bound to"
// 	case strings.Contains(et, "ASSUME") && direction == "outbound":
// 		return "Can assume"
// 	case strings.Contains(et, "ASSUME") && direction == "inbound":
// 		return "Assumable by"
// 	case et == "":
// 		return "Related"
// 	default:
// 		return strings.Title(strings.ToLower(strings.ReplaceAll(et, "_", " ")))
// 	}
// }

// func (s *CredentialDetailService) buildRelationships(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow, depth int, edgeType string) (*modelnewapi.CredentialRelationshipsResponse, error) {
// 	var edgeTypes []string
// 	for _, et := range strings.Split(edgeType, ",") {
// 		if et = strings.TrimSpace(et); et != "" {
// 			edgeTypes = append(edgeTypes, et)
// 		}
// 	}

// 	visited := map[string]bool{c.ARN: true}
// 	frontier := []string{c.ARN}
// 	var allEdges []reponewapi.CredGraphEdgeRow

// 	for hop := 0; hop < depth && len(frontier) > 0; hop++ {
// 		edges, err := s.repo.GetEdgesTouching(ctx, db, c.ScanID, frontier, edgeTypes)
// 		if err != nil {
// 			return nil, err
// 		}
// 		var next []string
// 		for _, e := range edges {
// 			allEdges = append(allEdges, e)
// 			if !visited[e.Source] {
// 				visited[e.Source] = true
// 				next = append(next, e.Source)
// 			}
// 			if !visited[e.Target] {
// 				visited[e.Target] = true
// 				next = append(next, e.Target)
// 			}
// 		}
// 		frontier = next
// 	}

// 	arns := make([]string, 0, len(visited))
// 	for a := range visited {
// 		arns = append(arns, a)
// 	}
// 	nodeInfo, err := s.repo.ResolveNodes(ctx, db, c.ScanID, arns)
// 	if err != nil {
// 		return nil, err
// 	}

// 	nodes := make([]modelnewapi.CredGraphNode, 0, len(arns))
// 	for _, arn := range arns {
// 		info := nodeInfo[arn]
// 		nodes = append(nodes, modelnewapi.CredGraphNode{
// 			ARN: arn, Name: nullStringOrEmpty(info.Name), Type: info.NodeType,
// 			Subtype: nullStringOrEmpty(info.Subtype), IsCurrent: arn == c.ARN,
// 		})
// 	}
// 	sort.Slice(nodes, func(i, j int) bool { return nodes[i].ARN < nodes[j].ARN })

// 	edges := make([]modelnewapi.CredGraphEdge, 0, len(allEdges))
// 	relTable := make([]modelnewapi.CredRelationshipRow, 0)
// 	for _, e := range allEdges {
// 		lastObserved := timePtrRFC3339FromNull(e.CreatedAt)
// 		edges = append(edges, modelnewapi.CredGraphEdge{
// 			Source: e.Source, Target: e.Target, EdgeType: nullStringOrEmpty(e.EdgeType), LastObservedAt: lastObserved,
// 		})
// 		if e.Source != c.ARN && e.Target != c.ARN {
// 			continue
// 		}
// 		direction := "outbound"
// 		targetArn := e.Target
// 		if e.Target == c.ARN {
// 			direction = "inbound"
// 			targetArn = e.Source
// 		}
// 		info := nodeInfo[targetArn]
// 		lastActive := lastObserved
// 		if info.NodeType == "identity" && info.LastActivityAt.Valid {
// 			lastActive = timePtrRFC3339FromNull(info.LastActivityAt)
// 		}
// 		relTable = append(relTable, modelnewapi.CredRelationshipRow{
// 			Relationship: credRelationshipLabel(nullStringOrEmpty(e.EdgeType), direction),
// 			Direction:    direction,
// 			TargetARN:    targetArn,
// 			TargetName:   nullStringOrEmpty(info.Name),
// 			TargetType:   info.NodeType,
// 			LastActive:   lastActive,
// 		})
// 	}

// 	return &modelnewapi.CredentialRelationshipsResponse{
// 		Tab:               "relationships",
// 		Graph:             modelnewapi.CredRelationshipGraph{Nodes: nodes, Edges: edges},
// 		RelationshipTable: relTable,
// 	}, nil
// }

// // ── tab=raw ───────────────────────────────────────────────────────────

// func (s *CredentialDetailService) buildRaw(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialRawResponse, error) {
// 	effRaw, err := s.repo.GetEffectivePermissionsRaw(ctx, db, c.ID, c.ScanID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	record := map[string]interface{}{
// 		"id":                      c.ID,
// 		"arn":                     c.ARN,
// 		"name":                    c.Name,
// 		"credential_type":         c.CredentialType,
// 		"account_id":              c.AccountID,
// 		"region":                  c.Region,
// 		"status":                  c.Status,
// 		"created_at_aws":          timePtrRFC3339FromNull(c.CreatedAtAWS),
// 		"first_seen_at":           timePtrRFC3339FromNull(c.FirstSeenAt),
// 		"last_seen_at":            timePtrRFC3339FromNull(c.LastSeenAt),
// 		"deleted_at":              timePtrRFC3339FromNull(c.DeletedAt),
// 		"last_used_at":            timePtrRFC3339FromNull(c.LastUsedAt),
// 		"last_rotated_at":         timePtrRFC3339FromNull(c.LastRotatedAt),
// 		"expires_at":              timePtrRFC3339FromNull(c.ExpiresAt),
// 		"rotation_enabled":        c.RotationEnabled,
// 		"rotation_interval_days":  nullInt64Ptr(c.RotationIntervalDays),
// 		"tags":                    credDecodeJSON(c.Tags),
// 		"owner_principal_arn":     nullStringPtr(c.OwnerPrincipalARN),
// 		"trust_policy":            credDecodeJSON(c.TrustPolicy),
// 		"attached_policies":       credDecodeJSON(c.AttachedPolicies),
// 		"inline_policies":         credDecodeJSON(c.InlinePolicies),
// 		"permission_boundary_arn": nullStringPtr(c.PermissionBoundaryARN),
// 		"max_session_duration":    nullInt64Ptr(c.MaxSessionDuration),
// 		"privilege_level":         nullInt64Ptr(c.PrivilegeLevel),
// 		"assumable_role_arns":     credDecodeJSON(c.AssumableRoleARNs),
// 		"discovery_source":        nullStringPtr(c.DiscoverySource),
// 		"scan_id":                 c.ScanID,
// 		"type_attributes":         credDecodeJSON(c.TypeAttributes),
// 		"raw_api_response":        credDecodeJSON(c.RawAPIResponse),
// 		"created_at":              timePtrRFC3339FromNull(c.CreatedAt),
// 		"updated_at":              timePtrRFC3339FromNull(c.UpdatedAt),
// 	}

// 	return &modelnewapi.CredentialRawResponse{
// 		Tab:                  "raw",
// 		CredentialRecord:     record,
// 		RawAPIResponse:       credDecodeJSON(c.RawAPIResponse),
// 		TrustPolicy:          credDecodeJSON(c.TrustPolicy),
// 		AttachedPolicies:     credDecodeJSON(c.AttachedPolicies),
// 		InlinePolicies:       credDecodeJSON(c.InlinePolicies),
// 		TypeAttributes:       credDecodeJSON(c.TypeAttributes),
// 		EffectivePermissions: credDecodeJSON(effRaw),
// 	}, nil
// }




















package newapi

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

// CredentialDetailValidationError is a client mistake (HTTP 400).
type CredentialDetailValidationError struct{ Msg string }

func (e *CredentialDetailValidationError) Error() string { return e.Msg }

// CredentialDetailNotFoundError covers "no completed scan yet" and
// "credential id not found within the latest completed scan".
type CredentialDetailNotFoundError struct{ Msg string }

func (e *CredentialDetailNotFoundError) Error() string { return e.Msg }

// CredentialDetailParams holds the raw, unvalidated query string values.
type CredentialDetailParams struct {
	Tab       string
	TimeRange string
	Depth     string
	EdgeType  string
}

var credValidTabs = map[string]bool{
	"overview":      true,
	"trust":         true,
	"activity":      true,
	"rotation":      true,
	"relationships": true,
	"raw":           true,
}

type CredentialDetailService struct {
	dbm   *database.Manager
	repo  *reponewapi.CredentialDetailRepository
	scans *reponewapi.ScanRepository
}

func NewCredentialDetailService(dbm *database.Manager, repo *reponewapi.CredentialDetailRepository, scans *reponewapi.ScanRepository) *CredentialDetailService {
	return &CredentialDetailService{dbm: dbm, repo: repo, scans: scans}
}

var credUUIDRe = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// Get implements Endpoint 7: Credential Detail.
func (s *CredentialDetailService) Get(ctx context.Context, id Identity, credentialID string, p CredentialDetailParams) (interface{}, error) {
	credentialID = strings.TrimSpace(credentialID)
	if !credUUIDRe.MatchString(credentialID) {
		return nil, &CredentialDetailValidationError{Msg: "id: must be a valid UUID"}
	}

	tab := strings.ToLower(strings.TrimSpace(p.Tab))
	if tab == "" {
		tab = "overview"
	}
	if !credValidTabs[tab] {
		return nil, &CredentialDetailValidationError{Msg: fmt.Sprintf("tab: invalid value %q", tab)}
	}

	// Validate the time filter up-front so a bad value is a 400, not a silent 90d.
	rng, err := ResolveTimeRange(p.TimeRange)
	if err != nil {
		return nil, &CredentialDetailValidationError{Msg: err.Error()}
	}

	depth := 1
	if v := strings.TrimSpace(p.Depth); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 3 {
			return nil, &CredentialDetailValidationError{Msg: "depth: must be 1, 2 or 3"}
		}
		depth = n
	}
	edgeType := strings.TrimSpace(p.EdgeType)

	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	latestScan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
	if err != nil {
		return nil, fmt.Errorf("resolve latest completed scan: %w", err)
	}
	if latestScan == nil {
		return nil, &CredentialDetailNotFoundError{Msg: "no completed scan available yet"}
	}

	core, err := s.repo.GetCore(ctx, tenantDB, credentialID, latestScan.ScanID)
	if err != nil {
		return nil, err
	}
	if core == nil {
		return nil, &CredentialDetailNotFoundError{Msg: fmt.Sprintf("credential %q not found in the latest completed scan", credentialID)}
	}

	switch tab {
	case "overview":
		return s.buildOverview(ctx, tenantDB, core)
	case "trust":
		return s.buildTrust(ctx, tenantDB, core)
	case "activity":
		return s.buildActivity(ctx, tenantDB, core, rng)
	case "rotation":
		return s.buildRotation(core), nil
	case "relationships":
		return s.buildRelationships(ctx, tenantDB, core, depth, edgeType)
	case "raw":
		return s.buildRaw(ctx, tenantDB, core)
	default:
		return nil, &CredentialDetailValidationError{Msg: fmt.Sprintf("tab: invalid value %q", tab)}
	}
}

// ── small local helpers (prefixed cred* to avoid collisions) ─────────────

func nullStringOrEmpty(s sql.NullString) string {
	if !s.Valid {
		return ""
	}
	return s.String
}

func credDecodeJSON(raw []byte) interface{} {
	if len(raw) == 0 {
		return nil
	}
	var v interface{}
	if err := json.Unmarshal(raw, &v); err != nil {
		return nil
	}
	return v
}

func credAgeDays(createdAtAWS, firstSeenAt sql.NullTime) *int {
	ref := createdAtAWS
	if !ref.Valid {
		ref = firstSeenAt
	}
	if !ref.Valid {
		return nil
	}
	d := int(time.Since(ref.Time).Hours() / 24)
	return &d
}

func credIdleDays(lastUsedAt sql.NullTime) *int {
	if !lastUsedAt.Valid {
		return nil
	}
	d := int(time.Since(lastUsedAt.Time).Hours() / 24)
	return &d
}

func credDaysSinceRotation(lastRotatedAt, createdAtAWS sql.NullTime) *int {
	ref := lastRotatedAt
	if !ref.Valid {
		ref = createdAtAWS
	}
	if !ref.Valid {
		return nil
	}
	d := int(time.Since(ref.Time).Hours() / 24)
	return &d
}

func credDaysUntilExpiry(expiresAt sql.NullTime) *int {
	if !expiresAt.Valid {
		return nil
	}
	d := int(time.Until(expiresAt.Time).Hours() / 24)
	return &d
}

func credRotationOverdue(c *reponewapi.CredentialCoreRow) bool {
	if !c.RotationEnabled || !c.RotationIntervalDays.Valid {
		return false
	}
	ref := c.LastRotatedAt
	if !ref.Valid {
		ref = c.CreatedAtAWS
	}
	if !ref.Valid {
		return false
	}
	return time.Now().After(ref.Time.AddDate(0, 0, int(c.RotationIntervalDays.Int64)))
}

func credRotationStatusLabel(enabled, overdue bool) string {
	if !enabled {
		return "Disabled"
	}
	if overdue {
		return "Overdue"
	}
	return "Enabled"
}

// credDeriveCategory is a presentation-layer heuristic — there is no stored
// "category" column for credentials in this schema.
func credDeriveCategory(credentialType string) string {
	switch strings.ToLower(strings.TrimSpace(credentialType)) {
	case "iam_role", "iam_user", "iam_group", "access_key", "iam_policy":
		return "IAM"
	case "secret", "secrets_manager_secret", "secretsmanager_secret":
		return "Secrets Manager"
	case "kms_key", "kms":
		return "KMS"
	case "service_account", "service_account_key":
		return "Service Account"
	case "instance_profile":
		return "Compute"
	case "":
		return "Unknown"
	default:
		return strings.ToUpper(credentialType[:1]) + credentialType[1:]
	}
}

// ── trust policy parsing ──────────────────────────────────────────────

type credTrustStatement struct {
	Effect         string // "allow" | "deny", lowercased
	PrincipalType  string // "AWS", "Service", "Federated", "*"
	PrincipalValue string
	HasCondition   bool
	ConditionDesc  string
}

func credParseTrustStatements(trustPolicy []byte) []credTrustStatement {
	if len(trustPolicy) == 0 {
		return nil
	}
	var doc struct {
		Statement json.RawMessage `json:"Statement"`
	}
	if err := json.Unmarshal(trustPolicy, &doc); err != nil || len(doc.Statement) == 0 {
		return nil
	}

	var stmts []map[string]interface{}
	if err := json.Unmarshal(doc.Statement, &stmts); err != nil {
		var single map[string]interface{}
		if err := json.Unmarshal(doc.Statement, &single); err == nil {
			stmts = []map[string]interface{}{single}
		}
	}

	out := make([]credTrustStatement, 0, len(stmts))
	for _, st := range stmts {
		cs := credTrustStatement{}
		if eff, ok := st["Effect"].(string); ok {
			cs.Effect = strings.ToLower(eff)
		}
		if cond, ok := st["Condition"]; ok {
			cs.HasCondition = true
			if b, err := json.Marshal(cond); err == nil {
				cs.ConditionDesc = string(b)
			}
		}
		switch p := st["Principal"].(type) {
		case string:
			cs.PrincipalType = "*"
			cs.PrincipalValue = p
		case map[string]interface{}:
			for k, v := range p {
				cs.PrincipalType = k
				switch vv := v.(type) {
				case string:
					cs.PrincipalValue = vv
				case []interface{}:
					var parts []string
					for _, item := range vv {
						if sv, ok := item.(string); ok {
							parts = append(parts, sv)
						}
					}
					cs.PrincipalValue = strings.Join(parts, ",")
				}
				break
			}
		}
		out = append(out, cs)
	}
	return out
}

var credArnAccountRe = regexp.MustCompile(`arn:aws[a-z0-9-]*:[a-z0-9-]+:[a-z0-9-]*:(\d{12}):`)

func credArnAccountID(arn string) string {
	m := credArnAccountRe.FindStringSubmatch(arn)
	if m == nil {
		return ""
	}
	return m[1]
}

func credComputeTrustPrincipalsAndWarnings(statements []credTrustStatement, accountID string) ([]modelnewapi.CredTrustPrincipal, []string) {
	principals := make([]modelnewapi.CredTrustPrincipal, 0, len(statements))
	var warnings []string
	for _, st := range statements {
		if st.PrincipalValue == "" {
			continue
		}
		var cond *string
		if st.HasCondition {
			c := st.ConditionDesc
			cond = &c
		}
		isExternal := false
		if st.Effect == "allow" && st.PrincipalType == "AWS" {
			for _, part := range strings.Split(st.PrincipalValue, ",") {
				acct := credArnAccountID(strings.TrimSpace(part))
				if acct != "" && accountID != "" && acct != accountID {
					isExternal = true
				}
			}
		}
		principals = append(principals, modelnewapi.CredTrustPrincipal{
			Principal:  st.PrincipalValue,
			Type:       st.PrincipalType,
			Condition:  cond,
			IsExternal: isExternal,
		})
		if st.Effect == "allow" {
			if st.PrincipalValue == "*" {
				warnings = append(warnings, "Trust policy allows a wildcard principal (*)")
			}
			if isExternal {
				warnings = append(warnings, fmt.Sprintf("Cross-account trust granted to principal '%s'", st.PrincipalValue))
			}
			if !st.HasCondition && st.PrincipalType == "AWS" {
				warnings = append(warnings, fmt.Sprintf("No condition restricts assumption by '%s'", st.PrincipalValue))
			}
		}
	}
	if warnings == nil {
		warnings = []string{}
	}
	return principals, warnings
}

func credBuildRiskSignals(c *reponewapi.CredentialCoreRow, boundCount int, hasExternal, hasWildcard, noCondition bool) []modelnewapi.CredRiskSignal {
	expired := c.ExpiresAt.Valid && c.ExpiresAt.Time.Before(time.Now())
	expSoon := false
	if c.ExpiresAt.Valid && !expired {
		if d := credDaysUntilExpiry(c.ExpiresAt); d != nil && *d <= 30 {
			expSoon = true
		}
	}
	idle := credIdleDays(c.LastUsedAt)
	stale := idle != nil && *idle > 90

	return []modelnewapi.CredRiskSignal{
		{Signal: "Orphaned (no identity bound)", Status: boundCount == 0, Severity: "high"},
		{Signal: "Overshared (3+ identities)", Status: boundCount >= 3, Severity: "medium"},
		{Signal: "Never rotated", Status: !c.LastRotatedAt.Valid, Severity: "high"},
		{Signal: "Rotation overdue", Status: credRotationOverdue(c), Severity: "high"},
		{Signal: "Expiring soon (< 30 days)", Status: expSoon, Severity: "high"},
		{Signal: "Already expired", Status: expired, Severity: "critical"},
		{Signal: "Stale (unused > 90 days)", Status: stale, Severity: "high"},
		{Signal: "External trust (cross-account)", Status: hasExternal, Severity: "medium"},
		{Signal: "Wildcard trust (Principal: *)", Status: hasWildcard, Severity: "critical"},
		{Signal: "No condition on trust policy", Status: noCondition, Severity: "high"},
		{Signal: "No permission boundary", Status: !c.PermissionBoundaryARN.Valid || c.PermissionBoundaryARN.String == "", Severity: "medium"},
	}
}

// ── tab=overview ──────────────────────────────────────────────────────

func (s *CredentialDetailService) buildOverview(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialOverviewResponse, error) {
	boundRows, err := s.repo.GetBoundIdentities(ctx, db, c.ID, c.ScanID)
	if err != nil {
		return nil, err
	}
	bound := make([]modelnewapi.CredBoundIdentity, 0, len(boundRows))
	for _, b := range boundRows {
		bound = append(bound, modelnewapi.CredBoundIdentity{
			IdentityID:     b.IdentityID,
			Name:           nullStringOrEmpty(b.Name),
			IdentityType:   nullStringOrEmpty(b.IdentityType),
			AccountID:      nullStringOrEmpty(b.AccountID),
			Status:         nullStringOrEmpty(b.Status),
			LastActivityAt: timePtrRFC3339FromNull(b.LastActivityAt),
			BindingType:    nullStringOrEmpty(b.BindingType),
		})
	}

	statements := credParseTrustStatements(c.TrustPolicy)
	hasExternal, hasWildcard, noCondition := false, false, false
	for _, st := range statements {
		if st.Effect != "allow" {
			continue
		}
		if st.PrincipalValue == "*" {
			hasWildcard = true
		}
		if st.PrincipalType == "AWS" {
			for _, part := range strings.Split(st.PrincipalValue, ",") {
				acct := credArnAccountID(strings.TrimSpace(part))
				if acct != "" && c.AccountID != "" && acct != c.AccountID {
					hasExternal = true
				}
			}
			if !st.HasCondition {
				noCondition = true
			}
		}
	}

	resp := &modelnewapi.CredentialOverviewResponse{
		Tab: "overview",
		Credential: modelnewapi.CredentialOverviewCore{
			ID:                    c.ID,
			Name:                  c.Name,
			ARN:                   c.ARN,
			CredentialType:        c.CredentialType,
			Category:              credDeriveCategory(c.CredentialType),
			AccountID:             c.AccountID,
			Region:                c.Region,
			Status:                c.Status,
			OwnerPrincipalARN:     nullStringPtr(c.OwnerPrincipalARN),
			CreatedAtAWS:          timePtrRFC3339FromNull(c.CreatedAtAWS),
			AgeDays:               credAgeDays(c.CreatedAtAWS, c.FirstSeenAt),
			LastUsedAt:            timePtrRFC3339FromNull(c.LastUsedAt),
			IdleDays:              credIdleDays(c.LastUsedAt),
			LastRotatedAt:         timePtrRFC3339FromNull(c.LastRotatedAt),
			DaysSinceRotation:     credDaysSinceRotation(c.LastRotatedAt, c.CreatedAtAWS),
			RotationEnabled:       c.RotationEnabled,
			RotationIntervalDays:  nullInt64Ptr(c.RotationIntervalDays),
			RotationStatus:        credRotationStatusLabel(c.RotationEnabled, credRotationOverdue(c)),
			ExpiresAt:             timePtrRFC3339FromNull(c.ExpiresAt),
			DaysUntilExpiry:       credDaysUntilExpiry(c.ExpiresAt),
			MaxSessionDuration:    nullInt64Ptr(c.MaxSessionDuration),
			PermissionBoundaryARN: nullStringPtr(c.PermissionBoundaryARN),
		},
		BoundIdentities: bound,
		TypeAttributes:  credDecodeJSON(c.TypeAttributes),
	}
	resp.RiskSignals = credBuildRiskSignals(c, len(bound), hasExternal, hasWildcard, noCondition)
	return resp, nil
}

// ── tab=trust ─────────────────────────────────────────────────────────

func (s *CredentialDetailService) buildTrust(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialTrustResponse, error) {
	statements := credParseTrustStatements(c.TrustPolicy)
	principals, warnings := credComputeTrustPrincipalsAndWarnings(statements, c.AccountID)

	effSummary, err := s.buildEffectivePermissionsSummary(ctx, db, c)
	if err != nil {
		return nil, err
	}
	assumableRoles, err := s.buildAssumableRoles(ctx, db, c)
	if err != nil {
		return nil, err
	}

	return &modelnewapi.CredentialTrustResponse{
		Tab: "trust",
		TrustPolicy: modelnewapi.CredTrustPolicyBlock{
			Raw:        credDecodeJSON(c.TrustPolicy),
			Principals: principals,
			Warnings:   warnings,
		},
		AttachedPolicies:            credDecodeJSON(c.AttachedPolicies),
		InlinePolicies:              credDecodeJSON(c.InlinePolicies),
		EffectivePermissionsSummary: effSummary,
		AssumableRoles:              assumableRoles,
		PermissionBoundary: modelnewapi.CredPermissionBoundary{
			BoundaryARN:          nullStringPtr(c.PermissionBoundaryARN),
			EffectiveRestriction: nil, // only the boundary's ARN is stored, not its document
			ActionsBlocked:       []string{},
		},
	}, nil
}

// loadEffectivePermissionsSummary decodes effective_permissions.permissions
// defensively — tolerates service/Service, effect/Effect, resource_arn/
// resource/Resource key casing; degrades to empty on any shape mismatch.
func (s *CredentialDetailService) buildEffectivePermissionsSummary(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) ([]modelnewapi.CredEffectivePermSummary, error) {
	raw, err := s.repo.GetEffectivePermissionsRaw(ctx, db, c.ID, c.ScanID)
	if err != nil {
		return nil, err
	}
	if len(raw) == 0 {
		return []modelnewapi.CredEffectivePermSummary{}, nil
	}
	var entries []map[string]interface{}
	if err := json.Unmarshal(raw, &entries); err != nil {
		return []modelnewapi.CredEffectivePermSummary{}, nil
	}

	type agg struct {
		allowed, denied int
		resources       map[string]struct{}
	}
	byService := map[string]*agg{}
	var order []string
	getStr := func(m map[string]interface{}, keys ...string) string {
		for _, k := range keys {
			if v, ok := m[k].(string); ok && v != "" {
				return v
			}
		}
		return ""
	}
	for _, e := range entries {
		service := getStr(e, "service", "Service")
		if service == "" {
			service = "unknown"
		}
		effect := strings.ToLower(getStr(e, "effect", "Effect"))
		resource := getStr(e, "resource_arn", "resource", "Resource")
		a, ok := byService[service]
		if !ok {
			a = &agg{resources: map[string]struct{}{}}
			byService[service] = a
			order = append(order, service)
		}
		if effect == "deny" {
			a.denied++
		} else {
			a.allowed++
		}
		if resource != "" {
			a.resources[resource] = struct{}{}
		}
	}
	sort.Strings(order)

	out := make([]modelnewapi.CredEffectivePermSummary, 0, len(order))
	for _, svc := range order {
		a := byService[svc]
		scopeLabel := "Unknown"
		if len(a.resources) == 1 {
			for res := range a.resources {
				scopeLabel = res
			}
		} else if len(a.resources) > 1 {
			scopeLabel = "Multiple"
		}
		out = append(out, modelnewapi.CredEffectivePermSummary{
			Service: svc, AllowedActions: a.allowed, DeniedActions: a.denied, ResourceScope: scopeLabel,
		})
	}
	return out, nil
}

func (s *CredentialDetailService) buildAssumableRoles(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) ([]modelnewapi.CredAssumableRole, error) {
	var arns []string
	if len(c.AssumableRoleARNs) > 0 {
		_ = json.Unmarshal(c.AssumableRoleARNs, &arns)
	}
	out := make([]modelnewapi.CredAssumableRole, 0, len(arns))
	for _, arn := range arns {
		role := modelnewapi.CredAssumableRole{TargetRoleARN: arn, TargetAccount: credArnAccountID(arn)}

		if condRaw, err := s.repo.GetTrustEdgeConditions(ctx, db, c.ARN, arn, c.ScanID); err == nil && len(condRaw) > 0 {
			cs := string(condRaw)
			role.Conditions = &cs
		}
		if lastAssumed, err := s.repo.GetLastAssumedAt(ctx, db, c.ID, arn, c.ScanID); err == nil {
			role.LastAssumed = timePtrRFC3339FromNull(lastAssumed)
		}
		out = append(out, role)
	}
	return out, nil
}

// ── tab=activity ──────────────────────────────────────────────────────

func (s *CredentialDetailService) buildActivity(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow, rng *ResolvedTimeRange) (*modelnewapi.CredentialActivityResponse, error) {
	start, end := rng.Start, rng.End

	volRows, err := s.repo.GetVolumeChart(ctx, db, c.ID, c.ScanID, start, end)
	if err != nil {
		return nil, err
	}
	volumeChart := make([]modelnewapi.CredVolumePoint, 0, len(volRows))
	for _, v := range volRows {
		volumeChart = append(volumeChart, modelnewapi.CredVolumePoint{Date: v.Date.Format("2006-01-02"), Count: v.Count})
	}

	totalCount, err := s.repo.CountRecentEvents(ctx, db, c.ID, c.ScanID, start, end)
	if err != nil {
		return nil, err
	}
	const pageSize = 50
	evRows, err := s.repo.GetRecentEvents(ctx, db, c.ID, c.ScanID, start, end, pageSize)
	if err != nil {
		return nil, err
	}
	recentEvents := make([]modelnewapi.CredRecentEvent, 0, len(evRows))
	for _, e := range evRows {
		recentEvents = append(recentEvents, modelnewapi.CredRecentEvent{
			EventTime:   timePtrRFC3339FromNull(e.EventTime),
			EventName:   e.EventName,
			Service:     e.Service,
			ResourceARN: nullStringPtr(e.ResourceARN),
			EventCount:  e.EventCount,
		})
	}

	boundRows, err := s.repo.GetBoundIdentities(ctx, db, c.ID, c.ScanID)
	if err != nil {
		return nil, err
	}
	usingIdentities := make([]modelnewapi.CredUsingIdentity, 0, len(boundRows))
	for _, b := range boundRows {
		usingIdentities = append(usingIdentities, modelnewapi.CredUsingIdentity{
			IdentityID:   b.IdentityID,
			Name:         nullStringOrEmpty(b.Name),
			IdentityType: nullStringOrEmpty(b.IdentityType),
		})
	}

	svcRows, err := s.repo.GetTopServices(ctx, db, c.ID, c.ScanID, start, end)
	if err != nil {
		return nil, err
	}
	total := 0
	for _, sc := range svcRows {
		total += sc.Count
	}
	topServices := make([]modelnewapi.CredServicePct, 0, len(svcRows))
	for _, sc := range svcRows {
		pct := 0.0
		if total > 0 {
			pct = (float64(sc.Count) / float64(total)) * 100
		}
		topServices = append(topServices, modelnewapi.CredServicePct{Service: sc.Service, Pct: roundTo2(pct), Count: sc.Count})
	}

	activeRegions := []modelnewapi.CredRegionCnt{}
	if c.Region != "" && total > 0 {
		activeRegions = append(activeRegions, modelnewapi.CredRegionCnt{Region: c.Region, Count: total})
	}

	distinctDays, err := s.repo.CountDistinctActiveDays(ctx, db, c.ID, c.ScanID, start, end)
	if err != nil {
		return nil, err
	}
	rangeDays := int(end.Sub(start).Hours()/24) + 1
	if rangeDays <= 0 {
		rangeDays = 1
	}
	usagePattern := "Intermittent"
	switch {
	case distinctDays == 0:
		usagePattern = "Dormant"
	case float64(distinctDays)/float64(rangeDays) >= 0.6:
		usagePattern = "Continuous"
	}

	totalPages := 0
	if pageSize > 0 {
		totalPages = (totalCount + pageSize - 1) / pageSize
	}

	return &modelnewapi.CredentialActivityResponse{
		Tab:                           "activity",
		TimeRange:                     rng.Label,
		VolumeChart:                   volumeChart,
		RecentEvents:                  recentEvents,
		IdentitiesUsingThisCredential: usingIdentities,
		Analytics: modelnewapi.CredActivityAnalytics{
			SourceIPs:     []modelnewapi.CredIPPct{},
			ActiveRegions: activeRegions,
			TopServices:   topServices,
			UsagePattern:  usagePattern,
			ErrorRatePct:  nil,
		},
		EventsPagination: modelnewapi.CredEventsPagination{
			Page: 1, PageSize: pageSize, TotalCount: totalCount, TotalPages: totalPages,
		},
	}, nil
}

// ── tab=rotation ──────────────────────────────────────────────────────

func (s *CredentialDetailService) buildRotation(c *reponewapi.CredentialCoreRow) *modelnewapi.CredentialRotationResponse {
	var timeline []modelnewapi.CredRotationEvent
	if c.CreatedAtAWS.Valid {
		details := "Discovered by scan"
		if c.DiscoverySource.Valid && c.DiscoverySource.String != "" {
			details = "Discovered via " + c.DiscoverySource.String
		}
		timeline = append(timeline, modelnewapi.CredRotationEvent{
			Date: c.CreatedAtAWS.Time.UTC().Format(time.RFC3339), Event: "Created", Details: details,
		})
	}
	if c.LastRotatedAt.Valid && (!c.CreatedAtAWS.Valid || !c.LastRotatedAt.Time.Equal(c.CreatedAtAWS.Time)) {
		timeline = append(timeline, modelnewapi.CredRotationEvent{
			Date: c.LastRotatedAt.Time.UTC().Format(time.RFC3339), Event: "Rotated", Details: "Most recent rotation on record",
		})
	}
	if timeline == nil {
		timeline = []modelnewapi.CredRotationEvent{}
	}

	var nextExpected *string
	if c.RotationEnabled && c.RotationIntervalDays.Valid {
		ref := c.LastRotatedAt
		if !ref.Valid {
			ref = c.CreatedAtAWS
		}
		if ref.Valid {
			t := ref.Time.AddDate(0, 0, int(c.RotationIntervalDays.Int64)).UTC().Format(time.RFC3339)
			nextExpected = &t
		}
	}

	overdue := credRotationOverdue(c)
	return &modelnewapi.CredentialRotationResponse{
		Tab:      "rotation",
		Timeline: timeline,
		Configuration: modelnewapi.CredRotationConfig{
			AutoRotation:         c.RotationEnabled,
			RotationIntervalDays: nullInt64Ptr(c.RotationIntervalDays),
			LastRotation:         timePtrRFC3339FromNull(c.LastRotatedAt),
			NextExpected:         nextExpected,
			Status:               credRotationStatusLabel(c.RotationEnabled, overdue),
			RotationLambdaARN:    nil,
		},
		Lifecycle: modelnewapi.CredRotationLifecycle{
			CreatedAtAWS:      timePtrRFC3339FromNull(c.CreatedAtAWS),
			AgeDays:           credAgeDays(c.CreatedAtAWS, c.FirstSeenAt),
			DaysSinceRotation: credDaysSinceRotation(c.LastRotatedAt, c.CreatedAtAWS),
			ExpiresAt:         timePtrRFC3339FromNull(c.ExpiresAt),
			DaysUntilExpiry:   credDaysUntilExpiry(c.ExpiresAt),
		},
	}
}

// ── tab=relationships ─────────────────────────────────────────────────

func credRelationshipLabel(edgeType, direction string) string {
	et := strings.ToUpper(strings.TrimSpace(edgeType))
	switch {
	case et == "BOUND_TO" && direction == "inbound":
		return "Used by"
	case et == "BOUND_TO" && direction == "outbound":
		return "Bound to"
	case strings.Contains(et, "ASSUME") && direction == "outbound":
		return "Can assume"
	case strings.Contains(et, "ASSUME") && direction == "inbound":
		return "Assumable by"
	case et == "":
		return "Related"
	default:
		return strings.Title(strings.ToLower(strings.ReplaceAll(et, "_", " ")))
	}
}

func (s *CredentialDetailService) buildRelationships(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow, depth int, edgeType string) (*modelnewapi.CredentialRelationshipsResponse, error) {
	var edgeTypes []string
	for _, et := range strings.Split(edgeType, ",") {
		if et = strings.TrimSpace(et); et != "" {
			edgeTypes = append(edgeTypes, et)
		}
	}

	visited := map[string]bool{c.ARN: true}
	frontier := []string{c.ARN}
	var allEdges []reponewapi.CredGraphEdgeRow

	for hop := 0; hop < depth && len(frontier) > 0; hop++ {
		edges, err := s.repo.GetEdgesTouching(ctx, db, c.ScanID, frontier, edgeTypes)
		if err != nil {
			return nil, err
		}
		var next []string
		for _, e := range edges {
			allEdges = append(allEdges, e)
			if !visited[e.Source] {
				visited[e.Source] = true
				next = append(next, e.Source)
			}
			if !visited[e.Target] {
				visited[e.Target] = true
				next = append(next, e.Target)
			}
		}
		frontier = next
	}

	arns := make([]string, 0, len(visited))
	for a := range visited {
		arns = append(arns, a)
	}
	nodeInfo, err := s.repo.ResolveNodes(ctx, db, c.ScanID, arns)
	if err != nil {
		return nil, err
	}

	nodes := make([]modelnewapi.CredGraphNode, 0, len(arns))
	for _, arn := range arns {
		info := nodeInfo[arn]
		nodes = append(nodes, modelnewapi.CredGraphNode{
			ARN: arn, Name: nullStringOrEmpty(info.Name), Type: info.NodeType,
			Subtype: nullStringOrEmpty(info.Subtype), IsCurrent: arn == c.ARN,
		})
	}
	sort.Slice(nodes, func(i, j int) bool { return nodes[i].ARN < nodes[j].ARN })

	edges := make([]modelnewapi.CredGraphEdge, 0, len(allEdges))
	relTable := make([]modelnewapi.CredRelationshipRow, 0)
	for _, e := range allEdges {
		lastObserved := timePtrRFC3339FromNull(e.CreatedAt)
		edges = append(edges, modelnewapi.CredGraphEdge{
			Source: e.Source, Target: e.Target, EdgeType: nullStringOrEmpty(e.EdgeType), LastObservedAt: lastObserved,
		})
		if e.Source != c.ARN && e.Target != c.ARN {
			continue
		}
		direction := "outbound"
		targetArn := e.Target
		if e.Target == c.ARN {
			direction = "inbound"
			targetArn = e.Source
		}
		info := nodeInfo[targetArn]
		lastActive := lastObserved
		if info.NodeType == "identity" && info.LastActivityAt.Valid {
			lastActive = timePtrRFC3339FromNull(info.LastActivityAt)
		}
		relTable = append(relTable, modelnewapi.CredRelationshipRow{
			Relationship: credRelationshipLabel(nullStringOrEmpty(e.EdgeType), direction),
			Direction:    direction,
			TargetARN:    targetArn,
			TargetName:   nullStringOrEmpty(info.Name),
			TargetType:   info.NodeType,
			LastActive:   lastActive,
		})
	}

	return &modelnewapi.CredentialRelationshipsResponse{
		Tab:               "relationships",
		Graph:             modelnewapi.CredRelationshipGraph{Nodes: nodes, Edges: edges},
		RelationshipTable: relTable,
	}, nil
}

// ── tab=raw ───────────────────────────────────────────────────────────

func (s *CredentialDetailService) buildRaw(ctx context.Context, db *sql.DB, c *reponewapi.CredentialCoreRow) (*modelnewapi.CredentialRawResponse, error) {
	effRaw, err := s.repo.GetEffectivePermissionsRaw(ctx, db, c.ID, c.ScanID)
	if err != nil {
		return nil, err
	}

	record := map[string]interface{}{
		"id":                      c.ID,
		"arn":                     c.ARN,
		"name":                    c.Name,
		"credential_type":         c.CredentialType,
		"account_id":              c.AccountID,
		"region":                  c.Region,
		"status":                  c.Status,
		"created_at_aws":          timePtrRFC3339FromNull(c.CreatedAtAWS),
		"first_seen_at":           timePtrRFC3339FromNull(c.FirstSeenAt),
		"last_seen_at":            timePtrRFC3339FromNull(c.LastSeenAt),
		"deleted_at":              timePtrRFC3339FromNull(c.DeletedAt),
		"last_used_at":            timePtrRFC3339FromNull(c.LastUsedAt),
		"last_rotated_at":         timePtrRFC3339FromNull(c.LastRotatedAt),
		"expires_at":              timePtrRFC3339FromNull(c.ExpiresAt),
		"rotation_enabled":        c.RotationEnabled,
		"rotation_interval_days":  nullInt64Ptr(c.RotationIntervalDays),
		"tags":                    credDecodeJSON(c.Tags),
		"owner_principal_arn":     nullStringPtr(c.OwnerPrincipalARN),
		"trust_policy":            credDecodeJSON(c.TrustPolicy),
		"attached_policies":       credDecodeJSON(c.AttachedPolicies),
		"inline_policies":         credDecodeJSON(c.InlinePolicies),
		"permission_boundary_arn": nullStringPtr(c.PermissionBoundaryARN),
		"max_session_duration":    nullInt64Ptr(c.MaxSessionDuration),
		"privilege_level":         nullInt64Ptr(c.PrivilegeLevel),
		"assumable_role_arns":     credDecodeJSON(c.AssumableRoleARNs),
		"discovery_source":        nullStringPtr(c.DiscoverySource),
		"scan_id":                 c.ScanID,
		"type_attributes":         credDecodeJSON(c.TypeAttributes),
		"raw_api_response":        credDecodeJSON(c.RawAPIResponse),
		"created_at":              timePtrRFC3339FromNull(c.CreatedAt),
		"updated_at":              timePtrRFC3339FromNull(c.UpdatedAt),
	}

	return &modelnewapi.CredentialRawResponse{
		Tab:                  "raw",
		CredentialRecord:     record,
		RawAPIResponse:       credDecodeJSON(c.RawAPIResponse),
		TrustPolicy:          credDecodeJSON(c.TrustPolicy),
		AttachedPolicies:     credDecodeJSON(c.AttachedPolicies),
		InlinePolicies:       credDecodeJSON(c.InlinePolicies),
		TypeAttributes:       credDecodeJSON(c.TypeAttributes),
		EffectivePermissions: credDecodeJSON(effRaw),
	}, nil
}