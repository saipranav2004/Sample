package newapi

import (
	"context"
	"fmt"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

type FilterOptionsService struct {
	dbm   *database.Manager
	repo  *reponewapi.FilterOptionsRepository
	scans *reponewapi.ScanRepository
}

func NewFilterOptionsService(
	dbm *database.Manager,
	repo *reponewapi.FilterOptionsRepository,
	scans *reponewapi.ScanRepository,
) *FilterOptionsService {
	return &FilterOptionsService{dbm: dbm, repo: repo, scans: scans}
}

// Get implements Endpoint 2 — every dropdown source in one response.
func (s *FilterOptionsService) Get(ctx context.Context, id Identity) (*modelnewapi.FilterOptionsResponse, error) {
	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	scan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
	if err != nil {
		return nil, err
	}
	scanID := ""
	if scan != nil {
		scanID = scan.ScanID
	}
	// No completed scan at all → scanID == "" matches no rows →
	// empty dropdown lists (fail-closed), not an error.

	accounts, err := s.repo.Accounts(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	regions, err := s.repo.Regions(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	scanList, err := s.repo.Scans(ctx, tenantDB)
	if err != nil {
		return nil, err
	}
	idTypes, err := s.repo.IdentityTypes(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	classes, err := s.repo.FunctionalClasses(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	credTypes, err := s.repo.CredentialTypes(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	envs, err := s.repo.Environments(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}
	statuses, err := s.repo.Statuses(ctx, tenantDB, scanID)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.FilterOptionsResponse{}

	resp.Accounts = make([]modelnewapi.AccountOption, 0, len(accounts))
	for _, a := range accounts {
		resp.Accounts = append(resp.Accounts, modelnewapi.AccountOption{
			AccountID:       a.AccountID,
			IdentityCount:   a.IdentityCount,
			CredentialCount: a.CredentialCount,
			IsDefault:       a.IsDefault,
		})
	}

	resp.Regions = make([]modelnewapi.RegionOption, 0, len(regions))
	for _, r := range regions {
		resp.Regions = append(resp.Regions, modelnewapi.RegionOption{Region: r.Label, Count: r.Count})
	}

	resp.Scans = make([]modelnewapi.ScanOption, 0, len(scanList))
	for _, sc := range scanList {
		item := modelnewapi.ScanOption{
			ScanID:           sc.ScanID,
			Status:           sc.Status,
			TotalIdentities:  sc.TotalIdentities,
			TotalCredentials: sc.TotalCredentials,
		}
		if sc.ScanEnd != nil {
			ts := sc.ScanEnd.UTC().Format(time.RFC3339)
			item.ScanEnd = &ts
		}
		resp.Scans = append(resp.Scans, item)
	}

	resp.IdentityTypes = toTypeCounts(idTypes)
	resp.FunctionalClasses = toClassCounts(classes)
	resp.CredentialTypes = toTypeCounts(credTypes)
	resp.Environments = toEnvCounts(envs)
	resp.Statuses = toStatusCounts(statuses)

	return resp, nil
}

func toTypeCounts(lcs []reponewapi.LabelCount) []modelnewapi.TypeCount {
	out := make([]modelnewapi.TypeCount, 0, len(lcs))
	for _, l := range lcs {
		out = append(out, modelnewapi.TypeCount{Type: l.Label, Count: l.Count})
	}
	return out
}

func toClassCounts(lcs []reponewapi.LabelCount) []modelnewapi.ClassCount {
	out := make([]modelnewapi.ClassCount, 0, len(lcs))
	for _, l := range lcs {
		out = append(out, modelnewapi.ClassCount{Class: l.Label, Count: l.Count})
	}
	return out
}

func toEnvCounts(lcs []reponewapi.LabelCount) []modelnewapi.EnvironmentCount {
	out := make([]modelnewapi.EnvironmentCount, 0, len(lcs))
	for _, l := range lcs {
		out = append(out, modelnewapi.EnvironmentCount{Environment: l.Label, Count: l.Count})
	}
	return out
}

func toStatusCounts(lcs []reponewapi.LabelCount) []modelnewapi.StatusCount {
	out := make([]modelnewapi.StatusCount, 0, len(lcs))
	for _, l := range lcs {
		out = append(out, modelnewapi.StatusCount{Status: l.Label, Count: l.Count})
	}
	return out
}