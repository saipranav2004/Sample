package newapi

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

// IdentitiesListValidationError is a dedicated validation error type for this
// endpoint (kept separate from UpdateValidationError to avoid guessing at its
// internal field layout from another file).
type IdentitiesListValidationError struct{ Msg string }

func (e *IdentitiesListValidationError) Error() string { return e.Msg }

// IdentitiesListParams are the raw (unvalidated) query-string values.
type IdentitiesListParams struct {
	Page                 string
	PageSize             string
	Search               string
	IdentityType         []string
	FunctionalClass      []string
	Environment          []string
	Status               []string
	Owner                string
	VpcID                string
	IsPubliclyAccessible string
	MinIdleDays          string
	SortBy               string
	SortOrder            string
}

type IdentitiesListService struct {
	dbm   *database.Manager
	repo  *reponewapi.IdentitiesListRepository
	scans *reponewapi.ScanRepository
}

func NewIdentitiesListService(
	dbm *database.Manager,
	repo *reponewapi.IdentitiesListRepository,
	scans *reponewapi.ScanRepository,
) *IdentitiesListService {
	return &IdentitiesListService{dbm: dbm, repo: repo, scans: scans}
}

// List implements Endpoint 4 — paginated, searchable, filterable, sortable.
func (s *IdentitiesListService) List(ctx context.Context, id Identity, p IdentitiesListParams) (*modelnewapi.IdentitiesListResponse, error) {
	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	// ── 1. Pagination ───────────────────────────────────────────────────
	page := 1
	if p.Page != "" {
		v, err := strconv.Atoi(p.Page)
		if err != nil || v < 1 {
			return nil, &IdentitiesListValidationError{Msg: "page must be a positive integer"}
		}
		page = v
	}
	pageSize := 25
	if p.PageSize != "" {
		v, err := strconv.Atoi(p.PageSize)
		if err != nil || v < 1 {
			return nil, &IdentitiesListValidationError{Msg: "page_size must be a positive integer"}
		}
		if v > 100 {
			v = 100
		}
		pageSize = v
	}

	// ── 2. Filters ──────────────────────────────────────────────────────
	var isPublic *bool
	if strings.TrimSpace(p.IsPubliclyAccessible) != "" {
		v, err := strconv.ParseBool(p.IsPubliclyAccessible)
		if err != nil {
			return nil, &IdentitiesListValidationError{Msg: "is_publicly_accessible must be true or false"}
		}
		isPublic = &v
	}

	var minIdleDays *int
	if strings.TrimSpace(p.MinIdleDays) != "" {
		v, err := strconv.Atoi(p.MinIdleDays)
		if err != nil || v < 0 {
			return nil, &IdentitiesListValidationError{Msg: "min_idle_days must be a non-negative integer"}
		}
		minIdleDays = &v
	}

	sortBy := strings.TrimSpace(p.SortBy)
	if sortBy == "" {
		sortBy = "last_activity_at"
	}
	sortColumn, ok := reponewapi.IdentitiesSortColumnAllowed(sortBy)
	if !ok {
		return nil, &IdentitiesListValidationError{Msg: fmt.Sprintf("sort_by %q is not a recognized column", sortBy)}
	}

	sortOrder := strings.TrimSpace(p.SortOrder)
	if sortOrder == "" {
		sortOrder = "desc"
	}
	if !strings.EqualFold(sortOrder, "asc") && !strings.EqualFold(sortOrder, "desc") {
		return nil, &IdentitiesListValidationError{Msg: "sort_order must be asc or desc"}
	}

	// ── 3. Resolve scan scope (latest COMPLETED) ───────────────────────
	scan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
	if err != nil {
		return nil, err
	}
	scanID := ""
	if scan != nil {
		scanID = scan.ScanID
	}
	// No completed scan → scanID == "" matches no rows → empty page, not an error.

	filter := reponewapi.IdentitiesListFilter{
		ScanID:               scanID,
		Search:               p.Search,
		IdentityTypes:        p.IdentityType,
		FunctionalClasses:    p.FunctionalClass,
		Environments:         p.Environment,
		Statuses:             p.Status,
		Owner:                p.Owner,
		VpcID:                p.VpcID,
		IsPubliclyAccessible: isPublic,
		MinIdleDays:          minIdleDays,
		SortColumn:           sortColumn,
		SortOrder:            strings.ToUpper(sortOrder),
		Page:                 page,
		PageSize:             pageSize,
	}

	// ── 4. Query ────────────────────────────────────────────────────────
	total, err := s.repo.Count(ctx, tenantDB, filter)
	if err != nil {
		return nil, err
	}
	rows, err := s.repo.List(ctx, tenantDB, filter)
	if err != nil {
		return nil, err
	}

	// ── 5. Shape response ───────────────────────────────────────────────
	totalPages := 0
	if pageSize > 0 {
		totalPages = (total + pageSize - 1) / pageSize
	}

	resp := &modelnewapi.IdentitiesListResponse{
		Pagination: modelnewapi.Pagination{
			Page:       page,
			PageSize:   pageSize,
			TotalCount: total,
			TotalPages: totalPages,
		},
		Data: make([]modelnewapi.IdentityListItem, 0, len(rows)),
	}

	for _, r := range rows {
		item := modelnewapi.IdentityListItem{
			ID:                       r.ID,
			Name:                     r.Name,
			ARN:                      r.ARN,
			IdentityType:             r.IdentityType,
			FunctionalClass:          r.FunctionalClass,
			AccountID:                r.AccountID,
			Region:                   r.Region,
			Environment:              r.Environment,
			Owner:                    r.Owner,
			Status:                   r.Status,
			IsPubliclyAccessible:     r.IsPubliclyAccessible,
			BoundCredentialsCount:    r.BoundCredentialsCount,
			AgeDays:                  r.AgeDays,
			IdleDays:                 r.IdleDays,
			CreatedBy:                r.CreatedBy,
			PermissionUtilizationPct: utilizationPct(r.UsedCount, r.GrantedCount), // shared formula — Endpoint 3 uses the same one
		}
		if r.VpcID.Valid {
			v := r.VpcID.String
			item.VpcID = &v
		}
		if r.LastActivityAt != nil {
			ts := r.LastActivityAt.UTC().Format(time.RFC3339)
			item.LastActivityAt = &ts
		}
		if r.CreatedAtAWS != nil {
			ts := r.CreatedAtAWS.UTC().Format(time.RFC3339)
			item.CreatedAtAWS = &ts
		}
		resp.Data = append(resp.Data, item)
	}

	return resp, nil
}