package newapi

import (
	"context"
	"fmt"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

type SettingsService struct {
	dbm      *database.Manager
	settings *reponewapi.SettingsRepository
	scans    *reponewapi.ScanRepository
}

// NewSettingsService takes the DB manager (to resolve the tenant data DB per
// request from the JWT) plus the two repositories built in main.go.
func NewSettingsService(dbm *database.Manager, settings *reponewapi.SettingsRepository, scans *reponewapi.ScanRepository) *SettingsService {
	return &SettingsService{dbm: dbm, settings: settings, scans: scans}
}

// Identity is what the JWT tells us about the caller.
type Identity struct {
	UserID   string
	TenantID string
	DBName   string
}

// Get implements Endpoint 1A — load the user's filter preferences and fall
// back to the tenant's account defaults for anything the user has not saved.
//
//	accounts / regions : user_settings (global DB) → else accounts.is_default rows
//	scan               : user's selected_scan_id (validated in tenant DB) → else latest COMPLETED scan
func (s *SettingsService) Get(ctx context.Context, id Identity) (*modelnewapi.SettingsResponse, error) {
	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	user, err := s.settings.GetUserSettings(ctx, tenantDB, id.UserID)
	if err != nil {
		return nil, err
	}
	defaults, err := s.settings.GetDefaultAccounts(ctx, tenantDB, id.TenantID)
	if err != nil {
		return nil, err
	}
	
	resp := &modelnewapi.SettingsResponse{Source: "accounts"}
	usedUser := false

	// ── accounts ───────────────────────────────────────────────────────────
	if user != nil && len(user.SelectedAccountIDs) > 0 {
		resp.Settings.Accounts = modelnewapi.SelectionSetting{Selected: user.SelectedAccountIDs}
		usedUser = true
	} else {
		resp.Settings.Accounts = modelnewapi.SelectionSetting{Selected: uniqueAccounts(defaults), IsDefault: true}
	}

	// ── regions ────────────────────────────────────────────────────────────
	if user != nil && len(user.SelectedRegions) > 0 {
		resp.Settings.Regions = modelnewapi.SelectionSetting{Selected: user.SelectedRegions}
		usedUser = true
	} else {
		resp.Settings.Regions = modelnewapi.SelectionSetting{Selected: uniqueRegions(defaults), IsDefault: true}
	}

	// ── scan ───────────────────────────────────────────────────────────────
	var effective *reponewapi.ScanInfo
	if user != nil && user.SelectedScanID != nil {
		resp.Settings.Scan.SelectedScanID = user.SelectedScanID
		effective, err = s.scans.GetCompletedScan(ctx, tenantDB, *user.SelectedScanID)
		if err != nil {
			return nil, err
		}
		if effective != nil {
			usedUser = true
		} else {
			// Saved scan no longer exists / is not completed → forget it, use latest.
			resp.Settings.Scan.SelectedScanID = nil
		}
	}
	if effective == nil {
		effective, err = s.scans.GetLatestCompletedScan(ctx, tenantDB)
		if err != nil {
			return nil, err
		}
		resp.Settings.Scan.IsDefault = true
	}
	if effective != nil {
		sid := effective.ScanID
		resp.Settings.Scan.EffectiveScanID = &sid
		if effective.ScanEnd != nil {
			ts := effective.ScanEnd.UTC().Format(time.RFC3339)
			resp.Settings.Scan.EffectiveScanTime = &ts
		}
	}

	if usedUser {
		resp.Source = "user_settings"
	}
	return resp, nil
}

func uniqueAccounts(rows []reponewapi.DefaultAccountRow) []string {
	return uniqueNonEmpty(rows, func(r reponewapi.DefaultAccountRow) string { return r.AccountID })
}

func uniqueRegions(rows []reponewapi.DefaultAccountRow) []string {
	return uniqueNonEmpty(rows, func(r reponewapi.DefaultAccountRow) string { return r.Region })
}

// uniqueNonEmpty keeps first-seen order and always returns a non-nil slice so
// the JSON is [] rather than null.
func uniqueNonEmpty(rows []reponewapi.DefaultAccountRow, pick func(reponewapi.DefaultAccountRow) string) []string {
	seen := make(map[string]struct{}, len(rows))
	out := make([]string, 0, len(rows))
	for _, r := range rows {
		v := pick(r)
		if v == "" {
			continue
		}
		if _, dup := seen[v]; dup {
			continue
		}
		seen[v] = struct{}{}
		out = append(out, v)
	}
	return out
}
