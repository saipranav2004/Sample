// package newapi

// import (
// 	"fmt"
// 	"strconv"
// 	"strings"
// )

// // ParseTimeRange normalizes a time_range query value into a day-count used
// // for SQL filtering AND a canonical label that MUST be echoed back in the
// // response (never echo the raw/unnormalized query param).
// //
// // Accepts: "", "90d", "30d", "30" (bare number), "all".
// // Invalid/garbage input falls back to the 90-day default.
// //
// // Shared by Credential Detail (activity tab) and Identity Detail (activity tab)
// // so both endpoints behave identically for the same input.
// func ParseTimeRange(tr string) (days int, label string) {
// 	tr = strings.ToLower(strings.TrimSpace(tr))
// 	if tr == "" {
// 		return 90, "90d"
// 	}
// 	if tr == "all" {
// 		return 36500, "all"
// 	}
// 	numPart := strings.TrimSuffix(tr, "d")
// 	n, err := strconv.Atoi(numPart)
// 	if err != nil || n <= 0 {
// 		return 90, "90d"
// 	}
// 	return n, fmt.Sprintf("%dd", n)
// }
















package newapi

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

// TimeRangeError is a client mistake in time_range (HTTP 400).
// Each service converts it into its own validation error.
type TimeRangeError struct{ Msg string }

func (e *TimeRangeError) Error() string { return e.Msg }

// ResolvedTimeRange is the shared result of resolving ?time_range=.
// The window is a rolling one ending now (UTC).
type ResolvedTimeRange struct {
	Days  int       // number of days in the window
	Start time.Time // now - Days
	End   time.Time // now
	Label string    // canonical label echoed back: "55d" or "all"
}

const maxRangeDays = 36500 // ~100 years

// ResolveTimeRange is shared by Identity Detail and Credential Detail so both
// endpoints behave identically for the same input.
//
//	""            → 90 days (default)
//	"1", "55"     → that many days (bare number)
//	"7d", "30d"   → that many days (optional "d" suffix)
//	"all"         → everything
//
// Anything else (0, negative, text, > 36500) → TimeRangeError (400) instead of
// silently falling back to a default.
func ResolveTimeRange(timeRange string) (*ResolvedTimeRange, error) {
	now := time.Now().UTC()
	tr := strings.ToLower(strings.TrimSpace(timeRange))
	if tr == "" {
		tr = "90"
	}

	if tr == "all" {
		return &ResolvedTimeRange{Days: maxRangeDays, Start: now.AddDate(0, 0, -maxRangeDays), End: now, Label: "all"}, nil
	}

	n, err := strconv.Atoi(strings.TrimSuffix(tr, "d"))
	if err != nil || n < 1 || n > maxRangeDays {
		return nil, &TimeRangeError{Msg: fmt.Sprintf("time_range %q is not valid: use a number of days (e.g. 1, 7, 55) or \"all\"", timeRange)}
	}
	return &ResolvedTimeRange{Days: n, Start: now.AddDate(0, 0, -n), End: now, Label: fmt.Sprintf("%dd", n)}, nil
}