// package newapi

// import (
// 	"context"
// 	"database/sql"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"strconv"
// 	"strings"
// 	"time"

// 	"nhi-backend-api/internal/database"
// 	modelnewapi "nhi-backend-api/internal/models/new_api"
// 	reponewapi "nhi-backend-api/internal/repository/new_api"
// )

// // ── Errors ───────────────────────────────────────────────────────────────

// type IdentityDetailValidationError struct{ Msg string }

// func (e *IdentityDetailValidationError) Error() string { return e.Msg }

// type IdentityDetailNotFoundError struct{ Msg string }

// func (e *IdentityDetailNotFoundError) Error() string { return e.Msg }

// // ── Params ───────────────────────────────────────────────────────────────

// type IdentityDetailParams struct {
// 	Tab       string
// 	TimeRange string
// 	StartDate string
// 	EndDate   string
// 	Service   string
// 	UsedOnly  string
// 	Depth     string
// 	EdgeType  string
// 	Page      string
// 	PageSize  string
// }

// var identityDetailTabs = map[string]bool{
// 	"overview":      true,
// 	"permissions":   true,
// 	"activity":      true,
// 	"relationships": true,
// 	"credentials":   true,
// 	"raw":           true,
// }

// var requiredIdentityTags = []string{"Name", "Environment", "Owner", "Team", "CostCenter", "Project"}

// type IdentityDetailService struct {
// 	dbm   *database.Manager
// 	repo  *reponewapi.IdentityDetailRepository
// 	scans *reponewapi.ScanRepository
// }

// func NewIdentityDetailService(dbm *database.Manager, repo *reponewapi.IdentityDetailRepository, scans *reponewapi.ScanRepository) *IdentityDetailService {
// 	return &IdentityDetailService{dbm: dbm, repo: repo, scans: scans}
// }

// func (s *IdentityDetailService) Get(ctx context.Context, id Identity, identityID string, p IdentityDetailParams) (interface{}, error) {
// 	if strings.TrimSpace(identityID) == "" {
// 		return nil, &IdentityDetailValidationError{Msg: "identity id is required"}
// 	}

// 	tenantDB, err := s.dbm.Tenant(id.DBName)
// 	if err != nil {
// 		return nil, fmt.Errorf("resolve tenant database: %w", err)
// 	}

// 	tab := strings.TrimSpace(strings.ToLower(p.Tab))
// 	if tab == "" {
// 		tab = "overview"
// 	}
// 	if !identityDetailTabs[tab] {
// 		return nil, &IdentityDetailValidationError{Msg: fmt.Sprintf("tab %q is not recognized", tab)}
// 	}

// 	scan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
// 	if err != nil {
// 		return nil, err
// 	}
// 	if scan == nil {
// 		return nil, &IdentityDetailNotFoundError{Msg: "no completed scan available"}
// 	}
// 	scanID := scan.ScanID

// 	exists, err := s.repo.IdentityExists(ctx, tenantDB, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}
// 	if !exists {
// 		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
// 	}

// 	switch tab {
// 	case "overview":
// 		return s.getOverview(ctx, tenantDB, scanID, identityID)
// 	case "permissions":
// 		return s.getPermissions(ctx, tenantDB, scanID, identityID, p)
// 	case "activity":
// 		return s.getActivity(ctx, tenantDB, scanID, identityID, p)
// 	case "relationships":
// 		return s.getRelationships(ctx, tenantDB, scanID, identityID, p)
// 	case "credentials":
// 		return s.getCredentials(ctx, tenantDB, scanID, identityID)
// 	case "raw":
// 		return s.getRaw(ctx, tenantDB, scanID, identityID)
// 	default:
// 		return nil, &IdentityDetailValidationError{Msg: "tab not implemented"}
// 	}
// }

// // ── overview ─────────────────────────────────────────────────────────────

// func (s *IdentityDetailService) getOverview(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityOverviewResponse, error) {
// 	row, err := s.repo.GetOverview(ctx, db, scanID, identityID)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
// 	}
// 	if err != nil {
// 		return nil, err
// 	}

// 	boundRows, err := s.repo.GetBoundCredentials(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	hasWildcard, err := s.repo.HasWildcardResourceScope(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	risk, err := s.repo.GetPrimaryCredentialRisk(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	var sgIDs []string
// 	_ = json.Unmarshal(row.SecurityGroupIDs, &sgIDs)

// 	resp := &modelnewapi.IdentityOverviewResponse{
// 		Tab: "overview",
// 		Identity: modelnewapi.IdentityOverviewCore{
// 			ID:                   row.ID,
// 			Name:                 row.Name,
// 			ARN:                  row.ARN,
// 			IdentityType:         row.IdentityType,
// 			FunctionalClass:      row.FunctionalClass,
// 			Category:             deriveCategory(row.IdentityType),
// 			AccountID:            row.AccountID,
// 			Region:               row.Region,
// 			VpcID:                nullStringPtr(row.VpcID),
// 			SubnetID:             nullStringPtr(row.SubnetID),
// 			SecurityGroupIDs:     sgIDs,
// 			Environment:          row.Environment,
// 			Owner:                row.Owner,
// 			Status:               row.Status,
// 			IsPubliclyAccessible: row.IsPubliclyAccessible,
// 			CreatedAtAWS:         timePtrRFC3339(row.CreatedAtAWS),
// 			AgeDays:              row.AgeDays,
// 			FirstSeenAt:          timePtrRFC3339(row.FirstSeenAt),
// 			LastSeenAt:           timePtrRFC3339(row.LastSeenAt),
// 			LastActivityAt:       timePtrRFC3339(row.LastActivityAt),
// 			IdleDays:             row.IdleDays,
// 			ParentARN:            nullStringPtr(row.ParentARN),
// 			CreatedBy:            row.CreatedBy,
// 		},
// 		TypeAttributes: json.RawMessage(row.TypeAttributes),
// 		Tags:           json.RawMessage(row.Tags),
// 	}

// 	// discovery_source exists as a real column; credential_resolution,
// 	// last_scanned and data_sources do not — all three are derived here.
// 	primaryBindingType := ""
// 	for _, b := range boundRows {
// 		if b.IsPrimary {
// 			primaryBindingType = b.BindingType
// 			break
// 		}
// 	}
// 	dataSources := "AWS API"
// 	if row.LastActivityAt != nil {
// 		dataSources = "AWS API + CloudTrail correlation"
// 	}
// 	resp.Discovery = modelnewapi.IdentityDiscovery{
// 		DiscoverySource:      row.DiscoverySource.String,
// 		CredentialResolution: bindingTypeLabel(primaryBindingType),
// 		ScanID:               row.ScanID,
// 		LastScanned:          timePtrRFC3339(row.UpdatedAt), // proxy — no dedicated last_scanned_at column
// 		DataSources:          dataSources,
// 	}

// 	for _, b := range boundRows {
// 		resp.BoundCredentials = append(resp.BoundCredentials, modelnewapi.BoundCredentialSummary{
// 			CredentialID:          b.CredentialID,
// 			Name:                  b.Name,
// 			CredentialType:        b.CredentialType,
// 			BindingType:           b.BindingType,
// 			IsPrimary:             b.IsPrimary,
// 			TrustPrincipal:        b.TrustPrincipal,
// 			AttachedPoliciesCount: b.AttachedPoliciesCount,
// 			InlinePoliciesCount:   b.InlinePoliciesCount,
// 			GrantedActionsCount:   int(b.GrantedCount),
// 			UsedActionsCount:      int(b.UsedCount),
// 			UtilizationPct:        utilizationPct(b.UsedCount, b.GrantedCount),
// 		})
// 	}
// 	if resp.BoundCredentials == nil {
// 		resp.BoundCredentials = []modelnewapi.BoundCredentialSummary{}
// 	}

// 	resp.MissingTags = computeMissingTags(row.Tags, requiredIdentityTags)
// 	resp.RiskSignals = computeRiskSignals(row, hasWildcard, risk)

// 	return resp, nil
// }

// func computeMissingTags(tagsJSON []byte, required []string) []string {
// 	present := map[string]bool{}
// 	var m map[string]interface{}
// 	if len(tagsJSON) > 0 {
// 		_ = json.Unmarshal(tagsJSON, &m)
// 	}
// 	for k := range m {
// 		present[k] = true
// 	}
// 	missing := []string{}
// 	for _, r := range required {
// 		if !present[r] {
// 			missing = append(missing, r)
// 		}
// 	}
// 	return missing
// }

// func computeRiskSignals(row *reponewapi.OverviewRow, hasWildcard bool, risk *reponewapi.PrimaryCredentialRiskRow) []modelnewapi.RiskSignal {
// 	neverRotated := false
// 	expiredOrExpiring := false
// 	crossAccount := false

// 	if risk != nil {
// 		neverRotated = risk.LastRotatedAt == nil
// 		if risk.ExpiresAt != nil {
// 			expiredOrExpiring = risk.ExpiresAt.Before(time.Now().UTC().Add(30 * 24 * time.Hour))
// 		}
// 		crossAccount = isCrossAccountTrust(risk.TrustPolicy, row.AccountID)
// 	}

// 	return []modelnewapi.RiskSignal{
// 		{Signal: "Publicly accessible", Status: row.IsPubliclyAccessible, Severity: "critical"},
// 		{Signal: "Stale (no activity > 90d)", Status: row.IdleDays > 90, Severity: "high"},
// 		{Signal: "No owner attribution", Status: strings.TrimSpace(row.Owner) == "", Severity: "medium"},
// 		{Signal: "Credential never rotated", Status: neverRotated, Severity: "high"},
// 		{Signal: "Credential expired/expiring", Status: expiredOrExpiring, Severity: "critical"},
// 		{Signal: "Cross-account trust", Status: crossAccount, Severity: "medium"},
// 		{Signal: "Wildcard resource scope", Status: hasWildcard, Severity: "high"},
// 		{Signal: "No VPC", Status: !row.VpcID.Valid, Severity: "medium"},
// 	}
// }

// func deriveCategory(identityType string) string {
// 	switch strings.ToLower(strings.TrimSpace(identityType)) {
// 	case "ec2_instance", "lambda_function", "ecs_task", "ecs_service", "fargate_task", "batch_job":
// 		return "Compute"
// 	case "iam_role", "iam_user", "iam_group", "sso_user", "federated_identity":
// 		return "Identity"
// 	case "s3_bucket", "ebs_volume", "efs_filesystem", "fsx_filesystem":
// 		return "Storage"
// 	case "rds_instance", "dynamodb_table", "redshift_cluster", "elasticache_cluster":
// 		return "Database"
// 	case "api_gateway", "load_balancer", "cloudfront_distribution", "vpc_endpoint":
// 		return "Networking"
// 	case "secrets_manager_secret", "kms_key", "ssm_parameter":
// 		return "Security"
// 	default:
// 		return "Other"
// 	}
// }

// func bindingTypeLabel(bindingType string) string {
// 	switch strings.ToLower(strings.TrimSpace(bindingType)) {
// 	case "instance_profile":
// 		return "IAM instance profile association"
// 	case "assume_role":
// 		return "STS AssumeRole"
// 	case "access_key":
// 		return "Static access key attachment"
// 	case "execution_role":
// 		return "Execution role binding"
// 	case "service_linked_role":
// 		return "Service-linked role"
// 	case "":
// 		return "Unresolved"
// 	default:
// 		return bindingType
// 	}
// }

// // ── trust policy parsing (used by overview risk signals + credentials tab) ──

// type trustPrincipalOut struct {
// 	Principal  interface{} `json:"principal"`
// 	Type       string      `json:"type"`
// 	Condition  interface{} `json:"condition"`
// 	IsExternal bool        `json:"is_external"`
// }

// func buildTrustPrincipals(trustPolicy []byte, accountID, fallbackARN string) json.RawMessage {
// 	out := []trustPrincipalOut{}

// 	var doc map[string]interface{}
// 	if len(trustPolicy) > 0 && json.Unmarshal(trustPolicy, &doc) == nil {
// 		var stmts []interface{}
// 		switch v := doc["Statement"].(type) {
// 		case []interface{}:
// 			stmts = v
// 		case map[string]interface{}:
// 			stmts = []interface{}{v}
// 		}
// 		for _, s := range stmts {
// 			stmt, ok := s.(map[string]interface{})
// 			if !ok {
// 				continue
// 			}
// 			cond := stmt["Condition"]
// 			switch p := stmt["Principal"].(type) {
// 			case string:
// 				out = append(out, trustPrincipalOut{Principal: p, Type: "*", Condition: cond, IsExternal: p == "*"})
// 			case map[string]interface{}:
// 				for ptype, pval := range p {
// 					isExternal := false
// 					if ptype == "AWS" {
// 						isExternal = !principalContainsAccount(pval, accountID)
// 					}
// 					out = append(out, trustPrincipalOut{Principal: pval, Type: ptype, Condition: cond, IsExternal: isExternal})
// 				}
// 			}
// 		}
// 	}

// 	if len(out) == 0 && strings.TrimSpace(fallbackARN) != "" {
// 		out = append(out, trustPrincipalOut{
// 			Principal:  fallbackARN,
// 			Type:       "AWS",
// 			IsExternal: !principalContainsAccount(fallbackARN, accountID),
// 		})
// 	}

// 	b, _ := json.Marshal(out)
// 	return json.RawMessage(b)
// }

// func principalContainsAccount(v interface{}, accountID string) bool {
// 	if strings.TrimSpace(accountID) == "" {
// 		return true // can't determine → assume same-account, avoid false positives
// 	}
// 	switch val := v.(type) {
// 	case string:
// 		return strings.Contains(val, accountID)
// 	case []interface{}:
// 		for _, item := range val {
// 			if s, ok := item.(string); ok && strings.Contains(s, accountID) {
// 				return true
// 			}
// 		}
// 	}
// 	return false
// }

// func isCrossAccountTrust(trustPolicy []byte, accountID string) bool {
// 	raw := buildTrustPrincipals(trustPolicy, accountID, "")
// 	var list []trustPrincipalOut
// 	_ = json.Unmarshal(raw, &list)
// 	for _, p := range list {
// 		if p.IsExternal {
// 			return true
// 		}
// 	}
// 	return false
// }

// // ── permissions ─────────────────────────────────────────────────────────

// func (s *IdentityDetailService) getPermissions(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityPermissionsResponse, error) {
// 	var usedOnly *bool
// 	if strings.TrimSpace(p.UsedOnly) != "" {
// 		v, err := strconv.ParseBool(p.UsedOnly)
// 		if err != nil {
// 			return nil, &IdentityDetailValidationError{Msg: "used_only must be true or false"}
// 		}
// 		usedOnly = &v
// 	}

// 	summary, err := s.repo.GetPermissionsSummary(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	filter := reponewapi.PermissionsFilter{Service: p.Service, UsedOnly: usedOnly}
// 	permRows, err := s.repo.ListPermissions(ctx, db, scanID, identityID, filter)
// 	if err != nil {
// 		return nil, err
// 	}

// 	breakdownRows, err := s.repo.GetPolicyBreakdown(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	resp := &modelnewapi.IdentityPermissionsResponse{
// 		Tab: "permissions",
// 		Summary: modelnewapi.PermissionsSummary{
// 			GrantedCount:   summary.GrantedCount,
// 			UsedCount:      summary.UsedCount,
// 			UnusedCount:    summary.GrantedCount - summary.UsedCount,
// 			UtilizationPct: utilizationPct(int64(summary.UsedCount), int64(summary.GrantedCount)),
// 		},
// 		Permissions:     []modelnewapi.PermissionItem{},
// 		PolicyBreakdown: []modelnewapi.PolicyBreakdownRow{},
// 	}

// 	for _, r := range permRows {
// 		var ips []string
// 		_ = json.Unmarshal(r.SourceIPs, &ips)
// 		resp.Permissions = append(resp.Permissions, modelnewapi.PermissionItem{
// 			Service:      r.Service,
// 			Action:       r.Action,
// 			ResourceARN:  r.ResourceARN,
// 			Effect:       r.Effect,
// 			PolicySource: r.PolicySource,
// 			PolicyType:   r.PolicyType,
// 			Used:         r.Used,
// 			LastUsedAt:   timePtrRFC3339(r.LastUsedAt),
// 			SourceIPs:    ips,
// 		})
// 	}

// 	for _, b := range breakdownRows {
// 		resp.PolicyBreakdown = append(resp.PolicyBreakdown, modelnewapi.PolicyBreakdownRow{
// 			PolicyName:       b.PolicyName,
// 			PolicyType:       b.PolicyType,
// 			TotalPermissions: b.TotalPermissions,
// 			UsedPermissions:  b.UsedPermissions,
// 		})
// 	}

// 	return resp, nil
// }

// // ── activity ─────────────────────────────────────────────────────────────

// var identityDetailTimeRanges = map[string]bool{"7d": true, "14d": true, "30d": true, "90d": true, "custom": true}

// func (s *IdentityDetailService) getActivity(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityActivityResponse, error) {
// 	timeRange := strings.TrimSpace(strings.ToLower(p.TimeRange))
// 	if timeRange == "" {
// 		timeRange = "90d"
// 	}
// 	if !identityDetailTimeRanges[timeRange] {
// 		return nil, &IdentityDetailValidationError{Msg: fmt.Sprintf("time_range %q is not recognized", timeRange)}
// 	}

// 	start, end, err := resolveTimeRange(timeRange, p.StartDate, p.EndDate)
// 	if err != nil {
// 		return nil, err
// 	}

// 	page := 1
// 	if p.Page != "" {
// 		v, err := strconv.Atoi(p.Page)
// 		if err != nil || v < 1 {
// 			return nil, &IdentityDetailValidationError{Msg: "page must be a positive integer"}
// 		}
// 		page = v
// 	}
// 	pageSize := 50
// 	if p.PageSize != "" {
// 		v, err := strconv.Atoi(p.PageSize)
// 		if err != nil || v < 1 {
// 			return nil, &IdentityDetailValidationError{Msg: "page_size must be a positive integer"}
// 		}
// 		if v > 200 {
// 			v = 200
// 		}
// 		pageSize = v
// 	}

// 	filter := reponewapi.ActivityFilter{Start: start, End: end, Service: p.Service, Page: page, PageSize: pageSize}

// 	volumeRows, err := s.repo.GetVolumeChart(ctx, db, scanID, identityID, filter)
// 	if err != nil {
// 		return nil, err
// 	}
// 	eventRows, total, err := s.repo.ListRecentEvents(ctx, db, scanID, identityID, filter)
// 	if err != nil {
// 		return nil, err
// 	}
// 	totals, err := s.repo.GetActivityTotals(ctx, db, scanID, identityID, filter)
// 	if err != nil {
// 		return nil, err
// 	}
// 	topIPs, err := s.repo.TopSourceIPs(ctx, db, scanID, identityID, filter, 10)
// 	if err != nil {
// 		return nil, err
// 	}
// 	topRegions, err := s.repo.TopActiveRegions(ctx, db, scanID, identityID, filter, 10)
// 	if err != nil {
// 		return nil, err
// 	}
// 	topServices, err := s.repo.TopServices(ctx, db, scanID, identityID, filter, 10)
// 	if err != nil {
// 		return nil, err
// 	}
// 	topActions, err := s.repo.TopActions(ctx, db, scanID, identityID, filter, 10)
// 	if err != nil {
// 		return nil, err
// 	}
// 	peakHours, err := s.repo.PeakHours(ctx, db, scanID, identityID, filter, 5)
// 	if err != nil {
// 		return nil, err
// 	}

// 	resp := &modelnewapi.IdentityActivityResponse{
// 		Tab:          "activity",
// 		TimeRange:    timeRange,
// 		VolumeChart:  []modelnewapi.VolumeChartPoint{},
// 		RecentEvents: []modelnewapi.ActivityEvent{},
// 		ErrorEvents:  []modelnewapi.ErrorEvent{}, // always empty — no error data in this schema
// 	}
// 	for _, v := range volumeRows {
// 		resp.VolumeChart = append(resp.VolumeChart, modelnewapi.VolumeChartPoint{Date: v.Day.Format("2006-01-02"), Count: v.Count})
// 	}
// 	for _, e := range eventRows {
// 		// identity_usage is pre-aggregated; source_ip/region/user_agent/
// 		// error_code/request_id have no backing column and are left empty.
// 		resp.RecentEvents = append(resp.RecentEvents, modelnewapi.ActivityEvent{
// 			EventTime:   e.LastSeen.UTC().Format(time.RFC3339),
// 			EventName:   e.EventName,
// 			Service:     e.Service,
// 			ResourceARN: e.ResourceARN,
// 			SourceIP:    "",
// 			Region:      "",
// 			UserAgent:   "",
// 			ErrorCode:   nil,
// 			RequestID:   "",
// 		})
// 	}

// 	analytics := modelnewapi.ActivityAnalytics{
// 		SourceIPs:     []modelnewapi.SourceIPStat{},
// 		ActiveRegions: []modelnewapi.RegionStat{},
// 		TopServices:   []modelnewapi.ServiceStat{},
// 		TopActions:    []modelnewapi.ActionStat{},
// 		PeakHours:     []modelnewapi.HourStat{},
// 	}
// 	for _, ip := range topIPs {
// 		analytics.SourceIPs = append(analytics.SourceIPs, modelnewapi.SourceIPStat{IP: ip.Key, Pct: pct(ip.Count, totals.TotalEvents)})
// 	}
// 	for _, r := range topRegions {
// 		analytics.ActiveRegions = append(analytics.ActiveRegions, modelnewapi.RegionStat{Region: r.Key, Count: r.Count})
// 	}
// 	for _, svc := range topServices {
// 		analytics.TopServices = append(analytics.TopServices, modelnewapi.ServiceStat{Service: svc.Key, Pct: pct(svc.Count, totals.TotalEvents), Count: svc.Count})
// 	}
// 	for _, a := range topActions {
// 		analytics.TopActions = append(analytics.TopActions, modelnewapi.ActionStat{Action: a.Key, Count: a.Count})
// 	}
// 	for _, h := range peakHours {
// 		analytics.PeakHours = append(analytics.PeakHours, modelnewapi.HourStat{Hour: h.Hour, Count: h.Count})
// 	}
// 	analytics.ErrorRatePct = 0        // no error data in this schema
// 	analytics.AccessDeniedRatePct = 0 // no error data in this schema
// 	analytics.UsagePattern = usagePattern(len(volumeRows), start, end)
// 	resp.Analytics = analytics

// 	totalPages := 0
// 	if pageSize > 0 {
// 		totalPages = (total + pageSize - 1) / pageSize
// 	}
// 	resp.EventsPagination = modelnewapi.EventsPagination{Page: page, PageSize: pageSize, TotalCount: total, TotalPages: totalPages}

// 	return resp, nil
// }

// func resolveTimeRange(timeRange, startDate, endDate string) (time.Time, time.Time, error) {
// 	now := time.Now().UTC()
// 	switch timeRange {
// 	case "7d":
// 		return now.AddDate(0, 0, -7), now, nil
// 	case "14d":
// 		return now.AddDate(0, 0, -14), now, nil
// 	case "30d":
// 		return now.AddDate(0, 0, -30), now, nil
// 	case "90d":
// 		return now.AddDate(0, 0, -90), now, nil
// 	case "custom":
// 		if strings.TrimSpace(startDate) == "" || strings.TrimSpace(endDate) == "" {
// 			return time.Time{}, time.Time{}, &IdentityDetailValidationError{Msg: "start_date and end_date are required when time_range=custom"}
// 		}
// 		start, err := time.Parse("2006-01-02", startDate)
// 		if err != nil {
// 			return time.Time{}, time.Time{}, &IdentityDetailValidationError{Msg: "start_date must be in YYYY-MM-DD format"}
// 		}
// 		end, err := time.Parse("2006-01-02", endDate)
// 		if err != nil {
// 			return time.Time{}, time.Time{}, &IdentityDetailValidationError{Msg: "end_date must be in YYYY-MM-DD format"}
// 		}
// 		end = end.Add(24*time.Hour - time.Nanosecond)
// 		if end.Before(start) {
// 			return time.Time{}, time.Time{}, &IdentityDetailValidationError{Msg: "end_date must not be before start_date"}
// 		}
// 		return start, end, nil
// 	default:
// 		return now.AddDate(0, 0, -90), now, nil
// 	}
// }

// func pct(part, total int) float64 {
// 	if total == 0 {
// 		return 0
// 	}
// 	return roundTo2((float64(part) / float64(total)) * 100)
// }

// func usagePattern(activeDays int, start, end time.Time) string {
// 	totalDays := int(end.Sub(start).Hours()/24) + 1
// 	if totalDays <= 0 {
// 		return "Unknown"
// 	}
// 	ratio := float64(activeDays) / float64(totalDays)
// 	switch {
// 	case ratio >= 0.7:
// 		return "Continuous"
// 	case ratio >= 0.3:
// 		return "Intermittent"
// 	default:
// 		return "Sporadic"
// 	}
// }

// func roundTo2(v float64) float64 {
// 	return float64(int(v*100+0.5)) / 100
// }

// // ── relationships ─────────────────────────────────────────────────────────

// func (s *IdentityDetailService) getRelationships(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityRelationshipsResponse, error) {
// 	depth := 1
// 	if strings.TrimSpace(p.Depth) != "" {
// 		v, err := strconv.Atoi(p.Depth)
// 		if err != nil || v < 1 || v > 3 {
// 			return nil, &IdentityDetailValidationError{Msg: "depth must be 1, 2 or 3"}
// 		}
// 		depth = v
// 	}

// 	rootARN, err := s.repo.GetIdentityARN(ctx, db, scanID, identityID)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
// 	}
// 	if err != nil {
// 		return nil, err
// 	}

// 	edgeRows, err := s.repo.GetTrustEdges(ctx, db, scanID, rootARN, depth, p.EdgeType)
// 	if err != nil {
// 		return nil, err
// 	}

// 	arnSet := map[string]bool{rootARN: true}
// 	for _, e := range edgeRows {
// 		arnSet[e.SourceARN] = true
// 		arnSet[e.TargetARN] = true
// 	}
// 	arns := make([]string, 0, len(arnSet))
// 	for a := range arnSet {
// 		arns = append(arns, a)
// 	}

// 	nodeRows, err := s.repo.ResolveNodes(ctx, db, scanID, arns)
// 	if err != nil {
// 		return nil, err
// 	}
// 	nodeByARN := map[string]reponewapi.NodeRow{}
// 	for _, n := range nodeRows {
// 		nodeByARN[n.ARN] = n
// 	}

// 	resp := &modelnewapi.IdentityRelationshipsResponse{
// 		Tab: "relationships",
// 		Graph: modelnewapi.RelationshipGraph{
// 			Nodes: []modelnewapi.GraphNode{},
// 			Edges: []modelnewapi.GraphEdge{},
// 		},
// 		RelationshipTable: []modelnewapi.RelationshipTableRow{},
// 	}

// 	for arn := range arnSet {
// 		n, ok := nodeByARN[arn]
// 		isCurrent := arn == rootARN
// 		if ok {
// 			resp.Graph.Nodes = append(resp.Graph.Nodes, modelnewapi.GraphNode{
// 				ARN: n.ARN, Name: n.Name, Type: n.Type, Subtype: n.Subtype, IsCurrent: isCurrent,
// 			})
// 		} else {
// 			resp.Graph.Nodes = append(resp.Graph.Nodes, modelnewapi.GraphNode{ARN: arn, IsCurrent: isCurrent})
// 		}
// 	}

// 	for _, e := range edgeRows {
// 		resp.Graph.Edges = append(resp.Graph.Edges, modelnewapi.GraphEdge{
// 			Source:         e.SourceARN,
// 			Target:         e.TargetARN,
// 			EdgeType:       e.EdgeType,
// 			LastObservedAt: timeOrEmpty(e.CreatedAt),
// 			Metadata:       json.RawMessage(e.Metadata),
// 		})

// 		if e.SourceARN == rootARN || e.TargetARN == rootARN {
// 			direction := "outbound"
// 			targetARN := e.TargetARN
// 			if e.TargetARN == rootARN {
// 				direction = "inbound"
// 				targetARN = e.SourceARN
// 			}
// 			n := nodeByARN[targetARN]
// 			resp.RelationshipTable = append(resp.RelationshipTable, modelnewapi.RelationshipTableRow{
// 				Relationship: humanizeEdgeType(e.EdgeType),
// 				Direction:    direction,
// 				TargetARN:    targetARN,
// 				TargetName:   n.Name,
// 				TargetType:   n.Type,
// 				LastActive:   timeOrEmpty(e.CreatedAt),
// 			})
// 		}
// 	}

// 	return resp, nil
// }

// func humanizeEdgeType(edgeType string) string {
// 	switch strings.ToUpper(edgeType) {
// 	case "BOUND_TO":
// 		return "Bound to"
// 	case "ACCESSES":
// 		return "Accesses"
// 	case "ASSUMES":
// 		return "Assumes"
// 	case "TRUSTS":
// 		return "Trusted by"
// 	default:
// 		return edgeType
// 	}
// }

// func timeOrEmpty(t *time.Time) string {
// 	if t == nil {
// 		return ""
// 	}
// 	return t.UTC().Format(time.RFC3339)
// }

// // ── credentials ─────────────────────────────────────────────────────────

// func (s *IdentityDetailService) getCredentials(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityCredentialsResponse, error) {
// 	accountID, err := s.repo.GetIdentityAccountID(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	rows, err := s.repo.GetCredentials(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	resp := &modelnewapi.IdentityCredentialsResponse{Tab: "credentials", Credentials: []modelnewapi.CredentialDetail{}}
// 	now := time.Now().UTC()

// 	for _, c := range rows {
// 		ageDays := 0
// 		if c.CreatedAtAWS != nil {
// 			ageDays = int(now.Sub(*c.CreatedAtAWS).Hours() / 24)
// 		}
// 		var daysSinceRotation *int
// 		rotationOverdue := false
// 		if c.LastRotatedAt != nil {
// 			d := int(now.Sub(*c.LastRotatedAt).Hours() / 24)
// 			daysSinceRotation = &d
// 			if c.RotationIntervalDays.Valid && int64(d) > c.RotationIntervalDays.Int64 {
// 				rotationOverdue = true
// 			}
// 		}
// 		var rotationInterval *int
// 		if c.RotationIntervalDays.Valid {
// 			v := int(c.RotationIntervalDays.Int64)
// 			rotationInterval = &v
// 		}
// 		var maxSession *int
// 		if c.MaxSessionDuration.Valid {
// 			v := int(c.MaxSessionDuration.Int64)
// 			maxSession = &v
// 		}
// 		var permBoundary *string
// 		if c.PermissionBoundaryARN.Valid {
// 			permBoundary = &c.PermissionBoundaryARN.String
// 		}

// 		resp.Credentials = append(resp.Credentials, modelnewapi.CredentialDetail{
// 			CredentialID:     c.CredentialID,
// 			Name:             c.Name,
// 			ARN:              c.ARN,
// 			CredentialType:   c.CredentialType,
// 			BindingType:      c.BindingType,
// 			BindingSource:    c.BindingSource,
// 			IsPrimary:        c.IsPrimary,
// 			TrustPolicy:      json.RawMessage(c.TrustPolicy),
// 			TrustPrincipals:  buildTrustPrincipals(c.TrustPolicy, accountID, c.OwnerPrincipalARN),
// 			AttachedPolicies: json.RawMessage(c.AttachedPolicies),
// 			InlinePolicies:   json.RawMessage(c.InlinePolicies),
// 			Lifecycle: modelnewapi.CredentialLifecycle{
// 				CreatedAtAWS:          timePtrRFC3339(c.CreatedAtAWS),
// 				LastUsedAt:            timePtrRFC3339(c.LastUsedAt),
// 				LastRotatedAt:         timePtrRFC3339(c.LastRotatedAt),
// 				AgeDays:               ageDays,
// 				DaysSinceRotation:     daysSinceRotation,
// 				RotationEnabled:       c.RotationEnabled,
// 				RotationIntervalDays:  rotationInterval,
// 				RotationOverdue:       rotationOverdue,
// 				ExpiresAt:             timePtrRFC3339(c.ExpiresAt),
// 				MaxSessionDuration:    maxSession,
// 				PermissionBoundaryARN: permBoundary,
// 			},
// 			AssumableRoles: json.RawMessage(c.AssumableRoleARNs),
// 		})
// 	}

// 	return resp, nil
// }

// // ── raw ─────────────────────────────────────────────────────────────────

// func (s *IdentityDetailService) getRaw(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityRawResponse, error) {
// 	row, err := s.repo.GetRaw(ctx, db, scanID, identityID)
// 	if errors.Is(err, sql.ErrNoRows) {
// 		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
// 	}
// 	if err != nil {
// 		return nil, err
// 	}

// 	resolved, err := s.repo.GetResolvedCredential(ctx, db, scanID, identityID)
// 	if err != nil {
// 		return nil, err
// 	}

// 	resp := &modelnewapi.IdentityRawResponse{
// 		Tab:            "raw",
// 		IdentityRecord: json.RawMessage(row.IdentityRecord),
// 		RawAPIResponse: json.RawMessage(row.RawAPIResponse),
// 		TypeAttributes: json.RawMessage(row.TypeAttributes),
// 	}
// 	if resolved != nil {
// 		resp.ResolvedCredential = &modelnewapi.ResolvedCredential{
// 			RoleARN:          resolved.RoleARN,
// 			AssumedVia:       resolved.BindingType,
// 			AttachedPolicies: resolved.AttachedPolicies,
// 			InlinePolicies:   resolved.InlinePolicies,
// 		}
// 	}
// 	return resp, nil
// }


// func nullStringPtr(v sql.NullString) *string {
// 	if !v.Valid {
// 		return nil
// 	}
// 	s := v.String
// 	return &s
// }

// func timePtrRFC3339(t *time.Time) *string {
// 	if t == nil {
// 		return nil
// 	}
// 	s := t.UTC().Format(time.RFC3339)
// 	return &s
// }







































package newapi

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

// ── Errors ───────────────────────────────────────────────────────────────

type IdentityDetailValidationError struct{ Msg string }

func (e *IdentityDetailValidationError) Error() string { return e.Msg }

type IdentityDetailNotFoundError struct{ Msg string }

func (e *IdentityDetailNotFoundError) Error() string { return e.Msg }

// ── Params ───────────────────────────────────────────────────────────────

type IdentityDetailParams struct {
	Tab       string
	TimeRange string
	Service   string
	UsedOnly  string
	Depth     string
	EdgeType  string
	Page      string
	PageSize  string
}

var identityDetailTabs = map[string]bool{
	"overview":      true,
	"permissions":   true,
	"activity":      true,
	"relationships": true,
	"credentials":   true,
	"raw":           true,
}

var requiredIdentityTags = []string{"Name", "Environment", "Owner", "Team", "CostCenter", "Project"}

type IdentityDetailService struct {
	dbm   *database.Manager
	repo  *reponewapi.IdentityDetailRepository
	scans *reponewapi.ScanRepository
}

func NewIdentityDetailService(dbm *database.Manager, repo *reponewapi.IdentityDetailRepository, scans *reponewapi.ScanRepository) *IdentityDetailService {
	return &IdentityDetailService{dbm: dbm, repo: repo, scans: scans}
}

func (s *IdentityDetailService) Get(ctx context.Context, id Identity, identityID string, p IdentityDetailParams) (interface{}, error) {
	if strings.TrimSpace(identityID) == "" {
		return nil, &IdentityDetailValidationError{Msg: "identity id is required"}
	}

	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	tab := strings.TrimSpace(strings.ToLower(p.Tab))
	if tab == "" {
		tab = "overview"
	}
	if !identityDetailTabs[tab] {
		return nil, &IdentityDetailValidationError{Msg: fmt.Sprintf("tab %q is not recognized", tab)}
	}

	scan, err := s.scans.GetLatestCompletedScan(ctx, tenantDB)
	if err != nil {
		return nil, err
	}
	if scan == nil {
		return nil, &IdentityDetailNotFoundError{Msg: "no completed scan available"}
	}
	scanID := scan.ScanID

	exists, err := s.repo.IdentityExists(ctx, tenantDB, scanID, identityID)
	if err != nil {
		return nil, err
	}
	if !exists {
		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
	}

	switch tab {
	case "overview":
		return s.getOverview(ctx, tenantDB, scanID, identityID)
	case "permissions":
		return s.getPermissions(ctx, tenantDB, scanID, identityID, p)
	case "activity":
		return s.getActivity(ctx, tenantDB, scanID, identityID, p)
	case "relationships":
		return s.getRelationships(ctx, tenantDB, scanID, identityID, p)
	case "credentials":
		return s.getCredentials(ctx, tenantDB, scanID, identityID)
	case "raw":
		return s.getRaw(ctx, tenantDB, scanID, identityID)
	default:
		return nil, &IdentityDetailValidationError{Msg: "tab not implemented"}
	}
}

// ── overview ─────────────────────────────────────────────────────────────

func (s *IdentityDetailService) getOverview(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityOverviewResponse, error) {
	row, err := s.repo.GetOverview(ctx, db, scanID, identityID)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
	}
	if err != nil {
		return nil, err
	}

	boundRows, err := s.repo.GetBoundCredentials(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	hasWildcard, err := s.repo.HasWildcardResourceScope(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	risk, err := s.repo.GetPrimaryCredentialRisk(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	var sgIDs []string
	_ = json.Unmarshal(row.SecurityGroupIDs, &sgIDs)

	resp := &modelnewapi.IdentityOverviewResponse{
		Tab: "overview",
		Identity: modelnewapi.IdentityOverviewCore{
			ID:                   row.ID,
			Name:                 row.Name,
			ARN:                  row.ARN,
			IdentityType:         row.IdentityType,
			FunctionalClass:      row.FunctionalClass,
			Category:             deriveCategory(row.IdentityType),
			AccountID:            row.AccountID,
			Region:               row.Region,
			VpcID:                nullStringPtr(row.VpcID),
			SubnetID:             nullStringPtr(row.SubnetID),
			SecurityGroupIDs:     sgIDs,
			Environment:          row.Environment,
			Owner:                row.Owner,
			Status:               row.Status,
			IsPubliclyAccessible: row.IsPubliclyAccessible,
			CreatedAtAWS:         timePtrRFC3339(row.CreatedAtAWS),
			AgeDays:              row.AgeDays,
			FirstSeenAt:          timePtrRFC3339(row.FirstSeenAt),
			LastSeenAt:           timePtrRFC3339(row.LastSeenAt),
			LastActivityAt:       timePtrRFC3339(row.LastActivityAt),
			IdleDays:             row.IdleDays,
			ParentARN:            nullStringPtr(row.ParentARN),
			CreatedBy:            row.CreatedBy,
		},
		TypeAttributes: json.RawMessage(row.TypeAttributes),
		Tags:           json.RawMessage(row.Tags),
	}

	// discovery_source exists as a real column; credential_resolution,
	// last_scanned and data_sources do not — all three are derived here.
	primaryBindingType := ""
	for _, b := range boundRows {
		if b.IsPrimary {
			primaryBindingType = b.BindingType
			break
		}
	}
	dataSources := "AWS API"
	if row.LastActivityAt != nil {
		dataSources = "AWS API + CloudTrail correlation"
	}
	resp.Discovery = modelnewapi.IdentityDiscovery{
		DiscoverySource:      row.DiscoverySource.String,
		CredentialResolution: bindingTypeLabel(primaryBindingType),
		ScanID:               row.ScanID,
		LastScanned:          timePtrRFC3339(row.UpdatedAt), // proxy — no dedicated last_scanned_at column
		DataSources:          dataSources,
	}

	for _, b := range boundRows {
		resp.BoundCredentials = append(resp.BoundCredentials, modelnewapi.BoundCredentialSummary{
			CredentialID:          b.CredentialID,
			Name:                  b.Name,
			CredentialType:        b.CredentialType,
			BindingType:           b.BindingType,
			IsPrimary:             b.IsPrimary,
			TrustPrincipal:        b.TrustPrincipal,
			AttachedPoliciesCount: b.AttachedPoliciesCount,
			InlinePoliciesCount:   b.InlinePoliciesCount,
			GrantedActionsCount:   int(b.GrantedCount),
			UsedActionsCount:      int(b.UsedCount),
			UtilizationPct:        utilizationPct(b.UsedCount, b.GrantedCount),
		})
	}
	if resp.BoundCredentials == nil {
		resp.BoundCredentials = []modelnewapi.BoundCredentialSummary{}
	}

	resp.MissingTags = computeMissingTags(row.Tags, requiredIdentityTags)
	resp.RiskSignals = computeRiskSignals(row, hasWildcard, risk)

	return resp, nil
}

func computeMissingTags(tagsJSON []byte, required []string) []string {
	present := map[string]bool{}
	var m map[string]interface{}
	if len(tagsJSON) > 0 {
		_ = json.Unmarshal(tagsJSON, &m)
	}
	for k := range m {
		present[k] = true
	}
	missing := []string{}
	for _, r := range required {
		if !present[r] {
			missing = append(missing, r)
		}
	}
	return missing
}

func computeRiskSignals(row *reponewapi.OverviewRow, hasWildcard bool, risk *reponewapi.PrimaryCredentialRiskRow) []modelnewapi.RiskSignal {
	neverRotated := false
	expiredOrExpiring := false
	crossAccount := false

	if risk != nil {
		neverRotated = risk.LastRotatedAt == nil
		if risk.ExpiresAt != nil {
			expiredOrExpiring = risk.ExpiresAt.Before(time.Now().UTC().Add(30 * 24 * time.Hour))
		}
		crossAccount = isCrossAccountTrust(risk.TrustPolicy, row.AccountID)
	}

	return []modelnewapi.RiskSignal{
		{Signal: "Publicly accessible", Status: row.IsPubliclyAccessible, Severity: "critical"},
		{Signal: "Stale (no activity > 90d)", Status: row.IdleDays > 90, Severity: "high"},
		{Signal: "No owner attribution", Status: strings.TrimSpace(row.Owner) == "", Severity: "medium"},
		{Signal: "Credential never rotated", Status: neverRotated, Severity: "high"},
		{Signal: "Credential expired/expiring", Status: expiredOrExpiring, Severity: "critical"},
		{Signal: "Cross-account trust", Status: crossAccount, Severity: "medium"},
		{Signal: "Wildcard resource scope", Status: hasWildcard, Severity: "high"},
		{Signal: "No VPC", Status: !row.VpcID.Valid, Severity: "medium"},
	}
}

func deriveCategory(identityType string) string {
	switch strings.ToLower(strings.TrimSpace(identityType)) {
	case "ec2_instance", "lambda_function", "ecs_task", "ecs_service", "fargate_task", "batch_job":
		return "Compute"
	case "iam_role", "iam_user", "iam_group", "sso_user", "federated_identity":
		return "Identity"
	case "s3_bucket", "ebs_volume", "efs_filesystem", "fsx_filesystem":
		return "Storage"
	case "rds_instance", "dynamodb_table", "redshift_cluster", "elasticache_cluster":
		return "Database"
	case "api_gateway", "load_balancer", "cloudfront_distribution", "vpc_endpoint":
		return "Networking"
	case "secrets_manager_secret", "kms_key", "ssm_parameter":
		return "Security"
	default:
		return "Other"
	}
}

func bindingTypeLabel(bindingType string) string {
	switch strings.ToLower(strings.TrimSpace(bindingType)) {
	case "instance_profile":
		return "IAM instance profile association"
	case "assume_role":
		return "STS AssumeRole"
	case "access_key":
		return "Static access key attachment"
	case "execution_role":
		return "Execution role binding"
	case "service_linked_role":
		return "Service-linked role"
	case "":
		return "Unresolved"
	default:
		return bindingType
	}
}

// ── trust policy parsing (used by overview risk signals + credentials tab) ──

type trustPrincipalOut struct {
	Principal  interface{} `json:"principal"`
	Type       string      `json:"type"`
	Condition  interface{} `json:"condition"`
	IsExternal bool        `json:"is_external"`
}

func buildTrustPrincipals(trustPolicy []byte, accountID, fallbackARN string) json.RawMessage {
	out := []trustPrincipalOut{}

	var doc map[string]interface{}
	if len(trustPolicy) > 0 && json.Unmarshal(trustPolicy, &doc) == nil {
		var stmts []interface{}
		switch v := doc["Statement"].(type) {
		case []interface{}:
			stmts = v
		case map[string]interface{}:
			stmts = []interface{}{v}
		}
		for _, s := range stmts {
			stmt, ok := s.(map[string]interface{})
			if !ok {
				continue
			}
			cond := stmt["Condition"]
			switch p := stmt["Principal"].(type) {
			case string:
				out = append(out, trustPrincipalOut{Principal: p, Type: "*", Condition: cond, IsExternal: p == "*"})
			case map[string]interface{}:
				for ptype, pval := range p {
					isExternal := false
					if ptype == "AWS" {
						isExternal = !principalContainsAccount(pval, accountID)
					}
					out = append(out, trustPrincipalOut{Principal: pval, Type: ptype, Condition: cond, IsExternal: isExternal})
				}
			}
		}
	}

	if len(out) == 0 && strings.TrimSpace(fallbackARN) != "" {
		out = append(out, trustPrincipalOut{
			Principal:  fallbackARN,
			Type:       "AWS",
			IsExternal: !principalContainsAccount(fallbackARN, accountID),
		})
	}

	b, _ := json.Marshal(out)
	return json.RawMessage(b)
}

func principalContainsAccount(v interface{}, accountID string) bool {
	if strings.TrimSpace(accountID) == "" {
		return true // can't determine → assume same-account, avoid false positives
	}
	switch val := v.(type) {
	case string:
		return strings.Contains(val, accountID)
	case []interface{}:
		for _, item := range val {
			if s, ok := item.(string); ok && strings.Contains(s, accountID) {
				return true
			}
		}
	}
	return false
}

func isCrossAccountTrust(trustPolicy []byte, accountID string) bool {
	raw := buildTrustPrincipals(trustPolicy, accountID, "")
	var list []trustPrincipalOut
	_ = json.Unmarshal(raw, &list)
	for _, p := range list {
		if p.IsExternal {
			return true
		}
	}
	return false
}

// ── permissions ─────────────────────────────────────────────────────────

func (s *IdentityDetailService) getPermissions(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityPermissionsResponse, error) {
	var usedOnly *bool
	if strings.TrimSpace(p.UsedOnly) != "" {
		v, err := strconv.ParseBool(p.UsedOnly)
		if err != nil {
			return nil, &IdentityDetailValidationError{Msg: "used_only must be true or false"}
		}
		usedOnly = &v
	}

	summary, err := s.repo.GetPermissionsSummary(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	filter := reponewapi.PermissionsFilter{Service: p.Service, UsedOnly: usedOnly}
	permRows, err := s.repo.ListPermissions(ctx, db, scanID, identityID, filter)
	if err != nil {
		return nil, err
	}

	breakdownRows, err := s.repo.GetPolicyBreakdown(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.IdentityPermissionsResponse{
		Tab: "permissions",
		Summary: modelnewapi.PermissionsSummary{
			GrantedCount:   summary.GrantedCount,
			UsedCount:      summary.UsedCount,
			UnusedCount:    summary.GrantedCount - summary.UsedCount,
			UtilizationPct: utilizationPct(int64(summary.UsedCount), int64(summary.GrantedCount)),
		},
		Permissions:     []modelnewapi.PermissionItem{},
		PolicyBreakdown: []modelnewapi.PolicyBreakdownRow{},
	}

	for _, r := range permRows {
		var ips []string
		_ = json.Unmarshal(r.SourceIPs, &ips)
		resp.Permissions = append(resp.Permissions, modelnewapi.PermissionItem{
			Service:      r.Service,
			Action:       r.Action,
			ResourceARN:  r.ResourceARN,
			Effect:       r.Effect,
			PolicySource: r.PolicySource,
			PolicyType:   r.PolicyType,
			Used:         r.Used,
			LastUsedAt:   timePtrRFC3339(r.LastUsedAt),
			SourceIPs:    ips,
		})
	}

	for _, b := range breakdownRows {
		resp.PolicyBreakdown = append(resp.PolicyBreakdown, modelnewapi.PolicyBreakdownRow{
			PolicyName:       b.PolicyName,
			PolicyType:       b.PolicyType,
			TotalPermissions: b.TotalPermissions,
			UsedPermissions:  b.UsedPermissions,
		})
	}

	return resp, nil
}

// ── activity ─────────────────────────────────────────────────────────────

func (s *IdentityDetailService) getActivity(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityActivityResponse, error) {
	rng, err := ResolveTimeRange(p.TimeRange)
	if err != nil {
		return nil, &IdentityDetailValidationError{Msg: err.Error()}
	}
	start, end := rng.Start, rng.End

	page := 1
	if p.Page != "" {
		v, err := strconv.Atoi(p.Page)
		if err != nil || v < 1 {
			return nil, &IdentityDetailValidationError{Msg: "page must be a positive integer"}
		}
		page = v
	}
	pageSize := 50
	if p.PageSize != "" {
		v, err := strconv.Atoi(p.PageSize)
		if err != nil || v < 1 {
			return nil, &IdentityDetailValidationError{Msg: "page_size must be a positive integer"}
		}
		if v > 200 {
			v = 200
		}
		pageSize = v
	}

	filter := reponewapi.ActivityFilter{Start: start, End: end, Service: p.Service, Page: page, PageSize: pageSize}

	volumeRows, err := s.repo.GetVolumeChart(ctx, db, scanID, identityID, filter)
	if err != nil {
		return nil, err
	}
	eventRows, total, err := s.repo.ListRecentEvents(ctx, db, scanID, identityID, filter)
	if err != nil {
		return nil, err
	}
	totals, err := s.repo.GetActivityTotals(ctx, db, scanID, identityID, filter)
	if err != nil {
		return nil, err
	}
	topIPs, err := s.repo.TopSourceIPs(ctx, db, scanID, identityID, filter, 10)
	if err != nil {
		return nil, err
	}
	topRegions, err := s.repo.TopActiveRegions(ctx, db, scanID, identityID, filter, 10)
	if err != nil {
		return nil, err
	}
	topServices, err := s.repo.TopServices(ctx, db, scanID, identityID, filter, 10)
	if err != nil {
		return nil, err
	}
	topActions, err := s.repo.TopActions(ctx, db, scanID, identityID, filter, 10)
	if err != nil {
		return nil, err
	}
	peakHours, err := s.repo.PeakHours(ctx, db, scanID, identityID, filter, 5)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.IdentityActivityResponse{
		Tab:          "activity",
		TimeRange:    rng.Label,
		VolumeChart:  []modelnewapi.VolumeChartPoint{},
		RecentEvents: []modelnewapi.ActivityEvent{},
		ErrorEvents:  []modelnewapi.ErrorEvent{}, // always empty — no error data in this schema
	}
	for _, v := range volumeRows {
		resp.VolumeChart = append(resp.VolumeChart, modelnewapi.VolumeChartPoint{Date: v.Day.Format("2006-01-02"), Count: v.Count})
	}
	for _, e := range eventRows {
		// identity_usage is pre-aggregated; source_ip/region/user_agent/
		// error_code/request_id have no backing column and are left empty.
		resp.RecentEvents = append(resp.RecentEvents, modelnewapi.ActivityEvent{
			EventTime:   e.LastSeen.UTC().Format(time.RFC3339),
			EventName:   e.EventName,
			Service:     e.Service,
			ResourceARN: e.ResourceARN,
			SourceIP:    "",
			Region:      "",
			UserAgent:   "",
			ErrorCode:   nil,
			RequestID:   "",
		})
	}

	analytics := modelnewapi.ActivityAnalytics{
		SourceIPs:     []modelnewapi.SourceIPStat{},
		ActiveRegions: []modelnewapi.RegionStat{},
		TopServices:   []modelnewapi.ServiceStat{},
		TopActions:    []modelnewapi.ActionStat{},
		PeakHours:     []modelnewapi.HourStat{},
	}
	for _, ip := range topIPs {
		analytics.SourceIPs = append(analytics.SourceIPs, modelnewapi.SourceIPStat{IP: ip.Key, Pct: pct(ip.Count, totals.TotalEvents)})
	}
	for _, r := range topRegions {
		analytics.ActiveRegions = append(analytics.ActiveRegions, modelnewapi.RegionStat{Region: r.Key, Count: r.Count})
	}
	for _, svc := range topServices {
		analytics.TopServices = append(analytics.TopServices, modelnewapi.ServiceStat{Service: svc.Key, Pct: pct(svc.Count, totals.TotalEvents), Count: svc.Count})
	}
	for _, a := range topActions {
		analytics.TopActions = append(analytics.TopActions, modelnewapi.ActionStat{Action: a.Key, Count: a.Count})
	}
	for _, h := range peakHours {
		analytics.PeakHours = append(analytics.PeakHours, modelnewapi.HourStat{Hour: h.Hour, Count: h.Count})
	}
	analytics.ErrorRatePct = 0        // no error data in this schema
	analytics.AccessDeniedRatePct = 0 // no error data in this schema
	analytics.UsagePattern = usagePattern(len(volumeRows), start, end)
	resp.Analytics = analytics

	totalPages := 0
	if pageSize > 0 {
		totalPages = (total + pageSize - 1) / pageSize
	}
	resp.EventsPagination = modelnewapi.EventsPagination{Page: page, PageSize: pageSize, TotalCount: total, TotalPages: totalPages}

	return resp, nil
}

func pct(part, total int) float64 {
	if total == 0 {
		return 0
	}
	return roundTo2((float64(part) / float64(total)) * 100)
}

func usagePattern(activeDays int, start, end time.Time) string {
	totalDays := int(end.Sub(start).Hours()/24) + 1
	if totalDays <= 0 {
		return "Unknown"
	}
	ratio := float64(activeDays) / float64(totalDays)
	switch {
	case ratio >= 0.7:
		return "Continuous"
	case ratio >= 0.3:
		return "Intermittent"
	default:
		return "Sporadic"
	}
}

func roundTo2(v float64) float64 {
	return float64(int(v*100+0.5)) / 100
}

// ── relationships ─────────────────────────────────────────────────────────

func (s *IdentityDetailService) getRelationships(ctx context.Context, db *sql.DB, scanID, identityID string, p IdentityDetailParams) (*modelnewapi.IdentityRelationshipsResponse, error) {
	depth := 1
	if strings.TrimSpace(p.Depth) != "" {
		v, err := strconv.Atoi(p.Depth)
		if err != nil || v < 1 || v > 3 {
			return nil, &IdentityDetailValidationError{Msg: "depth must be 1, 2 or 3"}
		}
		depth = v
	}

	rootARN, err := s.repo.GetIdentityARN(ctx, db, scanID, identityID)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
	}
	if err != nil {
		return nil, err
	}

	edgeRows, err := s.repo.GetTrustEdges(ctx, db, scanID, rootARN, depth, p.EdgeType)
	if err != nil {
		return nil, err
	}

	arnSet := map[string]bool{rootARN: true}
	for _, e := range edgeRows {
		arnSet[e.SourceARN] = true
		arnSet[e.TargetARN] = true
	}
	arns := make([]string, 0, len(arnSet))
	for a := range arnSet {
		arns = append(arns, a)
	}

	nodeRows, err := s.repo.ResolveNodes(ctx, db, scanID, arns)
	if err != nil {
		return nil, err
	}
	nodeByARN := map[string]reponewapi.NodeRow{}
	for _, n := range nodeRows {
		nodeByARN[n.ARN] = n
	}

	resp := &modelnewapi.IdentityRelationshipsResponse{
		Tab: "relationships",
		Graph: modelnewapi.RelationshipGraph{
			Nodes: []modelnewapi.GraphNode{},
			Edges: []modelnewapi.GraphEdge{},
		},
		RelationshipTable: []modelnewapi.RelationshipTableRow{},
	}

	for arn := range arnSet {
		n, ok := nodeByARN[arn]
		isCurrent := arn == rootARN
		if ok {
			resp.Graph.Nodes = append(resp.Graph.Nodes, modelnewapi.GraphNode{
				ARN: n.ARN, Name: n.Name, Type: n.Type, Subtype: n.Subtype, IsCurrent: isCurrent,
			})
		} else {
			resp.Graph.Nodes = append(resp.Graph.Nodes, modelnewapi.GraphNode{ARN: arn, IsCurrent: isCurrent})
		}
	}

	for _, e := range edgeRows {
		resp.Graph.Edges = append(resp.Graph.Edges, modelnewapi.GraphEdge{
			Source:         e.SourceARN,
			Target:         e.TargetARN,
			EdgeType:       e.EdgeType,
			LastObservedAt: timeOrEmpty(e.CreatedAt),
			Metadata:       json.RawMessage(e.Metadata),
		})

		if e.SourceARN == rootARN || e.TargetARN == rootARN {
			direction := "outbound"
			targetARN := e.TargetARN
			if e.TargetARN == rootARN {
				direction = "inbound"
				targetARN = e.SourceARN
			}
			n := nodeByARN[targetARN]
			resp.RelationshipTable = append(resp.RelationshipTable, modelnewapi.RelationshipTableRow{
				Relationship: humanizeEdgeType(e.EdgeType),
				Direction:    direction,
				TargetARN:    targetARN,
				TargetName:   n.Name,
				TargetType:   n.Type,
				LastActive:   timeOrEmpty(e.CreatedAt),
			})
		}
	}

	return resp, nil
}

func humanizeEdgeType(edgeType string) string {
	switch strings.ToUpper(edgeType) {
	case "BOUND_TO":
		return "Bound to"
	case "ACCESSES":
		return "Accesses"
	case "ASSUMES":
		return "Assumes"
	case "TRUSTS":
		return "Trusted by"
	default:
		return edgeType
	}
}

func timeOrEmpty(t *time.Time) string {
	if t == nil {
		return ""
	}
	return t.UTC().Format(time.RFC3339)
}

// ── credentials ─────────────────────────────────────────────────────────

func (s *IdentityDetailService) getCredentials(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityCredentialsResponse, error) {
	accountID, err := s.repo.GetIdentityAccountID(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	rows, err := s.repo.GetCredentials(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.IdentityCredentialsResponse{Tab: "credentials", Credentials: []modelnewapi.CredentialDetail{}}
	now := time.Now().UTC()

	for _, c := range rows {
		ageDays := 0
		if c.CreatedAtAWS != nil {
			ageDays = int(now.Sub(*c.CreatedAtAWS).Hours() / 24)
		}
		var daysSinceRotation *int
		rotationOverdue := false
		if c.LastRotatedAt != nil {
			d := int(now.Sub(*c.LastRotatedAt).Hours() / 24)
			daysSinceRotation = &d
			if c.RotationIntervalDays.Valid && int64(d) > c.RotationIntervalDays.Int64 {
				rotationOverdue = true
			}
		}
		var rotationInterval *int
		if c.RotationIntervalDays.Valid {
			v := int(c.RotationIntervalDays.Int64)
			rotationInterval = &v
		}
		var maxSession *int
		if c.MaxSessionDuration.Valid {
			v := int(c.MaxSessionDuration.Int64)
			maxSession = &v
		}
		var permBoundary *string
		if c.PermissionBoundaryARN.Valid {
			permBoundary = &c.PermissionBoundaryARN.String
		}

		resp.Credentials = append(resp.Credentials, modelnewapi.CredentialDetail{
			CredentialID:     c.CredentialID,
			Name:             c.Name,
			ARN:              c.ARN,
			CredentialType:   c.CredentialType,
			BindingType:      c.BindingType,
			BindingSource:    c.BindingSource,
			IsPrimary:        c.IsPrimary,
			TrustPolicy:      json.RawMessage(c.TrustPolicy),
			TrustPrincipals:  buildTrustPrincipals(c.TrustPolicy, accountID, c.OwnerPrincipalARN),
			AttachedPolicies: json.RawMessage(c.AttachedPolicies),
			InlinePolicies:   json.RawMessage(c.InlinePolicies),
			Lifecycle: modelnewapi.CredentialLifecycle{
				CreatedAtAWS:          timePtrRFC3339(c.CreatedAtAWS),
				LastUsedAt:            timePtrRFC3339(c.LastUsedAt),
				LastRotatedAt:         timePtrRFC3339(c.LastRotatedAt),
				AgeDays:               ageDays,
				DaysSinceRotation:     daysSinceRotation,
				RotationEnabled:       c.RotationEnabled,
				RotationIntervalDays:  rotationInterval,
				RotationOverdue:       rotationOverdue,
				ExpiresAt:             timePtrRFC3339(c.ExpiresAt),
				MaxSessionDuration:    maxSession,
				PermissionBoundaryARN: permBoundary,
			},
			AssumableRoles: json.RawMessage(c.AssumableRoleARNs),
		})
	}

	return resp, nil
}

// ── raw ─────────────────────────────────────────────────────────────────

func (s *IdentityDetailService) getRaw(ctx context.Context, db *sql.DB, scanID, identityID string) (*modelnewapi.IdentityRawResponse, error) {
	row, err := s.repo.GetRaw(ctx, db, scanID, identityID)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, &IdentityDetailNotFoundError{Msg: "identity not found"}
	}
	if err != nil {
		return nil, err
	}

	resolved, err := s.repo.GetResolvedCredential(ctx, db, scanID, identityID)
	if err != nil {
		return nil, err
	}

	resp := &modelnewapi.IdentityRawResponse{
		Tab:            "raw",
		IdentityRecord: json.RawMessage(row.IdentityRecord),
		RawAPIResponse: json.RawMessage(row.RawAPIResponse),
		TypeAttributes: json.RawMessage(row.TypeAttributes),
	}
	if resolved != nil {
		resp.ResolvedCredential = &modelnewapi.ResolvedCredential{
			RoleARN:          resolved.RoleARN,
			AssumedVia:       resolved.BindingType,
			AttachedPolicies: resolved.AttachedPolicies,
			InlinePolicies:   resolved.InlinePolicies,
		}
	}
	return resp, nil
}


func nullStringPtr(v sql.NullString) *string {
	if !v.Valid {
		return nil
	}
	s := v.String
	return &s
}

func timePtrRFC3339(t *time.Time) *string {
	if t == nil {
		return nil
	}
	s := t.UTC().Format(time.RFC3339)
	return &s
}