package newapi

import (
	"context"
	"fmt"
	"log"
	"regexp"
	"strings"

	"nhi-backend-api/internal/database"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	reponewapi "nhi-backend-api/internal/repository/new_api"
)

var (
	awsAccountIDRe = regexp.MustCompile(`^\d{12}$`)
	awsRegionRe    = regexp.MustCompile(`^[a-z]{2}(-[a-z]+)+-\d{1,2}$`)
)

const maxSelectionItems = 200

// UpdateValidationError is a client mistake (HTTP 400), not a server failure.
type UpdateValidationError struct{ Msg string }

func (e *UpdateValidationError) Error() string { return e.Msg }

type UpdateSettingsService struct {
	dbm   *database.Manager
	repo  *reponewapi.UpdateSettingsRepository
	scans *reponewapi.ScanRepository // only used to check the chosen scan exists
}

func NewUpdateSettingsService(dbm *database.Manager, repo *reponewapi.UpdateSettingsRepository, scans *reponewapi.ScanRepository) *UpdateSettingsService {
	return &UpdateSettingsService{dbm: dbm, repo: repo, scans: scans}
}

// cleanSelection trims, validates and de-duplicates a list. It never returns
// nil, so the stored JSON is [] and not null.
func cleanSelection(field string, items []string, re *regexp.Regexp) ([]string, error) {
	if len(items) > maxSelectionItems {
		return nil, &UpdateValidationError{Msg: fmt.Sprintf("%s: at most %d values allowed", field, maxSelectionItems)}
	}
	seen := make(map[string]struct{}, len(items))
	out := make([]string, 0, len(items))
	for i, it := range items {
		v := strings.TrimSpace(it)
		if !re.MatchString(v) {
			return nil, &UpdateValidationError{Msg: fmt.Sprintf("%s: invalid value at position %d", field, i)}
		}
		if _, dup := seen[v]; dup {
			continue
		}
		seen[v] = struct{}{}
		out = append(out, v)
	}
	return out, nil
}

// Update implements Endpoint 1B: validate, then save to user_settings in the
// tenant's data DB (nhi_db). The JWT is not touched.
func (s *UpdateSettingsService) Update(ctx context.Context, id Identity, req modelnewapi.UpdateSettingsRequest) (*modelnewapi.UpdateSettingsResponse, error) {
	accounts, err := cleanSelection("selected_account_ids", req.SelectedAccountIDs, awsAccountIDRe)
	if err != nil {
		return nil, err
	}
	regions, err := cleanSelection("selected_regions", req.SelectedRegions, awsRegionRe)
	if err != nil {
		return nil, err
	}

	var scanID *string
	if req.SelectedScanID != nil {
		if v := strings.TrimSpace(*req.SelectedScanID); v != "" {
			if len(v) > 200 {
				return nil, &UpdateValidationError{Msg: "selected_scan_id: too long"}
			}
			scanID = &v
		}
	}

	tenantDB, err := s.dbm.Tenant(id.DBName)
	if err != nil {
		return nil, fmt.Errorf("resolve tenant database: %w", err)
	}

	// A saved scan must exist and be COMPLETED (nhi_scans_aws.status, case-insensitive).
	if scanID != nil {
		scan, err := s.scans.GetCompletedScan(ctx, tenantDB, *scanID)
		if err != nil {
			return nil, err
		}
		if scan == nil {
			log.Printf(
				"settings update: user=%s tenant=%s db=%s rejected scan_id=%q (not found in nhi_scans_aws, or status != COMPLETED)",
				id.UserID, id.TenantID, id.DBName, *scanID,
			)
			return nil, &UpdateValidationError{
				Msg: fmt.Sprintf("selected_scan_id %q not found or not COMPLETED — pick an existing COMPLETED scan_id (or omit this field)", *scanID),
			}
		}
	}

	if err := s.repo.Upsert(ctx, tenantDB, id.UserID, accounts, regions, scanID); err != nil {
		return nil, err
	}

	return &modelnewapi.UpdateSettingsResponse{
		Success: true,
		Settings: modelnewapi.SavedSettings{
			SelectedAccountIDs: accounts,
			SelectedRegions:    regions,
			SelectedScanID:     scanID,
		},
	}, nil
}