package inventory

import (
	"errors"
	"log"
	"net/http"
	"strings"

	"github.com/gorilla/mux"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityCredentialsHandler struct {
	service *svcinventory.IdentityCredentialsService
	scope   CredentialListScope
}

func NewIdentityCredentialsHandler(service *svcinventory.IdentityCredentialsService, scope CredentialListScope) *IdentityCredentialsHandler {
	return &IdentityCredentialsHandler{service: service, scope: scope}
}

func (h *IdentityCredentialsHandler) Credentials(w http.ResponseWriter, r *http.Request) {
	q, ok := credentialAPIQuery(r, "account_id")
	if !ok {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid identity credential filters")
		return
	}
	identityID := strings.TrimSpace(mux.Vars(r)["id"])
	if !credentialAPIUUID.MatchString(identityID) {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	allowed, ok := identityFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok || !credentialAPIAccountAllowed(w, q.Get("account_id"), allowed) {
		return
	}
	result, err := h.service.GetByIdentityID(r.Context(), identityID, allowed, q.Get("account_id"))
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityCredentialsNotFound) {
			credentialAPIError(w, http.StatusNotFound, "NOT_FOUND", "Identity not found")
			return
		}
		log.Printf("identity credentials query failed: %T", err)
		credentialAPIError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load identity credentials")
		return
	}
	credentialAPIOK(w, result)
}
