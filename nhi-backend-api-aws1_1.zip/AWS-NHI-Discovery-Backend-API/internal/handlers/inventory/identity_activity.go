package inventory

import (
	"errors"
	"log"
	"net/http"
	"strings"

	"github.com/gorilla/mux"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityActivityHandler struct {
	service *svcinventory.IdentityActivityService
	scope   CredentialListScope
}

func NewIdentityActivityHandler(service *svcinventory.IdentityActivityService, scope CredentialListScope) *IdentityActivityHandler {
	return &IdentityActivityHandler{service: service, scope: scope}
}

func (h *IdentityActivityHandler) Activity(w http.ResponseWriter, r *http.Request) {
	q, ok := credentialAPIQuery(r, "account_id", "days")
	if !ok {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid identity activity filters")
		return
	}
	identityID := strings.TrimSpace(mux.Vars(r)["id"])
	if !credentialAPIUUID.MatchString(identityID) {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	days, ok := credentialAPIParseInt(q.Get("days"), 30, 1, 365)
	if !ok {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_FILTER", "days must be between 1 and 365")
		return
	}
	allowed, ok := identityFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok || !credentialAPIAccountAllowed(w, q.Get("account_id"), allowed) {
		return
	}
	result, err := h.service.GetActivity(r.Context(), repoinventory.IdentityActivityFilter{
		IdentityID: identityID, AllowedAccounts: allowed, AccountID: q.Get("account_id"), Days: days,
	})
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityActivityNotFound) {
			credentialAPIError(w, http.StatusNotFound, "NOT_FOUND", "Identity not found")
			return
		}
		log.Printf("identity activity query failed: %T", err)
		credentialAPIError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load identity activity")
		return
	}
	credentialAPIOK(w, result)
}
