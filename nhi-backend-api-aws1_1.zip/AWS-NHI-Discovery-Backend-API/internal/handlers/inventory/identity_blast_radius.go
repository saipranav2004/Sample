package inventory

import (
	"errors"
	"log"
	"net/http"
	"strings"

	"github.com/gorilla/mux"
	repoinventory "nhi-backend-api/internal/repository/inventory"
	svcinventory "nhi-backend-api/internal/services/inventory"
)

type IdentityBlastRadiusHandler struct {
	service *svcinventory.IdentityBlastRadiusService
	scope   CredentialListScope
}

func NewIdentityBlastRadiusHandler(service *svcinventory.IdentityBlastRadiusService, scope CredentialListScope) *IdentityBlastRadiusHandler {
	return &IdentityBlastRadiusHandler{service: service, scope: scope}
}

func (h *IdentityBlastRadiusHandler) BlastRadius(w http.ResponseWriter, r *http.Request) {
	q, ok := credentialAPIQuery(r, "account_id")
	if !ok {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid identity blast-radius filters")
		return
	}
	identityID := strings.TrimSpace(mux.Vars(r)["id"])
	if !credentialAPIUUID.MatchString(identityID) {
		credentialAPIError(w, http.StatusBadRequest, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	allowed, ok := identityFeatureAccounts(w, r, h.scope, h.service != nil)
	if !ok || !credentialAPIAccountAllowed(w, q.Get("account_id"), allowed) {
		return
	}
	result, err := h.service.GetBlastRadius(r.Context(), repoinventory.IdentityBlastRadiusFilter{
		IdentityID: identityID, AllowedAccounts: allowed, AccountID: q.Get("account_id"),
	})
	if err != nil {
		if errors.Is(err, repoinventory.ErrIdentityBlastRadiusNotFound) {
			credentialAPIError(w, http.StatusNotFound, "NOT_FOUND", "Identity not found")
			return
		}
		log.Printf("identity blast-radius query failed: %T", err)
		credentialAPIError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load identity blast radius")
		return
	}
	credentialAPIOK(w, result)
}
