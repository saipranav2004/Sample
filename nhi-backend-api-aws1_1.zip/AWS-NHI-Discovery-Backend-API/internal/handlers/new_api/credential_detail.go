// package newapi

// import (
// 	"errors"
// 	"log"
// 	"net/http"
// 	"strings"

// 	"github.com/gorilla/mux"

// 	"nhi-backend-api/internal/middleware"
// 	"nhi-backend-api/internal/models"
// 	svcnewapi "nhi-backend-api/internal/services/new_api"
// )

// type CredentialDetailHandler struct {
// 	svc *svcnewapi.CredentialDetailService
// }

// func NewCredentialDetailHandler(svc *svcnewapi.CredentialDetailService) *CredentialDetailHandler {
// 	return &CredentialDetailHandler{svc: svc}
// }

// // Get handles GET /api/v1/credentials/{id}?tab=&time_range=&depth=&edge_type=
// // (Endpoint 7: Credential Detail)
// func (h *CredentialDetailHandler) Get(w http.ResponseWriter, r *http.Request) {
// 	claims := middleware.GetClaims(r)
// 	if claims == nil {
// 		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
// 			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
// 		})
// 		return
// 	}

// 	credentialID := strings.TrimSpace(mux.Vars(r)["id"])
// 	q := r.URL.Query()
// 	params := svcnewapi.CredentialDetailParams{
// 		Tab:       q.Get("tab"),
// 		TimeRange: q.Get("time_range"),
// 		Depth:     q.Get("depth"),
// 		EdgeType:  q.Get("edge_type"),

// 	}

// 	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
// 		UserID:   claims.UserID,
// 		TenantID: claims.TenantID,
// 		DBName:   claims.DBName,
// 	}, credentialID, params)
// 	if err != nil {
// 		var ve *svcnewapi.CredentialDetailValidationError
// 		if errors.As(err, &ve) {
// 			writeJSON(w, http.StatusBadRequest, models.APIResponse{
// 				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
// 			})
// 			return
// 		}
// 		var nf *svcnewapi.CredentialDetailNotFoundError
// 		if errors.As(err, &nf) {
// 			writeJSON(w, http.StatusNotFound, models.APIResponse{
// 				Success: false, Message: nf.Msg, Error: "CREDENTIAL_NOT_FOUND",
// 			})
// 			return
// 		}
// 		log.Printf("credential detail: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
// 		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
// 			Success: false, Message: "Failed to load credential detail", Error: "CREDENTIAL_DETAIL_FAILED",
// 		})
// 		return
// 	}

// 	writeJSON(w, http.StatusOK, resp)
// }




























package newapi

import (
	"errors"
	"log"
	"net/http"
	"strings"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type CredentialDetailHandler struct {
	svc *svcnewapi.CredentialDetailService
}

func NewCredentialDetailHandler(svc *svcnewapi.CredentialDetailService) *CredentialDetailHandler {
	return &CredentialDetailHandler{svc: svc}
}

// Get handles GET /api/v1/credentials/{id}?tab=&time_range=&depth=&edge_type=
// (Endpoint 7: Credential Detail)
func (h *CredentialDetailHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	credentialID := strings.TrimSpace(mux.Vars(r)["id"])
	q := r.URL.Query()
	params := svcnewapi.CredentialDetailParams{
		Tab:       q.Get("tab"),
		TimeRange: q.Get("time_range"),
		Depth:     q.Get("depth"),
		EdgeType:  q.Get("edge_type"),

	}

	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, credentialID, params)
	if err != nil {
		var ve *svcnewapi.CredentialDetailValidationError
		if errors.As(err, &ve) {
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
			})
			return
		}
		var nf *svcnewapi.CredentialDetailNotFoundError
		if errors.As(err, &nf) {
			writeJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false, Message: nf.Msg, Error: "CREDENTIAL_NOT_FOUND",
			})
			return
		}
		log.Printf("credential detail: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false, Message: "Failed to load credential detail", Error: "CREDENTIAL_DETAIL_FAILED",
		})
		return
	}

	writeJSON(w, http.StatusOK, resp)
}