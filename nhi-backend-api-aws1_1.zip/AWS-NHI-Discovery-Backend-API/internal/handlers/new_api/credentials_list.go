package newapi

import (
	"errors"
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type CredentialsListHandler struct {
	svc *svcnewapi.CredentialsListService
}

func NewCredentialsListHandler(svc *svcnewapi.CredentialsListService) *CredentialsListHandler {
	return &CredentialsListHandler{svc: svc}
}

// List handles GET /api/v1/credentials   (Endpoint 6: Credentials List)
//
// Auth: JWT → user_id, tenant_id, db_name
func (h *CredentialsListHandler) List(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	q := r.URL.Query()
	params := svcnewapi.CredentialsListParams{
		Page:               q.Get("page"),
		PageSize:           q.Get("page_size"),
		Search:             q.Get("search"),
		CredentialType:     q.Get("credential_type"),
		Status:             q.Get("status"),
		OwnerPrincipalARN:  q.Get("owner_principal_arn"),
		RotationEnabled:    q.Get("rotation_enabled"),
		RotationOverdue:    q.Get("rotation_overdue"),
		IsOrphaned:         q.Get("is_orphaned"),
		HasExternalTrust:   q.Get("has_external_trust"),
		MinIdleDays:        q.Get("min_idle_days"),
		MaxDaysUntilExpiry: q.Get("max_days_until_expiry"),
		SortBy:             q.Get("sort_by"),
		SortOrder:          q.Get("sort_order"),
	}

	resp, err := h.svc.List(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, params)
	if err != nil {
		var ve *svcnewapi.CredentialsListValidationError
		if errors.As(err, &ve) {
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
			})
			return
		}
		log.Printf("credentials list: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false, Message: "Failed to load credentials", Error: "CREDENTIALS_LIST_FAILED",
		})
		return
	}

	writeJSON(w, http.StatusOK, resp)
}