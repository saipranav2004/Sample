package newapi

import (
	"errors"
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type IdentitiesListHandler struct {
	svc *svcnewapi.IdentitiesListService
}

func NewIdentitiesListHandler(svc *svcnewapi.IdentitiesListService) *IdentitiesListHandler {
	return &IdentitiesListHandler{svc: svc}
}

// List implements GET /api/v1/identities.
func (h *IdentitiesListHandler) List(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	q := r.URL.Query()
	params := svcnewapi.IdentitiesListParams{
		Page:                 q.Get("page"),
		PageSize:             q.Get("page_size"),
		Search:               q.Get("search"),
		IdentityType:         splitCSV(q["identity_type"]),
		FunctionalClass:      splitCSV(q["functional_class"]),
		Environment:          splitCSV(q["environment"]),
		Status:               splitCSV(q["status"]),
		Owner:                q.Get("owner"),
		VpcID:                q.Get("vpc_id"),
		IsPubliclyAccessible: q.Get("is_publicly_accessible"),
		MinIdleDays:          q.Get("min_idle_days"),
		SortBy:               q.Get("sort_by"),
		SortOrder:            q.Get("sort_order"),
	}

	resp, err := h.svc.List(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, params)
	if err != nil {
		var ve *svcnewapi.IdentitiesListValidationError
		switch {
		case errors.As(err, &ve):
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
			})
		default:
			log.Printf("identities list: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
			writeJSON(w, http.StatusInternalServerError, models.APIResponse{
				Success: false, Message: "Failed to load identities", Error: "IDENTITIES_LIST_FAILED",
			})
		}
		return
	}

	writeJSON(w, http.StatusOK, resp)
}