package newapi

import (
	"context"
	"errors"
	"log"
	"net/http"
	"strings"
	"time"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type DashboardOverviewHandler struct {
	svc *svcnewapi.DashboardOverviewService
}

func NewDashboardOverviewHandler(svc *svcnewapi.DashboardOverviewService) *DashboardOverviewHandler {
	return &DashboardOverviewHandler{svc: svc}
}


func (h *DashboardOverviewHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	q := r.URL.Query()
	params := svcnewapi.OverviewParams{
		ScanID:         strings.TrimSpace(q.Get("scan_id")),
		Accounts:       splitCSV(q["accounts"]),
		Regions:        splitCSV(q["regions"]),
	}

	// Stay inside the server's 15s WriteTimeout.
	ctx, cancel := context.WithTimeout(r.Context(), 12*time.Second)
	defer cancel()

	resp, err := h.svc.Get(ctx, svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, params)
	if err != nil {
		var ve *svcnewapi.UpdateValidationError
		switch {
		case errors.As(err, &ve):
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
			})
		case errors.Is(err, svcnewapi.ErrScanNotFound):
			writeJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false, Message: "Scan not found or not completed", Error: "SCAN_NOT_FOUND",
			})
		default:
			log.Printf("dashboard overview: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
			writeJSON(w, http.StatusInternalServerError, models.APIResponse{
				Success: false, Message: "Failed to load dashboard overview", Error: "DASHBOARD_OVERVIEW_FAILED",
			})
		}
		return
	}

	// Body is exactly the documented shape: { "kpis": {...}, "charts": {...} }
	writeJSON(w, http.StatusOK, resp)
}

// splitCSV accepts both ?accounts=a,b and ?accounts=a&accounts=b.
func splitCSV(values []string) []string {
	var out []string
	for _, v := range values {
		for _, part := range strings.Split(v, ",") {
			if p := strings.TrimSpace(part); p != "" {
				out = append(out, p)
			}
		}
	}
	return out
}





