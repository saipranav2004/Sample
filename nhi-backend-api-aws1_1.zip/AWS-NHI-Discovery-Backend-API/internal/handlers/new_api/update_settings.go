package newapi

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	modelnewapi "nhi-backend-api/internal/models/new_api"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type UpdateSettingsHandler struct {
	svc *svcnewapi.UpdateSettingsService
}

func NewUpdateSettingsHandler(svc *svcnewapi.UpdateSettingsService) *UpdateSettingsHandler {
	return &UpdateSettingsHandler{svc: svc}
}

// Update handles PUT /api/v1/settings   (Endpoint 1B: Update Settings)
//
// Auth: JWT → user_id (the token itself is unchanged)
func (h *UpdateSettingsHandler) Update(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, 1<<20) // 1 MB limit
	var req modelnewapi.UpdateSettingsRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, models.APIResponse{
			Success: false, Message: "Invalid JSON body", Error: "INVALID_REQUEST",
		})
		return
	}

	resp, err := h.svc.Update(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, req)
	if err != nil {
		var ve *svcnewapi.UpdateValidationError
		if errors.As(err, &ve) {
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_SETTINGS",
			})
			return
		}
		log.Printf("settings update: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false, Message: "Failed to save settings", Error: "SETTINGS_UPDATE_FAILED",
		})
		return
	}

	writeJSON(w, http.StatusOK, resp)
}