package newapi

import (
	"encoding/json"
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type SettingsHandler struct {
	svc *svcnewapi.SettingsService
}

func NewSettingsHandler(svc *svcnewapi.SettingsService) *SettingsHandler {
	return &SettingsHandler{svc: svc}
}

// Get handles GET /api/v1/settings   (Endpoint 1A: Get Settings)
//
// Auth: JWT → user_id, tenant_id, db_name
func (h *SettingsHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	})
	if err != nil {
		log.Printf("settings: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "Failed to load settings",
			Error:   "SETTINGS_LOAD_FAILED",
		})
		return
	}

	// Body is exactly the documented shape: { "settings": {...}, "source": "..." }
	writeJSON(w, http.StatusOK, resp)
}

func writeJSON(w http.ResponseWriter, status int, body interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
