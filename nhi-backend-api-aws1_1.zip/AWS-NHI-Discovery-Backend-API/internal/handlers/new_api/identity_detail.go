// package newapi

// import (
// 	"errors"
// 	"log"
// 	"net/http"

// 	"github.com/gorilla/mux"

// 	"nhi-backend-api/internal/middleware"
// 	"nhi-backend-api/internal/models"
// 	svcnewapi "nhi-backend-api/internal/services/new_api"
// )

// type IdentityDetailHandler struct {
// 	svc *svcnewapi.IdentityDetailService
// }

// func NewIdentityDetailHandler(svc *svcnewapi.IdentityDetailService) *IdentityDetailHandler {
// 	return &IdentityDetailHandler{svc: svc}
// }

// // Get implements GET /api/v1/identities/:id.
// func (h *IdentityDetailHandler) Get(w http.ResponseWriter, r *http.Request) {
// 	claims := middleware.GetClaims(r)
// 	if claims == nil {
// 		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
// 			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
// 		})
// 		return
// 	}

// 	identityID := mux.Vars(r)["id"]

// 	q := r.URL.Query()
// 	params := svcnewapi.IdentityDetailParams{
// 		Tab:       q.Get("tab"),
// 		TimeRange: q.Get("time_range"),
// 		StartDate: q.Get("start_date"),
// 		EndDate:   q.Get("end_date"),
// 		Service:   q.Get("service"),
// 		UsedOnly:  q.Get("used_only"),
// 		Depth:     q.Get("depth"),
// 		EdgeType:  q.Get("edge_type"),
// 		Page:      q.Get("page"),
// 		PageSize:  q.Get("page_size"),
// 	}

// 	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
// 		UserID:   claims.UserID,
// 		TenantID: claims.TenantID,
// 		DBName:   claims.DBName,
// 	}, identityID, params)
// 	if err != nil {
// 		var ve *svcnewapi.IdentityDetailValidationError
// 		var nf *svcnewapi.IdentityDetailNotFoundError
// 		switch {
// 		case errors.As(err, &ve):
// 			writeJSON(w, http.StatusBadRequest, models.APIResponse{
// 				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
// 			})
// 		case errors.As(err, &nf):
// 			writeJSON(w, http.StatusNotFound, models.APIResponse{
// 				Success: false, Message: nf.Msg, Error: "NOT_FOUND",
// 			})
// 		default:
// 			log.Printf("identity detail: user=%s tenant=%s db=%s id=%s: %v", claims.UserID, claims.TenantID, claims.DBName, identityID, err)
// 			writeJSON(w, http.StatusInternalServerError, models.APIResponse{
// 				Success: false, Message: "Failed to load identity detail", Error: "IDENTITY_DETAIL_FAILED",
// 			})
// 		}
// 		return
// 	}

// 	writeJSON(w, http.StatusOK, resp)
// }




























package newapi

import (
	"errors"
	"log"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type IdentityDetailHandler struct {
	svc *svcnewapi.IdentityDetailService
}

func NewIdentityDetailHandler(svc *svcnewapi.IdentityDetailService) *IdentityDetailHandler {
	return &IdentityDetailHandler{svc: svc}
}

// Get implements GET /api/v1/identities/:id.
func (h *IdentityDetailHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	identityID := mux.Vars(r)["id"]

	q := r.URL.Query()
	params := svcnewapi.IdentityDetailParams{
		Tab:       q.Get("tab"),
		TimeRange: q.Get("time_range"),
		Service:   q.Get("service"),
		UsedOnly:  q.Get("used_only"),
		Depth:     q.Get("depth"),
		EdgeType:  q.Get("edge_type"),
		Page:      q.Get("page"),
		PageSize:  q.Get("page_size"),
	}

	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	}, identityID, params)
	if err != nil {
		var ve *svcnewapi.IdentityDetailValidationError
		var nf *svcnewapi.IdentityDetailNotFoundError
		switch {
		case errors.As(err, &ve):
			writeJSON(w, http.StatusBadRequest, models.APIResponse{
				Success: false, Message: ve.Msg, Error: "INVALID_FILTER",
			})
		case errors.As(err, &nf):
			writeJSON(w, http.StatusNotFound, models.APIResponse{
				Success: false, Message: nf.Msg, Error: "NOT_FOUND",
			})
		default:
			log.Printf("identity detail: user=%s tenant=%s db=%s id=%s: %v", claims.UserID, claims.TenantID, claims.DBName, identityID, err)
			writeJSON(w, http.StatusInternalServerError, models.APIResponse{
				Success: false, Message: "Failed to load identity detail", Error: "IDENTITY_DETAIL_FAILED",
			})
		}
		return
	}

	writeJSON(w, http.StatusOK, resp)
}