package newapi

import (
	"log"
	"net/http"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/models"
	svcnewapi "nhi-backend-api/internal/services/new_api"
)

type FilterOptionsHandler struct {
	svc *svcnewapi.FilterOptionsService
}

func NewFilterOptionsHandler(svc *svcnewapi.FilterOptionsService) *FilterOptionsHandler {
	return &FilterOptionsHandler{svc: svc}
}

// Get implements GET /api/v1/filters.
func (h *FilterOptionsHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, models.APIResponse{
			Success: false, Message: "Unauthorized", Error: "UNAUTHORIZED",
		})
		return
	}

	resp, err := h.svc.Get(r.Context(), svcnewapi.Identity{
		UserID:   claims.UserID,
		TenantID: claims.TenantID,
		DBName:   claims.DBName,
	})
	if err != nil {
		log.Printf("filter options: user=%s tenant=%s db=%s: %v", claims.UserID, claims.TenantID, claims.DBName, err)
		writeJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false, Message: "Failed to load filter options", Error: "FILTER_OPTIONS_FAILED",
		})
		return
	}

	writeJSON(w, http.StatusOK, resp)
}