package handlers

import (
	"net/http"
	"strconv"
	"strings"

	"nhi-backend-api/internal/models"
	repo "nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
)

type AttackPathsHandler struct {
	service *services.AttackPathsService
}

func NewAttackPathsHandler(service *services.AttackPathsService) *AttackPathsHandler {
	return &AttackPathsHandler{service: service}
}

func (h *AttackPathsHandler) List(w http.ResponseWriter, r *http.Request) {
	maxHops := 3
	if raw := strings.TrimSpace(r.URL.Query().Get("max_hops")); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed < 1 || parsed > 10 {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "max_hops must be between 1 and 10"})
			return
		}
		maxHops = parsed
	}

	result, err := h.service.Find(r.Context(), repo.AttackPathsFilter{
		AccountID:  strings.TrimSpace(r.URL.Query().Get("account_id")),
		SourceType: strings.TrimSpace(r.URL.Query().Get("source_type")),
		MaxHops:    maxHops,
	})
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load attack paths", Error: err.Error()})
		return
	}
	sendJSON(w, http.StatusOK, result)
}
