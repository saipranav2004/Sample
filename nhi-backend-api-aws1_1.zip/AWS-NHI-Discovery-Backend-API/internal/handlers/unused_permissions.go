package handlers

import (
	"net/http"
	"strings"

	"nhi-backend-api/internal/models"
	"nhi-backend-api/internal/repository"
	"nhi-backend-api/internal/services"
)

type UnusedPermissionsHandler struct {
	service *services.UnusedPermissionsService
}

func NewUnusedPermissionsHandler(service *services.UnusedPermissionsService) *UnusedPermissionsHandler {
	return &UnusedPermissionsHandler{service: service}
}

func (h *UnusedPermissionsHandler) List(w http.ResponseWriter, r *http.Request) {
	result, err := h.service.Summary(r.Context(), repository.UnusedPermissionsFilter{
		AccountID:      strings.TrimSpace(r.URL.Query().Get("account_id")),
		CredentialType: strings.TrimSpace(r.URL.Query().Get("credential_type")),
	})
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load unused permissions", Error: err.Error()})
		return
	}
	sendJSON(w, http.StatusOK, result)
}
