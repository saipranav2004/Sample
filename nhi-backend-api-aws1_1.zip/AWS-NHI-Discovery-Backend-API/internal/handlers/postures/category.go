// package handlers

// import (
// 	"encoding/json"
// 	"log"
// 	"net/http"

// 	services "nhi-backend-api/internal/services/postures"
// )

// type CategoryHandler struct {
// 	svc *services.CategoryService
// }

// func NewCategoryHandler(svc *services.CategoryService) *CategoryHandler {
// 	return &CategoryHandler{svc: svc}
// }

// // Get implements GET /api/v1/postures/categories?scan_id=optional
// func (h *CategoryHandler) Get(w http.ResponseWriter, r *http.Request) {
// 	scanID := r.URL.Query().Get("scan_id")

// 	resp, err := h.svc.GetAll(r.Context(), scanID)
// 	if err != nil {
// 		log.Printf("categories: scan_id=%q: %v", scanID, err)
// 		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
// 			"success": false, "message": "Failed to load categories",
// 		})
// 		return
// 	}

// 	writeJSON(w, http.StatusOK, map[string]interface{}{
// 		"success": true, "data": resp,
// 	})
// }

// func writeJSON(w http.ResponseWriter, status int, payload interface{}) {
// 	w.Header().Set("Content-Type", "application/json")
// 	w.WriteHeader(status)
// 	_ = json.NewEncoder(w).Encode(payload)
// }














package handlers

import (
	"encoding/json"
	"log"
	"net/http"
	"strings"

	"nhi-backend-api/internal/middleware"
	services "nhi-backend-api/internal/services/postures"
)

type CategoryHandler struct {
	svc *services.CategoryService
}

func NewCategoryHandler(svc *services.CategoryService) *CategoryHandler {
	return &CategoryHandler{svc: svc}
}

// Get implements GET /api/v1/postures/categories?scan_id=optional
// The tenant database comes from the JWT (db_name), never from the request.
func (h *CategoryHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeJSON(w, http.StatusUnauthorized, map[string]interface{}{
			"success": false, "message": "Unauthorized", "error": "UNAUTHORIZED",
		})
		return
	}

	scanID := strings.TrimSpace(r.URL.Query().Get("scan_id"))

	resp, err := h.svc.GetAll(r.Context(), claims.DBName, scanID)
	if err != nil {
		log.Printf("categories: user=%s tenant=%s db=%s scan_id=%q: %v",
			claims.UserID, claims.TenantID, claims.DBName, scanID, err)
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false, "message": "Failed to load categories", "error": "CATEGORIES_FAILED",
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true, "data": resp,
	})
}

func writeJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}
