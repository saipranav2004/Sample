package dashboard

import (
	"net/http"
	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
	"strconv"
)

type ActivityHeatmapHandler struct {
	service *svcdashboard.ActivityHeatmapService
}

func NewActivityHeatmapHandler(service *svcdashboard.ActivityHeatmapService) *ActivityHeatmapHandler {
	return &ActivityHeatmapHandler{service: service}
}
func (h *ActivityHeatmapHandler) Heatmap(w http.ResponseWriter, r *http.Request) {
	days := 7
	if raw := r.URL.Query().Get("days"); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed <= 0 || parsed > 365 {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "days must be between 1 and 365"})
			return
		}
		days = parsed
	}
	result, err := h.service.Heatmap(r.Context(), repodashboard.ActivityHeatmapFilter{AccountID: r.URL.Query().Get("account_id"), Days: days})
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load activity heatmap", Error: err.Error()})
		return
	}
	sendJSON(w, http.StatusOK, result)
}
