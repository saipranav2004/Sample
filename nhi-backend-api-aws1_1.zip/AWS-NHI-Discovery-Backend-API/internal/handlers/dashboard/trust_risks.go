package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type TrustRisksHandler struct {
	service *svcdashboard.TrustRisksService
}

func NewTrustRisksHandler(service *svcdashboard.TrustRisksService) *TrustRisksHandler {
	return &TrustRisksHandler{service: service}
}

func (h *TrustRisksHandler) Summary(w http.ResponseWriter, r *http.Request) {
	filter := repodashboard.TrustRisksFilter{
		AccountID: r.URL.Query().Get("account_id"),
	}

	result, err := h.service.Summary(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load trust risk summary",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
