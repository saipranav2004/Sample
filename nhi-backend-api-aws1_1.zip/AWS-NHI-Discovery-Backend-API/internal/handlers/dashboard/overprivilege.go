package dashboard

import (
	"net/http"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type OverprivilegeHandler struct {
	service *svcdashboard.OverprivilegeService
}

func NewOverprivilegeHandler(service *svcdashboard.OverprivilegeService) *OverprivilegeHandler {
	return &OverprivilegeHandler{service: service}
}

func (h *OverprivilegeHandler) Summary(w http.ResponseWriter, r *http.Request) {
	filter := repodashboard.OverprivilegeFilter{
		AccountID: r.URL.Query().Get("account_id"),
	}

	result, err := h.service.Summary(r.Context(), filter)
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{
			Success: false,
			Message: "failed to load overprivilege summary",
			Error:   err.Error(),
		})
		return
	}

	sendJSON(w, http.StatusOK, result)
}
