package dashboard

import (
	"net/http"
	"strconv"

	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type SharedCredentialsHandler struct {
	service *svcdashboard.SharedCredentialsService
}

func NewSharedCredentialsHandler(service *svcdashboard.SharedCredentialsService) *SharedCredentialsHandler {
	return &SharedCredentialsHandler{service: service}
}

func (h *SharedCredentialsHandler) List(w http.ResponseWriter, r *http.Request) {
	minIdentities := 2
	if raw := r.URL.Query().Get("min_identities"); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed < 1 {
			sendJSON(w, http.StatusBadRequest, models.APIResponse{Success: false, Message: "min_identities must be a positive integer"})
			return
		}
		minIdentities = parsed
	}
	result, err := h.service.List(r.Context(), repodashboard.SharedCredentialsFilter{MinIdentities: minIdentities})
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load shared credentials", Error: err.Error()})
		return
	}
	sendJSON(w, http.StatusOK, result)
}
