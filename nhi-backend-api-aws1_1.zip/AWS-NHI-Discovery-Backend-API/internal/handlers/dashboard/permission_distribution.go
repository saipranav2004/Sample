package dashboard

import (
	"net/http"
	"nhi-backend-api/internal/models"
	repodashboard "nhi-backend-api/internal/repository/dashboard"
	svcdashboard "nhi-backend-api/internal/services/dashboard"
)

type PermissionDistributionHandler struct {
	service *svcdashboard.PermissionDistributionService
}

func NewPermissionDistributionHandler(service *svcdashboard.PermissionDistributionService) *PermissionDistributionHandler {
	return &PermissionDistributionHandler{service: service}
}
func (h *PermissionDistributionHandler) Distribution(w http.ResponseWriter, r *http.Request) {
	result, err := h.service.Distribution(r.Context(), repodashboard.PermissionDistributionFilter{AccountID: r.URL.Query().Get("account_id")})
	if err != nil {
		sendJSON(w, http.StatusInternalServerError, models.APIResponse{Success: false, Message: "failed to load permission distribution", Error: err.Error()})
		return
	}
	sendJSON(w, http.StatusOK, result)
}
