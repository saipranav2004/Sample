// package middleware

// import (
// 	"context"
// 	"encoding/json"
// 	"net/http"
// 	"strings"

// 	"nhi-backend-api/internal/config"
// 	"nhi-backend-api/internal/models"
// 	"nhi-backend-api/pkg/jwt"
// )

// type contextKey string

// const UserClaimsKey contextKey = "userClaims"

// type AuthMiddleware struct {
// 	jwtCfg config.JWTConfig
// }

// func NewAuthMiddleware(jwtCfg config.JWTConfig) *AuthMiddleware {
// 	return &AuthMiddleware{jwtCfg: jwtCfg}
// }

// // Authenticate verifies the incoming Bearer JWT token
// func (m *AuthMiddleware) Authenticate(next http.Handler) http.Handler {
// 	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
// 		authHeader := r.Header.Get("Authorization")
// 		if authHeader == "" {
// 			respondUnauthorized(w, "Missing Authorization header")
// 			return
// 		}

// 		parts := strings.Split(authHeader, " ")
// 		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
// 			respondUnauthorized(w, "Invalid Authorization format. Expected 'Bearer <token>'")
// 			return
// 		}

// 		tokenString := parts[1]
// 		claims, err := jwt.ValidateToken(tokenString, m.jwtCfg.Secret)
// 		if err != nil {
// 			respondUnauthorized(w, "Invalid or expired token")
// 			return
// 		}

// 		// Inject authenticated claims into request context
// 		ctx := context.WithValue(r.Context(), UserClaimsKey, claims)
// 		next.ServeHTTP(w, r.WithContext(ctx))
// 	})
// }

// func respondUnauthorized(w http.ResponseWriter, msg string) {
// 	w.Header().Set("Content-Type", "application/json")
// 	w.WriteHeader(http.StatusUnauthorized)
// 	json.NewEncoder(w).Encode(models.APIResponse{
// 		Success: false,
// 		Message: msg,
// 		Error:   "UNAUTHORIZED",
// 	})
// }

// // GetClaims retrieves user claims from context
// func GetClaims(r *http.Request) *jwt.CustomClaims {
// 	claims, ok := r.Context().Value(UserClaimsKey).(*jwt.CustomClaims)
// 	if !ok {
// 		return nil
// 	}
// 	return claims
// }





















package middleware

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/models"
	"nhi-backend-api/pkg/jwt"
)

type contextKey string

const UserClaimsKey contextKey = "userClaims"

// UserStatusChecker lets the middleware ask "is this user still active?".
// services.AuthService implements it.
type UserStatusChecker interface {
	IsActive(ctx context.Context, userID string) (bool, error)
}

type AuthMiddleware struct {
	jwtCfg config.JWTConfig
	status UserStatusChecker
}

func NewAuthMiddleware(jwtCfg config.JWTConfig, status UserStatusChecker) *AuthMiddleware {
	return &AuthMiddleware{jwtCfg: jwtCfg, status: status}
}

// Authenticate verifies the incoming Bearer JWT token
func (m *AuthMiddleware) Authenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			respondUnauthorized(w, "Missing Authorization header")
			return
		}

		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			respondUnauthorized(w, "Invalid Authorization format. Expected 'Bearer <token>'")
			return
		}

		tokenString := parts[1]
		claims, err := jwt.ValidateToken(tokenString, m.jwtCfg.Secret)
		if err != nil {
			respondUnauthorized(w, "Invalid or expired token")
			return
		}

		// A valid token must identify the user, the tenant and the data database.
		if claims.UserID == "" || claims.TenantID == "" || claims.DBName == "" {
			respondUnauthorized(w, "Token is missing user_id, tenant_id or db_name — please log in again")
			return
		}

		// The token is valid, but is the user still allowed in?
		if m.status != nil {
			active, err := m.status.IsActive(r.Context(), claims.UserID)
			if err != nil {
				respondError(w, http.StatusServiceUnavailable, "Unable to verify account status", "SERVICE_UNAVAILABLE")
				return
			}
			if !active {
				respondUnauthorized(w, "Account is not active")
				return
			}
		}

		// Inject authenticated claims into request context
		ctx := context.WithValue(r.Context(), UserClaimsKey, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func respondUnauthorized(w http.ResponseWriter, msg string) {
	respondError(w, http.StatusUnauthorized, msg, "UNAUTHORIZED")
}

func respondError(w http.ResponseWriter, code int, msg, errCode string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(models.APIResponse{
		Success: false,
		Message: msg,
		Error:   errCode,
	})
}

// GetClaims retrieves user claims from context
func GetClaims(r *http.Request) *jwt.CustomClaims {
	claims, ok := r.Context().Value(UserClaimsKey).(*jwt.CustomClaims)
	if !ok {
		return nil
	}
	return claims
}