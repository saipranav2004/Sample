package scope

import "testing"

func TestDataScopeQualifiesSchema(t *testing.T) {
	s := &DataScope{Schema: "tenant_a"}
	if got, want := s.QSchema(), `"tenant_a"`; got != want {
		t.Errorf("QSchema() = %s, want %s", got, want)
	}
	if got, want := s.Table("identities"), `"tenant_a"."identities"`; got != want {
		t.Errorf("Table() = %s, want %s", got, want)
	}
	// Defensive: embedded quotes are escaped rather than breaking out.
	evil := &DataScope{Schema: `a"b`}
	if got, want := evil.QSchema(), `"a""b"`; got != want {
		t.Errorf("QSchema() = %s, want %s", got, want)
	}
}
