# Project structure

```text
cmd/api-server/main.go            single entry point: config, database, wiring, HTTP server
configs/config.yaml               runtime configuration (secrets come from the environment)
internal/routes/routes.go         the one router; every /api route except login is behind JWT
internal/middleware/              JWT auth, CORS, request logging, v1 panic recovery
internal/{models,repository,services,handlers}/
    dashboard/                    /api/v1/dashboard/* (#1-#8)
    inventory/                    /api/v1/inventory/identities* (A1-A9)
    secscan/                      secret scanner: /api/findings, /api/allowlist, /api/findings/decision,
                                  /api/deep-scan-status, /api/deep-scan
internal/{handlers,services,repository,models}/*.go
                                  auth and the legacy /api/* routes (identities, lineage, consumers,
                                  secrets, credentials, scans, events, dashboard/summary, my-resources)
internal/config/                  config loader with environment overrides
migrations/                       SQL migrations for the users table
pkg/jwt, pkg/utils                token signing, pagination helpers
docs/                             API notes, schema references and source specifications
```

Each feature area keeps one flat package per layer: handler (HTTP and
validation) -> service (rules) -> repository (SQL) -> models (shapes).

- [Integration status](INTEGRATION_STATUS.md) - what each route returns today.
- [Secret scanner API](docs/SECRET_SCANNER_API.md) - endpoints, roles, errors, grants.
