> **HISTORICAL INITIAL REPORT (superseded).** After this report, the team supplied its complete current scanner column list. For the code's **current** behavior, schema assumptions, and integration test result, read [CURRENT_SCHEMA_ALIGNMENT.md](CURRENT_SCHEMA_ALIGNMENT.md). Statements below about `scan_start`, `discovered_at`, scanner JSONB columns, and unchanged response contracts describe the initial candidate, **not** the current release.

# Backend API: Oracle → PostgreSQL — team handoff

**Status: API code converted and tested against a disposable PostgreSQL 17 database. Not yet a production data cutover.** Source was the 45-file ZIP uploaded as `output.txt` (misnamed `.txt`); no Oracle schema/data dump and no scanner/ETL source were included. The original project did not have a usable `configs/config.yaml`, its README was empty, and it had no tests. The converted project is in `backend-postgres/`; the original is preserved separately in `backend-original/`.

## What changed

| Layer | Oracle behavior | PostgreSQL implementation |
|---|---|---|
| Driver/connection | `go-ora`, `sql.Open("oracle", …)`, Oracle service name | `lib/pq`, `sql.Open("postgres", …)`, database name + URL-escaped credentials + `sslmode` (default `require`). Ping with timeout; close connection on ping failure. `PostgresDB` replaces `OracleDB`. |
| Config | Oracle URL, service_name; config file absent | `database.name`, host/port/user, SSL mode; env overrides `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_SSLMODE`, `JWT_SECRET`; added example YAML. No credentials committed. |
| Parameters | `:1`, `:2` … | `$1`, `$2` …; dynamic filters keep bound parameters. Pagination placeholder positions and argument order were corrected and tested. |
| Latest scan | nested SELECT + `ROWNUM = 1` | `ORDER BY scan_start DESC, scan_id DESC LIMIT 1`; default for identity/event/dashboard/credential/lineage and now consumers. Explicit `scan_id` is still supported. |
| Pagination | Oracle `OFFSET … FETCH NEXT …`, ROWNUM wrapping | `LIMIT $n OFFSET $m` and stable sort where possible; consumer grouped-query pagination rewritten. |
| Functions/date math | `NVL`, `SYSDATE - N`, `DBMS_LOB.GETLENGTH`, `REGEXP_COUNT`, `JSON_TABLE`, `TO_CHAR` | `COALESCE`, `CURRENT_TIMESTAMP - INTERVAL 'N days'`, `jsonb_array_length`, `jsonb_array_elements` + `->>`, UTC `TO_CHAR(timestamp AT TIME ZONE 'UTC', …)`. |
| DDL/seeds | Oracle `NUMBER`, `VARCHAR2`, `SYSTIMESTAMP`, plaintext `admin123` seed | PostgreSQL identity key, `varchar`, `timestamptz DEFAULT now()`. Unsafe/unusable default admin seed removed; manually provision bcrypt hash. No sessions table created because the original migration was empty and JWT is stateless. |
| Tests | None | Integration coverage for all eight data repositories on PostgreSQL 17, including latest/explicit scans, JSONB credentials, grouped consumers, paging and filtering; `go test ./...` and `go vet ./...` pass. |

**API paths and JSON contracts remain unchanged** (`/api/auth/*`, `/api/dashboard/*`, `/api/identities`, `/api/identities/lineage`, `/api/identities/consumers`, `/api/secrets`, `/api/credentials`, `/api/scans`, `/api/events`). The consumer endpoint now defaults to the latest completed scan rather than mixing scans when `scan_id` is omitted; this is a deliberate behavior correction to match other endpoints. NULL classification appears as `UNKNOWN` in the dashboard breakdown instead of being silently dropped. Empty Oracle strings and PostgreSQL empty strings differ and must be reconciled during data migration.

## File-by-file audit (all 45 source archive members)

| File(s) | Assessment and action |
|---|---|
| `cmd/api-server/main.go` | Switch constructor to `NewPostgresDB`; route/service wiring unchanged. |
| `go.mod`, `go.sum` | Remove Oracle driver; add `github.com/lib/pq v1.10.9`; tidied sums. Go version stays at original `1.26.5`. |
| `internal/config/config.go` | Replace service name/Oracle DSN with PostgreSQL DSN, environment overrides and required-field checks. |
| `internal/repository/oracle.go` | Removed; replaced by `internal/repository/postgres.go` with pool, ping and close. |
| `internal/repository/user_repo.go` | PostgreSQL placeholders; nullable profile fields scan safely. Login still uses bcrypt in service layer. |
| `internal/repository/scan_repo.go` | PostgreSQL LIMIT/OFFSET, deterministic scan order, row iteration check. |
| `internal/repository/identity_repo.go` | Latest scan, JSON-array filters/text extraction (JSONB or valid JSON TEXT), intervals, UTC timestamp formatting, NULL handling and pagination. Integer flags remain 0/1. |
| `internal/repository/event_repo.go` | PostgreSQL placeholders/latest scan/pagination with stable id tie-breaker. |
| `internal/repository/dashboard_repo.go` | `COALESCE`, interval metrics, JSON array count and type breakdown (JSONB or valid JSON TEXT); NULL classification covered. |
| `internal/repository/credential_repo.go` | Replace `JSON_TABLE` with lateral JSONB expansion; retain IAM roles as synthetic credentials; UTC timestamp strings, filters, paging. |
| `internal/repository/consumer_repo.go` | Replace Oracle ROWNUM pagination, preserve grouped consumer semantics; use `sql.NullTime`, default latest scan, check scan/iteration errors. |
| `internal/repository/lineage_repo.go` | Replace Oracle functions/paging; return row scan errors rather than silently ignoring records. |
| `migrations/001_create_users.sql` | PostgreSQL users schema/table, unique email; no redundant index. |
| `migrations/002_create_sessions.sql` | Originally 0 bytes; documented no-op. |
| `migrations/003_seed_admin_user.sql` | Old plaintext seed was incompatible with bcrypt and unsafe; now comments/manual instruction only. |
| `internal/handlers/auth.go`, `credential.go`, `dashboard.go`, `events.go`, `identities.go`, `lineage.go`, `scans.go`, `secrets.go` | No direct database code; endpoints and payload handling left unchanged. Existing raw database-error response exposure is a separate security follow-up. |
| `internal/middleware/auth.go`, `cors.go`, `logger.go` | No database-specific code; unchanged except `gofmt`. |
| `internal/models/credential.go`, `event.go`, `identity.go`, `lineage.go`, `response.go`, `scan.go`, `user.go` | API types/JSON tags stay unchanged; no direct Oracle dependency. Their `int` flag fields require numeric PostgreSQL columns. |
| `internal/routes/routes.go` | All routes remain registered as before; no DB coupling. |
| `internal/services/auth_service.go`, `consumer_service.go`, `credential_service.go`, `dashboard_service.go`, `identity_service.go`, `lineage_service.go`, `scan_service.go` | Business logic unchanged; repositories retain constructors/API signatures. |
| `pkg/jwt/jwt.go`, `pkg/utils/helpers.go` | No database dependency; unchanged except formatting. |
| `README.md` | Previously empty; added setup, caveats, safety steps. |

New: `configs/config.example.yaml`, `docs/scanner_schema_reference.sql`, `docs/validate_schema.sql`, `internal/repository/postgres_integration_test.go`, and this report. The reference SQL is **not an approved production migration**; it contains inferred definitions solely to enable an end-to-end development test. `gofmt` may also produce whitespace-only diffs in untouched Go files.

## Production prerequisites / blocking questions

1. **Get authoritative Oracle DDL and scanner/ETL code** for `nhi_scanner.nhi_scans_aws`, `nhi_identities_aws`, `nhi_events_aws`, `nhi_lineage_aws` (and any other writers/readers). The archive only includes `nhi_users` DDL. Confirm actual column names, data types, nullability, keys, duplicate scan handling, identity/sequence strategy and where data is written. The API alone cannot migrate Oracle records or make the scanner write to PostgreSQL.
2. **Agree on target type contract.** Current Go queries expect `owned_credentials` as JSONB (recommended) or TEXT holding a valid JSON **array** (`[]` if none); SQL NULL, empty TEXT and JSON null are treated as []; `is_secret`, `is_admin`, `mfa_enabled`, `is_external` as 0/1 numeric (not PostgreSQL BOOLEAN); `last_active`, `created_at`, `password_last_used`, `access_key_1_last_used`, `scan_start`, `scan_end`, `event_time`, `discovered_at`, and user `created_at` as `timestamptz` stored with correct UTC instants. `attached_policies` remains comma-separated TEXT, not an array. `read_only` remains text, matching the current model. Adapt queries and models together if the production schema chooses other types.
3. **Migrate data, not just schema.** Inventory Oracle row counts, NULL and empty-string semantics, CLOB JSON validity, time zones, primary keys and max sequence values. Extract to staging, transform Oracle CLOB → valid JSONB array, flags → 0/1, dates → correct UTC instants, preserve IDs, then set PostgreSQL identity sequence above MAX(id) when explicit IDs are loaded (if identity mode allows it). Reconcile counts by table/scan and credential JSON array totals; verify sample joins and API responses. Run dual-read/compare or a scheduled freeze, then switch scanner writer and API together. Keep Oracle snapshot and rollback window.
4. **Provision infrastructure/security.** Create database and `nhi_scanner` schema with controlled owner/privileges. Grant application role `USAGE` on schema, `SELECT` on scanner/users tables (more permissions only if needed for provisioning); secure network, TLS and credentials through secret manager. Set `DB_SSLMODE=require` or stronger (validate TLS certificates per your deployment standard). Set a strong `JWT_SECRET`. Update deployment manifests, connection pool sizing, readiness checks and backups. The `/health` route is only a process check, **not** a database readiness check.
5. **Fix old seed/account management.** bcrypt is required by `AuthService`; plaintext `admin123` never authenticated. Seed an actual bcrypt hash through an approved provisioning process; decide whether existing Oracle user hashes can be copied. Do not ship a fixed default admin credential.
6. **Validate product/security edge cases.** Current handlers return internal DB error strings to clients; sanitize 5xx messages in a separate review. Large offset paging, `LIKE` wildcard interpretation, NHI role credentials being counted separately from dashboard JSON credential totals, case-sensitive PostgreSQL collations, and possibly nullable imported fields need owner acceptance. The test schema uses BIGINT IDs while Go models use `int` (safe on deployed 64-bit systems; review if IDs exceed range). The original auth flow has no DB sessions despite the empty migration.

## Recommended rollout

- **Before deployment:** Compare real Oracle DDL with the reference schema, approve a production DDL/data-conversion plan, implement scanner writes, migrate records, and run `docs/validate_schema.sql` against a staging database (its last query assumes a JSONB credentials column). Run full scanner + API smoke tests using representative scans and users.
- **Checks:** `go test ./...`; run the PostgreSQL integration test only on a disposable database named `*_test` after applying the reference schema and users migration; `go vet ./...`; check login, `/auth/me`, latest/explicit scans, all list filters, pagination and dashboard counts on migrated data. Compare per-scan Oracle/PostgreSQL count and sample JSON output.
- **Cutover:** Backup Oracle + PostgreSQL, pause writers, sync delta, validate counts/JSON/time zones and identities, start new PostgreSQL writer, point API to PG credentials, monitor 5xx/latency and roll back writer + API together if validation fails. Do not run the reference DDL blindly on production.

## Verification completed here

- `go mod tidy`, `go test ./...` and `go vet ./...`: pass (Go 1.26.5).
- PostgreSQL 17 disposable `nhi_test` with JSONB and `nhi_text_test` with TEXT credentials: applied reference tables + users migration, changing TEXT variant's credentials column type in the second DB; the same integration test exercised user, scan, identity filters, dashboard, credential JSON/role union, events, consumers, lineage, latest-vs-explicit scan, pagination. Passed on both.
- **Not verified:** against your actual Oracle database/data, your actual PostgreSQL deployment, scanner writes, authentication end-to-end, load/latency, or production schemas. These require the missing DDL/data and access.

## Field issue found during first external test (2026-09-29)

A user database returned `pq: COALESCE types text and jsonb cannot be matched` from dashboard summary. The original conversion assumed JSONB, while their `owned_credentials` column appears to be TEXT. The three repository queries now normalize `owned_credentials::text` to JSONB for JSON operations and handle SQL NULL, empty string, and JSON null. This is **not** a substitute for validating the real production schema and JSON contents; invalid JSON or a JSON object where an array is expected will still error. Verify with `information_schema.columns` and `docs/validate_schema.sql`.
