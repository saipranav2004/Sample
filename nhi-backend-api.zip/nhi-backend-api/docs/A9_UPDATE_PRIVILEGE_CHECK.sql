-- READ ONLY. Run as the SAME PostgreSQL role configured for the API server,
-- not merely as pgAdmin's postgres superuser. Does not update any identity.
SELECT current_database() AS database_name,
       current_user AS application_db_role,
       has_table_privilege(current_user, 'nhi_scanner.identities', 'SELECT') AS can_select_table,
       has_column_privilege(current_user, 'nhi_scanner.identities', 'functional_class', 'UPDATE') AS can_update_functional_class,
       has_column_privilege(current_user, 'nhi_scanner.identities', 'owner', 'UPDATE') AS can_update_owner,
       has_column_privilege(current_user, 'nhi_scanner.identities', 'environment', 'UPDATE') AS can_update_environment,
       has_column_privilege(current_user, 'nhi_scanner.identities', 'updated_at', 'UPDATE') AS can_update_updated_at;
-- If any UPDATE check is false, A9's valid PATCH will return 503 (SQLSTATE 42501)
-- until the database administrator grants narrowly scoped privileges.
-- No migration or GRANT is made by this query.
