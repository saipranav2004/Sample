# Confirmed catalog, account policy, and remaining business definitions

PDF dashboard APIs #1–#5 and #8 use rows from `nhi_scanner.identities` (UUID-keyed catalog); #1 also reads account-scoped scan metadata from `nhi_scanner.nhi_scans_aws` when no region is requested. Its credential/scan-duration/region-coverage fields are explicitly null pending authoritative sources. Approved **policy A** permits *all authenticated dashboard users* to view *all known AWS accounts*; JWT remains required. The single central main and router are retained.

The lead directed that #4/#5 omit unavailable `account_name`. The credentials table is not created, so #4/#5 serialize unavailable `credential_count` as **JSON null**, not zero; see [API #3–#5 contract](API_3_4_5_ANALYSIS_AND_INTEGRATION.md). The new #6/#7 credential endpoints are registered but return **HTTP 503** rather than inventing PDF metrics; see credential-source requirements.

API #8 uses catalog columns for public and dormant cards. Its owner/environment-tag cards currently use normalized `owner`/`environment` column emptiness as a **provisional rule**. Confirm whether the business definition instead requires inspecting `tags` JSONB. NULL `last_activity_at` currently counts as `no_activity_tracked` and is excluded from dormant; confirm desired semantics. There is **no confirmed IaC marker**: `not_in_iac` remains **JSON null** until the product specifies a validated source. See [API #8 metric notes](API_8_EXPOSURE_ANALYSIS.md).

Do not execute fixture tests against `nhi_db`; optional integration tests CREATE/TRUNCATE fixture tables and require a fresh disposable `*_test` database.
