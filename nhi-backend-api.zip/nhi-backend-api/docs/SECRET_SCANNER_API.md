# Secret scanner (credential exposure) API

The dashboard used to reach the scanner's Python API through a proxy that
attached `X-Dashboard-Key`. This backend now serves the same endpoints itself,
reading the scanner's tables in `nhi_scanner` directly. There is no proxy, no
upstream URL and no scanner key in configuration.

Code: `internal/{models,repository,services,handlers}/secscan/`, registered in
`internal/routes/routes.go`, wired in `cmd/api-server/main.go`.

## Endpoints

All require `Authorization: Bearer <JWT>` (the token from `POST /api/auth/login`).
Paths and response bodies are the ones in *API_Integration_Guide_Updated_3*.

| Method | Path | Body / query | Response |
|---|---|---|---|
| GET | `/api/findings` | optional `client_id`, `platform` (`codecommit`\|`github`) | `{"count", "findings":[...]}` - visible findings, newest first |
| GET | `/api/allowlist` | optional `client_id` | `{"entries":[...]}` - every entry, each with `source` |
| POST | `/api/allowlist` | `{client_id, file_path, detector, redacted, reason?}` | `{"ok":true, "entry":{...}}` |
| DELETE | `/api/allowlist` | `{client_id, file_path, detector, redacted}` | `{"ok":true\|false}` (false = nothing matched, not an error) |
| POST | `/api/findings/decision` | `{finding_id, platform, decision}`; decision `real_secret`\|`false_positive` | `{"ok":true}` |
| GET | `/api/deep-scan-status` | `client_id`, `repository` | deep-scan record, or `{"status":"not_started"}` |
| POST | `/api/deep-scan` | `{client_id, repository}` | **501** `DEEP_SCAN_UNAVAILABLE` - see below |

### Findings

- Read from `secscan_findings_codecommit` and `secscan_findings_github` in one
  statement (one consistent snapshot).
- A finding is hidden when its `(client_id, file_path, detector, redacted)`
  matches an entry in **its own platform's allowlist or the dashboard
  allowlist**, compared exactly.
- `platform` is taken from the table the row came from, so legacy rows with
  `platform = NULL` read `codecommit`.
- Nullable columns stay JSON `null` (never `0` or `""`). `ml_score` null means
  "never scored". Extra fields beyond the guide: `ml_score`, `ml_decision`,
  `ml_model_version`, `analyst_decision`, `analyst_decided_at`,
  `analyst_decided_by`.
- Ordered by `created_at` (ISO-8601 UTC text) descending, then platform and
  `finding_id`, so the order is stable.

### Allowlist

- `GET` returns the entries of all three tables. `source` says which:
  `dashboard`, `codecommit` or `github`.
- `POST` and `DELETE` write **only** `secscan_allowlist_dashboard`. The two
  platform allowlists belong to the scanner stacks. A finding hidden by its
  platform's own allowlist stays hidden after a dashboard `DELETE`.
- `POST` only accepts a key that belongs to an existing finding (404
  otherwise). Re-posting the same key updates `reason`, `dismissed_by` and
  `dismissed_at`.
- `dismissed_by` is always the authenticated user's email. A `dismissed_by`
  in the body is accepted for compatibility and ignored.
- An entry's `redacted` value is limited to 500 characters by the allowlist
  table. A longer redacted value cannot be allowlisted (400).

### Decisions

Writes only `analyst_decision`, `analyst_decided_at` and `analyst_decided_by`
on the row in the given platform's table. `ml_*` and `verification_status`
are untouched. `platform` is required because finding IDs are only unique
within one table.

### Deep scans

`GET /api/deep-scan-status` reads `secscan_deepscan_<platform>` and derives
`status` like the scanner: `failed` if `failed_at` is set, else `complete` if
`completed_at` is set, else `running`. Only the `admin` role sees the raw
`error` text, which can contain account and permission details; other roles
get a fixed message.

`POST /api/deep-scan` answers **501**. Starting a scan means putting a job on
the scanner's own queue (`secscan_jobs_<platform>`), whose payload format is
defined by the scanner service and was not provided. Writing a guessed job
could leave a scan marked `running` forever. To enable it, the scanner team
needs to supply the job contract (or an internal trigger endpoint).

## Who may do what

| Role (`users.role`) | Read findings, allowlist, scan status | Mark safe, restore, record a decision |
|---|---|---|
| `admin` | yes | yes |
| `team_lead` | yes | yes |
| `developer`, `auditor` | yes | no (403) |

All authenticated users see every `client_id`, the same policy the
dashboard applies to AWS accounts. To restrict users to particular clients, add
a trusted user-to-client mapping and filter in the service.

## Errors

Same envelope as the v1 dashboard: `{"error":{"code","message"}}`.

| Status | Code | When |
|---|---|---|
| 400 | `INVALID_FILTER`, `INVALID_BODY`, `INVALID_REQUEST` | unknown/repeated query parameter, malformed JSON, unknown body field, missing or too-long field, bad platform or decision |
| 401 | `UNAUTHORIZED` | missing or invalid token |
| 403 | `FORBIDDEN` | role cannot make changes |
| 404 | `NOT_FOUND` | the key or `finding_id` does not exist |
| 413 | `BODY_TOO_LARGE` | body over 16 KB |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | body not `application/json` |
| 501 | `DEEP_SCAN_UNAVAILABLE` | `POST /api/deep-scan` |
| 503 | `DATA_SOURCE_UNAVAILABLE` | scanner table missing, privilege missing, database down |
| 504 | `TIMEOUT` | the query took longer than 12 s |

Responses carry `Cache-Control: no-store`. No SQL, table name, finding ID or
secret fragment is put in an error or a log line.

## Database grants for the API's role

```sql
GRANT USAGE ON SCHEMA nhi_scanner TO <api_role>;
GRANT SELECT ON nhi_scanner.secscan_findings_codecommit, nhi_scanner.secscan_findings_github,
                nhi_scanner.secscan_allowlist_codecommit, nhi_scanner.secscan_allowlist_github,
                nhi_scanner.secscan_allowlist_dashboard,
                nhi_scanner.secscan_deepscan_codecommit, nhi_scanner.secscan_deepscan_github TO <api_role>;
GRANT INSERT, UPDATE, DELETE ON nhi_scanner.secscan_allowlist_dashboard TO <api_role>;
GRANT UPDATE (analyst_decision, analyst_decided_at, analyst_decided_by)
      ON nhi_scanner.secscan_findings_codecommit, nhi_scanner.secscan_findings_github TO <api_role>;
```

Without the write grants the read endpoints still work; the write endpoints
answer 503.

## Tests

- `internal/services/secscan/service_test.go` - validation, roles, timestamps.
- `internal/routes/secscan_routes_test.go` - the HTTP contract: auth, status
  codes, envelopes, `no-store`, sanitized errors.
- `internal/repository/secscan/repository_integration_test.go` - the SQL,
  against a **disposable** PostgreSQL built from
  `docs/secscan_schema_reference.sql`:

  ```sh
  TEST_DATABASE_URL='postgres://user@localhost:5432/secscan_test?sslmode=disable' \
    go test ./internal/repository/secscan -count=1 -v
  ```

  It drops and recreates the `secscan_*` tables and refuses any database whose
  name does not end in `_test`. Never point it at `nhi_db`.
