-- DEVELOPMENT/TEST reference for the secret scanner tables (nhi_scanner.secscan_*).
-- Written from Postgresql_Tables_Info (column names, types, nullability, keys).
-- The scanner service owns and creates the real tables; never apply this to nhi_db.
-- Used by internal/repository/secscan/repository_integration_test.go.

CREATE SCHEMA IF NOT EXISTS nhi_scanner;

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_findings_codecommit (
    finding_id          VARCHAR(1000) PRIMARY KEY,
    client_id           VARCHAR(200)  NOT NULL,
    repository          VARCHAR(500)  NOT NULL,
    branch              VARCHAR(500)  NOT NULL,
    commit_id           VARCHAR(100)  NOT NULL,
    author              VARCHAR(300)  NOT NULL,
    created_at          VARCHAR(50)   NOT NULL,
    detector            VARCHAR(100)  NOT NULL,
    severity            VARCHAR(50)   NOT NULL,
    file_path           VARCHAR(1000) NOT NULL,
    line_number         INTEGER       NOT NULL,
    redacted            VARCHAR(4000) NOT NULL,
    verification_status VARCHAR(50)   NOT NULL,
    risk_tier           VARCHAR(50)   NOT NULL,
    recommended_action  VARCHAR(200)  NOT NULL,
    codecommit_uri      VARCHAR(2000),
    platform            VARCHAR(50),
    github_uri          VARCHAR(2000),
    line_preview        VARCHAR(4000),
    confidence          VARCHAR(50),
    category            VARCHAR(100),
    committer           VARCHAR(300),
    commit_message      VARCHAR(4000),
    commit_authored_at  VARCHAR(50),
    files_changed       INTEGER,
    additions           INTEGER,
    deletions           INTEGER,
    repo_visibility     VARCHAR(50),
    repo_stars          INTEGER,
    repo_forks          INTEGER,
    repo_pushed_at      VARCHAR(50),
    ml_score            DOUBLE PRECISION,
    ml_decision         VARCHAR(50),
    ml_model_version    VARCHAR(100),
    analyst_decision    VARCHAR(50),
    analyst_decided_at  VARCHAR(50),
    analyst_decided_by  VARCHAR(300)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_findings_github (
    finding_id          VARCHAR(1000) PRIMARY KEY,
    client_id           VARCHAR(200)  NOT NULL,
    repository          VARCHAR(500)  NOT NULL,
    branch              VARCHAR(500)  NOT NULL,
    commit_id           VARCHAR(100)  NOT NULL,
    author              VARCHAR(300)  NOT NULL,
    created_at          VARCHAR(50)   NOT NULL,
    detector            VARCHAR(100)  NOT NULL,
    severity            VARCHAR(50)   NOT NULL,
    file_path           VARCHAR(1000) NOT NULL,
    line_number         INTEGER       NOT NULL,
    redacted            VARCHAR(4000) NOT NULL,
    verification_status VARCHAR(50)   NOT NULL,
    risk_tier           VARCHAR(50)   NOT NULL,
    recommended_action  VARCHAR(200)  NOT NULL,
    codecommit_uri      VARCHAR(2000),
    platform            VARCHAR(50),
    github_uri          VARCHAR(2000),
    line_preview        VARCHAR(4000),
    confidence          VARCHAR(50),
    category            VARCHAR(100),
    committer           VARCHAR(300),
    commit_message      VARCHAR(4000),
    commit_authored_at  VARCHAR(50),
    files_changed       INTEGER,
    additions           INTEGER,
    deletions           INTEGER,
    repo_visibility     VARCHAR(50),
    repo_stars          INTEGER,
    repo_forks          INTEGER,
    repo_pushed_at      VARCHAR(50),
    ml_score            DOUBLE PRECISION,
    ml_decision         VARCHAR(50),
    ml_model_version    VARCHAR(100),
    analyst_decision    VARCHAR(50),
    analyst_decided_at  VARCHAR(50),
    analyst_decided_by  VARCHAR(300)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_allowlist_codecommit (
    client_id    VARCHAR(200)  NOT NULL,
    file_path    VARCHAR(1000) NOT NULL,
    detector     VARCHAR(200)  NOT NULL,
    redacted     VARCHAR(500)  NOT NULL,
    reason       VARCHAR(1000) NOT NULL DEFAULT '',
    dismissed_by VARCHAR(200)  NOT NULL DEFAULT '',
    dismissed_at VARCHAR(50)   NOT NULL,
    PRIMARY KEY (client_id, file_path, detector, redacted)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_allowlist_github (
    client_id    VARCHAR(200)  NOT NULL,
    file_path    VARCHAR(1000) NOT NULL,
    detector     VARCHAR(200)  NOT NULL,
    redacted     VARCHAR(500)  NOT NULL,
    reason       VARCHAR(1000) NOT NULL DEFAULT '',
    dismissed_by VARCHAR(200)  NOT NULL DEFAULT '',
    dismissed_at VARCHAR(50)   NOT NULL,
    PRIMARY KEY (client_id, file_path, detector, redacted)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_allowlist_dashboard (
    client_id    VARCHAR(200)  NOT NULL,
    file_path    VARCHAR(1000) NOT NULL,
    detector     VARCHAR(200)  NOT NULL,
    redacted     VARCHAR(500)  NOT NULL,
    reason       VARCHAR(1000) NOT NULL DEFAULT '',
    dismissed_by VARCHAR(200)  NOT NULL DEFAULT '',
    dismissed_at VARCHAR(50)   NOT NULL,
    PRIMARY KEY (client_id, file_path, detector, redacted)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_deepscan_codecommit (
    client_id       VARCHAR(200)  NOT NULL,
    repo_key        VARCHAR(500)  NOT NULL,
    platform        VARCHAR(50)   NOT NULL,
    requested_at    VARCHAR(50)   NOT NULL,
    completed_at    VARCHAR(50),
    commits_scanned INTEGER,
    findings        INTEGER,
    failed_at       VARCHAR(50),
    error           VARCHAR(4000),
    PRIMARY KEY (client_id, repo_key, platform)
);

CREATE TABLE IF NOT EXISTS nhi_scanner.secscan_deepscan_github (
    client_id       VARCHAR(200)  NOT NULL,
    repo_key        VARCHAR(500)  NOT NULL,
    platform        VARCHAR(50)   NOT NULL,
    requested_at    VARCHAR(50)   NOT NULL,
    completed_at    VARCHAR(50),
    commits_scanned INTEGER,
    findings        INTEGER,
    failed_at       VARCHAR(50),
    error           VARCHAR(4000),
    PRIMARY KEY (client_id, repo_key, platform)
);
