-- Read-only credential-dashboard deployment check. Run as the ACTUAL Go API
-- database role (not only a pgAdmin superuser). Never run integration fixtures
-- on live nhi_db. Do not select secret/policy/raw-response row contents.
SELECT current_database() AS db_name, current_user AS application_role,
       has_schema_privilege(current_user, 'nhi_scanner', 'USAGE') AS schema_usage,
       has_table_privilege(current_user, 'nhi_scanner.credentials', 'SELECT') AS scanner_credentials_select,
       has_table_privilege(current_user, 'nhi_scanner.identities', 'SELECT') AS identities_select,
       has_table_privilege(current_user, 'nhi_scanner.nhi_scans_aws', 'SELECT') AS scans_select;

-- Aggregate metadata only: inspect real type labels, row coverage and NULL
-- usage/rotation timestamps before defining dashboard #7 hygiene semantics.
SELECT credential_type,
       COUNT(*) AS current_rows,
       COUNT(*) FILTER (WHERE last_used_at IS NULL) AS usage_not_recorded,
       COUNT(*) FILTER (WHERE last_rotated_at IS NULL) AS rotation_not_recorded,
       COUNT(*) FILTER (WHERE expires_at IS NULL) AS expiry_not_recorded,
       COUNT(*) FILTER (WHERE rotation_enabled IS NULL) AS rotation_flag_not_recorded,
       COUNT(*) FILTER (WHERE privilege_level IS NULL) AS privilege_not_scored,
       COUNT(*) FILTER (WHERE trust_policy IS NULL) AS trust_not_recorded,
       COUNT(*) FILTER (WHERE attached_policies IS NULL) AS attached_not_recorded,
       COUNT(*) FILTER (WHERE inline_policies IS NULL) AS inline_not_recorded
FROM nhi_scanner.credentials
WHERE deleted_at IS NULL
GROUP BY credential_type
ORDER BY credential_type;
