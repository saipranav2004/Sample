-- DEVELOPMENT/TEST REFERENCE. Based on the scanner columns supplied by the user.
-- Column types are aligned for API testing; actual constraints/defaults are NOT
-- authoritative production DDL. Do not apply this script to a production DB.
-- The 'identities' and 'nhi_identity_activity_aws' tables are not queried by this API.
CREATE SCHEMA IF NOT EXISTS nhi_scanner;
CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_scans_aws (
  id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  scan_id varchar(200) NOT NULL UNIQUE, account_id varchar(200), target_name varchar(200),
  status varchar(50), scan_end timestamptz,
  total_identities integer DEFAULT 0, total_events integer DEFAULT 0,
  total_secrets integer DEFAULT 0
);
CREATE INDEX IF NOT EXISTS scans_latest_idx ON nhi_scanner.nhi_scans_aws(status, scan_end DESC, id DESC);
CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_identities_aws (
  id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, scan_id varchar(200) NOT NULL,
  arn varchar(1000), name varchar(500), identity_type varchar(200),
  classification varchar(200), trust_type varchar(200), trust_service varchar(500),
  evidence text, matched_rules text, total_events integer, last_active timestamptz,
  owner_name varchar(500), owner_type varchar(200), primary_owner varchar(500),
  created_by_name varchar(500), attached_policies text, is_admin smallint DEFAULT 0,
  owned_credentials text DEFAULT '[]', is_secret smallint DEFAULT 0,
  created_at timestamptz, groups_list varchar(1000),
  password_age_days integer, console_access varchar(100), access_key_1_id varchar(200),
  access_key_2_id varchar(200), mfa_enabled smallint DEFAULT 0,
  password_last_used timestamptz, access_key_1_age_days integer,
  access_key_1_last_used timestamptz, read_events integer, write_events integer,
  distinct_action_count integer, long_lived_key_count integer, keys_observed_total integer,
  first_seen varchar(100), last_seen varchar(100), region_count integer,
  source_ip_count integer, error_count integer, report_json text
);
CREATE INDEX IF NOT EXISTS identities_scan_id_idx ON nhi_scanner.nhi_identities_aws(scan_id, id DESC);
CREATE INDEX IF NOT EXISTS identities_arn_scan_idx ON nhi_scanner.nhi_identities_aws(arn, scan_id);
CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_events_aws (
  id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, scan_id varchar(200) NOT NULL,
  identity_name varchar(500), identity_arn varchar(1000), identity_type varchar(200),
  event_time timestamptz, event_name varchar(500), event_source varchar(500),
  source_ip varchar(200), user_agent varchar(1000), read_only varchar(50),
  region varchar(200)
);
CREATE INDEX IF NOT EXISTS events_scan_arn_time_idx ON nhi_scanner.nhi_events_aws(scan_id, identity_arn, event_time DESC, id DESC);
CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_lineage_aws (
  id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, scan_id varchar(200) NOT NULL,
  source_arn varchar(1000), source_name varchar(500), rel_type varchar(200),
  direction varchar(100), target_type varchar(200), target_id varchar(1000),
  target_name varchar(500), via varchar(1000), source varchar(200), detail text,
  edge_count integer, last_seen varchar(100), is_external smallint DEFAULT 0
);
CREATE INDEX IF NOT EXISTS lineage_scan_arn_idx ON nhi_scanner.nhi_lineage_aws(scan_id, source_arn, target_name);
