> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and current source files. #7 still requires approved hygiene rules.

# Dashboard APIs #1 and #2 — implementation and contract

Both GET routes are registered inside the **existing** central JWT-protected `/api` router and use the approved policy A account resolver: every authenticated dashboard user may read every *known* 12-digit AWS account. The v1 summary is separate from the older `/api/dashboard/summary` legacy endpoint. One `cmd/api-server/main.go` wires the existing `DashboardBreakdownRepository` → service → handler for both routes; **no new main or router**.

## API #2 — real identity counts

`GET /api/v1/dashboard/identities/by-type?account_id=&region=&status=&functional_class=` counts only current (`deleted_at IS NULL`) identities in the confirmed UUID-keyed `nhi_scanner.identities`. Every SQL call enforces server-resolved `AllowedAccountIDs` and uses bound parameters. All four PDF filters are optional; other/duplicate/invalid query parameters return 400. The query groups by `identity_type`, sorts descending by count then type ascending, and returns `{"total":<sum>,"breakdown":[{"identity_type":"...","count":<number>}]}`. An authorized empty result is `{"total":0,"breakdown":[]}` after an actual query.

Rules that need product confirmation: blank/NULL `identity_type` becomes `unknown`; blank/NULL `region` becomes `unknown` (not `global`); blank/NULL `functional_class` becomes `unclassified`; status is compared case-insensitively after trimming, with NULL/blank as `unknown`. The filter accepts syntactically valid lowercase status names, not a fabricated fixed enumeration.

## API #1 — user-selected **partial 200** JSON

`GET /api/v1/dashboard/summary?account_id=&region=` returns a single **partial** PDF response. Never substitute the example figures in the PDF or convert unavailable information into numeric 0. The JSON keys remain present, with JSON `null` for unmeasured fields; the frontend must display these as “Not available.” This is **not a fully PDF-complete summary** until the missing sources are supplied.

| JSON card | Source and provisional rule |
|---|---|
| `total_identities` | Current scoped catalog rows; measured zero possible. |
| `identities_by_status` | Counts of current rows by trimmed lower-case status; NULL/blank → `unknown`. Empty map is `{}`. Only statuses present in current data are keys. |
| `new_identities_last_24h` | Current rows whose `first_seen_at` is between a single UTC `now-24h` and `now` (inclusive). Confirm whether discovery timestamp is the desired product rule. |
| `removed_identities_last_24h` | Rows whose `deleted_at` is in the same UTC 24h window. This measures *soft deletions*, not disappearance in a prior scanner snapshot. Confirm desired definition. |
| `total_accounts_scanned` | If **no `region`**: distinct scoped AWS account IDs with at least one `COMPLETED` scan having a non-NULL `scan_end` in `nhi_scanner.nhi_scans_aws`. 0 is measured if no matching completed scan. If `region` is specified: **null**, because scans cannot be region-filtered. |
| `last_scan_at`, `scan_status` | If **no `region`**: end time and recorded status of the most recently **ended** scoped scan (`scan_end` descending, ID as tie-breaker). May be null when none exist. If `region` specified: both **null** rather than implying region-specific scan freshness. An in-progress scan with NULL `scan_end` is not represented. |
| `total_regions_scanned` | **null**: scan records contain no region; distinct identity regions would not prove scan coverage. See API #5 for identity regions. |
| `scan_duration_seconds` | **null**: scan table has `scan_end`, but no confirmed scan-start timestamp. |
| `total_credentials`, `credentials_by_status`, `new_credentials_last_24h`, `expiring_credentials_30d`, `stale_credentials_90d`, `unrotated_credentials` | **null**: no canonical credentials table exists. Remain null even if an identity has `owned_credentials` legacy text. |

The identity cards respect both account and region filters. Scan-derived cards respect the requested account, but are null instead of incorrectly using account-wide scan facts when a region is supplied. Repository errors on required identity/scan queries return 503/500 per existing error handling; this partial 200 does **not** silently hide a failing measured source. Account scope unavailable → 503 `ACCESS_POLICY_UNAVAILABLE`; unknown requested account → 403; no JWT → 401; invalid/duplicate filters → 400. #6/#7 continue returning 503 pending the credentials source; #4/#5 continue `credential_count:null`; #8 continues `not_in_iac:null`.

## Copying the implementation

Replace the eight endpoint-named files `summary.go` and `identities_by_type.go` directly in **each** flat `internal/{models,repository,services,handlers}/dashboard/` folder. Merge the shared filter-check update in `internal/handlers/dashboard/identities_by_class.go` and the two new protected GET registrations in the **existing** `internal/routes/routes.go`. The existing `cmd/api-server/main.go` only has an updated comment; its repository/service/handler wiring already serves #1/#2. The complete backend ZIP retains configs/migrations/pkg and the existing legacy APIs.

`go test ./...` and `go vet ./...` pass with Go 1.26.5. The optional PostgreSQL integration fixture was updated but **not run** against a database: it CREATES/TRUNCATES scanner fixtures and must only be run in a disposable `*_test` DB. Never run it against `nhi_db` or a shared database.
