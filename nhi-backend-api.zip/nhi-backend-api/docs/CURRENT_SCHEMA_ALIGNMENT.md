# Backend API → current PostgreSQL scanner schema (team update)

**Status:** Code aligned with the complete scanner column inventory supplied by the team on 2026-09-29. Built and integration-tested against a disposable PostgreSQL 17 database with those columns. This is a *schema-aligned API candidate*, not an Oracle data migration or production validation. The inventory gives column names/types, not production constraints, defaults, indexes, real records, or the `nhi_users` table definition.

## Confirmed schema differences and response behavior

| Table / API | Earlier API assumed | Confirmed current schema / action |
|---|---|---|
| `nhi_identities_aws.owned_credentials` | JSONB | TEXT containing JSON. All dashboard, identity and credential JSON operations normalize nonempty valid JSON TEXT to JSONB; NULL, empty string and JSON `null` are treated as `[]`. Malformed JSON or non-array JSON must be cleaned at source. |
| `nhi_scans_aws.scan_start` | `timestamptz` | **Absent.** Latest completed scan is selected by `scan_end DESC NULLS LAST, id DESC`; historical scans use that order. `/api/scans` still includes `scan_start` but reports **null**, not a fabricated value. |
| `nhi_identities_aws.discovered_at` and `nhi_events_aws.discovered_at` | `timestamptz` | **Absent.** `/api/identities`, `/api/secrets`, and `/api/events` return `discovered_at: null` (models are nullable pointers). AWS `created_at` / event `event_time` are not relabelled as discovery timestamps. Frontend should support null. |
| `nhi_events_aws.caller_arn` and `caller_type` | Fields present for role-consumer details | **Absent.** `/api/identities/consumers?arn=…` returns HTTP **501** with `CONSUMERS_UNAVAILABLE`, rather than inventing a caller from a shared IP. When *both columns* are added later and populated by the scanner, the same endpoint automatically uses its existing grouped query. The `consumer_count` on each identity still represents distinct **source IPs**, not verified distinct caller principals. |
| `nhi_users` | Exists under `nhi_scanner` | **Not listed** in supplied scanner inventory. Authentication still needs `nhi_scanner.nhi_users` with bcrypt password hashes. Apply/reconcile `migrations/001_create_users.sql` only if needed; do not use plaintext password seed. |
| `nhi_identity_activity_aws`, `identities` (UUID keys) | Not used | Current API queries neither table. Do **not** conflate the UUID-based `identities` table with integer-keyed `nhi_identities_aws`. |

Flag fields `is_secret`, `is_admin`, `mfa_enabled`, and `is_external` are confirmed `smallint` and remain integer 0/1 in SQL. The listed timestamps used by existing filters are `timestamptz`. Additional supplied scanner columns (e.g. `report_json`, activity metrics and `access_key_2_id`) do not currently appear in API responses; this is not a promise to implement endpoints for them.

## Changed source paths

- `internal/repository/dashboard_repo.go`, `identity_repo.go`, `credential_repo.go`: read valid JSON from TEXT (and remain compatible with JSONB).
- `internal/repository/scan_repo.go`, `dashboard_repo.go`, `identity_repo.go`, `event_repo.go`, `lineage_repo.go`, `credential_repo.go`, `consumer_repo.go`: latest completed scan uses `scan_end` plus `id` tie-breaker; scans no longer select `scan_start`.
- `internal/repository/identity_repo.go`, `event_repo.go`: project NULL for missing `discovered_at`.
- `internal/models/scan.go`, `identity.go`, `event.go`: unavailable timestamps become `*time.Time`, serialized as JSON `null`.
- `internal/repository/consumer_repo.go`, `internal/handlers/identities.go`: check for caller columns and return 501 if unavailable; if later present, preserve grouped consumer behavior.
- `docs/scanner_schema_reference.sql`: **development-only** sample now follows the supplied scanner columns/types; it does not create unused `identities` or `nhi_identity_activity_aws`.
- `internal/repository/postgres_integration_test.go`: verifies current schema, TEXT credentials, latest/explicit scan, pagination, JSON metrics, NULL timestamps, unavailable consumer response at repository level, and auto-enable after caller columns are added in the disposable test DB.

Other auth/services/routes are unchanged. See the initial [`POSTGRES_MIGRATION_REPORT.md`](POSTGRES_MIGRATION_REPORT.md) for the Oracle-to-Postgres conversion history; this document **supersedes its original scanner schema assumptions**.

## Local verification (PowerShell)

Run from the project root with the **new ZIP's files** but retain your local `configs/config.yaml`:

```powershell
go test ./...
go vet ./...
go run ./cmd/api-server
```

In another window use your actual port (8080/8081) and JWT obtained from `/api/auth/login`:

```powershell
Invoke-RestMethod http://localhost:8081/health
$headers = @{ Authorization = "Bearer YOUR_JWT_TOKEN" }
Invoke-RestMethod http://localhost:8081/api/scans -Headers $headers
Invoke-RestMethod http://localhost:8081/api/dashboard/summary -Headers $headers
Invoke-RestMethod http://localhost:8081/api/identities -Headers $headers
Invoke-RestMethod http://localhost:8081/api/credentials -Headers $headers
Invoke-RestMethod 'http://localhost:8081/api/identities/consumers?arn=YOUR_ROLE_ARN' -Headers $headers
```

The last request is expected to return **501** on the current schema. Empty tables produce empty inventory/counts, not sample data. `docs/validate_schema.sql` checks required columns and key types; run only on a database you control. Integration tests **TRUNCATE** tables and temporarily add caller columns: **never** run `TEST_DATABASE_URL` against a real database; test refuses names not ending in `_test` but that is only a safeguard, not an isolation mechanism.

## Remaining blockers before claiming full functional parity

1. Scanner/ETL must be updated to write to PostgreSQL and supply valid JSON arrays. No Oracle data dump, scanner writer, production DDL constraints or row samples were provided.
2. Add real `scan_start`/`discovered_at` columns to the *writer and schema* if those API fields must be populated; do not backfill from unrelated time fields without a documented business rule. Until then clients must accept null.
3. Populate `caller_arn` and `caller_type` from authoritative event data for actual role-consumer details. A mere `ALTER TABLE ADD COLUMN` without updating the writer will make the endpoint return `Unknown` callers; do not treat this as a complete feature.
4. Validate credentials JSON content, user table/auth schema, NULL values in real rows, completed scans with missing `scan_end`, permissions, TLS, migration row counts, and frontend handling of null timestamps/HTTP 501. Existing handlers expose raw DB errors on some 500 responses; sanitize in a security follow-up.
