-- Run with psql -v ON_ERROR_STOP=1 -f docs/validate_schema.sql.
-- Confirm these queries against a disposable/staging DB first. No DDL/data changes.
-- First query: ideally zero rows. 'nhi_users' is required for authentication;
-- its DDL is in migrations/001_create_users.sql if not already provisioned.
WITH required(table_name, column_name) AS (
    VALUES
      ('nhi_users','id'),('nhi_users','email'),('nhi_users','password'),('nhi_users','full_name'),
      ('nhi_users','team'),('nhi_users','role'),('nhi_users','created_at'),
      ('nhi_scans_aws','id'),('nhi_scans_aws','scan_id'),('nhi_scans_aws','status'),
      ('nhi_scans_aws','scan_end'),('nhi_scans_aws','account_id'),('nhi_scans_aws','target_name'),
      ('nhi_scans_aws','total_identities'),('nhi_scans_aws','total_events'),('nhi_scans_aws','total_secrets'),
      ('nhi_identities_aws','id'),('nhi_identities_aws','scan_id'),('nhi_identities_aws','arn'),
      ('nhi_identities_aws','name'),('nhi_identities_aws','identity_type'),
      ('nhi_identities_aws','classification'),('nhi_identities_aws','trust_type'),
      ('nhi_identities_aws','trust_service'),('nhi_identities_aws','evidence'),
      ('nhi_identities_aws','matched_rules'),('nhi_identities_aws','total_events'),
      ('nhi_identities_aws','last_active'),('nhi_identities_aws','owner_name'),
      ('nhi_identities_aws','owner_type'),('nhi_identities_aws','primary_owner'),
      ('nhi_identities_aws','created_by_name'),('nhi_identities_aws','attached_policies'),
      ('nhi_identities_aws','is_admin'),('nhi_identities_aws','is_secret'),
      ('nhi_identities_aws','owned_credentials'),('nhi_identities_aws','created_at'),
      ('nhi_identities_aws','groups_list'),('nhi_identities_aws','mfa_enabled'),
      ('nhi_identities_aws','password_age_days'),('nhi_identities_aws','console_access'),
      ('nhi_identities_aws','password_last_used'),('nhi_identities_aws','access_key_1_id'),
      ('nhi_identities_aws','access_key_1_age_days'),('nhi_identities_aws','access_key_1_last_used'),
      ('nhi_events_aws','id'),('nhi_events_aws','scan_id'),('nhi_events_aws','identity_name'),
      ('nhi_events_aws','identity_arn'),('nhi_events_aws','identity_type'),
      ('nhi_events_aws','event_time'),('nhi_events_aws','event_name'),
      ('nhi_events_aws','event_source'),('nhi_events_aws','source_ip'),
      ('nhi_events_aws','user_agent'),('nhi_events_aws','read_only'),('nhi_events_aws','region'),
      ('nhi_lineage_aws','scan_id'),('nhi_lineage_aws','source_arn'),
      ('nhi_lineage_aws','target_name'),('nhi_lineage_aws','target_type'),
      ('nhi_lineage_aws','rel_type'),('nhi_lineage_aws','direction'),
      ('nhi_lineage_aws','via'),('nhi_lineage_aws','detail'),('nhi_lineage_aws','is_external')
)
SELECT r.table_name, r.column_name AS missing_column
FROM required r LEFT JOIN information_schema.columns c
  ON c.table_schema = 'nhi_scanner' AND c.table_name = r.table_name AND c.column_name = r.column_name
WHERE c.column_name IS NULL ORDER BY r.table_name, r.column_name;

-- Critical types and optional caller fields; caller columns are not currently present.
SELECT table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'nhi_scanner' AND (
  (table_name = 'nhi_identities_aws' AND column_name IN ('owned_credentials','is_secret','is_admin','mfa_enabled','last_active')) OR
  (table_name = 'nhi_events_aws' AND column_name IN ('event_time','caller_arn','caller_type')) OR
  (table_name = 'nhi_lineage_aws' AND column_name = 'is_external') OR
  (table_name = 'nhi_scans_aws' AND column_name IN ('id','scan_end'))
) ORDER BY table_name, column_name;

-- The next statement deliberately errors if TEXT contains malformed JSON.
-- Clean that data at source; successful result should be zero non-array values.
SELECT COUNT(*) AS non_array_credentials
FROM nhi_scanner.nhi_identities_aws
WHERE jsonb_typeof(COALESCE(NULLIF(NULLIF(btrim(owned_credentials::text), ''), 'null')::jsonb, '[]'::jsonb)) <> 'array';
