> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and current source files. #7 still requires approved hygiene rules.

# Dashboard APIs #3–#5 — current identity-count contract

Confirmed source is the UUID-keyed `nhi_scanner.identities` in `nhi_db`, not the older `nhi_scanner.nhi_identities_aws`. **Policy A:** every authenticated dashboard user may view all known AWS accounts. The existing single `cmd/api-server/main.go` injects the all-accounts scope; the existing single `internal/routes/routes.go` mounts the GET endpoints behind JWT. Missing JWT → 401; unknown `account_id` → 403; unavailable scope/source → 503.

| # | GET route | Optional filters | Response |
|---:|---|---|---|
| 3 | `/api/v1/dashboard/identities/by-class` | `account_id`, `region` | `total` plus `breakdown` of `functional_class` and count |
| 4 | `/api/v1/dashboard/identities/by-account` | `region`, `identity_type` | `total_accounts`; breakdown of `account_id`, `identity_count`, **`credential_count:null`** |
| 5 | `/api/v1/dashboard/identities/by-region` | `account_id`, `identity_type` | `total_regions`; breakdown of `region`, `identity_count`, **`credential_count:null`** |

The lead directed that unavailable `account_name` be omitted; it is not an identity name. No canonical credential table exists yet: the user explicitly requested a visible “not available,” so **`credential_count` is JSON null**, not absent or an invented zero. The frontend should render `null` as “Not available.” The scanner's `owned_credentials` has not been proven a complete credential inventory. Real counts can only be added after a validated source is agreed.

Counts use current identities (`deleted_at IS NULL`). Blank/NULL `functional_class` becomes `unclassified`; blank/NULL `region` becomes `unknown`, not AWS `global`. #4/#5 list only nonempty identity groups. Group totals count groups, not identities. Authorization scope is trusted, never filled from untrusted URL input; SQL values are parameterized.

API #8 is also implemented in the same flat `dashboard/` directories: see [its provisional metric analysis](API_8_EXPOSURE_ANALYSIS.md). See [integration status](../INTEGRATION_STATUS.md) for testing and disposable-DB safety.
