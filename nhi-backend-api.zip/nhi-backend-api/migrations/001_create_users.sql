-- Apply after the nhi_scanner schema exists. The application role needs SELECT.
CREATE SCHEMA IF NOT EXISTS nhi_scanner;
CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_users (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email varchar(200) NOT NULL UNIQUE,
    password varchar(500) NOT NULL,
    full_name varchar(200),
    team varchar(100),
    role varchar(50) NOT NULL DEFAULT 'developer',
    created_at timestamptz NOT NULL DEFAULT now()
);
-- UNIQUE(email) already creates an index; avoid duplicate index.
