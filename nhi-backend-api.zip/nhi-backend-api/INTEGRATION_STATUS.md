# Integration status

**Secret scanner (credential exposure) is implemented:** `GET /api/findings`, `GET/POST/DELETE /api/allowlist`, `POST /api/findings/decision` and `GET /api/deep-scan-status` read and write the `nhi_scanner.secscan_*` tables directly, with the same paths and bodies as the scanner's own API, behind this backend's JWT. `POST /api/deep-scan` answers 501 until the scanner team supplies its job contract. See [Secret scanner API](docs/SECRET_SCANNER_API.md). The SQL passed against a local disposable `secscan_test` PostgreSQL 16 built from `docs/secscan_schema_reference.sql`; live `nhi_db` was not used.

## Inventory A1–A9 and Dashboard #1–#8

**A1–A9 are implemented:** nine protected `/api/v1/inventory/identities...` routes with current-only (`deleted_at IS NULL`) account-scoped SQL, validation and sanitized errors. A7 has a strict tracked-activity cutoff; A8 exports all matching current rows (bounded, including user-approved raw JSON); A9 patches only three allowed fields and needs real DB UPDATE privilege. See [A7–A9 specifics and exceptions](docs/A7_A9_INVENTORY_IMPLEMENTATION.md) and [A1–A6 details](docs/A1_A6_INVENTORY_IMPLEMENTATION.md). The extended SQL fixture passed on a *local disposable* `inventory_a1_a9_test` PostgreSQL 17 DB, never on `nhi_db`. Dashboard #1–#8 retain shared exception handling and eight-route regression tests.

**Complete backend tree retained:** one existing `cmd/api-server/main.go` and `internal/routes/routes.go`, legacy handlers, `cmd/`, `configs/`, `migrations/`, and `pkg/`. The dashboard endpoint files live directly in the four flat `internal/{handlers,services,repository,models}/dashboard/` packages. The same central JWT middleware guards all eight dashboard v1 GET routes. Approved policy A: every authenticated dashboard user may view all known AWS accounts; scope is server-resolved, not URL-supplied.

| PDF API | Current status |
|---|---|
| #1 summary | **Partial 200 per user choice**: real scoped identity totals/statuses/new/removals and current scanner credential totals/statuses/new discoveries/known expiring and stale keys. NULL access-key usage keeps the stale card null, not fake zero. Unrotated classification, scanner-region coverage and scan duration remain JSON **null**. With `region`, scan cards are null while credential/identity cards remain filtered. See [credential integration](docs/CREDENTIAL_DASHBOARD_INTEGRATION.md). |
| #2 identities by type | Real grouped identity counts from current `nhi_scanner.identities`; account, region, status, functional_class filters. |
| #3 identities by class | Real grouped identity counts from current `nhi_scanner.identities`. |
| #4/#5 identities by account/region | Real identity counts with real `credential_count` from current `nhi_scanner.credentials`. `identity_type` applies only to identities; identity-driven groups retained. Unavailable `account_name` remains omitted. |
| #6 credential breakdown by type | Live current/scoped `nhi_scanner.credentials` grouped by `credential_type`, filtered by account/region/status. |
| #7 credential hygiene | **HTTP 503 `DATA_SOURCE_UNAVAILABLE`** pending scanner/product definitions of never-used, unrotated, privilege, admin/wildcard and public trust. The existence of 31 columns does not validate these classifications. No fabricated zeros. |
| #8 identity exposure | Identity-backed cards with documented provisional rules; unavailable `not_in_iac` explicitly JSON **null**. |

Unknown requested account → 403; missing JWT → 401; missing/invalid account-policy source → 503; malformed/unsupported query filter → 400. Go 1.26.5 `go test ./...` and `go vet ./...` pass. The **dashboard credential** fixture passed against local disposable `dashboard_credential_test` PostgreSQL 17 and the **inventory** fixture passed separately against `inventory_credential_test`. Live `nhi_db`, app-role privileges and actual production rows were not tested. All fixtures CREATE/TRUNCATE tables; run them only on isolated disposable databases named `*_test` (NEVER `nhi_db`).

See [current credential integration and blockers](docs/CREDENTIAL_DASHBOARD_INTEGRATION.md), [read-only deployment check](docs/CREDENTIALS_READ_ONLY_DEPLOYMENT_CHECK.sql), [historical #1/#2 analysis](docs/API_1_2_SUMMARY_AND_IDENTITY_TYPE.md) and [#8 metric assumptions](docs/API_8_EXPOSURE_ANALYSIS.md). APIs #9–#14 and Credential Inventory B1–B10/C1 remain outside the agreed scope; their empty placeholder files were removed.
