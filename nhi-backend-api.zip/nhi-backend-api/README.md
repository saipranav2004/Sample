# NHI Backend API

Go API for the NHI Discovery console, on PostgreSQL (`nhi_db`, schema `nhi_scanner`).

| Area | Routes | Notes |
|---|---|---|
| Auth | `POST /api/auth/login`, `GET /api/auth/me` | JWT (HS256) |
| Dashboard v1 | `/api/v1/dashboard/*` #1-#8 | [status](INTEGRATION_STATUS.md) |
| Inventory v1 | `/api/v1/inventory/identities*` A1-A9 | [A1-A6](docs/A1_A6_INVENTORY_IMPLEMENTATION.md), [A7-A9](docs/A7_A9_INVENTORY_IMPLEMENTATION.md) |
| Secret scanner | `/api/findings`, `/api/allowlist`, `/api/findings/decision`, `/api/deep-scan-status`, `/api/deep-scan` | [Secret scanner API](docs/SECRET_SCANNER_API.md) |
| Legacy | `/api/identities`, `/api/identities/lineage`, `/api/identities/consumers`, `/api/secrets`, `/api/credentials`, `/api/scans`, `/api/events`, `/api/dashboard/*` | unchanged |

See [project structure](PROJECT_STRUCTURE.md).

---

> **Inventory A1–A9 and Dashboard #1–#8:** See [A7–A9 behavior and exceptions](docs/A7_A9_INVENTORY_IMPLEMENTATION.md), [A1–A6 implementation](docs/A1_A6_INVENTORY_IMPLEMENTATION.md) and [integration status](INTEGRATION_STATUS.md). Nine inventory routes live in the four flat `internal/{handlers,services,repository,models}/inventory/` folders; the flat dashboard folders remain. The **single existing main/router** require JWT. Inventory shows only current (`deleted_at IS NULL`) identities. A8 bulk export includes approved raw scanner JSON; A9 PATCH requires actual DB UPDATE privilege. Dashboard #1 now measures available `nhi_scanner.credentials` cards while leaving unverified cards null; #4/#5 include real `credential_count`; #6 is live; #7 remains 503 pending scanner hygiene rules; #8 includes `not_in_iac:null`. See [credential integration and blockers](docs/CREDENTIAL_DASHBOARD_INTEGRATION.md). Legacy routes and top-level folders remain.

# NHI Backend API — PostgreSQL migration candidate

This is a conversion of the attached Oracle-backed Go API to PostgreSQL. See
[the current schema alignment](docs/CURRENT_SCHEMA_ALIGNMENT.md) and [the historical migration report](docs/POSTGRES_MIGRATION_REPORT.md) before deploying. **Scanner column names/types were supplied, but production constraints/defaults, Oracle data, scanner writer, and data migration remain outstanding.**

## Local setup (disposable PostgreSQL only)

1. Create a PostgreSQL database named `nhi_test` and apply
   `docs/scanner_schema_reference.sql` (DEVELOPMENT/TEST schema based on supplied column names/types), then
   `migrations/001_create_users.sql`. Do not apply the reference schema to
   production without matching it to the actual Oracle DDL and scanner writer.
2. Configure `configs/config.yaml` (host, port, name, user, SSL mode). Set `DB_PASSWORD` and `JWT_SECRET` securely in your
   environment; never commit passwords. TLS is required by default (set
   `DB_SSLMODE=disable` only for a local non-TLS database).
3. With Go 1.26.5: `go mod download && go test ./... && go run ./cmd/api-server`.
4. Integration tests **TRUNCATE test tables**: apply the development schema and
   then run `TEST_DATABASE_URL='postgres://user:password@localhost:5432/nhi_test?sslmode=disable' go test ./internal/repository -count=1 -v`.
   The test refuses any database whose name does not end in `_test`.
5. Provision a user with a securely generated bcrypt password hash. The old
   `admin123` Oracle seed is intentionally disabled (it never worked with
   bcrypt login). `002_create_sessions.sql` remains an explicitly empty slot.

Config loads from `configs/config.yaml` relative to the working directory;
`DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_SSLMODE`, and
`JWT_SECRET` override file settings. Tables are schema-qualified as
`nhi_scanner.*`; give the application role USAGE on the schema and SELECT on
scanner tables/users. The scanner service must independently write PostgreSQL.

### Existing scanner tables with TEXT credentials

The API accepts `owned_credentials` as PostgreSQL JSONB **or valid JSON stored in TEXT**; NULL, empty TEXT and JSON null are treated as an empty array. JSON objects or invalid JSON still need cleanup. The reference schema uses TEXT, matching the supplied scanner table definition. Confirm your column's actual type with `information_schema.columns` before making any production DDL changes.

### Current schema limitations

Latest completed scans use `scan_end` then `id` (no `scan_start` column). Responses keep `scan_start` and `discovered_at` keys but set them to JSON null because the columns do not exist. The role-consumer endpoint returns HTTP 501 until event `caller_arn` **and** `caller_type` are added and populated by the scanner. See `docs/CURRENT_SCHEMA_ALIGNMENT.md`.
