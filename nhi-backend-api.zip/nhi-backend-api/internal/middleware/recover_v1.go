package middleware

import (
	"log"
	"net/http"
)

type v1Writer struct {
	http.ResponseWriter
	started bool
}

func (w *v1Writer) WriteHeader(code int) { w.started = true; w.ResponseWriter.WriteHeader(code) }
func (w *v1Writer) Write(data []byte) (int, error) {
	w.started = true
	return w.ResponseWriter.Write(data)
}

// RecoverV1 confines panic recovery to newly implemented v1 GET endpoints;
// existing legacy API response contracts are left untouched. Never print the
// recovered value: it might contain raw scanner or database information.
func RecoverV1(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tracked := &v1Writer{ResponseWriter: w}
		defer func() {
			if recovered := recover(); recovered != nil {
				log.Printf("v1 API panic recovered: %T", recovered)
				if tracked.started {
					return
				} // cannot replace an already committed response
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("Cache-Control", "no-store")
				w.WriteHeader(http.StatusInternalServerError)
				_, _ = w.Write([]byte(`{"error":{"code":"INTERNAL_ERROR","message":"Unable to load API data"}}` + "\n"))
			}
		}()
		next(tracked, r)
	}
}
