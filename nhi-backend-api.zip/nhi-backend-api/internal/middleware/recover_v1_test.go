package middleware

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRecoverV1SanitizesPanic(t *testing.T) {
	h := RecoverV1(func(http.ResponseWriter, *http.Request) { panic("scanner secret must not leak") })
	w := httptest.NewRecorder()
	h(w, httptest.NewRequest("GET", "/api/v1/inventory/identities", nil))
	if w.Code != 500 || !strings.Contains(w.Body.String(), `"INTERNAL_ERROR"`) || strings.Contains(w.Body.String(), "scanner secret") {
		t.Fatalf("panic response: %d %s", w.Code, w.Body.String())
	}
}
func TestRecoverV1CannotRewriteCommittedResponse(t *testing.T) {
	h := RecoverV1(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(200); panic("secret") })
	w := httptest.NewRecorder()
	h(w, httptest.NewRequest("GET", "/api/v1/inventory/identities", nil))
	if w.Code != 200 || w.Body.Len() != 0 {
		t.Fatalf("committed response must not be overwritten: %d %s", w.Code, w.Body.String())
	}
}
