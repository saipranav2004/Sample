package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/mux"
	"github.com/lib/pq"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/inventory"
	repo "nhi-backend-api/internal/repository/inventory"
	svc "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
)

type AccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}
type Handler struct {
	service *svc.Service
	scope   AccountScope
}

func NewHandler(service *svc.Service, scope AccountScope) *Handler {
	return &Handler{service: service, scope: scope}
}

var accountID = regexp.MustCompile(`^[0-9]{12}$`)
var uuid = regexp.MustCompile(`(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$`)
var token = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,100}$`)
var region = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
var sorts = map[string]bool{"id": true, "name": true, "identity_type": true, "functional_class": true, "account_id": true, "region": true, "status": true, "created_at_aws": true, "last_seen_at": true, "last_activity_at": true}

type apiError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, status int, code, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	var body apiError
	body.Error.Code, body.Error.Message = code, msg
	b, _ := json.Marshal(body)
	w.WriteHeader(status)
	_, _ = w.Write(append(b, '\n'))
}
func writeOK(w http.ResponseWriter, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("inventory: encode response: %v", err)
		writeError(w, 500, "INTERNAL_ERROR", "Unable to encode inventory response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(200)
	_, _ = w.Write(append(b, '\n'))
}
func writeServiceError(w http.ResponseWriter, err error) {
	if errors.Is(err, svc.ErrNotFound) || errors.Is(err, repo.ErrNotFound) {
		writeError(w, 404, "NOT_FOUND", "Identity not found")
		return
	}
	if errors.Is(err, context.Canceled) {
		return
	}
	if errors.Is(err, context.DeadlineExceeded) {
		writeError(w, 504, "TIMEOUT", "Inventory request timed out")
		return
	}
	if errors.Is(err, m.ErrExportTooLarge) {
		writeError(w, http.StatusRequestEntityTooLarge, "EXPORT_TOO_LARGE", "Use narrower filters for this export")
		return
	}
	if errors.Is(err, svc.ErrSourceUnavailable) || errors.Is(err, svc.ErrIncomplete) || errors.Is(err, repo.ErrEmptyScope) {
		writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
		return
	}
	var pg *pq.Error
	if errors.As(err, &pg) {
		c := string(pg.Code)
		if c == "42P01" || c == "42703" || c == "42501" || strings.HasPrefix(c, "08") || c == "53300" || c == "57P01" {
			log.Printf("inventory source unavailable sqlstate=%s", c)
			writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
			return
		}
	}
	// The wrapped DB error might contain user filters or scanner values; log only
	// its type/SQLSTATE, never its raw message or SQL text.
	if errors.As(err, &pg) {
		log.Printf("inventory internal database error sqlstate=%s", pg.Code)
	} else {
		log.Printf("inventory internal error type=%T", err)
	}
	writeError(w, 500, "INTERNAL_ERROR", "Unable to load inventory data")
}
func (h *Handler) authorize(w http.ResponseWriter, r *http.Request, requested string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, 401, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if h == nil || h.service == nil || h.scope == nil {
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := h.scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		log.Printf("inventory account scope unavailable: %T", err)
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		writeError(w, 403, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	found := requested == ""
	for _, id := range ids {
		if !accountID.MatchString(id) {
			writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
		if id == requested {
			found = true
		}
	}
	if !found {
		writeError(w, 403, "FORBIDDEN", "AWS account is not authorized")
		return nil, false
	}
	return ids, true
}
func params(r *http.Request, allowed ...string) (map[string]string, bool) {
	q, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allow := map[string]bool{}
	for _, key := range allowed {
		allow[key] = true
	}
	out := map[string]string{}
	for key, values := range q {
		if !allow[key] || len(values) != 1 || values[0] == "" || len(values[0]) > 256 {
			return nil, false
		}
		out[key] = values[0]
	}
	if a := out["account_id"]; a != "" && !accountID.MatchString(a) {
		return nil, false
	}
	if z := out["region"]; z != "" && !region.MatchString(z) {
		return nil, false
	}
	for _, key := range []string{"identity_type", "functional_class", "status"} {
		if v := out[key]; v != "" && !token.MatchString(v) {
			return nil, false
		}
	}
	for _, val := range out {
		if strings.ContainsAny(val, "\x00\r\n") {
			return nil, false
		}
	}
	return out, true
}
func pathID(r *http.Request) (string, bool) { v := mux.Vars(r)["id"]; return v, uuid.MatchString(v) }
func parseBound(v string, def, max int64) (int64, bool) {
	if v == "" {
		return def, true
	}
	n, err := strconv.ParseInt(v, 10, 64)
	return n, err == nil && n >= 1 && n <= max
}

// parseListFilter is shared by A1 and A8; export accepts page/limit syntax
// but ignores the page selection because it downloads ALL matching rows.
func parseListFilter(p map[string]string) (m.ListFilter, bool) {
	page, ok1 := parseBound(p["page"], 1, 1_000_000)
	limit, ok2 := parseBound(p["limit"], 50, 200)
	if !ok1 || !ok2 {
		return m.ListFilter{}, false
	}
	sortBy := p["sort_by"]
	if sortBy == "" {
		sortBy = "last_seen_at"
	}
	sortOrder := strings.ToLower(p["sort_order"])
	if sortOrder == "" {
		sortOrder = "desc"
	}
	if !sorts[sortBy] || (sortOrder != "asc" && sortOrder != "desc") {
		return m.ListFilter{}, false
	}
	f := m.ListFilter{Page: page, Limit: limit, SortBy: sortBy, SortOrder: sortOrder, Search: p["search"], IdentityType: p["identity_type"], FunctionalClass: p["functional_class"], AccountID: p["account_id"], Region: p["region"], Status: p["status"], Owner: p["owner"], Environment: p["environment"]}
	if b := p["is_public"]; b != "" {
		if b != "true" && b != "false" {
			return m.ListFilter{}, false
		}
		v := b == "true"
		f.IsPublic = &v
	}
	if t := p["last_active_before"]; t != "" {
		v, e := time.Parse(time.RFC3339Nano, t)
		if e != nil {
			return m.ListFilter{}, false
		}
		v = v.UTC()
		f.LastActiveBefore = &v
	}
	return f, true
}

// A1: paged inventory list, exact PDF filters. No deleted row is ever shown.
func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "page", "limit", "sort_by", "sort_order", "search", "identity_type", "functional_class", "account_id", "region", "status", "owner", "environment", "is_public", "last_active_before")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid identity filters")
		return
	}
	f, ok := parseListFilter(p)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid identity filters")
		return
	}
	ids, ok := h.authorize(w, r, f.AccountID)
	if !ok {
		return
	}
	f.AllowedAccountIDs = ids
	out, err := h.service.List(r.Context(), f)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
