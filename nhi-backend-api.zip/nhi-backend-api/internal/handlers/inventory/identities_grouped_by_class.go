package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

func (h *Handler) Grouped(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "account_id", "region", "limit_per_class")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid grouped filters")
		return
	}
	limit, ok := parseBound(p["limit_per_class"], 10, 100)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid limit_per_class")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Grouped(r.Context(), m.GroupFilter{Scope: m.Scope{AllowedAccountIDs: ids}, AccountID: p["account_id"], Region: p["region"], LimitPerClass: limit})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
