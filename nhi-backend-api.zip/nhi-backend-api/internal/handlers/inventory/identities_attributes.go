package inventory

import "net/http"

func (h *Handler) Attributes(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected attributes filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Attributes(r.Context(), id, ids)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
