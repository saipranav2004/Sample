package inventory

import (
	"bytes"
	"encoding/json"
	"io"
	"mime"
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
	"regexp"
	"strings"
	"unicode/utf8"
)

const maxPatchBody = 8192

var patchClass = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,99}$`)

func readIdentityPatch(r *http.Request) (m.UpdatePatch, bool, int) {
	var out m.UpdatePatch
	media, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || media != "application/json" {
		return out, false, 415
	}
	data, err := io.ReadAll(io.LimitReader(r.Body, maxPatchBody+1))
	if err != nil {
		return out, false, 400
	}
	if len(data) > maxPatchBody {
		return out, false, 413
	}
	if !utf8.Valid(data) {
		return out, false, 400
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	start, err := decoder.Token()
	if err != nil || start != json.Delim('{') {
		return out, false, 400
	}
	seen := map[string]bool{}
	for decoder.More() {
		k, err := decoder.Token()
		if err != nil {
			return out, false, 400
		}
		key, ok := k.(string)
		if !ok || seen[key] || (key != "functional_class" && key != "owner" && key != "environment") {
			return out, false, 400
		}
		seen[key] = true
		var raw json.RawMessage
		if decoder.Decode(&raw) != nil || len(raw) == 0 || raw[0] != '"' {
			return out, false, 400
		}
		var value string
		if json.Unmarshal(raw, &value) != nil {
			return out, false, 400
		}
		value = strings.TrimSpace(value)
		if value == "" || len(value) > 256 || strings.ContainsAny(value, "\x00\r\n") || key == "functional_class" && !patchClass.MatchString(value) {
			return out, false, 400
		}
		switch key {
		case "functional_class":
			out.FunctionalClass = &value
		case "owner":
			out.Owner = &value
		case "environment":
			out.Environment = &value
		}
	}
	end, err := decoder.Token()
	if err != nil || end != json.Delim('}') || len(seen) == 0 {
		return out, false, 400
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		return out, false, 400
	}
	return out, true, 0
}

// A9: direct, scoped UPDATE of only the PDF-approved identity metadata.
// Account policy A explicitly includes writes per the user's approval.
func (h *Handler) Update(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected update filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	patch, ok, status := readIdentityPatch(r)
	if !ok {
		if status == 415 {
			writeError(w, status, "UNSUPPORTED_MEDIA_TYPE", "Content-Type must be application/json")
			return
		}
		if status == 413 {
			writeError(w, status, "BODY_TOO_LARGE", "Identity update body is too large")
			return
		}
		writeError(w, 400, "INVALID_BODY", "Update must contain nonempty approved string fields only")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Update(r.Context(), id, ids, patch)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
