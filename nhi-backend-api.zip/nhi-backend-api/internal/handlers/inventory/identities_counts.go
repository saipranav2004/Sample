package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

func (h *Handler) Counts(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "account_id", "region", "functional_class")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid counts filters")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Counts(r.Context(), m.CountsFilter{Scope: m.Scope{AllowedAccountIDs: ids}, AccountID: p["account_id"], Region: p["region"], FunctionalClass: p["functional_class"]})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
