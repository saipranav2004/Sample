package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

// A7: days is required, strictly positive and bounded. NULL last activity is
// untracked (not dormant); the repository enforces current-only identity rows.
func (h *Handler) Dormant(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "days", "identity_type", "account_id", "page", "limit")
	if !ok || p["days"] == "" {
		writeError(w, 400, "INVALID_FILTER", "days is required")
		return
	}
	days, ok1 := parseBound(p["days"], 0, 3650)
	page, ok2 := parseBound(p["page"], 1, 1_000_000)
	limit, ok3 := parseBound(p["limit"], 50, 200)
	if !ok1 || !ok2 || !ok3 {
		writeError(w, 400, "INVALID_FILTER", "Invalid dormant pagination or days")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Dormant(r.Context(), m.DormantFilter{Scope: m.Scope{AllowedAccountIDs: ids}, Days: days, IdentityType: p["identity_type"], AccountID: p["account_id"], Page: page, Limit: limit})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
