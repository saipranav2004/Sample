package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

// A8: export all matching current identities within safe resource limits.
// Format is explicit; A1 page/limit are parsed/validated but do not select
// just one page. Body is built before headers so failures never return a file.
func (h *Handler) Export(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "format", "page", "limit", "sort_by", "sort_order", "search", "identity_type", "functional_class", "account_id", "region", "status", "owner", "environment", "is_public", "last_active_before")
	if !ok || p["format"] != "csv" && p["format"] != "json" {
		writeError(w, 400, "INVALID_FILTER", "format must be csv or json")
		return
	}
	f, ok := parseListFilter(p)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid export filters")
		return
	}
	ids, ok := h.authorize(w, r, f.AccountID)
	if !ok {
		return
	}
	f.AllowedAccountIDs = ids
	out, err := h.service.Export(r.Context(), m.ExportFilter{ListFilter: f, Format: p["format"]})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	w.Header().Set("Content-Type", out.ContentType)
	w.Header().Set("Content-Disposition", `attachment; filename="`+out.Filename+`"`)
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(out.Body)
}
