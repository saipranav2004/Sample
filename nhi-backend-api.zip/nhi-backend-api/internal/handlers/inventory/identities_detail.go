package inventory

import "net/http"

// A2: absent, deleted and out-of-scope identities are indistinguishable 404s.
func (h *Handler) Detail(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected detail filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Detail(r.Context(), id, ids)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
