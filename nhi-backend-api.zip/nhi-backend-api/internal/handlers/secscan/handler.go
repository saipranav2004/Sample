// Package secscan serves the secret-scanner (credential exposure) API.
//
// Routes and response bodies match the scanner's own HTTP API
// (API_Integration_Guide_Updated_3), so the frontend reads them unchanged:
//
//	GET    /api/findings              {"count","findings"}
//	GET    /api/allowlist             {"entries"}
//	POST   /api/allowlist             {"ok","entry"}
//	DELETE /api/allowlist             {"ok"}
//	POST   /api/findings/decision     {"ok"}
//	GET    /api/deep-scan-status      deep-scan record or {"status":"not_started"}
//	POST   /api/deep-scan             501 - see DeepScan
//
// Differences from the scanner API: requests are authenticated with this
// backend's JWT instead of X-Dashboard-Key, changes need a reviewer role, and
// errors use this backend's v1 envelope {"error":{"code","message"}}.
package secscan

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log"
	"mime"
	"net/http"
	"net/url"
	"time"

	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/secscan"
	svc "nhi-backend-api/internal/services/secscan"
)

// Bodies are four short fields; anything bigger is a mistake or an attack.
const maxBodyBytes = 16 << 10

// Every request gets a budget below the server's 15s write timeout, so a
// slow database produces a clean 504 rather than a dropped connection.
const requestBudget = 12 * time.Second

type Handler struct{ service *svc.Service }

func NewHandler(service *svc.Service) *Handler { return &Handler{service: service} }

type errorBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	var body errorBody
	body.Error.Code, body.Error.Message = code, message
	data, _ := json.Marshal(body) // strings only; cannot fail
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_, _ = w.Write(append(data, '\n'))
}

// writeJSON encodes before committing the status, so a marshal failure can
// never produce a half-written 200.
func writeJSON(w http.ResponseWriter, status int, v interface{}) {
	data, err := json.Marshal(v)
	if err != nil {
		log.Printf("secscan response encoding failed: %T", err)
		writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to encode the response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_, _ = w.Write(append(data, '\n'))
}

// ready checks authentication and wiring before any work. The route is
// mounted behind the JWT middleware; the check stays here so a mis-mounted
// route still refuses anonymous callers.
func (h *Handler) ready(w http.ResponseWriter, r *http.Request) (role, email string, ok bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return "", "", false
	}
	if h == nil || h.service == nil {
		writeError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Secret scanner data is not available")
		return "", "", false
	}
	return claims.Role, claims.Email, true
}

// query reads the allowed query parameters. Unknown or repeated parameters
// are rejected rather than ignored, so a typo never silently widens a filter.
func query(r *http.Request, allowed ...string) (map[string]string, bool) {
	values, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	set := make(map[string]bool, len(allowed))
	for _, k := range allowed {
		set[k] = true
	}
	out := make(map[string]string, len(values))
	for k, v := range values {
		if !set[k] || len(v) != 1 {
			return nil, false
		}
		out[k] = v[0]
	}
	return out, true
}

// decode reads a JSON body strictly: JSON content type, bounded size, no
// unknown fields, exactly one value.
func decode(w http.ResponseWriter, r *http.Request, dst interface{}) bool {
	mediaType, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/json" {
		writeError(w, http.StatusUnsupportedMediaType, "UNSUPPORTED_MEDIA_TYPE", "Send the body as application/json")
		return false
	}
	body := http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		var tooBig *http.MaxBytesError
		if errors.As(err, &tooBig) {
			writeError(w, http.StatusRequestEntityTooLarge, "BODY_TOO_LARGE", "The request body is too large")
			return false
		}
		writeError(w, http.StatusBadRequest, "INVALID_BODY", "The request body is not valid JSON for this endpoint")
		return false
	}
	if err := dec.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		writeError(w, http.StatusBadRequest, "INVALID_BODY", "The request body must contain one JSON object")
		return false
	}
	return true
}

// fail maps a service error to a status. Messages are fixed strings: no
// SQL, table names, finding IDs or secret fragments reach the response or log.
func fail(w http.ResponseWriter, err error) {
	var verr *svc.ValidationError
	switch {
	case errors.Is(err, context.Canceled):
		return // the client went away; there is nobody to answer
	case errors.Is(err, context.DeadlineExceeded):
		writeError(w, http.StatusGatewayTimeout, "TIMEOUT", "The request timed out")
	case errors.As(err, &verr):
		writeError(w, http.StatusBadRequest, "INVALID_REQUEST", verr.Message)
	case errors.Is(err, svc.ErrForbidden):
		writeError(w, http.StatusForbidden, "FORBIDDEN", "Your role cannot change secret findings")
	case errors.Is(err, m.ErrNotFound):
		writeError(w, http.StatusNotFound, "NOT_FOUND", "No matching finding")
	case errors.Is(err, m.ErrSourceUnavailable):
		log.Printf("secscan data source unavailable: %v", err)
		writeError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Secret scanner data is not available")
	default:
		log.Printf("secscan internal error: %T", err)
		writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to process the request")
	}
}

func budget(r *http.Request) (context.Context, context.CancelFunc) {
	return context.WithTimeout(r.Context(), requestBudget)
}
