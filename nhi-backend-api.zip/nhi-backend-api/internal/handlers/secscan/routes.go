package secscan

import (
	"net/http"

	m "nhi-backend-api/internal/models/secscan"
)

// Findings handles GET /api/findings[?client_id=&platform=].
// Every finding not marked safe, newest first.
func (h *Handler) Findings(w http.ResponseWriter, r *http.Request) {
	if _, _, ok := h.ready(w, r); !ok {
		return
	}
	q, ok := query(r, "client_id", "platform")
	if !ok {
		writeError(w, http.StatusBadRequest, "INVALID_FILTER", "Unknown or repeated query parameter")
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.Findings(ctx, m.FindingsFilter{ClientID: q["client_id"], Platform: q["platform"]})
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// Allowlist handles GET /api/allowlist[?client_id=].
func (h *Handler) Allowlist(w http.ResponseWriter, r *http.Request) {
	if _, _, ok := h.ready(w, r); !ok {
		return
	}
	q, ok := query(r, "client_id")
	if !ok {
		writeError(w, http.StatusBadRequest, "INVALID_FILTER", "Unknown or repeated query parameter")
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.Allowlist(ctx, q["client_id"])
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// Dismiss handles POST /api/allowlist: mark a finding safe.
func (h *Handler) Dismiss(w http.ResponseWriter, r *http.Request) {
	role, email, ok := h.ready(w, r)
	if !ok {
		return
	}
	var req m.AllowlistRequest
	if !decode(w, r, &req) {
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.Dismiss(ctx, role, email, req)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// Restore handles DELETE /api/allowlist: undo a "mark as safe".
func (h *Handler) Restore(w http.ResponseWriter, r *http.Request) {
	role, _, ok := h.ready(w, r)
	if !ok {
		return
	}
	var req m.AllowlistRequest
	if !decode(w, r, &req) {
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.Restore(ctx, role, req)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// Decision handles POST /api/findings/decision: a human's verdict.
func (h *Handler) Decision(w http.ResponseWriter, r *http.Request) {
	role, email, ok := h.ready(w, r)
	if !ok {
		return
	}
	var req m.DecisionRequest
	if !decode(w, r, &req) {
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.Decide(ctx, role, email, req)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// DeepScanStatus handles GET /api/deep-scan-status?client_id=&repository=.
func (h *Handler) DeepScanStatus(w http.ResponseWriter, r *http.Request) {
	role, _, ok := h.ready(w, r)
	if !ok {
		return
	}
	q, ok := query(r, "client_id", "repository")
	if !ok {
		writeError(w, http.StatusBadRequest, "INVALID_FILTER", "Unknown or repeated query parameter")
		return
	}
	ctx, cancel := budget(r)
	defer cancel()
	out, err := h.service.DeepScanStatus(ctx, role, q["client_id"], q["repository"])
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// DeepScan handles POST /api/deep-scan.
//
// Starting a deep scan means handing a job to the scanner's worker queue,
// and the scanner service owns that queue's job format. Writing a guessed job
// into secscan_jobs_* could leave the scan marked "running" forever, so this
// endpoint refuses with 501 until the job contract is supplied by the scanner
// team. Status (GET /api/deep-scan-status) is fully served from the database.
func (h *Handler) DeepScan(w http.ResponseWriter, r *http.Request) {
	if _, _, ok := h.ready(w, r); !ok {
		return
	}
	writeError(w, http.StatusNotImplemented, "DEEP_SCAN_UNAVAILABLE",
		"Starting a deep scan is not available from this API yet")
}
