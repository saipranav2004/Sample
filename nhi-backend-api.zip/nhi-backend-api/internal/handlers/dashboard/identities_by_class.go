package dashboard

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/lib/pq"
	"log"
	"net/http"
	"net/url"
	"nhi-backend-api/internal/middleware"
	identitymodels "nhi-backend-api/internal/models/dashboard"
	identityservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
	"regexp"
)

// DashboardAccountScope must resolve permitted AWS account IDs from a trusted
// server-side policy. The existing JWT does NOT contain an account allowlist.
// Do not supply a default "all accounts" implementation without authorization.
type DashboardAccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}

type DashboardBreakdownHandler struct {
	service *identityservices.DashboardBreakdownService
	scope   DashboardAccountScope
}

func NewDashboard345Handler(service *identityservices.DashboardBreakdownService, scope DashboardAccountScope) *DashboardBreakdownHandler {
	return &DashboardBreakdownHandler{service: service, scope: scope}
}

// DashboardAccountIDReader is the trusted server-side list of AWS accounts.
// Do not populate it from a request parameter or from an unverified JWT claim.
type DashboardAccountIDReader interface {
	AllKnownAccountIDs(context.Context) ([]string, error)
}

// DashboardAllAccountsScope implements the explicitly approved policy A:
// every authenticated dashboard user may read all known AWS accounts.
// Revisit this policy before introducing per-user or per-team restrictions.
type DashboardAllAccountsScope struct{ reader DashboardAccountIDReader }

func NewDashboardAllAccountsScope(reader DashboardAccountIDReader) *DashboardAllAccountsScope {
	return &DashboardAllAccountsScope{reader: reader}
}

func (s *DashboardAllAccountsScope) AllowedAccountIDs(ctx context.Context, claims *appjwt.CustomClaims) ([]string, error) {
	if s == nil || s.reader == nil || claims == nil || claims.UserID <= 0 {
		return nil, errors.New("authenticated dashboard account scope unavailable")
	}
	return s.reader.AllKnownAccountIDs(ctx)
}

var (
	accountIDPattern        = regexp.MustCompile(`^[0-9]{12}$`)
	regionPattern           = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
	identityTypePattern     = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
	credentialStatusPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,63}$`)
	functionalClassPattern  = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
)

type dashboardError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func dashboardWriteError(w http.ResponseWriter, status int, code, message string) {
	var payload dashboardError
	payload.Error.Code, payload.Error.Message = code, message
	data, _ := json.Marshal(payload) // this static string-only struct cannot fail
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_, _ = w.Write(append(data, '\n'))
}

// Encode before committing HTTP 200. A malformed service result must not
// produce a partial successful response or silently swallow marshal errors.
func dashboardWriteOK(w http.ResponseWriter, result interface{}) {
	data, err := json.Marshal(result)
	if err != nil {
		log.Printf("dashboard response serialization failed: %T", err)
		dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to encode dashboard response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(append(data, '\n'))
}

func dashboardParams(r *http.Request, allowed ...string) (map[string]string, bool) {
	params, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allowedSet := make(map[string]bool, len(allowed))
	for _, key := range allowed {
		allowedSet[key] = true
	}
	result := make(map[string]string, len(params))
	for key, vals := range params {
		if !allowedSet[key] || len(vals) != 1 {
			return nil, false
		}
		result[key] = vals[0]
	}
	if s := result["account_id"]; s != "" && !accountIDPattern.MatchString(s) {
		return nil, false
	}
	if s := result["region"]; s != "" && !regionPattern.MatchString(s) {
		return nil, false
	}
	if s := result["identity_type"]; s != "" && !identityTypePattern.MatchString(s) {
		return nil, false
	}
	if s := result["status"]; s != "" && !credentialStatusPattern.MatchString(s) {
		return nil, false
	}
	if s := result["functional_class"]; s != "" && !functionalClassPattern.MatchString(s) {
		return nil, false
	}
	return result, true
}

// dashboardAuthorizedAccounts returns an explicit server-side account scope.
// No URL-supplied account ID can expand it. These checks remain even if the
// integrator temporarily mis-mounts the route outside the JWT middleware.
func (h *DashboardBreakdownHandler) dashboardAuthorizedAccounts(w http.ResponseWriter, r *http.Request, requestedAccount string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, requestedAccount)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, requestedAccount)
}

// Shared policy check for identity and credential dashboard endpoints.
// A configured service is required before any query; no caller can replace
// the server-resolved scope with an account_id taken from the query string.
func dashboardAuthorizedAccountsFor(w http.ResponseWriter, r *http.Request, scope DashboardAccountScope, serviceConfigured bool, requestedAccount string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		dashboardWriteError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if scope == nil || !serviceConfigured {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	// An invalid policy result is an integration error, never an expanded scope.
	for _, id := range ids {
		if !accountIDPattern.MatchString(id) {
			dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
	}
	if requestedAccount != "" {
		found := false
		for _, id := range ids {
			if id == requestedAccount {
				found = true
				break
			}
		}
		if !found {
			dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "AWS account is not authorized")
			return nil, false
		}
	}
	return ids, true
}

func dashboardServiceError(w http.ResponseWriter, err error) {
	if errors.Is(err, context.Canceled) {
		return
	} // client disconnected; do not write again
	if errors.Is(err, context.DeadlineExceeded) {
		dashboardWriteError(w, http.StatusGatewayTimeout, "TIMEOUT", "Dashboard request timed out")
		return
	}
	if errors.Is(err, identityservices.ErrDashboardSourceUnavailable) || errors.Is(err, identityservices.ErrDashboardSourceIncomplete) {
		dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
		return
	}
	var pg *pq.Error
	if errors.As(err, &pg) {
		state := string(pg.Code)
		if state == "42P01" || state == "42703" || state == "42501" || state == "53300" || state == "57P01" || len(state) >= 2 && state[:2] == "08" {
			log.Printf("dashboard data source unavailable sqlstate=%s", state)
			dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
			return
		}
		log.Printf("dashboard database error sqlstate=%s", state)
	} else {
		log.Printf("dashboard internal error: %T", err)
	}
	dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load dashboard data")
}

// ByClass implements GET /api/v1/dashboard/identities/by-class.
func (h *DashboardBreakdownHandler) ByClass(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-class filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.ByClass(r.Context(), identitymodels.ClassFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
