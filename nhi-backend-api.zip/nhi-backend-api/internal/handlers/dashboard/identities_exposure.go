package dashboard

import (
	"net/http"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// Exposure implements GET /api/v1/dashboard/identities/exposure.
// This reuses the existing JWT account-scope policy approved for APIs 3–5.
func (h *DashboardBreakdownHandler) Exposure(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid exposure filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.Exposure(r.Context(), identitymodels.ExposureFilter{
		AccountID: params["account_id"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
