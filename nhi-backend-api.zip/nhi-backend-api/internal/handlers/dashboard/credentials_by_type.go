package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
)

// DashboardCredentialHandler handles PDF APIs #6/#7, independent from the
// legacy /api/credentials route. It shares policy A's trusted account scope.
type DashboardCredentialHandler struct {
	service *s.DashboardCredentialService
	scope   DashboardAccountScope
}

func NewDashboardCredentialHandler(service *s.DashboardCredentialService, scope DashboardAccountScope) *DashboardCredentialHandler {
	return &DashboardCredentialHandler{service: service, scope: scope}
}

func (h *DashboardCredentialHandler) authorizedAccounts(w http.ResponseWriter, r *http.Request, accountID string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, accountID)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, accountID)
}

// ByType implements GET /api/v1/dashboard/credentials/by-type using current
// account-scoped scanner credentials; data source failures return sanitized 503.
func (h *DashboardCredentialHandler) ByType(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region", "status")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid credential by-type filters")
		return
	}
	accounts, ok := h.authorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.ByType(r.Context(), m.CredentialTypeFilter{
		AccountID: params["account_id"], Region: params["region"], Status: params["status"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
