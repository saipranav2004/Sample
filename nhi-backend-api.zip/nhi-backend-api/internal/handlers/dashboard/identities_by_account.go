package dashboard

import (
	"net/http"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByAccount implements GET /api/v1/dashboard/identities/by-account.
func (h *DashboardBreakdownHandler) ByAccount(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "region", "identity_type")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-account filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, "")
	if !ok {
		return
	}
	result, err := h.service.ByAccount(r.Context(), identitymodels.AccountFilter{
		Region: params["region"], IdentityType: params["identity_type"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
