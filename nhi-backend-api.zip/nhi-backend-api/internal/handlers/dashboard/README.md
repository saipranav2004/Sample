# Dashboard v1 handlers — one flat Go package

All 14 PDF endpoint-named `.go` files live DIRECTLY in `internal/handlers/dashboard/`, with no `identities/`, `credentials/`, `by-type/`, or other endpoint subfolders. Related endpoints may share types in their endpoint files; tests and helpers also remain in this one package (`package dashboard`).

APIs #1–#5 and #8 use the verified identity catalog. The user-confirmed `nhi_scanner.credentials` table now supplies measured cards for #1, real `credential_count` for #4/#5 and the live by-type breakdown #6. #7 remains 503 until usage/rotation/role-risk rules are confirmed; #1 still has nulls for unavailable metrics and #8 has `not_in_iac:null`. The other six PDF endpoints remain placeholders. See [current credential integration](../../../docs/CREDENTIAL_DASHBOARD_INTEGRATION.md) and [integration status](../../../INTEGRATION_STATUS.md).

There is exactly one existing application main (`cmd/api-server/main.go`) and one central router (`internal/routes/routes.go`). Only the controlled integrator should merge changes to those shared files; preserve all legacy code.
