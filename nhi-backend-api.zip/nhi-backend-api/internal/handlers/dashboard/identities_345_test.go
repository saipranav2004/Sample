package dashboard

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

type testScope struct{ ids []string }

func (a testScope) AllowedAccountIDs(_ context.Context, _ *appjwt.CustomClaims) ([]string, error) {
	return a.ids, nil
}

type testReader struct{}

func (testReader) ByClass(_ context.Context, _ m.ClassFilter) ([]m.FunctionalClassCount, error) {
	return []m.FunctionalClassCount{{FunctionalClass: "service", Count: 2}}, nil
}
func (testReader) ByAccountIdentityCounts(_ context.Context, _ m.AccountFilter) ([]m.AccountIdentityCount, error) {
	return []m.AccountIdentityCount{{AccountID: "123456789012", IdentityCount: 2}}, nil
}
func (testReader) ByRegionIdentityCounts(_ context.Context, _ m.RegionFilter) ([]m.RegionIdentityCount, error) {
	return []m.RegionIdentityCount{{Region: "global", IdentityCount: 2}}, nil
}

func TestDashboard345HTTP(t *testing.T) {
	const secret = "test-only-not-a-production-secret"
	token, err := appjwt.GenerateToken(1, "dev@example.test", "developer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	mw := middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret})
	h := NewDashboard345Handler(s.NewDashboardBreakdownService(testReader{}), testScope{ids: []string{"123456789012"}})
	hit := func(fn http.HandlerFunc, path string, auth bool) *httptest.ResponseRecorder {
		req := httptest.NewRequest(http.MethodGet, path, nil)
		if auth {
			req.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		mw.Authenticate(fn).ServeHTTP(w, req)
		return w
	}
	if w := hit(h.ByClass, "/api/v1/dashboard/identities/by-class", false); w.Code != http.StatusUnauthorized {
		t.Fatalf("missing JWT: %d", w.Code)
	}
	if w := hit(h.ByClass, "/api/v1/dashboard/identities/by-class?account_id=999999999999", true); w.Code != http.StatusForbidden {
		t.Fatalf("disallowed account: %d", w.Code)
	}
	if w := hit(h.ByClass, "/api/v1/dashboard/identities/by-class?unknown=x", true); w.Code != http.StatusBadRequest {
		t.Fatalf("unknown filter: %d", w.Code)
	}
	if w := hit(h.ByClass, "/api/v1/dashboard/identities/by-class?region=a&region=b", true); w.Code != http.StatusBadRequest {
		t.Fatalf("duplicate filter: %d", w.Code)
	}
	w := hit(h.ByClass, "/api/v1/dashboard/identities/by-class?account_id=123456789012&region=global", true)
	if w.Code != http.StatusOK {
		t.Fatalf("class: %d %s", w.Code, w.Body.String())
	}
	var out m.ByClassResponse
	if err := json.Unmarshal(w.Body.Bytes(), &out); err != nil || out.Total != 2 || strings.Contains(w.Body.String(), "\"success\"") {
		t.Fatalf("unexpected class payload: %s %v", w.Body.String(), err)
	}
	w = hit(h.ByAccount, "/api/v1/dashboard/identities/by-account?identity_type=lambda_function", true)
	var account m.ByAccountResponse
	if w.Code != http.StatusOK || json.Unmarshal(w.Body.Bytes(), &account) != nil || account.TotalAccounts != 1 || account.Breakdown[0].IdentityCount != 2 {
		t.Fatalf("identity-only account payload: %d %s", w.Code, w.Body.String())
	}
	if strings.Contains(w.Body.String(), "account_name") || !strings.Contains(w.Body.String(), `"credential_count":null`) {
		t.Fatalf("account name omitted and unavailable credential count null: %s", w.Body.String())
	}
	w = hit(h.ByRegion, "/api/v1/dashboard/identities/by-region?account_id=123456789012", true)
	var region m.ByRegionResponse
	if w.Code != http.StatusOK || json.Unmarshal(w.Body.Bytes(), &region) != nil || region.TotalRegions != 1 || region.Breakdown[0].Region != "global" || region.Breakdown[0].IdentityCount != 2 {
		t.Fatalf("identity-only region payload: %d %s", w.Code, w.Body.String())
	}
	if !strings.Contains(w.Body.String(), `"credential_count":null`) {
		t.Fatalf("unavailable credential count must be null: %s", w.Body.String())
	}
	noPolicy := NewDashboard345Handler(s.NewDashboardBreakdownService(testReader{}), nil)
	if w := hit(noPolicy.ByClass, "/api/v1/dashboard/identities/by-class", true); w.Code != http.StatusServiceUnavailable {
		t.Fatalf("missing policy must fail closed: %d", w.Code)
	}
	invalidPolicy := NewDashboard345Handler(s.NewDashboardBreakdownService(testReader{}), testScope{ids: []string{"not-an-account"}})
	if w := hit(invalidPolicy.ByClass, "/api/v1/dashboard/identities/by-class", true); w.Code != http.StatusServiceUnavailable {
		t.Fatalf("invalid policy must fail closed: %d", w.Code)
	}
}

// Option A is deliberate: a signed-in dashboard user receives every known AWS
// account, not a URL-supplied account ID or an unverified account JWT claim.
type knownAccountsStub struct{ ids []string }

func (s knownAccountsStub) AllKnownAccountIDs(_ context.Context) ([]string, error) {
	return s.ids, nil
}

func TestDashboardAllAccountsScope(t *testing.T) {
	scope := NewDashboardAllAccountsScope(knownAccountsStub{ids: []string{"123456789012", "234567890123"}})
	ids, err := scope.AllowedAccountIDs(context.Background(), &appjwt.CustomClaims{UserID: 9})
	if err != nil || len(ids) != 2 || ids[0] != "123456789012" {
		t.Fatalf("all-account policy: %v, %v", ids, err)
	}
	if _, err := scope.AllowedAccountIDs(context.Background(), nil); err == nil {
		t.Fatal("nil JWT claims accepted")
	}
	if _, err := scope.AllowedAccountIDs(context.Background(), &appjwt.CustomClaims{UserID: 0}); err == nil {
		t.Fatal("anonymous JWT user accepted")
	}
}
