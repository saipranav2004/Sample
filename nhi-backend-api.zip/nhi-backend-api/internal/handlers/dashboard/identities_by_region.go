package dashboard

import (
	"net/http"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByRegion implements GET /api/v1/dashboard/identities/by-region.
func (h *DashboardBreakdownHandler) ByRegion(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "identity_type")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-region filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.ByRegion(r.Context(), identitymodels.RegionFilter{
		AccountID: params["account_id"], IdentityType: params["identity_type"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
