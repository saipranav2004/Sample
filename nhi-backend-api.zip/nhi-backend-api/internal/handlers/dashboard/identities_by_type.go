package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// ByType implements GET /api/v1/dashboard/identities/by-type.
func (h *DashboardBreakdownHandler) ByType(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region", "status", "functional_class")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid identity by-type filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.ByType(r.Context(), m.TypeFilter{
		AccountID: params["account_id"], Region: params["region"], Status: params["status"],
		FunctionalClass: params["functional_class"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
