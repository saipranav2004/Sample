package dashboard

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/middleware"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	dashservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

func TestDashboardCredentialsHTTPWithoutInventory(t *testing.T) {
	const secret = "credentials-test-secret"
	token, err := appjwt.GenerateToken(1, "viewer@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	mw := middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret})
	h := NewDashboardCredentialHandler(
		dashservices.NewDashboardCredentialService(dashrepo.NewDashboardCredentialRepository(nil)),
		testScope{ids: []string{"123456789012"}},
	)
	request := func(handler http.HandlerFunc, path string, authenticated bool) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodGet, path, nil)
		if authenticated {
			r.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		mw.Authenticate(handler).ServeHTTP(w, r)
		return w
	}
	for _, tc := range []struct {
		fn       http.HandlerFunc
		path     string
		auth     bool
		want     int
		wantCode string
	}{
		{h.ByType, "/api/v1/dashboard/credentials/by-type", false, 401, "UNAUTHORIZED"},
		{h.Hygiene, "/api/v1/dashboard/credentials/hygiene", false, 401, "UNAUTHORIZED"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?account_id=999999999999", true, 403, "FORBIDDEN"},
		{h.Hygiene, "/api/v1/dashboard/credentials/hygiene?account_id=999999999999", true, 403, "FORBIDDEN"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?region=us-east-1&status=active", true, 503, "DATA_SOURCE_UNAVAILABLE"},
		{h.Hygiene, "/api/v1/dashboard/credentials/hygiene?account_id=123456789012", true, 503, "DATA_SOURCE_UNAVAILABLE"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?region=US-EAST-1", true, 400, "INVALID_FILTER"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?status=a%27%20OR%201%3D1", true, 400, "INVALID_FILTER"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?status=active&status=inactive", true, 400, "INVALID_FILTER"},
		{h.ByType, "/api/v1/dashboard/credentials/by-type?unexpected=1", true, 400, "INVALID_FILTER"},
		{h.Hygiene, "/api/v1/dashboard/credentials/hygiene?region=us-east-1", true, 400, "INVALID_FILTER"},
		{h.Hygiene, "/api/v1/dashboard/credentials/hygiene?account_id=bad", true, 400, "INVALID_FILTER"},
	} {
		w := request(tc.fn, tc.path, tc.auth)
		code := `"code":"` + tc.wantCode + `"`
		if tc.want == http.StatusUnauthorized { // existing global middleware uses a legacy error envelope
			code = `"error":"UNAUTHORIZED"`
		}
		if w.Code != tc.want || !strings.Contains(w.Body.String(), code) {
			t.Errorf("%s auth=%t: %d %s; expected %d %s", tc.path, tc.auth, w.Code, w.Body.String(), tc.want, tc.wantCode)
		}
		if tc.want == 503 && (strings.Contains(w.Body.String(), `"total"`) || strings.Contains(w.Body.String(), `"breakdown"`)) {
			t.Errorf("503 must not include a fabricated success payload: %s", w.Body.String())
		}
	}
	noPolicy := NewDashboardCredentialHandler(dashservices.NewDashboardCredentialService(dashrepo.NewDashboardCredentialRepository(nil)), nil)
	if w := request(noPolicy.ByType, "/api/v1/dashboard/credentials/by-type", true); w.Code != 503 || !strings.Contains(w.Body.String(), `"ACCESS_POLICY_UNAVAILABLE"`) {
		t.Fatalf("missing policy: %d %s", w.Code, w.Body.String())
	}
	badPolicy := NewDashboardCredentialHandler(dashservices.NewDashboardCredentialService(dashrepo.NewDashboardCredentialRepository(nil)), testScope{ids: []string{"bad-account"}})
	if w := request(badPolicy.Hygiene, "/api/v1/dashboard/credentials/hygiene", true); w.Code != 503 || !strings.Contains(w.Body.String(), `"ACCESS_POLICY_UNAVAILABLE"`) {
		t.Fatalf("invalid policy: %d %s", w.Code, w.Body.String())
	}
}
