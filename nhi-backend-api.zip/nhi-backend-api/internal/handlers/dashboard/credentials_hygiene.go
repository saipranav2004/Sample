package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// Hygiene implements GET /api/v1/dashboard/credentials/hygiene. Incomplete
// hygiene cards must not be presented as measured zeros or sample results.
func (h *DashboardCredentialHandler) Hygiene(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid credential hygiene filters")
		return
	}
	accounts, ok := h.authorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Hygiene(r.Context(), m.CredentialHygieneFilter{
		AccountID: params["account_id"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
