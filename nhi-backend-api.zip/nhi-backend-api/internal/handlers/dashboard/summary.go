package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// Summary implements GET /api/v1/dashboard/summary (partial 200 contract).
// Legacy GET /api/dashboard/summary remains a separate existing route.
func (h *DashboardBreakdownHandler) Summary(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid summary filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Summary(r.Context(), m.SummaryFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
