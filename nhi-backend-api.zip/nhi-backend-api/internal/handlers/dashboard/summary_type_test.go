package dashboard

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

type summaryTypeReader struct{ testReader }

func (summaryTypeReader) ByType(_ context.Context, _ m.TypeFilter) ([]m.IdentityTypeCount, error) {
	return []m.IdentityTypeCount{{IdentityType: "lambda_function", Count: 2}}, nil
}
func (summaryTypeReader) SummaryIdentityCounts(_ context.Context, _ m.SummaryFilter, _, _ time.Time) ([]m.SummaryIdentityRow, error) {
	return []m.SummaryIdentityRow{{Status: "active", CurrentCount: 2, New24h: 1}}, nil
}
func (summaryTypeReader) SummaryScanData(_ context.Context, _ m.SummaryFilter) (m.SummaryScanData, error) {
	return m.SummaryScanData{CompletedAccountCount: 1}, nil
}

func TestSummaryAndByTypeHTTP(t *testing.T) {
	const secret = "summary-test-only-secret"
	token, err := appjwt.GenerateToken(1, "tester@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	mw := middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret})
	h := NewDashboard345Handler(s.NewDashboardBreakdownService(summaryTypeReader{}), testScope{ids: []string{"123456789012"}})
	hit := func(fn http.HandlerFunc, path string, auth bool) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodGet, path, nil)
		if auth {
			r.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		mw.Authenticate(fn).ServeHTTP(w, r)
		return w
	}
	for _, fn := range []http.HandlerFunc{h.Summary, h.ByType} {
		if w := hit(fn, "/api/v1/dashboard/summary", false); w.Code != 401 {
			t.Fatalf("no JWT: %d", w.Code)
		}
		if w := hit(fn, "/api/v1/dashboard/summary?account_id=999999999999", true); w.Code != 403 {
			t.Fatalf("unknown account: %d %s", w.Code, w.Body.String())
		}
	}
	for _, tc := range []struct {
		fn   http.HandlerFunc
		path string
	}{
		{h.Summary, "/api/v1/dashboard/summary?status=active"},
		{h.Summary, "/api/v1/dashboard/summary?region=US-EAST-1"},
		{h.ByType, "/api/v1/dashboard/identities/by-type?functional_class=service&status=active&region=us-east-1&account_id=123456789012&status=inactive"},
		{h.ByType, "/api/v1/dashboard/identities/by-type?functional_class=%27%20OR%201%3D1"},
	} {
		if w := hit(tc.fn, tc.path, true); w.Code != 400 {
			t.Fatalf("invalid %s: %d %s", tc.path, w.Code, w.Body.String())
		}
	}
	w := hit(h.ByType, "/api/v1/dashboard/identities/by-type?account_id=123456789012&region=us-east-1&status=active&functional_class=service", true)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"total":2`) || !strings.Contains(w.Body.String(), `"identity_type":"lambda_function"`) {
		t.Fatalf("by type response: %d %s", w.Code, w.Body.String())
	}
	w = hit(h.Summary, "/api/v1/dashboard/summary?account_id=123456789012", true)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"total_identities":2`) || !strings.Contains(w.Body.String(), `"total_accounts_scanned":1`) || !strings.Contains(w.Body.String(), `"total_credentials":null`) || !strings.Contains(w.Body.String(), `"scan_duration_seconds":null`) {
		t.Fatalf("partial summary response: %d %s", w.Code, w.Body.String())
	}
	w = hit(h.Summary, "/api/v1/dashboard/summary?region=us-east-1", true)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"total_accounts_scanned":null`) || !strings.Contains(w.Body.String(), `"scan_status":null`) {
		t.Fatalf("region-scoped scan cards: %d %s", w.Code, w.Body.String())
	}
}
