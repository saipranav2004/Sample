package dashboard

import (
	"context"
	"errors"
	"github.com/lib/pq"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestDashboardErrorBoundary(t *testing.T) {
	tests := []struct {
		name   string
		err    error
		status int
		code   string
	}{
		{"timeout", context.DeadlineExceeded, 504, "TIMEOUT"},
		{"unavailable column", &pq.Error{Code: "42703", Message: "sensitive SQL"}, 503, "DATA_SOURCE_UNAVAILABLE"},
		{"missing table", &pq.Error{Code: "42P01", Message: "sensitive SQL"}, 503, "DATA_SOURCE_UNAVAILABLE"},
		{"permission", &pq.Error{Code: "42501", Message: "sensitive SQL"}, 503, "DATA_SOURCE_UNAVAILABLE"},
		{"unexpected", errors.New("secret connection string"), 500, "INTERNAL_ERROR"},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			w := httptest.NewRecorder()
			dashboardServiceError(w, tc.err)
			if w.Code != tc.status || !strings.Contains(w.Body.String(), tc.code) || strings.Contains(w.Body.String(), "sensitive SQL") || strings.Contains(w.Body.String(), "secret connection string") {
				t.Fatalf("%d %s", w.Code, w.Body.String())
			}
		})
	}
	w := httptest.NewRecorder()
	dashboardWriteOK(w, make(chan int))
	if w.Code != http.StatusInternalServerError || !strings.Contains(w.Body.String(), "INTERNAL_ERROR") {
		t.Fatalf("marshaling failure must not send 200: %d %s", w.Code, w.Body.String())
	}
	w = httptest.NewRecorder()
	dashboardServiceError(w, context.Canceled)
	if w.Body.Len() != 0 {
		t.Fatalf("client cancellation must not write: %s", w.Body.String())
	}
}
