package dashboard

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

type exposureTestReader struct{ testReader }

func (exposureTestReader) ExposureCounts(_ context.Context, _ m.ExposureFilter, _ time.Time) ([]m.ExposureCountRow, error) {
	return []m.ExposureCountRow{{IdentityType: "lambda_function", PublicCount: 2, DormantCount: 1, NoActivityCount: 3, MissingOwnerCount: 4, MissingEnvCount: 5}}, nil
}

func TestExposureHTTP(t *testing.T) {
	const secret = "test-only-secret"
	token, err := appjwt.GenerateToken(1, "dev@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	mw := middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret})
	h := NewDashboard345Handler(s.NewDashboardBreakdownService(exposureTestReader{}), testScope{ids: []string{"123456789012"}})
	hit := func(path string, auth bool) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodGet, path, nil)
		if auth {
			r.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		mw.Authenticate(http.HandlerFunc(h.Exposure)).ServeHTTP(w, r)
		return w
	}
	const path = "/api/v1/dashboard/identities/exposure"
	for _, tc := range []struct {
		path   string
		auth   bool
		status int
	}{
		{path, false, http.StatusUnauthorized},
		{path + "?account_id=999999999999", true, http.StatusForbidden},
		{path + "?region=us-east-1", true, http.StatusBadRequest},
		{path + "?account_id=123456789012&account_id=123456789012", true, http.StatusBadRequest},
	} {
		if w := hit(tc.path, tc.auth); w.Code != tc.status {
			t.Fatalf("%s: got %d, want %d: %s", tc.path, w.Code, tc.status, w.Body.String())
		}
	}
	w := hit(path+"?account_id=123456789012", true)
	if w.Code != http.StatusOK {
		t.Fatalf("exposure: %d %s", w.Code, w.Body.String())
	}
	var response m.ExposureResponse
	if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil || response.PubliclyAccessible.Total != 2 ||
		response.Dormant90d.Total != 1 || response.NoActivityTracked != 3 ||
		response.MissingOwnerTag != 4 || response.MissingEnvironmentTag != 5 || response.NotInIAC != nil ||
		len(response.PubliclyAccessible.ByType) != 1 {
		t.Fatalf("unexpected exposure body: %s, %v", w.Body.String(), err)
	}
	var obj map[string]json.RawMessage
	if json.Unmarshal(w.Body.Bytes(), &obj) != nil || string(obj["not_in_iac"]) != "null" {
		t.Fatalf("IaC must be explicit null, not fake zero: %s", w.Body.String())
	}
}
