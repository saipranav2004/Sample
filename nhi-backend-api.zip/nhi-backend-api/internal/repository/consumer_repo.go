package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"time"
)

type RoleConsumer struct {
	CallerARN    string    `json:"caller_arn"`
	CallerType   string    `json:"caller_type"`
	SourceIP     string    `json:"source_ip"`
	UserAgent    string    `json:"user_agent"`
	Region       string    `json:"region"`
	SessionCount int       `json:"session_count"`
	FirstAssumed time.Time `json:"first_assumed"`
	LastAssumed  time.Time `json:"last_assumed"`
}

// ErrConsumersUnavailable indicates that the scan's event table does not include
// caller_arn and caller_type; source IP alone is not a reliable identity.
var ErrConsumersUnavailable = errors.New("role consumer principals unavailable: nhi_events_aws requires caller_arn and caller_type")

type ConsumerRepository struct{ db *PostgresDB }

func NewConsumerRepository(db *PostgresDB) *ConsumerRepository { return &ConsumerRepository{db: db} }

func (r *ConsumerRepository) GetRoleConsumers(ctx context.Context, roleARN, scanID string, offset, limit int) ([]RoleConsumer, int, error) {
	consumers := make([]RoleConsumer, 0)
	var callerColumns int
	err := r.db.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = 'nhi_scanner' AND table_name = 'nhi_events_aws'
        AND column_name IN ('caller_arn', 'caller_type')`).Scan(&callerColumns)
	if err != nil {
		return nil, 0, fmt.Errorf("check consumer schema: %w", err)
	}
	if callerColumns != 2 {
		return nil, 0, ErrConsumersUnavailable
	}
	filter := "WHERE identity_arn = $1 AND event_name LIKE 'AssumeRole%'"
	args := []interface{}{roleARN}
	if scanID != "" {
		filter += " AND scan_id = $2"
		args = append(args, scanID)
	} else {
		filter += " AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)"
	}
	// Important: unlike the original query, group before counting distinct consumers.
	group := `GROUP BY COALESCE(caller_arn, 'Unknown Principal'),
        COALESCE(caller_type, 'Unknown'), COALESCE(source_ip, 'N/A'),
        COALESCE(user_agent, 'AWS SDK'), COALESCE(region, 'N/A')`
	base := `FROM nhi_scanner.nhi_events_aws ` + filter + " " + group
	countSQL := "SELECT COUNT(*) FROM (SELECT 1 " + base + ") AS grouped"
	var count int
	if err := r.db.DB.QueryRowContext(ctx, countSQL, args...).Scan(&count); err != nil {
		return consumers, 0, fmt.Errorf("count role consumers: %w", err)
	}
	if count == 0 {
		return consumers, 0, nil
	}

	n := len(args)
	pageSQL := `SELECT COALESCE(caller_arn, 'Unknown Principal'),
        COALESCE(caller_type, 'Unknown'), COALESCE(source_ip, 'N/A'),
        COALESCE(user_agent, 'AWS SDK'), COALESCE(region, 'N/A'),
        COUNT(*), MIN(event_time), MAX(event_time) ` + base + `
        ORDER BY MAX(event_time) DESC NULLS LAST, 1, 2, 3, 4, 5
        LIMIT $` + strconv.Itoa(n+1) + ` OFFSET $` + strconv.Itoa(n+2)
	args = append(args, limit, offset)
	rows, err := r.db.DB.QueryContext(ctx, pageSQL, args...)
	if err != nil {
		return consumers, count, fmt.Errorf("query role consumers: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var c RoleConsumer
		var first, last sql.NullTime
		if err := rows.Scan(&c.CallerARN, &c.CallerType, &c.SourceIP, &c.UserAgent,
			&c.Region, &c.SessionCount, &first, &last); err != nil {
			return nil, 0, fmt.Errorf("scan role consumer: %w", err)
		}
		if first.Valid {
			c.FirstAssumed = first.Time.UTC()
		}
		if last.Valid {
			c.LastAssumed = last.Time.UTC()
		}
		consumers = append(consumers, c)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate role consumers: %w", err)
	}
	return consumers, count, nil
}
