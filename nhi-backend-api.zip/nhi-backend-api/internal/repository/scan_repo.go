package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type ScanRepository struct {
	db *PostgresDB
}

func NewScanRepository(db *PostgresDB) *ScanRepository {
	return &ScanRepository{db: db}
}

// List returns historical scans paginated
func (r *ScanRepository) List(ctx context.Context, offset, limit int) ([]models.Scan, int, error) {
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, "SELECT COUNT(*) FROM nhi_scanner.nhi_scans_aws").Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count scans: %w", err)
	}

	query := `
		SELECT scan_id, COALESCE(account_id, ''), COALESCE(target_name, ''),
               COALESCE(total_identities, 0), COALESCE(total_events, 0),
               COALESCE(total_secrets, 0), COALESCE(status, ''),
               NULL::timestamptz AS scan_start, scan_end
		FROM nhi_scanner.nhi_scans_aws
		ORDER BY scan_end DESC NULLS LAST, id DESC
		LIMIT $2 OFFSET $1`

	rows, err := r.db.DB.QueryContext(ctx, query, offset, limit)
	if err != nil {
		return nil, 0, fmt.Errorf("query scans: %w", err)
	}
	defer rows.Close()

	var scans []models.Scan
	for rows.Next() {
		var s models.Scan
		var scanEnd sql.NullTime

		err := rows.Scan(
			&s.ScanID, &s.AccountID, &s.TargetName, &s.TotalIdentities,
			&s.TotalEvents, &s.TotalSecrets, &s.Status, &s.ScanStart, &scanEnd,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan row: %w", err)
		}

		if scanEnd.Valid {
			s.ScanEnd = &scanEnd.Time
		}

		scans = append(scans, s)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate scans: %w", err)
	}
	return scans, totalCount, nil
}
