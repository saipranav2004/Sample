package dashboard

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ErrEmptyAccountScope means the caller has not been authorized for any AWS account.
var ErrEmptyAccountScope = errors.New("authorized account scope is empty")

// DashboardBreakdownRepository reads the UUID-keyed nhi_scanner.identities catalog.
// This is intentionally distinct from nhi_scanner.nhi_identities_aws.
type DashboardBreakdownRepository struct{ db *sql.DB }

func NewDashboardBreakdownRepository(db *sql.DB) *DashboardBreakdownRepository {
	return &DashboardBreakdownRepository{db: db}
}

// AllKnownAccountIDs implements the explicitly approved policy that every
// authenticated dashboard user may see every known AWS account. Include scan
// targets and current scanner credentials as well as catalog rows, so an
// account with zero current identities can still be selected. Only 12-digit
// AWS account IDs qualify. A missing credentials table is an unavailable
// source, never silently treated as an empty credential inventory.
// This method supplies an account scope; it does not count identities.
func (r *DashboardBreakdownRepository) AllKnownAccountIDs(ctx context.Context) ([]string, error) {
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("account scope source unavailable")
	}
	const query = `
        SELECT account_id FROM (
            SELECT account_id FROM nhi_scanner.identities
            UNION
            SELECT account_id::text FROM nhi_scanner.nhi_scans_aws
            UNION
            SELECT account_id FROM nhi_scanner.credentials WHERE deleted_at IS NULL
        ) AS known_accounts
        WHERE account_id ~ '^[0-9]{12}$'
        ORDER BY account_id ASC`
	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("load dashboard account scope: %w", err)
	}
	defer rows.Close()
	ids := make([]string, 0)
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, fmt.Errorf("scan dashboard account scope: %w", err)
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate dashboard account scope: %w", err)
	}
	return ids, nil
}

// ByClass counts current (not soft-deleted) catalog identities. NULL/blank
// functional_class maps to "unclassified"; no other taxonomy remapping is assumed.
func (r *DashboardBreakdownRepository) ByClass(ctx context.Context, f identitymodels.ClassFilter) ([]identitymodels.FunctionalClassCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(BTRIM(functional_class), ''), 'unclassified') AS functional_class,
               COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
        GROUP BY 1
        ORDER BY identity_count DESC, functional_class ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region)
	if err != nil {
		return nil, fmt.Errorf("query by class: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.FunctionalClassCount, 0)
	for rows.Next() {
		var c identitymodels.FunctionalClassCount
		if err := rows.Scan(&c.FunctionalClass, &c.Count); err != nil {
			return nil, fmt.Errorf("scan by class: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate by class: %w", err)
	}
	return out, nil
}
