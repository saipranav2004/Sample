package dashboard

import (
	"context"
	"fmt"

	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByRegionIdentityCounts returns identity-only counts. NULL/blank region is
// classified as "unknown", not silently converted to the AWS "global" region.
func (r *DashboardBreakdownRepository) ByRegionIdentityCounts(ctx context.Context, f identitymodels.RegionFilter) ([]identitymodels.RegionIdentityCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(BTRIM(region), ''), 'unknown') AS region,
               COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR identity_type = $3::text)
        GROUP BY 1
        ORDER BY identity_count DESC, region ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.IdentityType)
	if err != nil {
		return nil, fmt.Errorf("query by region: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.RegionIdentityCount, 0)
	for rows.Next() {
		var c identitymodels.RegionIdentityCount
		if err := rows.Scan(&c.Region, &c.IdentityCount); err != nil {
			return nil, fmt.Errorf("scan by region: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate by region: %w", err)
	}
	return out, nil
}
