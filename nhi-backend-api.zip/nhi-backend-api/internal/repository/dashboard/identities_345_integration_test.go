package dashboard

import (
	"context"
	"database/sql"
	"errors"
	"net/url"
	"os"
	"strings"
	"testing"
	"time"

	_ "github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// Run only on an ISOLATED *_test database. This test creates/truncates nhi_scanner.identities.
// TEST_DASHBOARD_DATABASE_URL=postgres://.../dashboard_345_test?sslmode=disable go test ./internal/repository/dashboard -v
func TestDashboard345Postgres(t *testing.T) {
	dsn := os.Getenv("TEST_DASHBOARD_DATABASE_URL")
	if dsn == "" {
		t.Skip("set TEST_DASHBOARD_DATABASE_URL for disposable PostgreSQL integration test")
	}
	parsed, err := url.Parse(dsn)
	if err != nil || !strings.HasSuffix(parsed.Path, "_test") {
		t.Fatal("test creates/truncates nhi_scanner.identities: database name must end in _test")
	}
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	ctx := context.Background()
	for _, query := range []string{
		`CREATE SCHEMA IF NOT EXISTS nhi_scanner`,
		`CREATE TABLE IF NOT EXISTS nhi_scanner.identities (
            id uuid PRIMARY KEY, arn text NOT NULL, name text NOT NULL,
            identity_type text NOT NULL, functional_class text,
            account_id text NOT NULL, region text NOT NULL, status text NOT NULL,
            first_seen_at timestamptz NOT NULL, last_seen_at timestamptz NOT NULL,
            discovery_source text NOT NULL, created_at timestamptz NOT NULL,
            updated_at timestamptz NOT NULL, deleted_at timestamptz,
            is_publicly_accessible boolean, last_activity_at timestamptz,
            owner text, environment text)`,
		`ALTER TABLE nhi_scanner.identities ADD COLUMN IF NOT EXISTS is_publicly_accessible boolean`,
		`ALTER TABLE nhi_scanner.identities ADD COLUMN IF NOT EXISTS last_activity_at timestamptz`,
		`ALTER TABLE nhi_scanner.identities ADD COLUMN IF NOT EXISTS owner text`,
		`ALTER TABLE nhi_scanner.identities ADD COLUMN IF NOT EXISTS environment text`,
		`CREATE TABLE IF NOT EXISTS nhi_scanner.nhi_scans_aws (
            id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            scan_id varchar(200) NOT NULL, account_id varchar(200),
            status varchar(50), scan_end timestamptz)`,
		`ALTER TABLE nhi_scanner.nhi_scans_aws ADD COLUMN IF NOT EXISTS status varchar(50)`,
		`ALTER TABLE nhi_scanner.nhi_scans_aws ADD COLUMN IF NOT EXISTS scan_end timestamptz`,
		`CREATE TABLE IF NOT EXISTS nhi_scanner.credentials (
            id uuid PRIMARY KEY, arn text NOT NULL, name text NOT NULL,
            credential_type text NOT NULL, account_id text NOT NULL, region text NOT NULL,
            status text NOT NULL, created_at_aws timestamptz, first_seen_at timestamptz NOT NULL,
            last_seen_at timestamptz NOT NULL, deleted_at timestamptz,
            last_used_at timestamptz, last_rotated_at timestamptz, expires_at timestamptz,
            rotation_enabled boolean, rotation_interval_days integer, tags jsonb,
            owner_principal_arn text, trust_policy jsonb, attached_policies jsonb,
            inline_policies jsonb, permission_boundary_arn text, max_session_duration integer,
            privilege_level integer, assumable_role_arns jsonb, discovery_source text NOT NULL,
            scan_id text, type_attributes jsonb, raw_api_response jsonb,
            created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL)`,
		`TRUNCATE nhi_scanner.identities`,
		`TRUNCATE nhi_scanner.credentials`,
		`TRUNCATE nhi_scanner.nhi_scans_aws`,
		`INSERT INTO nhi_scanner.nhi_scans_aws (scan_id,account_id,status,scan_end) VALUES
            ('scope-scan','345678901234','COMPLETED',now()),
            ('fixture-scan','123456789012','COMPLETED',now()),
            ('bad-scan','invalid',NULL,NULL)`,
		`INSERT INTO nhi_scanner.identities
            (id,arn,name,identity_type,functional_class,account_id,region,status,
             first_seen_at,last_seen_at,discovery_source,created_at,updated_at,deleted_at) VALUES
            ('00000000-0000-0000-0000-000000000001','arn:test:1','one','lambda_function','service','123456789012','us-east-1','active',now(),now(),'test',now(),now(),NULL),
            ('00000000-0000-0000-0000-000000000002','arn:test:2','two','ec2_instance','','123456789012','global','active',now(),now(),'test',now(),now(),NULL),
            ('00000000-0000-0000-0000-000000000003','arn:test:3','three','lambda_function','cicd','234567890123','us-east-1','active',now(),now(),'test',now(),now(),NULL),
            ('00000000-0000-0000-0000-000000000004','arn:test:4','four','lambda_function','service','123456789012','','active',now(),now(),'test',now(),now(),NULL),
            ('00000000-0000-0000-0000-000000000005','arn:test:5','five','lambda_function','service','123456789012','us-east-1','active',now(),now(),'test',now(),now(),'2020-01-01T00:00:00Z')`,
		`INSERT INTO nhi_scanner.credentials
            (id,arn,name,credential_type,account_id,region,status,first_seen_at,last_seen_at,
             last_used_at,expires_at,discovery_source,created_at,updated_at,deleted_at) VALUES
            ('10000000-0000-0000-0000-000000000001','arn:key:1','key-1','access_key','123456789012','us-east-1','active',now()-interval '12 hours',now(),now()-interval '91 days',now()+interval '10 days','fixture',now(),now(),NULL),
            ('10000000-0000-0000-0000-000000000002','arn:cert:2','cert-2','acm_certificate','123456789012','global','expired',now()-interval '2 days',now(),NULL,now()-interval '1 day','fixture',now(),now(),NULL),
            ('10000000-0000-0000-0000-000000000003','arn:key:3','key-3','access_key','123456789012','us-east-1','inactive',now(),now(),NULL,NULL,'fixture',now(),now(),now()),
            ('10000000-0000-0000-0000-000000000004','arn:key:4','key-4','access_key','234567890123','us-east-1','active',now(),now(),NULL,NULL,'fixture',now(),now(),NULL),
            ('10000000-0000-0000-0000-000000000005','arn:key:5','key-5','access_key','456789012345','global','active',now(),now(),NULL,NULL,'fixture',now(),now(),NULL)`,
		`UPDATE nhi_scanner.identities
            SET is_publicly_accessible = true, last_activity_at = now() - interval '91 days', owner = NULL, environment = NULL
            WHERE id = '00000000-0000-0000-0000-000000000001'`,
		`UPDATE nhi_scanner.identities
            SET is_publicly_accessible = false, owner = 'owner', environment = 'prod'
            WHERE id = '00000000-0000-0000-0000-000000000002'`,
		`UPDATE nhi_scanner.identities
            SET is_publicly_accessible = true, last_activity_at = now() - interval '30 days', owner = '', environment = NULL
            WHERE id = '00000000-0000-0000-0000-000000000004'`,
	} {
		if _, err := db.ExecContext(ctx, query); err != nil {
			t.Fatalf("fixture query %s: %v", query, err)
		}
	}
	repo := NewDashboardBreakdownRepository(db)
	allAccounts, err := repo.AllKnownAccountIDs(ctx)
	if err != nil || len(allAccounts) != 4 || allAccounts[0] != "123456789012" ||
		allAccounts[1] != "234567890123" || allAccounts[2] != "345678901234" || allAccounts[3] != "456789012345" {
		t.Fatalf("known AWS accounts %+v %v", allAccounts, err)
	}
	allowed := []string{"123456789012"}
	classes, err := repo.ByClass(ctx, m.ClassFilter{AllowedAccountIDs: allowed})
	if err != nil || len(classes) != 2 || classes[0].FunctionalClass != "service" || classes[0].Count != 2 || classes[1].FunctionalClass != "unclassified" {
		t.Fatalf("classes %+v %v", classes, err)
	}
	classes, err = repo.ByClass(ctx, m.ClassFilter{AllowedAccountIDs: allowed, Region: "global"})
	if err != nil || len(classes) != 1 || classes[0].FunctionalClass != "unclassified" {
		t.Fatalf("global %+v %v", classes, err)
	}
	classes, err = repo.ByClass(ctx, m.ClassFilter{AllowedAccountIDs: allowed, Region: "unknown"})
	if err != nil || len(classes) != 1 || classes[0].FunctionalClass != "service" || classes[0].Count != 1 {
		t.Fatalf("unknown region class %+v %v", classes, err)
	}
	acct, err := repo.ByAccountIdentityCounts(ctx, m.AccountFilter{AllowedAccountIDs: allowed, Region: "us-east-1", IdentityType: "lambda_function"})
	if err != nil || len(acct) != 1 || acct[0].IdentityCount != 1 || acct[0].AccountID != "123456789012" {
		t.Fatalf("account %+v %v", acct, err)
	}
	acct, err = repo.ByAccountIdentityCounts(ctx, m.AccountFilter{AllowedAccountIDs: allowed, Region: "unknown", IdentityType: "lambda_function"})
	if err != nil || len(acct) != 1 || acct[0].IdentityCount != 1 {
		t.Fatalf("unknown region account %+v %v", acct, err)
	}
	regions, err := repo.ByRegionIdentityCounts(ctx, m.RegionFilter{AllowedAccountIDs: allowed, IdentityType: "lambda_function"})
	if err != nil || len(regions) != 2 || regions[0].Region != "unknown" || regions[1].Region != "us-east-1" {
		t.Fatalf("regions %+v %v", regions, err)
	}
	exposure, err := repo.ExposureCounts(ctx, m.ExposureFilter{AllowedAccountIDs: allowed}, time.Now().UTC().Add(-90*24*time.Hour))
	if err != nil || len(exposure) != 2 || exposure[0].IdentityType != "ec2_instance" ||
		exposure[1].IdentityType != "lambda_function" || exposure[1].PublicCount != 2 ||
		exposure[1].DormantCount != 1 || exposure[1].NoActivityCount != 0 ||
		exposure[1].MissingOwnerCount != 2 || exposure[1].MissingEnvCount != 2 ||
		exposure[0].NoActivityCount != 1 {
		t.Fatalf("exposure: %+v %v", exposure, err)
	}
	if _, err := repo.ExposureCounts(ctx, m.ExposureFilter{}, time.Now()); !errors.Is(err, ErrEmptyAccountScope) {
		t.Fatalf("unscoped exposure not rejected: %v", err)
	}
	byType, err := repo.ByType(ctx, m.TypeFilter{AllowedAccountIDs: allowed})
	if err != nil || len(byType) != 2 || byType[0].IdentityType != "lambda_function" || byType[0].Count != 2 || byType[1].Count != 1 {
		t.Fatalf("by type: %+v %v", byType, err)
	}
	byType, err = repo.ByType(ctx, m.TypeFilter{AllowedAccountIDs: allowed, Region: "us-east-1", Status: "active", FunctionalClass: "service"})
	if err != nil || len(byType) != 1 || byType[0].Count != 1 {
		t.Fatalf("filtered type: %+v %v", byType, err)
	}
	now := time.Now().UTC()
	summary, err := repo.SummaryIdentityCounts(ctx, m.SummaryFilter{AllowedAccountIDs: allowed}, now.Add(-24*time.Hour), now)
	if err != nil || len(summary) != 1 || summary[0].Status != "active" || summary[0].CurrentCount != 3 || summary[0].New24h != 3 || summary[0].Removed24h != 0 {
		t.Fatalf("summary identities: %+v %v", summary, err)
	}
	scan, err := repo.SummaryScanData(ctx, m.SummaryFilter{AllowedAccountIDs: allowed})
	if err != nil || scan.CompletedAccountCount != 1 || scan.LastScanAt == nil || scan.ScanStatus == nil || *scan.ScanStatus != "COMPLETED" {
		t.Fatalf("summary scans: %+v %v", scan, err)
	}
	cred := NewDashboardCredentialRepository(db)
	filteredTypes, err := cred.CredentialTypeCounts(ctx, m.CredentialTypeFilter{AllowedAccountIDs: allowed, Region: "us-east-1", Status: "active"})
	if err != nil || len(filteredTypes) != 1 || filteredTypes[0].CredentialType != "access_key" || filteredTypes[0].Count != 1 {
		t.Fatalf("scoped credential types %+v %v", filteredTypes, err)
	}
	allTypes, err := cred.CredentialTypeCounts(ctx, m.CredentialTypeFilter{AllowedAccountIDs: allowed})
	if err != nil || len(allTypes) != 2 || allTypes[0].Count != 1 || allTypes[1].Count != 1 {
		t.Fatalf("current-only credential types %+v %v", allTypes, err)
	}
	credentialSummary, err := cred.SummaryCredentialCounts(ctx, m.SummaryFilter{AllowedAccountIDs: allowed}, now.Add(-24*time.Hour), now)
	if err != nil || len(credentialSummary) != 2 {
		t.Fatalf("summary credential groups %+v %v", credentialSummary, err)
	}
	var total, new24h, expiring30d, stale90d int64
	for _, row := range credentialSummary {
		total += row.CurrentCount
		new24h += row.New24h
		expiring30d += row.Expiring30d
		stale90d += row.StaleKeys90d
	}
	if total != 2 || new24h != 1 || expiring30d != 1 || stale90d != 1 {
		t.Fatalf("summary credentials total=%d new=%d expiring=%d stale=%d", total, new24h, expiring30d, stale90d)
	}
	missingUsage, err := cred.SummaryCredentialCounts(ctx, m.SummaryFilter{AllowedAccountIDs: []string{"234567890123"}}, now.Add(-24*time.Hour), now)
	if err != nil || len(missingUsage) != 1 || missingUsage[0].UnknownKeyUsage != 1 || missingUsage[0].StaleKeys90d != 0 {
		t.Fatalf("unknown usage must not become stale or never used %+v %v", missingUsage, err)
	}
	perAccount, err := cred.ByAccountCredentialCounts(ctx, m.AccountFilter{AllowedAccountIDs: allowed, Region: "us-east-1", IdentityType: "lambda_function"})
	if err != nil || perAccount[allowed[0]] != 1 || len(perAccount) != 1 {
		t.Fatalf("credential by account %+v %v", perAccount, err)
	}
	perRegion, err := cred.ByRegionCredentialCounts(ctx, m.RegionFilter{AllowedAccountIDs: allowed, IdentityType: "ec2_instance"})
	if err != nil || perRegion["us-east-1"] != 1 || perRegion["global"] != 1 || len(perRegion) != 2 {
		t.Fatalf("credential by region %+v %v", perRegion, err)
	}
	if _, err := cred.CredentialTypeCounts(ctx, m.CredentialTypeFilter{}); !errors.Is(err, m.ErrCredentialSourceUnavailable) {
		t.Fatalf("unscoped credential types: %v", err)
	}
	if _, err := repo.ByType(ctx, m.TypeFilter{}); !errors.Is(err, ErrEmptyAccountScope) {
		t.Fatalf("unscoped by-type: %v", err)
	}
	if _, err := repo.SummaryIdentityCounts(ctx, m.SummaryFilter{}, now.Add(-24*time.Hour), now); !errors.Is(err, ErrEmptyAccountScope) {
		t.Fatalf("unscoped summary: %v", err)
	}
	if _, err := repo.SummaryScanData(ctx, m.SummaryFilter{AllowedAccountIDs: allowed, Region: "us-east-1"}); err == nil {
		t.Fatal("region-filtered scans must not be approximated")
	}
	if _, err := repo.ByClass(ctx, m.ClassFilter{}); !errors.Is(err, ErrEmptyAccountScope) {
		t.Fatalf("empty scope was not rejected: %v", err)
	}
}
