package dashboard

import (
	"context"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// ByType reads current UUID-keyed catalog identities, not the legacy scanner
// snapshot. Every query is constrained by trusted AllowedAccountIDs.
func (r *DashboardBreakdownRepository) ByType(ctx context.Context, f m.TypeFilter) ([]m.IdentityTypeCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(BTRIM(identity_type), ''), 'unknown') AS identity_type,
               COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
          AND ($4::text = '' OR COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') = $4::text)
          AND ($5::text = '' OR COALESCE(NULLIF(BTRIM(functional_class), ''), 'unclassified') = $5::text)
        GROUP BY 1
        ORDER BY identity_count DESC, identity_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.Status, f.FunctionalClass)
	if err != nil {
		return nil, fmt.Errorf("query identities by type: %w", err)
	}
	defer rows.Close()
	out := make([]m.IdentityTypeCount, 0)
	for rows.Next() {
		var c m.IdentityTypeCount
		if err := rows.Scan(&c.IdentityType, &c.Count); err != nil {
			return nil, fmt.Errorf("scan identities by type: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identities by type: %w", err)
	}
	return out, nil
}
