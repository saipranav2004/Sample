package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialRepository reads the authoritative scanner credential
// inventory. It never reads the unrelated legacy public.credentials table.
type DashboardCredentialRepository struct{ db *sql.DB }

func NewDashboardCredentialRepository(db *sql.DB) *DashboardCredentialRepository {
	return &DashboardCredentialRepository{db: db}
}

func (r *DashboardCredentialRepository) ready(ids []string) error {
	if r == nil || r.db == nil || len(ids) == 0 {
		return m.ErrCredentialSourceUnavailable
	}
	return nil
}

// CredentialTypeCounts implements PDF #6 using current scoped rows, including
// all statuses unless the caller selects a particular status.
func (r *DashboardCredentialRepository) CredentialTypeCounts(ctx context.Context, f m.CredentialTypeFilter) ([]m.CredentialTypeCount, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT credential_type, COUNT(*)
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
          AND ($4::text = '' OR COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') = $4::text)
        GROUP BY credential_type ORDER BY COUNT(*) DESC, credential_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.Status)
	if err != nil {
		return nil, fmt.Errorf("query credential types: %w", err)
	}
	defer rows.Close()
	out := make([]m.CredentialTypeCount, 0)
	for rows.Next() {
		var c m.CredentialTypeCount
		if err := rows.Scan(&c.CredentialType, &c.Count); err != nil {
			return nil, fmt.Errorf("scan credential type: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential types: %w", err)
	}
	return out, nil
}

// SummaryCredentialCounts backs PDF #1 status, newly discovered, expiring and
// stale access-key cards with measured facts. Missing last_used_at does NOT
// imply stale/never used. first_seen_at represents first discovery, not AWS
// issuance. All bounds use the service's one UTC instant.
func (r *DashboardCredentialRepository) SummaryCredentialCounts(ctx context.Context, f m.SummaryFilter, start, now time.Time) ([]m.SummaryCredentialRow, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') AS credential_status,
            COUNT(*) AS current_count,
            COUNT(*) FILTER (WHERE first_seen_at >= $3::timestamptz AND first_seen_at <= $4::timestamptz) AS new_24h,
            COUNT(*) FILTER (WHERE expires_at > $4::timestamptz AND expires_at <= $5::timestamptz) AS expiring_30d,
            COUNT(*) FILTER (WHERE credential_type = 'access_key' AND last_used_at IS NOT NULL
                             AND last_used_at < $6::timestamptz) AS stale_keys_90d,
            COUNT(*) FILTER (WHERE credential_type = 'access_key' AND last_used_at IS NULL) AS unknown_key_usage
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($7::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $7::text)
        GROUP BY 1 ORDER BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, start.UTC(), now.UTC(), now.UTC().Add(30*24*time.Hour), now.UTC().Add(-90*24*time.Hour), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query summary credentials: %w", err)
	}
	defer rows.Close()
	out := make([]m.SummaryCredentialRow, 0)
	for rows.Next() {
		var c m.SummaryCredentialRow
		if err := rows.Scan(&c.Status, &c.CurrentCount, &c.New24h, &c.Expiring30d, &c.StaleKeys90d, &c.UnknownKeyUsage); err != nil {
			return nil, fmt.Errorf("scan summary credentials: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate summary credentials: %w", err)
	}
	return out, nil
}

// ByAccountCredentialCounts counts all current matching credentials by AWS
// account and region. The optional identity_type filter only applies to the
// identity half: credentials have no identity_type or verified join to one.
func (r *DashboardCredentialRepository) ByAccountCredentialCounts(ctx context.Context, f m.AccountFilter) (map[string]int64, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT account_id, COUNT(*) FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $2::text)
        GROUP BY account_id`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query credentials by account: %w", err)
	}
	defer rows.Close()
	out := make(map[string]int64)
	for rows.Next() {
		var key string
		var n int64
		if err := rows.Scan(&key, &n); err != nil {
			return nil, fmt.Errorf("scan credentials by account: %w", err)
		}
		out[key] = n
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials by account: %w", err)
	}
	return out, nil
}

func (r *DashboardCredentialRepository) ByRegionCredentialCounts(ctx context.Context, f m.RegionFilter) (map[string]int64, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT COALESCE(NULLIF(BTRIM(region), ''), 'unknown'), COUNT(*)
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
        GROUP BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID)
	if err != nil {
		return nil, fmt.Errorf("query credentials by region: %w", err)
	}
	defer rows.Close()
	out := make(map[string]int64)
	for rows.Next() {
		var key string
		var n int64
		if err := rows.Scan(&key, &n); err != nil {
			return nil, fmt.Errorf("scan credentials by region: %w", err)
		}
		out[key] = n
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials by region: %w", err)
	}
	return out, nil
}
