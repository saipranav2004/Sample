package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// SummaryIdentityCounts groups ALL scoped catalog rows by status. Deleted
// identities contribute only to the removal card; all other counts use
// deleted_at IS NULL. UTC bounds are passed once by the service.
func (r *DashboardBreakdownRepository) SummaryIdentityCounts(ctx context.Context, f m.SummaryFilter, start, now time.Time) ([]m.SummaryIdentityRow, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') AS identity_status,
               COUNT(*) FILTER (WHERE deleted_at IS NULL) AS current_count,
               COUNT(*) FILTER (WHERE deleted_at IS NULL AND first_seen_at >= $3::timestamptz
                                 AND first_seen_at <= $4::timestamptz) AS new_24h,
               COUNT(*) FILTER (WHERE deleted_at >= $3::timestamptz
                                 AND deleted_at <= $4::timestamptz) AS removed_24h
        FROM nhi_scanner.identities
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($5::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $5::text)
        GROUP BY 1
        ORDER BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, start.UTC(), now.UTC(), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query dashboard summary identities: %w", err)
	}
	defer rows.Close()
	out := make([]m.SummaryIdentityRow, 0)
	for rows.Next() {
		var c m.SummaryIdentityRow
		if err := rows.Scan(&c.Status, &c.CurrentCount, &c.New24h, &c.Removed24h); err != nil {
			return nil, fmt.Errorf("scan dashboard summary identities: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate dashboard summary identities: %w", err)
	}
	return out, nil
}

// SummaryScanData reads real account-scoped scan facts. A completed scan
// counts toward total_accounts_scanned only if it has a scan_end. The most
// recently ended scan (of any status) supplies last_scan_at and scan_status.
// This method is never invoked with region set: scans have no region column.
func (r *DashboardBreakdownRepository) SummaryScanData(ctx context.Context, f m.SummaryFilter) (m.SummaryScanData, error) {
	var out m.SummaryScanData
	if len(f.AllowedAccountIDs) == 0 {
		return out, ErrEmptyAccountScope
	}
	if f.Region != "" {
		return out, fmt.Errorf("scan records do not support a region filter")
	}
	const totalSQL = `
        SELECT COUNT(DISTINCT account_id)
        FROM nhi_scanner.nhi_scans_aws
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND UPPER(BTRIM(status)) = 'COMPLETED'
          AND scan_end IS NOT NULL`
	if err := r.db.QueryRowContext(ctx, totalSQL, pq.Array(f.AllowedAccountIDs), f.AccountID).Scan(&out.CompletedAccountCount); err != nil {
		return out, fmt.Errorf("query completed scanned accounts: %w", err)
	}
	const latestSQL = `
        SELECT scan_end, status
        FROM nhi_scanner.nhi_scans_aws
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND scan_end IS NOT NULL
        ORDER BY scan_end DESC, id DESC LIMIT 1`
	var ended time.Time
	var status sql.NullString
	if err := r.db.QueryRowContext(ctx, latestSQL, pq.Array(f.AllowedAccountIDs), f.AccountID).Scan(&ended, &status); err != nil {
		if err == sql.ErrNoRows {
			return out, nil
		}
		return out, fmt.Errorf("query latest ended scan: %w", err)
	}
	ended = ended.UTC()
	out.LastScanAt = &ended
	if status.Valid && status.String != "" {
		out.ScanStatus = &status.String
	}
	return out, nil
}
