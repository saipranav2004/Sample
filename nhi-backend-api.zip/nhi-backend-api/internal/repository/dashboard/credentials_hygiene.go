package dashboard

import (
	"context"

	m "nhi-backend-api/internal/models/dashboard"
)

// CredentialHygiene deliberately fails closed until the scanner's semantics
// are confirmed for NULL last_used_at, NULL last_rotated_at, IAM role policy
// JSON shapes, privilege threshold, root owner, and public trust. The now-
// confirmed 31-column table supports expiry and tracked-usage measurements,
// but a successful PDF #7 response requires *every* risk card to have a
// reliable classification. Do not turn missing scanner fields into zero.
func (r *DashboardCredentialRepository) CredentialHygiene(_ context.Context, _ m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	return nil, m.ErrCredentialSourceUnavailable
}
