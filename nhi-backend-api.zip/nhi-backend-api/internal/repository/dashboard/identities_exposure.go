package dashboard

import (
	"context"
	"fmt"
	"time"

	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ExposureCounts reads ONLY the current UUID-keyed catalog and computes every
// available card in one query/snapshot. The IaC card cannot be derived from
// the confirmed columns and is deliberately not queried or guessed.
func (r *DashboardBreakdownRepository) ExposureCounts(ctx context.Context, f identitymodels.ExposureFilter, dormantBefore time.Time) ([]identitymodels.ExposureCountRow, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT identity_type,
               COUNT(*) FILTER (WHERE is_publicly_accessible IS TRUE) AS public_count,
               COUNT(*) FILTER (WHERE last_activity_at IS NOT NULL
                                 AND last_activity_at < $3::timestamptz) AS dormant_count,
               COUNT(*) FILTER (WHERE last_activity_at IS NULL) AS no_activity_count,
               COUNT(*) FILTER (WHERE NULLIF(BTRIM(owner), '') IS NULL) AS missing_owner_count,
               COUNT(*) FILTER (WHERE NULLIF(BTRIM(environment), '') IS NULL) AS missing_environment_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
        GROUP BY identity_type
        ORDER BY identity_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, dormantBefore.UTC())
	if err != nil {
		return nil, fmt.Errorf("query identity exposure: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.ExposureCountRow, 0)
	for rows.Next() {
		var c identitymodels.ExposureCountRow
		if err := rows.Scan(&c.IdentityType, &c.PublicCount, &c.DormantCount, &c.NoActivityCount, &c.MissingOwnerCount, &c.MissingEnvCount); err != nil {
			return nil, fmt.Errorf("scan identity exposure: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identity exposure: %w", err)
	}
	return out, nil
}
