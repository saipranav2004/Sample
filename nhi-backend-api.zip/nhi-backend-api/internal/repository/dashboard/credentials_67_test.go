package dashboard

import (
	"context"
	"errors"
	"testing"

	m "nhi-backend-api/internal/models/dashboard"
)

func TestCredentialRepositoryCannotInventMeasurements(t *testing.T) {
	r := NewDashboardCredentialRepository(nil)
	if groups, err := r.CredentialTypeCounts(context.Background(), m.CredentialTypeFilter{AllowedAccountIDs: []string{"123456789012"}}); groups != nil || !errors.Is(err, m.ErrCredentialSourceUnavailable) {
		t.Fatalf("expected unavailable, got %+v %v", groups, err)
	}
	if summary, err := r.CredentialHygiene(context.Background(), m.CredentialHygieneFilter{AllowedAccountIDs: []string{"123456789012"}}); summary != nil || !errors.Is(err, m.ErrCredentialSourceUnavailable) {
		t.Fatalf("expected unavailable, got %+v %v", summary, err)
	}
}
