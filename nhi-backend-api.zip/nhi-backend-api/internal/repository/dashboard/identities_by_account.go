package dashboard

import (
	"context"
	"fmt"

	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByAccountIdentityCounts returns identity-only counts. It must never infer
// credential_count or account_name from identity rows.
func (r *DashboardBreakdownRepository) ByAccountIdentityCounts(ctx context.Context, f identitymodels.AccountFilter) ([]identitymodels.AccountIdentityCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT account_id, COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $2::text)
          AND ($3::text = '' OR identity_type = $3::text)
        GROUP BY account_id
        ORDER BY identity_count DESC, account_id ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.Region, f.IdentityType)
	if err != nil {
		return nil, fmt.Errorf("query by account: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.AccountIdentityCount, 0)
	for rows.Next() {
		var c identitymodels.AccountIdentityCount
		if err := rows.Scan(&c.AccountID, &c.IdentityCount); err != nil {
			return nil, fmt.Errorf("scan by account: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate by account: %w", err)
	}
	return out, nil
}
