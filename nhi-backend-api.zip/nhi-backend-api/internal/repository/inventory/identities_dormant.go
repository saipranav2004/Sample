package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

// Dormant returns current identities with a tracked activity timestamp strictly
// before now-days*24h. NULL activity is untracked, not proof of dormancy.
func (r *Repository) Dormant(ctx context.Context, f m.DormantFilter, now time.Time) (*m.DormantResponse, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	if f.Days < 1 || f.Days > 3650 || f.Page < 1 || f.Page > 1_000_000 || f.Limit < 1 || f.Limit > 200 {
		return nil, fmt.Errorf("invalid dormant bounds")
	}
	cutoff := now.UTC().Add(-time.Duration(f.Days) * 24 * time.Hour)
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin dormant snapshot: %w", err)
	}
	defer tx.Rollback()
	const where = ` FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text)
 AND ($3::text='' OR identity_type=$3::text)
 AND last_activity_at IS NOT NULL AND last_activity_at<$4::timestamptz`
	args := []any{pq.Array(f.AllowedAccountIDs), f.AccountID, f.IdentityType, cutoff}
	out := &m.DormantResponse{ThresholdDays: f.Days, Data: []m.DormantItem{}}
	if err := tx.QueryRowContext(ctx, "SELECT COUNT(*)"+where, args...).Scan(&out.TotalDormant); err != nil {
		return nil, fmt.Errorf("count dormant identities: %w", err)
	}
	query := `SELECT id,name,identity_type,last_activity_at,owner,environment` + where + ` ORDER BY last_activity_at ASC,id ASC LIMIT $5 OFFSET $6`
	rows, err := tx.QueryContext(ctx, query, append(args, f.Limit, (f.Page-1)*f.Limit)...)
	if err != nil {
		return nil, fmt.Errorf("page dormant identities: %w", err)
	}
	for rows.Next() {
		var x m.DormantItem
		var owner, environment sql.NullString
		if err := rows.Scan(&x.ID, &x.Name, &x.IdentityType, &x.LastActivityAt, &owner, &environment); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan dormant identity: %w", err)
		}
		x.Owner = str(owner)
		x.Environment = str(environment)
		out.Data = append(out.Data, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate dormant identities: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close dormant rows: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit dormant snapshot: %w", err)
	}
	return out, nil
}
