package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Attributes(ctx context.Context, id string, ids []string) (*m.AttributesResponse, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const q = `SELECT identity_type,type_attributes FROM nhi_scanner.identities WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	out := &m.AttributesResponse{}
	var attributes []byte
	if err := r.db.QueryRowContext(ctx, q, id, pq.Array(ids)).Scan(&out.IdentityType, &attributes); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped identity attributes: %w", err)
	}
	out.TypeAttributes = raw(attributes)
	return out, nil
}
