package inventory

import (
	"context"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Counts(ctx context.Context, f m.CountsFilter) ([]m.CountRow, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const q = `SELECT COALESCE(NULLIF(LOWER(BTRIM(status)),''),'unknown'),
 COALESCE(NULLIF(BTRIM(identity_type),''),'unknown'),
 COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified'),COUNT(*)
 FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text)
 AND ($3::text='' OR COALESCE(NULLIF(BTRIM(region),''),'unknown')=$3::text)
 AND ($4::text='' OR COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified')=$4::text)
 GROUP BY 1,2,3 ORDER BY 1,2,3`
	rows, err := r.db.QueryContext(ctx, q, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.FunctionalClass)
	if err != nil {
		return nil, fmt.Errorf("query inventory counts: %w", err)
	}
	defer rows.Close()
	out := make([]m.CountRow, 0)
	for rows.Next() {
		var x m.CountRow
		if err := rows.Scan(&x.Status, &x.IdentityType, &x.FunctionalClass, &x.Count); err != nil {
			return nil, fmt.Errorf("scan inventory counts: %w", err)
		}
		out = append(out, x)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate inventory counts: %w", err)
	}
	return out, nil
}
