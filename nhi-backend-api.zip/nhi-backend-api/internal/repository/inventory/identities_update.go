package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	"strings"
)

// Update changes only the three PDF-approved fields and updated_at. UUID,
// current-row rule and trusted account scope are checked in the UPDATE itself;
// a deleted, inaccessible or absent ID is indistinguishable (404).
func (r *Repository) Update(ctx context.Context, id string, ids []string, fields map[string]string) (string, error) {
	if err := scoped(ids); err != nil {
		return "", err
	}
	if r == nil || r.db == nil {
		return "", fmt.Errorf("inventory db unavailable")
	}
	args := []any{id, pq.Array(ids)}
	sets := make([]string, 0, 4)
	for _, column := range []string{"functional_class", "owner", "environment"} {
		if v, ok := fields[column]; ok {
			args = append(args, v)
			sets = append(sets, fmt.Sprintf("%s=$%d", column, len(args)))
		}
	}
	if len(sets) == 0 || len(sets) != len(fields) {
		return "", fmt.Errorf("invalid identity update fields")
	}
	sets = append(sets, "updated_at=now()")
	query := `UPDATE nhi_scanner.identities SET ` + strings.Join(sets, ",") + ` WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL RETURNING id::text`
	var result string
	if err := r.db.QueryRowContext(ctx, query, args...).Scan(&result); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return "", ErrNotFound
		}
		return "", fmt.Errorf("update scoped identity: %w", err)
	}
	return result, nil
}
