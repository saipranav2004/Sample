package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

type Repository struct{ db *sql.DB }

func NewRepository(db *sql.DB) *Repository { return &Repository{db: db} }

var ErrEmptyScope = errors.New("inventory account scope empty")

func scoped(ids []string) error {
	if len(ids) == 0 {
		return ErrEmptyScope
	}
	return nil
}
func str(n sql.NullString) *string {
	if !n.Valid {
		return nil
	}
	x := n.String
	return &x
}
func at(n sql.NullTime) *time.Time {
	if !n.Valid {
		return nil
	}
	x := n.Time.UTC()
	return &x
}
func flag(n sql.NullBool) *bool {
	if !n.Valid {
		return nil
	}
	x := n.Bool
	return &x
}
func raw(b []byte) json.RawMessage {
	if b == nil {
		return json.RawMessage("null")
	}
	return json.RawMessage(b)
}

// Escape user search so '%' and '_' are literal, not unbounded SQL wildcards.
func escapeLike(v string) string {
	v = strings.ReplaceAll(v, `\`, `\\`)
	v = strings.ReplaceAll(v, `%`, `\%`)
	return strings.ReplaceAll(v, `_`, `\_`)
}
func listWhere(f m.ListFilter) (string, []any) {
	args := []any{pq.Array(f.AllowedAccountIDs)}
	where := []string{"deleted_at IS NULL", "account_id = ANY($1::text[])"}
	add := func(expr string, v any) { args = append(args, v); where = append(where, fmt.Sprintf(expr, len(args))) }
	for _, p := range []struct{ expr, v string }{
		{"identity_type = $%d", f.IdentityType},
		{"COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') = $%d", f.FunctionalClass},
		{"account_id = $%d", f.AccountID},
		{"COALESCE(NULLIF(BTRIM(region),''),'unknown') = $%d", f.Region},
		{"COALESCE(NULLIF(LOWER(BTRIM(status)),''),'unknown') = $%d", strings.ToLower(f.Status)},
		{"owner = $%d", f.Owner}, {"environment = $%d", f.Environment},
	} {
		if p.v != "" {
			add(p.expr, p.v)
		}
	}
	if f.IsPublic != nil {
		add("is_publicly_accessible = $%d", *f.IsPublic)
	}
	if f.LastActiveBefore != nil {
		add("last_activity_at < $%d", f.LastActiveBefore.UTC())
	}
	if f.Search != "" {
		add("(name ILIKE $%d ESCAPE '\\' OR arn ILIKE $%[1]d ESCAPE '\\')", "%"+escapeLike(f.Search)+"%")
	}
	return strings.Join(where, " AND "), args
}

var sortColumns = map[string]string{
	"id": "id", "name": "name", "identity_type": "identity_type", "functional_class": "functional_class", "account_id": "account_id", "region": "region", "status": "status", "created_at_aws": "created_at_aws", "last_seen_at": "last_seen_at", "last_activity_at": "last_activity_at",
}

func (r *Repository) List(ctx context.Context, f m.ListFilter) (*m.ListResponse, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	col, ok := sortColumns[f.SortBy]
	if !ok || (f.SortOrder != "asc" && f.SortOrder != "desc") || f.Page < 1 || f.Limit < 1 || f.Limit > 200 || f.Page > 1_000_000 {
		return nil, fmt.Errorf("invalid repository paging/sort")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin inventory snapshot: %w", err)
	}
	defer tx.Rollback()
	where, args := listWhere(f)
	var total int64
	if err := tx.QueryRowContext(ctx, "SELECT COUNT(*) FROM nhi_scanner.identities WHERE "+where, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count inventory identities: %w", err)
	}
	direction := strings.ToUpper(f.SortOrder)
	order := col + " " + direction + " NULLS LAST"
	if col != "id" {
		order += ", id ASC"
	}
	query := `SELECT id,arn,name,identity_type,functional_class,account_id,region,status,created_at_aws,last_seen_at,last_activity_at,owner,environment,is_publicly_accessible,tags
           FROM nhi_scanner.identities WHERE ` + where + ` ORDER BY ` + order + fmt.Sprintf(" LIMIT $%d OFFSET $%d", len(args)+1, len(args)+2)
	args = append(args, f.Limit, (f.Page-1)*f.Limit)
	rows, err := tx.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("list inventory identities: %w", err)
	}
	out := &m.ListResponse{Total: total, Page: f.Page, Limit: f.Limit, Data: []m.IdentitySummary{}}
	for rows.Next() {
		var x m.IdentitySummary
		var cls, owner, env sql.NullString
		var created, activity sql.NullTime
		var public sql.NullBool
		var tags []byte
		if err := rows.Scan(&x.ID, &x.ARN, &x.Name, &x.IdentityType, &cls, &x.AccountID, &x.Region, &x.Status, &created, &x.LastSeenAt, &activity, &owner, &env, &public, &tags); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan inventory list: %w", err)
		}
		x.FunctionalClass = str(cls)
		x.CreatedAtAWS = at(created)
		x.LastActivityAt = at(activity)
		x.Owner = str(owner)
		x.Environment = str(env)
		x.IsPubliclyAccessible = flag(public)
		x.Tags = raw(tags)
		out.Data = append(out.Data, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate inventory list: %w", err)
	}
	rows.Close()
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit inventory snapshot: %w", err)
	}
	return out, nil
}
