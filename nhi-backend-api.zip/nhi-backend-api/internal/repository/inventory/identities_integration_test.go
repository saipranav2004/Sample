package inventory

import (
	"context"
	"database/sql"
	"errors"
	_ "github.com/lib/pq"
	"net/url"
	m "nhi-backend-api/internal/models/inventory"
	"os"
	"strings"
	"testing"
	"time"
)

// DESTRUCTIVE FIXTURE: run ONLY against a disposable database ending _test.
// TEST_INVENTORY_DATABASE_URL=postgres://.../inventory_a1_a6_test?sslmode=disable go test ./internal/repository/inventory -v
func TestInventoryPostgres(t *testing.T) {
	dsn := os.Getenv("TEST_INVENTORY_DATABASE_URL")
	if dsn == "" {
		t.Skip("set a disposable *_test Postgres database URL")
	}
	u, err := url.Parse(dsn)
	if err != nil || !strings.HasSuffix(u.Path, "_test") {
		t.Fatal("integration fixture CREATEs/TRUNCATEs tables: use a disposable *_test database only")
	}
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	ctx := context.Background()
	for _, q := range []string{
		`CREATE SCHEMA IF NOT EXISTS nhi_scanner`,
		`CREATE TABLE IF NOT EXISTS nhi_scanner.identities (
 id uuid PRIMARY KEY,arn text NOT NULL,name text NOT NULL,identity_type text NOT NULL,
 functional_class text,account_id text NOT NULL,region text NOT NULL,status text NOT NULL,
 created_at_aws timestamptz,first_seen_at timestamptz NOT NULL,last_seen_at timestamptz NOT NULL,
 last_activity_at timestamptz,deleted_at timestamptz,vpc_id text,subnet_id text,
 security_group_ids jsonb,is_publicly_accessible boolean,tags jsonb,owner text,environment text,
 parent_arn text,cloudtrail_creator_arn text,discovery_source text NOT NULL,scan_id text,
 type_attributes jsonb,raw_api_response jsonb,created_at timestamptz NOT NULL,updated_at timestamptz NOT NULL)`,
		`TRUNCATE nhi_scanner.identities`,
		`INSERT INTO nhi_scanner.identities(id,arn,name,identity_type,functional_class,account_id,region,status,
 first_seen_at,last_seen_at,last_activity_at,created_at,updated_at,discovery_source,tags,type_attributes,security_group_ids,raw_api_response,deleted_at)
 VALUES
 ('00000000-0000-0000-0000-000000000001','arn:aws:lambda:us-east-1:123456789012:function:live-1','live-1','lambda_function','service','123456789012','us-east-1','active',now()-interval '10 days',now(),now()-interval '1 day',now(),now(),'scanner','{"owner":"team"}'::jsonb,'{"runtime":"go"}'::jsonb,'["sg-123"]'::jsonb,'{"safe":true}'::jsonb,NULL),
 ('00000000-0000-0000-0000-000000000002','arn:aws:lambda:us-east-1:123456789012:function:live-2','live-2','lambda_function',NULL,'123456789012','us-east-1','stopped',now()-interval '11 days',now(),NULL,now(),now(),'scanner',NULL,NULL,NULL,NULL,NULL),
 ('00000000-0000-0000-0000-000000000003','arn:aws:lambda:us-east-1:123456789012:function:deleted','deleted','lambda_function','service','123456789012','us-east-1','active',now()-interval '11 days',now(),NULL,now(),now(),'scanner',NULL,NULL,NULL,NULL,now()),
 ('00000000-0000-0000-0000-000000000004','arn:aws:lambda:us-east-1:234567890123:function:foreign','foreign','lambda_function','service','234567890123','us-east-1','active',now()-interval '11 days',now(),NULL,now(),now(),'scanner',NULL,NULL,NULL,NULL,NULL)`,
		`UPDATE nhi_scanner.identities SET last_activity_at=now()-interval '91 days' WHERE id='00000000-0000-0000-0000-000000000001'`,
	} {
		if _, err := db.ExecContext(ctx, q); err != nil {
			t.Fatalf("fixture %s: %v", q, err)
		}
	}
	r := NewRepository(db)
	scope := m.Scope{AllowedAccountIDs: []string{"123456789012"}}
	f := m.ListFilter{Scope: scope, Page: 1, Limit: 50, SortBy: "name", SortOrder: "asc"}
	list, err := r.List(ctx, f)
	if err != nil || list.Total != 2 || len(list.Data) != 2 || list.Data[0].Name != "live-1" {
		t.Fatalf("list %+v %v", list, err)
	}
	f.Search = "%"
	list, err = r.List(ctx, f)
	if err != nil || list.Total != 0 || len(list.Data) != 0 {
		t.Fatalf("escaped search %+v %v", list, err)
	}
	f.Search = ""
	f.FunctionalClass = "unclassified"
	list, err = r.List(ctx, f)
	if err != nil || list.Total != 1 || list.Data[0].Name != "live-2" {
		t.Fatalf("normalized unclassified filter %+v %v", list, err)
	}
	id1 := "00000000-0000-0000-0000-000000000001"
	detail, err := r.Detail(ctx, id1, scope.AllowedAccountIDs)
	if err != nil || detail.ID != id1 || string(detail.RawAPIResponse) != `{"safe": true}` && string(detail.RawAPIResponse) != `{"safe":true}` {
		t.Fatalf("detail %+v %v", detail, err)
	}
	for _, id := range []string{"00000000-0000-0000-0000-000000000003", "00000000-0000-0000-0000-000000000004"} {
		if _, err := r.Detail(ctx, id, scope.AllowedAccountIDs); !errors.Is(err, ErrNotFound) {
			t.Fatalf("deleted/foreign detail %s: %v", id, err)
		}
		if _, err := r.Attributes(ctx, id, scope.AllowedAccountIDs); !errors.Is(err, ErrNotFound) {
			t.Fatalf("deleted/foreign attributes %s: %v", id, err)
		}
		if _, err := r.Timeline(ctx, id, scope.AllowedAccountIDs); !errors.Is(err, ErrNotFound) {
			t.Fatalf("deleted/foreign timeline %s: %v", id, err)
		}
	}
	counts, err := r.Counts(ctx, m.CountsFilter{Scope: scope})
	if err != nil || len(counts) != 2 {
		t.Fatalf("counts %+v %v", counts, err)
	}
	attrs, err := r.Attributes(ctx, id1, scope.AllowedAccountIDs)
	if err != nil || attrs.IdentityType != "lambda_function" {
		t.Fatalf("attributes %+v %v", attrs, err)
	}
	timeline, err := r.Timeline(ctx, id1, scope.AllowedAccountIDs)
	if err != nil || timeline.ARN == "" || timeline.LastActivityAt == nil || time.Since(timeline.FirstSeenAt) < 0 {
		t.Fatalf("timeline %+v %v", timeline, err)
	}
	groups, err := r.Grouped(ctx, m.GroupFilter{Scope: scope, LimitPerClass: 1})
	if err != nil || len(groups) != 2 || groups[0].Count != 1 {
		t.Fatalf("groups %+v %v", groups, err)
	}
	if _, err := r.List(ctx, m.ListFilter{Page: 1, Limit: 50, SortBy: "name", SortOrder: "asc"}); !errors.Is(err, ErrEmptyScope) {
		t.Fatalf("unscoped list: %v", err)
	}
	// A7 excludes NULL activity, deleted rows and out-of-scope accounts.
	dormant, err := r.Dormant(ctx, m.DormantFilter{Scope: scope, Days: 90, Page: 1, Limit: 50}, time.Now().UTC())
	if err != nil || dormant.TotalDormant != 1 || len(dormant.Data) != 1 || dormant.Data[0].ID != id1 {
		t.Fatalf("dormant %+v %v", dormant, err)
	}
	// A8 downloads all matching current rows (not a single page) and includes
	// the real 28-column JSONB object without exposing a deleted/foreign row.
	f.FunctionalClass = ""
	f.Page, f.Limit = 2, 1 // intentionally ignored for export selection
	exported, err := r.ExportRows(ctx, m.ExportFilter{ListFilter: f, Format: "json"})
	if err != nil || len(exported) != 2 || !strings.Contains(string(exported[0]), `"raw_api_response"`) || strings.Contains(string(exported[0]), `"deleted"`) {
		t.Fatalf("export %d rows %v", len(exported), err)
	}
	if _, err := r.ExportRows(ctx, m.ExportFilter{ListFilter: m.ListFilter{SortBy: "id", SortOrder: "asc"}}); !errors.Is(err, ErrEmptyScope) {
		t.Fatalf("unscoped export: %v", err)
	}
	// A9 applies only allowlisted fields to a current scoped UUID.
	returned, err := r.Update(ctx, id1, scope.AllowedAccountIDs, map[string]string{"functional_class": "break_glass", "owner": "security-team", "environment": "prod"})
	if err != nil || returned != id1 {
		t.Fatalf("update %q: %v", returned, err)
	}
	changed, err := r.Detail(ctx, id1, scope.AllowedAccountIDs)
	if err != nil || changed.FunctionalClass == nil || *changed.FunctionalClass != "break_glass" || changed.Ownership.Owner == nil || *changed.Ownership.Owner != "security-team" {
		t.Fatalf("updated detail %+v %v", changed, err)
	}
	for _, id := range []string{"00000000-0000-0000-0000-000000000003", "00000000-0000-0000-0000-000000000004"} {
		if _, err := r.Update(ctx, id, scope.AllowedAccountIDs, map[string]string{"owner": "unauthorized"}); !errors.Is(err, ErrNotFound) {
			t.Fatalf("deleted/foreign update %s: %v", id, err)
		}
	}
}
