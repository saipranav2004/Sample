package inventory

import (
	"context"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Grouped(ctx context.Context, f m.GroupFilter) ([]m.GroupRow, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.LimitPerClass < 1 || f.LimitPerClass > 100 {
		return nil, fmt.Errorf("invalid per-class limit")
	}
	const q = `WITH ranked AS (
 SELECT COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') AS cls,
 id,name,identity_type,status,
 COUNT(*) OVER(PARTITION BY COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified')) AS group_count,
 ROW_NUMBER() OVER(PARTITION BY COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') ORDER BY name ASC,id ASC) AS rn
 FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text) AND ($3::text='' OR COALESCE(NULLIF(BTRIM(region),''),'unknown')=$3::text)
 ) SELECT cls,group_count,id,name,identity_type,status FROM ranked WHERE rn<=$4::bigint
 ORDER BY group_count DESC,cls ASC,name ASC,id ASC`
	rows, err := r.db.QueryContext(ctx, q, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.LimitPerClass)
	if err != nil {
		return nil, fmt.Errorf("query grouped identities: %w", err)
	}
	defer rows.Close()
	out := make([]m.GroupRow, 0)
	for rows.Next() {
		var x m.GroupRow
		if err := rows.Scan(&x.FunctionalClass, &x.Count, &x.Identity.ID, &x.Identity.Name, &x.Identity.IdentityType, &x.Identity.Status); err != nil {
			return nil, fmt.Errorf("scan grouped identities: %w", err)
		}
		out = append(out, x)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate grouped identities: %w", err)
	}
	return out, nil
}
