package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

var ErrNotFound = errors.New("inventory identity not found")

// Detail always constrains UUID and trusted account scope in SQL. A deleted
// identity is indistinguishable from a missing/inaccessible one (404).
func (r *Repository) Detail(ctx context.Context, id string, ids []string) (*m.DetailResponse, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const query = `SELECT id,arn,name,identity_type,functional_class,account_id,region,status,
 created_at_aws,first_seen_at,last_seen_at,last_activity_at,deleted_at,
 vpc_id,subnet_id,security_group_ids,is_publicly_accessible,tags,owner,environment,
 parent_arn,cloudtrail_creator_arn,discovery_source,scan_id,type_attributes,raw_api_response
 FROM nhi_scanner.identities
 WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	var x m.DetailResponse
	var class, vpc, subnet, owner, env, parent, creator, scan sql.NullString
	var created, activity, deleted sql.NullTime
	var pub sql.NullBool
	var groups, tags, attrs, response []byte
	err := r.db.QueryRowContext(ctx, query, id, pq.Array(ids)).Scan(
		&x.ID, &x.ARN, &x.Name, &x.IdentityType, &class, &x.AccountID, &x.Region, &x.Status,
		&created, &x.FirstSeenAt, &x.LastSeenAt, &activity, &deleted,
		&vpc, &subnet, &groups, &pub, &tags, &owner, &env,
		&parent, &creator, &x.Discovery.DiscoverySource, &scan, &attrs, &response)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped inventory detail: %w", err)
	}
	x.FunctionalClass = str(class)
	x.CreatedAtAWS = at(created)
	x.LastActivityAt = at(activity)
	x.DeletedAt = at(deleted)
	x.Network = m.Network{VPCID: str(vpc), SubnetID: str(subnet), SecurityGroupIDs: raw(groups), IsPubliclyAccessible: flag(pub)}
	x.Ownership = m.Ownership{Owner: str(owner), Environment: str(env), Tags: raw(tags)}
	x.Lineage = m.Lineage{ParentARN: str(parent), CloudTrailCreatorARN: str(creator)}
	x.Discovery.ScanID = str(scan)
	x.TypeAttributes = raw(attrs)
	x.RawAPIResponse = raw(response)
	return &x, nil
}
