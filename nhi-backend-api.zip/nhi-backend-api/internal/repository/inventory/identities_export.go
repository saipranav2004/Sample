package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
)

var ErrExportTooLarge = m.ErrExportTooLarge

const MaxExportRows = 50000
const MaxExportBytes = 50 << 20

// ExportRows reads ALL filtered current identities (not just the selected A1
// page) up to a hard safety cap, including all actual database columns via
// to_jsonb(i). Only SQL allowlisted ordering and bound filters are used.
func (r *Repository) ExportRows(ctx context.Context, f m.ExportFilter) ([]json.RawMessage, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	col, ok := sortColumns[f.SortBy]
	if !ok || (f.SortOrder != "asc" && f.SortOrder != "desc") {
		return nil, fmt.Errorf("invalid export sort")
	}
	where, args := listWhere(f.ListFilter)
	order := col + " " + strings.ToUpper(f.SortOrder) + " NULLS LAST"
	if col != "id" {
		order += ", id ASC"
	}
	query := `SELECT to_jsonb(i) FROM nhi_scanner.identities AS i WHERE ` + where + ` ORDER BY ` + order + fmt.Sprintf(" LIMIT $%d", len(args)+1)
	rows, err := r.db.QueryContext(ctx, query, append(args, MaxExportRows+1)...)
	if err != nil {
		return nil, fmt.Errorf("query inventory export: %w", err)
	}
	defer rows.Close()
	result := make([]json.RawMessage, 0)
	totalBytes := 0
	for rows.Next() {
		var b []byte
		if err := rows.Scan(&b); err != nil {
			return nil, fmt.Errorf("scan inventory export: %w", err)
		}
		if len(result) >= MaxExportRows || len(b) > MaxExportBytes-totalBytes {
			return nil, ErrExportTooLarge
		}
		totalBytes += len(b)
		result = append(result, json.RawMessage(b))
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate inventory export: %w", err)
	}
	return result, nil
}
