package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Timeline(ctx context.Context, id string, ids []string) (*m.TimelineRecord, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const q = `SELECT arn,first_seen_at,last_seen_at,last_activity_at FROM nhi_scanner.identities WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	out := &m.TimelineRecord{}
	var activity sql.NullTime
	if err := r.db.QueryRowContext(ctx, q, id, pq.Array(ids)).Scan(&out.ARN, &out.FirstSeenAt, &out.LastSeenAt, &activity); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped identity timeline: %w", err)
	}
	out.LastActivityAt = at(activity)
	return out, nil
}
