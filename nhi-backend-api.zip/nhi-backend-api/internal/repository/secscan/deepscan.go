package secscan

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	m "nhi-backend-api/internal/models/secscan"
)

// DeepScan returns the most recent deep-scan record for one repository, or
// nil when none was ever requested. A client lives on one platform, but both
// tables are read so the caller does not have to know which.
func (r *Repository) DeepScan(ctx context.Context, clientID, repository string) (*m.DeepScan, error) {
	if err := r.ready(); err != nil {
		return nil, err
	}
	cc, gh := platformTables[m.PlatformCodeCommit].deepscan, platformTables[m.PlatformGitHub].deepscan
	query := fmt.Sprintf(`SELECT * FROM (
	    SELECT client_id, repo_key, '%s' AS platform, requested_at, completed_at,
	        commits_scanned, findings, failed_at, error
	    FROM %s WHERE client_id = $1 AND repo_key = $2
	    UNION ALL
	    SELECT client_id, repo_key, '%s' AS platform, requested_at, completed_at,
	        commits_scanned, findings, failed_at, error
	    FROM %s WHERE client_id = $1 AND repo_key = $2
	) AS scans ORDER BY requested_at DESC, platform ASC LIMIT 1`,
		m.PlatformCodeCommit, cc, m.PlatformGitHub, gh)

	var (
		d                         m.DeepScan
		completedAt, failedAt, er sql.NullString
		commits, findings         sql.NullInt64
	)
	err := r.db.QueryRowContext(ctx, query, clientID, repository).Scan(
		&d.ClientID, &d.RepoKey, &d.Platform, &d.RequestedAt, &completedAt,
		&commits, &findings, &failedAt, &er)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, unavailable(fmt.Errorf("query deep scan: %w", err))
	}
	d.CompletedAt = nullString(completedAt)
	d.CommitsScanned = nullInt(commits)
	d.Findings = nullInt(findings)
	d.FailedAt = nullString(failedAt)
	d.Error = nullString(er)
	d.Status = m.DeepScanStatus(d.CompletedAt, d.FailedAt)
	return &d, nil
}
