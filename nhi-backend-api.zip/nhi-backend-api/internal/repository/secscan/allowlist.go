package secscan

import (
	"context"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/secscan"
)

// ListAllowlist returns the entries of all three allowlists, newest first.
// Each entry carries its source, because only dashboard entries are ours to
// remove: the platform lists belong to the scanner stacks.
func (r *Repository) ListAllowlist(ctx context.Context, clientID string) ([]m.AllowlistEntry, error) {
	if err := r.ready(); err != nil {
		return nil, err
	}
	sources := []struct{ source, table string }{
		{m.SourceDashboard, dashboardAllowlist},
		{m.SourceCodeCommit, platformTables[m.PlatformCodeCommit].allowlist},
		{m.SourceGitHub, platformTables[m.PlatformGitHub].allowlist},
	}
	parts := make([]string, 0, len(sources))
	for _, s := range sources {
		parts = append(parts, fmt.Sprintf(`SELECT client_id, file_path, detector, redacted,
	    reason, dismissed_by, dismissed_at, '%s' AS source
	    FROM %s WHERE ($1::text = '' OR client_id = $1::text)`, s.source, s.table))
	}
	query := "SELECT * FROM (" + strings.Join(parts, "\nUNION ALL\n") +
		") AS entries ORDER BY dismissed_at DESC, source ASC, client_id ASC, file_path ASC, detector ASC, redacted ASC"

	rows, err := r.db.QueryContext(ctx, query, clientID)
	if err != nil {
		return nil, unavailable(fmt.Errorf("query allowlist: %w", err))
	}
	defer rows.Close()
	out := make([]m.AllowlistEntry, 0)
	for rows.Next() {
		var e m.AllowlistEntry
		if err := rows.Scan(&e.ClientID, &e.FilePath, &e.Detector, &e.Redacted,
			&e.Reason, &e.DismissedBy, &e.DismissedAt, &e.Source); err != nil {
			return nil, fmt.Errorf("scan allowlist entry: %w", err)
		}
		out = append(out, e)
	}
	if err := rows.Err(); err != nil {
		return nil, unavailable(fmt.Errorf("iterate allowlist: %w", err))
	}
	return out, nil
}

// UpsertDashboardEntry adds or refreshes one entry in the dashboard
// allowlist. Marking the same finding safe again updates the reason, the
// reviewer and the time instead of failing.
func (r *Repository) UpsertDashboardEntry(ctx context.Context, e m.AllowlistEntry) (m.AllowlistEntry, error) {
	if err := r.ready(); err != nil {
		return m.AllowlistEntry{}, err
	}
	query := `INSERT INTO ` + dashboardAllowlist + ` AS d
	    (client_id, file_path, detector, redacted, reason, dismissed_by, dismissed_at)
	    VALUES ($1, $2, $3, $4, $5, $6, $7)
	    ON CONFLICT (client_id, file_path, detector, redacted) DO UPDATE
	    SET reason = EXCLUDED.reason, dismissed_by = EXCLUDED.dismissed_by,
	        dismissed_at = EXCLUDED.dismissed_at
	    RETURNING d.client_id, d.file_path, d.detector, d.redacted,
	        d.reason, d.dismissed_by, d.dismissed_at`
	var out m.AllowlistEntry
	err := r.db.QueryRowContext(ctx, query, e.ClientID, e.FilePath, e.Detector, e.Redacted,
		e.Reason, e.DismissedBy, e.DismissedAt).
		Scan(&out.ClientID, &out.FilePath, &out.Detector, &out.Redacted,
			&out.Reason, &out.DismissedBy, &out.DismissedAt)
	if err != nil {
		return m.AllowlistEntry{}, unavailable(fmt.Errorf("upsert allowlist entry: %w", err))
	}
	out.Source = m.SourceDashboard
	return out, nil
}

// DeleteDashboardEntry removes one dashboard allowlist entry. It reports
// whether a row was removed; nothing matching is not an error.
func (r *Repository) DeleteDashboardEntry(ctx context.Context, k m.AllowlistKey) (bool, error) {
	if err := r.ready(); err != nil {
		return false, err
	}
	query := `DELETE FROM ` + dashboardAllowlist + `
	    WHERE client_id = $1 AND file_path = $2 AND detector = $3 AND redacted = $4`
	res, err := r.db.ExecContext(ctx, query, k.ClientID, k.FilePath, k.Detector, k.Redacted)
	if err != nil {
		return false, unavailable(fmt.Errorf("delete allowlist entry: %w", err))
	}
	n, err := res.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("allowlist rows affected: %w", err)
	}
	return n > 0, nil
}
