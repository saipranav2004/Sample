package secscan

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	m "nhi-backend-api/internal/models/secscan"
)

// findingColumns is the explicit column list read from both findings tables.
// platform is not read from the row: it is stamped from the table the row
// came from, because older rows carry platform NULL.
const findingColumns = `f.finding_id, f.client_id, f.repository, f.branch, f.commit_id, f.author,
	f.created_at, f.detector, f.severity, f.file_path, f.line_number, f.redacted,
	f.verification_status, f.risk_tier, f.recommended_action, f.codecommit_uri,
	f.github_uri, f.line_preview, f.confidence, f.category, f.committer,
	f.commit_message, f.commit_authored_at, f.files_changed, f.additions, f.deletions,
	f.repo_visibility, f.repo_stars, f.repo_forks, f.repo_pushed_at,
	f.ml_score, f.ml_decision, f.ml_model_version,
	f.analyst_decision, f.analyst_decided_at, f.analyst_decided_by`

// visibleFindingsSQL builds one SELECT per platform: the platform's findings
// minus anything on that platform's own allowlist or the shared dashboard
// allowlist, matched on all four key columns exactly.
func visibleFindingsSQL(platform string) string {
	t := platformTables[platform]
	return fmt.Sprintf(`SELECT %s, '%s' AS platform
	FROM %s f
	WHERE ($1::text = '' OR f.client_id = $1::text)
	  AND NOT EXISTS (SELECT 1 FROM %s a
	      WHERE a.client_id = f.client_id AND a.file_path = f.file_path
	        AND a.detector = f.detector AND a.redacted = f.redacted)
	  AND NOT EXISTS (SELECT 1 FROM %s d
	      WHERE d.client_id = f.client_id AND d.file_path = f.file_path
	        AND d.detector = f.detector AND d.redacted = f.redacted)`,
		findingColumns, platform, t.findings, t.allowlist, dashboardAllowlist)
}

// ListFindings returns every visible finding, newest first. Both platforms
// are read in one statement, so the result is one consistent snapshot.
func (r *Repository) ListFindings(ctx context.Context, f m.FindingsFilter) ([]m.Finding, error) {
	if err := r.ready(); err != nil {
		return nil, err
	}
	parts := make([]string, 0, len(platformOrder))
	for _, p := range platformOrder {
		if f.Platform == "" || f.Platform == p {
			parts = append(parts, visibleFindingsSQL(p))
		}
	}
	if len(parts) == 0 {
		return []m.Finding{}, nil
	}
	// created_at is ISO-8601 text in UTC; text order is time order for it.
	// platform and finding_id break ties so paging the list is stable.
	query := "SELECT * FROM (" + strings.Join(parts, "\nUNION ALL\n") +
		") AS visible ORDER BY created_at DESC, platform ASC, finding_id ASC"

	rows, err := r.db.QueryContext(ctx, query, f.ClientID)
	if err != nil {
		return nil, unavailable(fmt.Errorf("query findings: %w", err))
	}
	defer rows.Close()

	out := make([]m.Finding, 0)
	for rows.Next() {
		finding, err := scanFinding(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, finding)
	}
	if err := rows.Err(); err != nil {
		return nil, unavailable(fmt.Errorf("iterate findings: %w", err))
	}
	return out, nil
}

func scanFinding(rows *sql.Rows) (m.Finding, error) {
	var (
		f                                                    m.Finding
		codecommitURI, githubURI, preview, confidence        sql.NullString
		category, committer, message, authoredAt, visibility sql.NullString
		pushedAt, mlDecision, mlVersion                      sql.NullString
		analystDecision, analystAt, analystBy                sql.NullString
		filesChanged, additions, deletions, stars, forks     sql.NullInt64
		mlScore                                              sql.NullFloat64
	)
	if err := rows.Scan(
		&f.FindingID, &f.ClientID, &f.Repository, &f.Branch, &f.CommitID, &f.Author,
		&f.CreatedAt, &f.Detector, &f.Severity, &f.FilePath, &f.LineNumber, &f.Redacted,
		&f.VerificationStatus, &f.RiskTier, &f.RecommendedAction, &codecommitURI,
		&githubURI, &preview, &confidence, &category, &committer,
		&message, &authoredAt, &filesChanged, &additions, &deletions,
		&visibility, &stars, &forks, &pushedAt,
		&mlScore, &mlDecision, &mlVersion,
		&analystDecision, &analystAt, &analystBy,
		&f.Platform,
	); err != nil {
		return m.Finding{}, fmt.Errorf("scan finding: %w", err)
	}
	f.CodeCommitURI = nullString(codecommitURI)
	f.GitHubURI = nullString(githubURI)
	f.LinePreview = nullString(preview)
	f.Confidence = nullString(confidence)
	f.Category = nullString(category)
	f.Committer = nullString(committer)
	f.CommitMessage = nullString(message)
	f.CommitAuthoredAt = nullString(authoredAt)
	f.FilesChanged = nullInt(filesChanged)
	f.Additions = nullInt(additions)
	f.Deletions = nullInt(deletions)
	f.RepoVisibility = nullString(visibility)
	f.RepoStars = nullInt(stars)
	f.RepoForks = nullInt(forks)
	f.RepoPushedAt = nullString(pushedAt)
	f.MLScore = nullFloat(mlScore)
	f.MLDecision = nullString(mlDecision)
	f.MLModelVersion = nullString(mlVersion)
	f.AnalystDecision = nullString(analystDecision)
	f.AnalystDecidedAt = nullString(analystAt)
	f.AnalystDecidedBy = nullString(analystBy)
	return f, nil
}

// FindingKeyExists reports whether any finding, on either platform, has this
// allowlist key - so an entry can only be created for a secret that was found.
func (r *Repository) FindingKeyExists(ctx context.Context, k m.AllowlistKey) (bool, error) {
	if err := r.ready(); err != nil {
		return false, err
	}
	query := fmt.Sprintf(`SELECT EXISTS (SELECT 1 FROM %s
	      WHERE client_id = $1 AND file_path = $2 AND detector = $3 AND redacted = $4)
	   OR EXISTS (SELECT 1 FROM %s
	      WHERE client_id = $1 AND file_path = $2 AND detector = $3 AND redacted = $4)`,
		platformTables[m.PlatformCodeCommit].findings, platformTables[m.PlatformGitHub].findings)
	var exists bool
	if err := r.db.QueryRowContext(ctx, query, k.ClientID, k.FilePath, k.Detector, k.Redacted).Scan(&exists); err != nil {
		return false, unavailable(fmt.Errorf("check finding key: %w", err))
	}
	return exists, nil
}

// SetDecision records a human's verdict on one finding. It writes only the
// three analyst_* columns: the ML opinion and the liveness check stay as the
// scanner left them. Returns ErrNotFound when no such finding exists.
func (r *Repository) SetDecision(ctx context.Context, platform, findingID, decision, decidedAt, decidedBy string) error {
	if err := r.ready(); err != nil {
		return err
	}
	t, ok := platformTables[platform]
	if !ok {
		return m.ErrNotFound
	}
	query := fmt.Sprintf(`UPDATE %s
	    SET analyst_decision = $2, analyst_decided_at = $3, analyst_decided_by = $4
	    WHERE finding_id = $1`, t.findings)
	res, err := r.db.ExecContext(ctx, query, findingID, decision, decidedAt, decidedBy)
	if err != nil {
		return unavailable(fmt.Errorf("update decision: %w", err))
	}
	n, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("decision rows affected: %w", err)
	}
	if n == 0 {
		return m.ErrNotFound
	}
	return nil
}
