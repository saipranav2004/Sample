// Package secscan reads and writes the secret scanner's tables in the
// nhi_scanner schema. The scanner runs as two independent stacks, CodeCommit
// and GitHub, and each writes its own copy of every table:
//
//	secscan_findings_<platform>   one row per detected secret
//	secscan_allowlist_<platform>  the stack's own "mark as safe" entries
//	secscan_deepscan_<platform>   on-demand full-history scan status
//
// plus secscan_allowlist_dashboard, the shared "mark as safe" list that this
// API writes to. Table names only ever come from the fixed map below - never
// from a request - and every value is a bound parameter.
package secscan

import (
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"

	m "nhi-backend-api/internal/models/secscan"
)

type tables struct{ findings, allowlist, deepscan string }

var platformTables = map[string]tables{
	m.PlatformCodeCommit: {
		findings:  "nhi_scanner.secscan_findings_codecommit",
		allowlist: "nhi_scanner.secscan_allowlist_codecommit",
		deepscan:  "nhi_scanner.secscan_deepscan_codecommit",
	},
	m.PlatformGitHub: {
		findings:  "nhi_scanner.secscan_findings_github",
		allowlist: "nhi_scanner.secscan_allowlist_github",
		deepscan:  "nhi_scanner.secscan_deepscan_github",
	},
}

// platformOrder fixes the UNION order so results are deterministic.
var platformOrder = []string{m.PlatformCodeCommit, m.PlatformGitHub}

const dashboardAllowlist = "nhi_scanner.secscan_allowlist_dashboard"

// Repository is the data access for the secret-scanner tables.
type Repository struct{ db *sql.DB }

func NewRepository(db *sql.DB) *Repository { return &Repository{db: db} }

func (r *Repository) ready() error {
	if r == nil || r.db == nil {
		return m.ErrSourceUnavailable
	}
	return nil
}

// unavailable maps "the scanner tables are not there or not readable" to
// ErrSourceUnavailable, so the handler answers 503 instead of 500.
func unavailable(err error) error {
	var pg *pq.Error
	if errors.As(err, &pg) {
		code := string(pg.Code)
		switch {
		case code == "42P01", code == "42703", code == "42501", code == "3F000",
			code == "53300", code == "57P01", len(code) >= 2 && code[:2] == "08":
			return fmt.Errorf("%w: sqlstate %s", m.ErrSourceUnavailable, code)
		}
	}
	return err
}

func nullString(v sql.NullString) *string {
	if !v.Valid {
		return nil
	}
	s := v.String
	return &s
}

func nullInt(v sql.NullInt64) *int64 {
	if !v.Valid {
		return nil
	}
	n := v.Int64
	return &n
}

func nullFloat(v sql.NullFloat64) *float64 {
	if !v.Valid {
		return nil
	}
	f := v.Float64
	return &f
}
