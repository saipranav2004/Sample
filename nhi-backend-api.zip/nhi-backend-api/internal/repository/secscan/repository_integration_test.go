package secscan

import (
	"context"
	"database/sql"
	"net/url"
	"os"
	"strings"
	"testing"

	m "nhi-backend-api/internal/models/secscan"
)

// Runs against a disposable PostgreSQL only:
//
//	TEST_DATABASE_URL='postgres://user@localhost:5432/secscan_test?sslmode=disable' \
//	    go test ./internal/repository/secscan -count=1 -v
//
// The test DROPS and recreates the nhi_scanner.secscan_* tables, so it refuses
// any database whose name does not end in "_test".
func testDB(t *testing.T) *sql.DB {
	t.Helper()
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("TEST_DATABASE_URL not set")
	}
	u, err := url.Parse(dsn)
	if err != nil || !strings.HasSuffix(strings.TrimPrefix(u.Path, "/"), "_test") {
		t.Fatal("refusing to run: the database name must end in _test")
	}
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { db.Close() })
	ddl, err := os.ReadFile("../../../docs/secscan_schema_reference.sql")
	if err != nil {
		t.Fatal(err)
	}
	for _, stmt := range []string{
		`DROP TABLE IF EXISTS nhi_scanner.secscan_findings_codecommit, nhi_scanner.secscan_findings_github,
		    nhi_scanner.secscan_allowlist_codecommit, nhi_scanner.secscan_allowlist_github,
		    nhi_scanner.secscan_allowlist_dashboard, nhi_scanner.secscan_deepscan_codecommit,
		    nhi_scanner.secscan_deepscan_github`,
		string(ddl),
	} {
		if _, err := db.Exec(stmt); err != nil {
			t.Fatal(err)
		}
	}
	return db
}

func insertFinding(t *testing.T, db *sql.DB, platform string, cols map[string]interface{}) {
	t.Helper()
	base := map[string]interface{}{
		"branch": "main", "commit_id": "abc", "author": "A <a@x>", "severity": "high",
		"line_number": 3, "verification_status": "UNSUPPORTED", "risk_tier": "HIGH",
		"recommended_action": "PAGE_ON_CALL",
	}
	for k, v := range cols {
		base[k] = v
	}
	names, holders, args := []string{}, []string{}, []interface{}{}
	for k, v := range base {
		names = append(names, k)
		args = append(args, v)
		holders = append(holders, "$"+itoa(len(args)))
	}
	q := "INSERT INTO nhi_scanner.secscan_findings_" + platform + " (" + strings.Join(names, ",") + ") VALUES (" + strings.Join(holders, ",") + ")"
	if _, err := db.Exec(q, args...); err != nil {
		t.Fatal(err)
	}
}

func itoa(n int) string {
	if n < 10 {
		return string(rune('0' + n))
	}
	return itoa(n/10) + string(rune('0'+n%10))
}

func TestSecscanRepositoryAgainstPostgres(t *testing.T) {
	db := testDB(t)
	repo := NewRepository(db)
	ctx := context.Background()

	// CodeCommit: one legacy row with platform NULL and null enrichment, one
	// row hidden by the CodeCommit stack's own allowlist.
	insertFinding(t, db, "codecommit", map[string]interface{}{
		"finding_id": "cc/old", "client_id": "cc-client", "repository": "test-sample",
		"created_at": "2026-09-18T12:17:39+00:00", "detector": "aws_access_key_id",
		"file_path": "config.py", "redacted": "AKIA****0001",
	})
	insertFinding(t, db, "codecommit", map[string]interface{}{
		"finding_id": "cc/hidden", "client_id": "cc-client", "repository": "test-sample",
		"created_at": "2026-09-20T00:00:00+00:00", "detector": "slack_webhook",
		"file_path": "hook.py", "redacted": "https://hooks****", "platform": "codecommit",
	})
	if _, err := db.Exec(`INSERT INTO nhi_scanner.secscan_allowlist_codecommit
	    (client_id, file_path, detector, redacted, dismissed_at)
	    VALUES ('cc-client','hook.py','slack_webhook','https://hooks****','2026-09-21T00:00:00+00:00')`); err != nil {
		t.Fatal(err)
	}
	// GitHub: the newest row, fully enriched; plus one that will be dismissed.
	insertFinding(t, db, "github", map[string]interface{}{
		"finding_id": "gh/new", "client_id": "gh-client", "repository": "owner/repo",
		"created_at": "2026-09-23T11:36:56+00:00", "detector": "stripe_key", "file_path": "settings.py",
		"redacted": "sk_t****kR6t", "platform": "github", "github_uri": "https://github.com/owner/repo/blob/abc/settings.py#L3",
		"repo_stars": 0, "additions": 17, "ml_score": 0.93, "repo_visibility": "public",
	})
	insertFinding(t, db, "github", map[string]interface{}{
		"finding_id": "gh/dismiss", "client_id": "gh-client", "repository": "owner/repo",
		"created_at": "2026-09-22T00:00:00+00:00", "detector": "jwt", "file_path": "a.py", "redacted": "eyJ****",
	})

	all, err := repo.ListFindings(ctx, m.FindingsFilter{})
	if err != nil {
		t.Fatal(err)
	}
	ids := []string{}
	for _, f := range all {
		ids = append(ids, f.FindingID+"@"+f.Platform)
	}
	if strings.Join(ids, ",") != "gh/new@github,gh/dismiss@github,cc/old@codecommit" {
		t.Fatalf("visible findings, newest first, platform from the table: %v", ids)
	}
	gh, old := all[0], all[2]
	if gh.RepoStars == nil || *gh.RepoStars != 0 || gh.MLScore == nil || *gh.MLScore != 0.93 || gh.CodeCommitURI != nil {
		t.Fatalf("zero must stay zero and null stay null: %+v", gh)
	}
	if old.Platform != "codecommit" || old.LinePreview != nil || old.FilesChanged != nil || old.MLScore != nil {
		t.Fatalf("legacy row must keep nulls and get its platform from the table: %+v", old)
	}

	byPlatform, _ := repo.ListFindings(ctx, m.FindingsFilter{Platform: "codecommit"})
	byClient, _ := repo.ListFindings(ctx, m.FindingsFilter{ClientID: "gh-client"})
	if len(byPlatform) != 1 || len(byClient) != 2 {
		t.Fatalf("filters: platform=%d client=%d", len(byPlatform), len(byClient))
	}

	// Dismiss through the dashboard allowlist hides it; doing it twice updates.
	key := m.AllowlistKey{ClientID: "gh-client", FilePath: "a.py", Detector: "jwt", Redacted: "eyJ****"}
	if ok, _ := repo.FindingKeyExists(ctx, key); !ok {
		t.Fatal("the finding's key must exist")
	}
	if ok, _ := repo.FindingKeyExists(ctx, m.AllowlistKey{ClientID: "x", FilePath: "a.py", Detector: "jwt", Redacted: "eyJ****"}); ok {
		t.Fatal("a key from another client must not exist")
	}
	entry := m.AllowlistEntry{ClientID: key.ClientID, FilePath: key.FilePath, Detector: key.Detector, Redacted: key.Redacted,
		Reason: "test fixture", DismissedBy: "a@x", DismissedAt: "2026-09-24T00:00:00+00:00"}
	if _, err := repo.UpsertDashboardEntry(ctx, entry); err != nil {
		t.Fatal(err)
	}
	entry.Reason, entry.DismissedAt = "rotated", "2026-09-25T00:00:00+00:00"
	saved, err := repo.UpsertDashboardEntry(ctx, entry)
	if err != nil || saved.Reason != "rotated" || saved.Source != "dashboard" {
		t.Fatalf("re-dismiss must update: %+v %v", saved, err)
	}
	visible, _ := repo.ListFindings(ctx, m.FindingsFilter{})
	if len(visible) != 2 {
		t.Fatalf("dismissed finding must be hidden, got %d", len(visible))
	}

	entries, err := repo.ListAllowlist(ctx, "")
	if err != nil || len(entries) != 2 || entries[0].Source != "dashboard" || entries[1].Source != "codecommit" {
		t.Fatalf("allowlist from all sources, newest first: %+v %v", entries, err)
	}
	if only, _ := repo.ListAllowlist(ctx, "cc-client"); len(only) != 1 {
		t.Fatalf("client filter: %d", len(only))
	}

	if removed, _ := repo.DeleteDashboardEntry(ctx, key); !removed {
		t.Fatal("restore must remove the dashboard row")
	}
	if removed, _ := repo.DeleteDashboardEntry(ctx, key); removed {
		t.Fatal("a second restore matches nothing")
	}
	// A platform-owned entry is never removed by the dashboard delete.
	if removed, _ := repo.DeleteDashboardEntry(ctx, m.AllowlistKey{ClientID: "cc-client", FilePath: "hook.py", Detector: "slack_webhook", Redacted: "https://hooks****"}); removed {
		t.Fatal("platform allowlists are not ours to change")
	}
	if visible, _ := repo.ListFindings(ctx, m.FindingsFilter{}); len(visible) != 3 {
		t.Fatalf("restored finding must reappear, got %d", len(visible))
	}

	// Decisions touch only the analyst columns of the right table.
	if err := repo.SetDecision(ctx, "github", "gh/new", "real_secret", "2026-09-26T00:00:00+00:00", "a@x"); err != nil {
		t.Fatal(err)
	}
	if err := repo.SetDecision(ctx, "codecommit", "gh/new", "real_secret", "t", "a"); err != m.ErrNotFound {
		t.Fatalf("a GitHub id in the CodeCommit table is not found, got %v", err)
	}
	after, _ := repo.ListFindings(ctx, m.FindingsFilter{ClientID: "gh-client"})
	if after[0].AnalystDecision == nil || *after[0].AnalystDecision != "real_secret" || after[0].MLScore == nil {
		t.Fatalf("decision stored, ML untouched: %+v", after[0])
	}

	// Deep-scan status.
	if scan, err := repo.DeepScan(ctx, "gh-client", "owner/repo"); err != nil || scan != nil {
		t.Fatalf("never requested: %+v %v", scan, err)
	}
	if _, err := db.Exec(`INSERT INTO nhi_scanner.secscan_deepscan_github
	    (client_id, repo_key, platform, requested_at, completed_at, commits_scanned, findings)
	    VALUES ('gh-client','owner/repo','github','2026-09-22T10:15:03+00:00','2026-09-22T10:19:47+00:00',5000,3)`); err != nil {
		t.Fatal(err)
	}
	scan, err := repo.DeepScan(ctx, "gh-client", "owner/repo")
	if err != nil || scan.Status != "complete" || *scan.CommitsScanned != 5000 || scan.Error != nil || scan.Platform != "github" {
		t.Fatalf("complete scan: %+v %v", scan, err)
	}
	if _, err := db.Exec(`INSERT INTO nhi_scanner.secscan_deepscan_codecommit
	    (client_id, repo_key, platform, requested_at, failed_at, error)
	    VALUES ('cc-client','test-sample','codecommit','2026-09-22T10:15:03+00:00','2026-09-22T10:15:17+00:00','AccessDenied')`); err != nil {
		t.Fatal(err)
	}
	if scan, _ := repo.DeepScan(ctx, "cc-client", "test-sample"); scan.Status != "failed" || *scan.Error != "AccessDenied" {
		t.Fatalf("failed scan: %+v", scan)
	}
}

func TestSecscanRepositoryReportsMissingTablesAsUnavailable(t *testing.T) {
	db := testDB(t)
	if _, err := db.Exec(`DROP TABLE nhi_scanner.secscan_findings_github`); err != nil {
		t.Fatal(err)
	}
	_, err := NewRepository(db).ListFindings(context.Background(), m.FindingsFilter{})
	if err == nil || !strings.Contains(err.Error(), m.ErrSourceUnavailable.Error()) {
		t.Fatalf("missing table must be ErrSourceUnavailable, got %v", err)
	}
}
