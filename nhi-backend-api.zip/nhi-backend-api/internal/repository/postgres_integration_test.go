package repository

import (
	"context"
	"database/sql"
	"errors"
	"net/url"
	"os"
	"strings"
	"testing"

	_ "github.com/lib/pq"
)

// Run against a disposable database after applying docs/scanner_schema_reference.sql
// and migrations/001_create_users.sql: TEST_DATABASE_URL=postgres://... go test ./internal/repository -v
func TestPostgresRepositories(t *testing.T) {
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("set TEST_DATABASE_URL for PostgreSQL integration test")
	}
	parsed, err := url.Parse(dsn)
	if err != nil || !strings.HasSuffix(parsed.Path, "_test") {
		t.Fatal("integration test TRUNCATES tables: database name must end in _test")
	}
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	ctx := context.Background()
	for _, q := range []string{
		"ALTER TABLE nhi_scanner.nhi_events_aws DROP COLUMN IF EXISTS caller_arn, DROP COLUMN IF EXISTS caller_type",
		"TRUNCATE nhi_scanner.nhi_users, nhi_scanner.nhi_scans_aws, nhi_scanner.nhi_identities_aws, nhi_scanner.nhi_events_aws, nhi_scanner.nhi_lineage_aws RESTART IDENTITY",
		`INSERT INTO nhi_scanner.nhi_users(email,password,full_name,team,role) VALUES ('user@example.com','bcrypt-hash','User','team','admin')`,
		`INSERT INTO nhi_scanner.nhi_scans_aws(scan_id,account_id,target_name,status,scan_end) VALUES ('old','123','aws','COMPLETED','2024-01-01T00:00:00Z'),('new','123','aws','COMPLETED','2026-01-01T00:00:00Z')`,
		`INSERT INTO nhi_scanner.nhi_identities_aws(scan_id,arn,name,identity_type,classification,is_admin,is_secret,owned_credentials,mfa_enabled,last_active) VALUES
            ('new','arn:aws:iam::123:role/app','app','IAM_ROLE','NHI_CICD',1,0,'[{"type":"ACCESS_KEY","id":"key-1","severity":"HIGH"}]',0,'2026-01-02T00:00:00Z'),
            ('old','arn:aws:iam::123:role/old','old','IAM_ROLE','NHI_CICD',0,0,'[]',0,'2024-01-02T00:00:00Z')`,
		`INSERT INTO nhi_scanner.nhi_events_aws(scan_id,identity_arn,event_time,event_name,source_ip) VALUES
            ('new','arn:aws:iam::123:role/app','2026-01-03T00:00:00Z','AssumeRole','1.2.3.4'),
            ('new','arn:aws:iam::123:role/app','2026-01-04T00:00:00Z','AssumeRole','1.2.3.4'),
            ('old','arn:aws:iam::123:role/app','2024-01-03T00:00:00Z','AssumeRole','5.6.7.8')`,
		`INSERT INTO nhi_scanner.nhi_lineage_aws(scan_id,source_arn,target_name,is_external) VALUES ('new','arn:aws:iam::123:role/app','S3',1)`,
	} {
		if _, err := db.ExecContext(ctx, q); err != nil {
			t.Fatalf("fixture %s: %v", q, err)
		}
	}
	r := &PostgresDB{DB: db}
	user, err := NewUserRepository(r).GetByEmail(ctx, "USER@EXAMPLE.COM")
	if err != nil || user == nil || user.Email != "user@example.com" {
		t.Fatalf("user: %+v %v", user, err)
	}
	scanList, n, err := NewScanRepository(r).List(ctx, 0, 10)
	if err != nil || n != 2 || scanList[0].ScanID != "new" || scanList[0].ScanStart != nil {
		t.Fatalf("scans: %+v %d %v", scanList, n, err)
	}
	idRepo := NewIdentityRepository(r)
	ids, n, err := idRepo.List(ctx, IdentityFilter{Limit: 10})
	if err != nil || n != 1 || ids[0].ARN != "arn:aws:iam::123:role/app" || len(ids[0].OwnedCredentials) != 1 || ids[0].ConsumerCount != 1 || ids[0].DiscoveredAt != nil {
		t.Fatalf("identities: %+v %d %v", ids, n, err)
	}
	yes := true
	ids, n, err = idRepo.List(ctx, IdentityFilter{HasCredentials: &yes, Limit: 10})
	if err != nil || n != 1 || len(ids) != 1 {
		t.Fatalf("identity filter: %+v %d %v", ids, n, err)
	}
	summary, err := NewDashboardRepository(r).GetSummary(ctx, "")
	if err != nil || summary.TotalIdentities != 1 || summary.TotalCredentials != 1 || summary.CredentialsBreakdown["ACCESS_KEY"] != 1 {
		t.Fatalf("dashboard: %+v %v", summary, err)
	}
	creds, n, err := NewCredentialRepository(r).List(ctx, CredentialFilter{Limit: 10})
	if err != nil || n != 2 || len(creds) != 2 {
		t.Fatalf("credentials: %+v %d %v", creds, n, err)
	}
	events, n, err := NewEventRepository(r).ListByIdentity(ctx, "arn:aws:iam::123:role/app", "", 0, 10)
	if err != nil || n != 2 || len(events) != 2 || events[0].DiscoveredAt != nil {
		t.Fatalf("events: %+v %d %v", events, n, err)
	}
	consumerRepo := NewConsumerRepository(r)
	_, _, err = consumerRepo.GetRoleConsumers(ctx, "arn:aws:iam::123:role/app", "", 0, 10)
	if !errors.Is(err, ErrConsumersUnavailable) {
		t.Fatalf("expected unavailable callers: %v", err)
	}
	// Simulate the future scanner upgrade: new caller columns become available.
	for _, stmt := range []string{
		"ALTER TABLE nhi_scanner.nhi_events_aws ADD COLUMN caller_arn text, ADD COLUMN caller_type text",
		"UPDATE nhi_scanner.nhi_events_aws SET caller_arn = CASE WHEN scan_id = 'old' THEN 'caller-2' ELSE 'caller-1' END, caller_type = 'IAM_ROLE'",
	} {
		if _, err := db.ExecContext(ctx, stmt); err != nil {
			t.Fatal(err)
		}
	}
	consumers, n, err := consumerRepo.GetRoleConsumers(ctx, "arn:aws:iam::123:role/app", "", 0, 10)
	if err != nil || n != 1 || len(consumers) != 1 || consumers[0].SessionCount != 2 {
		t.Fatalf("consumers after schema upgrade: %+v %d %v", consumers, n, err)
	}
	oldIDs, oldCount, err := idRepo.List(ctx, IdentityFilter{ScanID: "old", Limit: 10})
	if err != nil || oldCount != 1 || len(oldIDs) != 1 || oldIDs[0].Name != "old" {
		t.Fatalf("explicit scan: %+v %d %v", oldIDs, oldCount, err)
	}
	oldIDs, oldCount, err = idRepo.List(ctx, IdentityFilter{ScanID: "old", Limit: 10, Offset: 10})
	if err != nil || oldCount != 1 || len(oldIDs) != 0 {
		t.Fatalf("identity pagination: %+v %d %v", oldIDs, oldCount, err)
	}
	creds, n, err = NewCredentialRepository(r).List(ctx, CredentialFilter{ScanID: "new", Type: "ACCESS_KEY", Search: "key-1", Limit: 1})
	if err != nil || n != 1 || len(creds) != 1 {
		t.Fatalf("credential filters: %+v %d %v", creds, n, err)
	}
	consumers, n, err = NewConsumerRepository(r).GetRoleConsumers(ctx, "arn:aws:iam::123:role/app", "old", 0, 10)
	if err != nil || n != 1 || len(consumers) != 1 || consumers[0].CallerARN != "caller-2" {
		t.Fatalf("consumer scan: %+v %d %v", consumers, n, err)
	}
	edges, n, err := NewLineageRepository(r).GetServiceAccess(ctx, LineageFilter{SourceARN: "arn:aws:iam::123:role/app", Limit: 10})
	if err != nil || n != 1 || edges[0].IsExternal != 1 {
		t.Fatalf("lineage: %+v %d %v", edges, n, err)
	}
}
