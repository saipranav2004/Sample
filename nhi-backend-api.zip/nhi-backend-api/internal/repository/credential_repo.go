package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"nhi-backend-api/internal/models"
)

type CredentialRepository struct {
	db *PostgresDB
}

func NewCredentialRepository(db *PostgresDB) *CredentialRepository {
	return &CredentialRepository{db: db}
}

type CredentialFilter struct {
	Search   string
	Type     string
	Severity string
	ScanID   string
	Offset   int
	Limit    int
}

func (r *CredentialRepository) List(ctx context.Context, filter CredentialFilter) ([]models.FlattenedCredential, int, error) {
	whereClauses := []string{"1=1"}
	var args []interface{}
	argIdx := 1

	if filter.ScanID != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("scan_id = $%d", argIdx))
		args = append(args, filter.ScanID)
		argIdx++
	} else {
		whereClauses = append(whereClauses, "scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)")
	}

	if filter.Type != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_type = $%d", argIdx))
		args = append(args, filter.Type)
		argIdx++
	}

	if filter.Severity != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("cred_severity = $%d", argIdx))
		args = append(args, filter.Severity)
		argIdx++
	}

	if filter.Search != "" {
		searchTerm := "%" + strings.ToLower(filter.Search) + "%"
		whereClauses = append(whereClauses, fmt.Sprintf("(LOWER(identity_name) LIKE $%d OR LOWER(identity_arn) LIKE $%d OR LOWER(cred_id) LIKE $%d)", argIdx, argIdx+1, argIdx+2))
		args = append(args, searchTerm, searchTerm, searchTerm)
		argIdx += 3
	}

	whereSection := "WHERE " + strings.Join(whereClauses, " AND ")

	// Unified CTE: Traditional Credentials (from owned_credentials JSON) UNION ALL IAM Roles as Credentials
	baseCTE := `
		WITH flattened_creds AS (
			-- PART 1: Traditional credentials extracted from owned_credentials JSON
			SELECT
				i.id AS identity_id,
				i.arn AS identity_arn,
				i.name AS identity_name,
				i.identity_type,
				i.scan_id,
				jt.type AS cred_type,
				jt.id AS cred_id,
				jt.status AS cred_status,
				jt.severity AS cred_severity,
				jt.created_at,
				jt.expires_at,
				jt.last_used_date,
				jt.last_used_service,
				jt.description
			FROM nhi_scanner.nhi_identities_aws i
            CROSS JOIN LATERAL jsonb_array_elements(COALESCE(NULLIF(NULLIF(BTRIM(i.owned_credentials::text), ''), 'null')::jsonb, '[]'::jsonb)) AS raw(cred)
            CROSS JOIN LATERAL (SELECT
                raw.cred->>'type' AS type, raw.cred->>'id' AS id,
                raw.cred->>'status' AS status, raw.cred->>'severity' AS severity,
                raw.cred->>'created_at' AS created_at, raw.cred->>'expires_at' AS expires_at,
                raw.cred->>'last_used_date' AS last_used_date,
                raw.cred->>'last_used_service' AS last_used_service,
                raw.cred->>'description' AS description) jt
            WHERE i.owned_credentials IS NOT NULL
			UNION ALL

			-- PART 2: IAM Roles surfaced as first-class credential entries
			SELECT
				i.id AS identity_id,
				i.arn AS identity_arn,
				i.name AS identity_name,
				i.identity_type,
				i.scan_id,
				'IAM_ROLE' AS cred_type,
				i.arn AS cred_id,
				'Active' AS cred_status,
				CASE 
					WHEN i.is_admin = 1 THEN 'CRITICAL'
					WHEN i.classification = 'HUMAN' THEN 'HIGH'
					WHEN i.classification = 'NHI_CICD' THEN 'MEDIUM'
					ELSE 'LOW'
				END AS cred_severity,
				TO_CHAR(i.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at,
				NULL AS expires_at,
				TO_CHAR(i.last_active AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS last_used_date,
				COALESCE(i.trust_service, 'AWS STS') AS last_used_service,
				'IAM Role (' || COALESCE(i.classification, 'UNCLASSIFIED') || ') — Trust: ' || COALESCE(i.trust_type, 'N/A') AS description
			FROM nhi_scanner.nhi_identities_aws i
			WHERE i.identity_type = 'IAM_ROLE'
		)`

	// 2. Count Total Matches
	countQuery := fmt.Sprintf("%s SELECT COUNT(*) FROM flattened_creds %s", baseCTE, whereSection)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count flattened credentials: %w", err)
	}

	// 3. Paginated Fetch
	dataQuery := fmt.Sprintf(`
		%s
		SELECT identity_id, identity_arn, identity_name, identity_type, scan_id,
		       cred_type, cred_id, cred_status, cred_severity,
		       created_at, expires_at, last_used_date, last_used_service, description
		FROM flattened_creds
		%s
		ORDER BY 
			CASE cred_severity 
				WHEN 'CRITICAL' THEN 1
				WHEN 'HIGH' THEN 2
				WHEN 'MEDIUM' THEN 3
				WHEN 'LOW' THEN 4
				ELSE 5
			END,
			identity_name ASC, identity_id ASC, cred_id ASC
		LIMIT $%d OFFSET $%d`, baseCTE, whereSection, argIdx+1, argIdx)

	args = append(args, filter.Offset, filter.Limit)

	rows, err := r.db.DB.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query flattened credentials: %w", err)
	}
	defer rows.Close()

	var list []models.FlattenedCredential
	for rows.Next() {
		var c models.FlattenedCredential
		var idName, idARN, idType, scanID sql.NullString
		var cType, cID, cStatus, cSeverity sql.NullString
		var cCreated, cExpires, cLastUsed, cLastUsedSvc, cDesc sql.NullString

		err := rows.Scan(
			&c.IdentityID, &idARN, &idName, &idType, &scanID,
			&cType, &cID, &cStatus, &cSeverity,
			&cCreated, &cExpires, &cLastUsed, &cLastUsedSvc, &cDesc,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan credential row: %w", err)
		}

		c.IdentityARN = idARN.String
		c.IdentityName = idName.String
		c.IdentityType = idType.String
		c.ScanID = scanID.String
		c.Type = cType.String
		c.CredID = cID.String
		c.Status = cStatus.String
		c.Severity = cSeverity.String
		c.CreatedAt = cCreated.String
		c.ExpiresAt = cExpires.String
		c.LastUsedDate = cLastUsed.String
		c.LastUsedService = cLastUsedSvc.String
		c.Description = cDesc.String

		list = append(list, c)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate credentials: %w", err)
	}
	return list, totalCount, nil
}
