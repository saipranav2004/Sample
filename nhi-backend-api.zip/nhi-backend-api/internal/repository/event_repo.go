package repository

import (
	"context"
	"database/sql"
	"fmt"

	"nhi-backend-api/internal/models"
)

type EventRepository struct {
	db *PostgresDB
}

func NewEventRepository(db *PostgresDB) *EventRepository {
	return &EventRepository{db: db}
}

// ListByIdentity retrieves CloudTrail events safely handling casing, NULLs, and scan isolation
func (r *EventRepository) ListByIdentity(ctx context.Context, identityARN, scanID string, offset, limit int) ([]models.Event, int, error) {
	whereClause := "WHERE 1=1"
	var args []interface{}
	argIdx := 1

	if identityARN != "" {
		// Use LOWER() and TRIM() to guarantee matches regardless of ARN case mismatches
		whereClause += fmt.Sprintf(" AND LOWER(TRIM(identity_arn)) = LOWER(TRIM($%d))", argIdx)
		args = append(args, identityARN)
		argIdx++
	}

	// ── CRITICAL FIX: Default to latest completed scan if scanID is empty ──
	if scanID != "" {
		whereClause += fmt.Sprintf(" AND scan_id = $%d", argIdx)
		args = append(args, scanID)
		argIdx++
	} else {
		whereClause += " AND scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)"
	}

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM nhi_scanner.nhi_events_aws %s", whereClause)
	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, args...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count events: %w", err)
	}

	query := fmt.Sprintf(`
		SELECT id, scan_id, identity_name, identity_arn, identity_type,
		       event_time, event_name, event_source, source_ip,
		       user_agent, read_only, region, NULL::timestamptz AS discovered_at
		FROM nhi_scanner.nhi_events_aws
		%s
		ORDER BY event_time DESC, id DESC
		LIMIT $%d OFFSET $%d`, whereClause, argIdx+1, argIdx)

	args = append(args, offset, limit)

	rows, err := r.db.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query events: %w", err)
	}
	defer rows.Close()

	var events []models.Event
	for rows.Next() {
		var e models.Event
		var eventTime sql.NullTime
		var idName, idARN, idType sql.NullString
		var evName, evSource, srcIP, uAgent, rOnly, reg sql.NullString

		err := rows.Scan(
			&e.ID, &e.ScanID, &idName, &idARN, &idType,
			&eventTime, &evName, &evSource, &srcIP,
			&uAgent, &rOnly, &reg, &e.DiscoveredAt,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("scan event row: %w", err)
		}

		e.IdentityName = idName.String
		e.IdentityARN = idARN.String
		e.IdentityType = idType.String
		e.EventName = evName.String
		e.EventSource = evSource.String
		e.SourceIP = srcIP.String
		e.UserAgent = uAgent.String
		e.ReadOnly = rOnly.String
		e.Region = reg.String

		if eventTime.Valid {
			e.EventTime = &eventTime.Time
		}

		events = append(events, e)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate events: %w", err)
	}
	return events, totalCount, nil
}
