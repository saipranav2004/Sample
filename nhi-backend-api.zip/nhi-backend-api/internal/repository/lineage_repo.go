// internal/repository/lineage_repo.go
package repository

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/models"
)

type LineageRepository struct {
	db *PostgresDB
}

type LineageFilter struct {
	SourceARN string
	ScanID    string
	Offset    int
	Limit     int
}

func NewLineageRepository(db *PostgresDB) *LineageRepository {
	return &LineageRepository{db: db}
}

// GetServiceAccess retrieves a paginated slice of accessed services for an identity
func (r *LineageRepository) GetServiceAccess(ctx context.Context, filter LineageFilter) ([]models.LineageEdge, int, error) {
	// Build scan dynamic query filter
	scanFilter := "scan_id = (SELECT scan_id FROM nhi_scanner.nhi_scans_aws WHERE status = 'COMPLETED' ORDER BY scan_end DESC NULLS LAST, id DESC LIMIT 1)"

	var countArgs []interface{}
	countArgs = append(countArgs, filter.SourceARN)

	if filter.ScanID != "" {
		scanFilter = "scan_id = $2"
		countArgs = append(countArgs, filter.ScanID)
	}

	// 1. Fetch total count of access lineage records
	countQuery := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM nhi_scanner.nhi_lineage_aws
		WHERE source_arn = $1 AND %s`, scanFilter)

	var totalCount int
	err := r.db.DB.QueryRowContext(ctx, countQuery, countArgs...).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("count lineage edges: %w", err)
	}

	if totalCount == 0 {
		return []models.LineageEdge{}, 0, nil
	}

	// 2. Fetch paginated records
	offsetPlaceholder := "$2"
	limitPlaceholder := "$3"
	var selectArgs []interface{}
	selectArgs = append(selectArgs, filter.SourceARN)

	if filter.ScanID != "" {
		offsetPlaceholder = "$3"
		limitPlaceholder = "$4"
		selectArgs = append(selectArgs, filter.ScanID)
	}
	selectArgs = append(selectArgs, filter.Offset, filter.Limit)

	selectQuery := fmt.Sprintf(`
		SELECT 
			COALESCE(target_name, '—') AS target_name,
			COALESCE(target_type, '—') AS target_type,
			COALESCE(rel_type, '—') AS rel_type,
			COALESCE(direction, '—') AS direction,
			COALESCE(via, '—') AS via,
			COALESCE(is_external, 0) AS is_external,
			COALESCE(detail, '') AS detail
		FROM nhi_scanner.nhi_lineage_aws
		WHERE source_arn = $1 AND %s
		ORDER BY target_name, target_type, rel_type, direction
		LIMIT %s OFFSET %s`, scanFilter, limitPlaceholder, offsetPlaceholder)

	rows, err := r.db.DB.QueryContext(ctx, selectQuery, selectArgs...)
	if err != nil {
		return nil, 0, fmt.Errorf("query lineage edges: %w", err)
	}
	defer rows.Close()

	var edges []models.LineageEdge
	for rows.Next() {
		var edge models.LineageEdge
		if err := rows.Scan(
			&edge.TargetName,
			&edge.TargetType,
			&edge.RelType,
			&edge.Direction,
			&edge.Via,
			&edge.IsExternal,
			&edge.Detail,
		); err != nil {
			return nil, 0, fmt.Errorf("scan lineage edge: %w", err)
		}
		edges = append(edges, edge)
	}

	if edges == nil {
		edges = []models.LineageEdge{}
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate edges: %w", err)
	}
	return edges, totalCount, nil
}
