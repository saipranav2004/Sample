// Package secscan holds the request and response shapes of the secret-scanner
// (credential exposure) API. The JSON field names and envelopes match the
// scanner's own HTTP API (API_Integration_Guide_Updated_3), so a client built
// against that API reads these responses unchanged.
package secscan

import "errors"

// Platforms. Each one is a separate pair of tables in nhi_scanner.
const (
	PlatformCodeCommit = "codecommit"
	PlatformGitHub     = "github"
)

// Allowlist sources: which table an allowlist entry lives in.
const (
	SourceDashboard  = "dashboard"
	SourceCodeCommit = PlatformCodeCommit
	SourceGitHub     = PlatformGitHub
)

// Analyst decisions accepted by POST /api/findings/decision.
const (
	DecisionRealSecret    = "real_secret"
	DecisionFalsePositive = "false_positive"
)

// Deep-scan states, derived from a secscan_deepscan_* row.
const (
	DeepScanNotStarted = "not_started"
	DeepScanRunning    = "running"
	DeepScanComplete   = "complete"
	DeepScanFailed     = "failed"
)

var (
	// ErrSourceUnavailable means the scanner tables cannot be read or written
	// (missing table, missing privilege, database down).
	ErrSourceUnavailable = errors.New("secret scanner data source unavailable")
	// ErrNotFound means the referenced finding does not exist.
	ErrNotFound = errors.New("not found")
)

// Finding is one detected secret, one row of secscan_findings_<platform>.
// Nullable columns are pointers so JSON null means "not recorded", never a
// made-up zero or empty string.
type Finding struct {
	FindingID          string   `json:"finding_id"`
	ClientID           string   `json:"client_id"`
	Repository         string   `json:"repository"`
	Branch             string   `json:"branch"`
	CommitID           string   `json:"commit_id"`
	Author             string   `json:"author"`
	CreatedAt          string   `json:"created_at"`
	Detector           string   `json:"detector"`
	Severity           string   `json:"severity"`
	FilePath           string   `json:"file_path"`
	LineNumber         int      `json:"line_number"`
	Redacted           string   `json:"redacted"`
	VerificationStatus string   `json:"verification_status"`
	RiskTier           string   `json:"risk_tier"`
	RecommendedAction  string   `json:"recommended_action"`
	CodeCommitURI      *string  `json:"codecommit_uri"`
	Platform           string   `json:"platform"`
	GitHubURI          *string  `json:"github_uri"`
	LinePreview        *string  `json:"line_preview"`
	Confidence         *string  `json:"confidence"`
	Category           *string  `json:"category"`
	Committer          *string  `json:"committer"`
	CommitMessage      *string  `json:"commit_message"`
	CommitAuthoredAt   *string  `json:"commit_authored_at"`
	FilesChanged       *int64   `json:"files_changed"`
	Additions          *int64   `json:"additions"`
	Deletions          *int64   `json:"deletions"`
	RepoVisibility     *string  `json:"repo_visibility"`
	RepoStars          *int64   `json:"repo_stars"`
	RepoForks          *int64   `json:"repo_forks"`
	RepoPushedAt       *string  `json:"repo_pushed_at"`
	MLScore            *float64 `json:"ml_score"`
	MLDecision         *string  `json:"ml_decision"`
	MLModelVersion     *string  `json:"ml_model_version"`
	AnalystDecision    *string  `json:"analyst_decision"`
	AnalystDecidedAt   *string  `json:"analyst_decided_at"`
	AnalystDecidedBy   *string  `json:"analyst_decided_by"`
}

// FindingsResponse is GET /api/findings.
type FindingsResponse struct {
	Count    int       `json:"count"`
	Findings []Finding `json:"findings"`
}

// FindingsFilter narrows GET /api/findings. Empty fields match everything.
type FindingsFilter struct {
	ClientID string
	Platform string
}

// AllowlistEntry is one "mark as safe" decision. Source says which table it
// is stored in: only "dashboard" entries can be removed through this API;
// the other two belong to the scanner stacks themselves.
type AllowlistEntry struct {
	ClientID    string `json:"client_id"`
	FilePath    string `json:"file_path"`
	Detector    string `json:"detector"`
	Redacted    string `json:"redacted"`
	Reason      string `json:"reason"`
	DismissedBy string `json:"dismissed_by"`
	DismissedAt string `json:"dismissed_at"`
	Source      string `json:"source"`
}

// AllowlistResponse is GET /api/allowlist.
type AllowlistResponse struct {
	Entries []AllowlistEntry `json:"entries"`
}

// AllowlistKey identifies the findings an allowlist entry hides. It is the
// primary key of every secscan_allowlist_* table.
type AllowlistKey struct {
	ClientID string `json:"client_id"`
	FilePath string `json:"file_path"`
	Detector string `json:"detector"`
	Redacted string `json:"redacted"`
}

// AllowlistRequest is the body of POST and DELETE /api/allowlist.
// DismissedBy is accepted for compatibility with the scanner API but ignored:
// the reviewer is always the authenticated user.
type AllowlistRequest struct {
	ClientID    string `json:"client_id"`
	FilePath    string `json:"file_path"`
	Detector    string `json:"detector"`
	Redacted    string `json:"redacted"`
	Reason      string `json:"reason"`
	DismissedBy string `json:"dismissed_by"`
}

// AllowlistWriteResponse is POST /api/allowlist.
type AllowlistWriteResponse struct {
	OK    bool            `json:"ok"`
	Entry *AllowlistEntry `json:"entry,omitempty"`
}

// OKResponse is DELETE /api/allowlist and POST /api/findings/decision.
type OKResponse struct {
	OK bool `json:"ok"`
}

// DecisionRequest is the body of POST /api/findings/decision. Platform picks
// the table: finding IDs are only unique within one platform's table.
type DecisionRequest struct {
	FindingID string `json:"finding_id"`
	Platform  string `json:"platform"`
	Decision  string `json:"decision"`
	DecidedBy string `json:"decided_by"`
}

// DeepScan is one secscan_deepscan_* row with its derived status.
type DeepScan struct {
	ClientID       string  `json:"client_id"`
	RepoKey        string  `json:"repo_key"`
	Platform       string  `json:"platform"`
	RequestedAt    string  `json:"requested_at"`
	CompletedAt    *string `json:"completed_at"`
	CommitsScanned *int64  `json:"commits_scanned"`
	Findings       *int64  `json:"findings"`
	FailedAt       *string `json:"failed_at"`
	Error          *string `json:"error"`
	Status         string  `json:"status"`
}

// DeepScanStatus derives the status the same way the scanner does:
// failed if failed_at is set, else complete if completed_at is set, else running.
func DeepScanStatus(completedAt, failedAt *string) string {
	if failedAt != nil && *failedAt != "" {
		return DeepScanFailed
	}
	if completedAt != nil && *completedAt != "" {
		return DeepScanComplete
	}
	return DeepScanRunning
}
