package inventory

type CountsFilter struct {
	Scope
	AccountID, Region, FunctionalClass string
}
type CountsResponse struct {
	Total      int64            `json:"total"`
	Active     int64            `json:"active"`
	Stopped    int64            `json:"stopped"`
	Terminated int64            `json:"terminated"`
	ByType     map[string]int64 `json:"by_type"`
	ByClass    map[string]int64 `json:"by_class"`
}
type CountRow struct {
	Status, IdentityType, FunctionalClass string
	Count                                 int64
}
