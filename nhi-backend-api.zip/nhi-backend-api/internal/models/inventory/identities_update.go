package inventory

// UpdatePatch has pointers so an absent field is distinct from an actual
// update. Null/blank are rejected until a clearing contract is approved.
type UpdatePatch struct {
	FunctionalClass *string `json:"functional_class"`
	Owner           *string `json:"owner"`
	Environment     *string `json:"environment"`
}
type UpdateResponse struct {
	ID            string   `json:"id"`
	Message       string   `json:"message"`
	UpdatedFields []string `json:"updated_fields"`
}
