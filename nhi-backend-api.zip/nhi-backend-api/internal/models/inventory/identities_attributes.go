package inventory

import "encoding/json"

type AttributesResponse struct {
	IdentityType   string          `json:"identity_type"`
	TypeAttributes json.RawMessage `json:"type_attributes"`
}
