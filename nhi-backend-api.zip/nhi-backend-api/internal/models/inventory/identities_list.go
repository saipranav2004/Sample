package inventory

import (
	"encoding/json"
	"time"
)

// Scope is server-resolved; never take AllowedAccountIDs from query parameters.
type Scope struct{ AllowedAccountIDs []string }

type ListFilter struct {
	Scope
	Page, Limit                                                                  int64
	SortBy, SortOrder, Search                                                    string
	IdentityType, FunctionalClass, AccountID, Region, Status, Owner, Environment string
	IsPublic                                                                     *bool
	LastActiveBefore                                                             *time.Time
}

type IdentitySummary struct {
	ID                   string          `json:"id"`
	ARN                  string          `json:"arn"`
	Name                 string          `json:"name"`
	IdentityType         string          `json:"identity_type"`
	FunctionalClass      *string         `json:"functional_class"`
	AccountID            string          `json:"account_id"`
	Region               string          `json:"region"`
	Status               string          `json:"status"`
	CreatedAtAWS         *time.Time      `json:"created_at_aws"`
	LastSeenAt           time.Time       `json:"last_seen_at"`
	LastActivityAt       *time.Time      `json:"last_activity_at"`
	Owner                *string         `json:"owner"`
	Environment          *string         `json:"environment"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
	Tags                 json.RawMessage `json:"tags"`
}

type ListResponse struct {
	Total int64             `json:"total"`
	Page  int64             `json:"page"`
	Limit int64             `json:"limit"`
	Data  []IdentitySummary `json:"data"`
}
