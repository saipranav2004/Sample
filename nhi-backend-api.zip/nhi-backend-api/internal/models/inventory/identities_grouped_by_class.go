package inventory

type GroupFilter struct {
	Scope
	AccountID, Region string
	LimitPerClass     int64
}
type GroupIdentity struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	IdentityType string `json:"identity_type"`
	Status       string `json:"status"`
}
type ClassGroup struct {
	FunctionalClass string          `json:"functional_class"`
	Count           int64           `json:"count"`
	Identities      []GroupIdentity `json:"identities"`
}
type GroupedResponse struct {
	Groups []ClassGroup `json:"groups"`
}
type GroupRow struct {
	FunctionalClass string
	Count           int64
	Identity        GroupIdentity
}
