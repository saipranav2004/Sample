package inventory

import "errors"

var ErrExportTooLarge = errors.New("inventory export exceeds safe limit")

// ExportFilter accepts A1 selection/sort syntax, but exports ALL matches
// (not only one page), within repository row and byte limits.
type ExportFilter struct {
	ListFilter
	Format string
}
type ExportPayload struct {
	Body        []byte
	ContentType string
	Filename    string
}
