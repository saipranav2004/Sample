package inventory

import "time"

type TimelineRecord struct {
	ARN                     string
	FirstSeenAt, LastSeenAt time.Time
	LastActivityAt          *time.Time
}
type TimelineEvent struct {
	Event     string    `json:"event"`
	Timestamp time.Time `json:"timestamp"`
}
type TimelineResponse struct {
	IdentityARN           string          `json:"identity_arn"`
	Events                []TimelineEvent `json:"events"`
	AgeDays               int64           `json:"age_days"`
	DaysSinceLastActivity *int64          `json:"days_since_last_activity"`
}
