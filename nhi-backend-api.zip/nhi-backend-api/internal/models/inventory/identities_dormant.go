package inventory

import "time"

// DormantFilter uses the trusted account scope and one UTC now per request.
type DormantFilter struct {
	Scope
	Days                    int64
	AccountID, IdentityType string
	Page, Limit             int64
}
type DormantItem struct {
	ID             string    `json:"id"`
	Name           string    `json:"name"`
	IdentityType   string    `json:"identity_type"`
	LastActivityAt time.Time `json:"last_activity_at"`
	DaysInactive   int64     `json:"days_inactive"`
	Owner          *string   `json:"owner"`
	Environment    *string   `json:"environment"`
}
type DormantResponse struct {
	ThresholdDays int64         `json:"threshold_days"`
	TotalDormant  int64         `json:"total_dormant"`
	Data          []DormantItem `json:"data"`
}
