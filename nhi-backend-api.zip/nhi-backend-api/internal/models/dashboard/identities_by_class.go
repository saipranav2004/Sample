package dashboard

// ClassFilter is the PDF's by-class filter set. AllowedAccountIDs is a trusted,
// server-resolved authorization scope, never derived from URL input.
type ClassFilter struct {
	AccountID         string
	Region            string
	AllowedAccountIDs []string
}

type FunctionalClassCount struct {
	FunctionalClass string `json:"functional_class"`
	Count           int64  `json:"count"`
}

type ByClassResponse struct {
	Total     int64                  `json:"total"`
	Breakdown []FunctionalClassCount `json:"breakdown"`
}
