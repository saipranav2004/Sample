package dashboard

// AccountFilter scopes API #4 to approved AWS accounts and supports its
// optional region and identity_type filters.
type AccountFilter struct {
	Region            string
	IdentityType      string
	AllowedAccountIDs []string
}

// AccountIdentityCount is an identity count read from nhi_scanner.identities.
type AccountIdentityCount struct {
	AccountID     string
	IdentityCount int64
}

// AccountBreakdown omits account_name at the lead's direction. Production
// measures CredentialCount from current nhi_scanner.credentials; nil remains
// unavailable for unconfigured/adaptor-only service instances.
type AccountBreakdown struct {
	AccountID       string `json:"account_id"`
	IdentityCount   int64  `json:"identity_count"`
	CredentialCount *int64 `json:"credential_count"`
}

type ByAccountResponse struct {
	TotalAccounts int                `json:"total_accounts"`
	Breakdown     []AccountBreakdown `json:"breakdown"`
}
