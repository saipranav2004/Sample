package dashboard

// RegionFilter scopes API #5 to approved AWS accounts and supports its
// optional account_id and identity_type filters.
type RegionFilter struct {
	AccountID         string
	IdentityType      string
	AllowedAccountIDs []string
}

// RegionIdentityCount is an identity count read from nhi_scanner.identities.
type RegionIdentityCount struct {
	Region        string
	IdentityCount int64
}

// RegionBreakdown includes measured current credential counts in production.
// A nil count is unavailable for an unconfigured/adaptor-only service.
type RegionBreakdown struct {
	Region          string `json:"region"`
	IdentityCount   int64  `json:"identity_count"`
	CredentialCount *int64 `json:"credential_count"`
}

type ByRegionResponse struct {
	TotalRegions int               `json:"total_regions"`
	Breakdown    []RegionBreakdown `json:"breakdown"`
}
