package dashboard

import "time"

// SummaryFilter carries the two PDF filters and the trusted, authenticated
// account scope. AllowedAccountIDs must NEVER come from URL query parameters.
type SummaryFilter struct {
	AccountID         string
	Region            string
	AllowedAccountIDs []string
}

// SummaryIdentityRow is the repository's grouped identity status result.
// Deleted rows contribute only to Removed24h; current rows to other counts.
type SummaryIdentityRow struct {
	Status       string
	CurrentCount int64
	New24h       int64
	Removed24h   int64
}

// SummaryCredentialRow is a measured status group from current, scoped
// scanner credentials. Usage/expiry counts require actual non-NULL dates.
type SummaryCredentialRow struct {
	Status          string
	CurrentCount    int64
	New24h          int64
	Expiring30d     int64
	StaleKeys90d    int64
	UnknownKeyUsage int64
}

// SummaryScanData holds measured scan fields at the account scope. No region
// or scan-start column was supplied in the scan table.
type SummaryScanData struct {
	CompletedAccountCount int64
	LastScanAt            *time.Time
	ScanStatus            *string
}

// SummaryResponse is a deliberately PARTIAL PDF #1 contract: null means not
// measurable from verified sources, never a measured zero. The frontend must
// treat null values as "Not available" (including all scan cards when region
// is specified, because scan records cannot be filtered by region).
type SummaryResponse struct {
	TotalIdentities          int64             `json:"total_identities"`
	TotalCredentials         *int64            `json:"total_credentials"`
	TotalAccountsScanned     *int64            `json:"total_accounts_scanned"`
	TotalRegionsScanned      *int64            `json:"total_regions_scanned"`
	IdentitiesByStatus       map[string]int64  `json:"identities_by_status"`
	CredentialsByStatus      *map[string]int64 `json:"credentials_by_status"`
	NewIdentitiesLast24h     int64             `json:"new_identities_last_24h"`
	RemovedIdentitiesLast24h int64             `json:"removed_identities_last_24h"`
	NewCredentialsLast24h    *int64            `json:"new_credentials_last_24h"`
	ExpiringCredentials30d   *int64            `json:"expiring_credentials_30d"`
	StaleCredentials90d      *int64            `json:"stale_credentials_90d"`
	UnrotatedCredentials     *int64            `json:"unrotated_credentials"`
	LastScanAt               *time.Time        `json:"last_scan_at"`
	ScanDurationSeconds      *int64            `json:"scan_duration_seconds"`
	ScanStatus               *string           `json:"scan_status"`
}
