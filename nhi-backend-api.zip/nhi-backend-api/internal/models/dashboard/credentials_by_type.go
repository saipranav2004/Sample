package dashboard

import "errors"

// ErrCredentialSourceUnavailable means a required credential source or
// classification rule is unavailable. Never translate it into a measured zero.
var ErrCredentialSourceUnavailable = errors.New("dashboard credential inventory is not configured")

// CredentialTypeFilter carries the PDF #6 filters and the trusted account
// scope resolved from the authenticated request, never from the URL alone.
type CredentialTypeFilter struct {
	AccountID         string
	Region            string
	Status            string
	AllowedAccountIDs []string
}

type CredentialTypeCount struct {
	CredentialType string `json:"credential_type"`
	Count          int64  `json:"count"`
}

type CredentialsByTypeResponse struct {
	Total     int64                 `json:"total"`
	Breakdown []CredentialTypeCount `json:"breakdown"`
}
