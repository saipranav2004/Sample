package dashboard

// TypeFilter uses the trusted JWT-resolved AWS-account scope, not a client-
// provided list. All four PDF #2 query parameters are optional.
type TypeFilter struct {
	AccountID         string
	Region            string
	Status            string
	FunctionalClass   string
	AllowedAccountIDs []string
}

type IdentityTypeCount struct {
	IdentityType string `json:"identity_type"`
	Count        int64  `json:"count"`
}

type ByTypeResponse struct {
	Total     int64               `json:"total"`
	Breakdown []IdentityTypeCount `json:"breakdown"`
}
