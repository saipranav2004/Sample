package dashboard

// ExposureFilter carries the optional PDF account_id and a trusted, JWT-
// resolved AWS-account scope. Never fill AllowedAccountIDs from a URL.
type ExposureFilter struct {
	AccountID         string
	AllowedAccountIDs []string
}

// ExposureCountByType is a real count of current identities of one type.
type ExposureCountByType struct {
	IdentityType string `json:"identity_type"`
	Count        int64  `json:"count"`
}

type ExposureGroup struct {
	Total  int64                 `json:"total"`
	ByType []ExposureCountByType `json:"by_type"`
}

// ExposureResponse implements the available catalog-derived PDF #8 cards.
// No confirmed IaC marker exists: nil NotInIAC serializes as JSON null, NOT 0.
// The product must approve the normalized owner/environment column semantics.
type ExposureResponse struct {
	PubliclyAccessible    ExposureGroup `json:"publicly_accessible"`
	Dormant90d            ExposureGroup `json:"dormant_90d"`
	NoActivityTracked     int64         `json:"no_activity_tracked"`
	MissingOwnerTag       int64         `json:"missing_owner_tag"`
	MissingEnvironmentTag int64         `json:"missing_environment_tag"`
	NotInIAC              *int64        `json:"not_in_iac"`
}

// ExposureCountRow is a grouped repository result, not a JSON response.
type ExposureCountRow struct {
	IdentityType      string
	PublicCount       int64
	DormantCount      int64
	NoActivityCount   int64
	MissingOwnerCount int64
	MissingEnvCount   int64
}
