package dashboard

// CredentialHygieneFilter uses the same trusted account scope as PDF #6.
type CredentialHygieneFilter struct {
	AccountID         string
	AllowedAccountIDs []string
}

type CredentialHygieneGroup struct {
	Total  int64                 `json:"total"`
	ByType []CredentialTypeCount `json:"by_type"`
}

type HighPrivilegeRoles struct {
	Total           int64 `json:"total"`
	AdminAccess     int64 `json:"admin_access"`
	WildcardActions int64 `json:"wildcard_actions"`
}

// CredentialHygieneResponse is the PDF #7 shape. An instance is returned
// ONLY when every metric is backed by an approved source. Until then the
// repository returns ErrCredentialSourceUnavailable and HTTP 503.
type CredentialHygieneResponse struct {
	ExpiringWithin30d       CredentialHygieneGroup `json:"expiring_within_30d"`
	AlreadyExpired          CredentialHygieneGroup `json:"already_expired"`
	StaleAccessKeys90d      int64                  `json:"stale_access_keys_90d"`
	NeverUsedAccessKeys     int64                  `json:"never_used_access_keys"`
	UnrotatedSecrets90d     int64                  `json:"unrotated_secrets_90d"`
	RotationDisabledSecrets int64                  `json:"rotation_disabled_secrets"`
	RootAccessKeysPresent   int64                  `json:"root_access_keys_present"`
	HighPrivilegeRoles      HighPrivilegeRoles     `json:"high_privilege_roles"`
	PublicTrustRoles        int64                  `json:"public_trust_roles"`
}
