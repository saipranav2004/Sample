package dashboard

import (
	"encoding/json"
	"testing"
)

func TestCredentialPDFSuccessShapes(t *testing.T) {
	byType, err := json.Marshal(CredentialsByTypeResponse{Total: 2, Breakdown: []CredentialTypeCount{{CredentialType: "access_key", Count: 2}}})
	if err != nil || string(byType) != `{"total":2,"breakdown":[{"credential_type":"access_key","count":2}]}` {
		t.Fatalf("#6 shape: %s %v", byType, err)
	}
	data, err := json.Marshal(CredentialHygieneResponse{
		ExpiringWithin30d: CredentialHygieneGroup{ByType: []CredentialTypeCount{}},
		AlreadyExpired:    CredentialHygieneGroup{ByType: []CredentialTypeCount{}},
	})
	if err != nil {
		t.Fatal(err)
	}
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(data, &obj); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"expiring_within_30d", "already_expired", "stale_access_keys_90d", "never_used_access_keys", "unrotated_secrets_90d", "rotation_disabled_secrets", "root_access_keys_present", "high_privilege_roles", "public_trust_roles"} {
		if _, exists := obj[name]; !exists {
			t.Fatalf("#7 missing %s: %s", name, data)
		}
	}
	var roles map[string]int64
	if err := json.Unmarshal(obj["high_privilege_roles"], &roles); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"total", "admin_access", "wildcard_actions"} {
		if _, exists := roles[name]; !exists {
			t.Fatalf("#7 high_privilege_roles missing %s: %s", name, data)
		}
	}
}
