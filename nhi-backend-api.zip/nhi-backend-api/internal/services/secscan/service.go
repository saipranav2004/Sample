// Package secscan is the business logic of the secret-scanner API: input
// validation, who may change what, and the timestamps written back.
package secscan

import (
	"context"
	"errors"
	"strings"
	"time"
	"unicode/utf8"

	m "nhi-backend-api/internal/models/secscan"
)

// Repository is what the service needs from storage.
type Repository interface {
	ListFindings(ctx context.Context, f m.FindingsFilter) ([]m.Finding, error)
	FindingKeyExists(ctx context.Context, k m.AllowlistKey) (bool, error)
	SetDecision(ctx context.Context, platform, findingID, decision, decidedAt, decidedBy string) error
	ListAllowlist(ctx context.Context, clientID string) ([]m.AllowlistEntry, error)
	UpsertDashboardEntry(ctx context.Context, e m.AllowlistEntry) (m.AllowlistEntry, error)
	DeleteDashboardEntry(ctx context.Context, k m.AllowlistKey) (bool, error)
	DeepScan(ctx context.Context, clientID, repository string) (*m.DeepScan, error)
}

// ValidationError is a request the caller can fix; the message is safe to
// show and never echoes the submitted value.
type ValidationError struct{ Message string }

func (e *ValidationError) Error() string { return e.Message }

func invalid(msg string) error { return &ValidationError{Message: msg} }

// ErrForbidden means the caller's role may not perform the change.
var ErrForbidden = errors.New("role may not change secret findings")

// reviewerRoles may mark findings safe, restore them and record decisions.
// Every authenticated role may read. Roles come from the users table
// (admin, team_lead, developer, auditor).
var reviewerRoles = map[string]bool{"admin": true, "team_lead": true}

// CanReview reports whether a role may change findings.
func CanReview(role string) bool { return reviewerRoles[strings.ToLower(strings.TrimSpace(role))] }

// CanSeeScanErrors reports whether a role may read raw deep-scan errors,
// which can contain internal account and permission details.
func CanSeeScanErrors(role string) bool { return strings.EqualFold(strings.TrimSpace(role), "admin") }

// Column limits from the scanner schema. The allowlist columns are the
// tightest, so a value that fits them fits the findings columns too.
const (
	maxClientID   = 200
	maxFilePath   = 1000
	maxDetector   = 200
	maxRedacted   = 500
	maxReason     = 1000
	maxActor      = 200
	maxRepository = 500
	maxFindingID  = 1000
)

// Service implements the secret-scanner API.
type Service struct {
	repo Repository
	now  func() time.Time
}

func NewService(repo Repository) *Service {
	return &Service{repo: repo, now: time.Now}
}

// timestamp formats an instant the way the scanner stores them:
// ISO-8601 UTC with an explicit offset, e.g. 2026-09-23T11:12:25+00:00.
func (s *Service) timestamp() string {
	return s.now().UTC().Format("2006-01-02T15:04:05-07:00")
}

func checkText(name, value string, max int, required bool) error {
	if required && strings.TrimSpace(value) == "" {
		return invalid(name + " is required")
	}
	if !utf8.ValidString(value) || strings.ContainsRune(value, 0) {
		return invalid(name + " is not valid text")
	}
	if utf8.RuneCountInString(value) > max {
		return invalid(name + " is too long")
	}
	return nil
}

// ValidatePlatform accepts "" (both platforms), "codecommit" or "github".
func ValidatePlatform(p string, required bool) error {
	switch p {
	case m.PlatformCodeCommit, m.PlatformGitHub:
		return nil
	case "":
		if required {
			return invalid("platform is required")
		}
		return nil
	default:
		return invalid(`platform must be "codecommit" or "github"`)
	}
}

func validateKey(k m.AllowlistKey) error {
	for _, c := range []struct {
		name, value string
		max         int
	}{
		{"client_id", k.ClientID, maxClientID},
		{"file_path", k.FilePath, maxFilePath},
		{"detector", k.Detector, maxDetector},
		{"redacted", k.Redacted, maxRedacted},
	} {
		if err := checkText(c.name, c.value, c.max, true); err != nil {
			return err
		}
	}
	return nil
}

// actor is the authenticated reviewer recorded on a change.
func actor(email string) string {
	email = strings.TrimSpace(email)
	if email == "" {
		email = "dashboard user"
	}
	if utf8.RuneCountInString(email) > maxActor {
		email = string([]rune(email)[:maxActor])
	}
	return email
}

// Findings lists every finding not marked safe, newest first.
func (s *Service) Findings(ctx context.Context, f m.FindingsFilter) (*m.FindingsResponse, error) {
	if err := checkText("client_id", f.ClientID, maxClientID, false); err != nil {
		return nil, err
	}
	if err := ValidatePlatform(f.Platform, false); err != nil {
		return nil, err
	}
	findings, err := s.repo.ListFindings(ctx, f)
	if err != nil {
		return nil, err
	}
	return &m.FindingsResponse{Count: len(findings), Findings: findings}, nil
}

// Allowlist lists every "mark as safe" entry.
func (s *Service) Allowlist(ctx context.Context, clientID string) (*m.AllowlistResponse, error) {
	if err := checkText("client_id", clientID, maxClientID, false); err != nil {
		return nil, err
	}
	entries, err := s.repo.ListAllowlist(ctx, clientID)
	if err != nil {
		return nil, err
	}
	return &m.AllowlistResponse{Entries: entries}, nil
}

// Dismiss marks a finding safe in the dashboard allowlist. The reviewer is
// the authenticated user, never a name supplied in the body.
func (s *Service) Dismiss(ctx context.Context, role, email string, req m.AllowlistRequest) (*m.AllowlistWriteResponse, error) {
	if !CanReview(role) {
		return nil, ErrForbidden
	}
	key := m.AllowlistKey{ClientID: req.ClientID, FilePath: req.FilePath, Detector: req.Detector, Redacted: req.Redacted}
	if err := validateKey(key); err != nil {
		return nil, err
	}
	reason := strings.TrimSpace(req.Reason)
	if err := checkText("reason", reason, maxReason, false); err != nil {
		return nil, err
	}
	exists, err := s.repo.FindingKeyExists(ctx, key)
	if err != nil {
		return nil, err
	}
	if !exists {
		return nil, m.ErrNotFound
	}
	entry, err := s.repo.UpsertDashboardEntry(ctx, m.AllowlistEntry{
		ClientID: key.ClientID, FilePath: key.FilePath, Detector: key.Detector, Redacted: key.Redacted,
		Reason: reason, DismissedBy: actor(email), DismissedAt: s.timestamp(),
	})
	if err != nil {
		return nil, err
	}
	return &m.AllowlistWriteResponse{OK: true, Entry: &entry}, nil
}

// Restore removes a dashboard allowlist entry. ok is false when nothing
// matched, which is not an error.
func (s *Service) Restore(ctx context.Context, role string, req m.AllowlistRequest) (*m.OKResponse, error) {
	if !CanReview(role) {
		return nil, ErrForbidden
	}
	key := m.AllowlistKey{ClientID: req.ClientID, FilePath: req.FilePath, Detector: req.Detector, Redacted: req.Redacted}
	if err := validateKey(key); err != nil {
		return nil, err
	}
	removed, err := s.repo.DeleteDashboardEntry(ctx, key)
	if err != nil {
		return nil, err
	}
	return &m.OKResponse{OK: removed}, nil
}

// Decide records a human's verdict on one finding.
func (s *Service) Decide(ctx context.Context, role, email string, req m.DecisionRequest) (*m.OKResponse, error) {
	if !CanReview(role) {
		return nil, ErrForbidden
	}
	if err := checkText("finding_id", req.FindingID, maxFindingID, true); err != nil {
		return nil, err
	}
	if err := ValidatePlatform(req.Platform, true); err != nil {
		return nil, err
	}
	if req.Decision != m.DecisionRealSecret && req.Decision != m.DecisionFalsePositive {
		return nil, invalid(`decision must be "real_secret" or "false_positive"`)
	}
	if err := s.repo.SetDecision(ctx, req.Platform, req.FindingID, req.Decision, s.timestamp(), actor(email)); err != nil {
		return nil, err
	}
	return &m.OKResponse{OK: true}, nil
}

// DeepScanStatus reports the deep scan of one repository. A repository that
// was never deep-scanned answers {"status":"not_started"}, as the scanner does.
func (s *Service) DeepScanStatus(ctx context.Context, role, clientID, repository string) (interface{}, error) {
	if err := checkText("client_id", clientID, maxClientID, true); err != nil {
		return nil, err
	}
	if err := checkText("repository", repository, maxRepository, true); err != nil {
		return nil, err
	}
	scan, err := s.repo.DeepScan(ctx, clientID, repository)
	if err != nil {
		return nil, err
	}
	if scan == nil {
		return map[string]string{"status": m.DeepScanNotStarted}, nil
	}
	if scan.Error != nil && !CanSeeScanErrors(role) {
		msg := "The deep scan failed. An administrator can see the reason."
		scan.Error = &msg
	}
	return scan, nil
}
