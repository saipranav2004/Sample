package secscan

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"

	m "nhi-backend-api/internal/models/secscan"
)

type fakeRepo struct {
	keyExists   bool
	upserted    *m.AllowlistEntry
	deleted     bool
	decision    []string
	decisionErr error
	scan        *m.DeepScan
	filter      m.FindingsFilter
}

func (f *fakeRepo) ListFindings(_ context.Context, filter m.FindingsFilter) ([]m.Finding, error) {
	f.filter = filter
	return []m.Finding{{FindingID: "a"}, {FindingID: "b"}}, nil
}
func (f *fakeRepo) FindingKeyExists(context.Context, m.AllowlistKey) (bool, error) {
	return f.keyExists, nil
}
func (f *fakeRepo) SetDecision(_ context.Context, platform, id, decision, at, by string) error {
	f.decision = []string{platform, id, decision, at, by}
	return f.decisionErr
}
func (f *fakeRepo) ListAllowlist(context.Context, string) ([]m.AllowlistEntry, error) {
	return []m.AllowlistEntry{}, nil
}
func (f *fakeRepo) UpsertDashboardEntry(_ context.Context, e m.AllowlistEntry) (m.AllowlistEntry, error) {
	f.upserted = &e
	e.Source = m.SourceDashboard
	return e, nil
}
func (f *fakeRepo) DeleteDashboardEntry(context.Context, m.AllowlistKey) (bool, error) {
	return f.deleted, nil
}
func (f *fakeRepo) DeepScan(context.Context, string, string) (*m.DeepScan, error) {
	return f.scan, nil
}

func fixedService(repo Repository) *Service {
	s := NewService(repo)
	s.now = func() time.Time { return time.Date(2026, 9, 23, 11, 12, 25, 0, time.FixedZone("IST", 5*3600+1800)) }
	return s
}

var validReq = m.AllowlistRequest{ClientID: "c", FilePath: "config.py", Detector: "aws_access_key_id", Redacted: "AKIA****MNOP", Reason: " rotated "}

func isValidation(err error) bool {
	var v *ValidationError
	return errors.As(err, &v)
}

func TestFindingsCountsAndValidatesFilters(t *testing.T) {
	repo := &fakeRepo{}
	s := fixedService(repo)
	out, err := s.Findings(context.Background(), m.FindingsFilter{ClientID: "c", Platform: "github"})
	if err != nil || out.Count != 2 || len(out.Findings) != 2 {
		t.Fatalf("findings: %+v %v", out, err)
	}
	if repo.filter.Platform != "github" || repo.filter.ClientID != "c" {
		t.Fatalf("filter not passed: %+v", repo.filter)
	}
	if _, err := s.Findings(context.Background(), m.FindingsFilter{Platform: "gitlab"}); !isValidation(err) {
		t.Fatalf("unknown platform must be a validation error, got %v", err)
	}
	if _, err := s.Findings(context.Background(), m.FindingsFilter{ClientID: strings.Repeat("x", 201)}); !isValidation(err) {
		t.Fatalf("long client_id must be rejected, got %v", err)
	}
}

func TestDismissNeedsReviewerRoleAndExistingFinding(t *testing.T) {
	repo := &fakeRepo{keyExists: true}
	s := fixedService(repo)
	for _, role := range []string{"developer", "auditor", "", "viewer"} {
		if _, err := s.Dismiss(context.Background(), role, "x@y", validReq); !errors.Is(err, ErrForbidden) {
			t.Fatalf("role %q must be forbidden, got %v", role, err)
		}
	}
	out, err := s.Dismiss(context.Background(), "Team_Lead", "lead@example.com", validReq)
	if err != nil || !out.OK || out.Entry == nil {
		t.Fatalf("dismiss: %+v %v", out, err)
	}
	e := repo.upserted
	if e.DismissedBy != "lead@example.com" || e.Reason != "rotated" || e.DismissedAt != "2026-09-23T05:42:25+00:00" {
		t.Fatalf("entry not attributed/timestamped as the scanner stores it: %+v", e)
	}
	repo.keyExists = false
	if _, err := s.Dismiss(context.Background(), "admin", "a@b", validReq); !errors.Is(err, m.ErrNotFound) {
		t.Fatalf("dismissing a key with no finding must be not found, got %v", err)
	}
}

func TestDismissValidatesEveryKeyField(t *testing.T) {
	s := fixedService(&fakeRepo{keyExists: true})
	cases := []m.AllowlistRequest{
		{FilePath: "f", Detector: "d", Redacted: "r"},
		{ClientID: "c", Detector: "d", Redacted: "r"},
		{ClientID: "c", FilePath: "f", Redacted: "r"},
		{ClientID: "c", FilePath: "f", Detector: "d"},
		{ClientID: "c", FilePath: "f", Detector: "d", Redacted: strings.Repeat("r", 501)},
		{ClientID: "c", FilePath: "f", Detector: "d", Redacted: "r", Reason: strings.Repeat("y", 1001)},
		{ClientID: "c\x00", FilePath: "f", Detector: "d", Redacted: "r"},
	}
	for i, c := range cases {
		if _, err := s.Dismiss(context.Background(), "admin", "a@b", c); !isValidation(err) {
			t.Fatalf("case %d must be a validation error, got %v", i, err)
		}
	}
}

func TestRestoreReportsWhetherAnythingWasRemoved(t *testing.T) {
	repo := &fakeRepo{deleted: false}
	s := fixedService(repo)
	out, err := s.Restore(context.Background(), "admin", validReq)
	if err != nil || out.OK {
		t.Fatalf("nothing matched must be ok:false without error: %+v %v", out, err)
	}
	repo.deleted = true
	if out, _ := s.Restore(context.Background(), "admin", validReq); !out.OK {
		t.Fatal("a removed row must be ok:true")
	}
	if _, err := s.Restore(context.Background(), "auditor", validReq); !errors.Is(err, ErrForbidden) {
		t.Fatalf("auditor must not restore, got %v", err)
	}
}

func TestDecide(t *testing.T) {
	repo := &fakeRepo{}
	s := fixedService(repo)
	req := m.DecisionRequest{FindingID: "c/r/abc/f.py:3:jwt", Platform: "github", Decision: "false_positive", DecidedBy: "spoofed"}
	if _, err := s.Decide(context.Background(), "admin", "a@b.c", req); err != nil {
		t.Fatal(err)
	}
	if strings.Join(repo.decision, "|") != "github|c/r/abc/f.py:3:jwt|false_positive|2026-09-23T05:42:25+00:00|a@b.c" {
		t.Fatalf("decision written wrongly (decided_by must come from the token): %v", repo.decision)
	}
	for _, bad := range []m.DecisionRequest{
		{FindingID: "x", Platform: "github", Decision: "maybe"},
		{FindingID: "x", Decision: "real_secret"},
		{Platform: "github", Decision: "real_secret"},
	} {
		if _, err := s.Decide(context.Background(), "admin", "a", bad); !isValidation(err) {
			t.Fatalf("%+v must be rejected, got %v", bad, err)
		}
	}
	repo.decisionErr = m.ErrNotFound
	if _, err := s.Decide(context.Background(), "admin", "a", req); !errors.Is(err, m.ErrNotFound) {
		t.Fatalf("missing finding must be not found, got %v", err)
	}
}

func TestDeepScanStatus(t *testing.T) {
	repo := &fakeRepo{}
	s := fixedService(repo)
	out, err := s.DeepScanStatus(context.Background(), "developer", "c", "repo")
	if err != nil || out.(map[string]string)["status"] != "not_started" {
		t.Fatalf("never-requested scan: %v %v", out, err)
	}
	raw := "AccessDeniedException on arn:aws:iam::123:role/x"
	failed := "2026-09-22T10:15:17+00:00"
	repo.scan = &m.DeepScan{Status: m.DeepScanFailed, FailedAt: &failed, Error: &raw}
	out, _ = s.DeepScanStatus(context.Background(), "developer", "c", "repo")
	if *out.(*m.DeepScan).Error == raw {
		t.Fatal("raw scanner errors must be hidden from non-admins")
	}
	repo.scan = &m.DeepScan{Status: m.DeepScanFailed, FailedAt: &failed, Error: &raw}
	out, _ = s.DeepScanStatus(context.Background(), "admin", "c", "repo")
	if *out.(*m.DeepScan).Error != raw {
		t.Fatal("admins see the raw error")
	}
	if _, err := s.DeepScanStatus(context.Background(), "admin", "", "repo"); !isValidation(err) {
		t.Fatalf("client_id required, got %v", err)
	}
	if _, err := s.DeepScanStatus(context.Background(), "admin", "c", ""); !isValidation(err) {
		t.Fatalf("repository required, got %v", err)
	}
}

func TestDeepScanStatusDerivation(t *testing.T) {
	done, failed := "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:01+00:00"
	if m.DeepScanStatus(nil, nil) != m.DeepScanRunning ||
		m.DeepScanStatus(&done, nil) != m.DeepScanComplete ||
		m.DeepScanStatus(&done, &failed) != m.DeepScanFailed ||
		m.DeepScanStatus(nil, &failed) != m.DeepScanFailed {
		t.Fatal("status must be failed > complete > running")
	}
}
