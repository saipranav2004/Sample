package inventory

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
)

// Order mirrors the 28 columns confirmed by the user's live schema audit.
// A CSV JSONB cell is a compact JSON string; SQL NULL is an empty cell.
var exportColumns = []string{
	"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "deleted_at",
	"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible", "tags", "owner", "environment",
	"parent_arn", "cloudtrail_creator_arn", "discovery_source", "scan_id", "type_attributes", "raw_api_response",
	"created_at", "updated_at",
}

const maxExportBytes = 50 << 20

func (s *Service) Export(ctx context.Context, f m.ExportFilter) (*m.ExportPayload, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.Format != "csv" && f.Format != "json" {
		return nil, ErrIncomplete
	}
	rows, err := s.reader.ExportRows(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.ExportPayload{Filename: "identities-export." + f.Format}
	if f.Format == "json" {
		out.ContentType = "application/json; charset=utf-8"
		out.Body, err = json.Marshal(rows)
		if err != nil {
			return nil, ErrIncomplete
		}
		if len(out.Body)+1 > maxExportBytes {
			return nil, m.ErrExportTooLarge
		}
		out.Body = append(out.Body, '\n')
		return out, nil
	}
	var buf bytes.Buffer
	writer := csv.NewWriter(&buf)
	if err := writer.Write(exportColumns); err != nil {
		return nil, err
	}
	for _, record := range rows {
		var obj map[string]json.RawMessage
		if json.Unmarshal(record, &obj) != nil || obj == nil {
			return nil, ErrIncomplete
		}
		line := make([]string, 0, len(exportColumns))
		for _, col := range exportColumns {
			value, exists := obj[col]
			if !exists {
				return nil, ErrIncomplete
			}
			if len(value) == 0 || string(value) == "null" {
				line = append(line, "")
				continue
			}
			var v string
			if value[0] == '"' {
				if json.Unmarshal(value, &v) != nil {
					return nil, ErrIncomplete
				}
			} else {
				v = string(value)
			}
			// Prefix Excel/Sheets formula triggers, including whitespace-hidden ones.
			trimmed := strings.TrimLeft(v, " \t\r\n")
			if len(trimmed) > 0 && strings.ContainsRune("=+-@", rune(trimmed[0])) {
				v = "'" + v
			}
			line = append(line, v)
		}
		if err := writer.Write(line); err != nil {
			return nil, err
		}
		if buf.Len() > maxExportBytes {
			return nil, m.ErrExportTooLarge
		}
	}
	writer.Flush()
	if err := writer.Error(); err != nil {
		return nil, err
	}
	if buf.Len() > maxExportBytes {
		return nil, m.ErrExportTooLarge
	}
	out.ContentType = "text/csv; charset=utf-8"
	out.Body = buf.Bytes()
	return out, nil
}
