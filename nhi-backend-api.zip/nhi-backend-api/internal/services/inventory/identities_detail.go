package inventory

import (
	"context"
	"encoding/json"
	inventory "nhi-backend-api/internal/models/inventory"
	"strings"
)

func (s *Service) Detail(ctx context.Context, id string, ids []string) (*inventory.DetailResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	out, err := s.reader.Detail(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if out == nil || !strings.EqualFold(out.ID, id) || out.AccountID == "" || out.DeletedAt != nil ||
		!jsonObjectOrNull(out.Ownership.Tags) || !jsonObjectOrNull(out.TypeAttributes) ||
		!jsonArrayOrNull(out.Network.SecurityGroupIDs) ||
		(len(out.RawAPIResponse) > 0 && !json.Valid(out.RawAPIResponse)) {
		return nil, ErrIncomplete
	}
	return out, nil
}
