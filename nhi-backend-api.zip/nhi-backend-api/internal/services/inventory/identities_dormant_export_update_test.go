package inventory

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
	"testing"
	"time"
)

type extendedReaderStub struct {
	readerStub
	dormant  *m.DormantResponse
	exported []json.RawMessage
	update   map[string]string
	fail     error
}

func (s *extendedReaderStub) Dormant(_ context.Context, _ m.DormantFilter, _ time.Time) (*m.DormantResponse, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return s.dormant, nil
}
func (s *extendedReaderStub) ExportRows(_ context.Context, _ m.ExportFilter) ([]json.RawMessage, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return s.exported, nil
}
func (s *extendedReaderStub) Update(_ context.Context, id string, _ []string, updates map[string]string) (string, error) {
	if s.fail != nil {
		return "", s.fail
	}
	s.update = updates
	return id, nil
}
func TestDormantServiceAndNullActivity(t *testing.T) {
	now := time.Now().UTC()
	stub := &extendedReaderStub{dormant: &m.DormantResponse{ThresholdDays: 90, TotalDormant: 1, Data: []m.DormantItem{{ID: "current", IdentityType: "lambda_function", LastActivityAt: now.Add(-91 * 24 * time.Hour)}}}}
	result, err := NewService(stub).Dormant(context.Background(), m.DormantFilter{Scope: m.Scope{AllowedAccountIDs: []string{"123456789012"}}, Days: 90, Page: 1, Limit: 10})
	if err != nil || result.TotalDormant != 1 || result.Data[0].DaysInactive < 90 {
		t.Fatalf("dormant %+v %v", result, err)
	}
	stub.dormant.Data[0].LastActivityAt = now
	if _, err := NewService(stub).Dormant(context.Background(), m.DormantFilter{Scope: m.Scope{AllowedAccountIDs: []string{"123456789012"}}, Days: 90, Page: 1, Limit: 10}); !errors.Is(err, ErrIncomplete) {
		t.Fatalf("recent identity erroneously dormant: %v", err)
	}
}
func TestExportJSONCSVAndFormulaEscaping(t *testing.T) {
	obj := map[string]any{}
	for _, col := range exportColumns {
		obj[col] = nil
	}
	obj["id"] = "00000000-0000-0000-0000-000000000001"
	obj["name"] = "=HYPERLINK(\"http://bad.invalid\")"
	obj["tags"] = map[string]any{"team": "security"}
	raw, err := json.Marshal(obj)
	if err != nil {
		t.Fatal(err)
	}
	stub := &extendedReaderStub{exported: []json.RawMessage{raw}}
	scope := m.Scope{AllowedAccountIDs: []string{"123456789012"}}
	for _, format := range []string{"json", "csv"} {
		out, err := NewService(stub).Export(context.Background(), m.ExportFilter{ListFilter: m.ListFilter{Scope: scope}, Format: format})
		if err != nil || out == nil || out.Filename != "identities-export."+format {
			t.Fatalf("%s: %+v %v", format, out, err)
		}
		if format == "json" {
			if !strings.Contains(string(out.Body), `"raw_api_response":null`) {
				t.Fatalf("full JSON fields: %s", out.Body)
			}
			continue
		}
		parsed, err := csv.NewReader(strings.NewReader(string(out.Body))).ReadAll()
		if err != nil || len(parsed) != 2 || len(parsed[0]) != 28 || len(parsed[1]) != 28 {
			t.Fatalf("csv columns: %v %v", parsed, err)
		}
		if parsed[1][2][0] != '\'' {
			t.Fatalf("CSV formula was not escaped: %q", parsed[1][2])
		}
	}
	stub.fail = m.ErrExportTooLarge
	if _, err := NewService(stub).Export(context.Background(), m.ExportFilter{ListFilter: m.ListFilter{Scope: scope}, Format: "json"}); !errors.Is(err, m.ErrExportTooLarge) {
		t.Fatalf("large export: %v", err)
	}
}
func TestUpdateServiceAllowlist(t *testing.T) {
	const id = "00000000-0000-0000-0000-000000000001"
	value := "security-team"
	class := "break_glass"
	stub := &extendedReaderStub{}
	scope := []string{"123456789012"}
	out, err := NewService(stub).Update(context.Background(), id, scope, m.UpdatePatch{FunctionalClass: &class, Owner: &value})
	if err != nil || out.Message != "Updated" || len(out.UpdatedFields) != 2 || stub.update["owner"] != "security-team" {
		t.Fatalf("patch %+v %v", out, err)
	}
	blank := " "
	if _, err := NewService(stub).Update(context.Background(), id, scope, m.UpdatePatch{Owner: &blank}); !errors.Is(err, ErrIncomplete) {
		t.Fatalf("blank patch: %v", err)
	}
	if _, err := NewService(stub).Update(context.Background(), id, scope, m.UpdatePatch{}); !errors.Is(err, ErrIncomplete) {
		t.Fatalf("empty patch: %v", err)
	}
}
