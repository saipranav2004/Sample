package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Counts(ctx context.Context, f m.CountsFilter) (*m.CountsResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	rows, err := s.reader.Counts(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.CountsResponse{ByType: map[string]int64{}, ByClass: map[string]int64{}}
	for _, r := range rows {
		if r.Status == "" || r.IdentityType == "" || r.FunctionalClass == "" {
			return nil, ErrIncomplete
		}
		if out.Total, err = checkedAdd(out.Total, r.Count); err != nil {
			return nil, err
		}
		switch r.Status {
		case "active":
			out.Active, err = checkedAdd(out.Active, r.Count)
		case "stopped":
			out.Stopped, err = checkedAdd(out.Stopped, r.Count)
		case "terminated":
			out.Terminated, err = checkedAdd(out.Terminated, r.Count)
		}
		if err != nil {
			return nil, err
		}
		if out.ByType[r.IdentityType], err = checkedAdd(out.ByType[r.IdentityType], r.Count); err != nil {
			return nil, err
		}
		if out.ByClass[r.FunctionalClass], err = checkedAdd(out.ByClass[r.FunctionalClass], r.Count); err != nil {
			return nil, err
		}
	}
	return out, nil
}
