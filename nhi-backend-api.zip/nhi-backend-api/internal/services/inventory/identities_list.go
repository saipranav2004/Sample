package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"nhi-backend-api/internal/models/inventory"
	"time"
)

var (
	ErrSourceUnavailable = errors.New("inventory source unavailable")
	ErrIncomplete        = errors.New("inventory source incomplete")
	ErrNotFound          = errors.New("identity not found")
)

type Reader interface {
	List(context.Context, inventory.ListFilter) (*inventory.ListResponse, error)
	Detail(context.Context, string, []string) (*inventory.DetailResponse, error)
	Counts(context.Context, inventory.CountsFilter) ([]inventory.CountRow, error)
	Attributes(context.Context, string, []string) (*inventory.AttributesResponse, error)
	Timeline(context.Context, string, []string) (*inventory.TimelineRecord, error)
	Grouped(context.Context, inventory.GroupFilter) ([]inventory.GroupRow, error)
	Dormant(context.Context, inventory.DormantFilter, time.Time) (*inventory.DormantResponse, error)
	ExportRows(context.Context, inventory.ExportFilter) ([]json.RawMessage, error)
	Update(context.Context, string, []string, map[string]string) (string, error)
}
type Service struct{ reader Reader }

func NewService(r Reader) *Service { return &Service{reader: r} }
func (s *Service) check(ids []string) error {
	if s == nil || s.reader == nil || len(ids) == 0 {
		return ErrSourceUnavailable
	}
	return nil
}
func (s *Service) List(ctx context.Context, f inventory.ListFilter) (*inventory.ListResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	result, err := s.reader.List(ctx, f)
	if err != nil {
		return nil, err
	}
	if result == nil || result.Data == nil || result.Total < 0 || result.Page != f.Page || result.Limit != f.Limit || int64(len(result.Data)) > f.Limit {
		return nil, ErrIncomplete
	}
	for _, item := range result.Data {
		if item.ID == "" || item.AccountID == "" || !jsonObjectOrNull(item.Tags) {
			return nil, ErrIncomplete
		}
	}
	return result, nil
}

// JSONB is syntactically valid in PostgreSQL, but a JSON scalar/array is not
// an ownership tags map or type-attributes object as required by the PDF.
func jsonObjectOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var obj map[string]json.RawMessage
	return json.Unmarshal(data, &obj) == nil && obj != nil
}
func jsonArrayOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var arr []json.RawMessage
	return json.Unmarshal(data, &arr) == nil && arr != nil
}
func validCount(n int64) error {
	if n < 0 {
		return ErrIncomplete
	}
	return nil
}
func checkedAdd(a, b int64) (int64, error) {
	if err := validCount(b); err != nil {
		return 0, err
	}
	if b > math.MaxInt64-a {
		return 0, fmt.Errorf("%w: count overflow", ErrIncomplete)
	}
	return a + b, nil
}
