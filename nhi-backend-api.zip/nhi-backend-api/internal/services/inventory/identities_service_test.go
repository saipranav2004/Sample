package inventory

import (
	"context"
	"encoding/json"
	"errors"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
	"testing"
	"time"
)

type readerStub struct {
	rows     []m.CountRow
	grouped  []m.GroupRow
	timeline *m.TimelineRecord
	detail   *m.DetailResponse
	list     *m.ListResponse
	attrs    *m.AttributesResponse
}

func (s readerStub) List(context.Context, m.ListFilter) (*m.ListResponse, error) { return s.list, nil }
func (s readerStub) Detail(context.Context, string, []string) (*m.DetailResponse, error) {
	return s.detail, nil
}
func (s readerStub) Counts(context.Context, m.CountsFilter) ([]m.CountRow, error) { return s.rows, nil }
func (s readerStub) Attributes(context.Context, string, []string) (*m.AttributesResponse, error) {
	return s.attrs, nil
}
func (s readerStub) Timeline(context.Context, string, []string) (*m.TimelineRecord, error) {
	return s.timeline, nil
}
func (s readerStub) Dormant(context.Context, m.DormantFilter, time.Time) (*m.DormantResponse, error) {
	return &m.DormantResponse{ThresholdDays: 90, Data: []m.DormantItem{}}, nil
}
func (s readerStub) ExportRows(context.Context, m.ExportFilter) ([]json.RawMessage, error) {
	return []json.RawMessage{}, nil
}
func (s readerStub) Update(_ context.Context, id string, _ []string, _ map[string]string) (string, error) {
	return id, nil
}
func (s readerStub) Grouped(context.Context, m.GroupFilter) ([]m.GroupRow, error) {
	return s.grouped, nil
}
func TestInventoryServiceBoundaries(t *testing.T) {
	const id = "00000000-0000-0000-0000-000000000001"
	scope := m.Scope{AllowedAccountIDs: []string{"123456789012"}}
	s := NewService(readerStub{rows: []m.CountRow{{Status: "active", IdentityType: "lambda", FunctionalClass: "service", Count: 2}, {Status: "unknown", IdentityType: "ec2", FunctionalClass: "unclassified", Count: 1}}})
	counts, err := s.Counts(context.Background(), m.CountsFilter{Scope: scope})
	if err != nil || counts.Total != 3 || counts.Active != 2 || counts.ByType["ec2"] != 1 {
		t.Fatalf("counts %+v %v", counts, err)
	}
	if _, err := s.Counts(context.Background(), m.CountsFilter{}); !errors.Is(err, ErrSourceUnavailable) {
		t.Fatalf("unscoped counts: %v", err)
	}
	if _, err := NewService(readerStub{}).Counts(context.Background(), m.CountsFilter{Scope: scope}); !errors.Is(err, ErrIncomplete) {
		t.Fatalf("nil counts must not mean zero: %v", err)
	}
	detail := &m.DetailResponse{ID: id, AccountID: "123456789012", Ownership: m.Ownership{Tags: json.RawMessage(`{"env":"prod"}`)}, Network: m.Network{SecurityGroupIDs: json.RawMessage(`["sg-1"]`)}, TypeAttributes: json.RawMessage(`{"runtime":"go"}`), RawAPIResponse: json.RawMessage(`{"ok":true}`)}
	result, err := NewService(readerStub{detail: detail}).Detail(context.Background(), id, scope.AllowedAccountIDs)
	if err != nil || result.ID != id {
		t.Fatalf("detail %+v %v", result, err)
	}
	// PostgreSQL's uuid output is canonical lower case; an upper-case path
	// spelling of the same UUID must not spuriously become a 503.
	letterID := "aaaaaaaa-0000-0000-0000-000000000001"
	detail.ID = letterID
	if _, err := NewService(readerStub{detail: detail}).Detail(context.Background(), strings.ToUpper(letterID), scope.AllowedAccountIDs); err != nil {
		t.Fatalf("uppercase UUID lookup: %v", err)
	}
	detail.ID = id
	removed := time.Now()
	detail.DeletedAt = &removed
	if _, err := NewService(readerStub{detail: detail}).Detail(context.Background(), id, scope.AllowedAccountIDs); !errors.Is(err, ErrIncomplete) {
		t.Fatalf("deleted adapter row accepted: %v", err)
	}
	first := time.Now().UTC().Add(-11 * 24 * time.Hour)
	last := time.Now().UTC().Add(-time.Hour)
	event, err := NewService(readerStub{timeline: &m.TimelineRecord{ARN: "arn:sample", FirstSeenAt: first, LastSeenAt: last}}).Timeline(context.Background(), id, scope.AllowedAccountIDs)
	if err != nil || len(event.Events) != 2 || event.DaysSinceLastActivity != nil || event.AgeDays < 10 {
		t.Fatalf("nullable timeline %+v %v", event, err)
	}
	group := []m.GroupRow{{FunctionalClass: "service", Count: 7, Identity: m.GroupIdentity{ID: id}}, {FunctionalClass: "unclassified", Count: 2, Identity: m.GroupIdentity{ID: id}}}
	grouped, err := NewService(readerStub{grouped: group}).Grouped(context.Background(), m.GroupFilter{Scope: scope, LimitPerClass: 1})
	if err != nil || len(grouped.Groups) != 2 || grouped.Groups[0].Count != 7 || len(grouped.Groups[0].Identities) != 1 {
		t.Fatalf("grouped %+v %v", grouped, err)
	}
}
