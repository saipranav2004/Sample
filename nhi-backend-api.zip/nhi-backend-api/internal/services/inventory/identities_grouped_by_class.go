package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Grouped(ctx context.Context, f m.GroupFilter) (*m.GroupedResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	rows, err := s.reader.Grouped(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.GroupedResponse{Groups: []m.ClassGroup{}}
	idx := map[string]int{}
	for _, r := range rows {
		if r.FunctionalClass == "" || r.Count <= 0 || r.Identity.ID == "" {
			return nil, ErrIncomplete
		}
		n, ok := idx[r.FunctionalClass]
		if !ok {
			n = len(out.Groups)
			idx[r.FunctionalClass] = n
			out.Groups = append(out.Groups, m.ClassGroup{FunctionalClass: r.FunctionalClass, Count: r.Count, Identities: []m.GroupIdentity{}})
		}
		if out.Groups[n].Count != r.Count || int64(len(out.Groups[n].Identities)) >= f.LimitPerClass {
			return nil, ErrIncomplete
		}
		out.Groups[n].Identities = append(out.Groups[n].Identities, r.Identity)
	}
	return out, nil
}
