package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

func (s *Service) Dormant(ctx context.Context, f m.DormantFilter) (*m.DormantResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.Days < 1 || f.Days > 3650 || f.Page < 1 || f.Page > 1_000_000 || f.Limit < 1 || f.Limit > 200 {
		return nil, ErrIncomplete
	}
	now := time.Now().UTC()
	out, err := s.reader.Dormant(ctx, f, now)
	if err != nil {
		return nil, err
	}
	if out == nil || out.Data == nil || out.ThresholdDays != f.Days || out.TotalDormant < 0 || int64(len(out.Data)) > f.Limit || int64(len(out.Data)) > out.TotalDormant {
		return nil, ErrIncomplete
	}
	for i := range out.Data {
		item := &out.Data[i]
		if item.ID == "" || item.IdentityType == "" || item.LastActivityAt.IsZero() || !item.LastActivityAt.Before(now.Add(-time.Duration(f.Days)*24*time.Hour)) {
			return nil, ErrIncomplete
		}
		item.DaysInactive = int64(now.Sub(item.LastActivityAt).Hours() / 24)
	}
	return out, nil
}
