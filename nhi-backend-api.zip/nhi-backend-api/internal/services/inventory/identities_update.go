package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"regexp"
	"strings"
)

var classPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,99}$`)

// Update changes only PDF-approved fields. Caller authorization is resolved
// before service invocation; the repository repeats the scope in UPDATE SQL.
func (s *Service) Update(ctx context.Context, id string, ids []string, patch m.UpdatePatch) (*m.UpdateResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	fields := make(map[string]string, 3)
	for _, p := range []struct {
		name  string
		value *string
	}{
		{"functional_class", patch.FunctionalClass}, {"owner", patch.Owner}, {"environment", patch.Environment},
	} {
		if p.value == nil {
			continue
		}
		value := strings.TrimSpace(*p.value)
		if value == "" || len(value) > 256 || strings.ContainsAny(value, "\x00\r\n") || p.name == "functional_class" && !classPattern.MatchString(value) {
			return nil, ErrIncomplete
		}
		fields[p.name] = value
	}
	if len(fields) == 0 {
		return nil, ErrIncomplete
	}
	returned, err := s.reader.Update(ctx, id, ids, fields)
	if err != nil {
		return nil, err
	}
	if !strings.EqualFold(returned, id) {
		return nil, ErrIncomplete
	}
	out := &m.UpdateResponse{ID: returned, Message: "Updated", UpdatedFields: []string{}}
	for _, name := range []string{"functional_class", "owner", "environment"} {
		if _, ok := fields[name]; ok {
			out.UpdatedFields = append(out.UpdatedFields, name)
		}
	}
	return out, nil
}
