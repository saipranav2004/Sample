package inventory

import (
	"context"
	"encoding/json"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Attributes(ctx context.Context, id string, ids []string) (*m.AttributesResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	out, err := s.reader.Attributes(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if out == nil || out.IdentityType == "" {
		return nil, ErrIncomplete
	}
	if len(out.TypeAttributes) > 0 && string(out.TypeAttributes) != "null" {
		var shape map[string]json.RawMessage
		if json.Unmarshal(out.TypeAttributes, &shape) != nil || shape == nil {
			return nil, ErrIncomplete
		}
	}
	return out, nil
}
