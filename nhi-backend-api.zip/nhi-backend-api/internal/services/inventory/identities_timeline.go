package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

func (s *Service) Timeline(ctx context.Context, id string, ids []string) (*m.TimelineResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	row, err := s.reader.Timeline(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if row == nil || row.ARN == "" {
		return nil, ErrIncomplete
	}
	now := time.Now().UTC()
	if row.FirstSeenAt.After(now) || row.LastSeenAt.After(now) || row.LastSeenAt.Before(row.FirstSeenAt) {
		return nil, ErrIncomplete
	}
	out := &m.TimelineResponse{IdentityARN: row.ARN, Events: []m.TimelineEvent{{Event: "first_discovered", Timestamp: row.FirstSeenAt.UTC()}}, AgeDays: int64(now.Sub(row.FirstSeenAt).Hours() / 24)}
	if row.LastActivityAt != nil {
		if row.LastActivityAt.After(now) {
			return nil, ErrIncomplete
		}
		n := int64(now.Sub(*row.LastActivityAt).Hours() / 24)
		out.DaysSinceLastActivity = &n
		out.Events = append(out.Events, m.TimelineEvent{Event: "last_activity", Timestamp: row.LastActivityAt.UTC()})
	}
	out.Events = append(out.Events, m.TimelineEvent{Event: "last_confirmed", Timestamp: row.LastSeenAt.UTC()})
	return out, nil
}
