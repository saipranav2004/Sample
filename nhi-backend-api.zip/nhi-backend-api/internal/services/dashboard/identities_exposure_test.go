package dashboard

import (
	"context"
	"errors"
	"testing"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type exposureStub struct {
	f      m.ExposureFilter
	cutoff time.Time
	rows   []m.ExposureCountRow
}

func (*exposureStub) ByClass(context.Context, m.ClassFilter) ([]m.FunctionalClassCount, error) {
	return nil, nil
}
func (*exposureStub) ByAccountIdentityCounts(context.Context, m.AccountFilter) ([]m.AccountIdentityCount, error) {
	return nil, nil
}
func (*exposureStub) ByRegionIdentityCounts(context.Context, m.RegionFilter) ([]m.RegionIdentityCount, error) {
	return nil, nil
}
func (s *exposureStub) ExposureCounts(_ context.Context, f m.ExposureFilter, cutoff time.Time) ([]m.ExposureCountRow, error) {
	s.f, s.cutoff = f, cutoff
	return s.rows, nil
}

func TestExposureService(t *testing.T) {
	stub := &exposureStub{rows: []m.ExposureCountRow{
		{IdentityType: "lambda_function", PublicCount: 2, DormantCount: 1, NoActivityCount: 3, MissingOwnerCount: 4, MissingEnvCount: 5},
		{IdentityType: "ec2_instance", PublicCount: 5, DormantCount: 4, MissingEnvCount: 1},
	}}
	svc := NewDashboardBreakdownService(stub)
	before := time.Now().UTC().Add(-90 * 24 * time.Hour)
	out, err := svc.Exposure(context.Background(), m.ExposureFilter{AccountID: "123456789012", AllowedAccountIDs: []string{"123456789012"}})
	if err != nil || out.PubliclyAccessible.Total != 7 || out.Dormant90d.Total != 5 ||
		out.NoActivityTracked != 3 || out.MissingOwnerTag != 4 || out.MissingEnvironmentTag != 6 ||
		out.NotInIAC != nil || len(out.PubliclyAccessible.ByType) != 2 ||
		out.PubliclyAccessible.ByType[0].IdentityType != "ec2_instance" ||
		out.Dormant90d.ByType[0].IdentityType != "ec2_instance" || stub.f.AccountID != "123456789012" {
		t.Fatalf("exposure: %+v, err=%v", out, err)
	}
	if stub.cutoff.Before(before) || stub.cutoff.After(time.Now().UTC().Add(-90*24*time.Hour)) {
		t.Fatalf("bad cutoff: %s", stub.cutoff)
	}
	stub.rows = nil
	out, err = svc.Exposure(context.Background(), m.ExposureFilter{AllowedAccountIDs: []string{"123456789012"}})
	if err != nil || out.NotInIAC != nil || out.PubliclyAccessible.ByType == nil || out.Dormant90d.ByType == nil || out.PubliclyAccessible.Total != 0 {
		t.Fatalf("empty exposure: %+v, %v", out, err)
	}
	if _, err := svc.Exposure(context.Background(), m.ExposureFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped exposure: %v", err)
	}
	stub.rows = []m.ExposureCountRow{{PublicCount: -1}}
	if _, err := svc.Exposure(context.Background(), m.ExposureFilter{AllowedAccountIDs: []string{"123456789012"}}); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("negative count not rejected: %v", err)
	}
}
