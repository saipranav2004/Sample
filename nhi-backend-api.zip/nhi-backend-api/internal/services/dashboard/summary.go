package dashboard

import (
	"context"
	"math"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type dashboardSummaryReader interface {
	SummaryIdentityCounts(context.Context, m.SummaryFilter, time.Time, time.Time) ([]m.SummaryIdentityRow, error)
	SummaryScanData(context.Context, m.SummaryFilter) (m.SummaryScanData, error)
}

// Summary returns a measured-and-null PDF #1 response. Credentials are
// measured from the configured scanner repository; unrotated credentials,
// scan duration and regional scan coverage remain unmeasured. Region-filtered
// scan cards are null, though region-filtered credential cards are measured.
func (s *DashboardBreakdownService) Summary(ctx context.Context, f m.SummaryFilter) (*m.SummaryResponse, error) {
	if s == nil || s.identities == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	reader, ok := s.identities.(dashboardSummaryReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	now := time.Now().UTC()
	rows, err := reader.SummaryIdentityCounts(ctx, f, now.Add(-24*time.Hour), now)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.SummaryResponse{IdentitiesByStatus: make(map[string]int64)}
	seen := make(map[string]bool, len(rows))
	for _, row := range rows {
		if row.Status == "" || seen[row.Status] {
			return nil, ErrDashboardSourceIncomplete
		}
		seen[row.Status] = true
		for _, count := range []int64{row.CurrentCount, row.New24h, row.Removed24h} {
			if err := checkCount(count, "summary identity"); err != nil {
				return nil, err
			}
		}
		if row.CurrentCount > math.MaxInt64-out.TotalIdentities ||
			row.New24h > math.MaxInt64-out.NewIdentitiesLast24h ||
			row.Removed24h > math.MaxInt64-out.RemovedIdentitiesLast24h {
			return nil, ErrDashboardSourceIncomplete
		}
		out.TotalIdentities += row.CurrentCount
		out.NewIdentitiesLast24h += row.New24h
		out.RemovedIdentitiesLast24h += row.Removed24h
		if row.CurrentCount > 0 {
			out.IdentitiesByStatus[row.Status] = row.CurrentCount
		}
	}
	if s.credentials != nil {
		credentialRows, err := s.credentials.SummaryCredentialCounts(ctx, f, now.Add(-24*time.Hour), now)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialRows == nil { // nil,nil cannot stand for measured zero
			return nil, ErrDashboardSourceIncomplete
		}
		byStatus := make(map[string]int64, len(credentialRows))
		var total, new24h, expiring, stale, unknownUsage int64
		for _, row := range credentialRows {
			if row.Status == "" {
				return nil, ErrDashboardSourceIncomplete
			}
			if _, duplicate := byStatus[row.Status]; duplicate {
				return nil, ErrDashboardSourceIncomplete
			}
			for _, n := range []int64{row.CurrentCount, row.New24h, row.Expiring30d, row.StaleKeys90d, row.UnknownKeyUsage} {
				if err := checkCount(n, "summary credential"); err != nil {
					return nil, err
				}
			}
			if row.CurrentCount > math.MaxInt64-total || row.New24h > math.MaxInt64-new24h ||
				row.Expiring30d > math.MaxInt64-expiring || row.StaleKeys90d > math.MaxInt64-stale ||
				row.UnknownKeyUsage > math.MaxInt64-unknownUsage ||
				row.New24h > row.CurrentCount || row.Expiring30d > row.CurrentCount ||
				row.StaleKeys90d > row.CurrentCount || row.UnknownKeyUsage > row.CurrentCount ||
				row.StaleKeys90d > row.CurrentCount-row.UnknownKeyUsage {
				return nil, ErrDashboardSourceIncomplete
			}
			byStatus[row.Status] = row.CurrentCount
			total += row.CurrentCount
			new24h += row.New24h
			expiring += row.Expiring30d
			stale += row.StaleKeys90d
			unknownUsage += row.UnknownKeyUsage
		}
		out.TotalCredentials = &total
		out.CredentialsByStatus = &byStatus
		out.NewCredentialsLast24h = &new24h
		out.ExpiringCredentials30d = &expiring
		if unknownUsage == 0 { // NULL usage may mean untracked, not never-used
			out.StaleCredentials90d = &stale
		}
	}
	if f.Region == "" {
		scan, err := reader.SummaryScanData(ctx, f)
		if err != nil {
			return nil, err
		}
		if err := checkCount(scan.CompletedAccountCount, "completed scanned accounts"); err != nil {
			return nil, err
		}
		out.TotalAccountsScanned = &scan.CompletedAccountCount // 0 only if query measured zero
		out.LastScanAt = scan.LastScanAt
		out.ScanStatus = scan.ScanStatus
	}
	// Unrotated classification has no confirmed rule. Neither scan-start nor
	// regional scan coverage is present in the confirmed scan table. These
	// pointer fields stay nil rather than fabricating measured zero.
	return out, nil
}
