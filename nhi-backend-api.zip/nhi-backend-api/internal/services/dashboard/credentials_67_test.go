package dashboard

import (
	"context"
	"errors"
	"testing"

	m "nhi-backend-api/internal/models/dashboard"
)

type credentialReaderStub struct {
	counts  []m.CredentialTypeCount
	hygiene *m.CredentialHygieneResponse
	err     error
}

func (s credentialReaderStub) CredentialTypeCounts(context.Context, m.CredentialTypeFilter) ([]m.CredentialTypeCount, error) {
	return s.counts, s.err
}
func (s credentialReaderStub) CredentialHygiene(context.Context, m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	return s.hygiene, s.err
}

func TestCredentialServicesFailClosed(t *testing.T) {
	ctx := context.Background()
	f := m.CredentialTypeFilter{AllowedAccountIDs: []string{"123456789012"}}
	h := m.CredentialHygieneFilter{AllowedAccountIDs: f.AllowedAccountIDs}
	for _, s := range []*DashboardCredentialService{
		NewDashboardCredentialService(nil),
		NewDashboardCredentialService(credentialReaderStub{err: m.ErrCredentialSourceUnavailable}),
	} {
		if result, err := s.ByType(ctx, f); result != nil || !errors.Is(err, ErrDashboardSourceUnavailable) {
			t.Fatalf("expected 503-class error for #6, got %+v %v", result, err)
		}
		if result, err := s.Hygiene(ctx, h); result != nil || !errors.Is(err, ErrDashboardSourceUnavailable) {
			t.Fatalf("expected 503-class error for #7, got %+v %v", result, err)
		}
	}
	s := NewDashboardCredentialService(credentialReaderStub{})
	if result, err := s.ByType(ctx, f); result != nil || !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil must NOT mean zero inventory: %+v %v", result, err)
	}
	if result, err := s.Hygiene(ctx, h); result != nil || !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil must NOT mean zero risk: %+v %v", result, err)
	}
	if _, err := s.ByType(ctx, m.CredentialTypeFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped #6: %v", err)
	}
	if _, err := s.Hygiene(ctx, m.CredentialHygieneFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped #7: %v", err)
	}
}

func TestCredentialServicesWithApprovedReader(t *testing.T) {
	ctx := context.Background()
	f := m.CredentialTypeFilter{AllowedAccountIDs: []string{"123456789012"}}
	s := NewDashboardCredentialService(credentialReaderStub{
		counts: []m.CredentialTypeCount{{CredentialType: "access_key", Count: 2}, {CredentialType: "acm_certificate", Count: 3}},
		hygiene: &m.CredentialHygieneResponse{
			ExpiringWithin30d:  m.CredentialHygieneGroup{Total: 2, ByType: []m.CredentialTypeCount{{CredentialType: "acm_certificate", Count: 2}}},
			AlreadyExpired:     m.CredentialHygieneGroup{ByType: []m.CredentialTypeCount{}},
			HighPrivilegeRoles: m.HighPrivilegeRoles{Total: 4, AdminAccess: 3, WildcardActions: 2},
		},
	})
	byType, err := s.ByType(ctx, f)
	if err != nil || byType.Total != 5 || len(byType.Breakdown) != 2 {
		t.Fatalf("by type: %+v %v", byType, err)
	}
	hygiene, err := s.Hygiene(ctx, m.CredentialHygieneFilter{AllowedAccountIDs: f.AllowedAccountIDs})
	if err != nil || hygiene.ExpiringWithin30d.Total != 2 || hygiene.HighPrivilegeRoles.Total != 4 {
		t.Fatalf("hygiene: %+v %v", hygiene, err)
	}
	badCounts := NewDashboardCredentialService(credentialReaderStub{counts: []m.CredentialTypeCount{{CredentialType: "access_key", Count: -1}}})
	if _, err := badCounts.ByType(ctx, f); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("negative count must fail: %v", err)
	}
	badHygiene := NewDashboardCredentialService(credentialReaderStub{hygiene: &m.CredentialHygieneResponse{
		ExpiringWithin30d: m.CredentialHygieneGroup{Total: 2, ByType: []m.CredentialTypeCount{}},
		AlreadyExpired:    m.CredentialHygieneGroup{ByType: []m.CredentialTypeCount{}},
	}})
	if _, err := badHygiene.Hygiene(ctx, m.CredentialHygieneFilter{AllowedAccountIDs: f.AllowedAccountIDs}); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("inconsistent hygiene totals must fail: %v", err)
	}
}
