package dashboard

import (
	"context"
	"sort"
	"time"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// The exposure reader is optional for older test implementations of APIs 3–5.
// The production DashboardBreakdownRepository implements it.
type dashboardExposureReader interface {
	ExposureCounts(context.Context, identitymodels.ExposureFilter, time.Time) ([]identitymodels.ExposureCountRow, error)
}

// Exposure builds the dashboard #8 cards. Dormancy is a non-NULL activity
// timestamp strictly older than 90*24 hours; a NULL timestamp goes into
// no_activity_tracked, not dormant_90d. IaC availability is unknown.
func (s *DashboardBreakdownService) Exposure(ctx context.Context, f identitymodels.ExposureFilter) (*identitymodels.ExposureResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	reader, ok := s.identities.(dashboardExposureReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	cutoff := time.Now().UTC().Add(-90 * 24 * time.Hour)
	rows, err := reader.ExposureCounts(ctx, f, cutoff)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ExposureResponse{
		PubliclyAccessible: identitymodels.ExposureGroup{ByType: []identitymodels.ExposureCountByType{}},
		Dormant90d:         identitymodels.ExposureGroup{ByType: []identitymodels.ExposureCountByType{}},
		NotInIAC:           nil, // not a measured zero
	}
	for _, row := range rows {
		for _, item := range []struct {
			label string
			n     int64
		}{
			{"public", row.PublicCount}, {"dormant", row.DormantCount},
			{"no activity", row.NoActivityCount}, {"missing owner", row.MissingOwnerCount},
			{"missing environment", row.MissingEnvCount},
		} {
			if err := checkCount(item.n, item.label); err != nil {
				return nil, err
			}
		}
		if row.PublicCount > 0 {
			out.PubliclyAccessible.ByType = append(out.PubliclyAccessible.ByType, identitymodels.ExposureCountByType{IdentityType: row.IdentityType, Count: row.PublicCount})
		}
		if row.DormantCount > 0 {
			out.Dormant90d.ByType = append(out.Dormant90d.ByType, identitymodels.ExposureCountByType{IdentityType: row.IdentityType, Count: row.DormantCount})
		}
		out.PubliclyAccessible.Total += row.PublicCount
		out.Dormant90d.Total += row.DormantCount
		out.NoActivityTracked += row.NoActivityCount
		out.MissingOwnerTag += row.MissingOwnerCount
		out.MissingEnvironmentTag += row.MissingEnvCount
	}
	less := func(a, b identitymodels.ExposureCountByType) bool {
		if a.Count != b.Count {
			return a.Count > b.Count
		}
		return a.IdentityType < b.IdentityType
	}
	sort.Slice(out.PubliclyAccessible.ByType, func(i, j int) bool {
		return less(out.PubliclyAccessible.ByType[i], out.PubliclyAccessible.ByType[j])
	})
	sort.Slice(out.Dormant90d.ByType, func(i, j int) bool {
		return less(out.Dormant90d.ByType[i], out.Dormant90d.ByType[j])
	})
	return out, nil
}
