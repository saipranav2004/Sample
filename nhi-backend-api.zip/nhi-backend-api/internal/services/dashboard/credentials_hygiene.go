package dashboard

import (
	"context"
	"fmt"
	"math"
	"strings"

	m "nhi-backend-api/internal/models/dashboard"
)

// Hygiene returns no JSON success until all PDF #7 cards have a complete,
// verified backing source. The current repository always reports unavailable.
func (s *DashboardCredentialService) Hygiene(ctx context.Context, f m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	if s == nil || s.reader == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	out, err := s.reader.CredentialHygiene(ctx, f)
	if err != nil {
		return nil, credentialSourceError(err)
	}
	if out == nil { // nil,nil is NOT evidence all hygiene cards are zero
		return nil, ErrDashboardSourceIncomplete
	}
	for _, metric := range []struct {
		name string
		n    int64
	}{
		{"stale_access_keys_90d", out.StaleAccessKeys90d},
		{"never_used_access_keys", out.NeverUsedAccessKeys},
		{"unrotated_secrets_90d", out.UnrotatedSecrets90d},
		{"rotation_disabled_secrets", out.RotationDisabledSecrets},
		{"root_access_keys_present", out.RootAccessKeysPresent},
		{"high_privilege_roles.total", out.HighPrivilegeRoles.Total},
		{"high_privilege_roles.admin_access", out.HighPrivilegeRoles.AdminAccess},
		{"high_privilege_roles.wildcard_actions", out.HighPrivilegeRoles.WildcardActions},
		{"public_trust_roles", out.PublicTrustRoles},
	} {
		if err := checkCount(metric.n, metric.name); err != nil {
			return nil, err
		}
	}
	for _, g := range []struct {
		name string
		data m.CredentialHygieneGroup
	}{
		{"expiring_within_30d", out.ExpiringWithin30d},
		{"already_expired", out.AlreadyExpired},
	} {
		if err := checkCount(g.data.Total, g.name); err != nil {
			return nil, err
		}
		if g.data.ByType == nil { // the complete source should use [] for no matches
			return nil, fmt.Errorf("%w: missing %s by_type", ErrDashboardSourceIncomplete, g.name)
		}
		var sum int64
		seen := make(map[string]bool, len(g.data.ByType))
		for _, c := range g.data.ByType {
			if strings.TrimSpace(c.CredentialType) == "" || seen[c.CredentialType] {
				return nil, fmt.Errorf("%w: invalid or duplicate %s type", ErrDashboardSourceIncomplete, g.name)
			}
			seen[c.CredentialType] = true
			if err := checkCount(c.Count, g.name); err != nil {
				return nil, err
			}
			if c.Count > math.MaxInt64-sum {
				return nil, fmt.Errorf("%w: %s count overflow", ErrDashboardSourceIncomplete, g.name)
			}
			sum += c.Count
		}
		if sum != g.data.Total {
			return nil, fmt.Errorf("%w: %s total does not match by_type", ErrDashboardSourceIncomplete, g.name)
		}
	}
	// admin_access and wildcard_actions may overlap: no arithmetic equality
	// is imposed on high_privilege_roles subcounts until rules are approved.
	return out, nil
}
