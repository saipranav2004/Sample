package dashboard

import (
	"context"
	"errors"
	"fmt"
	"time"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

var (
	// A required, approved backing source has not yet been provided.
	ErrDashboardSourceUnavailable = errors.New("dashboard source unavailable")
	// The configured source did not provide a value for every returned group.
	ErrDashboardSourceIncomplete = errors.New("dashboard source incomplete")
)

// Dashboard345IdentityReader reads catalog counts from nhi_scanner.identities.
// The repository must enforce AllowedAccountIDs for every query.
type Dashboard345IdentityReader interface {
	ByClass(context.Context, identitymodels.ClassFilter) ([]identitymodels.FunctionalClassCount, error)
	ByAccountIdentityCounts(context.Context, identitymodels.AccountFilter) ([]identitymodels.AccountIdentityCount, error)
	ByRegionIdentityCounts(context.Context, identitymodels.RegionFilter) ([]identitymodels.RegionIdentityCount, error)
}

// CredentialSummaryReader supplies real credential facts to PDF #1/#4/#5.
// Kept separate from the identity reader to preserve flat domain ownership.
type CredentialSummaryReader interface {
	SummaryCredentialCounts(context.Context, identitymodels.SummaryFilter, time.Time, time.Time) ([]identitymodels.SummaryCredentialRow, error)
	ByAccountCredentialCounts(context.Context, identitymodels.AccountFilter) (map[string]int64, error)
	ByRegionCredentialCounts(context.Context, identitymodels.RegionFilter) (map[string]int64, error)
}

type DashboardBreakdownService struct {
	identities  Dashboard345IdentityReader
	credentials CredentialSummaryReader
}

// The optional argument preserves old independent identity-only service tests.
// Production explicitly provides the scanner credential repository.
func NewDashboardBreakdownService(ids Dashboard345IdentityReader, credentials ...CredentialSummaryReader) *DashboardBreakdownService {
	s := &DashboardBreakdownService{identities: ids}
	if len(credentials) > 0 {
		s.credentials = credentials[0]
	}
	return s
}

func requireScope(ids []string) error {
	if len(ids) == 0 {
		return ErrDashboardSourceUnavailable
	}
	return nil
}

func checkCount(n int64, label string) error {
	if n < 0 {
		return fmt.Errorf("%w: negative %s count", ErrDashboardSourceIncomplete, label)
	}
	return nil
}

func (s *DashboardBreakdownService) ByClass(ctx context.Context, f identitymodels.ClassFilter) (*identitymodels.ByClassResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByClass(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByClassResponse{Breakdown: make([]identitymodels.FunctionalClassCount, 0, len(groups))}
	for _, group := range groups {
		if err := checkCount(group.Count, "identity"); err != nil {
			return nil, err
		}
		out.Total += group.Count
		out.Breakdown = append(out.Breakdown, group)
	}
	return out, nil
}
