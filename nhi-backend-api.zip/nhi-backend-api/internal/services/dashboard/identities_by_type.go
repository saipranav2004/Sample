package dashboard

import (
	"context"
	"math"

	m "nhi-backend-api/internal/models/dashboard"
)

// Keep APIs #3–#5 compatible with existing reader fakes: only the production
// identity repository needs to implement the additional PDF #2 method.
type dashboardTypeReader interface {
	ByType(context.Context, m.TypeFilter) ([]m.IdentityTypeCount, error)
}

func (s *DashboardBreakdownService) ByType(ctx context.Context, f m.TypeFilter) (*m.ByTypeResponse, error) {
	if s == nil || s.identities == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	reader, ok := s.identities.(dashboardTypeReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	groups, err := reader.ByType(ctx, f)
	if err != nil {
		return nil, err
	}
	if groups == nil { // nil,nil from an unfinished adapter is not zero identities
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.ByTypeResponse{Breakdown: make([]m.IdentityTypeCount, 0, len(groups))}
	seen := make(map[string]bool, len(groups))
	for _, group := range groups {
		if group.IdentityType == "" || seen[group.IdentityType] {
			return nil, ErrDashboardSourceIncomplete
		}
		seen[group.IdentityType] = true
		if err := checkCount(group.Count, "identity type"); err != nil {
			return nil, err
		}
		if group.Count > math.MaxInt64-out.Total {
			return nil, ErrDashboardSourceIncomplete
		}
		out.Total += group.Count
		out.Breakdown = append(out.Breakdown, group)
	}
	return out, nil
}
