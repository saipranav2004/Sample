package dashboard

import (
	"context"
	"errors"
	"testing"

	m "nhi-backend-api/internal/models/dashboard"
)

type fakeIDs struct {
	classFilter   m.ClassFilter
	accountFilter m.AccountFilter
	regionFilter  m.RegionFilter
	classes       []m.FunctionalClassCount
	accounts      []m.AccountIdentityCount
	regions       []m.RegionIdentityCount
}

func (f *fakeIDs) ByClass(_ context.Context, q m.ClassFilter) ([]m.FunctionalClassCount, error) {
	f.classFilter = q
	return f.classes, nil
}
func (f *fakeIDs) ByAccountIdentityCounts(_ context.Context, q m.AccountFilter) ([]m.AccountIdentityCount, error) {
	f.accountFilter = q
	return f.accounts, nil
}
func (f *fakeIDs) ByRegionIdentityCounts(_ context.Context, q m.RegionFilter) ([]m.RegionIdentityCount, error) {
	f.regionFilter = q
	return f.regions, nil
}

func TestDashboard345IdentityOnlyResults(t *testing.T) {
	id := &fakeIDs{
		classes:  []m.FunctionalClassCount{{FunctionalClass: "service", Count: 2}, {FunctionalClass: "unclassified", Count: 1}},
		accounts: []m.AccountIdentityCount{{AccountID: "123456789012", IdentityCount: 3}},
		regions:  []m.RegionIdentityCount{{Region: "global", IdentityCount: 3}},
	}
	scope := []string{"123456789012"}
	svc := NewDashboardBreakdownService(id)
	byClass, err := svc.ByClass(context.Background(), m.ClassFilter{AccountID: scope[0], Region: "global", AllowedAccountIDs: scope})
	if err != nil || byClass.Total != 3 || len(byClass.Breakdown) != 2 || id.classFilter.Region != "global" {
		t.Fatalf("class: %+v, %v", byClass, err)
	}
	byAccount, err := svc.ByAccount(context.Background(), m.AccountFilter{Region: "global", IdentityType: "lambda_function", AllowedAccountIDs: scope})
	if err != nil || byAccount.TotalAccounts != 1 || byAccount.Breakdown[0].IdentityCount != 3 || byAccount.Breakdown[0].CredentialCount != nil || id.accountFilter.Region != "global" {
		t.Fatalf("account: %+v, %v", byAccount, err)
	}
	byRegion, err := svc.ByRegion(context.Background(), m.RegionFilter{AccountID: scope[0], AllowedAccountIDs: scope})
	if err != nil || byRegion.TotalRegions != 1 || byRegion.Breakdown[0].IdentityCount != 3 || byRegion.Breakdown[0].CredentialCount != nil || id.regionFilter.AccountID != scope[0] {
		t.Fatalf("region: %+v, %v", byRegion, err)
	}
	id.accounts, id.regions = nil, nil
	byAccount, err = svc.ByAccount(context.Background(), m.AccountFilter{AllowedAccountIDs: scope})
	if err != nil || byAccount.TotalAccounts != 0 || byAccount.Breakdown == nil {
		t.Fatalf("empty account breakdown: %+v, %v", byAccount, err)
	}
	byRegion, err = svc.ByRegion(context.Background(), m.RegionFilter{AllowedAccountIDs: scope})
	if err != nil || byRegion.TotalRegions != 0 || byRegion.Breakdown == nil {
		t.Fatalf("empty region breakdown: %+v, %v", byRegion, err)
	}
	if _, err := svc.ByAccount(context.Background(), m.AccountFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped account query was not rejected: %v", err)
	}
	if _, err := svc.ByRegion(context.Background(), m.RegionFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped region query was not rejected: %v", err)
	}
}
