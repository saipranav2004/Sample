package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByAccount preserves the lead-approved omission of account_name; credential
// counts are independently measured by account/region from current credentials.
// identity_type has no credential-side equivalent and filters identities only.
func (s *DashboardBreakdownService) ByAccount(ctx context.Context, f identitymodels.AccountFilter) (*identitymodels.ByAccountResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByAccountIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByAccountResponse{Breakdown: make([]identitymodels.AccountBreakdown, 0, len(groups))}
	var credentialCounts map[string]int64
	if s.credentials != nil {
		credentialCounts, err = s.credentials.ByAccountCredentialCounts(ctx, f)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialCounts == nil {
			return nil, ErrDashboardSourceIncomplete
		}
		for _, n := range credentialCounts {
			if err := checkCount(n, "credential account"); err != nil {
				return nil, err
			}
		}
	}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		item := identitymodels.AccountBreakdown{AccountID: group.AccountID, IdentityCount: group.IdentityCount}
		if credentialCounts != nil {
			value := credentialCounts[group.AccountID]
			item.CredentialCount = &value // absent group is a measured zero
		}
		out.Breakdown = append(out.Breakdown, item)
	}
	out.TotalAccounts = len(out.Breakdown)
	return out, nil
}
