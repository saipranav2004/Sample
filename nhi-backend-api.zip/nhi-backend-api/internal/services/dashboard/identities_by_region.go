package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByRegion adds actual credential counts for each identity region; no
// credential-to-identity_type relationship is invented.
func (s *DashboardBreakdownService) ByRegion(ctx context.Context, f identitymodels.RegionFilter) (*identitymodels.ByRegionResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByRegionIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByRegionResponse{Breakdown: make([]identitymodels.RegionBreakdown, 0, len(groups))}
	var credentialCounts map[string]int64
	if s.credentials != nil {
		credentialCounts, err = s.credentials.ByRegionCredentialCounts(ctx, f)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialCounts == nil {
			return nil, ErrDashboardSourceIncomplete
		}
		for _, n := range credentialCounts {
			if err := checkCount(n, "credential region"); err != nil {
				return nil, err
			}
		}
	}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		item := identitymodels.RegionBreakdown{Region: group.Region, IdentityCount: group.IdentityCount}
		if credentialCounts != nil {
			value := credentialCounts[group.Region]
			item.CredentialCount = &value
		}
		out.Breakdown = append(out.Breakdown, item)
	}
	out.TotalRegions = len(out.Breakdown)
	return out, nil
}
