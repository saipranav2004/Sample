package dashboard

import (
	"context"
	"errors"
	"fmt"
	"math"
	"strings"

	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialReader uses the confirmed scanner credentials table for
// #6; #7 is deliberately unavailable until its risk definitions are approved.
type DashboardCredentialReader interface {
	CredentialTypeCounts(context.Context, m.CredentialTypeFilter) ([]m.CredentialTypeCount, error)
	CredentialHygiene(context.Context, m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error)
}

type DashboardCredentialService struct{ reader DashboardCredentialReader }

func NewDashboardCredentialService(reader DashboardCredentialReader) *DashboardCredentialService {
	return &DashboardCredentialService{reader: reader}
}

func credentialSourceError(err error) error {
	if errors.Is(err, m.ErrCredentialSourceUnavailable) {
		return ErrDashboardSourceUnavailable
	}
	return err
}

func (s *DashboardCredentialService) ByType(ctx context.Context, f m.CredentialTypeFilter) (*m.CredentialsByTypeResponse, error) {
	if s == nil || s.reader == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	counts, err := s.reader.CredentialTypeCounts(ctx, f)
	if err != nil {
		return nil, credentialSourceError(err)
	}
	if counts == nil { // nil,nil is NOT a proven empty inventory
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.CredentialsByTypeResponse{Breakdown: make([]m.CredentialTypeCount, 0, len(counts))}
	seen := make(map[string]bool, len(counts))
	for _, c := range counts {
		if strings.TrimSpace(c.CredentialType) == "" || seen[c.CredentialType] {
			return nil, fmt.Errorf("%w: invalid or duplicate credential type", ErrDashboardSourceIncomplete)
		}
		seen[c.CredentialType] = true
		if err := checkCount(c.Count, "credential"); err != nil {
			return nil, err
		}
		if c.Count > math.MaxInt64-out.Total {
			return nil, fmt.Errorf("%w: credential total overflow", ErrDashboardSourceIncomplete)
		}
		out.Total += c.Count
		out.Breakdown = append(out.Breakdown, c)
	}
	return out, nil
}
