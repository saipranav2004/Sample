package dashboard

import (
	"context"
	"errors"
	"testing"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type dashboardCredentialStub struct {
	summary []m.SummaryCredentialRow
	account map[string]int64
	region  map[string]int64
	err     error
	f       m.SummaryFilter
	start   time.Time
	now     time.Time
}

func (s *dashboardCredentialStub) SummaryCredentialCounts(_ context.Context, f m.SummaryFilter, start, now time.Time) ([]m.SummaryCredentialRow, error) {
	s.f, s.start, s.now = f, start, now
	return s.summary, s.err
}
func (s *dashboardCredentialStub) ByAccountCredentialCounts(context.Context, m.AccountFilter) (map[string]int64, error) {
	return s.account, s.err
}
func (s *dashboardCredentialStub) ByRegionCredentialCounts(context.Context, m.RegionFilter) (map[string]int64, error) {
	return s.region, s.err
}

func TestDashboardCredentialBackedSummaryAndGroups(t *testing.T) {
	const account = "123456789012"
	ids := &summaryTypeStub{fakeIDs: &fakeIDs{accounts: []m.AccountIdentityCount{{AccountID: account, IdentityCount: 2}}, regions: []m.RegionIdentityCount{{Region: "us-east-1", IdentityCount: 1}, {Region: "global", IdentityCount: 1}}}, rows: []m.SummaryIdentityRow{}, scan: m.SummaryScanData{}}
	cred := &dashboardCredentialStub{
		summary: []m.SummaryCredentialRow{{Status: "active", CurrentCount: 2, New24h: 1, Expiring30d: 1, StaleKeys90d: 1}, {Status: "expired", CurrentCount: 1}},
		account: map[string]int64{account: 3}, region: map[string]int64{"us-east-1": 2},
	}
	s := NewDashboardBreakdownService(ids, cred)
	f := m.SummaryFilter{AllowedAccountIDs: []string{account}, Region: "us-east-1"}
	result, err := s.Summary(context.Background(), f)
	if err != nil || result.TotalCredentials == nil || *result.TotalCredentials != 3 || result.NewCredentialsLast24h == nil || *result.NewCredentialsLast24h != 1 || result.ExpiringCredentials30d == nil || *result.ExpiringCredentials30d != 1 || result.StaleCredentials90d == nil || *result.StaleCredentials90d != 1 || result.CredentialsByStatus == nil || (*result.CredentialsByStatus)["expired"] != 1 {
		t.Fatalf("measured credentials %+v %v", result, err)
	}
	if result.UnrotatedCredentials != nil || result.ScanDurationSeconds != nil || result.TotalAccountsScanned != nil || ids.scanCalls != 0 || cred.f.Region != f.Region || cred.now.Sub(cred.start) != 24*time.Hour {
		t.Fatalf("unsupported/unfiltered data %+v %#v", result, cred)
	}
	byAccount, err := s.ByAccount(context.Background(), m.AccountFilter{AllowedAccountIDs: f.AllowedAccountIDs, IdentityType: "lambda_function"})
	if err != nil || len(byAccount.Breakdown) != 1 || byAccount.Breakdown[0].CredentialCount == nil || *byAccount.Breakdown[0].CredentialCount != 3 {
		t.Fatalf("by-account credential count %+v %v", byAccount, err)
	}
	byRegion, err := s.ByRegion(context.Background(), m.RegionFilter{AllowedAccountIDs: f.AllowedAccountIDs, IdentityType: "lambda_function"})
	if err != nil || len(byRegion.Breakdown) != 2 || byRegion.Breakdown[0].CredentialCount == nil || *byRegion.Breakdown[0].CredentialCount != 2 || byRegion.Breakdown[1].CredentialCount == nil || *byRegion.Breakdown[1].CredentialCount != 0 {
		t.Fatalf("by-region credential count %+v %v", byRegion, err)
	}
	cred.summary = []m.SummaryCredentialRow{{Status: "active", CurrentCount: 2, UnknownKeyUsage: 1}}
	result, err = s.Summary(context.Background(), f)
	if err != nil || result.TotalCredentials == nil || *result.TotalCredentials != 2 || result.StaleCredentials90d != nil {
		t.Fatalf("unknown key usage must not mean measured zero stale keys: %+v %v", result, err)
	}
	cred.summary = []m.SummaryCredentialRow{}
	result, err = s.Summary(context.Background(), m.SummaryFilter{AllowedAccountIDs: f.AllowedAccountIDs})
	if err != nil || result.TotalCredentials == nil || *result.TotalCredentials != 0 || result.CredentialsByStatus == nil || len(*result.CredentialsByStatus) != 0 {
		t.Fatalf("measured empty credentials %+v %v", result, err)
	}
	cred.summary = nil
	if _, err := s.Summary(context.Background(), f); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil credential result must fail: %v", err)
	}
	cred.summary = []m.SummaryCredentialRow{{Status: "active", CurrentCount: 1, New24h: 2}}
	if _, err := s.Summary(context.Background(), f); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("impossible credentials must fail: %v", err)
	}
	cred.summary = []m.SummaryCredentialRow{}
	cred.account = nil
	if _, err := s.ByAccount(context.Background(), m.AccountFilter{AllowedAccountIDs: f.AllowedAccountIDs}); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil account counts must fail: %v", err)
	}
	cred.account = map[string]int64{}
	cred.err = m.ErrCredentialSourceUnavailable
	if _, err := s.Summary(context.Background(), f); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unavailable credential source must map to 503-class summary error: %v", err)
	}
	if _, err := s.ByAccount(context.Background(), m.AccountFilter{AllowedAccountIDs: f.AllowedAccountIDs}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unavailable credential source must map to 503-class group error: %v", err)
	}
	cred.err = nil
	cred.region = map[string]int64{"global": -1}
	if _, err := s.ByRegion(context.Background(), m.RegionFilter{AllowedAccountIDs: f.AllowedAccountIDs}); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("negative region counts must fail: %v", err)
	}
}
