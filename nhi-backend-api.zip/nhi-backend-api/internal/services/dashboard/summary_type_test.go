package dashboard

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type summaryTypeStub struct {
	*fakeIDs
	rows       []m.SummaryIdentityRow
	byType     []m.IdentityTypeCount
	scan       m.SummaryScanData
	typeFilter m.TypeFilter
	scanCalls  int
	start      time.Time
	end        time.Time
}

func (s *summaryTypeStub) ByType(_ context.Context, f m.TypeFilter) ([]m.IdentityTypeCount, error) {
	s.typeFilter = f
	return s.byType, nil
}
func (s *summaryTypeStub) SummaryIdentityCounts(_ context.Context, _ m.SummaryFilter, start, now time.Time) ([]m.SummaryIdentityRow, error) {
	s.start, s.end = start, now
	return s.rows, nil
}
func (s *summaryTypeStub) SummaryScanData(_ context.Context, _ m.SummaryFilter) (m.SummaryScanData, error) {
	s.scanCalls++
	return s.scan, nil
}

func TestIdentityTypeService(t *testing.T) {
	stub := &summaryTypeStub{fakeIDs: &fakeIDs{}, byType: []m.IdentityTypeCount{{IdentityType: "lambda_function", Count: 2}, {IdentityType: "ec2_instance", Count: 1}}}
	s := NewDashboardBreakdownService(stub)
	f := m.TypeFilter{AllowedAccountIDs: []string{"123456789012"}, AccountID: "123456789012", Region: "us-east-1", Status: "active", FunctionalClass: "service"}
	result, err := s.ByType(context.Background(), f)
	if err != nil || result.Total != 3 || len(result.Breakdown) != 2 || stub.typeFilter.FunctionalClass != "service" {
		t.Fatalf("by type: %+v %v", result, err)
	}
	stub.byType = []m.IdentityTypeCount{}
	result, err = s.ByType(context.Background(), f)
	if err != nil || result.Total != 0 || result.Breakdown == nil {
		t.Fatalf("measured empty type response: %+v %v", result, err)
	}
	stub.byType = nil
	if _, err := s.ByType(context.Background(), f); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil reader is incomplete: %v", err)
	}
	if _, err := s.ByType(context.Background(), m.TypeFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("no scope: %v", err)
	}
}

func TestPartialSummaryService(t *testing.T) {
	ended := time.Date(2025, time.June, 14, 3, 0, 0, 0, time.UTC)
	status := "COMPLETED"
	stub := &summaryTypeStub{fakeIDs: &fakeIDs{}, rows: []m.SummaryIdentityRow{{Status: "active", CurrentCount: 2, New24h: 1}, {Status: "terminated", CurrentCount: 1, Removed24h: 1}}, scan: m.SummaryScanData{CompletedAccountCount: 2, LastScanAt: &ended, ScanStatus: &status}}
	s := NewDashboardBreakdownService(stub)
	filter := m.SummaryFilter{AllowedAccountIDs: []string{"123456789012"}}
	result, err := s.Summary(context.Background(), filter)
	if err != nil || result.TotalIdentities != 3 || result.NewIdentitiesLast24h != 1 || result.RemovedIdentitiesLast24h != 1 || result.IdentitiesByStatus["active"] != 2 || result.TotalAccountsScanned == nil || *result.TotalAccountsScanned != 2 || stub.scanCalls != 1 {
		t.Fatalf("summary: %+v %v", result, err)
	}
	if result.TotalCredentials != nil || result.CredentialsByStatus != nil || result.TotalRegionsScanned != nil || result.ScanDurationSeconds != nil || result.ExpiringCredentials30d != nil {
		t.Fatalf("missing data must not look measured: %+v", result)
	}
	if delta := stub.end.Sub(stub.start); delta != 24*time.Hour {
		t.Fatalf("not a 24h UTC window: %s", delta)
	}
	body, err := json.Marshal(result)
	if err != nil || !strings.Contains(string(body), `"total_credentials":null`) || !strings.Contains(string(body), `"scan_duration_seconds":null`) || !strings.Contains(string(body), `"total_regions_scanned":null`) {
		t.Fatalf("nulls missing from JSON: %s %v", body, err)
	}
	result, err = s.Summary(context.Background(), m.SummaryFilter{AllowedAccountIDs: filter.AllowedAccountIDs, Region: "us-east-1"})
	if err != nil || result.TotalAccountsScanned != nil || result.LastScanAt != nil || result.ScanStatus != nil || stub.scanCalls != 1 {
		t.Fatalf("region may not imply regional scan coverage: %+v %v", result, err)
	}
	stub.rows = nil
	if _, err := s.Summary(context.Background(), filter); !errors.Is(err, ErrDashboardSourceIncomplete) {
		t.Fatalf("nil,nil identity rows: %v", err)
	}
	if _, err := s.Summary(context.Background(), m.SummaryFilter{}); !errors.Is(err, ErrDashboardSourceUnavailable) {
		t.Fatalf("unscoped: %v", err)
	}
}
