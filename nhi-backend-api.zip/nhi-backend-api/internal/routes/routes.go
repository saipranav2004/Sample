// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	secscanhandlers "nhi-backend-api/internal/handlers/secscan"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	SecscanHandler             *secscanhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 measures available credentials; #4/#5 include actual credential
	// counts; #6 is live; #7 remains 503 pending hygiene rules; #8 has
	// not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. #6 queries
	// nhi_scanner.credentials; #7 stays fail-closed until risk rules are agreed.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// Secret scanner (credential exposure): CodeCommit and GitHub findings
	// read directly from the nhi_scanner.secscan_* tables. Same paths and
	// response bodies as the scanner's own API, behind this backend's JWT.
	// Reading is open to every authenticated user; changes need a reviewer
	// role (admin, team_lead), checked in the service.
	if h.SecscanHandler != nil {
		protected.HandleFunc("/findings", middleware.RecoverV1(h.SecscanHandler.Findings)).Methods("GET")
		protected.HandleFunc("/findings/decision", middleware.RecoverV1(h.SecscanHandler.Decision)).Methods("POST")
		protected.HandleFunc("/allowlist", middleware.RecoverV1(h.SecscanHandler.Allowlist)).Methods("GET")
		protected.HandleFunc("/allowlist", middleware.RecoverV1(h.SecscanHandler.Dismiss)).Methods("POST")
		protected.HandleFunc("/allowlist", middleware.RecoverV1(h.SecscanHandler.Restore)).Methods("DELETE")
		protected.HandleFunc("/deep-scan-status", middleware.RecoverV1(h.SecscanHandler.DeepScanStatus)).Methods("GET")
		protected.HandleFunc("/deep-scan", middleware.RecoverV1(h.SecscanHandler.DeepScan)).Methods("POST")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
