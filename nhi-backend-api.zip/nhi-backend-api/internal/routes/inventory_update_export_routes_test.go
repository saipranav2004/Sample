package routes

import (
	"net/http"
	"net/http/httptest"
	"nhi-backend-api/internal/config"
	inventoryhandler "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/inventory"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	inventoryservice "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
	"strings"
	"testing"
)

func TestInventoryPatchExceptions(t *testing.T) {
	const secret = "test-inventory-patch-secret"
	token, err := appjwt.GenerateToken(1, "test@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	mkRouter := func(fail error) http.Handler {
		return SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{fail: fail}), inventoryScopeStub{})})
	}
	send := func(router http.Handler, path, body, contentType string, auth bool) *httptest.ResponseRecorder {
		req := httptest.NewRequest(http.MethodPatch, path, strings.NewReader(body))
		if contentType != "" {
			req.Header.Set("Content-Type", contentType)
		}
		if auth {
			req.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		router.ServeHTTP(w, req)
		return w
	}
	path := "/api/v1/inventory/identities/" + testID
	for _, tc := range []struct {
		body, media string
		auth        bool
		want        int
	}{
		{`{"owner":"security-team","functional_class":"break_glass"}`, "application/json", true, 200},
		{`{"owner":"security-team"}`, "application/json", false, 401},
		{`{}`, "application/json", true, 400},
		{`{"owner":"one","owner":"two"}`, "application/json", true, 400},
		{`{"status":"active"}`, "application/json", true, 400},
		{`{"owner":null}`, "application/json", true, 400},
		{`{"owner":" "}`, "application/json", true, 400},
		{`{"functional_class":"DROP TABLE identities"}`, "application/json", true, 400},
		{`{"owner":"a"}`, "text/plain", true, 415},
	} {
		w := send(mkRouter(nil), path, tc.body, tc.media, tc.auth)
		if w.Code != tc.want {
			t.Errorf("PATCH %s auth=%t: %d %s want %d", tc.body, tc.auth, w.Code, w.Body.String(), tc.want)
		}
		if tc.want == 200 && !strings.Contains(w.Body.String(), `"updated_fields":["functional_class","owner"]`) {
			t.Errorf("success shape: %s", w.Body.String())
		}
	}
	if w := send(mkRouter(nil), "/api/v1/inventory/identities/not-a-uuid", `{"owner":"x"}`, "application/json", true); w.Code != 400 {
		t.Fatalf("malformed UUID: %d", w.Code)
	}
	if w := send(mkRouter(nil), path, `{"owner":"`+strings.Repeat("A", 9000)+`"}`, "application/json", true); w.Code != 413 {
		t.Fatalf("oversize: %d %s", w.Code, w.Body.String())
	}
	if w := send(mkRouter(inventoryrepo.ErrNotFound), path, `{"owner":"security-team"}`, "application/json", true); w.Code != 404 {
		t.Fatalf("deleted/missing/out-of-scope: %d %s", w.Code, w.Body.String())
	}
}

func TestInventoryExportDownloads(t *testing.T) {
	const secret = "test-inventory-export-secret"
	token, err := appjwt.GenerateToken(1, "test@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	router := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{}), inventoryScopeStub{})})
	req := httptest.NewRequest(http.MethodGet, "/api/v1/inventory/identities/export?format=json&account_id=123456789012", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)
	if w.Code != 200 || !strings.Contains(w.Header().Get("Content-Disposition"), "attachment") || !strings.Contains(w.Header().Get("Content-Type"), "application/json") || !strings.Contains(w.Body.String(), `"id"`) {
		t.Fatalf("export: %d %s headers=%v", w.Code, w.Body.String(), w.Header())
	}
	limited := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{fail: m.ErrExportTooLarge}), inventoryScopeStub{})})
	w = httptest.NewRecorder()
	limited.ServeHTTP(w, req)
	if w.Code != 413 || !strings.Contains(w.Body.String(), `"EXPORT_TOO_LARGE"`) || w.Header().Get("Content-Disposition") != "" {
		t.Fatalf("over-large export must not download a partial file: %d %s", w.Code, w.Body.String())
	}
}
