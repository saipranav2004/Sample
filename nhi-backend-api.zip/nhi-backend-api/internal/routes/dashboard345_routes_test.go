package routes

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"nhi-backend-api/internal/config"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	dashservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

// Check the real /api prefix, the v1 route registration and the existing JWT
// middleware. No DB or unsafe account-policy stub is used in this test.
func TestDashboard345RoutesFailClosed(t *testing.T) {
	const secret = "test-secret-only"
	token, err := appjwt.GenerateToken(9, "tester@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	router := SetupRoutes(HandlerContainer{
		AuthMiddleware:      middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}),
		Dashboard345Handler: dashhandlers.NewDashboard345Handler(nil, nil),
	})
	for _, endpoint := range []string{
		"/api/v1/dashboard/summary",
		"/api/v1/dashboard/identities/by-type",
		"/api/v1/dashboard/identities/by-class",
		"/api/v1/dashboard/identities/by-account",
		"/api/v1/dashboard/identities/by-region",
		"/api/v1/dashboard/identities/exposure",
	} {
		for _, test := range []struct {
			authorized bool
			want       int
		}{
			{false, http.StatusUnauthorized}, {true, http.StatusServiceUnavailable},
		} {
			r := httptest.NewRequest(http.MethodGet, endpoint, nil)
			if test.authorized {
				r.Header.Set("Authorization", "Bearer "+token)
			}
			w := httptest.NewRecorder()
			router.ServeHTTP(w, r)
			if w.Code != test.want {
				t.Fatalf("%s authorized=%t: status %d, want %d; body=%s", endpoint, test.authorized, w.Code, test.want, w.Body.String())
			}
		}
	}
}

type dashboardSourceStub struct{}

func (dashboardSourceStub) AllKnownAccountIDs(context.Context) ([]string, error) {
	return []string{"123456789012"}, nil
}
func (dashboardSourceStub) ByType(_ context.Context, f m.TypeFilter) ([]m.IdentityTypeCount, error) {
	if len(f.AllowedAccountIDs) != 1 || f.AllowedAccountIDs[0] != "123456789012" {
		return nil, dashservices.ErrDashboardSourceUnavailable
	}
	return []m.IdentityTypeCount{{IdentityType: "lambda_function", Count: 2}}, nil
}
func (dashboardSourceStub) SummaryIdentityCounts(_ context.Context, f m.SummaryFilter, _, _ time.Time) ([]m.SummaryIdentityRow, error) {
	if len(f.AllowedAccountIDs) != 1 || f.AllowedAccountIDs[0] != "123456789012" {
		return nil, dashservices.ErrDashboardSourceUnavailable
	}
	return []m.SummaryIdentityRow{{Status: "active", CurrentCount: 2, New24h: 1}}, nil
}
func (dashboardSourceStub) SummaryScanData(_ context.Context, f m.SummaryFilter) (m.SummaryScanData, error) {
	if len(f.AllowedAccountIDs) != 1 || f.AllowedAccountIDs[0] != "123456789012" {
		return m.SummaryScanData{}, dashservices.ErrDashboardSourceUnavailable
	}
	return m.SummaryScanData{CompletedAccountCount: 1}, nil
}
func (dashboardSourceStub) ByClass(_ context.Context, f m.ClassFilter) ([]m.FunctionalClassCount, error) {
	if len(f.AllowedAccountIDs) != 1 || f.AllowedAccountIDs[0] != "123456789012" {
		return nil, dashservices.ErrDashboardSourceUnavailable
	}
	return []m.FunctionalClassCount{{FunctionalClass: "service", Count: 2}}, nil
}
func (dashboardSourceStub) ByAccountIdentityCounts(context.Context, m.AccountFilter) ([]m.AccountIdentityCount, error) {
	return []m.AccountIdentityCount{{AccountID: "123456789012", IdentityCount: 2}}, nil
}
func (dashboardSourceStub) ByRegionIdentityCounts(context.Context, m.RegionFilter) ([]m.RegionIdentityCount, error) {
	return []m.RegionIdentityCount{{Region: "us-east-1", IdentityCount: 2}}, nil
}
func (dashboardSourceStub) ExposureCounts(context.Context, m.ExposureFilter, time.Time) ([]m.ExposureCountRow, error) {
	return []m.ExposureCountRow{{IdentityType: "service", PublicCount: 2, DormantCount: 1}}, nil
}

func TestDashboard345OptionA(t *testing.T) {
	const secret = "test-option-a-only"
	token, err := appjwt.GenerateToken(9, "tester@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	src := dashboardSourceStub{}
	h := dashhandlers.NewDashboard345Handler(
		dashservices.NewDashboardBreakdownService(src),
		dashhandlers.NewDashboardAllAccountsScope(src),
	)
	router := SetupRoutes(HandlerContainer{
		AuthMiddleware:      middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}),
		Dashboard345Handler: h,
	})
	for _, tc := range []struct {
		url  string
		want int
	}{
		{"/api/v1/dashboard/summary", http.StatusOK},
		{"/api/v1/dashboard/identities/by-type", http.StatusOK},
		{"/api/v1/dashboard/identities/by-class", http.StatusOK},
		{"/api/v1/dashboard/identities/by-class?account_id=999999999999", http.StatusForbidden},
		{"/api/v1/dashboard/identities/by-account", http.StatusOK},
		{"/api/v1/dashboard/identities/by-region", http.StatusOK},
		{"/api/v1/dashboard/identities/exposure", http.StatusOK},
	} {
		req := httptest.NewRequest(http.MethodGet, tc.url, nil)
		req.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		router.ServeHTTP(w, req)
		if w.Code != tc.want {
			t.Fatalf("GET %s: %d, want %d (%s)", tc.url, w.Code, tc.want, w.Body.String())
		}
		if tc.url == "/api/v1/dashboard/identities/by-class" && !strings.Contains(w.Body.String(), `"total":2`) {
			t.Fatalf("by-class payload: %s", w.Body.String())
		}
		if strings.Contains(w.Body.String(), "account_name") {
			t.Fatalf("account_name must be omitted: %s", w.Body.String())
		}
		if tc.url == "/api/v1/dashboard/identities/by-account" || tc.url == "/api/v1/dashboard/identities/by-region" {
			if !strings.Contains(w.Body.String(), `"credential_count":null`) {
				t.Fatalf("unavailable credential count must be null: %s", w.Body.String())
			}
		}
		if tc.url == "/api/v1/dashboard/identities/exposure" && !strings.Contains(w.Body.String(), `"not_in_iac":null`) {
			t.Fatalf("unavailable IaC count must be null: %s", w.Body.String())
		}
	}
}

// Exercise the real v1 routes with the existing JWT middleware and policy A.
// No credentials database is used: until it exists #6/#7 must return 503.
func TestDashboardCredentialRoutesUnavailable(t *testing.T) {
	const secret = "test-credential-v1-secret"
	token, err := appjwt.GenerateToken(9, "tester@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	src := dashboardSourceStub{}
	h := dashhandlers.NewDashboardCredentialHandler(
		dashservices.NewDashboardCredentialService(dashrepo.NewDashboardCredentialRepository(nil)),
		dashhandlers.NewDashboardAllAccountsScope(src),
	)
	router := SetupRoutes(HandlerContainer{
		AuthMiddleware:             middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}),
		DashboardCredentialHandler: h,
	})
	for _, endpoint := range []string{
		"/api/v1/dashboard/credentials/by-type?account_id=123456789012&region=us-east-1&status=active",
		"/api/v1/dashboard/credentials/hygiene?account_id=123456789012",
	} {
		for _, tc := range []struct {
			auth       bool
			wantStatus int
			wantCode   string
		}{
			{false, http.StatusUnauthorized, "UNAUTHORIZED"},
			{true, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE"},
		} {
			r := httptest.NewRequest(http.MethodGet, endpoint, nil)
			if tc.auth {
				r.Header.Set("Authorization", "Bearer "+token)
			}
			w := httptest.NewRecorder()
			router.ServeHTTP(w, r)
			code := `"code":"` + tc.wantCode + `"`
			if tc.wantStatus == http.StatusUnauthorized { // legacy auth middleware envelope
				code = `"error":"UNAUTHORIZED"`
			}
			if w.Code != tc.wantStatus || !strings.Contains(w.Body.String(), code) {
				t.Fatalf("%s auth=%t: %d %s", endpoint, tc.auth, w.Code, w.Body.String())
			}
		}
	}
	for _, endpoint := range []string{
		"/api/v1/dashboard/credentials/by-type?account_id=999999999999",
		"/api/v1/dashboard/credentials/hygiene?account_id=999999999999",
	} {
		r := httptest.NewRequest(http.MethodGet, endpoint, nil)
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		router.ServeHTTP(w, r)
		if w.Code != http.StatusForbidden {
			t.Fatalf("unknown account %s: %d %s", endpoint, w.Code, w.Body.String())
		}
	}
}
