package routes

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"nhi-backend-api/internal/config"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	dashservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

type measuredCredentials struct{}

func (measuredCredentials) SummaryCredentialCounts(_ context.Context, _ m.SummaryFilter, _, _ time.Time) ([]m.SummaryCredentialRow, error) {
	return []m.SummaryCredentialRow{{Status: "active", CurrentCount: 3, New24h: 1}}, nil
}
func (measuredCredentials) ByAccountCredentialCounts(context.Context, m.AccountFilter) (map[string]int64, error) {
	return map[string]int64{"123456789012": 3}, nil
}
func (measuredCredentials) ByRegionCredentialCounts(context.Context, m.RegionFilter) (map[string]int64, error) {
	return map[string]int64{"us-east-1": 3}, nil
}
func (measuredCredentials) CredentialTypeCounts(context.Context, m.CredentialTypeFilter) ([]m.CredentialTypeCount, error) {
	return []m.CredentialTypeCount{{CredentialType: "access_key", Count: 3}}, nil
}
func (measuredCredentials) CredentialHygiene(context.Context, m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	return nil, m.ErrCredentialSourceUnavailable // no invented risk rules
}

func TestDashboardCredentialBackedHTTPRoutes(t *testing.T) {
	const secret = "measured-credentials-route-test"
	token, err := appjwt.GenerateToken(9, "viewer@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	src := dashboardSourceStub{}
	creds := measuredCredentials{}
	scope := dashhandlers.NewDashboardAllAccountsScope(src)
	router := SetupRoutes(HandlerContainer{
		AuthMiddleware:             middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}),
		Dashboard345Handler:        dashhandlers.NewDashboard345Handler(dashservices.NewDashboardBreakdownService(src, creds), scope),
		DashboardCredentialHandler: dashhandlers.NewDashboardCredentialHandler(dashservices.NewDashboardCredentialService(creds), scope),
	})
	for _, tc := range []struct{ path, fragment string }{
		{"/api/v1/dashboard/summary", `"total_credentials":3`},
		{"/api/v1/dashboard/identities/by-account?identity_type=lambda_function", `"credential_count":3`},
		{"/api/v1/dashboard/identities/by-region?identity_type=lambda_function", `"credential_count":3`},
		{"/api/v1/dashboard/credentials/by-type?status=active", `"credential_type":"access_key"`},
	} {
		r := httptest.NewRequest(http.MethodGet, tc.path, nil)
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		router.ServeHTTP(w, r)
		if w.Code != 200 || !strings.Contains(w.Body.String(), tc.fragment) {
			t.Fatalf("%s: %d %s", tc.path, w.Code, w.Body.String())
		}
	}
	// No policy/usage-history classifications were approved, so #7 cannot
	// return a made-up risk score even though the credential table exists.
	r := httptest.NewRequest(http.MethodGet, "/api/v1/dashboard/credentials/hygiene", nil)
	r.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, r)
	if w.Code != 503 || !strings.Contains(w.Body.String(), `"DATA_SOURCE_UNAVAILABLE"`) {
		t.Fatalf("incomplete hygiene classification: %d %s", w.Code, w.Body.String())
	}
}
