package routes

import (
	"context"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"nhi-backend-api/internal/config"
	inventoryhandler "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/inventory"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	inventoryservice "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
)

const testID = "00000000-0000-0000-0000-000000000001"

type inventoryScopeStub struct{}

func (inventoryScopeStub) AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error) {
	return []string{"123456789012"}, nil
}

type inventoryReaderStub struct{ fail error }

func (s inventoryReaderStub) List(_ context.Context, f m.ListFilter) (*m.ListResponse, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	if len(f.AllowedAccountIDs) != 1 {
		return nil, errors.New("unscoped")
	}
	return &m.ListResponse{Total: 1, Page: f.Page, Limit: f.Limit, Data: []m.IdentitySummary{{ID: testID, ARN: "arn:test", AccountID: "123456789012"}}}, nil
}
func (s inventoryReaderStub) Detail(_ context.Context, _ string, _ []string) (*m.DetailResponse, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return &m.DetailResponse{ID: testID, ARN: "arn:test", AccountID: "123456789012", RawAPIResponse: json.RawMessage(`{"ok":true}`)}, nil
}
func (s inventoryReaderStub) Counts(context.Context, m.CountsFilter) ([]m.CountRow, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return []m.CountRow{{Status: "active", IdentityType: "lambda_function", FunctionalClass: "service", Count: 1}}, nil
}
func (s inventoryReaderStub) Attributes(context.Context, string, []string) (*m.AttributesResponse, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return &m.AttributesResponse{IdentityType: "lambda_function", TypeAttributes: json.RawMessage(`{"runtime":"go"}`)}, nil
}
func (s inventoryReaderStub) Timeline(context.Context, string, []string) (*m.TimelineRecord, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return &m.TimelineRecord{ARN: "arn:test", FirstSeenAt: time.Now().Add(-24 * time.Hour), LastSeenAt: time.Now().Add(-time.Hour)}, nil
}
func (s inventoryReaderStub) Dormant(_ context.Context, f m.DormantFilter, _ time.Time) (*m.DormantResponse, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return &m.DormantResponse{ThresholdDays: f.Days, TotalDormant: 0, Data: []m.DormantItem{}}, nil
}
func (s inventoryReaderStub) ExportRows(context.Context, m.ExportFilter) ([]json.RawMessage, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return []json.RawMessage{json.RawMessage(`{"id":"00000000-0000-0000-0000-000000000001"}`)}, nil
}
func (s inventoryReaderStub) Update(_ context.Context, id string, _ []string, _ map[string]string) (string, error) {
	if s.fail != nil {
		return "", s.fail
	}
	return id, nil
}
func (s inventoryReaderStub) Grouped(context.Context, m.GroupFilter) ([]m.GroupRow, error) {
	if s.fail != nil {
		return nil, s.fail
	}
	return []m.GroupRow{{FunctionalClass: "service", Count: 1, Identity: m.GroupIdentity{ID: testID, Name: "one", IdentityType: "lambda_function", Status: "active"}}}, nil
}

func TestInventoryRoutesAndErrors(t *testing.T) {
	const secret = "inventory-only-test-secret"
	token, err := appjwt.GenerateToken(3, "user@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	router := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{}), inventoryScopeStub{})})
	hit := func(path string, auth bool) *httptest.ResponseRecorder {
		req := httptest.NewRequest("GET", path, nil)
		if auth {
			req.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		router.ServeHTTP(w, req)
		return w
	}
	for _, path := range []string{
		"/api/v1/inventory/identities", "/api/v1/inventory/identities/" + testID,
		"/api/v1/inventory/identities/counts", "/api/v1/inventory/identities/" + testID + "/attributes",
		"/api/v1/inventory/identities/" + testID + "/timeline", "/api/v1/inventory/identities/grouped-by-class",
		"/api/v1/inventory/identities/dormant?days=90", "/api/v1/inventory/identities/export?format=json",
	} {
		if w := hit(path, false); w.Code != 401 {
			t.Errorf("%s without token=%d", path, w.Code)
		}
		if w := hit(path, true); w.Code != 200 {
			t.Errorf("%s with token=%d: %s", path, w.Code, w.Body.String())
		}
	}
	for _, tc := range []struct {
		url    string
		status int
	}{
		{"/api/v1/inventory/identities/counts?account_id=999999999999", 403},
		{"/api/v1/inventory/identities?page=0", 400},
		{"/api/v1/inventory/identities?limit=9999", 400},
		{"/api/v1/inventory/identities?sort_by=name%3Bdrop", 400},
		{"/api/v1/inventory/identities?is_public=maybe", 400},
		{"/api/v1/inventory/identities?last_active_before=bad", 400},
		{"/api/v1/inventory/identities?region=a&region=b", 400},
		{"/api/v1/inventory/identities/grouped-by-class?limit_per_class=0", 400},
		{"/api/v1/inventory/identities/dormant", 400},
		{"/api/v1/inventory/identities/dormant?days=0", 400},
		{"/api/v1/inventory/identities/dormant?days=5000", 400},
		{"/api/v1/inventory/identities/export?format=xml", 400},
		{"/api/v1/inventory/identities/not-a-uuid", 400},
	} {
		if w := hit(tc.url, true); w.Code != tc.status {
			t.Errorf("%s got %d want %d: %s", tc.url, w.Code, tc.status, w.Body.String())
		}
	}
	if w := hit("/api/v1/inventory/identities/counts", true); !strings.Contains(w.Body.String(), `"total":1`) {
		t.Fatalf("static counts route shadowed: %s", w.Body.String())
	}
	// A repository-level not found never distinguishes missing/deleted/out-of-scope.
	absent := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{fail: errors.New("unexpected")}), inventoryScopeStub{})})
	req := httptest.NewRequest("GET", "/api/v1/inventory/identities/"+testID, nil)
	req.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	absent.ServeHTTP(w, req)
	if w.Code != 500 || strings.Contains(w.Body.String(), "unexpected") {
		t.Fatalf("unredacted internal error: %d %s", w.Code, w.Body.String())
	}
	missing := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), InventoryHandler: inventoryhandler.NewHandler(inventoryservice.NewService(inventoryReaderStub{fail: inventoryrepo.ErrNotFound}), inventoryScopeStub{})})
	for _, path := range []string{"/api/v1/inventory/identities/" + testID, "/api/v1/inventory/identities/" + testID + "/attributes", "/api/v1/inventory/identities/" + testID + "/timeline"} {
		req := httptest.NewRequest("GET", path, nil)
		req.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		missing.ServeHTTP(w, req)
		if w.Code != 404 || !strings.Contains(w.Body.String(), `"NOT_FOUND"`) {
			t.Fatalf("missing/deleted identity %s: %d %s", path, w.Code, w.Body.String())
		}
	}
}
