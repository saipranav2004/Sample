package routes

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/lib/pq"

	"nhi-backend-api/internal/config"
	secscanhandlers "nhi-backend-api/internal/handlers/secscan"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/secscan"
	secscanservices "nhi-backend-api/internal/services/secscan"
	appjwt "nhi-backend-api/pkg/jwt"
)

type secscanStub struct{ listErr error }

func (s secscanStub) ListFindings(context.Context, m.FindingsFilter) ([]m.Finding, error) {
	if s.listErr != nil {
		return nil, s.listErr
	}
	uri := "https://github.com/o/r/blob/abc/a.py#L3"
	return []m.Finding{{FindingID: "c/o/r/abc/a.py:3:jwt", ClientID: "c", Repository: "o/r", Platform: "github",
		RiskTier: "HIGH", GitHubURI: &uri, LineNumber: 3}}, nil
}
func (secscanStub) FindingKeyExists(_ context.Context, k m.AllowlistKey) (bool, error) {
	return k.ClientID == "c", nil
}
func (secscanStub) SetDecision(_ context.Context, _, id, _, _, _ string) error {
	if id != "known" {
		return m.ErrNotFound
	}
	return nil
}
func (secscanStub) ListAllowlist(context.Context, string) ([]m.AllowlistEntry, error) {
	return []m.AllowlistEntry{{ClientID: "c", Source: "dashboard"}}, nil
}
func (secscanStub) UpsertDashboardEntry(_ context.Context, e m.AllowlistEntry) (m.AllowlistEntry, error) {
	e.Source = "dashboard"
	return e, nil
}
func (secscanStub) DeleteDashboardEntry(context.Context, m.AllowlistKey) (bool, error) {
	return true, nil
}
func (secscanStub) DeepScan(context.Context, string, string) (*m.DeepScan, error) { return nil, nil }

const secscanSecret = "secscan-route-test"

func secscanRouter(t *testing.T, repo secscanservices.Repository) http.Handler {
	t.Helper()
	return SetupRoutes(HandlerContainer{
		AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secscanSecret}),
		SecscanHandler: secscanhandlers.NewHandler(secscanservices.NewService(repo)),
	})
}

func secscanToken(t *testing.T, role string) string {
	t.Helper()
	token, err := appjwt.GenerateToken(7, role+"@example.test", role, "security", secscanSecret, 1)
	if err != nil {
		t.Fatal(err)
	}
	return token
}

func secscanCall(t *testing.T, h http.Handler, method, path, role, contentType, body string) *httptest.ResponseRecorder {
	t.Helper()
	r := httptest.NewRequest(method, path, strings.NewReader(body))
	if role != "" {
		r.Header.Set("Authorization", "Bearer "+secscanToken(t, role))
	}
	if contentType != "" {
		r.Header.Set("Content-Type", contentType)
	}
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	return w
}

const keyBody = `{"client_id":"c","file_path":"config.py","detector":"aws_access_key_id","redacted":"AKIA****MNOP"}`

func TestSecscanRoutes(t *testing.T) {
	h := secscanRouter(t, secscanStub{})
	cases := []struct {
		name, method, path, role, ctype, body string
		status                                int
		fragment                              string
	}{
		{"findings need a token", "GET", "/api/findings", "", "", "", 401, ""},
		{"findings shape", "GET", "/api/findings", "auditor", "", "", 200, `"count":1,"findings":[{"finding_id":"c/o/r/abc/a.py:3:jwt"`},
		{"findings keep nulls", "GET", "/api/findings?platform=github", "auditor", "", "", 200, `"codecommit_uri":null`},
		{"unknown filter", "GET", "/api/findings?severity=high", "auditor", "", "", 400, `"INVALID_FILTER"`},
		{"bad platform", "GET", "/api/findings?platform=gitlab", "auditor", "", "", 400, `"INVALID_REQUEST"`},
		{"allowlist shape", "GET", "/api/allowlist", "developer", "", "", 200, `"entries":[{"client_id":"c"`},
		{"dismiss", "POST", "/api/allowlist", "admin", "application/json", keyBody, 200, `"ok":true,"entry":{"client_id":"c"`},
		{"dismiss attributes reviewer", "POST", "/api/allowlist", "team_lead", "application/json; charset=utf-8", keyBody, 200, `"dismissed_by":"team_lead@example.test"`},
		{"dismiss forbidden role", "POST", "/api/allowlist", "developer", "application/json", keyBody, 403, `"FORBIDDEN"`},
		{"dismiss wrong content type", "POST", "/api/allowlist", "admin", "text/plain", keyBody, 415, ""},
		{"dismiss unknown field", "POST", "/api/allowlist", "admin", "application/json", `{"client_id":"c","x":1}`, 400, `"INVALID_BODY"`},
		{"dismiss two objects", "POST", "/api/allowlist", "admin", "application/json", keyBody + keyBody, 400, `"INVALID_BODY"`},
		{"dismiss missing field", "POST", "/api/allowlist", "admin", "application/json", `{"client_id":"c"}`, 400, `"INVALID_REQUEST"`},
		{"dismiss unknown finding", "POST", "/api/allowlist", "admin", "application/json", strings.Replace(keyBody, `"c"`, `"other"`, 1), 404, `"NOT_FOUND"`},
		{"dismiss too large", "POST", "/api/allowlist", "admin", "application/json", `{"reason":"` + strings.Repeat("x", 20000) + `"}`, 413, ""},
		{"restore", "DELETE", "/api/allowlist", "admin", "application/json", keyBody, 200, `{"ok":true}`},
		{"restore forbidden", "DELETE", "/api/allowlist", "auditor", "application/json", keyBody, 403, ""},
		{"decision", "POST", "/api/findings/decision", "admin", "application/json", `{"finding_id":"known","platform":"github","decision":"real_secret"}`, 200, `{"ok":true}`},
		{"decision missing finding", "POST", "/api/findings/decision", "admin", "application/json", `{"finding_id":"gone","platform":"github","decision":"real_secret"}`, 404, ""},
		{"decision bad value", "POST", "/api/findings/decision", "admin", "application/json", `{"finding_id":"known","platform":"github","decision":"maybe"}`, 400, ""},
		{"deep scan status", "GET", "/api/deep-scan-status?client_id=c&repository=o/r", "developer", "", "", 200, `{"status":"not_started"}`},
		{"deep scan status needs params", "GET", "/api/deep-scan-status?client_id=c", "developer", "", "", 400, ""},
		{"deep scan trigger", "POST", "/api/deep-scan", "admin", "application/json", `{"client_id":"c","repository":"r"}`, 501, `"DEEP_SCAN_UNAVAILABLE"`},
		// The shared router answers an unregistered method with 404, as for
		// every other route; it must never reach a handler.
		{"wrong method", "PUT", "/api/allowlist", "admin", "application/json", keyBody, 404, ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := secscanCall(t, h, tc.method, tc.path, tc.role, tc.ctype, tc.body)
			if w.Code != tc.status || !strings.Contains(w.Body.String(), tc.fragment) {
				t.Fatalf("got %d %s", w.Code, w.Body.String())
			}
			if w.Code >= 200 && w.Code < 300 && w.Header().Get("Cache-Control") != "no-store" {
				t.Fatal("secret findings must not be cached")
			}
		})
	}
}

func TestSecscanSourceErrorsAreSanitized(t *testing.T) {
	missing := fmt.Errorf("query findings: %w", &pq.Error{Code: "42P01", Message: `relation "nhi_scanner.secscan_findings_github" does not exist`})
	for _, tc := range []struct {
		err    error
		status int
	}{
		{fmt.Errorf("%w: sqlstate 42P01", m.ErrSourceUnavailable), 503},
		{context.DeadlineExceeded, 504},
		{missing, 500},
	} {
		h := secscanRouter(t, secscanStub{listErr: tc.err})
		w := secscanCall(t, h, "GET", "/api/findings", "admin", "", "")
		if w.Code != tc.status || strings.Contains(w.Body.String(), "nhi_scanner") || strings.Contains(w.Body.String(), "relation") {
			t.Fatalf("%v: got %d %s", tc.err, w.Code, w.Body.String())
		}
	}
}

func TestSecscanRoutesAreOptional(t *testing.T) {
	// Without a secscan handler the router still builds and the route is absent.
	h := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secscanSecret})})
	w := secscanCall(t, h, "GET", "/api/findings", "admin", "", "")
	if w.Code != 404 {
		t.Fatalf("expected 404, got %d", w.Code)
	}
}
