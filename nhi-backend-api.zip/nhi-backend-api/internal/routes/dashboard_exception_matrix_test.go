package routes

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/lib/pq"
	"nhi-backend-api/internal/config"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/dashboard"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	dashservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
)

type faultyDashboardReader struct{ dashboardSourceStub }

func (faultyDashboardReader) ByType(context.Context, m.TypeFilter) ([]m.IdentityTypeCount, error) {
	return nil, &pq.Error{Code: "42P01"}
}
func (faultyDashboardReader) ByClass(context.Context, m.ClassFilter) ([]m.FunctionalClassCount, error) {
	return nil, &pq.Error{Code: "42P01"}
}
func (faultyDashboardReader) ByAccountIdentityCounts(context.Context, m.AccountFilter) ([]m.AccountIdentityCount, error) {
	return nil, &pq.Error{Code: "42P01"}
}
func (faultyDashboardReader) ByRegionIdentityCounts(context.Context, m.RegionFilter) ([]m.RegionIdentityCount, error) {
	return nil, &pq.Error{Code: "42P01"}
}
func (faultyDashboardReader) ExposureCounts(context.Context, m.ExposureFilter, time.Time) ([]m.ExposureCountRow, error) {
	return nil, &pq.Error{Code: "42P01"}
}
func (faultyDashboardReader) SummaryIdentityCounts(context.Context, m.SummaryFilter, time.Time, time.Time) ([]m.SummaryIdentityRow, error) {
	return nil, &pq.Error{Code: "42P01"}
}

func TestAllEightDashboardExceptionEnvelope(t *testing.T) {
	const secret = "all-eight-test-secret"
	token, err := appjwt.GenerateToken(9, "viewer@example.test", "viewer", "team", secret, 1)
	if err != nil {
		t.Fatal(err)
	}
	reader := faultyDashboardReader{}
	scope := dashhandlers.NewDashboardAllAccountsScope(reader)
	router := SetupRoutes(HandlerContainer{AuthMiddleware: middleware.NewAuthMiddleware(config.JWTConfig{Secret: secret}), Dashboard345Handler: dashhandlers.NewDashboard345Handler(dashservices.NewDashboardBreakdownService(reader), scope), DashboardCredentialHandler: dashhandlers.NewDashboardCredentialHandler(dashservices.NewDashboardCredentialService(dashrepo.NewDashboardCredentialRepository(nil)), scope)})
	for _, p := range []string{"/api/v1/dashboard/summary", "/api/v1/dashboard/identities/by-type", "/api/v1/dashboard/identities/by-class", "/api/v1/dashboard/identities/by-account", "/api/v1/dashboard/identities/by-region", "/api/v1/dashboard/credentials/by-type", "/api/v1/dashboard/credentials/hygiene", "/api/v1/dashboard/identities/exposure"} {
		for _, tc := range []struct {
			suffix string
			auth   bool
			want   int
			code   string
		}{
			{"", false, 401, `"UNAUTHORIZED"`},
			{"?unknown_filter=bad", true, 400, `"INVALID_FILTER"`},
			{"?account_id=999999999999", true, 403, `"FORBIDDEN"`},
			{"", true, 503, `"DATA_SOURCE_UNAVAILABLE"`},
		} {
			req := httptest.NewRequest(http.MethodGet, p+tc.suffix, nil)
			if tc.auth {
				req.Header.Set("Authorization", "Bearer "+token)
			}
			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)
			// #4 supports region/type only, not account_id, so an unsupported filter is 400.
			want := tc.want
			code := tc.code
			if p == "/api/v1/dashboard/identities/by-account" && tc.suffix == "?account_id=999999999999" {
				want = 400
				code = `"INVALID_FILTER"`
			}
			if w.Code != want || !strings.Contains(w.Body.String(), code) {
				t.Errorf("%s%s auth=%t: %d %s want %d %s", p, tc.suffix, tc.auth, w.Code, w.Body.String(), want, code)
			}
		}
	}
}
