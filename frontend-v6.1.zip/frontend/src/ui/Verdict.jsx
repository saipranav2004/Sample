import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Skeleton } from './Skeleton';
import { TONE_FG, TONE_VAR, cn } from './cn';

const SEVERITY = { critical: 'Critical', high: 'High', medium: 'Medium' };

/**
 * The answer to "is anything wrong with this, and what do I do?", first on
 * the record: the worst findings, each with its next step. A clean record
 * says so in one line instead of leaving the reader to scan every check.
 *
 * findings: [{ key, tone, label, detail?, next? }], worst first, or null
 * while the evidence is still loading.
 */
export function Verdict({ findings, max = 3, cleanText, moreText, className }) {
  if (findings === null || findings === undefined) {
    return <Skeleton className={cn('h-[84px] w-full rounded-[var(--radius-panel)]', className)} />;
  }
  if (findings.length === 0) {
    return (
      <section
        aria-label="Verdict"
        className={cn('flex items-start gap-3 rounded-[var(--radius-panel)] border border-line border-l-[3px] bg-surface px-4 py-3', className)}
        style={{ borderLeftColor: TONE_VAR.low }}
      >
        <CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-low" />
        <div className="min-w-0">
          <h3 className="text-[13.5px] font-semibold text-ink">Nothing needs attention</h3>
          {cleanText && <p className="mt-0.5 text-[12.5px] text-ink-3">{cleanText}</p>}
        </div>
      </section>
    );
  }
  const worst = findings[0].tone;
  const shown = findings.slice(0, max);
  const hidden = findings.length - shown.length;
  return (
    <section
      aria-label="Verdict"
      className={cn('rounded-[var(--radius-panel)] border border-line border-l-[3px] bg-surface px-4 py-3', className)}
      style={{ borderLeftColor: TONE_VAR[worst] }}
    >
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        <AlertTriangle aria-hidden="true" className={cn('size-4 shrink-0', TONE_FG[worst])} />
        <h3 className="text-[13.5px] font-semibold text-ink">
          {findings.length === 1 ? '1 thing needs attention' : `${findings.length} things need attention`}
        </h3>
        <span className={cn('text-[11px] font-semibold tracking-[0.06em] uppercase', TONE_FG[worst])}>{SEVERITY[worst] ?? ''}</span>
      </div>
      <ol className="mt-2 flex flex-col gap-1.5">
        {shown.map((finding) => (
          <li key={finding.key} className="flex items-start gap-2.5 text-[12.5px]">
            <span aria-hidden="true" className="mt-[6px] size-[7px] shrink-0 rounded-full" style={{ background: TONE_VAR[finding.tone] }} />
            <span className="min-w-0">
              <span className={cn('font-semibold', TONE_FG[finding.tone])}>{finding.label}</span>
              {finding.detail && <span className="text-ink-3"> · {finding.detail}</span>}
              {finding.next && <span className="block text-ink-2">{finding.next}</span>}
            </span>
          </li>
        ))}
      </ol>
      {hidden > 0 && <p className="mt-2 text-[12px] text-ink-3">{moreText ? moreText(hidden) : `+${hidden} more below`}</p>}
    </section>
  );
}
