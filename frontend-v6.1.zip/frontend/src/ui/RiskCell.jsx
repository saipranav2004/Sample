import { CircleCheck } from 'lucide-react';
import { TONE_BG, TONE_FG, cn } from './cn';

/**
 * The worst thing about a row, then how many more there are (reference
 * console's status column). The full list is in the tooltip and on the
 * record itself, so the column stays one line wide.
 */
export function RiskCell({ signals, clearLabel = 'No issues' }) {
  if (!signals.length) {
    return (
      <span className="inline-flex items-center gap-1.5 text-[12px] font-medium text-low">
        <CircleCheck aria-hidden="true" className="size-3.5" />
        {clearLabel}
      </span>
    );
  }
  const [first, ...rest] = signals;
  return (
    <span className="flex min-w-0 items-center gap-1.5" title={signals.map((signal) => signal.label).join(' · ')}>
      <span aria-hidden="true" className={cn('size-1.5 shrink-0 rounded-full', TONE_BG[first.tone] ?? TONE_BG.neutral)} />
      <span className={cn('truncate text-[12.5px] font-semibold', first.tone === 'neutral' ? 'text-ink-2' : TONE_FG[first.tone])}>{first.label}</span>
      {rest.length > 0 && (
        <span data-numeric="" className="shrink-0 rounded-full bg-surface-3 px-1.5 py-px text-[10.5px] font-semibold text-ink-2">
          +{rest.length}
        </span>
      )}
    </span>
  );
}
