import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Link2Off, SearchX } from 'lucide-react';
import { fetchOrphanedCredentials } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatNumber } from '../../lib/format';
import { credentialBadge, credentialTypeLabel } from '../../lib/labels';
import { Reveal } from '../../lib/motion';
import { RecordPreview } from '../preview/RecordPreview';
import { DataGrid } from '../../ui/DataGrid';
import { FilterSelect } from '../../ui/FilterBar';
import { Freshness } from '../../ui/Freshness';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState } from '../../ui/States';
import { RefreshButton, TableToolbar } from '../../ui/TableTools';
import { TypeBadge } from '../../ui/TypeBadge';
import { RecordBar, ResultCount } from '../../ui/WorkArea';
import { AgeCell } from './parts';

const PAGE_SIZES = [25, 50, 100];
const TOKEN = /^[a-zA-Z0-9_-]{1,100}$/;

/**
 * Credentials no identity holds: GET /api/v1/orphaned-credentials. The API
 * returns every one in the latest completed scan, across all accounts, with
 * no filters or paging, so the type filter and the pages are applied here.
 * Rows carry `credential_id`; they are mapped to `id` so the preview drawer
 * and the detail link work the same as on every other list.
 */
export function OrphanedView() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = useQuery((signal) => fetchOrphanedCredentials(signal), []);

  const page = Math.max(1, Number.parseInt(searchParams.get('page') ?? '1', 10) || 1);
  const limit = PAGE_SIZES.includes(Number(searchParams.get('limit'))) ? Number(searchParams.get('limit')) : 25;
  const credentialType = TOKEN.test(searchParams.get('credential_type') ?? '') ? searchParams.get('credential_type') : '';

  const update = (changes, keepPage = false) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  const all = useMemo(
    () => (query.data?.orphaned ?? []).map((row) => ({ ...row, id: row.credential_id })),
    [query.data],
  );
  const typeOptions = useMemo(() => {
    const counts = new Map();
    for (const row of all) counts.set(row.credential_type, (counts.get(row.credential_type) ?? 0) + 1);
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([value, count]) => ({ value, label: `${credentialTypeLabel(value)} (${count})` }));
  }, [all]);
  const matching = credentialType ? all.filter((row) => row.credential_type === credentialType) : all;
  const total = matching.length;
  const lastPage = Math.max(1, Math.ceil(total / limit));
  const current = Math.min(page, lastPage);
  const rows = useMemo(() => matching.slice((current - 1) * limit, current * limit), [matching, current, limit]);

  const [peek, setPeek] = useState(null);
  const [peekRows, setPeekRows] = useState(rows);
  if (peekRows !== rows) {
    setPeekRows(rows);
    if (peek !== null) setPeek(null);
  }

  const columns = [
    {
      key: 'name',
      header: 'Credential',
      primary: true,
      cell: (row) => {
        const badge = credentialBadge(row.credential_type);
        return (
          <span className="flex min-w-0 items-center gap-3">
            <TypeBadge code={badge.code} color={badge.color} />
            <span className="min-w-0">
              <span className="block truncate text-[13px] font-semibold text-ink" title={row.name || row.id}>
                {row.name || row.id}
              </span>
              <span className="block truncate text-[11px] text-ink-3">{credentialTypeLabel(row.credential_type)}</span>
            </span>
          </span>
        );
      },
    },
    {
      key: 'last_used_at',
      header: 'Last used',
      width: '160px',
      mobile: true,
      cell: (row) => <Freshness value={row.last_used_at} empty="Never used" emptyTitle="No recorded use, or AWS does not report use for this type" />,
    },
    {
      key: 'days_unused',
      header: 'Unused for',
      width: '120px',
      cell: (row) =>
        row.days_unused === null || row.days_unused === undefined ? (
          <span className="text-ink-3">-</span>
        ) : (
          <span data-numeric="" className="font-semibold text-ink">
            {formatNumber(row.days_unused)} day{row.days_unused === 1 ? '' : 's'}
          </span>
        ),
    },
    {
      key: 'created_at_aws',
      header: 'Age',
      width: '120px',
      priority: 'wide',
      cell: (row) => <AgeCell value={row.created_at_aws} />,
    },
  ];

  return (
    <>
      <Reveal>
        <Panel flush className="overflow-hidden">
          <RecordBar
            trailing={
              <TableToolbar>
                <RefreshButton onRefresh={query.refetch} refreshing={query.isRefreshing} />
              </TableToolbar>
            }
          >
            <FilterSelect label="Type" value={credentialType} options={typeOptions} onChange={(value) => update({ credential_type: value })} />
            <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'credential' : 'credentials'} loading={!query.data} />
          </RecordBar>
          <p className="border-b border-line bg-surface px-4 py-2 text-[12.5px] text-ink-3">
            No identity is bound to these in the latest completed scan, across every account. Confirm nothing outside AWS depends on one, then retire it. Never used comes first.
          </p>

          {query.isError && !query.data ? (
            <ErrorState error={query.error} onRetry={query.refetch} />
          ) : (
            <>
              <DataGrid
                caption="Credentials held by no identity"
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                loading={!query.data}
                refreshing={query.isRefreshing}
                onRowClick={(row, event) => {
                  if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                  else setPeek(rows.indexOf(row));
                }}
                selectedKey={peek !== null ? rows[peek]?.id : undefined}
                rowLabel={(row) => `Preview ${row.name || row.id}`}
                skeletonRows={8}
                emptyState={
                  credentialType ? (
                    <EmptyState icon={SearchX} title="None of this type" description="Choose another type to widen the list." />
                  ) : (
                    <EmptyState icon={Link2Off} title="Every credential has a holder" description="Each credential in the latest scan is bound to at least one identity." />
                  )
                }
              />
              {total > 0 && (
                <Pagination
                  page={current}
                  pageSize={limit}
                  total={total}
                  pageSizes={PAGE_SIZES}
                  unit="credentials"
                  onPageChange={(next) => update({ page: next > 1 ? next : '' }, true)}
                  onPageSizeChange={(size) => update({ limit: size })}
                />
              )}
            </>
          )}
        </Panel>
      </Reveal>
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </>
  );
}
