import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarClock, Copy, Download, FileJson, Hourglass, KeyRound, Link2Off, SearchX } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchCredentialCounts, fetchCredentials, fetchExpiringCredentials, fetchOrphanedCredentials, fetchStaleCredentials } from '../../lib/api/endpoints';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { formatNumber } from '../../lib/format';
import { credentialBadge, credentialTypeLabel, regionLabel, statusMeta } from '../../lib/labels';
import { Page, Reveal } from '../../lib/motion';
import { useExport } from '../../lib/useExport';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { Button, IconButton } from '../../ui/Button';
import { DataGrid } from '../../ui/DataGrid';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Input, SearchInput } from '../../ui/Field';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState, InlineError } from '../../ui/States';
import { OverflowMenu, RefreshButton, TableSettings, TableToolbar } from '../../ui/TableTools';
import { RecordPreview } from '../preview/RecordPreview';
import { useToast } from '../../ui/Toast';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { copyText } from '../identities/IdentitiesPage';
import { ClockView } from './ClockView';
import { OrphanedView } from './OrphanedView';
import { Tabs } from '../../ui/Tabs';
import { AgeCell, ExpiryCell, PrivilegeCell } from './parts';
import { Freshness } from '../../ui/Freshness';
import { RiskCell } from '../../ui/RiskCell';
import { credentialSignals } from '../../lib/signals';
import { TypeBadge } from '../../ui/TypeBadge';
import { cn } from '../../ui/cn';
import { EXPORT_SORTABLE, FILTER_KEYS, PAGE_SIZES, appliedCount, readListState } from './query';

const DENSITY_KEY = 'nhi.grid.density';

const LABELS = {
  search: 'Search',
  credential_type: 'Type',
  account_id: 'Account',
  region: 'Region',
  status: 'Status',
  rotation_enabled: 'Rotation',
  expiring_within_days: 'Expires within',
  stale_days: 'Unused for',
  privilege_level_min: 'Privilege',
  privilege_level_max: 'Privilege',
  owner_principal_arn: 'Owner',
};

const PRIVILEGE_BANDS = [
  { value: '8-10', label: 'Critical (8-10)' },
  { value: '6-7', label: 'High (6-7)' },
  { value: '4-5', label: 'Medium (4-5)' },
  { value: '0-3', label: 'Low (0-3)' },
];

/**
 * Credential inventory: GET /api/v1/inventory/credentials, filtered, sorted
 * and paged on the server. All state lives in the URL.
 */
export default function CredentialsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { can, lock } = useAccess();
  const { railOpen, toggleRail } = useFacetRail();
  const tableTop = useRef(null);
  const state = useMemo(() => readListState(searchParams), [searchParams]);
  const { filters, page, limit, sort } = state;

  const [searchDraft, setSearchDraft] = useState(filters.search);
  const debouncedSearch = useDebouncedValue(searchDraft.trim().slice(0, 256), 320);
  const [density, setDensity] = useState(() => {
    try {
      return localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable';
    } catch {
      return 'comfortable';
    }
  });

  const update = (changes, { keepPage = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  useEffect(() => {
    if (debouncedSearch !== filters.search) update({ search: debouncedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);
  useEffect(() => {
    setSearchDraft((draft) => (draft.trim() === filters.search ? draft : filters.search));
  }, [filters.search]);

  const listKey = JSON.stringify([filters, page, limit, sort]);
  const list = useQuery(
    (signal) => fetchCredentials({ ...filters, page, limit, sort_by: sort.key, sort_order: sort.direction }, signal),
    [listKey],
    { enabled: !['expiring', 'stale', 'orphaned'].includes(searchParams.get('view')) },
  );
  const counts = useQuery(
    (signal) => fetchCredentialCounts({ account_id: filters.account_id, region: filters.region }, signal),
    [filters.account_id, filters.region],
  );
  const filterQuery = useFilterOptions();
  const options = optionsOf(filterQuery);

  const rows = list.data?.data ?? [];
  /* Index of the row open in the preview drawer. */
  const [peek, setPeek] = useState(null);
  /* A new page of results closes the preview: its index would point at a
     different record. */
  const [peekData, setPeekData] = useState(list.data);
  if (peekData !== list.data) {
    setPeekData(list.data);
    if (peek !== null) setPeek(null);
  }
  const total = list.data?.total ?? 0;
  const applied = appliedCount(filters);

  useEffect(() => {
    if (!list.data || rows.length > 0 || total === 0 || page === 1) return;
    update({ page: Math.max(1, Math.ceil(total / limit)) }, { keepPage: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [list.data]);

  const clearAll = () => {
    setSearchDraft('');
    update(Object.fromEntries(FILTER_KEYS.map((key) => [key, ''])));
  };

  const exporter = useExport('credentials');
  const onExport = (format) =>
    exporter.run(format, {
      ...filters,
      ...(EXPORT_SORTABLE.has(sort.key) ? { sort_by: sort.key, sort_order: sort.direction } : {}),
    });

  const chips = FILTER_KEYS.filter((key) => filters[key] && key !== 'privilege_level_max')
    .map((key) => ({ key, label: LABELS[key], value: describe(key, filters) }))
    .concat(
      filters.privilege_level_max && !filters.privilege_level_min
        ? [{ key: 'privilege_level_max', label: 'Privilege', value: `0-${filters.privilege_level_max}` }]
        : [],
    );

  const facetGroups = useFacets({ filters, counts: counts.data, options, update });

  /* The view tabs: the whole inventory, the two clocks people act on, and
     credentials nobody holds. Each count is the same request its view makes,
     at the window in use, so a tab and its list never disagree. */
  const view = ['expiring', 'stale', 'orphaned'].includes(searchParams.get('view')) ? searchParams.get('view') : 'all';
  const windowDays = (key, fallback) => {
    const n = Number(searchParams.get('days'));
    return view === key && Number.isInteger(n) && n >= 1 ? n : fallback;
  };
  const expiringDays = windowDays('expiring', 30);
  const staleDays = windowDays('stale', 90);
  const expiringCount = useQuery((signal) => fetchExpiringCredentials({ days: expiringDays, limit: 1 }, signal), [expiringDays]);
  const staleCount = useQuery((signal) => fetchStaleCredentials({ days: staleDays, limit: 1 }, signal), [staleDays]);
  const orphanedCount = useQuery((signal) => fetchOrphanedCredentials(signal), []);
  const viewTabs = [
    { value: 'all', label: 'All credentials', icon: KeyRound, count: counts.data ? formatNumber(counts.data.total) : undefined },
    { value: 'expiring', label: `Expiring in ${expiringDays} days`, icon: CalendarClock, count: expiringCount.data ? formatNumber(expiringCount.data.total_expiring) : undefined },
    { value: 'stale', label: `Unused ${staleDays}+ days`, icon: Hourglass, count: staleCount.data ? formatNumber(staleCount.data.total_stale) : undefined },
    { value: 'orphaned', label: 'No holder', icon: Link2Off, count: orphanedCount.data ? formatNumber(orphanedCount.data.total) : undefined },
  ];
  const setView = (next) => {
    setSearchDraft('');
    setSearchParams(next === 'all' ? {} : { view: next });
  };

  const columns = [
    {
      key: 'name',
      header: 'Credential',
      primary: true,
      sortable: true,
      width: '25%',
      cell: (row) => {
        const badge = credentialBadge(row.credential_type);
        return (
          <span className="flex min-w-0 items-center gap-3">
            <TypeBadge code={badge.code} color={badge.color} />
            <span className="min-w-0">
              <span
                className={cn('block truncate text-[13px] font-semibold text-ink', row.credential_type === 'access_key' && 'font-mono text-[12.5px]')}
                title={row.name || row.arn}
              >
                {row.name || row.arn}
              </span>
              <span className="block truncate text-[11px] text-ink-3">{credentialTypeLabel(row.credential_type)}</span>
            </span>
          </span>
        );
      },
    },
    {
      /* The principal the scanner records as owning the credential. Not the
         same as which identities are bound to it (Held by, on the record):
         a credential can have an owner principal and still have no holder. */
      key: 'owner_principal_arn',
      header: 'Owner principal',
      width: '170px',
      priority: 'wide',
      cell: (row) =>
        row.owner_principal_arn ? (
          <span className="block min-w-0" title={row.owner_principal_arn}>
            <span className="block truncate font-mono text-[12px] text-ink">{String(row.owner_principal_arn).split(':').pop()}</span>
            <span className="block truncate text-[11px] text-ink-3">{String(row.owner_principal_arn).split(':')[4] || row.account_id}</span>
          </span>
        ) : (
          <span className="block min-w-0">
            <span className="block truncate text-ink-3 italic">None recorded</span>
            <span className="block truncate font-mono text-[11px] text-ink-3">{row.account_id}</span>
          </span>
        ),
    },
    {
      key: 'risk',
      header: 'Needs attention',
      width: '188px',
      mobile: true,
      cell: (row) => <RiskCell signals={credentialSignals(row)} />,
    },
    {
      key: 'privilege_level',
      header: 'Privilege',
      sortable: true,
      width: '112px',
      priority: 'xl',
      cell: (row) => <PrivilegeCell level={row.privilege_level} credentialType={row.credential_type} />,
    },
    {
      key: 'last_used_at',
      header: 'Last used',
      sortable: true,
      width: '140px',
      mobile: true,
      cell: (row) => <Freshness value={row.last_used_at} empty="Never used" emptyTitle="No recorded use, or AWS does not report use for this type" />,
    },
    {
      key: 'expires_at',
      header: 'Expires',
      sortable: true,
      width: '128px',
      mobile: true,
      cell: (row) => <ExpiryCell value={row.expires_at} />,
    },
    {
      key: 'created_at_aws',
      header: 'Age',
      sortable: true,
      width: '112px',
      priority: 'xl',
      cell: (row) => <AgeCell value={row.created_at_aws} />,
    },
  ];

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Credentials"
          lede="Roles, access keys, secrets, certificates and parameters the scanner found. Open one for its hygiene, trust policy and permissions."
          tabs={<Tabs size="sm" tabs={viewTabs} value={view} onChange={setView} />}
          actions={
            <Button
              variant="secondary"
              icon={Download}
              loading={exporter.exporting === 'csv'}
              disabled={Boolean(exporter.exporting)}
              locked={lock('data.export')}
              onClick={() => onExport('csv')}
            >
              Export CSV
            </Button>
          }
        />
      </Reveal>

      {view === 'orphaned' ? (
        <OrphanedView />
      ) : view !== 'all' ? (
        <ClockView view={view} />
      ) : (
      <>
      <Reveal>
        <div ref={tableTop} className="scroll-mt-20">
        <WorkArea
          railOpen={railOpen}
          rail={<FacetRail groups={facetGroups} appliedCount={applied} onClearAll={clearAll} onClose={toggleRail} />}
        >
          <Panel flush className="overflow-hidden">
            <RecordBar
              trailing={
                <TableToolbar>
                  {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={applied} />}
                  <RefreshButton onRefresh={list.refetch} refreshing={list.isRefreshing} />
                  <TableSettings
                    density={density}
                    onDensityChange={(value) => {
                      setDensity(value);
                      try {
                        localStorage.setItem(DENSITY_KEY, value);
                      } catch {
                        /* a reading preference; safe to lose */
                      }
                    }}
                  />
                  <OverflowMenu
                    items={[
                      {
                        key: 'json',
                        label: 'Export as JSON',
                        hint: 'Every credential matching these filters, with full records',
                        icon: FileJson,
                        onSelect: () => onExport('json'),
                        disabled: Boolean(exporter.exporting) || !can('data.export'),
                        disabledHint: exporter.exporting ? 'An export is already running' : lock('data.export'),
                      },
                    ]}
                  />
                </TableToolbar>
              }
            >
              <SearchInput
                size="sm"
                value={searchDraft}
                onChange={setSearchDraft}
                maxLength={256}
                placeholder="Search name or ARN…"
                className="w-full min-w-0 sm:max-w-sm"
              />
              <ResultCount shown={formatNumber(total)} unit={total === 1 ? 'credential' : 'credentials'} loading={list.isLoading && !list.data} />
            </RecordBar>

            <AppliedFilters
              filters={chips}
              onRemove={(key) => {
                if (key === 'search') setSearchDraft('');
                if (key === 'privilege_level_min' || key === 'privilege_level_max') update({ privilege_level_min: '', privilege_level_max: '' });
                else update({ [key]: '' });
              }}
              onClearAll={clearAll}
            />

            {list.isError && !list.data ? (
              <ErrorState error={list.error} onRetry={list.refetch} />
            ) : (
              <>
                {list.isError && (
                  <div className="p-3">
                    <InlineError error={list.error} onRetry={list.refetch} label="Could not refresh" />
                  </div>
                )}
                <DataGrid
                  caption="Credentials"
                  columns={columns}
                  rows={rows}
                  rowKey={(row) => row.id}
                  loading={list.isLoading && !list.data}
                  refreshing={list.isRefreshing || (list.isLoading && Boolean(list.data))}
                  onRowClick={(row, event) => {
                    if (event?.metaKey || event?.ctrlKey) window.open(`/credentials/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                    else setPeek(rows.indexOf(row));
                  }}
                  selectedKey={peek !== null ? rows[peek]?.id : undefined}
                  rowLabel={(row) => `Preview ${row.name || row.arn}`}
                  sort={sort}
                  onSortChange={(next) => update({ sort_by: next.key, sort_order: next.direction })}
                  density={density}
                  skeletonRows={10}
                  rowActions={(row) => (
                    <IconButton
                      icon={Copy}
                      label={`Copy ARN for ${row.name || row.arn}`}
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation();
                        copyText(row.arn).then((ok) =>
                          notify(
                            ok
                              ? { variant: 'success', title: 'ARN copied', duration: 2200 }
                              : { variant: 'error', title: 'Copy failed', description: 'The browser blocked clipboard access.' },
                          ),
                        );
                      }}
                    />
                  )}
                  emptyState={
                    applied > 0 ? (
                      <EmptyState
                        icon={SearchX}
                        title="No credentials match these filters"
                        description="Remove a filter or change the search to widen the list."
                        action={
                          <Button variant="secondary" size="sm" onClick={clearAll}>
                            Clear all filters
                          </Button>
                        }
                      />
                    ) : (
                      <EmptyState title="No credentials discovered yet" description="Credentials appear here after the scanner completes a discovery run." />
                    )
                  }
                />
                {total > 0 && (
                  <Pagination
                    page={page}
                    pageSize={limit}
                    total={total}
                    pageSizes={PAGE_SIZES}
                    unit={total === 1 ? 'credential' : 'credentials'}
                    scrollTarget={tableTop}
                    onPageChange={(next) => update({ page: next > 1 ? next : '' }, { keepPage: true })}
                    onPageSizeChange={(size) => update({ limit: size })}
                  />
                )}
              </>
            )}
          </Panel>
        </WorkArea>
        </div>
      </Reveal>
      </>
      )}
      <RecordPreview kind="credential" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </Page>
  );
}

function describe(key, filters) {
  const value = filters[key];
  switch (key) {
    case 'credential_type':
      return credentialTypeLabel(value);
    case 'status':
      return statusMeta(value).label;
    case 'region':
      return regionLabel(value);
    case 'rotation_enabled':
      return value === 'true' ? 'On' : 'Off';
    case 'expiring_within_days':
      return `${value} days`;
    case 'stale_days':
      return `${value} days`;
    case 'privilege_level_min':
      return `${value}-${filters.privilege_level_max || 10}`;
    default:
      return value;
  }
}

/* ── Facets ──────────────────────────────────────────────────────────────── */

function useFacets({ filters, counts, options, update }) {
  const [ownerDraft, setOwnerDraft] = useState(filters.owner_principal_arn);
  useEffect(() => setOwnerDraft(filters.owner_principal_arn), [filters.owner_principal_arn]);

  const single = (key, label, opts, extra = {}) => ({
    key,
    label,
    single: true,
    options: opts.map((option) => ({ ...option, active: filters[key] === option.value })),
    onToggle: (value) => update({ [key]: value }),
    ...extra,
  });

  const byType = counts?.by_type ?? {};
  const typeValues = [...new Set([...options.credentialTypes, ...Object.keys(byType)])].sort((a, b) => (byType[b] ?? 0) - (byType[a] ?? 0));
  const statusCounts = counts ? { active: counts.active, inactive: counts.inactive, expired: counts.expired } : {};
  const credentialStatuses = ['active', 'inactive', 'expired', 'pending_deletion'].filter(
    (status) => options.statuses.includes(status) || statusCounts[status] > 0 || filters.status === status,
  );
  const band = filters.privilege_level_min || filters.privilege_level_max ? `${filters.privilege_level_min || 0}-${filters.privilege_level_max || 10}` : '';

  /* Ordered by how often a reviewer narrows by them: what the credential is,
     whether it is live, then the risk questions, then where it lives. */
  return [
    single('credential_type', 'Type', typeValues.map((value) => ({ value, label: credentialTypeLabel(value), count: byType[value] })), {
      emptyText: counts ? 'No credentials yet.' : 'Loading…',
    }),
    single('status', 'Status', credentialStatuses.map((value) => ({ value, label: statusMeta(value).label, count: statusCounts[value] }))),
    {
      key: 'privilege',
      label: 'Privilege (IAM roles)',
      single: true,
      options: PRIVILEGE_BANDS.map((option) => ({ ...option, active: band === option.value })),
      onToggle: (value) => {
        if (!value) update({ privilege_level_min: '', privilege_level_max: '' });
        else {
          const [min, max] = value.split('-');
          update({ privilege_level_min: min, privilege_level_max: max === '10' ? '' : max });
        }
      },
    },
    single('expiring_within_days', 'Expires within', [7, 30, 90].map((d) => ({ value: String(d), label: `${d} days` }))),
    single('stale_days', 'Unused for', [30, 90, 180, 365].map((d) => ({ value: String(d), label: `${d}+ days` }))),
    single('rotation_enabled', 'Rotation', [
      { value: 'true', label: 'Enabled' },
      { value: 'false', label: 'Disabled' },
    ], { defaultOpen: false }),
    single('account_id', 'AWS account', options.accounts.map((value) => ({ value, label: value })), { defaultOpen: false }),
    single('region', 'Region', options.regions.map((value) => ({ value, label: regionLabel(value) })), { defaultOpen: false }),
    {
      key: 'owner_principal_arn',
      label: 'Owner principal',
      defaultOpen: Boolean(filters.owner_principal_arn),
      activeCount: filters.owner_principal_arn ? 1 : 0,
      content: (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            const value = ownerDraft.trim();
            update({ owner_principal_arn: value.startsWith('arn:') ? value : '' });
          }}
          className="flex flex-col gap-1.5"
        >
          <Input
            size="sm"
            value={ownerDraft}
            onChange={(event) => setOwnerDraft(event.target.value)}
            placeholder="arn:aws:iam::123456789012:role/…"
            aria-label="Owner principal ARN"
            spellCheck={false}
          />
          <span className="text-[11px] text-ink-3">Exact ARN. Press Enter to apply.</span>
        </form>
      ),
    },
  ];
}
