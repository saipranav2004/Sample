import { useState } from 'react';
import { CheckCircle2, CircleSlash, MinusCircle } from 'lucide-react';
import { formatDate, formatDateTime, formatRelativeShort, parseDate } from '../../lib/format';
import { privilegeMeta } from '../../lib/labels';
import { TONE_VAR, cn } from '../../ui/cn';
import { MiniMeter } from '../../ui/TypeBadge';

/**
 * Privilege level 0-10 as ten small segments. Only IAM roles carry a level;
 * the list endpoint reports 0 for everything else, which is not a score, so
 * other types show a dash.
 */
export function PrivilegeCell({ level, credentialType }) {
  if (credentialType !== 'iam_role' || level === null || level === undefined) {
    return <span className="text-ink-3">-</span>;
  }
  const meta = privilegeMeta(level);
  return (
    <span className="inline-flex items-center gap-2" title={`Privilege ${level} of 10 · ${meta.label}`}>
      <span aria-hidden="true" className="flex gap-[2px]">
        {Array.from({ length: 10 }).map((_, index) => (
          <span
            key={index}
            className="h-3 w-[3px] rounded-[1px]"
            style={{ background: index < level ? TONE_VAR[meta.tone] : 'var(--t-track)' }}
          />
        ))}
      </span>
      <span data-numeric="" className="text-[12px] font-semibold text-ink">
        {level}
      </span>
      <span className="sr-only">of 10, {meta.label}</span>
    </span>
  );
}

/**
 * Expiry as distance, coloured by urgency (past and under 7 days red, under
 * 30 amber), with a countdown meter once it is within 90 days: the bar fills
 * as the date approaches, so the column reads at a glance.
 */
export function ExpiryCell({ value }) {
  const [now] = useState(() => Date.now());
  const date = parseDate(value);
  if (!date) return <span className="text-ink-3">No expiry</span>;
  const days = Math.floor((date.getTime() - now) / 86400000);
  const tone = days < 7 ? 'critical' : days < 30 ? 'high' : 'neutral';
  const text = cn('block truncate', tone === 'critical' ? 'text-critical' : tone === 'high' ? 'text-high' : 'text-ink-2');
  return (
    <span className="block min-w-0" title={formatDateTime(value)}>
      <span className={text}>
        {days < 0 ? `Expired ${formatRelativeShort(value).replace(/ ago$/, '')}` : days === 0 ? 'Today' : `In ${days} day${days === 1 ? '' : 's'}`}
      </span>
      {days <= 90 && (
        <MiniMeter
          value={days < 0 ? 100 : 100 - (days / 90) * 100}
          tone={TONE_VAR[tone]}
          width={72}
          label={days < 0 ? 'Expired' : `${days} days left`}
        />
      )}
    </span>
  );
}

export function RotationCell({ value }) {
  if (value === true) {
    return (
      <span className="inline-flex items-center gap-1.5 text-low">
        <CheckCircle2 aria-hidden="true" className="size-3.5" /> On
      </span>
    );
  }
  if (value === false) {
    return (
      <span className="inline-flex items-center gap-1.5 text-high">
        <CircleSlash aria-hidden="true" className="size-3.5" /> Off
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-ink-3" title="Rotation does not apply to this credential type, or AWS did not report it">
      <MinusCircle aria-hidden="true" className="size-3.5" /> n/a
    </span>
  );
}

export function LastUsedCell({ value }) {
  if (!value) return <span className="block truncate text-ink-3">Never</span>;
  return (
    <span className="block truncate" title={formatDateTime(value)}>
      {formatRelativeShort(value)}
    </span>
  );
}

export function DateCell({ value, empty = '-' }) {
  if (!value) return <span className="text-ink-3">{empty}</span>;
  return <span title={formatDateTime(value)}>{formatDate(value)}</span>;
}

/** Tag object -> [key, value] pairs with string values. */
export function tagPairs(tags) {
  if (!tags || typeof tags !== 'object' || Array.isArray(tags)) return [];
  return Object.entries(tags).map(([key, value]) => [key, typeof value === 'string' ? value : JSON.stringify(value)]);
}

export function TagChips({ tags, empty = 'No tags' }) {
  const pairs = tagPairs(tags);
  if (pairs.length === 0) return <span className="text-ink-3">{empty}</span>;
  return (
    <span className="flex flex-wrap gap-1.5">
      {pairs.map(([key, value]) => (
        <span key={key} className="inline-flex max-w-full items-center rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px]">
          <span className="text-ink-3">{key}</span>
          {value !== '' && <span className="truncate text-ink">={value}</span>}
        </span>
      ))}
    </span>
  );
}

/** How long the credential has existed, with a bar that fills over two years. */
export function AgeCell({ value }) {
  const created = parseDate(value);
  if (!created) return <span className="text-[12px] text-ink-3">Unknown</span>;
  const days = Math.max(0, Math.floor((Date.now() - created.getTime()) / 86_400_000));
  const tone = days >= 365 ? 'high' : days >= 180 ? 'medium' : 'brand';
  return (
    <span className="block" title={`Created ${created.toLocaleDateString()}`}>
      <span data-numeric="" className="block text-[12.5px] text-ink-2">
        {days.toLocaleString()} days
      </span>
      <MiniMeter value={Math.min(100, (days / 730) * 100)} tone={tone} width={56} label={`${days} days old`} />
    </span>
  );
}
