import { Link } from 'react-router-dom';
import { ArrowRight, Crown, KeyRound, Link2, ShieldAlert, Sparkles, Star } from 'lucide-react';
import { formatNumber, formatRelative, humanizeToken } from '../../lib/format';
import { identityBadge, identityTypeLabel } from '../../lib/labels';
import { BarChart } from '../../charts/BarChart';
import { Meter } from '../../ui/Meter';
import { ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, InlineError } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import { TypeBadge } from '../../ui/TypeBadge';
import { TONE_FG, cn } from '../../ui/cn';

/*
 * What a credential reaches, from the relationship endpoints (all scoped to
 * the latest completed scan):
 *   /impact/credentials/{id}                    blast radius summary
 *   /inventory/credentials/{id}/bound-identities who holds it
 *   /inventory/credentials/{id}/effective-permissions and /usage
 *   /inventory/credentials/{id}/trust-chain     roles only
 * Shared by the preview drawer and the full record.
 */

const SEVERITY_TONE = { critical: 'critical', high: 'high', medium: 'medium', low: 'low', none: 'low' };
const toneOf = (value) => SEVERITY_TONE[String(value || '').toLowerCase()] ?? 'neutral';
const label = (value) => (value ? String(value).charAt(0).toUpperCase() + String(value).slice(1).toLowerCase() : 'Unknown');

/** One line of six figures: how far misuse of this credential would reach. */
export function BlastRadius({ query, compact = false }) {
  if (query.isError && !query.data) return <InlineError error={query.error} onRetry={query.refetch} label="Blast radius unavailable" />;
  if (!query.data) return <Skeleton className="h-[86px] w-full rounded-[var(--radius-control)]" />;
  const { impact, overall_severity: severity } = query.data;
  const services = impact.services_accessible ?? [];
  const cells = [
    { key: 'identities', label: 'Identities holding it', value: formatNumber(impact.identities_affected) },
    { key: 'permissions', label: 'Actions granted', value: formatNumber(impact.permissions_granted) },
    {
      key: 'services',
      label: 'Services reachable',
      value: services.includes('*') ? 'Every service' : formatNumber(services.length),
      tone: services.includes('*') ? 'critical' : undefined,
    },
    {
      key: 'escalation',
      label: 'Privilege escalation',
      value: impact.privilege_escalation_possible ? 'Possible' : 'Not found',
      tone: impact.privilege_escalation_possible ? 'critical' : 'low',
    },
    { key: 'paths', label: 'Onward paths', value: formatNumber(impact.attack_paths_count), tone: impact.attack_paths_count > 0 ? 'high' : undefined },
    {
      key: 'scope',
      label: 'Data reach',
      value: humanizeToken(impact.data_access_scope),
      tone: /cross/i.test(impact.data_access_scope) ? 'high' : undefined,
    },
  ];
  return (
    <div className="overflow-hidden rounded-[var(--radius-control)] border border-line">
      <div className="flex items-center justify-between gap-3 border-b border-line bg-surface-2/70 px-3.5 py-2">
        <span className="flex items-center gap-2 text-[12.5px] font-semibold text-ink">
          <ShieldAlert aria-hidden="true" className={cn('size-4', TONE_FG[toneOf(severity)])} />
          Blast radius
        </span>
        <Tag size="sm" dot tone={toneOf(severity)}>
          {label(severity)}
        </Tag>
      </div>
      <dl className={cn('grid', compact ? 'grid-cols-2 @min-[30rem]:grid-cols-3' : 'grid-cols-2 @min-[34rem]:grid-cols-3 @min-[56rem]:grid-cols-6')}>
        {cells.map((cell) => (
          <div key={cell.key} className="min-w-0 border-t border-l border-line px-3.5 py-2.5 first:border-l-0 [&:nth-child(-n+2)]:border-t-0 @min-[34rem]:[&:nth-child(-n+3)]:border-t-0">
            <dt className="truncate text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{cell.label}</dt>
            <dd className={cn('mt-0.5 truncate text-[15px] font-bold', cell.tone ? TONE_FG[cell.tone] : 'text-ink')} data-numeric="">
              {cell.value}
            </dd>
          </div>
        ))}
      </dl>
      {services.length > 0 && !services.includes('*') && !compact && (
        <p className="border-t border-line px-3.5 py-2 text-[11.5px] text-ink-3">
          Services: <span className="font-mono text-ink-2">{services.join(', ')}</span>
        </p>
      )}
    </div>
  );
}

/** The identities that hold the credential in the latest scan. */
export function HeldBy({ query, limit }) {
  if (query.isError && !query.data) return <InlineError error={query.error} onRetry={query.refetch} label="Holders unavailable" />;
  if (!query.data) return <ListSkeleton rows={3} />;
  const { identities, total_identities: total, blast_radius_severity: severity } = query.data;
  if (identities.length === 0) {
    return (
      <EmptyState
        compact
        icon={Link2}
        title="No identity holds it"
        description="Nothing in the latest scan uses this credential. An orphaned credential is a candidate to remove once the owner confirms."
      />
    );
  }
  const shown = limit ? identities.slice(0, limit) : identities;
  return (
    <div>
      <p className="mb-2 flex items-center gap-2 text-[12px] text-ink-3">
        <span data-numeric="" className="font-semibold text-ink">
          {formatNumber(total)}
        </span>{' '}
        identit{total === 1 ? 'y holds' : 'ies hold'} it
        <Tag size="sm" tone={toneOf(severity)}>
          {label(severity)} spread
        </Tag>
      </p>
      <ul className="divide-y divide-line rounded-[var(--radius-control)] border border-line">
        {shown.map((item) => (
          <li key={`${item.identity_id}-${item.binding_type}`}>
            <Link
              to={`/identities/${encodeURIComponent(item.identity_id)}`}
              className="flex items-center gap-3 px-3 py-2.5 transition-colors hover:bg-surface-2"
            >
              <TypeBadge code={identityBadge(item.identity_type)} color="var(--t-brand)" />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1.5">
                  <span className="truncate text-[13px] font-semibold text-ink">{item.identity_name || item.identity_id}</span>
                  {item.is_primary && <Star aria-label="Primary holder" className="size-3.5 shrink-0 fill-current text-medium" />}
                </span>
                <span className="block truncate text-[11.5px] text-ink-3">
                  {[identityTypeLabel(item.identity_type), humanizeToken(item.binding_type), item.account_id].filter(Boolean).join(' · ')}
                </span>
              </span>
              <span className="shrink-0 text-right text-[11.5px] text-ink-3">{item.last_seen_at ? `seen ${formatRelative(item.last_seen_at)}` : ''}</span>
              <ArrowRight aria-hidden="true" className="size-3.5 shrink-0 text-ink-3" />
            </Link>
          </li>
        ))}
      </ul>
      {limit && identities.length > limit && (
        <p className="mt-2 text-[12px] text-ink-3">and {formatNumber(identities.length - limit)} more on the full record.</p>
      )}
    </div>
  );
}

/**
 * What it may do, and how much of that it actually uses. The gap is the
 * overprivilege: actions granted but never called in the window.
 */
export function PermissionsSummary({ permissions, usage, compact = false }) {
  if (permissions.isError && !permissions.data) return <InlineError error={permissions.error} onRetry={permissions.refetch} label="Permissions unavailable" />;
  if (!permissions.data) return <ListSkeleton rows={4} />;
  const data = permissions.data;
  if (data.total_permissions === 0) {
    return <EmptyState compact icon={KeyRound} title="No permissions recorded" description="The latest scan recorded no effective permissions for this credential." />;
  }
  const used = usage.data;
  const services = [...data.by_service].sort((a, b) => b.action_count - a.action_count);
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-2">
        {data.has_admin_access && (
          <Tag tone="critical" icon={Crown}>
            Administrator access
          </Tag>
        )}
        <Tag tone="neutral">{formatNumber(data.allow_count)} allowed</Tag>
        {data.deny_count > 0 && <Tag tone="low">{formatNumber(data.deny_count)} denied</Tag>}
        {data.wildcard_actions.length > 0 && <Tag tone="high">{formatNumber(data.wildcard_actions.length)} wildcard</Tag>}
      </div>

      {used && (
        <div className="rounded-[var(--radius-control)] border border-line bg-surface-2/60 p-3.5">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink">
              <Sparkles aria-hidden="true" className="size-3.5 text-ink-3" />
              Used {formatNumber(used.used_actions)} of {formatNumber(used.granted_actions)} granted actions
            </p>
            <Tag size="sm" tone={toneOf(used.overprivilege_severity)}>
              {used.overprivilege_severity === 'none' ? 'Right-sized' : `${label(used.overprivilege_severity)} overprivilege`}
            </Tag>
          </div>
          <Meter
            className="mt-2.5"
            value={100 - (Number(used.unused_percentage) || 0)}
            tone={toneOf(used.overprivilege_severity) === 'low' ? 'low' : 'brand'}
            label="Share of granted actions used"
          />
          <p className="mt-1.5 text-[11.5px] text-ink-3">
            {Math.round(Number(used.unused_percentage) || 0)}% never called in the last 90 days. {used.recommendation}
          </p>
          {!compact && used.unused_but_granted.length > 0 && (
            <div className="mt-3">
              <p className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Granted, never used</p>
              <ul className="mt-1.5 flex flex-wrap gap-1.5">
                {used.unused_but_granted.slice(0, 24).map((item) => (
                  <li key={`${item.action}-${item.granted_by}`} title={item.granted_by ? `Granted by ${item.granted_by}` : undefined} className="rounded-md border border-line bg-surface px-1.5 py-0.5 font-mono text-[11px] text-ink-2">
                    {item.action}
                  </li>
                ))}
                {used.unused_but_granted.length > 24 && <li className="px-1 text-[11.5px] text-ink-3">+{used.unused_but_granted.length - 24} more</li>}
              </ul>
            </div>
          )}
        </div>
      )}
      {usage.isError && !usage.data && <InlineError error={usage.error} onRetry={usage.refetch} label="Usage unavailable" />}

      <div>
        <p className="mb-1 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Actions by service</p>
        <BarChart
          items={services.slice(0, compact ? 6 : 8).map((row) => ({ key: row.service, label: serviceLabel(row.service, data.permissions), value: row.action_count }))}
          color="var(--t-ramp-4)"
          label="Granted actions by service"
        />
      </div>
    </div>
  );
}

/** The API groups a bare `*` action under "unknown"; say what it is. */
function serviceLabel(service, permissions) {
  if (service === '*' || (service === 'unknown' && permissions.some((row) => row.action === '*'))) return 'All services (action *)';
  return service;
}

const TRUST_GROUPS = [
  { key: 'can_be_assumed_by', title: 'Who can assume it', side: 'source_arn', empty: 'No principal can assume this role.' },
  { key: 'can_assume', title: 'Roles it can assume', side: 'target_arn', empty: 'It assumes no other role.' },
  { key: 'can_pass_role_to', title: 'Roles it can pass', side: 'target_arn', empty: 'It cannot pass any role.' },
];

/** The role's trust chain: inbound assumption, onward assumption, pass-role. */
export function TrustChain({ query }) {
  if (query.isError && !query.data) return <InlineError error={query.error} onRetry={query.refetch} label="Trust chain unavailable" />;
  if (!query.data) return <ListSkeleton rows={4} />;
  return (
    <div className="grid gap-3 @min-[40rem]:grid-cols-3">
      {TRUST_GROUPS.map((group) => {
        const edges = query.data[group.key] ?? [];
        return (
          <section key={group.key} className="min-w-0 rounded-[var(--radius-control)] border border-line px-3.5 py-3">
            <h4 className="flex items-center justify-between text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">
              {group.title}
              <span data-numeric="" className="font-semibold tracking-normal text-ink-2">
                {formatNumber(edges.length)}
              </span>
            </h4>
            {edges.length === 0 ? (
              <p className="mt-1.5 text-[12.5px] text-ink-3">{group.empty}</p>
            ) : (
              <ul className="mt-1.5 flex flex-col gap-2">
                {edges.map((edge, index) => {
                  const arn = edge[group.side];
                  const external = /cross_account/i.test(edge.edge_type) || /:root$/.test(arn ?? '');
                  return (
                    <li key={`${arn}-${edge.edge_type}-${index}`} className="min-w-0">
                      <p className="truncate font-mono text-[12px] text-ink" title={arn}>
                        {shortPrincipal(arn)}
                      </p>
                      <p className="flex flex-wrap items-center gap-1.5 text-[11px] text-ink-3">
                        {humanizeToken(edge.edge_type)}
                        {external && (
                          <Tag size="sm" tone="high">
                            External
                          </Tag>
                        )}
                        {edge.conditions && <span title={JSON.stringify(edge.conditions)}>· with conditions</span>}
                      </p>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        );
      })}
    </div>
  );
}

/** `arn:aws:iam::123:role/name` -> `role/name (123)`; service principals as they are. */
function shortPrincipal(arn) {
  const text = String(arn || '');
  const parts = text.split(':');
  if (parts.length >= 6 && parts[0] === 'arn') return `${parts.slice(5).join(':')}${parts[4] ? ` (${parts[4]})` : ''}`;
  return text;
}
