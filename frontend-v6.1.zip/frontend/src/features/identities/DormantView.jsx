import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Moon, SearchX } from 'lucide-react';
import { fetchDormantIdentities, fetchIdentitiesByAccount, fetchIdentityCounts } from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelativeShort } from '../../lib/format';
import { identityTypeLabel } from '../../lib/labels';
import { Reveal } from '../../lib/motion';
import { RecordPreview } from '../preview/RecordPreview';
import { CellStack, DataGrid } from '../../ui/DataGrid';
import { FilterSelect } from '../../ui/FilterBar';
import { Pagination } from '../../ui/Pagination';
import { Panel } from '../../ui/Panel';
import { EmptyState, ErrorState } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { RefreshButton, TableToolbar } from '../../ui/TableTools';
import { RecordBar } from '../../ui/WorkArea';

const THRESHOLDS = [30, 60, 90, 180, 365];
const PAGE_SIZES = [25, 50, 100];
const ACCOUNT = /^[0-9]{12}$/;
const TOKEN = /^[a-zA-Z0-9_-]{1,100}$/;

/**
 * Identities with no recorded activity for at least N days:
 * `GET /api/v1/inventory/identities/dormant`. An identity AWS records no
 * activity for at all is not dormant by this definition - it is untracked,
 * and the dashboard counts those separately.
 */
export function DormantView() {
  const [searchParams, setSearchParams] = useSearchParams();

  const days = THRESHOLDS.includes(Number(searchParams.get('days'))) ? Number(searchParams.get('days')) : 90;
  const page = Math.max(1, Math.min(1_000_000, Number.parseInt(searchParams.get('page') ?? '1', 10) || 1));
  const limit = PAGE_SIZES.includes(Number(searchParams.get('limit'))) ? Number(searchParams.get('limit')) : 25;
  const accountId = ACCOUNT.test(searchParams.get('account_id') ?? '') ? searchParams.get('account_id') : '';
  const identityType = TOKEN.test(searchParams.get('identity_type') ?? '') ? searchParams.get('identity_type') : '';

  const update = (changes, keepPage = false) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(changes)) {
      if (value === '' || value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    if (!keepPage) next.delete('page');
    setSearchParams(next);
  };

  const query = useQuery(
    (signal) =>
      fetchDormantIdentities({ days, page, limit, account_id: accountId, identity_type: identityType }, signal),
    [days, page, limit, accountId, identityType],
  );
  const accounts = useQuery((signal) => fetchIdentitiesByAccount({}, signal), []);
  const counts = useQuery((signal) => fetchIdentityCounts({}, signal), []);

  const accountOptions = useMemo(
    () => [
      { value: '', label: 'All accounts' },
      ...(accounts.data?.breakdown ?? []).map((row) => ({ value: row.account_id, label: row.account_id })),
    ],
    [accounts.data],
  );
  const typeOptions = useMemo(
    () => [
      { value: '', label: 'All types' },
      ...Object.keys(counts.data?.by_type ?? {})
        .sort()
        .map((value) => ({ value, label: identityTypeLabel(value) })),
    ],
    [counts.data],
  );

  const rows = query.data?.data ?? [];
  const [peek, setPeek] = useState(null);
  const [peekData, setPeekData] = useState(query.data);
  if (peekData !== query.data) {
    setPeekData(query.data);
    if (peek !== null) setPeek(null);
  }
  const total = query.data?.total_dormant ?? 0;
  const filtered = Boolean(accountId || identityType);

  const columns = [
    {
      key: 'name',
      header: 'Identity',
      primary: true,
      cell: (row) => <CellStack title={row.name || row.id} meta={identityTypeLabel(row.identity_type)} />,
    },
    {
      key: 'days_inactive',
      header: 'Inactive for',
      width: '14%',
      /* The API lists identities with no recorded activity at all with
         days_inactive 0; "0 days" would read as "used today". */
      cell: (row) =>
        row.last_activity_at ? (
          <span data-numeric="" className="font-semibold text-ink">
            {formatNumber(row.days_inactive)} days
          </span>
        ) : (
          <span className="font-semibold text-ink" title="AWS has no record of this identity ever being used">
            Never active
          </span>
        ),
    },
    {
      key: 'last_activity_at',
      header: 'Last active',
      width: '16%',
      cell: (row) =>
        row.last_activity_at ? (
          <span title={formatDateTime(row.last_activity_at)}>{formatRelativeShort(row.last_activity_at)}</span>
        ) : (
          <span className="text-ink-3">No activity recorded</span>
        ),
    },
    {
      key: 'owner',
      header: 'Owner',
      width: '16%',
      cell: (row) => (row.owner ? <span className="block truncate">{row.owner}</span> : <span className="block truncate text-ink-3">None</span>),
    },
    {
      key: 'environment',
      header: 'Environment',
      width: '14%',
      priority: 'wide',
      cell: (row) =>
        row.environment ? <span className="block truncate">{row.environment}</span> : <span className="block truncate text-ink-3">None</span>,
    },
  ];

  return (
    <>
      <Reveal>
      <Panel flush className="overflow-hidden">
        <RecordBar
          trailing={
            <TableToolbar>
              <RefreshButton onRefresh={query.refetch} refreshing={query.isRefreshing} />
            </TableToolbar>
          }
        >
          <SegmentedControl
            label="Inactive for at least"
            value={String(days)}
            onChange={(value) => update({ days: value })}
            options={THRESHOLDS.map((value) => ({ value: String(value), label: `${value}d`, title: `${value} days` }))}
          />
          <FilterSelect label="Account" value={accountId} options={accountOptions.filter((option) => option.value)} onChange={(value) => update({ account_id: value })} />
          <FilterSelect label="Type" value={identityType} options={typeOptions.filter((option) => option.value)} onChange={(value) => update({ identity_type: value })} />
        </RecordBar>
        <p className="border-b border-line bg-surface px-4 py-2 text-[12.5px] text-ink-3">
          Still exist but not used for {days} days or more, plus any with no activity recorded at all (shown as Never active). Confirm with the owner, then remove what is no longer needed.
        </p>

        {query.isError && !query.data ? (
          <ErrorState error={query.error} onRetry={query.refetch} />
        ) : (
          <>
            <DataGrid
              caption={`Identities inactive for ${days} days or more`}
              columns={columns}
              rows={rows}
              rowKey={(row) => row.id}
              loading={query.isLoading && !query.data}
              refreshing={query.isRefreshing || (query.isLoading && Boolean(query.data))}
              onRowClick={(row, event) => {
                  if (event?.metaKey || event?.ctrlKey) window.open(`/identities/${encodeURIComponent(row.id)}`, '_blank', 'noopener');
                  else setPeek(rows.indexOf(row));
                }}
                selectedKey={peek !== null ? rows[peek]?.id : undefined}
                rowLabel={(row) => `Preview ${row.name || row.id}`}
              skeletonRows={8}
              emptyState={
                filtered ? (
                  <EmptyState
                    icon={SearchX}
                    title="Nothing dormant matches these filters"
                    description="Choose another account or type, or a shorter period."
                  />
                ) : (
                  <EmptyState
                    icon={Moon}
                    title={`Nothing inactive for ${days} days or more`}
                    description="Every identity with tracked activity has been used within this period."
                  />
                )
              }
            />
            {total > 0 && (
              <Pagination
                page={page}
                pageSize={limit}
                total={total}
                pageSizes={PAGE_SIZES}
                unit="identities"
                onPageChange={(next) => update({ page: next > 1 ? next : '' }, true)}
                onPageSizeChange={(size) => update({ limit: size })}
              />
            )}
          </>
        )}
      </Panel>
      </Reveal>
      <RecordPreview kind="identity" rows={rows} index={peek} onIndexChange={setPeek} onClose={() => setPeek(null)} />
    </>
  );
}
