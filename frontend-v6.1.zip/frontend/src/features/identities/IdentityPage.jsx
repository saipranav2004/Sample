import { useState } from 'react';
import { identityFindings } from '../../lib/verdict';
import { Verdict } from '../../ui/Verdict';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Braces, Clock, Fingerprint, Globe2, KeyRound, ListTree, Pencil, ShieldAlert } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { fetchCredentials, fetchIdentity, fetchIdentityAttributes, fetchIdentityTimeline } from '../../lib/api/endpoints';
import { credentialSignals } from '../../lib/signals';
import { DataGrid } from '../../ui/DataGrid';
import { Freshness } from '../../ui/Freshness';
import { RiskCell } from '../../ui/RiskCell';
import { ExpiryCell } from '../credentials/parts';
import { useQuery } from '../../lib/hooks';
import { Page, Reveal } from '../../lib/motion';
import { formatDate, formatDateTime, formatNumber, formatRelative, parseDate } from '../../lib/format';
import { classColor, credentialBadge, credentialTypeLabel, functionalClassLabel, identityBadge, identityTypeLabel, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { DetailList, DetailRow, Panel, PanelHeader } from '../../ui/Panel';
import { DetailSkeleton, ListSkeleton, Skeleton } from '../../ui/Skeleton';
import { EmptyState, ErrorState } from '../../ui/States';
import { Tabs } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { AccessChain } from '../../ui/AccessChain';
import { FactsCard } from '../../ui/FactsCard';
import { StatusChecks, checkSummary } from '../../ui/StatusChecks';
import { TypeBadge } from '../../ui/TypeBadge';
import { RelatedLinks } from '../../ui/RelatedLinks';
import { identityChecks } from './checks';
import { Lifecycle, scannerSegments, spanText, unseenStat } from '../../ui/Lifecycle';
import { EditIdentityDialog } from './EditIdentityDialog';
import { AttributeList, JsonBlock, tagEntries } from './JsonView';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const TABS = [
  { value: 'overview', label: 'Overview', icon: Fingerprint },
  { value: 'credentials', label: 'Credentials', icon: KeyRound },
  { value: 'attributes', label: 'Attributes', icon: ListTree },
  { value: 'timeline', label: 'Timeline', icon: Clock },
  { value: 'raw', label: 'Raw record', icon: Braces },
];

/**
 * One identity: `GET /api/v1/inventory/identities/{id}`, with its
 * type-specific attributes and timeline from their own endpoints. The tab is
 * in the URL so a link can land on the part that matters.
 */
export default function IdentityPage() {
  const { id } = useParams();
  const validId = UUID.test(id ?? '');
  const [searchParams, setSearchParams] = useSearchParams();
  const { can, lock } = useAccess();
  const [editing, setEditing] = useState(false);

  const detail = useQuery((signal) => fetchIdentity(id, signal), [id], { enabled: validId });
  /* The raw tab is offered only when the scanner kept something to show:
     a stored null, an empty object or an empty string is not a record, and
     a tab that always opens empty teaches people to ignore it. */
  const raw = storedRaw(detail.data?.raw_api_response);
  const tabs = raw === null ? TABS.filter((entry) => entry.value !== 'raw') : TABS;
  const requested = searchParams.get('tab') || 'overview';
  const tab = tabs.some((entry) => entry.value === requested) ? requested : 'overview';
  const attributes = useQuery((signal) => fetchIdentityAttributes(id, signal), [id], {
    enabled: validId && tab === 'attributes',
  });
  const timeline = useQuery((signal) => fetchIdentityTimeline(id, signal), [id], {
    enabled: validId && tab === 'timeline',
  });
  /* Credentials recorded with this identity as their owner principal - the
     one identity-to-credential link the list API can filter on. Loaded with
     the record so the tab shows its count. */
  const arn = detail.data?.arn;
  const owned = useQuery((signal) => fetchCredentials({ owner_principal_arn: arn, limit: 100, sort_by: 'privilege_level', sort_order: 'desc' }, signal), [arn], {
    enabled: Boolean(arn),
  });
  const tabsWithCounts = tabs.map((entry) => (entry.value === 'credentials' ? { ...entry, count: owned.data ? owned.data.total : undefined } : entry));

  const setTab = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'overview') next.delete('tab');
    else next.set('tab', value);
    setSearchParams(next, { replace: true });
  };

  const back = (
    <Button variant="secondary" as={Link} to="/identities" icon={ArrowLeft}>
      Identities
    </Button>
  );

  const identity = detail.data;

  if (!validId || (detail.isError && !identity)) {
    const missing = !validId || detail.error?.status === 404 || detail.error?.status === 400;
    return (
      <div className="flex flex-col gap-6">
        <PageHeader title="Identity" actions={back} />
        <Panel>
          {missing ? (
            <EmptyState
              icon={Fingerprint}
              title="No identity with that id"
              description="It may have been removed by a later discovery run, or the link is incomplete. Find it again from Identities."
              action={back}
            />
          ) : (
            <ErrorState error={detail.error} onRetry={detail.refetch} />
          )}
        </Panel>
      </div>
    );
  }

  if (!identity) {
    return (
      <div className="flex flex-col gap-6" aria-busy="true">
        <PageHeader title={<Skeleton className="h-7 w-64 rounded" />} actions={back} />
        <Panel prominence="lead">
          <DetailSkeleton rows={8} />
        </Panel>
        <span role="status" className="sr-only">
          Loading identity
        </span>
      </div>
    );
  }

  const status = statusMeta(identity.status);
  const tags = tagEntries(identity.ownership?.tags);

  return (
    <Page className="flex flex-col gap-6">
      <Reveal>
      <PageHeader
        title={
          <span className="flex min-w-0 items-center gap-3">
            <TypeBadge size="lg" code={identityBadge(identity.identity_type)} color={classColor(identity.functional_class)} title={identityTypeLabel(identity.identity_type)} />
            <span className="block min-w-0 truncate font-mono">{identity.name || identity.arn}</span>
          </span>
        }
        lede={identitySummary(identity)}
        actions={
          <>
            <Button variant="secondary" as={Link} to="/identities" icon={ArrowLeft}>
              Identities
            </Button>
            {identity.network?.is_publicly_accessible === true && (
              <Button variant="secondary" as={Link} to="/identities?is_public=true" icon={Globe2}>
                Internet-exposed
              </Button>
            )}
            <Button
              variant="primary"
              icon={Pencil}
              onClick={() => setEditing(true)}
              locked={lock('identity.edit')}
              disabled={Boolean(identity.deleted_at)}
              title={identity.deleted_at ? 'A deleted identity cannot be edited' : undefined}
            >
              Edit ownership
            </Button>
          </>
        }
        meta={
          <div className="flex flex-wrap items-center gap-2">
            <Tag tone={status.tone} dot>
              {status.label}
            </Tag>
            {identity.deleted_at && <Tag tone="neutral">Deleted {formatRelative(identity.deleted_at)}</Tag>}
            <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
              <CopyableValue value={identity.arn} />
            </span>
          </div>
        }
        tabs={<Tabs size="sm" tabs={tabsWithCounts} value={tab} onChange={setTab} />}
      />
      </Reveal>
      <Reveal key={tab}>

      {tab === 'overview' && <OverviewTab identity={identity} tags={tags} owned={owned} onOpenCredentials={() => setTab('credentials')} />}

      {tab === 'credentials' && <OwnedCredentials query={owned} arn={identity.arn} />}

      {tab === 'attributes' && (
        <Panel>
          <PanelHeader
            title={`${identityTypeLabel(identity.identity_type)} attributes`}
            subtitle="Fields AWS reports for this kind of resource, as the scanner recorded them."
          />
          <div className="mt-3">
            {attributes.isError ? (
              <ErrorState compact error={attributes.error} onRetry={attributes.refetch} />
            ) : !attributes.data ? (
              <DetailSkeleton rows={6} />
            ) : (
              <AttributeList
                value={attributes.data.type_attributes}
                emptyTitle="No type-specific attributes"
                emptyText="The scanner recorded no extra attributes for this identity."
              />
            )}
          </div>
        </Panel>
      )}

      {tab === 'timeline' && <TimelineTab query={timeline} />}

      {tab === 'raw' && raw !== null && (
        <Panel>
          <PanelHeader
            title="Raw AWS response"
            subtitle="Exactly what the AWS API returned when the scanner discovered this identity."
          />
          <div className="mt-3">
            <JsonBlock value={raw} copyLabel="Copy JSON" />
          </div>
        </Panel>
      )}

      </Reveal>

      <EditIdentityDialog
        open={editing && can('identity.edit')}
        identity={identity}
        onClose={() => setEditing(false)}
        onSaved={() => {
          setEditing(false);
          detail.refetch();
        }}
      />
    </Page>
  );
}

function Missing({ children = 'Not recorded' }) {
  return <span className="text-ink-3">{children}</span>;
}

const DAY = 86_400_000;

/** One plain sentence: what it is, who owns it, how exposed and how used. */
function identitySummary(identity) {
  const owner = identity.ownership?.owner;
  const env = identity.ownership?.environment;
  const pub = identity.network?.is_publicly_accessible;
  const head = `${identityTypeLabel(identity.identity_type)} (${functionalClassLabel(identity.functional_class)}) in account ${identity.account_id}, ${regionLabel(identity.region)}`;
  /* Names stay on one line: a hyphen in them is not a place to wrap. */
  const who = owner ? (
    <>
      owned by <span className="whitespace-nowrap">{owner}</span>
      {env && <> in <span className="whitespace-nowrap">{env}</span></>}
    </>
  ) : (
    'with no owner recorded'
  );
  const facts = [
    pub === true ? 'reachable from the internet' : pub === false ? 'not publicly reachable' : null,
    identity.last_activity_at ? `last active ${formatRelative(identity.last_activity_at)}` : 'no activity recorded by AWS',
  ].filter(Boolean);
  return (
    <>
      {head}, {who}. {facts.join(', ').replace(/^./, (c) => c.toUpperCase())}.
    </>
  );
}

/** The last segment of an ARN, and the AWS service it belongs to. */
function arnParts(arn) {
  const text = String(arn ?? '');
  const parts = text.split(':');
  const resource = parts.slice(5).join(':');
  const segments = resource.split('/').filter(Boolean);
  /* CloudFormation stacks are stack/<name>/<id>; the id says nothing to a reader. */
  const name = parts[2] === 'cloudformation' && segments[0] === 'stack' && segments[1] ? segments[1] : segments.pop();
  return { service: parts[2] ?? '', account: parts[4] ?? '', name: name || resource || text };
}

const SERVICE_NAMES = { cloudformation: 'CloudFormation stack', iam: 'IAM', ecs: 'ECS', eks: 'EKS', lambda: 'Lambda', ec2: 'EC2', sagemaker: 'SageMaker', bedrock: 'Bedrock', apprunner: 'App Runner' };

/**
 * The stored AWS response, or null when there is nothing in it. Some
 * scanners store the response as a JSON string, so a string that parses is
 * shown as the object it holds.
 */
function storedRaw(value) {
  let parsed = value;
  if (typeof value === 'string') {
    const text = value.trim();
    if (!text || text === 'null') return null;
    try {
      parsed = JSON.parse(text);
    } catch {
      return text;
    }
  }
  if (parsed === null || parsed === undefined) return null;
  if (Array.isArray(parsed)) return parsed.length ? parsed : null;
  if (typeof parsed === 'object') return Object.keys(parsed).length ? parsed : null;
  return parsed;
}

/** The identity's life as lanes: what the scanner could see, and its activity. */
function identityLifecycle(identity, now) {
  const created = parseDate(identity.created_at_aws);
  const found = parseDate(identity.first_seen_at);
  const confirmed = parseDate(identity.last_seen_at);
  const active = parseDate(identity.last_activity_at);
  const deleted = parseDate(identity.deleted_at);
  const start = created ?? found;
  const idleDays = active ? Math.floor((now - active.getTime()) / DAY) : null;
  const activity = [];
  if (active) {
    if (start && active > start) activity.push({ key: 'active', from: start.toISOString(), to: active.toISOString(), label: 'Until last activity', tone: 'low' });
    activity.push({ key: 'idle', from: active.toISOString(), to: deleted ? deleted.toISOString() : 'now', label: 'Inactive', tone: idleDays >= 90 ? 'high' : idleDays >= 30 ? 'medium' : 'neutral' });
  } else if (start) {
    activity.push({ key: 'none', from: start.toISOString(), to: deleted ? deleted.toISOString() : 'now', label: 'No activity recorded', tone: 'neutral', hatch: true });
  }
  if (deleted) activity.push({ key: 'deleted', from: deleted.toISOString(), to: 'now', label: 'Deleted', tone: 'critical' });
  return {
    stats: [
      { key: 'age', label: 'Age', value: start ? spanText(now - start.getTime()) : 'Unknown', sub: created ? `Created ${formatDate(created)}` : 'Creation date not recorded' },
      unseenStat(created, found),
      active
        ? { key: 'idle', label: 'Inactive for', value: spanText(now - active.getTime()), sub: `Last active ${formatDate(active)}`, tone: idleDays >= 90 ? 'high' : idleDays >= 30 ? 'medium' : undefined }
        : { key: 'idle', label: 'Inactive for', value: 'Unknown', sub: 'AWS records no activity' },
      {
        key: 'confirmed',
        label: 'Last confirmed',
        value: confirmed ? formatRelative(confirmed) : 'Never',
        sub: confirmed ? `Seen by scan ${formatDate(confirmed)}` : 'Not seen by a scan',
        tone: confirmed && now - confirmed.getTime() > 7 * DAY ? 'medium' : undefined,
      },
    ],
    lanes: [
      { key: 'scanner', label: 'Scanner view', segments: scannerSegments(created, found, confirmed, now) },
      { key: 'activity', label: 'Activity', segments: activity },
    ],
    events: [
      { key: 'created', label: 'Created in AWS', at: identity.created_at_aws },
      { key: 'discovered', label: 'First discovered', at: identity.first_seen_at, tone: 'neutral' },
      { key: 'active', label: 'Last active', at: identity.last_activity_at, tone: 'low' },
      { key: 'confirmed', label: 'Last confirmed', at: identity.last_seen_at, tone: 'info' },
      ...(identity.deleted_at ? [{ key: 'deleted', label: 'Deleted', at: identity.deleted_at, tone: 'critical' }] : []),
    ],
  };
}

function OverviewTab({ identity, tags, owned, onOpenCredentials }) {
  const network = identity.network ?? {};
  const ownership = identity.ownership ?? {};
  const lineage = identity.lineage ?? {};
  const discovery = identity.discovery ?? {};
  const groups = Array.isArray(network.security_group_ids) ? network.security_group_ids.map(String) : [];
  const [now] = useState(() => Date.now());
  const lastActive = parseDate(identity.last_activity_at);
  const creator = lineage.cloudtrail_creator_arn ? arnParts(lineage.cloudtrail_creator_arn) : null;
  const parent = lineage.parent_arn ? arnParts(lineage.parent_arn) : null;
  const isPublic = network.is_publicly_accessible === true;
  const checks = identityChecks(identity, now);

  return (
    <div className="flex flex-col gap-4">
      {/* 0. The verdict: what is wrong, worst first, and what to do. */}
      <Verdict findings={identityFindings(identity, now)} max={4} cleanText={`${checkSummary(checks)}. Private, owned, labelled and in use.`} />
      {/* 1. The record at a glance (reference console). */}
      <FactsCard
        facts={[
          { label: 'What it is', value: identityTypeLabel(identity.identity_type), sub: `${functionalClassLabel(identity.functional_class)} class` },
          { label: 'Where', value: identity.account_id, mono: true, sub: [regionLabel(identity.region), ownership.environment].filter(Boolean).join(' · ') },
          { label: 'Owner', value: ownership.owner || 'No owner', tone: ownership.owner ? undefined : 'medium', sub: ownership.owner ? 'Owner tag' : 'No owner tag' },
          {
            label: 'Reachable from',
            value: isPublic ? 'The internet' : network.is_publicly_accessible === false ? 'Private network only' : null,
            tone: isPublic ? 'critical' : undefined,
            sub: [network.vpc_id || 'No VPC recorded', groups.length ? `${groups.length} security group${groups.length === 1 ? '' : 's'}` : 'no security groups'].join(' · '),
          },
          (() => {
            const rows = owned.data?.data ?? [];
            const flagged = rows.filter((row) => credentialSignals(row).some((signal) => ['critical', 'high'].includes(signal.tone))).length;
            return {
              label: 'Credentials it owns',
              value: owned.data ? (
                owned.data.total ? (
                  <button type="button" onClick={onOpenCredentials} className="text-left text-brand hover:underline">
                    {formatNumber(owned.data.total)} credential{owned.data.total === 1 ? '' : 's'}
                  </button>
                ) : (
                  'None'
                )
              ) : null,
              tone: flagged ? 'high' : undefined,
              sub: owned.data ? (owned.data.total ? (flagged ? `${formatNumber(flagged)} need attention` : 'None need attention') : 'No credential names it as owner') : 'Loading',
            };
          })(),
          { label: 'Last active', value: identity.last_activity_at ? formatRelative(identity.last_activity_at) : 'No activity recorded', sub: identity.last_activity_at ? formatDateTime(identity.last_activity_at) : undefined },
        ]}
      />

      {/* 2. Every check, with what is fine as well as what is not. */}
      <div className="grid gap-4 @min-[60rem]:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
        <Panel prominence="lead">
          <PanelHeader title="Status checks" subtitle={checkSummary(checks)} icon={ShieldAlert} />
          <StatusChecks className="mt-2" checks={checks} />
        </Panel>
        <Panel>
          <PanelHeader title="Tags" subtitle="Edit ownership changes these in the inventory, not in AWS." />
          <div className="mt-3">
            {tags.length === 0 ? (
              <Missing>No tags</Missing>
            ) : (
              <span className="flex flex-wrap gap-1.5">
                {tags.map(([key, value]) => (
                  <span key={key} className="inline-flex max-w-full items-center rounded-md border border-line bg-surface-2 px-2 py-0.5 font-mono text-[11.5px]">
                    <span className="text-ink-3">{key}</span>
                    {value !== '' && value !== null && (
                      <span className="truncate text-ink">={typeof value === 'object' ? JSON.stringify(value) : String(value)}</span>
                    )}
                  </span>
                ))}
              </span>
            )}
          </div>
          <h3 className="mt-5 mb-1 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Related</h3>
          <RelatedLinks
            links={[
              ownership.owner && { to: `/identities?owner=${encodeURIComponent(ownership.owner)}`, label: `Everything ${ownership.owner} owns`, hint: 'Same owner' },
              { to: `/identities?identity_type=${encodeURIComponent(identity.identity_type)}`, label: `Every ${identityTypeLabel(identity.identity_type)}`, hint: 'Same type' },
              { to: `/identities?account_id=${encodeURIComponent(identity.account_id)}`, label: `Identities in ${identity.account_id}`, hint: 'Same account' },
              { to: `/identities?functional_class=${encodeURIComponent(identity.functional_class || 'unclassified')}`, label: `${functionalClassLabel(identity.functional_class)} identities`, hint: 'Same class' },
            ]}
          />
        </Panel>
      </div>

      {/* 3. Is it in use: its life on one line. */}
      <Panel>
        <PanelHeader
          title="Activity"
          subtitle="Its life as periods: how long it went unseen, how long it has been idle. A long idle period is the case for removing it."
          icon={Clock}
        />
        <div className="mt-4">
          <Lifecycle now={now} {...identityLifecycle(identity, now)} />
          {lastActive && parseDate(identity.created_at_aws) && lastActive < parseDate(identity.created_at_aws) && (
            <p className="mt-3 rounded-[var(--radius-control)] border border-medium/30 bg-medium-soft px-3 py-2 text-[12px] text-ink-2">
              AWS reports this identity as last active before it was created. One of the two dates is wrong in the source data, so treat the inactive period as approximate.
            </p>
          )}
        </div>
      </Panel>

      {/* 4. Where it came from and who can reach it. */}
      <Panel>
        <PanelHeader title="Origin and reach" subtitle="Who created it, what it belongs to, and where it can be reached from." icon={Globe2} />
        <div className="mt-3">
          <AccessChain
            links={['created', 'runs in']}
            steps={[
              {
                key: 'creator',
                label: 'Created by',
                empty: 'Not found in CloudTrail',
                items: creator ? [{ title: creator.name, meta: `${SERVICE_NAMES[creator.service] ?? creator.service} · account ${creator.account}`, mono: true }] : [],
                footer: lineage.cloudtrail_creator_arn ? <CopyableValue value={lineage.cloudtrail_creator_arn} className="text-[11px]" /> : null,
              },
              {
                key: 'self',
                label: 'This identity',
                self: true,
                items: [
                  { title: identity.name || identity.arn, meta: `${identityTypeLabel(identity.identity_type)} · ${statusMeta(identity.status).label}` },
                  parent
                    ? { title: `Part of ${parent.name}`, meta: SERVICE_NAMES[parent.service] ?? parent.service }
                    : { title: 'No parent resource', meta: 'Not part of a stack or group' },
                ],
              },
              {
                key: 'network',
                label: 'Network',
                tone: isPublic ? 'critical' : undefined,
                items: [
                  isPublic
                    ? { title: 'Reachable from the internet', meta: 'Publicly accessible', tone: 'critical' }
                    : network.is_publicly_accessible === false
                      ? { title: 'Not publicly reachable', meta: 'Private' }
                      : { title: 'Exposure not determined', meta: 'The scanner could not tell' },
                  { title: network.vpc_id || 'No VPC recorded', meta: network.subnet_id ? `subnet ${network.subnet_id}` : 'No subnet recorded', mono: Boolean(network.vpc_id) },
                  { title: groups.length ? `${groups.length} security group${groups.length === 1 ? '' : 's'}` : 'No security groups', meta: groups.join(', ') || undefined },
                ],
              },
            ]}
          />
        </div>
      </Panel>

      {/* 5. How it was found (reference console). */}
      <Panel prominence="quiet">
        <PanelHeader title="How it was found" prominence="quiet" />
        <DetailList className="mt-2">
          <DetailRow label="Source">{tokenLabel(discovery.discovery_source)}</DetailRow>
          <DetailRow label="Scan" mono>
            {discovery.scan_id || <Missing />}
          </DetailRow>
          <DetailRow label="First discovered">{identity.first_seen_at ? formatDateTime(identity.first_seen_at) : <Missing />}</DetailRow>
          {parent && (
            <DetailRow label="Parent" mono>
              <CopyableValue value={lineage.parent_arn} />
            </DetailRow>
          )}
          {lineage.cloudtrail_creator_arn && (
            <DetailRow label="Created by" mono>
              <CopyableValue value={lineage.cloudtrail_creator_arn} />
            </DetailRow>
          )}
          <DetailRow label="ID" mono>
            <CopyableValue value={identity.id} />
          </DetailRow>
        </DetailList>
      </Panel>
    </div>
  );
}

const EVENT_LABELS = {
  first_discovered: { label: 'First discovered', hint: 'The scanner saw this identity for the first time.' },
  last_activity: { label: 'Last active', hint: 'The most recent use AWS has recorded.' },
  last_confirmed: { label: 'Last confirmed', hint: 'The latest scan that still found it.' },
};

function TimelineTab({ query }) {
  if (query.isError) {
    return (
      <Panel>
        <ErrorState error={query.error} onRetry={query.refetch} />
      </Panel>
    );
  }
  if (!query.data) {
    return (
      <Panel>
        <ListSkeleton rows={3} />
      </Panel>
    );
  }
  const data = query.data;
  const events = [...(data.events ?? [])].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
  /* The API reports 0 days when there is no activity at all; only a
     last_activity event makes the figure meaningful. */
  const tracked = events.some((event) => event.event === 'last_activity');
  return (
    <Panel>
      <PanelHeader title="Timeline" />
      <dl className="mt-3 grid grid-cols-2 gap-3 border-b border-line pb-4">
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Known for</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {formatNumber(data.age_days)} <span className="text-[12px] font-medium text-ink-3">days</span>
          </dd>
        </div>
        <div>
          <dt className="text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">Since last activity</dt>
          <dd data-numeric="" className="mt-1 font-display text-[20px] leading-none font-bold text-ink">
            {!tracked || data.days_since_last_activity === null || data.days_since_last_activity === undefined ? (
              <span className="text-[13px] font-medium text-ink-3">Not tracked</span>
            ) : (
              <>
                {formatNumber(data.days_since_last_activity)} <span className="text-[12px] font-medium text-ink-3">days</span>
              </>
            )}
          </dd>
        </div>
      </dl>
      <ol className="mt-4 flex flex-col gap-4 border-l border-line pl-5">
        {events.map((event) => {
          const meta = EVENT_LABELS[event.event] ?? { label: tokenLabel(event.event), hint: '' };
          return (
            <li key={`${event.event}-${event.timestamp}`} className="relative">
              <span aria-hidden="true" className="absolute top-1.5 -left-[25px] size-2.5 rounded-full border-2 border-surface bg-brand" />
              <p className="text-[13px] font-medium text-ink">{meta.label}</p>
              <p className="text-[12px] text-ink-3">
                <time dateTime={event.timestamp}>{formatDateTime(event.timestamp)}</time> · {formatRelative(event.timestamp)}
              </p>
              {meta.hint && <p className="mt-0.5 text-[12px] text-ink-3">{meta.hint}</p>}
            </li>
          );
        })}
      </ol>
    </Panel>
  );
}

/**
 * Credentials whose recorded owner principal is this identity, worst first.
 * The API has no identity-to-credential binding lookup yet (bindings are
 * read from the credential side), so this is ownership, and says so.
 */
function OwnedCredentials({ query, arn }) {
  const navigate = useNavigate();
  const rows = query.data?.data ?? [];
  return (
    <Panel flush className="overflow-hidden">
      <div className="border-b border-line px-4 py-3">
        <h2 className="text-[14px] font-semibold text-ink">Credentials it owns</h2>
        <p className="mt-0.5 text-[12.5px] text-ink-3">
          Credentials recorded with this identity as their owner principal, most privileged first. Credentials it uses through a binding are listed on each credential&apos;s own page.
        </p>
      </div>
      <DataGrid
        caption="Credentials owned by this identity"
        density="compact"
        loading={query.isLoading && !query.data}
        rows={rows}
        rowKey={(row) => row.id}
        onRowClick={(row) => navigate(`/credentials/${encodeURIComponent(row.id)}`)}
        rowLabel={(row) => `Open ${row.name || row.arn}`}
        emptyState={
          query.isError ? (
            <ErrorState compact error={query.error} onRetry={query.refetch} />
          ) : (
            <EmptyState
              compact
              icon={KeyRound}
              title="No credential names it as owner"
              description="No credential in the latest scan has this identity as its owner principal."
              action={
                <Button as={Link} to={`/credentials?owner_principal_arn=${encodeURIComponent(arn)}`} variant="secondary" size="sm">
                  Open the credential list
                </Button>
              }
            />
          )
        }
        columns={[
          {
            key: 'name',
            header: 'Credential',
            primary: true,
            width: '34%',
            cell: (row) => {
              const badge = credentialBadge(row.credential_type);
              return (
                <span className="flex min-w-0 items-center gap-3">
                  <TypeBadge code={badge.code} color={badge.color} />
                  <span className="min-w-0">
                    <span className="block truncate text-[13px] font-semibold text-ink">{row.name || row.arn}</span>
                    <span className="block truncate text-[11px] text-ink-3">{credentialTypeLabel(row.credential_type)}</span>
                  </span>
                </span>
              );
            },
          },
          { key: 'risk', header: 'Needs attention', width: '190px', mobile: true, cell: (row) => <RiskCell signals={credentialSignals(row)} /> },
          { key: 'used', header: 'Last used', width: '140px', cell: (row) => <Freshness value={row.last_used_at} empty="Never used" /> },
          { key: 'expires', header: 'Expires', width: '130px', priority: 'wide', cell: (row) => <ExpiryCell value={row.expires_at} /> },
        ]}
      />
    </Panel>
  );
}
