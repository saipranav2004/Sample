import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import {
  fetchBoundIdentities,
  fetchCredential,
  fetchCredentialFlags,
  fetchCredentialImpact,
  fetchCredentials,
  fetchIdentity,
} from '../../lib/api/endpoints';
import { credentialSignals } from '../../lib/signals';
import { credentialFindings, identityFindings } from '../../lib/verdict';
import { BlastRadius } from '../credentials/relations';
import { RiskCell } from '../../ui/RiskCell';
import { Verdict } from '../../ui/Verdict';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatRelative } from '../../lib/format';
import { credentialTypeLabel, functionalClassLabel, identityTypeLabel, privilegeMeta, regionLabel, statusMeta, tokenLabel } from '../../lib/labels';
import { EASE_OUT } from '../../lib/motion';
import { Button, IconButton } from '../../ui/Button';
import { CopyableValue } from '../../ui/Copyable';
import { Drawer } from '../../ui/Overlay';
import { FactsCard } from '../../ui/FactsCard';
import { DetailSkeleton, ListSkeleton } from '../../ui/Skeleton';
import { ErrorState } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import { credentialChecks } from '../credentials/checks';
import { ExpiryCell, TagChips } from '../credentials/parts';

/**
 * Quick look at one row without leaving the list: what is wrong with it,
 * who owns it, and the dates that matter. Up and down (or J and K) step
 * through the rows behind it; the full page is one click away.
 *
 * Triage is "check ten rows in a row". Opening each one as a page costs a
 * load and the reader's place in the list every time.
 */
export function RecordPreview({ kind, rows, index, onIndexChange, onClose }) {
  const open = index !== null && index >= 0 && index < rows.length;
  const row = open ? rows[index] : null;
  const total = rows.length;

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      const tag = event.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((event.key === 'ArrowDown' || event.key === 'j') && index < total - 1) {
        event.preventDefault();
        onIndexChange(index + 1);
      }
      if ((event.key === 'ArrowUp' || event.key === 'k') && index > 0) {
        event.preventDefault();
        onIndexChange(index - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, index, total, onIndexChange]);

  const href = row ? `/${kind === 'identity' ? 'identities' : 'credentials'}/${encodeURIComponent(row.id)}` : '#';
  const typeLabel = row ? (kind === 'identity' ? identityTypeLabel(row.identity_type) : credentialTypeLabel(row.credential_type)) : '';

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="lg"
      eyebrow={row ? (kind === 'identity' ? `${functionalClassLabel(row.functional_class)} identity` : 'Credential') : ''}
      title={row ? row.name || row.arn : ''}
      subtitle={row ? [typeLabel, row.account_id && `account ${row.account_id}`, row.region && regionLabel(row.region)].filter(Boolean).join(' · ') : null}
      footer={
        <>
          <span className="mr-auto flex items-center gap-1">
            <IconButton icon={ChevronUp} label="Previous row (K)" size="sm" variant="secondary" disabled={!open || index === 0} onClick={() => onIndexChange(index - 1)} />
            <IconButton icon={ChevronDown} label="Next row (J)" size="sm" variant="secondary" disabled={!open || index >= total - 1} onClick={() => onIndexChange(index + 1)} />
            <span data-numeric="" className="ml-1.5 text-[12px] text-ink-3">
              {open ? `${index + 1} of ${total}` : ''}
            </span>
          </span>
          <Button as={Link} to={href} variant="primary" iconRight={ArrowRight}>
            Open {kind === 'identity' ? 'identity' : 'credential'}
          </Button>
        </>
      }
    >
      {/* Stepping between rows swaps the body with a short cross-fade, so the
          change of record is visible without the panel moving. */}
      <AnimatePresence mode="wait" initial={false}>
        {row && (
          <motion.div
            key={row.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: EASE_OUT }}
            className="@container flex flex-col gap-5 p-4 sm:p-5"
          >
            {kind === 'identity' ? <IdentityBody id={row.id} /> : <CredentialBody id={row.id} />}
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}

function Section({ title, aside, children }) {
  return (
    <section>
      <div className="mb-1.5 flex items-baseline justify-between gap-3">
        <h3 className="text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{title}</h3>
        {aside && <span className="text-[11.5px] text-ink-3">{aside}</span>}
      </div>
      {children}
    </section>
  );
}

function CredentialBody({ id }) {
  const detail = useQuery((signal) => fetchCredential(id, signal), [id]);
  const flags = useQuery((signal) => fetchCredentialFlags(id, signal), [id]);
  const impact = useQuery((signal) => fetchCredentialImpact(id, signal), [id]);
  const holders = useQuery((signal) => fetchBoundIdentities(id, signal), [id]);
  const credential = detail.data;
  if (detail.isError) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!credential) {
    return (
      <>
        <DetailSkeleton rows={6} />
        <ListSkeleton rows={3} />
      </>
    );
  }
  const status = statusMeta(credential.status);
  const isRole = credential.credential_type === 'iam_role';
  const level = Number(credential.iam_role_details?.privilege_level);
  const owner = credential.owner_principal_arn;
  const checks = flags.data ? credentialChecks(credential, flags.data.flags) : [];
  const clear = checks.filter((check) => check.result === 'clear');
  /* Holders still loading or failed: the verdict waits for the flags only and
     leaves the holder finding out rather than guessing. */
  const findings = flags.isError ? [] : credentialFindings({ credential, flags: flags.data?.flags, holders: holders.data });
  const list = holders.data?.identities ?? [];
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Tag size="sm" tone={status.tone} dot>
          {status.label}
        </Tag>
        <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
          <CopyableValue value={credential.arn} />
        </span>
      </div>
      {flags.isError ? (
        <ErrorState compact error={flags.error} onRetry={flags.refetch} title="Hygiene checks could not load" />
      ) : (
        <Verdict
          findings={findings}
          cleanText={clear.length ? `${clear.length} hygiene check${clear.length === 1 ? '' : 's'} clear.` : 'No hygiene check applies to this type.'}
          moreText={(n) => `+${n} more on the full record`}
        />
      )}
      <FactsCard
        facts={[
          { label: 'Owner principal', value: owner ? String(owner).split(':').pop() : 'None recorded', mono: Boolean(owner), tone: owner ? undefined : 'medium', sub: owner ? String(owner).split(':')[4] || undefined : undefined },
          isRole
            ? { label: 'Privilege', value: Number.isFinite(level) ? `${level} of 10 · ${privilegeMeta(level).label}` : 'Not scored', tone: Number.isFinite(level) && level >= 6 ? privilegeMeta(level).tone : undefined }
            : { label: 'Rotation', value: credential.rotation_enabled === true ? 'Automatic' : credential.rotation_enabled === false ? 'Turned off' : 'Not managed' },
          { label: 'Last used', value: credential.last_used_at ? formatRelative(credential.last_used_at) : 'No recorded use', sub: credential.last_used_at ? formatDateTime(credential.last_used_at) : undefined },
          { label: 'Expires', value: <ExpiryCell value={credential.expires_at} /> },
        ]}
      />
      <Section title="Held by" aside={holders.data ? `${holders.data.total_identities} identit${holders.data.total_identities === 1 ? 'y' : 'ies'}` : null}>
        {holders.isError ? (
          <ErrorState compact error={holders.error} onRetry={holders.refetch} />
        ) : !holders.data ? (
          <ListSkeleton rows={2} />
        ) : list.length === 0 ? (
          <p className="text-[12.5px] text-ink-3">No identity is bound to it in the latest scan.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-line rounded-[var(--radius-control)] border border-line">
            {list.slice(0, 3).map((holder) => (
              <li key={holder.identity_id}>
                <Link to={`/identities/${encodeURIComponent(holder.identity_id)}`} className="flex items-center justify-between gap-3 px-3 py-2 hover:bg-surface-2">
                  <span className="min-w-0">
                    <span className="block truncate text-[13px] font-medium text-ink">{holder.identity_name || holder.identity_id}</span>
                    <span className="block truncate text-[11.5px] text-ink-3">
                      {identityTypeLabel(holder.identity_type)} · {tokenLabel(holder.binding_type)}
                    </span>
                  </span>
                  {holder.is_primary && (
                    <Tag size="sm" tone="neutral">
                      Primary
                    </Tag>
                  )}
                </Link>
              </li>
            ))}
            {list.length > 3 && <li className="px-3 py-2 text-[12px] text-ink-3">+{list.length - 3} more on the full record</li>}
          </ul>
        )}
      </Section>
      <BlastRadius query={impact} compact />
      {credential.tags && Object.keys(credential.tags).length > 0 && (
        <Section title="Tags">
          <TagChips tags={credential.tags} />
        </Section>
      )}
    </>
  );
}

function IdentityBody({ id }) {
  const detail = useQuery((signal) => fetchIdentity(id, signal), [id]);
  const identity = detail.data;
  const arn = identity?.arn;
  const owned = useQuery(
    (signal) => fetchCredentials({ owner_principal_arn: arn, limit: 3, sort_by: 'privilege_level', sort_order: 'desc' }, signal),
    [arn],
    { enabled: Boolean(arn) },
  );
  if (detail.isError) return <ErrorState compact error={detail.error} onRetry={detail.refetch} />;
  if (!identity) {
    return (
      <>
        <DetailSkeleton rows={6} />
        <ListSkeleton rows={3} />
      </>
    );
  }
  const status = statusMeta(identity.status);
  const isPublic = identity.network?.is_publicly_accessible === true;
  const creator = identity.lineage?.cloudtrail_creator_arn;
  const network = identity.network ?? {};
  const lineage = identity.lineage ?? {};
  const rows = owned.data?.data ?? [];
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Tag size="sm" tone={status.tone} dot>
          {status.label}
        </Tag>
        {identity.deleted_at && <Tag size="sm" tone="neutral">Removed {formatRelative(identity.deleted_at)}</Tag>}
        <span className="min-w-0 max-w-full text-[11.5px] text-ink-3">
          <CopyableValue value={identity.arn} />
        </span>
      </div>
      <Verdict findings={identityFindings(identity)} cleanText="Private, owned, labelled and in use." />
      <FactsCard
        facts={[
          { label: 'Owner', value: identity.ownership?.owner || 'No owner', tone: identity.ownership?.owner ? undefined : 'medium', sub: identity.ownership?.environment || 'No environment' },
          { label: 'Last active', value: identity.last_activity_at ? formatRelative(identity.last_activity_at) : 'No activity recorded', sub: identity.last_activity_at ? formatDateTime(identity.last_activity_at) : undefined },
          { label: 'Reachable from', value: isPublic ? 'The internet' : network.is_publicly_accessible === false ? 'Private network only' : null, tone: isPublic ? 'critical' : undefined, sub: network.vpc_id ? `VPC ${network.vpc_id}` : undefined },
          { label: 'Created by', value: creator ? String(creator).split('/').pop() : null, mono: Boolean(creator), sub: lineage.parent_arn ? `Part of ${String(lineage.parent_arn).split(':').pop()}` : creator ? 'CloudTrail' : 'Not found in CloudTrail' },
        ]}
      />
      <Section title="Credentials it owns" aside={owned.data ? `${owned.data.total} total` : null}>
        {owned.isError ? (
          <ErrorState compact error={owned.error} onRetry={owned.refetch} />
        ) : !owned.data ? (
          <ListSkeleton rows={2} />
        ) : rows.length === 0 ? (
          <p className="text-[12.5px] text-ink-3">No credential records this identity as its owner principal.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-line rounded-[var(--radius-control)] border border-line">
            {rows.map((row) => (
              <li key={row.id}>
                <Link to={`/credentials/${encodeURIComponent(row.id)}`} className="flex items-center justify-between gap-3 px-3 py-2 hover:bg-surface-2">
                  <span className="min-w-0">
                    <span className="block truncate text-[13px] font-medium text-ink">{row.name || row.arn}</span>
                    <span className="block truncate text-[11.5px] text-ink-3">{credentialTypeLabel(row.credential_type)}</span>
                  </span>
                  <RiskCell signals={credentialSignals(row)} />
                </Link>
              </li>
            ))}
            {owned.data.total > rows.length && <li className="px-3 py-2 text-[12px] text-ink-3">+{owned.data.total - rows.length} more on the full record</li>}
          </ul>
        )}
      </Section>
    </>
  );
}
