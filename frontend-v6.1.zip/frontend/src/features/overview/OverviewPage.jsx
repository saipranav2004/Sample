import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Clock, FileWarning, Fingerprint, KeyRound, Link2Off, RotateCw, ScanLine, TimerReset } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import {
  fetchCredentialHygiene,
  fetchCredentialsByType,
  fetchExposure,
  fetchFindings,
  fetchIdentities,
  fetchIdentitiesByClass,
  fetchOrphanedCredentials,
  fetchScanContext,
  fetchSummary,
} from '../../lib/api/endpoints';
import { useQuery } from '../../lib/hooks';
import { formatDateTime, formatNumber, formatRelative, humanizeToken, localDateDaysAgo, percentValue } from '../../lib/format';
import { Page, Reveal, RevealItem, RevealList } from '../../lib/motion';
import { classColor, credentialBadge, credentialTypeLabel, functionalClassLabel, regionLabel } from '../../lib/labels';
import { optionsOf, useFilterOptions } from '../../lib/useFilterOptions';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { Select } from '../../ui/Field';
import { ProportionBar } from '../../ui/Meter';
import { Panel, PanelHeader } from '../../ui/Panel';
import { MetricTile } from '../../ui/Stat';
import { ListSkeleton, Skeleton, StatStripSkeleton } from '../../ui/Skeleton';
import { ClearState, EmptyState, ErrorState, InlineError } from '../../ui/States';
import { Tag } from '../../ui/Tag';
import { TONE_FG, TONE_VAR, cn } from '../../ui/cn';
import { analystDecisionMeta, summariseFindings } from '../exposure/scannerState';

const ACCOUNT = /^[0-9]{12}$/;
const REGION = /^[a-z0-9-]{1,64}$/;

/**
 * Dashboard. It answers four questions, in the order a security lead asks
 * them on opening the console, and nothing else:
 *
 *   1. Which scan am I looking at?                    snapshot strip
 *   2. How big is the estate, and is it growing?       four tiles
 *   3. Where is the risk concentrated?                 exposure signals
 *   4. Have secrets leaked into code?                  credential exposure
 *
 * plus one compact line on what the estate is made of. Per-item work (what
 * to fix next, who owns it) belongs on the lists and, later, on Alerts; the
 * dashboard shows how widespread each problem is, not a to-do list.
 *
 * Every figure comes from an existing endpoint, scoped by the API to the
 * latest completed scan. Each panel loads and fails on its own.
 */
export default function OverviewPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { can } = useAccess();
  const canSeeExposure = can('exposure.view');
  const accountId = ACCOUNT.test(searchParams.get('account_id') ?? '') ? searchParams.get('account_id') : '';
  const region = REGION.test(searchParams.get('region') ?? '') ? searchParams.get('region') : '';
  const filtered = Boolean(accountId || region);
  const options = optionsOf(useFilterOptions());

  const both = { account_id: accountId, region };
  const acct = { account_id: accountId };
  const key = `${accountId}|${region}`;

  const summary = useQuery((signal) => fetchSummary(both, signal), [key]);
  const scans = useQuery((signal) => fetchScanContext(signal), []);
  const exposure = useQuery((signal) => fetchExposure(acct, signal), [accountId]);
  /* Counted with the same request the row opens, so the figure and the list
     agree; the exposure endpoint's own dormant bucket uses a slightly
     different cut-off (now minus 90 days rather than a calendar date). */
  const inactiveSince = localDateDaysAgo(90);
  const inactive = useQuery((signal) => fetchIdentities({ ...acct, last_active_before: `${inactiveSince}T00:00:00Z`, limit: 1 }, signal), [accountId, inactiveSince]);
  const hygiene = useQuery((signal) => fetchCredentialHygiene(acct, signal), [accountId]);
  const orphaned = useQuery((signal) => fetchOrphanedCredentials(signal), []);
  const byClass = useQuery((signal) => fetchIdentitiesByClass(both, signal), [key]);
  const byType = useQuery((signal) => fetchCredentialsByType(both, signal), [key]);
  const findings = useQuery((signal) => fetchFindings(signal), [], { enabled: canSeeExposure });
  const flagged = useQuery((signal) => fetchFindings(signal, { flagged: true }), [], { enabled: canSeeExposure });

  const queries = [summary, scans, exposure, inactive, hygiene, orphaned, byClass, byType, ...(canSeeExposure ? [findings, flagged] : [])];
  const refreshing = queries.some((query) => query.isRefreshing);
  const refreshAll = () => queries.forEach((query) => query.refetch());
  const allFailed = queries.every((query) => query.isError && !query.data);

  const setFilter = (name, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(name, value);
    else next.delete(name);
    setSearchParams(next, { replace: true });
  };
  const scope = { accountId, region };

  return (
    <Page className="flex flex-col gap-5">
      <Reveal>
        <PageHeader
          title="Dashboard"
          lede="Non-human identities and the credentials they hold, across every AWS account the scanner reaches."
          actions={
            <>
              <Select
                size="sm"
                aria-label="AWS account"
                value={accountId}
                onChange={(event) => setFilter('account_id', event.target.value)}
                options={[{ value: '', label: 'All accounts' }, ...options.accounts.map((id) => ({ value: id, label: id }))]}
                className="w-40"
              />
              <Select
                size="sm"
                aria-label="Region"
                value={region}
                onChange={(event) => setFilter('region', event.target.value)}
                options={[{ value: '', label: 'All regions' }, ...options.regions.map((r) => ({ value: r, label: regionLabel(r) }))]}
                className="w-36"
              />
              <Button variant="secondary" size="sm" icon={RotateCw} onClick={refreshAll} loading={refreshing}>
                Refresh
              </Button>
            </>
          }
          meta={<ScanSnapshot scans={scans} summary={summary} filtered={filtered} onClear={() => setSearchParams({}, { replace: true })} />}
        />
      </Reveal>

      {allFailed ? (
        <Reveal>
          <Panel>
            <ErrorState error={summary.error} onRetry={refreshAll} title="The dashboard could not be loaded" />
          </Panel>
        </Reveal>
      ) : (
        <>
          <Reveal>
            <Headline summary={summary} scans={scans} orphaned={orphaned} findings={canSeeExposure ? findings : null} filtered={filtered} scope={scope} />
          </Reveal>

          <Reveal>
            <SignalsPanel summary={summary} exposure={exposure} inactive={inactive} inactiveSince={inactiveSince} hygiene={hygiene} scope={scope} />
          </Reveal>

          <Reveal className={cn('grid gap-4', canSeeExposure && '@min-[64rem]:grid-cols-2')}>
            {canSeeExposure && <ExposurePanel findings={findings} flagged={flagged} />}
            <MakeupPanel byClass={byClass} byType={byType} scope={scope} stacked={canSeeExposure} />
          </Reveal>
        </>
      )}
    </Page>
  );
}

function withScope(path, { accountId, region }) {
  const url = new URL(path, 'http://x');
  if (accountId) url.searchParams.set('account_id', accountId);
  if (region && !url.searchParams.has('region')) url.searchParams.set('region', region);
  return `${url.pathname}${url.search}`;
}

function ScopeNote({ children }) {
  if (!children) return null;
  return <span className="rounded-full bg-surface-3 px-2 py-0.5 text-[10.5px] font-medium text-ink-3">{children}</span>;
}

/* ── Header strip ────────────────────────────────────────────────────────── */

/**
 * Which scan every figure on this page comes from. The API scopes the
 * inventory and the dashboard to the latest COMPLETED scan, so that scan is
 * named here - with a notice when a newer one is running (the figures change
 * when it completes) or when the newest attempt failed (they did not).
 */
function ScanSnapshot({ scans, summary, filtered, onClear }) {
  if (scans.isLoading && !scans.data) return <Skeleton className="h-[74px] w-full rounded-[var(--radius-panel)]" />;
  const latest = scans.data?.latest;
  const running = scans.data?.running;
  const data = summary.data;
  if (!latest) {
    return (
      <p className="flex items-center gap-2 text-[12.5px] text-ink-3">
        <Clock aria-hidden="true" className="size-3.5" />
        {scans.isError ? 'Scan history is unavailable.' : 'No completed scan yet - figures appear once the first scan finishes.'}
      </p>
    );
  }
  const start = new Date(latest.scan_start).getTime();
  const end = new Date(latest.scan_end).getTime();
  const minutes = Number.isFinite(end - start) ? Math.max(0, Math.round((end - start) / 60000)) : null;
  const cells = [
    { label: 'Scan', value: <span className="font-mono text-[12px]">{latest.scan_id}</span> },
    latest.target_name && { label: 'Target', value: latest.target_name },
    { label: 'Finished', value: <time dateTime={latest.scan_end} title={formatDateTime(latest.scan_end)}>{formatDateTime(latest.scan_end)}</time> },
    minutes !== null && { label: 'Took', value: minutes < 60 ? `${minutes} min` : `${Math.floor(minutes / 60)} h ${minutes % 60} min` },
    data && { label: 'Covers', value: `${formatNumber(data.total_accounts_scanned)} account${data.total_accounts_scanned === 1 ? '' : 's'} · ${formatNumber(data.total_regions_scanned)} region${data.total_regions_scanned === 1 ? '' : 's'}` },
  ].filter(Boolean);
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2.5 rounded-[var(--radius-panel)] border border-line bg-surface px-4 py-3 shadow-[var(--t-shadow-sm)]">
        <div className="flex items-center gap-2.5">
          <span aria-hidden="true" className="grid size-8 place-items-center rounded-lg border border-line bg-surface-2 text-ink-2">
            <ScanLine className="size-4" />
          </span>
          <span>
            <span className="block text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Snapshot</span>
            <span className="block text-[13px] font-semibold text-ink">
              Latest completed scan <span className="font-normal text-ink-3">· {formatRelative(latest.scan_end)}</span>
            </span>
          </span>
        </div>
        {cells.map((cell) => (
          <div key={cell.label} className="min-w-0">
            <span className="block text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{cell.label}</span>
            <span className="block truncate text-[12.5px] text-ink-2">{cell.value}</span>
          </div>
        ))}
        <span className="ml-auto flex items-center gap-3">
          {filtered && (
            <button type="button" onClick={onClear} className="text-[12.5px] font-medium text-brand hover:underline">
              Clear filters
            </button>
          )}
          <Tag tone="low" size="sm" dot>
            Completed
          </Tag>
        </span>
      </div>
      {running && (
        <p className="flex items-center gap-2 rounded-[var(--radius-control)] border border-info/25 bg-info-soft/60 px-3 py-2 text-[12.5px] text-ink-2">
          <span aria-hidden="true" className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-info opacity-60" />
            <span className="relative inline-flex size-2 rounded-full bg-info" />
          </span>
          <span>
            A newer scan, <span className="font-mono text-[12px]">{running.scan_id}</span>, started {formatRelative(running.scan_start)}. These figures switch to it when it completes.
          </span>
        </p>
      )}
    </div>
  );
}

/* ── Tiles ───────────────────────────────────────────────────────────────── */

/**
 * How big the estate is and whether it is growing, then the two numbers
 * nobody else on the page carries: secrets found in code, and credentials
 * no identity holds. The identity trend comes from the scan history, one
 * point per completed scan.
 */
function Headline({ summary, scans, orphaned, findings, filtered, scope }) {
  if (summary.isLoading && !summary.data) return <StatStripSkeleton count={4} />;
  if (summary.isError && !summary.data) {
    return (
      <Panel>
        <ErrorState error={summary.error} onRetry={summary.refetch} title="The summary could not be loaded" compact />
      </Panel>
    );
  }
  const data = summary.data;
  const active = Number(data.identities_by_status?.active) || 0;
  const activeCredentials = Number(data.credentials_by_status?.active) || 0;
  /* The scan history is estate-wide, so the trend is shown only unfiltered. */
  const history = filtered ? [] : [...(scans.data?.completed ?? [])].reverse().map((scan) => Number(scan.total_identities)).filter(Number.isFinite);
  const previous = scans.data?.previous ? Number(scans.data.previous.total_identities) : null;
  const delta = !filtered && previous !== null && Number.isFinite(previous) ? data.total_identities - previous : null;
  const summaryOfFindings = findings?.data ? summariseFindings(findings.data.findings) : null;
  const highFindings = summaryOfFindings ? (summaryOfFindings.byTier.CRITICAL || 0) + (summaryOfFindings.byTier.HIGH || 0) : 0;
  const unreviewed = findings?.data ? findings.data.findings.filter((finding) => analystDecisionMeta(finding.analyst_decision).key === 'unreviewed').length : 0;

  return (
    <div className="grid grid-cols-2 gap-3 @min-[60rem]:grid-cols-4">
      <MetricTile
        as={Link}
        to={withScope('/identities', scope)}
        label="Identities"
        value={data.total_identities}
        icon={Fingerprint}
        caption={[delta !== null ? `${delta >= 0 ? '+' : ''}${formatNumber(delta)} since the previous scan` : null, `${formatNumber(active)} active`].filter(Boolean).join(' · ')}
        sparkline={history.length > 1 ? history : undefined}
        meter={history.length > 1 ? undefined : percentValue(active, data.total_identities)}
        meterLabel="Share active"
      />
      <MetricTile
        as={Link}
        to={withScope('/credentials', scope)}
        label="Credentials"
        value={data.total_credentials}
        icon={KeyRound}
        caption={`${formatNumber(activeCredentials)} active`}
        meter={percentValue(activeCredentials, data.total_credentials)}
        meterLabel="Share active"
      />
      {findings ? (
        <MetricTile
          as={Link}
          to="/exposure"
          label="Secrets in code"
          value={findings.data ? findings.data.count : null}
          icon={FileWarning}
          tone={findings.data?.count ? 'critical' : 'low'}
          caption={findings.isError ? 'Findings could not be loaded' : findings.data ? `${formatNumber(highFindings)} high risk · ${formatNumber(unreviewed)} not reviewed` : 'Loading'}
        />
      ) : (
        <MetricTile
          as={Link}
          to={withScope('/credentials?expiring_within_days=30', scope)}
          label="Expiring in 30 days"
          value={data.expiring_credentials_30d}
          icon={TimerReset}
          tone={data.expiring_credentials_30d > 0 ? 'high' : undefined}
          caption="Renew or retire before they lapse"
        />
      )}
      <MetricTile
        as={Link}
        to="/credentials?view=orphaned"
        label="Held by no identity"
        value={orphaned.data ? orphaned.data.total : null}
        icon={Link2Off}
        tone={orphaned.data?.total ? 'medium' : 'low'}
        caption={orphaned.isError ? 'Could not be loaded' : filtered ? 'No identity bound to them · all accounts' : 'No identity bound to them - review or remove'}
      />
    </div>
  );
}

/* ── Exposure signals ────────────────────────────────────────────────────── */

const TONE_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

/**
 * How widespread each risk is: a count, and the share of identities or
 * credentials it covers. A share says whether a problem is a handful of
 * stragglers or the norm, which a bare count cannot.
 */
function SignalsPanel({ summary, exposure, inactive, inactiveSince, hygiene, scope }) {
  const s = summary.data;
  const e = exposure.data;
  const h = hygiene.data;
  const identities = Number(s?.total_identities) || 0;
  const credentials = Number(s?.total_credentials) || 0;
  const groups = [
    {
      key: 'identities',
      title: 'Identities',
      base: identities,
      unit: 'identities',
      ready: Boolean(e && s),
      error: exposure.isError && !e ? exposure : null,
      items: e
        ? [
            { key: 'public', tone: 'critical', label: 'Reachable from the internet', detail: 'A public endpoint or address, so anyone can try it.', value: e.publicly_accessible?.total, to: withScope('/identities?is_public=true', { accountId: scope.accountId }) },
            { key: 'dormant', tone: 'high', label: 'Inactive for 90+ days', detail: 'Still deployed, nothing has used it for three months.', value: inactive.data ? inactive.data.total : e.dormant_90d?.total, to: withScope(`/identities?last_active_before=${inactiveSince}`, { accountId: scope.accountId }) },
            { key: 'owner', tone: 'medium', label: 'No owner', detail: 'No owner tag, so nobody is answerable for it.', value: e.missing_owner_tag },
            { key: 'env', tone: 'medium', label: 'No environment', detail: 'Production and test cannot be told apart.', value: e.missing_environment_tag },
            { key: 'untracked', tone: 'medium', label: 'No activity tracked', detail: 'AWS reports no usage, so idleness cannot be judged.', value: e.no_activity_tracked },
          ]
        : [],
    },
    {
      key: 'credentials',
      title: 'Credentials',
      base: credentials,
      unit: 'credentials',
      ready: Boolean(h && s),
      error: hygiene.isError && !h ? hygiene : null,
      items: h
        ? [
            { key: 'root', tone: 'critical', label: 'Root account access keys', detail: 'Root should never hold keys.', value: h.root_access_keys_present },
            { key: 'public-trust', tone: 'critical', label: 'Roles anyone can assume', detail: 'The trust policy allows any principal.', value: h.public_trust_roles },
            { key: 'expired', tone: 'critical', label: 'Past their expiry date', detail: 'Still listed after they stopped working.', value: h.already_expired?.total },
            { key: 'privileged', tone: 'high', label: 'High-privilege IAM roles', detail: `Privilege 7 or above; ${formatNumber(h.high_privilege_roles?.admin_access)} with admin access.`, value: h.high_privilege_roles?.total, to: withScope('/credentials?credential_type=iam_role&privilege_level_min=7', { accountId: scope.accountId }) },
            { key: 'expiring', tone: 'high', label: 'Expiring within 30 days', detail: 'Renew or retire before they lapse.', value: h.expiring_within_30d?.total, to: withScope('/credentials?expiring_within_days=30', { accountId: scope.accountId }) },
            { key: 'stale-keys', tone: 'medium', label: 'Access keys unused for 90 days', detail: 'Live keys nobody calls with.', value: h.stale_access_keys_90d, to: withScope('/credentials?credential_type=access_key&stale_days=90', { accountId: scope.accountId }) },
            { key: 'unrotated', tone: 'medium', label: 'Secrets not rotated in 90 days', detail: 'The same value for a quarter or more.', value: h.unrotated_secrets_90d },
            { key: 'rotation-off', tone: 'medium', label: 'Rotation turned off', detail: 'Secrets that will never change on their own.', value: h.rotation_disabled_secrets, to: withScope('/credentials?rotation_enabled=false', { accountId: scope.accountId }) },
          ]
        : [],
    },
  ];

  return (
    <Panel>
      <PanelHeader
        icon={TimerReset}
        title="Exposure signals"
        subtitle="How widespread each risk is across the estate. Select one to see the records."
        actions={<ScopeNote>{scope.region ? 'All regions' : null}</ScopeNote>}
      />
      <div className="mt-4 grid gap-x-10 gap-y-6 @min-[46rem]:grid-cols-2">
        {groups.map((group) => {
          const open = group.items.filter((item) => Number(item.value) > 0).sort((a, b) => TONE_ORDER[a.tone] - TONE_ORDER[b.tone] || b.value - a.value);
          const clear = group.items.filter((item) => Number(item.value) === 0);
          return (
            <section key={group.key} className="min-w-0">
              <h3 className="mb-1 flex items-baseline justify-between text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">
                {group.title}
                <span className="font-medium tracking-normal normal-case">of {formatNumber(group.base)}</span>
              </h3>
              {group.error ? (
                <InlineError error={group.error.error} onRetry={group.error.refetch} label={`${group.title} signals could not load`} />
              ) : !group.ready ? (
                <ListSkeleton rows={4} />
              ) : open.length === 0 ? (
                <ClearState compact title="Nothing flagged" description="Every signal here reads zero." />
              ) : (
                <RevealList className="flex flex-col divide-y divide-line">
                  {open.map((item, index) => (
                    <RevealItem key={item.key} index={index}>
                      <SignalRow item={item} base={group.base} unit={group.unit} />
                    </RevealItem>
                  ))}
                </RevealList>
              )}
              {clear.length > 0 && (
                <p className="mt-2 flex items-start gap-1.5 text-[11.5px] text-ink-3">
                  <CheckCircle2 aria-hidden="true" className="mt-px size-3.5 shrink-0 text-low" />
                  <span>
                    <span className="font-medium text-ink-2">Clear:</span> {clear.map((item) => item.label.toLowerCase()).join(', ')}.
                  </span>
                </p>
              )}
            </section>
          );
        })}
      </div>
    </Panel>
  );
}

function SignalRow({ item, base, unit }) {
  const share = base ? (Number(item.value) / base) * 100 : 0;
  const body = (
    <>
      <span className="flex items-baseline justify-between gap-3">
        <span className={cn('text-[13px] font-semibold', TONE_FG[item.tone])}>{item.label}</span>
        <span data-numeric="" className="shrink-0 font-display text-[18px] leading-none font-bold text-ink">
          {formatNumber(item.value)}
        </span>
      </span>
      <span className="mt-0.5 flex items-baseline justify-between gap-3 text-[11.5px] text-ink-3">
        <span className="min-w-0 truncate">{item.detail}</span>
        <span data-numeric="" className="shrink-0">
          {share < 1 && share > 0 ? '<1' : Math.round(share)}% of {unit}
        </span>
      </span>
      <span aria-hidden="true" className="mt-1.5 block h-1.5 overflow-hidden rounded-full bg-[var(--t-track)]">
        <span className="block h-full rounded-full transition-[width] duration-700" style={{ width: `${Math.max(1.5, Math.min(100, share))}%`, background: TONE_VAR[item.tone] }} />
      </span>
    </>
  );
  return item.to ? (
    <Link to={item.to} className="-mx-2 block rounded-md px-2 py-2.5 transition-colors hover:bg-surface-2" title={`Open the ${unit}`}>
      {body}
    </Link>
  ) : (
    <div className="py-2.5">{body}</div>
  );
}

/* ── Credential exposure ─────────────────────────────────────────────────── */

const TIERS = [
  ['HIGH', 'High', 'high'],
  ['MEDIUM', 'Medium', 'medium'],
  ['LOW', 'Low', 'low'],
];

/** Secrets the scanner found in connected repositories (admins only). */
function ExposurePanel({ findings, flagged }) {
  const data = findings.data;
  const summary = data ? summariseFindings(data.findings) : null;
  const unreviewed = data ? data.findings.filter((finding) => analystDecisionMeta(finding.analyst_decision).key === 'unreviewed').length : 0;
  const tiers = summary
    ? [
        ...(summary.byTier.CRITICAL ? [['CRITICAL', 'Critical', 'critical']] : []),
        ...TIERS,
      ].map(([key, label, tone]) => ({ key, label, tone, value: summary.byTier[key] || 0 }))
    : [];
  const max = Math.max(1, ...tiers.map((tier) => tier.value));
  return (
    <Panel>
      <PanelHeader
        icon={FileWarning}
        title="Credential exposure"
        subtitle="Secrets committed to connected repositories, by risk."
        actions={
          <Button as={Link} to="/exposure" variant="secondary" size="sm" iconRight={ArrowRight}>
            Review
          </Button>
        }
      />
      <div className="mt-4">
        {findings.isError && !data ? (
          <InlineError error={findings.error} onRetry={findings.refetch} label="Findings could not load" />
        ) : !data ? (
          <ListSkeleton rows={5} />
        ) : data.count === 0 ? (
          <ClearState compact title="No secrets exposed in code" description="The scanner found nothing outstanding across the connected repositories." />
        ) : (
          <div className="flex flex-col gap-4">
            <ul className="flex flex-col gap-2.5">
              {tiers.map((tier) => (
                <li key={tier.key} className="grid grid-cols-[5.5rem_minmax(0,1fr)_2.5rem] items-center gap-3">
                  <Tag size="sm" tone={tier.tone} dot>
                    {tier.label}
                  </Tag>
                  <span className="h-2 overflow-hidden rounded-full bg-[var(--t-track)]">
                    <span className="block h-full rounded-full" style={{ width: `${(tier.value / max) * 100}%`, background: TONE_VAR[tier.tone] }} />
                  </span>
                  <span data-numeric="" className="text-right text-[15px] font-bold text-ink">
                    {formatNumber(tier.value)}
                  </span>
                </li>
              ))}
            </ul>
            <dl className="grid grid-cols-2 gap-3 border-t border-line pt-3 @min-[26rem]:grid-cols-4">
              {[
                ['GitHub', summary.byPlatform.github],
                ['CodeCommit', summary.byPlatform.codecommit],
                ['Unreviewed', unreviewed],
                ['Likely false', flagged.data ? flagged.data.count : null],
              ].map(([label, value]) => (
                <div key={label} className="min-w-0" title={label === 'Likely false' ? 'The model marks these as probable false positives' : undefined}>
                  <dt className="truncate text-[10.5px] font-semibold tracking-[0.08em] text-ink-3 uppercase">{label}</dt>
                  <dd data-numeric="" className="text-[17px] font-bold text-ink">
                    {value === null ? '-' : formatNumber(value)}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="border-t border-line pt-3">
              <p className="mb-1.5 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">Most frequent detectors</p>
              <ul className="flex flex-col gap-1">
                {summary.detectors.slice(0, 4).map((detector) => (
                  <li key={detector.key} className="flex items-center justify-between gap-3 text-[12.5px]">
                    <span className="truncate text-ink-2">{humanizeToken(detector.key)}</span>
                    <span data-numeric="" className="font-semibold text-ink">
                      {formatNumber(detector.value)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </Panel>
  );
}

/* ── What the estate is made of ──────────────────────────────────────────── */

/**
 * Composition in two lines: identities by class and credentials by type, as
 * one stacked bar each. Context for the signals above, not a work queue, so
 * it takes the least room; a segment or legend entry opens that slice.
 */
function MakeupPanel({ byClass, byType, scope, stacked }) {
  const navigate = useNavigate();
  const rows = [
    {
      key: 'class',
      title: 'Identities by class',
      query: byClass,
      segments: (data) =>
        [...(data.breakdown ?? [])]
          .filter((row) => row.count > 0)
          .sort((a, b) => b.count - a.count)
          .map((row) => ({
            key: row.functional_class,
            label: functionalClassLabel(row.functional_class),
            value: row.count,
            color: classColor(row.functional_class),
            to: withScope(`/identities?functional_class=${encodeURIComponent(row.functional_class)}`, scope),
          })),
    },
    {
      key: 'type',
      title: 'Credentials by type',
      query: byType,
      segments: (data) =>
        [...(data.breakdown ?? [])]
          .filter((row) => row.count > 0)
          .sort((a, b) => b.count - a.count)
          .map((row) => ({
            key: row.credential_type,
            label: credentialTypeLabel(row.credential_type),
            value: row.count,
            color: credentialBadge(row.credential_type).color,
            to: withScope(`/credentials?credential_type=${encodeURIComponent(row.credential_type)}`, scope),
          })),
    },
  ];
  return (
    <Panel>
      <PanelHeader title="What the estate is made of" subtitle="Select a segment to open that slice of the inventory." />
      <div className={cn('mt-4 grid gap-6', !stacked && '@min-[56rem]:grid-cols-2')}>
        {rows.map((row) => (
          <section key={row.key} className="min-w-0">
            <p className="mb-2 text-[10.5px] font-semibold tracking-[0.085em] text-ink-3 uppercase">{row.title}</p>
            {row.query.isError && !row.query.data ? (
              row.query.error?.status === 400 ? (
                <EmptyState compact title="Nothing in this scope" description={row.query.error.message} />
              ) : (
                <InlineError error={row.query.error} onRetry={row.query.refetch} label="Could not load" />
              )
            ) : !row.query.data ? (
              <Skeleton className="h-16 w-full rounded" />
            ) : (
              <MakeupRow segments={row.segments(row.query.data)} label={row.title} onSelect={(segment) => navigate(segment.to)} />
            )}
          </section>
        ))}
      </div>
    </Panel>
  );
}

function MakeupRow({ segments, label, onSelect }) {
  const total = segments.reduce((sum, segment) => sum + segment.value, 0);
  if (total === 0) return <p className="text-[12.5px] text-ink-3">Nothing recorded.</p>;
  return (
    <>
      <ProportionBar height={12} total={total} segments={segments} ariaLabel={label} onSelect={onSelect} />
      <ul className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1.5">
        {segments.map((segment) => (
          <li key={segment.key}>
            <Link to={segment.to} className="inline-flex items-center gap-1.5 text-[12px] text-ink-2 hover:text-ink">
              <span aria-hidden="true" className="size-2.5 rounded-[3px]" style={{ background: segment.color }} />
              {segment.label}
              <span data-numeric="" className="font-semibold text-ink">
                {formatNumber(segment.value)}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
