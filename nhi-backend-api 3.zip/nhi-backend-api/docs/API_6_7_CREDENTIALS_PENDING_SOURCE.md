> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and [current source files](CREDENTIAL_DASHBOARD_UPDATED_CODE.md). #7 still requires approved hygiene rules.

# PDF APIs #6/#7 — credential source pending

**Status:** The endpoints, typed PDF success contracts, services, repository boundaries, authentication, account scope, filter validation, and central wiring are implemented. The credential table has **not** been created; there is no verified complete credential inventory. **Authenticated, authorized requests intentionally return HTTP 503, not a 200 response of zero/sample counts.** These endpoints are *not* PDF-data-complete yet. No schema migration was added.

| PDF # | GET route | Query parameters | Current result after authorization |
|---:|---|---|---|
| 6 | `/api/v1/dashboard/credentials/by-type` | `account_id`, `region`, `status` (all optional) | 503 `DATA_SOURCE_UNAVAILABLE` |
| 7 | `/api/v1/dashboard/credentials/hygiene` | `account_id` (optional) | 503 `DATA_SOURCE_UNAVAILABLE` |

The two GET routes sit on the **same existing `/api` JWT-protected router**. Account scope follows the already-approved policy A: every signed-in dashboard user may view every *known* AWS account, resolved server-side through the existing identity/scan account catalog. No JWT → 401 (the existing auth middleware response envelope); bad or duplicate/unknown query parameter → 400 `INVALID_FILTER`; account_id absent from the known-account set → 403 `FORBIDDEN`; account-scope failure → 503 `ACCESS_POLICY_UNAVAILABLE`; valid request when inventory is unavailable → 503 `DATA_SOURCE_UNAVAILABLE`. The absent `status` enum is **not guessed**: syntax alone is validated (`[a-z][a-z0-9_-]*`, max 64 chars) until the canonical values are known. Region uses the existing dashboard syntax check. Query strings cannot extend the trusted account scope.

A typical valid authorized request currently yields:

```http
HTTP/1.1 503 Service Unavailable
Content-Type: application/json
Cache-Control: no-store

{"error":{"code":"DATA_SOURCE_UNAVAILABLE","message":"Required dashboard data source is not ready"}}
```

The structs for a later successful #6 `{"total":…,"breakdown":[{"credential_type":…,"count":…}]}` and every specified #7 hygiene card are defined in `internal/models/dashboard/credentials_by_type.go` and `credentials_hygiene.go`. A successful result is only permitted from a future complete, verified reader; nil source / nil result / inconsistent metrics fail closed. The **current repository always returns** `ErrCredentialSourceUnavailable`; it executes no SQL. Do **not** infer complete counts from `owned_credentials` or other legacy fields, or return PDF example figures. APIs #4/#5 still include `credential_count:null` until an approved complete inventory exists.

## Integration (existing full backend, not a new main/router)

Replace these files in the four *flat* `dashboard/` directories:

```text
internal/models/dashboard/credentials_by_type.go
internal/models/dashboard/credentials_hygiene.go
internal/repository/dashboard/credentials_by_type.go
internal/repository/dashboard/credentials_hygiene.go
internal/services/dashboard/credentials_by_type.go
internal/services/dashboard/credentials_hygiene.go
internal/handlers/dashboard/credentials_by_type.go
internal/handlers/dashboard/credentials_hygiene.go
```

Also update **existing** `internal/handlers/dashboard/identities_by_class.go` to share authorization checks and validate `status`, **existing** `cmd/api-server/main.go` to wire the new repository/service/handler to the shared account scope, and **existing** `internal/routes/routes.go` to register both protected GET routes. No additional `cmd/` application or `routes.go` is created. The exact complete source files are in [API_6_7_CREDENTIALS_COPY_PASTE.md](API_6_7_CREDENTIALS_COPY_PASTE.md) and the complete backend ZIP. Do not replace developers' local changes without merging.

## What we need before computing real metrics

1. Credential table(s), actual schema, sample sanitized rows, key/account/region/status fields, soft-delete/current-row rule, and approved credential-type values. Confirm whether #6 counts rows, distinct IDs, or unique assets and whether region/status fields are normalized.
2. PDF #7 rules and columns for expiration cutoff (timezone and exclusive/inclusive 30 days), used vs never used, access-key staleness at 90 days, last rotation/rotation enabled for secrets, root key detection, high-privilege role definitions (admin access and wildcard actions may overlap), and public trust. Establish whether some cards require identities, certificates, or IAM role policy/trust tables in addition to a credentials table.
3. Whether any metric lacks an authoritative source even after the table arrives: do **not** return 200 with omitted/unavailable cards disguised as zeros. Either agree on nullable/partial contract with the frontend or continue responding 503 for incomplete #7.

`go test ./...` and `go vet ./...` passed with Go 1.26.5. The optional PostgreSQL fixture tests from APIs #3–#5/#8 were **not run against a database**. They CREATE/TRUNCATE tables; only run them on a disposable `*_test` database, never a live/shared `nhi_db`.
