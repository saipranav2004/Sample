# Credential Exposure Tab — Backend Task Summary

**Status: analysis and implementation plan prepared; secret-scanner APIs are not yet implemented.**

## My task

Build the backend APIs for a **Credential Exposure** tab that shows detected secrets across **AWS CodeCommit and GitHub**. A finding must show where the secret was detected (customer, repository, commit, file and line), its **redacted** preview, actionable risk tier, and distinct scanner-verification, ML and human-review statuses. The tab should let authorized reviewers dismiss/restore findings and record human decisions, and display repository scan progress where required.

## Data and integrations

- Read and merge `nhi_scanner.secscan_findings_codecommit` and `nhi_scanner.secscan_findings_github`. The platform-specific `secscan_allowlist_*` tables plus `secscan_allowlist_dashboard` control which findings are hidden. The two scanner stacks also have `secscan_ledger_*` (last fully scanned commit), `secscan_deepscan_*` (on-demand scan status), and `secscan_jobs_*` (internal worker queues).
- The existing Python scanner/aggregator owns detection, webhooks, job execution and deep-scan triggering. **Do not move scanner workers or enqueue jobs directly from Go.** If a Go deep-scan trigger is approved, call the Python service server-to-server; never put its `X-Dashboard-Key` in browser code.
- Keep this feature separate from the AWS credential **inventory** table (`nhi_scanner.credentials`) and the existing `/api/secrets` route. A detected secret in a code repository is not automatically a row in the AWS credential inventory.

## Planned API work

1. Tenant-scoped, paginated findings list and exact finding detail, combining both platforms and excluding effective allowlisted matches. Add an overview derived from the same authorized finding set if the tab needs summary cards.
2. Allowlist list/dismiss/restore operations; preserve existing Python/dashboard suppression rules and attribute reviewer actions to the authenticated user.
3. Human decision endpoint for `real_secret` or `false_positive`; keep this separate from the ML decision and credential-liveness verification.
4. Read-only repository ledger/deep-scan status. Optional operator-only scan-job health and optional Python-proxied deep-scan trigger, subject to approval.
5. Validation and **exception handling for every endpoint**: JWT authentication, authorized `client_id` scope, reviewer roles, safe 404s, strict request validation, capped pagination/bodies, DB privilege/outage and upstream errors, timeouts and sanitized logging. Cover both platforms, NULL/legacy fields, allowlist overlaps and failure paths in tests.

## Important design decisions before implementation

- The current JWT does **not** establish which scanner `client_id` a user may access. The previously approved all-AWS-accounts dashboard policy does **not** authorize cross-customer secret findings. Agree on a trusted user/team-to-client mapping and reviewer/operator roles first.
- Decide whether Go performs reviewer writes directly to the shared scanner database or calls the existing Python API; confirm scanner re-scans preserve human decisions.
- Confirm whether dashboard allowlisting should intentionally suppress identical `(client_id, file_path, detector, redacted)` matches across multiple repositories or platforms; the current table key does not include either.
- Agree on versioned Go API response shapes, paging limits, legacy timestamp handling and whether the tab needs a deep-scan trigger.

**Implementation approach:** add a flat `secscan` package under each existing models/repository/services/handlers layer; keep the backend's **one main** and **one router**, and do not alter A1–A9 or legacy APIs. Validate against disposable PostgreSQL fixtures—not the live `nhi_db`. The detailed design and exception matrix are in [Secret-scanner API analysis and plan](SECSCAN_API_ANALYSIS_AND_PLAN.md).
