> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and [current source files](CREDENTIAL_DASHBOARD_UPDATED_CODE.md). #7 still requires approved hygiene rules.

> **Current integration note:** Inventory A1–A6 are also registered in this main/router. Their full code is in [A1_A6_COMPLETE_CODE.md](A1_A6_COMPLETE_CODE.md).

# APIs #6/#7 — complete code for the existing backend

**Partial implementation:** the credential table does not exist. Authenticated/authorized #6/#7 requests currently return `503 DATA_SOURCE_UNAVAILABLE`; the PDF success models below are for a future complete source. Never represent unavailable credentials as zero. See [the readiness and metric checklist](API_6_7_CREDENTIALS_PENDING_SOURCE.md).

Paste/merge the eight `credentials_*.go` files into the four existing **flat** dashboard layer directories. Also merge the shared auth/status validation update in the existing `identities_by_class.go`, and the wiring/route changes in the **single existing** `main.go` and `routes.go` (also carrying APIs #1/#2). Source sections are verbatim, complete files from the compile-tested project. Preserve unrelated local modifications.

## `internal/models/dashboard/credentials_by_type.go`

```go
package dashboard

import "errors"

// ErrCredentialSourceUnavailable means no approved, complete credential
// inventory exists. It must never be translated into a measured zero.
var ErrCredentialSourceUnavailable = errors.New("dashboard credential inventory is not configured")

// CredentialTypeFilter carries the PDF #6 filters and the trusted account
// scope resolved from the authenticated request, never from the URL alone.
type CredentialTypeFilter struct {
	AccountID         string
	Region            string
	Status            string
	AllowedAccountIDs []string
}

type CredentialTypeCount struct {
	CredentialType string `json:"credential_type"`
	Count          int64  `json:"count"`
}

type CredentialsByTypeResponse struct {
	Total     int64                 `json:"total"`
	Breakdown []CredentialTypeCount `json:"breakdown"`
}
```

## `internal/models/dashboard/credentials_hygiene.go`

```go
package dashboard

// CredentialHygieneFilter uses the same trusted account scope as PDF #6.
type CredentialHygieneFilter struct {
	AccountID         string
	AllowedAccountIDs []string
}

type CredentialHygieneGroup struct {
	Total  int64                 `json:"total"`
	ByType []CredentialTypeCount `json:"by_type"`
}

type HighPrivilegeRoles struct {
	Total           int64 `json:"total"`
	AdminAccess     int64 `json:"admin_access"`
	WildcardActions int64 `json:"wildcard_actions"`
}

// CredentialHygieneResponse is the PDF #7 shape. An instance is returned
// ONLY when every metric is backed by an approved source. Until then the
// repository returns ErrCredentialSourceUnavailable and HTTP 503.
type CredentialHygieneResponse struct {
	ExpiringWithin30d       CredentialHygieneGroup `json:"expiring_within_30d"`
	AlreadyExpired          CredentialHygieneGroup `json:"already_expired"`
	StaleAccessKeys90d      int64                  `json:"stale_access_keys_90d"`
	NeverUsedAccessKeys     int64                  `json:"never_used_access_keys"`
	UnrotatedSecrets90d     int64                  `json:"unrotated_secrets_90d"`
	RotationDisabledSecrets int64                  `json:"rotation_disabled_secrets"`
	RootAccessKeysPresent   int64                  `json:"root_access_keys_present"`
	HighPrivilegeRoles      HighPrivilegeRoles     `json:"high_privilege_roles"`
	PublicTrustRoles        int64                  `json:"public_trust_roles"`
}
```

## `internal/repository/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"context"
	"database/sql"

	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialRepository is deliberately separate from the legacy
// credential API and from the identity catalog. The credentials table has NOT
// been created; neither is an approved complete source for PDF APIs #6/#7.
type DashboardCredentialRepository struct{ db *sql.DB }

func NewDashboardCredentialRepository(db *sql.DB) *DashboardCredentialRepository {
	return &DashboardCredentialRepository{db: db}
}

// CredentialTypeCounts cannot query a nonexistent/unapproved credential
// inventory. Once the table is created, implement scoped grouped counts here
// using parameterized SQL and all three PDF filters. Do not use sample data.
func (r *DashboardCredentialRepository) CredentialTypeCounts(_ context.Context, _ m.CredentialTypeFilter) ([]m.CredentialTypeCount, error) {
	return nil, m.ErrCredentialSourceUnavailable
}
```

## `internal/repository/dashboard/credentials_hygiene.go`

```go
package dashboard

import (
	"context"

	m "nhi-backend-api/internal/models/dashboard"
)

// CredentialHygiene intentionally fails closed. The credential table and
// definitions of expiring, stale, never-used, unrotated, privilege, root and
// public trust have not been confirmed; the identity catalog alone cannot
// supply these counts. Implement only after the authoritative schema exists.
func (r *DashboardCredentialRepository) CredentialHygiene(_ context.Context, _ m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	return nil, m.ErrCredentialSourceUnavailable
}
```

## `internal/services/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"context"
	"errors"
	"fmt"
	"math"
	"strings"

	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialReader can be replaced when a complete credential table
// and the credential_type/status/region mappings have been confirmed.
type DashboardCredentialReader interface {
	CredentialTypeCounts(context.Context, m.CredentialTypeFilter) ([]m.CredentialTypeCount, error)
	CredentialHygiene(context.Context, m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error)
}

type DashboardCredentialService struct{ reader DashboardCredentialReader }

func NewDashboardCredentialService(reader DashboardCredentialReader) *DashboardCredentialService {
	return &DashboardCredentialService{reader: reader}
}

func credentialSourceError(err error) error {
	if errors.Is(err, m.ErrCredentialSourceUnavailable) {
		return ErrDashboardSourceUnavailable
	}
	return err
}

func (s *DashboardCredentialService) ByType(ctx context.Context, f m.CredentialTypeFilter) (*m.CredentialsByTypeResponse, error) {
	if s == nil || s.reader == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	counts, err := s.reader.CredentialTypeCounts(ctx, f)
	if err != nil {
		return nil, credentialSourceError(err)
	}
	if counts == nil { // nil,nil is NOT a proven empty inventory
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.CredentialsByTypeResponse{Breakdown: make([]m.CredentialTypeCount, 0, len(counts))}
	seen := make(map[string]bool, len(counts))
	for _, c := range counts {
		if strings.TrimSpace(c.CredentialType) == "" || seen[c.CredentialType] {
			return nil, fmt.Errorf("%w: invalid or duplicate credential type", ErrDashboardSourceIncomplete)
		}
		seen[c.CredentialType] = true
		if err := checkCount(c.Count, "credential"); err != nil {
			return nil, err
		}
		if c.Count > math.MaxInt64-out.Total {
			return nil, fmt.Errorf("%w: credential total overflow", ErrDashboardSourceIncomplete)
		}
		out.Total += c.Count
		out.Breakdown = append(out.Breakdown, c)
	}
	return out, nil
}
```

## `internal/services/dashboard/credentials_hygiene.go`

```go
package dashboard

import (
	"context"
	"fmt"
	"math"
	"strings"

	m "nhi-backend-api/internal/models/dashboard"
)

// Hygiene returns no JSON success until all PDF #7 cards have a complete,
// verified backing source. The current repository always reports unavailable.
func (s *DashboardCredentialService) Hygiene(ctx context.Context, f m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	if s == nil || s.reader == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	out, err := s.reader.CredentialHygiene(ctx, f)
	if err != nil {
		return nil, credentialSourceError(err)
	}
	if out == nil { // nil,nil is NOT evidence all hygiene cards are zero
		return nil, ErrDashboardSourceIncomplete
	}
	for _, metric := range []struct {
		name string
		n    int64
	}{
		{"stale_access_keys_90d", out.StaleAccessKeys90d},
		{"never_used_access_keys", out.NeverUsedAccessKeys},
		{"unrotated_secrets_90d", out.UnrotatedSecrets90d},
		{"rotation_disabled_secrets", out.RotationDisabledSecrets},
		{"root_access_keys_present", out.RootAccessKeysPresent},
		{"high_privilege_roles.total", out.HighPrivilegeRoles.Total},
		{"high_privilege_roles.admin_access", out.HighPrivilegeRoles.AdminAccess},
		{"high_privilege_roles.wildcard_actions", out.HighPrivilegeRoles.WildcardActions},
		{"public_trust_roles", out.PublicTrustRoles},
	} {
		if err := checkCount(metric.n, metric.name); err != nil {
			return nil, err
		}
	}
	for _, g := range []struct {
		name string
		data m.CredentialHygieneGroup
	}{
		{"expiring_within_30d", out.ExpiringWithin30d},
		{"already_expired", out.AlreadyExpired},
	} {
		if err := checkCount(g.data.Total, g.name); err != nil {
			return nil, err
		}
		if g.data.ByType == nil { // the complete source should use [] for no matches
			return nil, fmt.Errorf("%w: missing %s by_type", ErrDashboardSourceIncomplete, g.name)
		}
		var sum int64
		seen := make(map[string]bool, len(g.data.ByType))
		for _, c := range g.data.ByType {
			if strings.TrimSpace(c.CredentialType) == "" || seen[c.CredentialType] {
				return nil, fmt.Errorf("%w: invalid or duplicate %s type", ErrDashboardSourceIncomplete, g.name)
			}
			seen[c.CredentialType] = true
			if err := checkCount(c.Count, g.name); err != nil {
				return nil, err
			}
			if c.Count > math.MaxInt64-sum {
				return nil, fmt.Errorf("%w: %s count overflow", ErrDashboardSourceIncomplete, g.name)
			}
			sum += c.Count
		}
		if sum != g.data.Total {
			return nil, fmt.Errorf("%w: %s total does not match by_type", ErrDashboardSourceIncomplete, g.name)
		}
	}
	// admin_access and wildcard_actions may overlap: no arithmetic equality
	// is imposed on high_privilege_roles subcounts until rules are approved.
	return out, nil
}
```

## `internal/handlers/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
)

// DashboardCredentialHandler handles PDF APIs #6/#7, independent from the
// legacy /api/credentials route. It shares policy A's trusted account scope.
type DashboardCredentialHandler struct {
	service *s.DashboardCredentialService
	scope   DashboardAccountScope
}

func NewDashboardCredentialHandler(service *s.DashboardCredentialService, scope DashboardAccountScope) *DashboardCredentialHandler {
	return &DashboardCredentialHandler{service: service, scope: scope}
}

func (h *DashboardCredentialHandler) authorizedAccounts(w http.ResponseWriter, r *http.Request, accountID string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, accountID)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, accountID)
}

// ByType implements GET /api/v1/dashboard/credentials/by-type. While no
// canonical credential inventory exists, authorized requests return 503.
func (h *DashboardCredentialHandler) ByType(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region", "status")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid credential by-type filters")
		return
	}
	accounts, ok := h.authorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.ByType(r.Context(), m.CredentialTypeFilter{
		AccountID: params["account_id"], Region: params["region"], Status: params["status"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
```

## `internal/handlers/dashboard/credentials_hygiene.go`

```go
package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// Hygiene implements GET /api/v1/dashboard/credentials/hygiene. Incomplete
// hygiene cards must not be presented as measured zeros or sample results.
func (h *DashboardCredentialHandler) Hygiene(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid credential hygiene filters")
		return
	}
	accounts, ok := h.authorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Hygiene(r.Context(), m.CredentialHygieneFilter{
		AccountID: params["account_id"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
```

## `internal/handlers/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/url"
	"nhi-backend-api/internal/middleware"
	identitymodels "nhi-backend-api/internal/models/dashboard"
	identityservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
	"regexp"
)

// DashboardAccountScope must resolve permitted AWS account IDs from a trusted
// server-side policy. The existing JWT does NOT contain an account allowlist.
// Do not supply a default "all accounts" implementation without authorization.
type DashboardAccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}

type DashboardBreakdownHandler struct {
	service *identityservices.DashboardBreakdownService
	scope   DashboardAccountScope
}

func NewDashboard345Handler(service *identityservices.DashboardBreakdownService, scope DashboardAccountScope) *DashboardBreakdownHandler {
	return &DashboardBreakdownHandler{service: service, scope: scope}
}

// DashboardAccountIDReader is the trusted server-side list of AWS accounts.
// Do not populate it from a request parameter or from an unverified JWT claim.
type DashboardAccountIDReader interface {
	AllKnownAccountIDs(context.Context) ([]string, error)
}

// DashboardAllAccountsScope implements the explicitly approved policy A:
// every authenticated dashboard user may read all known AWS accounts.
// Revisit this policy before introducing per-user or per-team restrictions.
type DashboardAllAccountsScope struct{ reader DashboardAccountIDReader }

func NewDashboardAllAccountsScope(reader DashboardAccountIDReader) *DashboardAllAccountsScope {
	return &DashboardAllAccountsScope{reader: reader}
}

func (s *DashboardAllAccountsScope) AllowedAccountIDs(ctx context.Context, claims *appjwt.CustomClaims) ([]string, error) {
	if s == nil || s.reader == nil || claims == nil || claims.UserID <= 0 {
		return nil, errors.New("authenticated dashboard account scope unavailable")
	}
	return s.reader.AllKnownAccountIDs(ctx)
}

var (
	accountIDPattern        = regexp.MustCompile(`^[0-9]{12}$`)
	regionPattern           = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
	identityTypePattern     = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
	credentialStatusPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,63}$`)
)

type dashboardError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func dashboardWriteError(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	var payload dashboardError
	payload.Error.Code, payload.Error.Message = code, message
	_ = json.NewEncoder(w).Encode(payload)
}

func dashboardWriteOK(w http.ResponseWriter, result interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(result) // raw PDF response, no legacy wrapper
}

func dashboardParams(r *http.Request, allowed ...string) (map[string]string, bool) {
	params, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allowedSet := make(map[string]bool, len(allowed))
	for _, key := range allowed {
		allowedSet[key] = true
	}
	result := make(map[string]string, len(params))
	for key, vals := range params {
		if !allowedSet[key] || len(vals) != 1 {
			return nil, false
		}
		result[key] = vals[0]
	}
	if s := result["account_id"]; s != "" && !accountIDPattern.MatchString(s) {
		return nil, false
	}
	if s := result["region"]; s != "" && !regionPattern.MatchString(s) {
		return nil, false
	}
	if s := result["identity_type"]; s != "" && !identityTypePattern.MatchString(s) {
		return nil, false
	}
	if s := result["status"]; s != "" && !credentialStatusPattern.MatchString(s) {
		return nil, false
	}
	return result, true
}

// dashboardAuthorizedAccounts returns an explicit server-side account scope.
// No URL-supplied account ID can expand it. These checks remain even if the
// integrator temporarily mis-mounts the route outside the JWT middleware.
func (h *DashboardBreakdownHandler) dashboardAuthorizedAccounts(w http.ResponseWriter, r *http.Request, requestedAccount string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, requestedAccount)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, requestedAccount)
}

// Shared policy check for identity and credential dashboard endpoints.
// A configured service is required before any query; no caller can replace
// the server-resolved scope with an account_id taken from the query string.
func dashboardAuthorizedAccountsFor(w http.ResponseWriter, r *http.Request, scope DashboardAccountScope, serviceConfigured bool, requestedAccount string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		dashboardWriteError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if scope == nil || !serviceConfigured {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	// An invalid policy result is an integration error, never an expanded scope.
	for _, id := range ids {
		if !accountIDPattern.MatchString(id) {
			dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
	}
	if requestedAccount != "" {
		found := false
		for _, id := range ids {
			if id == requestedAccount {
				found = true
				break
			}
		}
		if !found {
			dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "AWS account is not authorized")
			return nil, false
		}
	}
	return ids, true
}

func dashboardServiceError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, identityservices.ErrDashboardSourceUnavailable), errors.Is(err, identityservices.ErrDashboardSourceIncomplete):
		dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
	default:
		dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load dashboard data")
	}
}

// ByClass implements GET /api/v1/dashboard/identities/by-class.
func (h *DashboardBreakdownHandler) ByClass(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-class filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.ByClass(r.Context(), identitymodels.ClassFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
```

## `cmd/api-server/main.go`

```go
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	dashservices "nhi-backend-api/internal/services/dashboard"
	inventoryservices "nhi-backend-api/internal/services/inventory"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize PostgreSQL Database
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// Dashboard APIs #1–#8 share approved policy A: every JWT-authenticated
	// dashboard user may see all known AWS accounts. The resolver reads the
	// catalog and scan targets; URL parameters NEVER supply the scope.
	// #1 has explicit nulls for unavailable cards; #4/#5 credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	dashboard345Repo := dashrepo.NewDashboardBreakdownRepository(db.DB)
	dashboard345Scope := dashhandlers.NewDashboardAllAccountsScope(dashboard345Repo)
	dashboard345Service := dashservices.NewDashboardBreakdownService(dashboard345Repo)
	dashboard345Handler := dashhandlers.NewDashboard345Handler(dashboard345Service, dashboard345Scope)
	dashboardCredentialRepo := dashrepo.NewDashboardCredentialRepository(db.DB)
	dashboardCredentialService := dashservices.NewDashboardCredentialService(dashboardCredentialRepo)
	dashboardCredentialHandler := dashhandlers.NewDashboardCredentialHandler(dashboardCredentialService, dashboard345Scope)

	// Inventory A1–A6 uses the same approved JWT/account scope; all inventory
	// reads are constrained to current identities in nhi_scanner.identities.
	inventoryRepository := inventoryrepo.NewRepository(db.DB)
	inventoryService := inventoryservices.NewService(inventoryRepository)
	inventoryHandler := inventoryhandlers.NewHandler(inventoryService, dashboard345Scope)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                authHandler,
		DashboardHandler:           dashboardHandler,
		Dashboard345Handler:        dashboard345Handler,
		DashboardCredentialHandler: dashboardCredentialHandler,
		InventoryHandler:           inventoryHandler,
		IdentityHandler:            identityHandler,
		SecretHandler:              secretHandler,
		ScanHandler:                scanHandler,
		AuthMiddleware:             authMiddleware,
		EventHandler:               eventHandler,
		LineageHandler:             lineageHandler,
		CredentialHandler:          credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
```

## `internal/routes/routes.go`

```go
// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 is a partial null-aware response; #4/#5 have credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. Until their
	// authoritative table and metric definitions exist, requests fail as 503.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
```

## Tests

The full backend ZIP includes `internal/handlers/dashboard/credentials_67_test.go`, `internal/services/dashboard/credentials_67_test.go`, `internal/repository/dashboard/credentials_67_test.go`, and the updated `internal/routes/dashboard345_routes_test.go`. Run `go test ./... && go vet ./...` with Go 1.26.5. Do not run optional CREATE/TRUNCATE PostgreSQL fixtures except on a disposable `*_test` database.
