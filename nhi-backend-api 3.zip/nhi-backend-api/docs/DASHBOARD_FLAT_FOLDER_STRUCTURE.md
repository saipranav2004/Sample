# Final requested folder arrangement: one flat `dashboard` package per layer

This starter mirrors the PDF's **14 GET APIs as filenames, not nested folders**. The route paths still use `/api/v1/dashboard/...`; Go source remains flat in the following four directories:

```text
internal/handlers/dashboard/
internal/services/dashboard/
internal/repository/dashboard/
internal/models/dashboard/
```

**There are no `identities/`, `credentials/`, `by-type/`, or other API-specific subdirectories inside these folders.** Each of the four directories contains the 14 PDF endpoint-named `.go` files, plus any necessary package helper and test files. All files in a directory declare `package dashboard`. **Current update:** APIs #1–#8 are registered. #1 now includes measured credential facts with remaining unknown cards null; #2 returns real counts; #4/#5 have measured `credential_count`; #6 is live from `nhi_scanner.credentials`; #7 still returns **503** until hygiene classifications are confirmed; #8 returns `not_in_iac:null`. The other six endpoints remain placeholders. The existing PostgreSQL backend, central router/main, and legacy routes are intact.

| PDF # | GET route (prefix `/api/v1/dashboard`) | File in **each** dashboard layer directory |
|---:|---|---|
| 1 | `/summary` | `summary.go` |
| 2 | `/identities/by-type` | `identities_by_type.go` |
| 3 | `/identities/by-class` | `identities_by_class.go` |
| 4 | `/identities/by-account` | `identities_by_account.go` |
| 5 | `/identities/by-region` | `identities_by_region.go` |
| 6 | `/credentials/by-type` | `credentials_by_type.go` |
| 7 | `/credentials/hygiene` | `credentials_hygiene.go` |
| 8 | `/identities/exposure` | `identities_exposure.go` |
| 9 | `/scan-health` | `scan_health.go` |
| 10 | `/trends` | `trends.go` |
| 11 | `/recent-discoveries` | `recent_discoveries.go` |
| 12 | `/credentials/privilege-distribution` | `credentials_privilege_distribution.go` |
| 13 | `/ownership-coverage` | `ownership_coverage.go` |
| 14 | `/filters` | `filters.go` |

The endpoint-named files for **#1–#8** are in each of the four layers. Common types coordinate related identity and credential endpoints without introducing nested directories; use import aliases when multiple `dashboard` packages appear together. #1 is **partial** with measured credential cards and honest nulls; #6 reads the confirmed scanner table; #7 remains fail-closed pending approved risk rules.

Only the integrator updates `cmd/api-server/main.go`, `internal/routes/routes.go`, global auth/config and shared business contracts. Team members can own any number of the 14 endpoints; they edit only endpoint-named files across the four dashboard folders, with no whole-folder overwrite during handoff. The PDF is saved at `docs/source/dashboard-api-spec.pdf` in the full starter ZIP.

**Current data gaps:** `nhi_scanner.credentials` is now user-confirmed (31 columns); account-name source, scan-start/region evidence, IaC marker and credential hygiene rules remain unavailable. Policy A grants authenticated dashboard users visibility into all known AWS accounts; no JWT account mapping is presumed. #7 intentionally returns 503; #1/#8 preserve nulls. Avoid fake/sample counts. See [current credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md). See the current [integration status](../INTEGRATION_STATUS.md).
