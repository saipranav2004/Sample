# PDF API #8 — Exposure & Dormancy Summary

`GET /api/v1/dashboard/identities/exposure?account_id=<optional 12-digit AWS ID>` is registered in the **single existing** `internal/routes/routes.go`, inside the JWT-protected `/api` subrouter. It reuses the user-approved policy A account resolver from APIs 3–5: every authenticated dashboard user can see all known AWS account IDs. The only allowed query parameter is `account_id`; unauthorized account IDs return 403; missing JWT returns 401; malformed or unsupported filters return 400. The existing central `cmd/api-server/main.go` already constructs the required identity repository, service and handler, so **it does not need changing** for #8.

The confirmed UUID catalog `nhi_scanner.identities` supplies `account_id`, `identity_type`, `deleted_at`, `is_publicly_accessible`, `last_activity_at`, `owner`, and `environment`. This implementation counts only `deleted_at IS NULL` identities within the trusted account scope (and optional account_id). A single parameterized PostgreSQL conditional-aggregation query provides all database-backed metrics in one snapshot. Dormancy cutoff is UTC `now - 90 * 24h` captured once per request. Per-type arrays have only nonzero groups and are sorted count descending, then identity_type ascending; empty breakdowns are JSON `[]`.

| Response field | Proposed source/rule | Readiness |
|---|---|---|
| `publicly_accessible.total`, `.by_type` | `is_publicly_accessible IS TRUE`; NULL is not TRUE. | Directly computed from catalog. |
| `dormant_90d.total`, `.by_type` | `last_activity_at IS NOT NULL AND last_activity_at < cutoff`; NULL is NOT dormant. | Proposed rule; confirm with lead. |
| `no_activity_tracked` | `last_activity_at IS NULL`. | Proposed interpretation; NULL could also mean never active, confirm with lead. |
| `missing_owner_tag` | `owner IS NULL OR BTRIM(owner) = ''`. | **Provisional proxy:** confirm that `owner` is a normalized owner-tag field. This does not inspect `tags` JSONB directly. |
| `missing_environment_tag` | `environment IS NULL OR BTRIM(environment) = ''`. | **Provisional proxy:** confirm that `environment` is a normalized environment-tag field. This does not inspect `tags` JSONB directly. |
| `not_in_iac` | **No confirmed IaC marker or agreed mapping in the listed columns.** | JSON **null**, not made-up 0. Obtain authoritative column/JSON path and rule before enabling a numeric count. |

**Important:** This is a *partial PDF #8 response*. The PDF expects a numeric `not_in_iac`. Your frontend must display JSON `null` as “Not available,” or the team must instead keep API #8 unavailable until the IaC metric is specified. The PDF example numbers are not hard-coded. Do not infer IaC from `discovery_source` without a product-approved mapping.

## Files to paste over the previous full backend

```text
internal/models/dashboard/identities_exposure.go
internal/repository/dashboard/identities_exposure.go
internal/services/dashboard/identities_exposure.go
internal/handlers/dashboard/identities_exposure.go
internal/routes/routes.go              # add ONE GET registration under existing protected router
```

All four endpoint files reside **directly** in their layer's flat `dashboard/` directory. `docs/API_8_EXPOSURE_COPY_PASTE.md` has their complete contents and the exact route edit. If copying test files, include `internal/handlers/dashboard/identities_exposure_test.go`, `internal/services/dashboard/identities_exposure_test.go`, and the updated `internal/routes/dashboard345_routes_test.go`. The optional `internal/repository/dashboard/identities_345_integration_test.go` has a disposable fixture that tests the new SQL but CREATES/TRUNCATES tables: only use a *fresh isolated* database named `*_test`; NEVER run against `nhi_db` or a shared database.

Go 1.26.5: `go test ./...` and `go vet ./...` pass; the PostgreSQL integration fixture is skipped unless explicitly configured. Production catalog counts and tag semantics have **not** been verified against your live data. Only four extra endpoint files and one registration are required; no new main/router package or unapproved migrations.
