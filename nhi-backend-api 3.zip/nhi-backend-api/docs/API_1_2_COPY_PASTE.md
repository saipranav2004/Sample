> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and [current source files](CREDENTIAL_DASHBOARD_UPDATED_CODE.md). #7 still requires approved hygiene rules.

> **Current integration note:** Inventory A1–A6 are also registered in this main/router. Their full code is in [A1_A6_COMPLETE_CODE.md](A1_A6_COMPLETE_CODE.md).

# PDF APIs #1/#2 — complete current code

The PDF #1 success response is **partial by user choice**: unavailable credential cards, scanned-region coverage and scan duration serialize as JSON null (and region-filtered scan cards are null). API #2 returns real type-grouped current identity counts. Read [definitions and limitations](API_1_2_SUMMARY_AND_IDENTITY_TYPE.md) before using the response.

Paste/merge the eight endpoint files directly inside the four flat dashboard layer directories. **Also** merge the updated shared validation helper in `identities_by_class.go` and the two existing central `main.go` / `routes.go` files shown below. #1/#2 use the existing dashboard repository/service/handler wiring; the production `main.go` needs no new constructor. Preserve local integrator changes.

## `internal/models/dashboard/summary.go`

```go
package dashboard

import "time"

// SummaryFilter carries the two PDF filters and the trusted, authenticated
// account scope. AllowedAccountIDs must NEVER come from URL query parameters.
type SummaryFilter struct {
	AccountID         string
	Region            string
	AllowedAccountIDs []string
}

// SummaryIdentityRow is the repository's grouped identity status result.
// Deleted rows contribute only to Removed24h; current rows to other counts.
type SummaryIdentityRow struct {
	Status       string
	CurrentCount int64
	New24h       int64
	Removed24h   int64
}

// SummaryScanData holds measured scan fields at the account scope. No region
// or scan-start column was supplied in the scan table.
type SummaryScanData struct {
	CompletedAccountCount int64
	LastScanAt            *time.Time
	ScanStatus            *string
}

// SummaryResponse is a deliberately PARTIAL PDF #1 contract: null means not
// measurable from verified sources, never a measured zero. The frontend must
// treat null values as "Not available" (including all scan cards when region
// is specified, because scan records cannot be filtered by region).
type SummaryResponse struct {
	TotalIdentities          int64             `json:"total_identities"`
	TotalCredentials         *int64            `json:"total_credentials"`
	TotalAccountsScanned     *int64            `json:"total_accounts_scanned"`
	TotalRegionsScanned      *int64            `json:"total_regions_scanned"`
	IdentitiesByStatus       map[string]int64  `json:"identities_by_status"`
	CredentialsByStatus      *map[string]int64 `json:"credentials_by_status"`
	NewIdentitiesLast24h     int64             `json:"new_identities_last_24h"`
	RemovedIdentitiesLast24h int64             `json:"removed_identities_last_24h"`
	NewCredentialsLast24h    *int64            `json:"new_credentials_last_24h"`
	ExpiringCredentials30d   *int64            `json:"expiring_credentials_30d"`
	StaleCredentials90d      *int64            `json:"stale_credentials_90d"`
	UnrotatedCredentials     *int64            `json:"unrotated_credentials"`
	LastScanAt               *time.Time        `json:"last_scan_at"`
	ScanDurationSeconds      *int64            `json:"scan_duration_seconds"`
	ScanStatus               *string           `json:"scan_status"`
}
```

## `internal/models/dashboard/identities_by_type.go`

```go
package dashboard

// TypeFilter uses the trusted JWT-resolved AWS-account scope, not a client-
// provided list. All four PDF #2 query parameters are optional.
type TypeFilter struct {
	AccountID         string
	Region            string
	Status            string
	FunctionalClass   string
	AllowedAccountIDs []string
}

type IdentityTypeCount struct {
	IdentityType string `json:"identity_type"`
	Count        int64  `json:"count"`
}

type ByTypeResponse struct {
	Total     int64               `json:"total"`
	Breakdown []IdentityTypeCount `json:"breakdown"`
}
```

## `internal/repository/dashboard/summary.go`

```go
package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// SummaryIdentityCounts groups ALL scoped catalog rows by status. Deleted
// identities contribute only to the removal card; all other counts use
// deleted_at IS NULL. UTC bounds are passed once by the service.
func (r *DashboardBreakdownRepository) SummaryIdentityCounts(ctx context.Context, f m.SummaryFilter, start, now time.Time) ([]m.SummaryIdentityRow, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') AS identity_status,
               COUNT(*) FILTER (WHERE deleted_at IS NULL) AS current_count,
               COUNT(*) FILTER (WHERE deleted_at IS NULL AND first_seen_at >= $3::timestamptz
                                 AND first_seen_at <= $4::timestamptz) AS new_24h,
               COUNT(*) FILTER (WHERE deleted_at >= $3::timestamptz
                                 AND deleted_at <= $4::timestamptz) AS removed_24h
        FROM nhi_scanner.identities
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($5::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $5::text)
        GROUP BY 1
        ORDER BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, start.UTC(), now.UTC(), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query dashboard summary identities: %w", err)
	}
	defer rows.Close()
	out := make([]m.SummaryIdentityRow, 0)
	for rows.Next() {
		var c m.SummaryIdentityRow
		if err := rows.Scan(&c.Status, &c.CurrentCount, &c.New24h, &c.Removed24h); err != nil {
			return nil, fmt.Errorf("scan dashboard summary identities: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate dashboard summary identities: %w", err)
	}
	return out, nil
}

// SummaryScanData reads real account-scoped scan facts. A completed scan
// counts toward total_accounts_scanned only if it has a scan_end. The most
// recently ended scan (of any status) supplies last_scan_at and scan_status.
// This method is never invoked with region set: scans have no region column.
func (r *DashboardBreakdownRepository) SummaryScanData(ctx context.Context, f m.SummaryFilter) (m.SummaryScanData, error) {
	var out m.SummaryScanData
	if len(f.AllowedAccountIDs) == 0 {
		return out, ErrEmptyAccountScope
	}
	if f.Region != "" {
		return out, fmt.Errorf("scan records do not support a region filter")
	}
	const totalSQL = `
        SELECT COUNT(DISTINCT account_id)
        FROM nhi_scanner.nhi_scans_aws
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND UPPER(BTRIM(status)) = 'COMPLETED'
          AND scan_end IS NOT NULL`
	if err := r.db.QueryRowContext(ctx, totalSQL, pq.Array(f.AllowedAccountIDs), f.AccountID).Scan(&out.CompletedAccountCount); err != nil {
		return out, fmt.Errorf("query completed scanned accounts: %w", err)
	}
	const latestSQL = `
        SELECT scan_end, status
        FROM nhi_scanner.nhi_scans_aws
        WHERE account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND scan_end IS NOT NULL
        ORDER BY scan_end DESC, id DESC LIMIT 1`
	var ended time.Time
	var status sql.NullString
	if err := r.db.QueryRowContext(ctx, latestSQL, pq.Array(f.AllowedAccountIDs), f.AccountID).Scan(&ended, &status); err != nil {
		if err == sql.ErrNoRows {
			return out, nil
		}
		return out, fmt.Errorf("query latest ended scan: %w", err)
	}
	ended = ended.UTC()
	out.LastScanAt = &ended
	if status.Valid && status.String != "" {
		out.ScanStatus = &status.String
	}
	return out, nil
}
```

## `internal/repository/dashboard/identities_by_type.go`

```go
package dashboard

import (
	"context"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// ByType reads current UUID-keyed catalog identities, not the legacy scanner
// snapshot. Every query is constrained by trusted AllowedAccountIDs.
func (r *DashboardBreakdownRepository) ByType(ctx context.Context, f m.TypeFilter) ([]m.IdentityTypeCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(BTRIM(identity_type), ''), 'unknown') AS identity_type,
               COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
          AND ($4::text = '' OR COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') = $4::text)
          AND ($5::text = '' OR COALESCE(NULLIF(BTRIM(functional_class), ''), 'unclassified') = $5::text)
        GROUP BY 1
        ORDER BY identity_count DESC, identity_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.Status, f.FunctionalClass)
	if err != nil {
		return nil, fmt.Errorf("query identities by type: %w", err)
	}
	defer rows.Close()
	out := make([]m.IdentityTypeCount, 0)
	for rows.Next() {
		var c m.IdentityTypeCount
		if err := rows.Scan(&c.IdentityType, &c.Count); err != nil {
			return nil, fmt.Errorf("scan identities by type: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identities by type: %w", err)
	}
	return out, nil
}
```

## `internal/services/dashboard/summary.go`

```go
package dashboard

import (
	"context"
	"math"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type dashboardSummaryReader interface {
	SummaryIdentityCounts(context.Context, m.SummaryFilter, time.Time, time.Time) ([]m.SummaryIdentityRow, error)
	SummaryScanData(context.Context, m.SummaryFilter) (m.SummaryScanData, error)
}

// Summary returns a PARTIAL PDF #1 response, as approved by the user. No
// credential fields are guessed; scan duration/region coverage cannot be
// measured from the confirmed scan table. Region-scoped scan cards are null.
func (s *DashboardBreakdownService) Summary(ctx context.Context, f m.SummaryFilter) (*m.SummaryResponse, error) {
	if s == nil || s.identities == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	reader, ok := s.identities.(dashboardSummaryReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	now := time.Now().UTC()
	rows, err := reader.SummaryIdentityCounts(ctx, f, now.Add(-24*time.Hour), now)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.SummaryResponse{IdentitiesByStatus: make(map[string]int64)}
	seen := make(map[string]bool, len(rows))
	for _, row := range rows {
		if row.Status == "" || seen[row.Status] {
			return nil, ErrDashboardSourceIncomplete
		}
		seen[row.Status] = true
		for _, count := range []int64{row.CurrentCount, row.New24h, row.Removed24h} {
			if err := checkCount(count, "summary identity"); err != nil {
				return nil, err
			}
		}
		if row.CurrentCount > math.MaxInt64-out.TotalIdentities ||
			row.New24h > math.MaxInt64-out.NewIdentitiesLast24h ||
			row.Removed24h > math.MaxInt64-out.RemovedIdentitiesLast24h {
			return nil, ErrDashboardSourceIncomplete
		}
		out.TotalIdentities += row.CurrentCount
		out.NewIdentitiesLast24h += row.New24h
		out.RemovedIdentitiesLast24h += row.Removed24h
		if row.CurrentCount > 0 {
			out.IdentitiesByStatus[row.Status] = row.CurrentCount
		}
	}
	if f.Region == "" {
		scan, err := reader.SummaryScanData(ctx, f)
		if err != nil {
			return nil, err
		}
		if err := checkCount(scan.CompletedAccountCount, "completed scanned accounts"); err != nil {
			return nil, err
		}
		out.TotalAccountsScanned = &scan.CompletedAccountCount // 0 only if query measured zero
		out.LastScanAt = scan.LastScanAt
		out.ScanStatus = scan.ScanStatus
	}
	// The confirmed schema has no complete credentials inventory, scan-start
	// timestamp or scan-region coverage. All corresponding pointer fields stay
	// nil so JSON explicitly includes null, not fabricated 0 / empty string.
	return out, nil
}
```

## `internal/services/dashboard/identities_by_type.go`

```go
package dashboard

import (
	"context"
	"math"

	m "nhi-backend-api/internal/models/dashboard"
)

// Keep APIs #3–#5 compatible with existing reader fakes: only the production
// identity repository needs to implement the additional PDF #2 method.
type dashboardTypeReader interface {
	ByType(context.Context, m.TypeFilter) ([]m.IdentityTypeCount, error)
}

func (s *DashboardBreakdownService) ByType(ctx context.Context, f m.TypeFilter) (*m.ByTypeResponse, error) {
	if s == nil || s.identities == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	reader, ok := s.identities.(dashboardTypeReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	groups, err := reader.ByType(ctx, f)
	if err != nil {
		return nil, err
	}
	if groups == nil { // nil,nil from an unfinished adapter is not zero identities
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.ByTypeResponse{Breakdown: make([]m.IdentityTypeCount, 0, len(groups))}
	seen := make(map[string]bool, len(groups))
	for _, group := range groups {
		if group.IdentityType == "" || seen[group.IdentityType] {
			return nil, ErrDashboardSourceIncomplete
		}
		seen[group.IdentityType] = true
		if err := checkCount(group.Count, "identity type"); err != nil {
			return nil, err
		}
		if group.Count > math.MaxInt64-out.Total {
			return nil, ErrDashboardSourceIncomplete
		}
		out.Total += group.Count
		out.Breakdown = append(out.Breakdown, group)
	}
	return out, nil
}
```

## `internal/handlers/dashboard/summary.go`

```go
package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// Summary implements GET /api/v1/dashboard/summary (partial 200 contract).
// Legacy GET /api/dashboard/summary remains a separate existing route.
func (h *DashboardBreakdownHandler) Summary(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid summary filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Summary(r.Context(), m.SummaryFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
```

## `internal/handlers/dashboard/identities_by_type.go`

```go
package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
)

// ByType implements GET /api/v1/dashboard/identities/by-type.
func (h *DashboardBreakdownHandler) ByType(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region", "status", "functional_class")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid identity by-type filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.ByType(r.Context(), m.TypeFilter{
		AccountID: params["account_id"], Region: params["region"], Status: params["status"],
		FunctionalClass: params["functional_class"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
```

## `internal/handlers/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/url"
	"nhi-backend-api/internal/middleware"
	identitymodels "nhi-backend-api/internal/models/dashboard"
	identityservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
	"regexp"
)

// DashboardAccountScope must resolve permitted AWS account IDs from a trusted
// server-side policy. The existing JWT does NOT contain an account allowlist.
// Do not supply a default "all accounts" implementation without authorization.
type DashboardAccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}

type DashboardBreakdownHandler struct {
	service *identityservices.DashboardBreakdownService
	scope   DashboardAccountScope
}

func NewDashboard345Handler(service *identityservices.DashboardBreakdownService, scope DashboardAccountScope) *DashboardBreakdownHandler {
	return &DashboardBreakdownHandler{service: service, scope: scope}
}

// DashboardAccountIDReader is the trusted server-side list of AWS accounts.
// Do not populate it from a request parameter or from an unverified JWT claim.
type DashboardAccountIDReader interface {
	AllKnownAccountIDs(context.Context) ([]string, error)
}

// DashboardAllAccountsScope implements the explicitly approved policy A:
// every authenticated dashboard user may read all known AWS accounts.
// Revisit this policy before introducing per-user or per-team restrictions.
type DashboardAllAccountsScope struct{ reader DashboardAccountIDReader }

func NewDashboardAllAccountsScope(reader DashboardAccountIDReader) *DashboardAllAccountsScope {
	return &DashboardAllAccountsScope{reader: reader}
}

func (s *DashboardAllAccountsScope) AllowedAccountIDs(ctx context.Context, claims *appjwt.CustomClaims) ([]string, error) {
	if s == nil || s.reader == nil || claims == nil || claims.UserID <= 0 {
		return nil, errors.New("authenticated dashboard account scope unavailable")
	}
	return s.reader.AllKnownAccountIDs(ctx)
}

var (
	accountIDPattern        = regexp.MustCompile(`^[0-9]{12}$`)
	regionPattern           = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
	identityTypePattern     = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
	credentialStatusPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,63}$`)
	functionalClassPattern  = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
)

type dashboardError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func dashboardWriteError(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	var payload dashboardError
	payload.Error.Code, payload.Error.Message = code, message
	_ = json.NewEncoder(w).Encode(payload)
}

func dashboardWriteOK(w http.ResponseWriter, result interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(result) // raw PDF response, no legacy wrapper
}

func dashboardParams(r *http.Request, allowed ...string) (map[string]string, bool) {
	params, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allowedSet := make(map[string]bool, len(allowed))
	for _, key := range allowed {
		allowedSet[key] = true
	}
	result := make(map[string]string, len(params))
	for key, vals := range params {
		if !allowedSet[key] || len(vals) != 1 {
			return nil, false
		}
		result[key] = vals[0]
	}
	if s := result["account_id"]; s != "" && !accountIDPattern.MatchString(s) {
		return nil, false
	}
	if s := result["region"]; s != "" && !regionPattern.MatchString(s) {
		return nil, false
	}
	if s := result["identity_type"]; s != "" && !identityTypePattern.MatchString(s) {
		return nil, false
	}
	if s := result["status"]; s != "" && !credentialStatusPattern.MatchString(s) {
		return nil, false
	}
	if s := result["functional_class"]; s != "" && !functionalClassPattern.MatchString(s) {
		return nil, false
	}
	return result, true
}

// dashboardAuthorizedAccounts returns an explicit server-side account scope.
// No URL-supplied account ID can expand it. These checks remain even if the
// integrator temporarily mis-mounts the route outside the JWT middleware.
func (h *DashboardBreakdownHandler) dashboardAuthorizedAccounts(w http.ResponseWriter, r *http.Request, requestedAccount string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, requestedAccount)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, requestedAccount)
}

// Shared policy check for identity and credential dashboard endpoints.
// A configured service is required before any query; no caller can replace
// the server-resolved scope with an account_id taken from the query string.
func dashboardAuthorizedAccountsFor(w http.ResponseWriter, r *http.Request, scope DashboardAccountScope, serviceConfigured bool, requestedAccount string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		dashboardWriteError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if scope == nil || !serviceConfigured {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	// An invalid policy result is an integration error, never an expanded scope.
	for _, id := range ids {
		if !accountIDPattern.MatchString(id) {
			dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
	}
	if requestedAccount != "" {
		found := false
		for _, id := range ids {
			if id == requestedAccount {
				found = true
				break
			}
		}
		if !found {
			dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "AWS account is not authorized")
			return nil, false
		}
	}
	return ids, true
}

func dashboardServiceError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, identityservices.ErrDashboardSourceUnavailable), errors.Is(err, identityservices.ErrDashboardSourceIncomplete):
		dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
	default:
		dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load dashboard data")
	}
}

// ByClass implements GET /api/v1/dashboard/identities/by-class.
func (h *DashboardBreakdownHandler) ByClass(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-class filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.ByClass(r.Context(), identitymodels.ClassFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
```

## `cmd/api-server/main.go`

```go
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	dashservices "nhi-backend-api/internal/services/dashboard"
	inventoryservices "nhi-backend-api/internal/services/inventory"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize PostgreSQL Database
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// Dashboard APIs #1–#8 share approved policy A: every JWT-authenticated
	// dashboard user may see all known AWS accounts. The resolver reads the
	// catalog and scan targets; URL parameters NEVER supply the scope.
	// #1 has explicit nulls for unavailable cards; #4/#5 credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	dashboard345Repo := dashrepo.NewDashboardBreakdownRepository(db.DB)
	dashboard345Scope := dashhandlers.NewDashboardAllAccountsScope(dashboard345Repo)
	dashboard345Service := dashservices.NewDashboardBreakdownService(dashboard345Repo)
	dashboard345Handler := dashhandlers.NewDashboard345Handler(dashboard345Service, dashboard345Scope)
	dashboardCredentialRepo := dashrepo.NewDashboardCredentialRepository(db.DB)
	dashboardCredentialService := dashservices.NewDashboardCredentialService(dashboardCredentialRepo)
	dashboardCredentialHandler := dashhandlers.NewDashboardCredentialHandler(dashboardCredentialService, dashboard345Scope)

	// Inventory A1–A6 uses the same approved JWT/account scope; all inventory
	// reads are constrained to current identities in nhi_scanner.identities.
	inventoryRepository := inventoryrepo.NewRepository(db.DB)
	inventoryService := inventoryservices.NewService(inventoryRepository)
	inventoryHandler := inventoryhandlers.NewHandler(inventoryService, dashboard345Scope)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                authHandler,
		DashboardHandler:           dashboardHandler,
		Dashboard345Handler:        dashboard345Handler,
		DashboardCredentialHandler: dashboardCredentialHandler,
		InventoryHandler:           inventoryHandler,
		IdentityHandler:            identityHandler,
		SecretHandler:              secretHandler,
		ScanHandler:                scanHandler,
		AuthMiddleware:             authMiddleware,
		EventHandler:               eventHandler,
		LineageHandler:             lineageHandler,
		CredentialHandler:          credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
```

## `internal/routes/routes.go`

```go
// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 is a partial null-aware response; #4/#5 have credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. Until their
	// authoritative table and metric definitions exist, requests fail as 503.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
```

## Tests

The full backend project includes handler/service/route tests and an optional updated PostgreSQL fixture. Run `go test ./... && go vet ./...` (Go 1.26.5). The PostgreSQL fixture CREATES/TRUNCATES tables: **NEVER** run it against a live/shared DB; only on a disposable `*_test` database.
