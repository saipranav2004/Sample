> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and [current source files](CREDENTIAL_DASHBOARD_UPDATED_CODE.md). #7 still requires approved hygiene rules.

> **ARCHIVED (not the current #4/#5 response):** This file predates the requested explicit `credential_count:null` and API #8. Do not copy these models or central files over the current backend. See [INTEGRATION_STATUS.md](../INTEGRATION_STATUS.md) and [API #8 source](API_8_EXPOSURE_COPY_PASTE.md) for the up-to-date tree.

# API 4/5 identity-only interim — complete six files to replace

Use these complete files **together** over the previous Option-A, correct-schema full backend. The lead advised leaving out `account_name` and the credentials table does not yet exist, so APIs #4/#5 now return account/region identity counts only. Unknown fields are **omitted**, never set to zero. The existing repository queries, HTTP handlers, and single `internal/routes/routes.go` remain unchanged. The responses for #4/#5 intentionally differ from the PDF. Run `go test ./...` and `go vet ./...` after replacing.


## `internal/models/dashboard/identities_by_account.go`

```go
package dashboard

// AccountFilter is scoped to authenticated AWS accounts and supports the
// optional filters in PDF API #4.
type AccountFilter struct {
	Region            string
	IdentityType      string
	AllowedAccountIDs []string
}

type AccountIdentityCount struct {
	AccountID     string
	IdentityCount int64
}

// AccountBreakdown is the lead-approved IDENTITY-ONLY interim contract.
// account_name and credential_count are intentionally absent, not zero.
type AccountBreakdown struct {
	AccountID     string `json:"account_id"`
	IdentityCount int64  `json:"identity_count"`
}

type ByAccountResponse struct {
	TotalAccounts int                `json:"total_accounts"`
	Breakdown     []AccountBreakdown `json:"breakdown"`
}
```


## `internal/models/dashboard/identities_by_region.go`

```go
package dashboard

// RegionFilter is scoped to authenticated AWS accounts and supports the
// optional filters in PDF API #5.
type RegionFilter struct {
	AccountID         string
	IdentityType      string
	AllowedAccountIDs []string
}

type RegionIdentityCount struct {
	Region        string
	IdentityCount int64
}

// RegionBreakdown is the lead-approved IDENTITY-ONLY interim contract.
// credential_count is intentionally absent, not zero.
type RegionBreakdown struct {
	Region        string `json:"region"`
	IdentityCount int64  `json:"identity_count"`
}

type ByRegionResponse struct {
	TotalRegions int               `json:"total_regions"`
	Breakdown    []RegionBreakdown `json:"breakdown"`
}
```


## `internal/services/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"errors"
	"fmt"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

var (
	// A required, approved backing source has not yet been provided.
	ErrDashboardSourceUnavailable = errors.New("dashboard source unavailable")
	// The configured source did not provide a value for every returned group.
	ErrDashboardSourceIncomplete = errors.New("dashboard source incomplete")
)

// Dashboard345IdentityReader reads catalog counts from nhi_scanner.identities.
// The repository must enforce AllowedAccountIDs for every query.
type Dashboard345IdentityReader interface {
	ByClass(context.Context, identitymodels.ClassFilter) ([]identitymodels.FunctionalClassCount, error)
	ByAccountIdentityCounts(context.Context, identitymodels.AccountFilter) ([]identitymodels.AccountIdentityCount, error)
	ByRegionIdentityCounts(context.Context, identitymodels.RegionFilter) ([]identitymodels.RegionIdentityCount, error)
}

type DashboardBreakdownService struct{ identities Dashboard345IdentityReader }

func NewDashboardBreakdownService(ids Dashboard345IdentityReader) *DashboardBreakdownService {
	return &DashboardBreakdownService{identities: ids}
}

func requireScope(ids []string) error {
	if len(ids) == 0 {
		return ErrDashboardSourceUnavailable
	}
	return nil
}

func checkCount(n int64, label string) error {
	if n < 0 {
		return fmt.Errorf("%w: negative %s count", ErrDashboardSourceIncomplete, label)
	}
	return nil
}

func (s *DashboardBreakdownService) ByClass(ctx context.Context, f identitymodels.ClassFilter) (*identitymodels.ByClassResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByClass(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByClassResponse{Breakdown: make([]identitymodels.FunctionalClassCount, 0, len(groups))}
	for _, group := range groups {
		if err := checkCount(group.Count, "identity"); err != nil {
			return nil, err
		}
		out.Total += group.Count
		out.Breakdown = append(out.Breakdown, group)
	}
	return out, nil
}
```


## `internal/services/dashboard/identities_by_account.go`

```go
package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByAccount returns the lead-approved interim identity-only breakdown.
// No account name or credential count is inferred from identity rows.
func (s *DashboardBreakdownService) ByAccount(ctx context.Context, f identitymodels.AccountFilter) (*identitymodels.ByAccountResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByAccountIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByAccountResponse{Breakdown: make([]identitymodels.AccountBreakdown, 0, len(groups))}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		out.Breakdown = append(out.Breakdown, identitymodels.AccountBreakdown{
			AccountID: group.AccountID, IdentityCount: group.IdentityCount,
		})
	}
	out.TotalAccounts = len(out.Breakdown)
	return out, nil
}
```


## `internal/services/dashboard/identities_by_region.go`

```go
package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByRegion returns the lead-approved interim identity-only breakdown.
// No credential counts are inferred from identity rows.
func (s *DashboardBreakdownService) ByRegion(ctx context.Context, f identitymodels.RegionFilter) (*identitymodels.ByRegionResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByRegionIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByRegionResponse{Breakdown: make([]identitymodels.RegionBreakdown, 0, len(groups))}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		out.Breakdown = append(out.Breakdown, identitymodels.RegionBreakdown{
			Region: group.Region, IdentityCount: group.IdentityCount,
		})
	}
	out.TotalRegions = len(out.Breakdown)
	return out, nil
}
```


## `cmd/api-server/main.go`

```go
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	dashservices "nhi-backend-api/internal/services/dashboard"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize PostgreSQL Database
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// PDF APIs 3/4/5. Approved policy A: every authenticated dashboard user
	// can see all known AWS accounts. The resolver reads account IDs from the
	// catalog and scan targets; it never takes the scope from URL input.
	// Lead-approved interim contract: #4/#5 return identity counts only.
	// Account names and credential counts are omitted, not set to zero.
	dashboard345Repo := dashrepo.NewDashboardBreakdownRepository(db.DB)
	dashboard345Scope := dashhandlers.NewDashboardAllAccountsScope(dashboard345Repo)
	dashboard345Service := dashservices.NewDashboardBreakdownService(dashboard345Repo)
	dashboard345Handler := dashhandlers.NewDashboard345Handler(dashboard345Service, dashboard345Scope)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:         authHandler,
		DashboardHandler:    dashboardHandler,
		Dashboard345Handler: dashboard345Handler,
		IdentityHandler:     identityHandler,
		SecretHandler:       secretHandler,
		ScanHandler:         scanHandler,
		AuthMiddleware:      authMiddleware,
		EventHandler:        eventHandler,
		LineageHandler:      lineageHandler,
		CredentialHandler:   credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
```
