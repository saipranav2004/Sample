> **A7–A9 historical source guide:** Inventory code is still current, but the single main/router and dashboard credential wiring now reflect the confirmed credential table. For current integration files, use the [credential-backed update guide](CREDENTIAL_DASHBOARD_UPDATED_CODE.md) or the complete ZIP.

# A7–A9 — complete new and modified source files

Merge these into the existing A1–A6 backend. A7 and A8 are GET; A9 is a scoped PATCH approved for all authenticated users under policy A. **Never run integration fixtures on `nhi_db`**. Before deploying A9, check UPDATE privileges using [the read-only SQL](A9_UPDATE_PRIVILEGE_CHECK.sql), and confirm the scanner preserves metadata edits. See [contract and exceptions](A7_A9_INVENTORY_IMPLEMENTATION.md).

Twelve new endpoint files go directly in the four existing flat `inventory/` layer folders. The service/handler `identities_list.go` files below have the shared Reader/filter/error extensions; the **single existing** `internal/routes/routes.go` registers three new routes, putting static A7/A8 paths ahead of `{id}`. `cmd/api-server/main.go` is unchanged; do not add a second main or router.

## `internal/models/inventory/identities_dormant.go`

```go
package inventory

import "time"

// DormantFilter uses the trusted account scope and one UTC now per request.
type DormantFilter struct {
	Scope
	Days                    int64
	AccountID, IdentityType string
	Page, Limit             int64
}
type DormantItem struct {
	ID             string    `json:"id"`
	Name           string    `json:"name"`
	IdentityType   string    `json:"identity_type"`
	LastActivityAt time.Time `json:"last_activity_at"`
	DaysInactive   int64     `json:"days_inactive"`
	Owner          *string   `json:"owner"`
	Environment    *string   `json:"environment"`
}
type DormantResponse struct {
	ThresholdDays int64         `json:"threshold_days"`
	TotalDormant  int64         `json:"total_dormant"`
	Data          []DormantItem `json:"data"`
}
```

## `internal/models/inventory/identities_export.go`

```go
package inventory

import "errors"

var ErrExportTooLarge = errors.New("inventory export exceeds safe limit")

// ExportFilter accepts A1 selection/sort syntax, but exports ALL matches
// (not only one page), within repository row and byte limits.
type ExportFilter struct {
	ListFilter
	Format string
}
type ExportPayload struct {
	Body        []byte
	ContentType string
	Filename    string
}
```

## `internal/models/inventory/identities_update.go`

```go
package inventory

// UpdatePatch has pointers so an absent field is distinct from an actual
// update. Null/blank are rejected until a clearing contract is approved.
type UpdatePatch struct {
	FunctionalClass *string `json:"functional_class"`
	Owner           *string `json:"owner"`
	Environment     *string `json:"environment"`
}
type UpdateResponse struct {
	ID            string   `json:"id"`
	Message       string   `json:"message"`
	UpdatedFields []string `json:"updated_fields"`
}
```

## `internal/repository/inventory/identities_dormant.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

// Dormant returns current identities with a tracked activity timestamp strictly
// before now-days*24h. NULL activity is untracked, not proof of dormancy.
func (r *Repository) Dormant(ctx context.Context, f m.DormantFilter, now time.Time) (*m.DormantResponse, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	if f.Days < 1 || f.Days > 3650 || f.Page < 1 || f.Page > 1_000_000 || f.Limit < 1 || f.Limit > 200 {
		return nil, fmt.Errorf("invalid dormant bounds")
	}
	cutoff := now.UTC().Add(-time.Duration(f.Days) * 24 * time.Hour)
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin dormant snapshot: %w", err)
	}
	defer tx.Rollback()
	const where = ` FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text)
 AND ($3::text='' OR identity_type=$3::text)
 AND last_activity_at IS NOT NULL AND last_activity_at<$4::timestamptz`
	args := []any{pq.Array(f.AllowedAccountIDs), f.AccountID, f.IdentityType, cutoff}
	out := &m.DormantResponse{ThresholdDays: f.Days, Data: []m.DormantItem{}}
	if err := tx.QueryRowContext(ctx, "SELECT COUNT(*)"+where, args...).Scan(&out.TotalDormant); err != nil {
		return nil, fmt.Errorf("count dormant identities: %w", err)
	}
	query := `SELECT id,name,identity_type,last_activity_at,owner,environment` + where + ` ORDER BY last_activity_at ASC,id ASC LIMIT $5 OFFSET $6`
	rows, err := tx.QueryContext(ctx, query, append(args, f.Limit, (f.Page-1)*f.Limit)...)
	if err != nil {
		return nil, fmt.Errorf("page dormant identities: %w", err)
	}
	for rows.Next() {
		var x m.DormantItem
		var owner, environment sql.NullString
		if err := rows.Scan(&x.ID, &x.Name, &x.IdentityType, &x.LastActivityAt, &owner, &environment); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan dormant identity: %w", err)
		}
		x.Owner = str(owner)
		x.Environment = str(environment)
		out.Data = append(out.Data, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate dormant identities: %w", err)
	}
	if err := rows.Close(); err != nil {
		return nil, fmt.Errorf("close dormant rows: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit dormant snapshot: %w", err)
	}
	return out, nil
}
```

## `internal/repository/inventory/identities_export.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
)

var ErrExportTooLarge = m.ErrExportTooLarge

const MaxExportRows = 50000
const MaxExportBytes = 50 << 20

// ExportRows reads ALL filtered current identities (not just the selected A1
// page) up to a hard safety cap, including all actual database columns via
// to_jsonb(i). Only SQL allowlisted ordering and bound filters are used.
func (r *Repository) ExportRows(ctx context.Context, f m.ExportFilter) ([]json.RawMessage, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	col, ok := sortColumns[f.SortBy]
	if !ok || (f.SortOrder != "asc" && f.SortOrder != "desc") {
		return nil, fmt.Errorf("invalid export sort")
	}
	where, args := listWhere(f.ListFilter)
	order := col + " " + strings.ToUpper(f.SortOrder) + " NULLS LAST"
	if col != "id" {
		order += ", id ASC"
	}
	query := `SELECT to_jsonb(i) FROM nhi_scanner.identities AS i WHERE ` + where + ` ORDER BY ` + order + fmt.Sprintf(" LIMIT $%d", len(args)+1)
	rows, err := r.db.QueryContext(ctx, query, append(args, MaxExportRows+1)...)
	if err != nil {
		return nil, fmt.Errorf("query inventory export: %w", err)
	}
	defer rows.Close()
	result := make([]json.RawMessage, 0)
	totalBytes := 0
	for rows.Next() {
		var b []byte
		if err := rows.Scan(&b); err != nil {
			return nil, fmt.Errorf("scan inventory export: %w", err)
		}
		if len(result) >= MaxExportRows || len(b) > MaxExportBytes-totalBytes {
			return nil, ErrExportTooLarge
		}
		totalBytes += len(b)
		result = append(result, json.RawMessage(b))
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate inventory export: %w", err)
	}
	return result, nil
}
```

## `internal/repository/inventory/identities_update.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	"strings"
)

// Update changes only the three PDF-approved fields and updated_at. UUID,
// current-row rule and trusted account scope are checked in the UPDATE itself;
// a deleted, inaccessible or absent ID is indistinguishable (404).
func (r *Repository) Update(ctx context.Context, id string, ids []string, fields map[string]string) (string, error) {
	if err := scoped(ids); err != nil {
		return "", err
	}
	if r == nil || r.db == nil {
		return "", fmt.Errorf("inventory db unavailable")
	}
	args := []any{id, pq.Array(ids)}
	sets := make([]string, 0, 4)
	for _, column := range []string{"functional_class", "owner", "environment"} {
		if v, ok := fields[column]; ok {
			args = append(args, v)
			sets = append(sets, fmt.Sprintf("%s=$%d", column, len(args)))
		}
	}
	if len(sets) == 0 || len(sets) != len(fields) {
		return "", fmt.Errorf("invalid identity update fields")
	}
	sets = append(sets, "updated_at=now()")
	query := `UPDATE nhi_scanner.identities SET ` + strings.Join(sets, ",") + ` WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL RETURNING id::text`
	var result string
	if err := r.db.QueryRowContext(ctx, query, args...).Scan(&result); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return "", ErrNotFound
		}
		return "", fmt.Errorf("update scoped identity: %w", err)
	}
	return result, nil
}
```

## `internal/services/inventory/identities_dormant.go`

```go
package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

func (s *Service) Dormant(ctx context.Context, f m.DormantFilter) (*m.DormantResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.Days < 1 || f.Days > 3650 || f.Page < 1 || f.Page > 1_000_000 || f.Limit < 1 || f.Limit > 200 {
		return nil, ErrIncomplete
	}
	now := time.Now().UTC()
	out, err := s.reader.Dormant(ctx, f, now)
	if err != nil {
		return nil, err
	}
	if out == nil || out.Data == nil || out.ThresholdDays != f.Days || out.TotalDormant < 0 || int64(len(out.Data)) > f.Limit || int64(len(out.Data)) > out.TotalDormant {
		return nil, ErrIncomplete
	}
	for i := range out.Data {
		item := &out.Data[i]
		if item.ID == "" || item.IdentityType == "" || item.LastActivityAt.IsZero() || !item.LastActivityAt.Before(now.Add(-time.Duration(f.Days)*24*time.Hour)) {
			return nil, ErrIncomplete
		}
		item.DaysInactive = int64(now.Sub(item.LastActivityAt).Hours() / 24)
	}
	return out, nil
}
```

## `internal/services/inventory/identities_export.go`

```go
package inventory

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	m "nhi-backend-api/internal/models/inventory"
	"strings"
)

// Order mirrors the 28 columns confirmed by the user's live schema audit.
// A CSV JSONB cell is a compact JSON string; SQL NULL is an empty cell.
var exportColumns = []string{
	"id", "arn", "name", "identity_type", "functional_class", "account_id", "region", "status",
	"created_at_aws", "first_seen_at", "last_seen_at", "last_activity_at", "deleted_at",
	"vpc_id", "subnet_id", "security_group_ids", "is_publicly_accessible", "tags", "owner", "environment",
	"parent_arn", "cloudtrail_creator_arn", "discovery_source", "scan_id", "type_attributes", "raw_api_response",
	"created_at", "updated_at",
}

const maxExportBytes = 50 << 20

func (s *Service) Export(ctx context.Context, f m.ExportFilter) (*m.ExportPayload, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.Format != "csv" && f.Format != "json" {
		return nil, ErrIncomplete
	}
	rows, err := s.reader.ExportRows(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.ExportPayload{Filename: "identities-export." + f.Format}
	if f.Format == "json" {
		out.ContentType = "application/json; charset=utf-8"
		out.Body, err = json.Marshal(rows)
		if err != nil {
			return nil, ErrIncomplete
		}
		if len(out.Body)+1 > maxExportBytes {
			return nil, m.ErrExportTooLarge
		}
		out.Body = append(out.Body, '\n')
		return out, nil
	}
	var buf bytes.Buffer
	writer := csv.NewWriter(&buf)
	if err := writer.Write(exportColumns); err != nil {
		return nil, err
	}
	for _, record := range rows {
		var obj map[string]json.RawMessage
		if json.Unmarshal(record, &obj) != nil || obj == nil {
			return nil, ErrIncomplete
		}
		line := make([]string, 0, len(exportColumns))
		for _, col := range exportColumns {
			value, exists := obj[col]
			if !exists {
				return nil, ErrIncomplete
			}
			if len(value) == 0 || string(value) == "null" {
				line = append(line, "")
				continue
			}
			var v string
			if value[0] == '"' {
				if json.Unmarshal(value, &v) != nil {
					return nil, ErrIncomplete
				}
			} else {
				v = string(value)
			}
			// Prefix Excel/Sheets formula triggers, including whitespace-hidden ones.
			trimmed := strings.TrimLeft(v, " \t\r\n")
			if len(trimmed) > 0 && strings.ContainsRune("=+-@", rune(trimmed[0])) {
				v = "'" + v
			}
			line = append(line, v)
		}
		if err := writer.Write(line); err != nil {
			return nil, err
		}
		if buf.Len() > maxExportBytes {
			return nil, m.ErrExportTooLarge
		}
	}
	writer.Flush()
	if err := writer.Error(); err != nil {
		return nil, err
	}
	if buf.Len() > maxExportBytes {
		return nil, m.ErrExportTooLarge
	}
	out.ContentType = "text/csv; charset=utf-8"
	out.Body = buf.Bytes()
	return out, nil
}
```

## `internal/services/inventory/identities_update.go`

```go
package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"regexp"
	"strings"
)

var classPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,99}$`)

// Update changes only PDF-approved fields. Caller authorization is resolved
// before service invocation; the repository repeats the scope in UPDATE SQL.
func (s *Service) Update(ctx context.Context, id string, ids []string, patch m.UpdatePatch) (*m.UpdateResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	fields := make(map[string]string, 3)
	for _, p := range []struct {
		name  string
		value *string
	}{
		{"functional_class", patch.FunctionalClass}, {"owner", patch.Owner}, {"environment", patch.Environment},
	} {
		if p.value == nil {
			continue
		}
		value := strings.TrimSpace(*p.value)
		if value == "" || len(value) > 256 || strings.ContainsAny(value, "\x00\r\n") || p.name == "functional_class" && !classPattern.MatchString(value) {
			return nil, ErrIncomplete
		}
		fields[p.name] = value
	}
	if len(fields) == 0 {
		return nil, ErrIncomplete
	}
	returned, err := s.reader.Update(ctx, id, ids, fields)
	if err != nil {
		return nil, err
	}
	if !strings.EqualFold(returned, id) {
		return nil, ErrIncomplete
	}
	out := &m.UpdateResponse{ID: returned, Message: "Updated", UpdatedFields: []string{}}
	for _, name := range []string{"functional_class", "owner", "environment"} {
		if _, ok := fields[name]; ok {
			out.UpdatedFields = append(out.UpdatedFields, name)
		}
	}
	return out, nil
}
```

## `internal/handlers/inventory/identities_dormant.go`

```go
package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

// A7: days is required, strictly positive and bounded. NULL last activity is
// untracked (not dormant); the repository enforces current-only identity rows.
func (h *Handler) Dormant(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "days", "identity_type", "account_id", "page", "limit")
	if !ok || p["days"] == "" {
		writeError(w, 400, "INVALID_FILTER", "days is required")
		return
	}
	days, ok1 := parseBound(p["days"], 0, 3650)
	page, ok2 := parseBound(p["page"], 1, 1_000_000)
	limit, ok3 := parseBound(p["limit"], 50, 200)
	if !ok1 || !ok2 || !ok3 {
		writeError(w, 400, "INVALID_FILTER", "Invalid dormant pagination or days")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Dormant(r.Context(), m.DormantFilter{Scope: m.Scope{AllowedAccountIDs: ids}, Days: days, IdentityType: p["identity_type"], AccountID: p["account_id"], Page: page, Limit: limit})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_export.go`

```go
package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

// A8: export all matching current identities within safe resource limits.
// Format is explicit; A1 page/limit are parsed/validated but do not select
// just one page. Body is built before headers so failures never return a file.
func (h *Handler) Export(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "format", "page", "limit", "sort_by", "sort_order", "search", "identity_type", "functional_class", "account_id", "region", "status", "owner", "environment", "is_public", "last_active_before")
	if !ok || p["format"] != "csv" && p["format"] != "json" {
		writeError(w, 400, "INVALID_FILTER", "format must be csv or json")
		return
	}
	f, ok := parseListFilter(p)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid export filters")
		return
	}
	ids, ok := h.authorize(w, r, f.AccountID)
	if !ok {
		return
	}
	f.AllowedAccountIDs = ids
	out, err := h.service.Export(r.Context(), m.ExportFilter{ListFilter: f, Format: p["format"]})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	w.Header().Set("Content-Type", out.ContentType)
	w.Header().Set("Content-Disposition", `attachment; filename="`+out.Filename+`"`)
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(out.Body)
}
```

## `internal/handlers/inventory/identities_update.go`

```go
package inventory

import (
	"bytes"
	"encoding/json"
	"io"
	"mime"
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
	"regexp"
	"strings"
	"unicode/utf8"
)

const maxPatchBody = 8192

var patchClass = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,99}$`)

func readIdentityPatch(r *http.Request) (m.UpdatePatch, bool, int) {
	var out m.UpdatePatch
	media, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || media != "application/json" {
		return out, false, 415
	}
	data, err := io.ReadAll(io.LimitReader(r.Body, maxPatchBody+1))
	if err != nil {
		return out, false, 400
	}
	if len(data) > maxPatchBody {
		return out, false, 413
	}
	if !utf8.Valid(data) {
		return out, false, 400
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	start, err := decoder.Token()
	if err != nil || start != json.Delim('{') {
		return out, false, 400
	}
	seen := map[string]bool{}
	for decoder.More() {
		k, err := decoder.Token()
		if err != nil {
			return out, false, 400
		}
		key, ok := k.(string)
		if !ok || seen[key] || (key != "functional_class" && key != "owner" && key != "environment") {
			return out, false, 400
		}
		seen[key] = true
		var raw json.RawMessage
		if decoder.Decode(&raw) != nil || len(raw) == 0 || raw[0] != '"' {
			return out, false, 400
		}
		var value string
		if json.Unmarshal(raw, &value) != nil {
			return out, false, 400
		}
		value = strings.TrimSpace(value)
		if value == "" || len(value) > 256 || strings.ContainsAny(value, "\x00\r\n") || key == "functional_class" && !patchClass.MatchString(value) {
			return out, false, 400
		}
		switch key {
		case "functional_class":
			out.FunctionalClass = &value
		case "owner":
			out.Owner = &value
		case "environment":
			out.Environment = &value
		}
	}
	end, err := decoder.Token()
	if err != nil || end != json.Delim('}') || len(seen) == 0 {
		return out, false, 400
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		return out, false, 400
	}
	return out, true, 0
}

// A9: direct, scoped UPDATE of only the PDF-approved identity metadata.
// Account policy A explicitly includes writes per the user's approval.
func (h *Handler) Update(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected update filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	patch, ok, status := readIdentityPatch(r)
	if !ok {
		if status == 415 {
			writeError(w, status, "UNSUPPORTED_MEDIA_TYPE", "Content-Type must be application/json")
			return
		}
		if status == 413 {
			writeError(w, status, "BODY_TOO_LARGE", "Identity update body is too large")
			return
		}
		writeError(w, 400, "INVALID_BODY", "Update must contain nonempty approved string fields only")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Update(r.Context(), id, ids, patch)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/services/inventory/identities_list.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"nhi-backend-api/internal/models/inventory"
	"time"
)

var (
	ErrSourceUnavailable = errors.New("inventory source unavailable")
	ErrIncomplete        = errors.New("inventory source incomplete")
	ErrNotFound          = errors.New("identity not found")
)

type Reader interface {
	List(context.Context, inventory.ListFilter) (*inventory.ListResponse, error)
	Detail(context.Context, string, []string) (*inventory.DetailResponse, error)
	Counts(context.Context, inventory.CountsFilter) ([]inventory.CountRow, error)
	Attributes(context.Context, string, []string) (*inventory.AttributesResponse, error)
	Timeline(context.Context, string, []string) (*inventory.TimelineRecord, error)
	Grouped(context.Context, inventory.GroupFilter) ([]inventory.GroupRow, error)
	Dormant(context.Context, inventory.DormantFilter, time.Time) (*inventory.DormantResponse, error)
	ExportRows(context.Context, inventory.ExportFilter) ([]json.RawMessage, error)
	Update(context.Context, string, []string, map[string]string) (string, error)
}
type Service struct{ reader Reader }

func NewService(r Reader) *Service { return &Service{reader: r} }
func (s *Service) check(ids []string) error {
	if s == nil || s.reader == nil || len(ids) == 0 {
		return ErrSourceUnavailable
	}
	return nil
}
func (s *Service) List(ctx context.Context, f inventory.ListFilter) (*inventory.ListResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	result, err := s.reader.List(ctx, f)
	if err != nil {
		return nil, err
	}
	if result == nil || result.Data == nil || result.Total < 0 || result.Page != f.Page || result.Limit != f.Limit || int64(len(result.Data)) > f.Limit {
		return nil, ErrIncomplete
	}
	for _, item := range result.Data {
		if item.ID == "" || item.AccountID == "" || !jsonObjectOrNull(item.Tags) {
			return nil, ErrIncomplete
		}
	}
	return result, nil
}

// JSONB is syntactically valid in PostgreSQL, but a JSON scalar/array is not
// an ownership tags map or type-attributes object as required by the PDF.
func jsonObjectOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var obj map[string]json.RawMessage
	return json.Unmarshal(data, &obj) == nil && obj != nil
}
func jsonArrayOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var arr []json.RawMessage
	return json.Unmarshal(data, &arr) == nil && arr != nil
}
func validCount(n int64) error {
	if n < 0 {
		return ErrIncomplete
	}
	return nil
}
func checkedAdd(a, b int64) (int64, error) {
	if err := validCount(b); err != nil {
		return 0, err
	}
	if b > math.MaxInt64-a {
		return 0, fmt.Errorf("%w: count overflow", ErrIncomplete)
	}
	return a + b, nil
}
```

## `internal/handlers/inventory/identities_list.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/mux"
	"github.com/lib/pq"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/inventory"
	repo "nhi-backend-api/internal/repository/inventory"
	svc "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
)

type AccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}
type Handler struct {
	service *svc.Service
	scope   AccountScope
}

func NewHandler(service *svc.Service, scope AccountScope) *Handler {
	return &Handler{service: service, scope: scope}
}

var accountID = regexp.MustCompile(`^[0-9]{12}$`)
var uuid = regexp.MustCompile(`(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$`)
var token = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,100}$`)
var region = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
var sorts = map[string]bool{"id": true, "name": true, "identity_type": true, "functional_class": true, "account_id": true, "region": true, "status": true, "created_at_aws": true, "last_seen_at": true, "last_activity_at": true}

type apiError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, status int, code, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	var body apiError
	body.Error.Code, body.Error.Message = code, msg
	b, _ := json.Marshal(body)
	w.WriteHeader(status)
	_, _ = w.Write(append(b, '\n'))
}
func writeOK(w http.ResponseWriter, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("inventory: encode response: %v", err)
		writeError(w, 500, "INTERNAL_ERROR", "Unable to encode inventory response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(200)
	_, _ = w.Write(append(b, '\n'))
}
func writeServiceError(w http.ResponseWriter, err error) {
	if errors.Is(err, svc.ErrNotFound) || errors.Is(err, repo.ErrNotFound) {
		writeError(w, 404, "NOT_FOUND", "Identity not found")
		return
	}
	if errors.Is(err, context.Canceled) {
		return
	}
	if errors.Is(err, context.DeadlineExceeded) {
		writeError(w, 504, "TIMEOUT", "Inventory request timed out")
		return
	}
	if errors.Is(err, m.ErrExportTooLarge) {
		writeError(w, http.StatusRequestEntityTooLarge, "EXPORT_TOO_LARGE", "Use narrower filters for this export")
		return
	}
	if errors.Is(err, svc.ErrSourceUnavailable) || errors.Is(err, svc.ErrIncomplete) || errors.Is(err, repo.ErrEmptyScope) {
		writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
		return
	}
	var pg *pq.Error
	if errors.As(err, &pg) {
		c := string(pg.Code)
		if c == "42P01" || c == "42703" || c == "42501" || strings.HasPrefix(c, "08") || c == "53300" || c == "57P01" {
			log.Printf("inventory source unavailable sqlstate=%s", c)
			writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
			return
		}
	}
	// The wrapped DB error might contain user filters or scanner values; log only
	// its type/SQLSTATE, never its raw message or SQL text.
	if errors.As(err, &pg) {
		log.Printf("inventory internal database error sqlstate=%s", pg.Code)
	} else {
		log.Printf("inventory internal error type=%T", err)
	}
	writeError(w, 500, "INTERNAL_ERROR", "Unable to load inventory data")
}
func (h *Handler) authorize(w http.ResponseWriter, r *http.Request, requested string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, 401, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if h == nil || h.service == nil || h.scope == nil {
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := h.scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		log.Printf("inventory account scope unavailable: %T", err)
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		writeError(w, 403, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	found := requested == ""
	for _, id := range ids {
		if !accountID.MatchString(id) {
			writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
		if id == requested {
			found = true
		}
	}
	if !found {
		writeError(w, 403, "FORBIDDEN", "AWS account is not authorized")
		return nil, false
	}
	return ids, true
}
func params(r *http.Request, allowed ...string) (map[string]string, bool) {
	q, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allow := map[string]bool{}
	for _, key := range allowed {
		allow[key] = true
	}
	out := map[string]string{}
	for key, values := range q {
		if !allow[key] || len(values) != 1 || values[0] == "" || len(values[0]) > 256 {
			return nil, false
		}
		out[key] = values[0]
	}
	if a := out["account_id"]; a != "" && !accountID.MatchString(a) {
		return nil, false
	}
	if z := out["region"]; z != "" && !region.MatchString(z) {
		return nil, false
	}
	for _, key := range []string{"identity_type", "functional_class", "status"} {
		if v := out[key]; v != "" && !token.MatchString(v) {
			return nil, false
		}
	}
	for _, val := range out {
		if strings.ContainsAny(val, "\x00\r\n") {
			return nil, false
		}
	}
	return out, true
}
func pathID(r *http.Request) (string, bool) { v := mux.Vars(r)["id"]; return v, uuid.MatchString(v) }
func parseBound(v string, def, max int64) (int64, bool) {
	if v == "" {
		return def, true
	}
	n, err := strconv.ParseInt(v, 10, 64)
	return n, err == nil && n >= 1 && n <= max
}

// parseListFilter is shared by A1 and A8; export accepts page/limit syntax
// but ignores the page selection because it downloads ALL matching rows.
func parseListFilter(p map[string]string) (m.ListFilter, bool) {
	page, ok1 := parseBound(p["page"], 1, 1_000_000)
	limit, ok2 := parseBound(p["limit"], 50, 200)
	if !ok1 || !ok2 {
		return m.ListFilter{}, false
	}
	sortBy := p["sort_by"]
	if sortBy == "" {
		sortBy = "last_seen_at"
	}
	sortOrder := strings.ToLower(p["sort_order"])
	if sortOrder == "" {
		sortOrder = "desc"
	}
	if !sorts[sortBy] || (sortOrder != "asc" && sortOrder != "desc") {
		return m.ListFilter{}, false
	}
	f := m.ListFilter{Page: page, Limit: limit, SortBy: sortBy, SortOrder: sortOrder, Search: p["search"], IdentityType: p["identity_type"], FunctionalClass: p["functional_class"], AccountID: p["account_id"], Region: p["region"], Status: p["status"], Owner: p["owner"], Environment: p["environment"]}
	if b := p["is_public"]; b != "" {
		if b != "true" && b != "false" {
			return m.ListFilter{}, false
		}
		v := b == "true"
		f.IsPublic = &v
	}
	if t := p["last_active_before"]; t != "" {
		v, e := time.Parse(time.RFC3339Nano, t)
		if e != nil {
			return m.ListFilter{}, false
		}
		v = v.UTC()
		f.LastActiveBefore = &v
	}
	return f, true
}

// A1: paged inventory list, exact PDF filters. No deleted row is ever shown.
func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "page", "limit", "sort_by", "sort_order", "search", "identity_type", "functional_class", "account_id", "region", "status", "owner", "environment", "is_public", "last_active_before")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid identity filters")
		return
	}
	f, ok := parseListFilter(p)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid identity filters")
		return
	}
	ids, ok := h.authorize(w, r, f.AccountID)
	if !ok {
		return
	}
	f.AllowedAccountIDs = ids
	out, err := h.service.List(r.Context(), f)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/routes/routes.go`

```go
// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 is a partial null-aware response; #4/#5 have credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. Until their
	// authoritative table and metric definitions exist, requests fail as 503.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
```

## Tests

The complete project ZIP includes route/service exception tests and `internal/repository/inventory/identities_integration_test.go` exercising actual SQL. `go test ./... && go vet ./...` (Go 1.26.5); run the CREATE/TRUNCATE integration fixture **only** against a disposable `_test` database. Never run it against a live/shared `nhi_db`.
