# Current credential-backed dashboard source files

This file contains the **complete current contents** of every source file newly created or modified for Overview Dashboard #1/#4/#5/#6 and the #7 fail-closed status. Merge into the full backend ZIP without replacing the existing JWT, inventory, legacy routes or other files. There is only one main and one router. See [implementation and remaining rules](CREDENTIAL_DASHBOARD_INTEGRATION.md). **Do not run integration fixtures against live `nhi_db`.**

## `cmd/api-server/main.go`

```go
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	dashservices "nhi-backend-api/internal/services/dashboard"
	inventoryservices "nhi-backend-api/internal/services/inventory"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize PostgreSQL Database
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// Dashboard APIs #1–#8 share approved policy A: every JWT-authenticated
	// dashboard user may see all known AWS accounts. The resolver reads the
	// catalog and scan targets; URL parameters NEVER supply the scope.
	// #1 measures available credential facts; #4/#5 have credential counts;
	// #6 is credential-backed. #7 remains unavailable pending risk rules;
	// #8 has not_in_iac:null.
	dashboard345Repo := dashrepo.NewDashboardBreakdownRepository(db.DB)
	dashboard345Scope := dashhandlers.NewDashboardAllAccountsScope(dashboard345Repo)
	dashboardCredentialRepo := dashrepo.NewDashboardCredentialRepository(db.DB)
	dashboard345Service := dashservices.NewDashboardBreakdownService(dashboard345Repo, dashboardCredentialRepo)
	dashboard345Handler := dashhandlers.NewDashboard345Handler(dashboard345Service, dashboard345Scope)
	dashboardCredentialService := dashservices.NewDashboardCredentialService(dashboardCredentialRepo)
	dashboardCredentialHandler := dashhandlers.NewDashboardCredentialHandler(dashboardCredentialService, dashboard345Scope)

	// Inventory A1–A6 uses the same approved JWT/account scope; all inventory
	// reads are constrained to current identities in nhi_scanner.identities.
	inventoryRepository := inventoryrepo.NewRepository(db.DB)
	inventoryService := inventoryservices.NewService(inventoryRepository)
	inventoryHandler := inventoryhandlers.NewHandler(inventoryService, dashboard345Scope)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                authHandler,
		DashboardHandler:           dashboardHandler,
		Dashboard345Handler:        dashboard345Handler,
		DashboardCredentialHandler: dashboardCredentialHandler,
		InventoryHandler:           inventoryHandler,
		IdentityHandler:            identityHandler,
		SecretHandler:              secretHandler,
		ScanHandler:                scanHandler,
		AuthMiddleware:             authMiddleware,
		EventHandler:               eventHandler,
		LineageHandler:             lineageHandler,
		CredentialHandler:          credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
```

## `internal/routes/routes.go`

```go
// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 measures available credentials; #4/#5 include actual credential
	// counts; #6 is live; #7 remains 503 pending hygiene rules; #8 has
	// not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. #6 queries
	// nhi_scanner.credentials; #7 stays fail-closed until risk rules are agreed.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
```

## `internal/models/dashboard/summary.go`

```go
package dashboard

import "time"

// SummaryFilter carries the two PDF filters and the trusted, authenticated
// account scope. AllowedAccountIDs must NEVER come from URL query parameters.
type SummaryFilter struct {
	AccountID         string
	Region            string
	AllowedAccountIDs []string
}

// SummaryIdentityRow is the repository's grouped identity status result.
// Deleted rows contribute only to Removed24h; current rows to other counts.
type SummaryIdentityRow struct {
	Status       string
	CurrentCount int64
	New24h       int64
	Removed24h   int64
}

// SummaryCredentialRow is a measured status group from current, scoped
// scanner credentials. Usage/expiry counts require actual non-NULL dates.
type SummaryCredentialRow struct {
	Status          string
	CurrentCount    int64
	New24h          int64
	Expiring30d     int64
	StaleKeys90d    int64
	UnknownKeyUsage int64
}

// SummaryScanData holds measured scan fields at the account scope. No region
// or scan-start column was supplied in the scan table.
type SummaryScanData struct {
	CompletedAccountCount int64
	LastScanAt            *time.Time
	ScanStatus            *string
}

// SummaryResponse is a deliberately PARTIAL PDF #1 contract: null means not
// measurable from verified sources, never a measured zero. The frontend must
// treat null values as "Not available" (including all scan cards when region
// is specified, because scan records cannot be filtered by region).
type SummaryResponse struct {
	TotalIdentities          int64             `json:"total_identities"`
	TotalCredentials         *int64            `json:"total_credentials"`
	TotalAccountsScanned     *int64            `json:"total_accounts_scanned"`
	TotalRegionsScanned      *int64            `json:"total_regions_scanned"`
	IdentitiesByStatus       map[string]int64  `json:"identities_by_status"`
	CredentialsByStatus      *map[string]int64 `json:"credentials_by_status"`
	NewIdentitiesLast24h     int64             `json:"new_identities_last_24h"`
	RemovedIdentitiesLast24h int64             `json:"removed_identities_last_24h"`
	NewCredentialsLast24h    *int64            `json:"new_credentials_last_24h"`
	ExpiringCredentials30d   *int64            `json:"expiring_credentials_30d"`
	StaleCredentials90d      *int64            `json:"stale_credentials_90d"`
	UnrotatedCredentials     *int64            `json:"unrotated_credentials"`
	LastScanAt               *time.Time        `json:"last_scan_at"`
	ScanDurationSeconds      *int64            `json:"scan_duration_seconds"`
	ScanStatus               *string           `json:"scan_status"`
}
```

## `internal/models/dashboard/identities_by_account.go`

```go
package dashboard

// AccountFilter scopes API #4 to approved AWS accounts and supports its
// optional region and identity_type filters.
type AccountFilter struct {
	Region            string
	IdentityType      string
	AllowedAccountIDs []string
}

// AccountIdentityCount is an identity count read from nhi_scanner.identities.
type AccountIdentityCount struct {
	AccountID     string
	IdentityCount int64
}

// AccountBreakdown omits account_name at the lead's direction. Production
// measures CredentialCount from current nhi_scanner.credentials; nil remains
// unavailable for unconfigured/adaptor-only service instances.
type AccountBreakdown struct {
	AccountID       string `json:"account_id"`
	IdentityCount   int64  `json:"identity_count"`
	CredentialCount *int64 `json:"credential_count"`
}

type ByAccountResponse struct {
	TotalAccounts int                `json:"total_accounts"`
	Breakdown     []AccountBreakdown `json:"breakdown"`
}
```

## `internal/models/dashboard/identities_by_region.go`

```go
package dashboard

// RegionFilter scopes API #5 to approved AWS accounts and supports its
// optional account_id and identity_type filters.
type RegionFilter struct {
	AccountID         string
	IdentityType      string
	AllowedAccountIDs []string
}

// RegionIdentityCount is an identity count read from nhi_scanner.identities.
type RegionIdentityCount struct {
	Region        string
	IdentityCount int64
}

// RegionBreakdown includes measured current credential counts in production.
// A nil count is unavailable for an unconfigured/adaptor-only service.
type RegionBreakdown struct {
	Region          string `json:"region"`
	IdentityCount   int64  `json:"identity_count"`
	CredentialCount *int64 `json:"credential_count"`
}

type ByRegionResponse struct {
	TotalRegions int               `json:"total_regions"`
	Breakdown    []RegionBreakdown `json:"breakdown"`
}
```

## `internal/models/dashboard/credentials_by_type.go`

```go
package dashboard

import "errors"

// ErrCredentialSourceUnavailable means a required credential source or
// classification rule is unavailable. Never translate it into a measured zero.
var ErrCredentialSourceUnavailable = errors.New("dashboard credential inventory is not configured")

// CredentialTypeFilter carries the PDF #6 filters and the trusted account
// scope resolved from the authenticated request, never from the URL alone.
type CredentialTypeFilter struct {
	AccountID         string
	Region            string
	Status            string
	AllowedAccountIDs []string
}

type CredentialTypeCount struct {
	CredentialType string `json:"credential_type"`
	Count          int64  `json:"count"`
}

type CredentialsByTypeResponse struct {
	Total     int64                 `json:"total"`
	Breakdown []CredentialTypeCount `json:"breakdown"`
}
```

## `internal/services/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"errors"
	"fmt"
	"time"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

var (
	// A required, approved backing source has not yet been provided.
	ErrDashboardSourceUnavailable = errors.New("dashboard source unavailable")
	// The configured source did not provide a value for every returned group.
	ErrDashboardSourceIncomplete = errors.New("dashboard source incomplete")
)

// Dashboard345IdentityReader reads catalog counts from nhi_scanner.identities.
// The repository must enforce AllowedAccountIDs for every query.
type Dashboard345IdentityReader interface {
	ByClass(context.Context, identitymodels.ClassFilter) ([]identitymodels.FunctionalClassCount, error)
	ByAccountIdentityCounts(context.Context, identitymodels.AccountFilter) ([]identitymodels.AccountIdentityCount, error)
	ByRegionIdentityCounts(context.Context, identitymodels.RegionFilter) ([]identitymodels.RegionIdentityCount, error)
}

// CredentialSummaryReader supplies real credential facts to PDF #1/#4/#5.
// Kept separate from the identity reader to preserve flat domain ownership.
type CredentialSummaryReader interface {
	SummaryCredentialCounts(context.Context, identitymodels.SummaryFilter, time.Time, time.Time) ([]identitymodels.SummaryCredentialRow, error)
	ByAccountCredentialCounts(context.Context, identitymodels.AccountFilter) (map[string]int64, error)
	ByRegionCredentialCounts(context.Context, identitymodels.RegionFilter) (map[string]int64, error)
}

type DashboardBreakdownService struct {
	identities  Dashboard345IdentityReader
	credentials CredentialSummaryReader
}

// The optional argument preserves old independent identity-only service tests.
// Production explicitly provides the scanner credential repository.
func NewDashboardBreakdownService(ids Dashboard345IdentityReader, credentials ...CredentialSummaryReader) *DashboardBreakdownService {
	s := &DashboardBreakdownService{identities: ids}
	if len(credentials) > 0 {
		s.credentials = credentials[0]
	}
	return s
}

func requireScope(ids []string) error {
	if len(ids) == 0 {
		return ErrDashboardSourceUnavailable
	}
	return nil
}

func checkCount(n int64, label string) error {
	if n < 0 {
		return fmt.Errorf("%w: negative %s count", ErrDashboardSourceIncomplete, label)
	}
	return nil
}

func (s *DashboardBreakdownService) ByClass(ctx context.Context, f identitymodels.ClassFilter) (*identitymodels.ByClassResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByClass(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByClassResponse{Breakdown: make([]identitymodels.FunctionalClassCount, 0, len(groups))}
	for _, group := range groups {
		if err := checkCount(group.Count, "identity"); err != nil {
			return nil, err
		}
		out.Total += group.Count
		out.Breakdown = append(out.Breakdown, group)
	}
	return out, nil
}
```

## `internal/services/dashboard/summary.go`

```go
package dashboard

import (
	"context"
	"math"
	"time"

	m "nhi-backend-api/internal/models/dashboard"
)

type dashboardSummaryReader interface {
	SummaryIdentityCounts(context.Context, m.SummaryFilter, time.Time, time.Time) ([]m.SummaryIdentityRow, error)
	SummaryScanData(context.Context, m.SummaryFilter) (m.SummaryScanData, error)
}

// Summary returns a measured-and-null PDF #1 response. Credentials are
// measured from the configured scanner repository; unrotated credentials,
// scan duration and regional scan coverage remain unmeasured. Region-filtered
// scan cards are null, though region-filtered credential cards are measured.
func (s *DashboardBreakdownService) Summary(ctx context.Context, f m.SummaryFilter) (*m.SummaryResponse, error) {
	if s == nil || s.identities == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	reader, ok := s.identities.(dashboardSummaryReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	now := time.Now().UTC()
	rows, err := reader.SummaryIdentityCounts(ctx, f, now.Add(-24*time.Hour), now)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.SummaryResponse{IdentitiesByStatus: make(map[string]int64)}
	seen := make(map[string]bool, len(rows))
	for _, row := range rows {
		if row.Status == "" || seen[row.Status] {
			return nil, ErrDashboardSourceIncomplete
		}
		seen[row.Status] = true
		for _, count := range []int64{row.CurrentCount, row.New24h, row.Removed24h} {
			if err := checkCount(count, "summary identity"); err != nil {
				return nil, err
			}
		}
		if row.CurrentCount > math.MaxInt64-out.TotalIdentities ||
			row.New24h > math.MaxInt64-out.NewIdentitiesLast24h ||
			row.Removed24h > math.MaxInt64-out.RemovedIdentitiesLast24h {
			return nil, ErrDashboardSourceIncomplete
		}
		out.TotalIdentities += row.CurrentCount
		out.NewIdentitiesLast24h += row.New24h
		out.RemovedIdentitiesLast24h += row.Removed24h
		if row.CurrentCount > 0 {
			out.IdentitiesByStatus[row.Status] = row.CurrentCount
		}
	}
	if s.credentials != nil {
		credentialRows, err := s.credentials.SummaryCredentialCounts(ctx, f, now.Add(-24*time.Hour), now)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialRows == nil { // nil,nil cannot stand for measured zero
			return nil, ErrDashboardSourceIncomplete
		}
		byStatus := make(map[string]int64, len(credentialRows))
		var total, new24h, expiring, stale, unknownUsage int64
		for _, row := range credentialRows {
			if row.Status == "" {
				return nil, ErrDashboardSourceIncomplete
			}
			if _, duplicate := byStatus[row.Status]; duplicate {
				return nil, ErrDashboardSourceIncomplete
			}
			for _, n := range []int64{row.CurrentCount, row.New24h, row.Expiring30d, row.StaleKeys90d, row.UnknownKeyUsage} {
				if err := checkCount(n, "summary credential"); err != nil {
					return nil, err
				}
			}
			if row.CurrentCount > math.MaxInt64-total || row.New24h > math.MaxInt64-new24h ||
				row.Expiring30d > math.MaxInt64-expiring || row.StaleKeys90d > math.MaxInt64-stale ||
				row.UnknownKeyUsage > math.MaxInt64-unknownUsage ||
				row.New24h > row.CurrentCount || row.Expiring30d > row.CurrentCount ||
				row.StaleKeys90d > row.CurrentCount || row.UnknownKeyUsage > row.CurrentCount ||
				row.StaleKeys90d > row.CurrentCount-row.UnknownKeyUsage {
				return nil, ErrDashboardSourceIncomplete
			}
			byStatus[row.Status] = row.CurrentCount
			total += row.CurrentCount
			new24h += row.New24h
			expiring += row.Expiring30d
			stale += row.StaleKeys90d
			unknownUsage += row.UnknownKeyUsage
		}
		out.TotalCredentials = &total
		out.CredentialsByStatus = &byStatus
		out.NewCredentialsLast24h = &new24h
		out.ExpiringCredentials30d = &expiring
		if unknownUsage == 0 { // NULL usage may mean untracked, not never-used
			out.StaleCredentials90d = &stale
		}
	}
	if f.Region == "" {
		scan, err := reader.SummaryScanData(ctx, f)
		if err != nil {
			return nil, err
		}
		if err := checkCount(scan.CompletedAccountCount, "completed scanned accounts"); err != nil {
			return nil, err
		}
		out.TotalAccountsScanned = &scan.CompletedAccountCount // 0 only if query measured zero
		out.LastScanAt = scan.LastScanAt
		out.ScanStatus = scan.ScanStatus
	}
	// Unrotated classification has no confirmed rule. Neither scan-start nor
	// regional scan coverage is present in the confirmed scan table. These
	// pointer fields stay nil rather than fabricating measured zero.
	return out, nil
}
```

## `internal/services/dashboard/identities_by_account.go`

```go
package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByAccount preserves the lead-approved omission of account_name; credential
// counts are independently measured by account/region from current credentials.
// identity_type has no credential-side equivalent and filters identities only.
func (s *DashboardBreakdownService) ByAccount(ctx context.Context, f identitymodels.AccountFilter) (*identitymodels.ByAccountResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByAccountIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByAccountResponse{Breakdown: make([]identitymodels.AccountBreakdown, 0, len(groups))}
	var credentialCounts map[string]int64
	if s.credentials != nil {
		credentialCounts, err = s.credentials.ByAccountCredentialCounts(ctx, f)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialCounts == nil {
			return nil, ErrDashboardSourceIncomplete
		}
		for _, n := range credentialCounts {
			if err := checkCount(n, "credential account"); err != nil {
				return nil, err
			}
		}
	}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		item := identitymodels.AccountBreakdown{AccountID: group.AccountID, IdentityCount: group.IdentityCount}
		if credentialCounts != nil {
			value := credentialCounts[group.AccountID]
			item.CredentialCount = &value // absent group is a measured zero
		}
		out.Breakdown = append(out.Breakdown, item)
	}
	out.TotalAccounts = len(out.Breakdown)
	return out, nil
}
```

## `internal/services/dashboard/identities_by_region.go`

```go
package dashboard

import (
	"context"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ByRegion adds actual credential counts for each identity region; no
// credential-to-identity_type relationship is invented.
func (s *DashboardBreakdownService) ByRegion(ctx context.Context, f identitymodels.RegionFilter) (*identitymodels.ByRegionResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	groups, err := s.identities.ByRegionIdentityCounts(ctx, f)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ByRegionResponse{Breakdown: make([]identitymodels.RegionBreakdown, 0, len(groups))}
	var credentialCounts map[string]int64
	if s.credentials != nil {
		credentialCounts, err = s.credentials.ByRegionCredentialCounts(ctx, f)
		if err != nil {
			return nil, credentialSourceError(err)
		}
		if credentialCounts == nil {
			return nil, ErrDashboardSourceIncomplete
		}
		for _, n := range credentialCounts {
			if err := checkCount(n, "credential region"); err != nil {
				return nil, err
			}
		}
	}
	for _, group := range groups {
		if err := checkCount(group.IdentityCount, "identity"); err != nil {
			return nil, err
		}
		item := identitymodels.RegionBreakdown{Region: group.Region, IdentityCount: group.IdentityCount}
		if credentialCounts != nil {
			value := credentialCounts[group.Region]
			item.CredentialCount = &value
		}
		out.Breakdown = append(out.Breakdown, item)
	}
	out.TotalRegions = len(out.Breakdown)
	return out, nil
}
```

## `internal/services/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"context"
	"errors"
	"fmt"
	"math"
	"strings"

	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialReader uses the confirmed scanner credentials table for
// #6; #7 is deliberately unavailable until its risk definitions are approved.
type DashboardCredentialReader interface {
	CredentialTypeCounts(context.Context, m.CredentialTypeFilter) ([]m.CredentialTypeCount, error)
	CredentialHygiene(context.Context, m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error)
}

type DashboardCredentialService struct{ reader DashboardCredentialReader }

func NewDashboardCredentialService(reader DashboardCredentialReader) *DashboardCredentialService {
	return &DashboardCredentialService{reader: reader}
}

func credentialSourceError(err error) error {
	if errors.Is(err, m.ErrCredentialSourceUnavailable) {
		return ErrDashboardSourceUnavailable
	}
	return err
}

func (s *DashboardCredentialService) ByType(ctx context.Context, f m.CredentialTypeFilter) (*m.CredentialsByTypeResponse, error) {
	if s == nil || s.reader == nil || requireScope(f.AllowedAccountIDs) != nil {
		return nil, ErrDashboardSourceUnavailable
	}
	counts, err := s.reader.CredentialTypeCounts(ctx, f)
	if err != nil {
		return nil, credentialSourceError(err)
	}
	if counts == nil { // nil,nil is NOT a proven empty inventory
		return nil, ErrDashboardSourceIncomplete
	}
	out := &m.CredentialsByTypeResponse{Breakdown: make([]m.CredentialTypeCount, 0, len(counts))}
	seen := make(map[string]bool, len(counts))
	for _, c := range counts {
		if strings.TrimSpace(c.CredentialType) == "" || seen[c.CredentialType] {
			return nil, fmt.Errorf("%w: invalid or duplicate credential type", ErrDashboardSourceIncomplete)
		}
		seen[c.CredentialType] = true
		if err := checkCount(c.Count, "credential"); err != nil {
			return nil, err
		}
		if c.Count > math.MaxInt64-out.Total {
			return nil, fmt.Errorf("%w: credential total overflow", ErrDashboardSourceIncomplete)
		}
		out.Total += c.Count
		out.Breakdown = append(out.Breakdown, c)
	}
	return out, nil
}
```

## `internal/repository/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ErrEmptyAccountScope means the caller has not been authorized for any AWS account.
var ErrEmptyAccountScope = errors.New("authorized account scope is empty")

// DashboardBreakdownRepository reads the UUID-keyed nhi_scanner.identities catalog.
// This is intentionally distinct from nhi_scanner.nhi_identities_aws.
type DashboardBreakdownRepository struct{ db *sql.DB }

func NewDashboardBreakdownRepository(db *sql.DB) *DashboardBreakdownRepository {
	return &DashboardBreakdownRepository{db: db}
}

// AllKnownAccountIDs implements the explicitly approved policy that every
// authenticated dashboard user may see every known AWS account. Include scan
// targets and current scanner credentials as well as catalog rows, so an
// account with zero current identities can still be selected. Only 12-digit
// AWS account IDs qualify. A missing credentials table is an unavailable
// source, never silently treated as an empty credential inventory.
// This method supplies an account scope; it does not count identities.
func (r *DashboardBreakdownRepository) AllKnownAccountIDs(ctx context.Context) ([]string, error) {
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("account scope source unavailable")
	}
	const query = `
        SELECT account_id FROM (
            SELECT account_id FROM nhi_scanner.identities
            UNION
            SELECT account_id::text FROM nhi_scanner.nhi_scans_aws
            UNION
            SELECT account_id FROM nhi_scanner.credentials WHERE deleted_at IS NULL
        ) AS known_accounts
        WHERE account_id ~ '^[0-9]{12}$'
        ORDER BY account_id ASC`
	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("load dashboard account scope: %w", err)
	}
	defer rows.Close()
	ids := make([]string, 0)
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, fmt.Errorf("scan dashboard account scope: %w", err)
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate dashboard account scope: %w", err)
	}
	return ids, nil
}

// ByClass counts current (not soft-deleted) catalog identities. NULL/blank
// functional_class maps to "unclassified"; no other taxonomy remapping is assumed.
func (r *DashboardBreakdownRepository) ByClass(ctx context.Context, f identitymodels.ClassFilter) ([]identitymodels.FunctionalClassCount, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT COALESCE(NULLIF(BTRIM(functional_class), ''), 'unclassified') AS functional_class,
               COUNT(*) AS identity_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
        GROUP BY 1
        ORDER BY identity_count DESC, functional_class ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region)
	if err != nil {
		return nil, fmt.Errorf("query by class: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.FunctionalClassCount, 0)
	for rows.Next() {
		var c identitymodels.FunctionalClassCount
		if err := rows.Scan(&c.FunctionalClass, &c.Count); err != nil {
			return nil, fmt.Errorf("scan by class: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate by class: %w", err)
	}
	return out, nil
}
```

## `internal/repository/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/dashboard"
)

// DashboardCredentialRepository reads the authoritative scanner credential
// inventory. It never reads the unrelated legacy public.credentials table.
type DashboardCredentialRepository struct{ db *sql.DB }

func NewDashboardCredentialRepository(db *sql.DB) *DashboardCredentialRepository {
	return &DashboardCredentialRepository{db: db}
}

func (r *DashboardCredentialRepository) ready(ids []string) error {
	if r == nil || r.db == nil || len(ids) == 0 {
		return m.ErrCredentialSourceUnavailable
	}
	return nil
}

// CredentialTypeCounts implements PDF #6 using current scoped rows, including
// all statuses unless the caller selects a particular status.
func (r *DashboardCredentialRepository) CredentialTypeCounts(ctx context.Context, f m.CredentialTypeFilter) ([]m.CredentialTypeCount, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT credential_type, COUNT(*)
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($3::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $3::text)
          AND ($4::text = '' OR COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') = $4::text)
        GROUP BY credential_type ORDER BY COUNT(*) DESC, credential_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.Status)
	if err != nil {
		return nil, fmt.Errorf("query credential types: %w", err)
	}
	defer rows.Close()
	out := make([]m.CredentialTypeCount, 0)
	for rows.Next() {
		var c m.CredentialTypeCount
		if err := rows.Scan(&c.CredentialType, &c.Count); err != nil {
			return nil, fmt.Errorf("scan credential type: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credential types: %w", err)
	}
	return out, nil
}

// SummaryCredentialCounts backs PDF #1 status, newly discovered, expiring and
// stale access-key cards with measured facts. Missing last_used_at does NOT
// imply stale/never used. first_seen_at represents first discovery, not AWS
// issuance. All bounds use the service's one UTC instant.
func (r *DashboardCredentialRepository) SummaryCredentialCounts(ctx context.Context, f m.SummaryFilter, start, now time.Time) ([]m.SummaryCredentialRow, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT COALESCE(NULLIF(LOWER(BTRIM(status)), ''), 'unknown') AS credential_status,
            COUNT(*) AS current_count,
            COUNT(*) FILTER (WHERE first_seen_at >= $3::timestamptz AND first_seen_at <= $4::timestamptz) AS new_24h,
            COUNT(*) FILTER (WHERE expires_at > $4::timestamptz AND expires_at <= $5::timestamptz) AS expiring_30d,
            COUNT(*) FILTER (WHERE credential_type = 'access_key' AND last_used_at IS NOT NULL
                             AND last_used_at < $6::timestamptz) AS stale_keys_90d,
            COUNT(*) FILTER (WHERE credential_type = 'access_key' AND last_used_at IS NULL) AS unknown_key_usage
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
          AND ($7::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $7::text)
        GROUP BY 1 ORDER BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, start.UTC(), now.UTC(), now.UTC().Add(30*24*time.Hour), now.UTC().Add(-90*24*time.Hour), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query summary credentials: %w", err)
	}
	defer rows.Close()
	out := make([]m.SummaryCredentialRow, 0)
	for rows.Next() {
		var c m.SummaryCredentialRow
		if err := rows.Scan(&c.Status, &c.CurrentCount, &c.New24h, &c.Expiring30d, &c.StaleKeys90d, &c.UnknownKeyUsage); err != nil {
			return nil, fmt.Errorf("scan summary credentials: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate summary credentials: %w", err)
	}
	return out, nil
}

// ByAccountCredentialCounts counts all current matching credentials by AWS
// account and region. The optional identity_type filter only applies to the
// identity half: credentials have no identity_type or verified join to one.
func (r *DashboardCredentialRepository) ByAccountCredentialCounts(ctx context.Context, f m.AccountFilter) (map[string]int64, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT account_id, COUNT(*) FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR COALESCE(NULLIF(BTRIM(region), ''), 'unknown') = $2::text)
        GROUP BY account_id`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.Region)
	if err != nil {
		return nil, fmt.Errorf("query credentials by account: %w", err)
	}
	defer rows.Close()
	out := make(map[string]int64)
	for rows.Next() {
		var key string
		var n int64
		if err := rows.Scan(&key, &n); err != nil {
			return nil, fmt.Errorf("scan credentials by account: %w", err)
		}
		out[key] = n
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials by account: %w", err)
	}
	return out, nil
}

func (r *DashboardCredentialRepository) ByRegionCredentialCounts(ctx context.Context, f m.RegionFilter) (map[string]int64, error) {
	if err := r.ready(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const query = `SELECT COALESCE(NULLIF(BTRIM(region), ''), 'unknown'), COUNT(*)
        FROM nhi_scanner.credentials
        WHERE deleted_at IS NULL AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
        GROUP BY 1`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID)
	if err != nil {
		return nil, fmt.Errorf("query credentials by region: %w", err)
	}
	defer rows.Close()
	out := make(map[string]int64)
	for rows.Next() {
		var key string
		var n int64
		if err := rows.Scan(&key, &n); err != nil {
			return nil, fmt.Errorf("scan credentials by region: %w", err)
		}
		out[key] = n
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate credentials by region: %w", err)
	}
	return out, nil
}
```

## `internal/repository/dashboard/credentials_hygiene.go`

```go
package dashboard

import (
	"context"

	m "nhi-backend-api/internal/models/dashboard"
)

// CredentialHygiene deliberately fails closed until the scanner's semantics
// are confirmed for NULL last_used_at, NULL last_rotated_at, IAM role policy
// JSON shapes, privilege threshold, root owner, and public trust. The now-
// confirmed 31-column table supports expiry and tracked-usage measurements,
// but a successful PDF #7 response requires *every* risk card to have a
// reliable classification. Do not turn missing scanner fields into zero.
func (r *DashboardCredentialRepository) CredentialHygiene(_ context.Context, _ m.CredentialHygieneFilter) (*m.CredentialHygieneResponse, error) {
	return nil, m.ErrCredentialSourceUnavailable
}
```

## `internal/handlers/dashboard/credentials_by_type.go`

```go
package dashboard

import (
	"net/http"

	m "nhi-backend-api/internal/models/dashboard"
	s "nhi-backend-api/internal/services/dashboard"
)

// DashboardCredentialHandler handles PDF APIs #6/#7, independent from the
// legacy /api/credentials route. It shares policy A's trusted account scope.
type DashboardCredentialHandler struct {
	service *s.DashboardCredentialService
	scope   DashboardAccountScope
}

func NewDashboardCredentialHandler(service *s.DashboardCredentialService, scope DashboardAccountScope) *DashboardCredentialHandler {
	return &DashboardCredentialHandler{service: service, scope: scope}
}

func (h *DashboardCredentialHandler) authorizedAccounts(w http.ResponseWriter, r *http.Request, accountID string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, accountID)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, accountID)
}

// ByType implements GET /api/v1/dashboard/credentials/by-type using current
// account-scoped scanner credentials; data source failures return sanitized 503.
func (h *DashboardCredentialHandler) ByType(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region", "status")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid credential by-type filters")
		return
	}
	accounts, ok := h.authorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	out, err := h.service.ByType(r.Context(), m.CredentialTypeFilter{
		AccountID: params["account_id"], Region: params["region"], Status: params["status"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, out)
}
```

## Verification

The full ZIP also includes `internal/services/dashboard/credentials_summary_test.go`, `internal/routes/dashboard_credentials_live_routes_test.go`, and the extended `internal/repository/dashboard/identities_345_integration_test.go`. `go test ./...` and `go vet ./...` pass under Go 1.26.5. The SQL fixture was run only on a disposable local `_test` database; no live `nhi_db` data or UPDATE/SELECT privileges were verified.
