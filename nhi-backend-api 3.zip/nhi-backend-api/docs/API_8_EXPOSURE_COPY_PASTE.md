# API #8 Exposure — complete source files (copy/paste)

Apply these to the **existing complete backend**, not to a blank new project. They are new endpoint-named files directly inside the four flat dashboard directories. This partial PDF #8 contract returns `not_in_iac:null` because a trustworthy IaC marker has not been provided. Owner/environment tag rules are provisional; read [API_8_EXPOSURE_ANALYSIS.md](API_8_EXPOSURE_ANALYSIS.md) first.

## `internal/models/dashboard/identities_exposure.go`

```go
package dashboard

// ExposureFilter carries the optional PDF account_id and a trusted, JWT-
// resolved AWS-account scope. Never fill AllowedAccountIDs from a URL.
type ExposureFilter struct {
	AccountID         string
	AllowedAccountIDs []string
}

// ExposureCountByType is a real count of current identities of one type.
type ExposureCountByType struct {
	IdentityType string `json:"identity_type"`
	Count        int64  `json:"count"`
}

type ExposureGroup struct {
	Total  int64                 `json:"total"`
	ByType []ExposureCountByType `json:"by_type"`
}

// ExposureResponse implements the available catalog-derived PDF #8 cards.
// No confirmed IaC marker exists: nil NotInIAC serializes as JSON null, NOT 0.
// The product must approve the normalized owner/environment column semantics.
type ExposureResponse struct {
	PubliclyAccessible    ExposureGroup `json:"publicly_accessible"`
	Dormant90d            ExposureGroup `json:"dormant_90d"`
	NoActivityTracked     int64         `json:"no_activity_tracked"`
	MissingOwnerTag       int64         `json:"missing_owner_tag"`
	MissingEnvironmentTag int64         `json:"missing_environment_tag"`
	NotInIAC              *int64        `json:"not_in_iac"`
}

// ExposureCountRow is a grouped repository result, not a JSON response.
type ExposureCountRow struct {
	IdentityType      string
	PublicCount       int64
	DormantCount      int64
	NoActivityCount   int64
	MissingOwnerCount int64
	MissingEnvCount   int64
}
```

## `internal/repository/dashboard/identities_exposure.go`

```go
package dashboard

import (
	"context"
	"fmt"
	"time"

	"github.com/lib/pq"
	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// ExposureCounts reads ONLY the current UUID-keyed catalog and computes every
// available card in one query/snapshot. The IaC card cannot be derived from
// the confirmed columns and is deliberately not queried or guessed.
func (r *DashboardBreakdownRepository) ExposureCounts(ctx context.Context, f identitymodels.ExposureFilter, dormantBefore time.Time) ([]identitymodels.ExposureCountRow, error) {
	if len(f.AllowedAccountIDs) == 0 {
		return nil, ErrEmptyAccountScope
	}
	const query = `
        SELECT identity_type,
               COUNT(*) FILTER (WHERE is_publicly_accessible IS TRUE) AS public_count,
               COUNT(*) FILTER (WHERE last_activity_at IS NOT NULL
                                 AND last_activity_at < $3::timestamptz) AS dormant_count,
               COUNT(*) FILTER (WHERE last_activity_at IS NULL) AS no_activity_count,
               COUNT(*) FILTER (WHERE NULLIF(BTRIM(owner), '') IS NULL) AS missing_owner_count,
               COUNT(*) FILTER (WHERE NULLIF(BTRIM(environment), '') IS NULL) AS missing_environment_count
        FROM nhi_scanner.identities
        WHERE deleted_at IS NULL
          AND account_id = ANY($1::text[])
          AND ($2::text = '' OR account_id = $2::text)
        GROUP BY identity_type
        ORDER BY identity_type ASC`
	rows, err := r.db.QueryContext(ctx, query, pq.Array(f.AllowedAccountIDs), f.AccountID, dormantBefore.UTC())
	if err != nil {
		return nil, fmt.Errorf("query identity exposure: %w", err)
	}
	defer rows.Close()
	out := make([]identitymodels.ExposureCountRow, 0)
	for rows.Next() {
		var c identitymodels.ExposureCountRow
		if err := rows.Scan(&c.IdentityType, &c.PublicCount, &c.DormantCount, &c.NoActivityCount, &c.MissingOwnerCount, &c.MissingEnvCount); err != nil {
			return nil, fmt.Errorf("scan identity exposure: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate identity exposure: %w", err)
	}
	return out, nil
}
```

## `internal/services/dashboard/identities_exposure.go`

```go
package dashboard

import (
	"context"
	"sort"
	"time"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// The exposure reader is optional for older test implementations of APIs 3–5.
// The production DashboardBreakdownRepository implements it.
type dashboardExposureReader interface {
	ExposureCounts(context.Context, identitymodels.ExposureFilter, time.Time) ([]identitymodels.ExposureCountRow, error)
}

// Exposure builds the dashboard #8 cards. Dormancy is a non-NULL activity
// timestamp strictly older than 90*24 hours; a NULL timestamp goes into
// no_activity_tracked, not dormant_90d. IaC availability is unknown.
func (s *DashboardBreakdownService) Exposure(ctx context.Context, f identitymodels.ExposureFilter) (*identitymodels.ExposureResponse, error) {
	if s == nil || s.identities == nil {
		return nil, ErrDashboardSourceUnavailable
	}
	if err := requireScope(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	reader, ok := s.identities.(dashboardExposureReader)
	if !ok {
		return nil, ErrDashboardSourceUnavailable
	}
	cutoff := time.Now().UTC().Add(-90 * 24 * time.Hour)
	rows, err := reader.ExposureCounts(ctx, f, cutoff)
	if err != nil {
		return nil, err
	}
	out := &identitymodels.ExposureResponse{
		PubliclyAccessible: identitymodels.ExposureGroup{ByType: []identitymodels.ExposureCountByType{}},
		Dormant90d:         identitymodels.ExposureGroup{ByType: []identitymodels.ExposureCountByType{}},
		NotInIAC:           nil, // not a measured zero
	}
	for _, row := range rows {
		for _, item := range []struct {
			label string
			n     int64
		}{
			{"public", row.PublicCount}, {"dormant", row.DormantCount},
			{"no activity", row.NoActivityCount}, {"missing owner", row.MissingOwnerCount},
			{"missing environment", row.MissingEnvCount},
		} {
			if err := checkCount(item.n, item.label); err != nil {
				return nil, err
			}
		}
		if row.PublicCount > 0 {
			out.PubliclyAccessible.ByType = append(out.PubliclyAccessible.ByType, identitymodels.ExposureCountByType{IdentityType: row.IdentityType, Count: row.PublicCount})
		}
		if row.DormantCount > 0 {
			out.Dormant90d.ByType = append(out.Dormant90d.ByType, identitymodels.ExposureCountByType{IdentityType: row.IdentityType, Count: row.DormantCount})
		}
		out.PubliclyAccessible.Total += row.PublicCount
		out.Dormant90d.Total += row.DormantCount
		out.NoActivityTracked += row.NoActivityCount
		out.MissingOwnerTag += row.MissingOwnerCount
		out.MissingEnvironmentTag += row.MissingEnvCount
	}
	less := func(a, b identitymodels.ExposureCountByType) bool {
		if a.Count != b.Count {
			return a.Count > b.Count
		}
		return a.IdentityType < b.IdentityType
	}
	sort.Slice(out.PubliclyAccessible.ByType, func(i, j int) bool {
		return less(out.PubliclyAccessible.ByType[i], out.PubliclyAccessible.ByType[j])
	})
	sort.Slice(out.Dormant90d.ByType, func(i, j int) bool {
		return less(out.Dormant90d.ByType[i], out.Dormant90d.ByType[j])
	})
	return out, nil
}
```

## `internal/handlers/dashboard/identities_exposure.go`

```go
package dashboard

import (
	"net/http"

	identitymodels "nhi-backend-api/internal/models/dashboard"
)

// Exposure implements GET /api/v1/dashboard/identities/exposure.
// This reuses the existing JWT account-scope policy approved for APIs 3–5.
func (h *DashboardBreakdownHandler) Exposure(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid exposure filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.Exposure(r.Context(), identitymodels.ExposureFilter{
		AccountID: params["account_id"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
```

## Add one route inside the **existing** `internal/routes/routes.go`

Inside the `if h.Dashboard345Handler != nil {` block, after the by-region GET route, add:

```go
protected.HandleFunc("/v1/dashboard/identities/exposure", h.Dashboard345Handler.Exposure).Methods("GET")
```

The `/api` prefix and JWT middleware are already applied by the containing router. **Do not add another router or main file**. No change is required in `cmd/api-server/main.go`: its existing `dashrepo.NewDashboardBreakdownRepository(db)` → `dashservices.NewDashboardBreakdownService(...)` → `dashhandlers.NewDashboard345Handler(...)` chain already exposes the new reader method.

Expected JSON shape (illustrative zeros are *not* fixture or production measurements):

```json
{"publicly_accessible":{"total":0,"by_type":[]},"dormant_90d":{"total":0,"by_type":[]},"no_activity_tracked":0,"missing_owner_tag":0,"missing_environment_tag":0,"not_in_iac":null}
```

Tests: `go test ./... && go vet ./...` (Go 1.26.5). The optional PostgreSQL integration fixture can CREATE/TRUNCATE rows; run it only on a disposable `*_test` database, **never** a shared or live database.
