> **Historical snapshot:** This document predates the confirmed `nhi_scanner.credentials` table. For the CURRENT #1/#4/#5/#6 code, status and exceptions, use [credential integration](CREDENTIAL_DASHBOARD_INTEGRATION.md) and [current source files](CREDENTIAL_DASHBOARD_UPDATED_CODE.md). #7 still requires approved hygiene rules.

> **Current integration note:** A7–A9 are also registered in the central router shown below; see [A7–A9 code](A7_A9_COMPLETE_CODE.md).

# Inventory A1–A6 — full source files

These 24 endpoint-named files implement the PDF Identity Inventory APIs A1–A6 directly inside four flat `internal/{models,repository,services,handlers}/inventory/` packages. **Current-only rule:** every SQL query enforces `deleted_at IS NULL`. Deleted, missing and out-of-scope UUIDs all return 404 on detail/attributes/timeline. Existing dashboard policy A is shared under JWT, and the user explicitly approved full `raw_api_response` for authenticated inventory users. See [implementation, errors, tests and security notes](A1_A6_INVENTORY_IMPLEMENTATION.md).

The last three sections show the *current complete* shared dashboard error helper and the **single existing** main/router. The router also calls `middleware.RecoverV1` from `internal/middleware/recover_v1.go`; its complete file is included below and in the full project ZIP. Merge them; do not overwrite another developer’s local modifications. Do not add a second main/router, schema migration, or invented credentials table.

## `internal/models/inventory/identities_list.go`

```go
package inventory

import (
	"encoding/json"
	"time"
)

// Scope is server-resolved; never take AllowedAccountIDs from query parameters.
type Scope struct{ AllowedAccountIDs []string }

type ListFilter struct {
	Scope
	Page, Limit                                                                  int64
	SortBy, SortOrder, Search                                                    string
	IdentityType, FunctionalClass, AccountID, Region, Status, Owner, Environment string
	IsPublic                                                                     *bool
	LastActiveBefore                                                             *time.Time
}

type IdentitySummary struct {
	ID                   string          `json:"id"`
	ARN                  string          `json:"arn"`
	Name                 string          `json:"name"`
	IdentityType         string          `json:"identity_type"`
	FunctionalClass      *string         `json:"functional_class"`
	AccountID            string          `json:"account_id"`
	Region               string          `json:"region"`
	Status               string          `json:"status"`
	CreatedAtAWS         *time.Time      `json:"created_at_aws"`
	LastSeenAt           time.Time       `json:"last_seen_at"`
	LastActivityAt       *time.Time      `json:"last_activity_at"`
	Owner                *string         `json:"owner"`
	Environment          *string         `json:"environment"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
	Tags                 json.RawMessage `json:"tags"`
}

type ListResponse struct {
	Total int64             `json:"total"`
	Page  int64             `json:"page"`
	Limit int64             `json:"limit"`
	Data  []IdentitySummary `json:"data"`
}
```

## `internal/models/inventory/identities_detail.go`

```go
package inventory

import (
	"encoding/json"
	"time"
)

type Network struct {
	VPCID                *string         `json:"vpc_id"`
	SubnetID             *string         `json:"subnet_id"`
	SecurityGroupIDs     json.RawMessage `json:"security_group_ids"`
	IsPubliclyAccessible *bool           `json:"is_publicly_accessible"`
}
type Ownership struct {
	Owner       *string         `json:"owner"`
	Environment *string         `json:"environment"`
	Tags        json.RawMessage `json:"tags"`
}
type Lineage struct {
	ParentARN            *string `json:"parent_arn"`
	CloudTrailCreatorARN *string `json:"cloudtrail_creator_arn"`
}
type Discovery struct {
	DiscoverySource string  `json:"discovery_source"`
	ScanID          *string `json:"scan_id"`
}
type DetailResponse struct {
	ID              string          `json:"id"`
	ARN             string          `json:"arn"`
	Name            string          `json:"name"`
	IdentityType    string          `json:"identity_type"`
	FunctionalClass *string         `json:"functional_class"`
	AccountID       string          `json:"account_id"`
	Region          string          `json:"region"`
	Status          string          `json:"status"`
	CreatedAtAWS    *time.Time      `json:"created_at_aws"`
	FirstSeenAt     time.Time       `json:"first_seen_at"`
	LastSeenAt      time.Time       `json:"last_seen_at"`
	LastActivityAt  *time.Time      `json:"last_activity_at"`
	DeletedAt       *time.Time      `json:"deleted_at"`
	Network         Network         `json:"network"`
	Ownership       Ownership       `json:"ownership"`
	Lineage         Lineage         `json:"lineage"`
	Discovery       Discovery       `json:"discovery"`
	TypeAttributes  json.RawMessage `json:"type_attributes"`
	RawAPIResponse  json.RawMessage `json:"raw_api_response"`
}
```

## `internal/models/inventory/identities_counts.go`

```go
package inventory

type CountsFilter struct {
	Scope
	AccountID, Region, FunctionalClass string
}
type CountsResponse struct {
	Total      int64            `json:"total"`
	Active     int64            `json:"active"`
	Stopped    int64            `json:"stopped"`
	Terminated int64            `json:"terminated"`
	ByType     map[string]int64 `json:"by_type"`
	ByClass    map[string]int64 `json:"by_class"`
}
type CountRow struct {
	Status, IdentityType, FunctionalClass string
	Count                                 int64
}
```

## `internal/models/inventory/identities_attributes.go`

```go
package inventory

import "encoding/json"

type AttributesResponse struct {
	IdentityType   string          `json:"identity_type"`
	TypeAttributes json.RawMessage `json:"type_attributes"`
}
```

## `internal/models/inventory/identities_timeline.go`

```go
package inventory

import "time"

type TimelineRecord struct {
	ARN                     string
	FirstSeenAt, LastSeenAt time.Time
	LastActivityAt          *time.Time
}
type TimelineEvent struct {
	Event     string    `json:"event"`
	Timestamp time.Time `json:"timestamp"`
}
type TimelineResponse struct {
	IdentityARN           string          `json:"identity_arn"`
	Events                []TimelineEvent `json:"events"`
	AgeDays               int64           `json:"age_days"`
	DaysSinceLastActivity *int64          `json:"days_since_last_activity"`
}
```

## `internal/models/inventory/identities_grouped_by_class.go`

```go
package inventory

type GroupFilter struct {
	Scope
	AccountID, Region string
	LimitPerClass     int64
}
type GroupIdentity struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	IdentityType string `json:"identity_type"`
	Status       string `json:"status"`
}
type ClassGroup struct {
	FunctionalClass string          `json:"functional_class"`
	Count           int64           `json:"count"`
	Identities      []GroupIdentity `json:"identities"`
}
type GroupedResponse struct {
	Groups []ClassGroup `json:"groups"`
}
type GroupRow struct {
	FunctionalClass string
	Count           int64
	Identity        GroupIdentity
}
```

## `internal/repository/inventory/identities_list.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

type Repository struct{ db *sql.DB }

func NewRepository(db *sql.DB) *Repository { return &Repository{db: db} }

var ErrEmptyScope = errors.New("inventory account scope empty")

func scoped(ids []string) error {
	if len(ids) == 0 {
		return ErrEmptyScope
	}
	return nil
}
func str(n sql.NullString) *string {
	if !n.Valid {
		return nil
	}
	x := n.String
	return &x
}
func at(n sql.NullTime) *time.Time {
	if !n.Valid {
		return nil
	}
	x := n.Time.UTC()
	return &x
}
func flag(n sql.NullBool) *bool {
	if !n.Valid {
		return nil
	}
	x := n.Bool
	return &x
}
func raw(b []byte) json.RawMessage {
	if b == nil {
		return json.RawMessage("null")
	}
	return json.RawMessage(b)
}

// Escape user search so '%' and '_' are literal, not unbounded SQL wildcards.
func escapeLike(v string) string {
	v = strings.ReplaceAll(v, `\`, `\\`)
	v = strings.ReplaceAll(v, `%`, `\%`)
	return strings.ReplaceAll(v, `_`, `\_`)
}
func listWhere(f m.ListFilter) (string, []any) {
	args := []any{pq.Array(f.AllowedAccountIDs)}
	where := []string{"deleted_at IS NULL", "account_id = ANY($1::text[])"}
	add := func(expr string, v any) { args = append(args, v); where = append(where, fmt.Sprintf(expr, len(args))) }
	for _, p := range []struct{ expr, v string }{
		{"identity_type = $%d", f.IdentityType},
		{"COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') = $%d", f.FunctionalClass},
		{"account_id = $%d", f.AccountID},
		{"COALESCE(NULLIF(BTRIM(region),''),'unknown') = $%d", f.Region},
		{"COALESCE(NULLIF(LOWER(BTRIM(status)),''),'unknown') = $%d", strings.ToLower(f.Status)},
		{"owner = $%d", f.Owner}, {"environment = $%d", f.Environment},
	} {
		if p.v != "" {
			add(p.expr, p.v)
		}
	}
	if f.IsPublic != nil {
		add("is_publicly_accessible = $%d", *f.IsPublic)
	}
	if f.LastActiveBefore != nil {
		add("last_activity_at < $%d", f.LastActiveBefore.UTC())
	}
	if f.Search != "" {
		add("(name ILIKE $%d ESCAPE '\\' OR arn ILIKE $%[1]d ESCAPE '\\')", "%"+escapeLike(f.Search)+"%")
	}
	return strings.Join(where, " AND "), args
}

var sortColumns = map[string]string{
	"id": "id", "name": "name", "identity_type": "identity_type", "functional_class": "functional_class", "account_id": "account_id", "region": "region", "status": "status", "created_at_aws": "created_at_aws", "last_seen_at": "last_seen_at", "last_activity_at": "last_activity_at",
}

func (r *Repository) List(ctx context.Context, f m.ListFilter) (*m.ListResponse, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if r == nil || r.db == nil {
		return nil, fmt.Errorf("inventory db unavailable")
	}
	col, ok := sortColumns[f.SortBy]
	if !ok || (f.SortOrder != "asc" && f.SortOrder != "desc") || f.Page < 1 || f.Limit < 1 || f.Limit > 200 || f.Page > 1_000_000 {
		return nil, fmt.Errorf("invalid repository paging/sort")
	}
	tx, err := r.db.BeginTx(ctx, &sql.TxOptions{Isolation: sql.LevelRepeatableRead, ReadOnly: true})
	if err != nil {
		return nil, fmt.Errorf("begin inventory snapshot: %w", err)
	}
	defer tx.Rollback()
	where, args := listWhere(f)
	var total int64
	if err := tx.QueryRowContext(ctx, "SELECT COUNT(*) FROM nhi_scanner.identities WHERE "+where, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count inventory identities: %w", err)
	}
	direction := strings.ToUpper(f.SortOrder)
	order := col + " " + direction + " NULLS LAST"
	if col != "id" {
		order += ", id ASC"
	}
	query := `SELECT id,arn,name,identity_type,functional_class,account_id,region,status,created_at_aws,last_seen_at,last_activity_at,owner,environment,is_publicly_accessible,tags
           FROM nhi_scanner.identities WHERE ` + where + ` ORDER BY ` + order + fmt.Sprintf(" LIMIT $%d OFFSET $%d", len(args)+1, len(args)+2)
	args = append(args, f.Limit, (f.Page-1)*f.Limit)
	rows, err := tx.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("list inventory identities: %w", err)
	}
	out := &m.ListResponse{Total: total, Page: f.Page, Limit: f.Limit, Data: []m.IdentitySummary{}}
	for rows.Next() {
		var x m.IdentitySummary
		var cls, owner, env sql.NullString
		var created, activity sql.NullTime
		var public sql.NullBool
		var tags []byte
		if err := rows.Scan(&x.ID, &x.ARN, &x.Name, &x.IdentityType, &cls, &x.AccountID, &x.Region, &x.Status, &created, &x.LastSeenAt, &activity, &owner, &env, &public, &tags); err != nil {
			rows.Close()
			return nil, fmt.Errorf("scan inventory list: %w", err)
		}
		x.FunctionalClass = str(cls)
		x.CreatedAtAWS = at(created)
		x.LastActivityAt = at(activity)
		x.Owner = str(owner)
		x.Environment = str(env)
		x.IsPubliclyAccessible = flag(public)
		x.Tags = raw(tags)
		out.Data = append(out.Data, x)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, fmt.Errorf("iterate inventory list: %w", err)
	}
	rows.Close()
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit inventory snapshot: %w", err)
	}
	return out, nil
}
```

## `internal/repository/inventory/identities_detail.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

var ErrNotFound = errors.New("inventory identity not found")

// Detail always constrains UUID and trusted account scope in SQL. A deleted
// identity is indistinguishable from a missing/inaccessible one (404).
func (r *Repository) Detail(ctx context.Context, id string, ids []string) (*m.DetailResponse, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const query = `SELECT id,arn,name,identity_type,functional_class,account_id,region,status,
 created_at_aws,first_seen_at,last_seen_at,last_activity_at,deleted_at,
 vpc_id,subnet_id,security_group_ids,is_publicly_accessible,tags,owner,environment,
 parent_arn,cloudtrail_creator_arn,discovery_source,scan_id,type_attributes,raw_api_response
 FROM nhi_scanner.identities
 WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	var x m.DetailResponse
	var class, vpc, subnet, owner, env, parent, creator, scan sql.NullString
	var created, activity, deleted sql.NullTime
	var pub sql.NullBool
	var groups, tags, attrs, response []byte
	err := r.db.QueryRowContext(ctx, query, id, pq.Array(ids)).Scan(
		&x.ID, &x.ARN, &x.Name, &x.IdentityType, &class, &x.AccountID, &x.Region, &x.Status,
		&created, &x.FirstSeenAt, &x.LastSeenAt, &activity, &deleted,
		&vpc, &subnet, &groups, &pub, &tags, &owner, &env,
		&parent, &creator, &x.Discovery.DiscoverySource, &scan, &attrs, &response)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped inventory detail: %w", err)
	}
	x.FunctionalClass = str(class)
	x.CreatedAtAWS = at(created)
	x.LastActivityAt = at(activity)
	x.DeletedAt = at(deleted)
	x.Network = m.Network{VPCID: str(vpc), SubnetID: str(subnet), SecurityGroupIDs: raw(groups), IsPubliclyAccessible: flag(pub)}
	x.Ownership = m.Ownership{Owner: str(owner), Environment: str(env), Tags: raw(tags)}
	x.Lineage = m.Lineage{ParentARN: str(parent), CloudTrailCreatorARN: str(creator)}
	x.Discovery.ScanID = str(scan)
	x.TypeAttributes = raw(attrs)
	x.RawAPIResponse = raw(response)
	return &x, nil
}
```

## `internal/repository/inventory/identities_counts.go`

```go
package inventory

import (
	"context"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Counts(ctx context.Context, f m.CountsFilter) ([]m.CountRow, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	const q = `SELECT COALESCE(NULLIF(LOWER(BTRIM(status)),''),'unknown'),
 COALESCE(NULLIF(BTRIM(identity_type),''),'unknown'),
 COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified'),COUNT(*)
 FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text)
 AND ($3::text='' OR COALESCE(NULLIF(BTRIM(region),''),'unknown')=$3::text)
 AND ($4::text='' OR COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified')=$4::text)
 GROUP BY 1,2,3 ORDER BY 1,2,3`
	rows, err := r.db.QueryContext(ctx, q, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.FunctionalClass)
	if err != nil {
		return nil, fmt.Errorf("query inventory counts: %w", err)
	}
	defer rows.Close()
	out := make([]m.CountRow, 0)
	for rows.Next() {
		var x m.CountRow
		if err := rows.Scan(&x.Status, &x.IdentityType, &x.FunctionalClass, &x.Count); err != nil {
			return nil, fmt.Errorf("scan inventory counts: %w", err)
		}
		out = append(out, x)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate inventory counts: %w", err)
	}
	return out, nil
}
```

## `internal/repository/inventory/identities_attributes.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Attributes(ctx context.Context, id string, ids []string) (*m.AttributesResponse, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const q = `SELECT identity_type,type_attributes FROM nhi_scanner.identities WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	out := &m.AttributesResponse{}
	var attributes []byte
	if err := r.db.QueryRowContext(ctx, q, id, pq.Array(ids)).Scan(&out.IdentityType, &attributes); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped identity attributes: %w", err)
	}
	out.TypeAttributes = raw(attributes)
	return out, nil
}
```

## `internal/repository/inventory/identities_timeline.go`

```go
package inventory

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Timeline(ctx context.Context, id string, ids []string) (*m.TimelineRecord, error) {
	if err := scoped(ids); err != nil {
		return nil, err
	}
	const q = `SELECT arn,first_seen_at,last_seen_at,last_activity_at FROM nhi_scanner.identities WHERE id=$1::uuid AND account_id=ANY($2::text[]) AND deleted_at IS NULL`
	out := &m.TimelineRecord{}
	var activity sql.NullTime
	if err := r.db.QueryRowContext(ctx, q, id, pq.Array(ids)).Scan(&out.ARN, &out.FirstSeenAt, &out.LastSeenAt, &activity); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("load scoped identity timeline: %w", err)
	}
	out.LastActivityAt = at(activity)
	return out, nil
}
```

## `internal/repository/inventory/identities_grouped_by_class.go`

```go
package inventory

import (
	"context"
	"fmt"
	"github.com/lib/pq"
	m "nhi-backend-api/internal/models/inventory"
)

func (r *Repository) Grouped(ctx context.Context, f m.GroupFilter) ([]m.GroupRow, error) {
	if err := scoped(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	if f.LimitPerClass < 1 || f.LimitPerClass > 100 {
		return nil, fmt.Errorf("invalid per-class limit")
	}
	const q = `WITH ranked AS (
 SELECT COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') AS cls,
 id,name,identity_type,status,
 COUNT(*) OVER(PARTITION BY COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified')) AS group_count,
 ROW_NUMBER() OVER(PARTITION BY COALESCE(NULLIF(BTRIM(functional_class),''),'unclassified') ORDER BY name ASC,id ASC) AS rn
 FROM nhi_scanner.identities WHERE deleted_at IS NULL AND account_id=ANY($1::text[])
 AND ($2::text='' OR account_id=$2::text) AND ($3::text='' OR COALESCE(NULLIF(BTRIM(region),''),'unknown')=$3::text)
 ) SELECT cls,group_count,id,name,identity_type,status FROM ranked WHERE rn<=$4::bigint
 ORDER BY group_count DESC,cls ASC,name ASC,id ASC`
	rows, err := r.db.QueryContext(ctx, q, pq.Array(f.AllowedAccountIDs), f.AccountID, f.Region, f.LimitPerClass)
	if err != nil {
		return nil, fmt.Errorf("query grouped identities: %w", err)
	}
	defer rows.Close()
	out := make([]m.GroupRow, 0)
	for rows.Next() {
		var x m.GroupRow
		if err := rows.Scan(&x.FunctionalClass, &x.Count, &x.Identity.ID, &x.Identity.Name, &x.Identity.IdentityType, &x.Identity.Status); err != nil {
			return nil, fmt.Errorf("scan grouped identities: %w", err)
		}
		out = append(out, x)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate grouped identities: %w", err)
	}
	return out, nil
}
```

## `internal/services/inventory/identities_list.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"nhi-backend-api/internal/models/inventory"
)

var (
	ErrSourceUnavailable = errors.New("inventory source unavailable")
	ErrIncomplete        = errors.New("inventory source incomplete")
	ErrNotFound          = errors.New("identity not found")
)

type Reader interface {
	List(context.Context, inventory.ListFilter) (*inventory.ListResponse, error)
	Detail(context.Context, string, []string) (*inventory.DetailResponse, error)
	Counts(context.Context, inventory.CountsFilter) ([]inventory.CountRow, error)
	Attributes(context.Context, string, []string) (*inventory.AttributesResponse, error)
	Timeline(context.Context, string, []string) (*inventory.TimelineRecord, error)
	Grouped(context.Context, inventory.GroupFilter) ([]inventory.GroupRow, error)
}
type Service struct{ reader Reader }

func NewService(r Reader) *Service { return &Service{reader: r} }
func (s *Service) check(ids []string) error {
	if s == nil || s.reader == nil || len(ids) == 0 {
		return ErrSourceUnavailable
	}
	return nil
}
func (s *Service) List(ctx context.Context, f inventory.ListFilter) (*inventory.ListResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	result, err := s.reader.List(ctx, f)
	if err != nil {
		return nil, err
	}
	if result == nil || result.Data == nil || result.Total < 0 || result.Page != f.Page || result.Limit != f.Limit || int64(len(result.Data)) > f.Limit {
		return nil, ErrIncomplete
	}
	for _, item := range result.Data {
		if item.ID == "" || item.AccountID == "" || !jsonObjectOrNull(item.Tags) {
			return nil, ErrIncomplete
		}
	}
	return result, nil
}

// JSONB is syntactically valid in PostgreSQL, but a JSON scalar/array is not
// an ownership tags map or type-attributes object as required by the PDF.
func jsonObjectOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var obj map[string]json.RawMessage
	return json.Unmarshal(data, &obj) == nil && obj != nil
}
func jsonArrayOrNull(data json.RawMessage) bool {
	if len(data) == 0 || string(data) == "null" {
		return true
	}
	var arr []json.RawMessage
	return json.Unmarshal(data, &arr) == nil && arr != nil
}
func validCount(n int64) error {
	if n < 0 {
		return ErrIncomplete
	}
	return nil
}
func checkedAdd(a, b int64) (int64, error) {
	if err := validCount(b); err != nil {
		return 0, err
	}
	if b > math.MaxInt64-a {
		return 0, fmt.Errorf("%w: count overflow", ErrIncomplete)
	}
	return a + b, nil
}
```

## `internal/services/inventory/identities_detail.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	inventory "nhi-backend-api/internal/models/inventory"
	"strings"
)

func (s *Service) Detail(ctx context.Context, id string, ids []string) (*inventory.DetailResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	out, err := s.reader.Detail(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if out == nil || !strings.EqualFold(out.ID, id) || out.AccountID == "" || out.DeletedAt != nil ||
		!jsonObjectOrNull(out.Ownership.Tags) || !jsonObjectOrNull(out.TypeAttributes) ||
		!jsonArrayOrNull(out.Network.SecurityGroupIDs) ||
		(len(out.RawAPIResponse) > 0 && !json.Valid(out.RawAPIResponse)) {
		return nil, ErrIncomplete
	}
	return out, nil
}
```

## `internal/services/inventory/identities_counts.go`

```go
package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Counts(ctx context.Context, f m.CountsFilter) (*m.CountsResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	rows, err := s.reader.Counts(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.CountsResponse{ByType: map[string]int64{}, ByClass: map[string]int64{}}
	for _, r := range rows {
		if r.Status == "" || r.IdentityType == "" || r.FunctionalClass == "" {
			return nil, ErrIncomplete
		}
		if out.Total, err = checkedAdd(out.Total, r.Count); err != nil {
			return nil, err
		}
		switch r.Status {
		case "active":
			out.Active, err = checkedAdd(out.Active, r.Count)
		case "stopped":
			out.Stopped, err = checkedAdd(out.Stopped, r.Count)
		case "terminated":
			out.Terminated, err = checkedAdd(out.Terminated, r.Count)
		}
		if err != nil {
			return nil, err
		}
		if out.ByType[r.IdentityType], err = checkedAdd(out.ByType[r.IdentityType], r.Count); err != nil {
			return nil, err
		}
		if out.ByClass[r.FunctionalClass], err = checkedAdd(out.ByClass[r.FunctionalClass], r.Count); err != nil {
			return nil, err
		}
	}
	return out, nil
}
```

## `internal/services/inventory/identities_attributes.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Attributes(ctx context.Context, id string, ids []string) (*m.AttributesResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	out, err := s.reader.Attributes(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if out == nil || out.IdentityType == "" {
		return nil, ErrIncomplete
	}
	if len(out.TypeAttributes) > 0 && string(out.TypeAttributes) != "null" {
		var shape map[string]json.RawMessage
		if json.Unmarshal(out.TypeAttributes, &shape) != nil || shape == nil {
			return nil, ErrIncomplete
		}
	}
	return out, nil
}
```

## `internal/services/inventory/identities_timeline.go`

```go
package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
	"time"
)

func (s *Service) Timeline(ctx context.Context, id string, ids []string) (*m.TimelineResponse, error) {
	if err := s.check(ids); err != nil {
		return nil, err
	}
	row, err := s.reader.Timeline(ctx, id, ids)
	if err != nil {
		return nil, err
	}
	if row == nil || row.ARN == "" {
		return nil, ErrIncomplete
	}
	now := time.Now().UTC()
	if row.FirstSeenAt.After(now) || row.LastSeenAt.After(now) || row.LastSeenAt.Before(row.FirstSeenAt) {
		return nil, ErrIncomplete
	}
	out := &m.TimelineResponse{IdentityARN: row.ARN, Events: []m.TimelineEvent{{Event: "first_discovered", Timestamp: row.FirstSeenAt.UTC()}}, AgeDays: int64(now.Sub(row.FirstSeenAt).Hours() / 24)}
	if row.LastActivityAt != nil {
		if row.LastActivityAt.After(now) {
			return nil, ErrIncomplete
		}
		n := int64(now.Sub(*row.LastActivityAt).Hours() / 24)
		out.DaysSinceLastActivity = &n
		out.Events = append(out.Events, m.TimelineEvent{Event: "last_activity", Timestamp: row.LastActivityAt.UTC()})
	}
	out.Events = append(out.Events, m.TimelineEvent{Event: "last_confirmed", Timestamp: row.LastSeenAt.UTC()})
	return out, nil
}
```

## `internal/services/inventory/identities_grouped_by_class.go`

```go
package inventory

import (
	"context"
	m "nhi-backend-api/internal/models/inventory"
)

func (s *Service) Grouped(ctx context.Context, f m.GroupFilter) (*m.GroupedResponse, error) {
	if err := s.check(f.AllowedAccountIDs); err != nil {
		return nil, err
	}
	rows, err := s.reader.Grouped(ctx, f)
	if err != nil {
		return nil, err
	}
	if rows == nil {
		return nil, ErrIncomplete
	}
	out := &m.GroupedResponse{Groups: []m.ClassGroup{}}
	idx := map[string]int{}
	for _, r := range rows {
		if r.FunctionalClass == "" || r.Count <= 0 || r.Identity.ID == "" {
			return nil, ErrIncomplete
		}
		n, ok := idx[r.FunctionalClass]
		if !ok {
			n = len(out.Groups)
			idx[r.FunctionalClass] = n
			out.Groups = append(out.Groups, m.ClassGroup{FunctionalClass: r.FunctionalClass, Count: r.Count, Identities: []m.GroupIdentity{}})
		}
		if out.Groups[n].Count != r.Count || int64(len(out.Groups[n].Identities)) >= f.LimitPerClass {
			return nil, ErrIncomplete
		}
		out.Groups[n].Identities = append(out.Groups[n].Identities, r.Identity)
	}
	return out, nil
}
```

## `internal/handlers/inventory/identities_list.go`

```go
package inventory

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/mux"
	"github.com/lib/pq"
	"nhi-backend-api/internal/middleware"
	m "nhi-backend-api/internal/models/inventory"
	repo "nhi-backend-api/internal/repository/inventory"
	svc "nhi-backend-api/internal/services/inventory"
	appjwt "nhi-backend-api/pkg/jwt"
)

type AccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}
type Handler struct {
	service *svc.Service
	scope   AccountScope
}

func NewHandler(service *svc.Service, scope AccountScope) *Handler {
	return &Handler{service: service, scope: scope}
}

var accountID = regexp.MustCompile(`^[0-9]{12}$`)
var uuid = regexp.MustCompile(`(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$`)
var token = regexp.MustCompile(`^[a-zA-Z0-9_-]{1,100}$`)
var region = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
var sorts = map[string]bool{"id": true, "name": true, "identity_type": true, "functional_class": true, "account_id": true, "region": true, "status": true, "created_at_aws": true, "last_seen_at": true, "last_activity_at": true}

type apiError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func writeError(w http.ResponseWriter, status int, code, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	var body apiError
	body.Error.Code, body.Error.Message = code, msg
	b, _ := json.Marshal(body)
	w.WriteHeader(status)
	_, _ = w.Write(append(b, '\n'))
}
func writeOK(w http.ResponseWriter, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("inventory: encode response: %v", err)
		writeError(w, 500, "INTERNAL_ERROR", "Unable to encode inventory response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(200)
	_, _ = w.Write(append(b, '\n'))
}
func writeServiceError(w http.ResponseWriter, err error) {
	if errors.Is(err, svc.ErrNotFound) || errors.Is(err, repo.ErrNotFound) {
		writeError(w, 404, "NOT_FOUND", "Identity not found")
		return
	}
	if errors.Is(err, context.Canceled) {
		return
	}
	if errors.Is(err, context.DeadlineExceeded) {
		writeError(w, 504, "TIMEOUT", "Inventory request timed out")
		return
	}
	if errors.Is(err, svc.ErrSourceUnavailable) || errors.Is(err, svc.ErrIncomplete) || errors.Is(err, repo.ErrEmptyScope) {
		writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
		return
	}
	var pg *pq.Error
	if errors.As(err, &pg) {
		c := string(pg.Code)
		if c == "42P01" || c == "42703" || c == "42501" || strings.HasPrefix(c, "08") || c == "53300" || c == "57P01" {
			log.Printf("inventory source unavailable sqlstate=%s", c)
			writeError(w, 503, "DATA_SOURCE_UNAVAILABLE", "Required inventory data source is not ready")
			return
		}
	}
	// The wrapped DB error might contain user filters or scanner values; log only
	// its type/SQLSTATE, never its raw message or SQL text.
	if errors.As(err, &pg) {
		log.Printf("inventory internal database error sqlstate=%s", pg.Code)
	} else {
		log.Printf("inventory internal error type=%T", err)
	}
	writeError(w, 500, "INTERNAL_ERROR", "Unable to load inventory data")
}
func (h *Handler) authorize(w http.ResponseWriter, r *http.Request, requested string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, 401, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if h == nil || h.service == nil || h.scope == nil {
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := h.scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		log.Printf("inventory account scope unavailable: %T", err)
		writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		writeError(w, 403, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	found := requested == ""
	for _, id := range ids {
		if !accountID.MatchString(id) {
			writeError(w, 503, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
		if id == requested {
			found = true
		}
	}
	if !found {
		writeError(w, 403, "FORBIDDEN", "AWS account is not authorized")
		return nil, false
	}
	return ids, true
}
func params(r *http.Request, allowed ...string) (map[string]string, bool) {
	q, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allow := map[string]bool{}
	for _, key := range allowed {
		allow[key] = true
	}
	out := map[string]string{}
	for key, values := range q {
		if !allow[key] || len(values) != 1 || values[0] == "" || len(values[0]) > 256 {
			return nil, false
		}
		out[key] = values[0]
	}
	if a := out["account_id"]; a != "" && !accountID.MatchString(a) {
		return nil, false
	}
	if z := out["region"]; z != "" && !region.MatchString(z) {
		return nil, false
	}
	for _, key := range []string{"identity_type", "functional_class", "status"} {
		if v := out[key]; v != "" && !token.MatchString(v) {
			return nil, false
		}
	}
	for _, val := range out {
		if strings.ContainsAny(val, "\x00\r\n") {
			return nil, false
		}
	}
	return out, true
}
func pathID(r *http.Request) (string, bool) { v := mux.Vars(r)["id"]; return v, uuid.MatchString(v) }
func parseBound(v string, def, max int64) (int64, bool) {
	if v == "" {
		return def, true
	}
	n, err := strconv.ParseInt(v, 10, 64)
	return n, err == nil && n >= 1 && n <= max
}

// A1: paged inventory list, exact PDF filters. No deleted row is ever shown.
func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "page", "limit", "sort_by", "sort_order", "search", "identity_type", "functional_class", "account_id", "region", "status", "owner", "environment", "is_public", "last_active_before")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid identity filters")
		return
	}
	page, ok1 := parseBound(p["page"], 1, 1_000_000)
	limit, ok2 := parseBound(p["limit"], 50, 200)
	if !ok1 || !ok2 {
		writeError(w, 400, "INVALID_FILTER", "Invalid pagination")
		return
	}
	sortBy := p["sort_by"]
	if sortBy == "" {
		sortBy = "last_seen_at"
	}
	sortOrder := strings.ToLower(p["sort_order"])
	if sortOrder == "" {
		sortOrder = "desc"
	}
	if !sorts[sortBy] || (sortOrder != "asc" && sortOrder != "desc") {
		writeError(w, 400, "INVALID_FILTER", "Invalid sort field or order")
		return
	}
	f := m.ListFilter{Page: page, Limit: limit, SortBy: sortBy, SortOrder: sortOrder, Search: p["search"], IdentityType: p["identity_type"], FunctionalClass: p["functional_class"], AccountID: p["account_id"], Region: p["region"], Status: p["status"], Owner: p["owner"], Environment: p["environment"]}
	if b := p["is_public"]; b != "" {
		if b != "true" && b != "false" {
			writeError(w, 400, "INVALID_FILTER", "is_public must be true or false")
			return
		}
		v := b == "true"
		f.IsPublic = &v
	}
	if t := p["last_active_before"]; t != "" {
		v, e := time.Parse(time.RFC3339Nano, t)
		if e != nil {
			writeError(w, 400, "INVALID_FILTER", "last_active_before must be RFC3339")
			return
		}
		v = v.UTC()
		f.LastActiveBefore = &v
	}
	ids, ok := h.authorize(w, r, f.AccountID)
	if !ok {
		return
	}
	f.AllowedAccountIDs = ids
	out, err := h.service.List(r.Context(), f)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_detail.go`

```go
package inventory

import "net/http"

// A2: absent, deleted and out-of-scope identities are indistinguishable 404s.
func (h *Handler) Detail(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected detail filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Detail(r.Context(), id, ids)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_counts.go`

```go
package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

func (h *Handler) Counts(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "account_id", "region", "functional_class")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid counts filters")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Counts(r.Context(), m.CountsFilter{Scope: m.Scope{AllowedAccountIDs: ids}, AccountID: p["account_id"], Region: p["region"], FunctionalClass: p["functional_class"]})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_attributes.go`

```go
package inventory

import "net/http"

func (h *Handler) Attributes(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected attributes filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Attributes(r.Context(), id, ids)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_timeline.go`

```go
package inventory

import "net/http"

func (h *Handler) Timeline(w http.ResponseWriter, r *http.Request) {
	if _, ok := params(r); !ok {
		writeError(w, 400, "INVALID_FILTER", "Unexpected timeline filter")
		return
	}
	id, ok := pathID(r)
	if !ok {
		writeError(w, 400, "INVALID_ID", "Identity ID must be a UUID")
		return
	}
	ids, ok := h.authorize(w, r, "")
	if !ok {
		return
	}
	out, err := h.service.Timeline(r.Context(), id, ids)
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/inventory/identities_grouped_by_class.go`

```go
package inventory

import (
	"net/http"
	m "nhi-backend-api/internal/models/inventory"
)

func (h *Handler) Grouped(w http.ResponseWriter, r *http.Request) {
	p, ok := params(r, "account_id", "region", "limit_per_class")
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid grouped filters")
		return
	}
	limit, ok := parseBound(p["limit_per_class"], 10, 100)
	if !ok {
		writeError(w, 400, "INVALID_FILTER", "Invalid limit_per_class")
		return
	}
	ids, ok := h.authorize(w, r, p["account_id"])
	if !ok {
		return
	}
	out, err := h.service.Grouped(r.Context(), m.GroupFilter{Scope: m.Scope{AllowedAccountIDs: ids}, AccountID: p["account_id"], Region: p["region"], LimitPerClass: limit})
	if err != nil {
		writeServiceError(w, err)
		return
	}
	writeOK(w, out)
}
```

## `internal/handlers/dashboard/identities_by_class.go`

```go
package dashboard

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/lib/pq"
	"log"
	"net/http"
	"net/url"
	"nhi-backend-api/internal/middleware"
	identitymodels "nhi-backend-api/internal/models/dashboard"
	identityservices "nhi-backend-api/internal/services/dashboard"
	appjwt "nhi-backend-api/pkg/jwt"
	"regexp"
)

// DashboardAccountScope must resolve permitted AWS account IDs from a trusted
// server-side policy. The existing JWT does NOT contain an account allowlist.
// Do not supply a default "all accounts" implementation without authorization.
type DashboardAccountScope interface {
	AllowedAccountIDs(context.Context, *appjwt.CustomClaims) ([]string, error)
}

type DashboardBreakdownHandler struct {
	service *identityservices.DashboardBreakdownService
	scope   DashboardAccountScope
}

func NewDashboard345Handler(service *identityservices.DashboardBreakdownService, scope DashboardAccountScope) *DashboardBreakdownHandler {
	return &DashboardBreakdownHandler{service: service, scope: scope}
}

// DashboardAccountIDReader is the trusted server-side list of AWS accounts.
// Do not populate it from a request parameter or from an unverified JWT claim.
type DashboardAccountIDReader interface {
	AllKnownAccountIDs(context.Context) ([]string, error)
}

// DashboardAllAccountsScope implements the explicitly approved policy A:
// every authenticated dashboard user may read all known AWS accounts.
// Revisit this policy before introducing per-user or per-team restrictions.
type DashboardAllAccountsScope struct{ reader DashboardAccountIDReader }

func NewDashboardAllAccountsScope(reader DashboardAccountIDReader) *DashboardAllAccountsScope {
	return &DashboardAllAccountsScope{reader: reader}
}

func (s *DashboardAllAccountsScope) AllowedAccountIDs(ctx context.Context, claims *appjwt.CustomClaims) ([]string, error) {
	if s == nil || s.reader == nil || claims == nil || claims.UserID <= 0 {
		return nil, errors.New("authenticated dashboard account scope unavailable")
	}
	return s.reader.AllKnownAccountIDs(ctx)
}

var (
	accountIDPattern        = regexp.MustCompile(`^[0-9]{12}$`)
	regionPattern           = regexp.MustCompile(`^[a-z0-9-]{1,64}$`)
	identityTypePattern     = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
	credentialStatusPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,63}$`)
	functionalClassPattern  = regexp.MustCompile(`^[a-z0-9_-]{1,100}$`)
)

type dashboardError struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func dashboardWriteError(w http.ResponseWriter, status int, code, message string) {
	var payload dashboardError
	payload.Error.Code, payload.Error.Message = code, message
	data, _ := json.Marshal(payload) // this static string-only struct cannot fail
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_, _ = w.Write(append(data, '\n'))
}

// Encode before committing HTTP 200. A malformed service result must not
// produce a partial successful response or silently swallow marshal errors.
func dashboardWriteOK(w http.ResponseWriter, result interface{}) {
	data, err := json.Marshal(result)
	if err != nil {
		log.Printf("dashboard response serialization failed: %T", err)
		dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to encode dashboard response")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(append(data, '\n'))
}

func dashboardParams(r *http.Request, allowed ...string) (map[string]string, bool) {
	params, err := url.ParseQuery(r.URL.RawQuery)
	if err != nil {
		return nil, false
	}
	allowedSet := make(map[string]bool, len(allowed))
	for _, key := range allowed {
		allowedSet[key] = true
	}
	result := make(map[string]string, len(params))
	for key, vals := range params {
		if !allowedSet[key] || len(vals) != 1 {
			return nil, false
		}
		result[key] = vals[0]
	}
	if s := result["account_id"]; s != "" && !accountIDPattern.MatchString(s) {
		return nil, false
	}
	if s := result["region"]; s != "" && !regionPattern.MatchString(s) {
		return nil, false
	}
	if s := result["identity_type"]; s != "" && !identityTypePattern.MatchString(s) {
		return nil, false
	}
	if s := result["status"]; s != "" && !credentialStatusPattern.MatchString(s) {
		return nil, false
	}
	if s := result["functional_class"]; s != "" && !functionalClassPattern.MatchString(s) {
		return nil, false
	}
	return result, true
}

// dashboardAuthorizedAccounts returns an explicit server-side account scope.
// No URL-supplied account ID can expand it. These checks remain even if the
// integrator temporarily mis-mounts the route outside the JWT middleware.
func (h *DashboardBreakdownHandler) dashboardAuthorizedAccounts(w http.ResponseWriter, r *http.Request, requestedAccount string) ([]string, bool) {
	if h == nil {
		return dashboardAuthorizedAccountsFor(w, r, nil, false, requestedAccount)
	}
	return dashboardAuthorizedAccountsFor(w, r, h.scope, h.service != nil, requestedAccount)
}

// Shared policy check for identity and credential dashboard endpoints.
// A configured service is required before any query; no caller can replace
// the server-resolved scope with an account_id taken from the query string.
func dashboardAuthorizedAccountsFor(w http.ResponseWriter, r *http.Request, scope DashboardAccountScope, serviceConfigured bool, requestedAccount string) ([]string, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		dashboardWriteError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return nil, false
	}
	if scope == nil || !serviceConfigured {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	ids, err := scope.AllowedAccountIDs(r.Context(), claims)
	if err != nil {
		dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
		return nil, false
	}
	if len(ids) == 0 {
		dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "No AWS accounts are authorized")
		return nil, false
	}
	// An invalid policy result is an integration error, never an expanded scope.
	for _, id := range ids {
		if !accountIDPattern.MatchString(id) {
			dashboardWriteError(w, http.StatusServiceUnavailable, "ACCESS_POLICY_UNAVAILABLE", "Account access policy unavailable")
			return nil, false
		}
	}
	if requestedAccount != "" {
		found := false
		for _, id := range ids {
			if id == requestedAccount {
				found = true
				break
			}
		}
		if !found {
			dashboardWriteError(w, http.StatusForbidden, "FORBIDDEN", "AWS account is not authorized")
			return nil, false
		}
	}
	return ids, true
}

func dashboardServiceError(w http.ResponseWriter, err error) {
	if errors.Is(err, context.Canceled) {
		return
	} // client disconnected; do not write again
	if errors.Is(err, context.DeadlineExceeded) {
		dashboardWriteError(w, http.StatusGatewayTimeout, "TIMEOUT", "Dashboard request timed out")
		return
	}
	if errors.Is(err, identityservices.ErrDashboardSourceUnavailable) || errors.Is(err, identityservices.ErrDashboardSourceIncomplete) {
		dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
		return
	}
	var pg *pq.Error
	if errors.As(err, &pg) {
		state := string(pg.Code)
		if state == "42P01" || state == "42703" || state == "42501" || state == "53300" || state == "57P01" || len(state) >= 2 && state[:2] == "08" {
			log.Printf("dashboard data source unavailable sqlstate=%s", state)
			dashboardWriteError(w, http.StatusServiceUnavailable, "DATA_SOURCE_UNAVAILABLE", "Required dashboard data source is not ready")
			return
		}
		log.Printf("dashboard database error sqlstate=%s", state)
	} else {
		log.Printf("dashboard internal error: %T", err)
	}
	dashboardWriteError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Unable to load dashboard data")
}

// ByClass implements GET /api/v1/dashboard/identities/by-class.
func (h *DashboardBreakdownHandler) ByClass(w http.ResponseWriter, r *http.Request) {
	params, ok := dashboardParams(r, "account_id", "region")
	if !ok {
		dashboardWriteError(w, http.StatusBadRequest, "INVALID_FILTER", "Invalid by-class filters")
		return
	}
	accounts, ok := h.dashboardAuthorizedAccounts(w, r, params["account_id"])
	if !ok {
		return
	}
	result, err := h.service.ByClass(r.Context(), identitymodels.ClassFilter{
		AccountID: params["account_id"], Region: params["region"], AllowedAccountIDs: accounts,
	})
	if err != nil {
		dashboardServiceError(w, err)
		return
	}
	dashboardWriteOK(w, result)
}
```

## `cmd/api-server/main.go`

```go
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	dashrepo "nhi-backend-api/internal/repository/dashboard"
	inventoryrepo "nhi-backend-api/internal/repository/inventory"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/services"
	dashservices "nhi-backend-api/internal/services/dashboard"
	inventoryservices "nhi-backend-api/internal/services/inventory"
)

func main() {
	fmt.Println("╔══════════════════════════════════════════╗")
	fmt.Println("║     NHI Discovery — Backend API Server   ║")
	fmt.Println("║     Identity Management Platform         ║")
	fmt.Println("╚══════════════════════════════════════════╝")
	fmt.Println()

	// 1. Load Configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("❌ Failed to load config: %v", err)
	}
	fmt.Println("✅ Configuration loaded")

	// 2. Initialize PostgreSQL Database
	db, err := repository.NewPostgresDB(&cfg.Database)
	if err != nil {
		log.Fatalf("❌ Database connection failed: %v", err)
	}
	defer db.Close()

	// 3. Initialize Repositories
	userRepo := repository.NewUserRepository(db)
	identityRepo := repository.NewIdentityRepository(db)
	scanRepo := repository.NewScanRepository(db)
	dashboardRepo := repository.NewDashboardRepository(db)
	eventRepo := repository.NewEventRepository(db)
	credentialRepo := repository.NewCredentialRepository(db)
	lineageRepo := repository.NewLineageRepository(db)

	// ── NEW: Consumer Repository ──
	consumerRepo := repository.NewConsumerRepository(db)

	lineageService := services.NewLineageService(lineageRepo)
	lineageHandler := handlers.NewLineageHandler(lineageService)

	// 4. Initialize Services
	authService := services.NewAuthService(userRepo, cfg.JWT)
	identityService := services.NewIdentityService(identityRepo)
	dashboardService := services.NewDashboardService(dashboardRepo, identityRepo)
	scanService := services.NewScanService(scanRepo)
	credentialService := services.NewCredentialService(credentialRepo)

	// ── NEW: Consumer Service ──
	consumerService := services.NewConsumerService(consumerRepo)

	// 5. Initialize Handlers & Middleware
	authHandler := handlers.NewAuthHandler(authService)
	dashboardHandler := handlers.NewDashboardHandler(dashboardService)

	// ── UPDATED: Added consumerService to IdentityHandler ──
	identityHandler := handlers.NewIdentityHandler(identityService, consumerService)

	secretHandler := handlers.NewSecretHandler(identityService)
	scanHandler := handlers.NewScanHandler(scanService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT)
	eventHandler := handlers.NewEventHandler(eventRepo)
	credentialHandler := handlers.NewCredentialHandler(credentialService)

	// Dashboard APIs #1–#8 share approved policy A: every JWT-authenticated
	// dashboard user may see all known AWS accounts. The resolver reads the
	// catalog and scan targets; URL parameters NEVER supply the scope.
	// #1 has explicit nulls for unavailable cards; #4/#5 credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	dashboard345Repo := dashrepo.NewDashboardBreakdownRepository(db.DB)
	dashboard345Scope := dashhandlers.NewDashboardAllAccountsScope(dashboard345Repo)
	dashboard345Service := dashservices.NewDashboardBreakdownService(dashboard345Repo)
	dashboard345Handler := dashhandlers.NewDashboard345Handler(dashboard345Service, dashboard345Scope)
	dashboardCredentialRepo := dashrepo.NewDashboardCredentialRepository(db.DB)
	dashboardCredentialService := dashservices.NewDashboardCredentialService(dashboardCredentialRepo)
	dashboardCredentialHandler := dashhandlers.NewDashboardCredentialHandler(dashboardCredentialService, dashboard345Scope)

	// Inventory A1–A6 uses the same approved JWT/account scope; all inventory
	// reads are constrained to current identities in nhi_scanner.identities.
	inventoryRepository := inventoryrepo.NewRepository(db.DB)
	inventoryService := inventoryservices.NewService(inventoryRepository)
	inventoryHandler := inventoryhandlers.NewHandler(inventoryService, dashboard345Scope)

	// 6. Setup Routes
	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                authHandler,
		DashboardHandler:           dashboardHandler,
		Dashboard345Handler:        dashboard345Handler,
		DashboardCredentialHandler: dashboardCredentialHandler,
		InventoryHandler:           inventoryHandler,
		IdentityHandler:            identityHandler,
		SecretHandler:              secretHandler,
		ScanHandler:                scanHandler,
		AuthMiddleware:             authMiddleware,
		EventHandler:               eventHandler,
		LineageHandler:             lineageHandler,
		CredentialHandler:          credentialHandler,
	})

	// 7. Apply CORS
	corsHandler := middleware.SetupCORS(cfg.CORS)(router)

	// 8. Start HTTP Server
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      corsHandler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("\n🚀 NHI API Server running on http://localhost:%d\n\n", cfg.Server.Port)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("❌ Server error: %v", err)
	}
}
```

## `internal/routes/routes.go`

```go
// internal/routes/routes.go
package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	dashhandlers "nhi-backend-api/internal/handlers/dashboard"
	inventoryhandlers "nhi-backend-api/internal/handlers/inventory"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler                *handlers.AuthHandler
	DashboardHandler           *handlers.DashboardHandler
	Dashboard345Handler        *dashhandlers.DashboardBreakdownHandler
	DashboardCredentialHandler *dashhandlers.DashboardCredentialHandler
	InventoryHandler           *inventoryhandlers.Handler
	IdentityHandler            *handlers.IdentityHandler
	SecretHandler              *handlers.SecretHandler
	ScanHandler                *handlers.ScanHandler
	EventHandler               *handlers.EventHandler
	CredentialHandler          *handlers.CredentialHandler
	LineageHandler             *handlers.LineageHandler
	AuthMiddleware             *middleware.AuthMiddleware
}

// SetupRoutes registers all API routes and applies security middleware
func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()

	// Global Middleware
	r.Use(middleware.RequestLogger)

	// Health check
	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","service":"nhi-backend-api"}`))
	}).Methods("GET")

	api := r.PathPrefix("/api").Subrouter()

	// ==========================================
	// PUBLIC ROUTES (No JWT required)
	// ==========================================
	api.HandleFunc("/auth/login", h.AuthHandler.Login).Methods("POST")

	// ==========================================
	// PROTECTED ROUTES (JWT token required)
	// ==========================================
	protected := api.PathPrefix("").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)

	// Auth Profile
	protected.HandleFunc("/auth/me", h.AuthHandler.Me).Methods("GET")

	// 1. Dashboard & My Resources
	protected.HandleFunc("/dashboard/summary", h.DashboardHandler.Summary).Methods("GET")
	protected.HandleFunc("/dashboard/my-resources", h.DashboardHandler.MyResources).Methods("GET")

	// Dashboard APIs #1–#8; distinct from the legacy /api/dashboard/* routes.
	// Requires JWT and approved policy A (authenticated users see known accounts).
	// #1 is a partial null-aware response; #4/#5 have credential_count:null;
	// #6/#7 return 503 pending credentials; #8 has not_in_iac:null.
	if h.Dashboard345Handler != nil {
		protected.HandleFunc("/v1/dashboard/summary", middleware.RecoverV1(h.Dashboard345Handler.Summary)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-type", middleware.RecoverV1(h.Dashboard345Handler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-class", middleware.RecoverV1(h.Dashboard345Handler.ByClass)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-account", middleware.RecoverV1(h.Dashboard345Handler.ByAccount)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/by-region", middleware.RecoverV1(h.Dashboard345Handler.ByRegion)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/identities/exposure", middleware.RecoverV1(h.Dashboard345Handler.Exposure)).Methods("GET")
	}
	// PDF APIs #6/#7: protected credential dashboard routes. Until their
	// authoritative table and metric definitions exist, requests fail as 503.
	if h.DashboardCredentialHandler != nil {
		protected.HandleFunc("/v1/dashboard/credentials/by-type", middleware.RecoverV1(h.DashboardCredentialHandler.ByType)).Methods("GET")
		protected.HandleFunc("/v1/dashboard/credentials/hygiene", middleware.RecoverV1(h.DashboardCredentialHandler.Hygiene)).Methods("GET")
	}

	// Inventory A1–A9, using the same JWT and account scope as dashboard.
	// Static routes precede the UUID detail route so counts/groups/dormant/export
	// are not mistaken for identity IDs. Legacy /api/identities is unchanged.
	if h.InventoryHandler != nil {
		protected.HandleFunc("/v1/inventory/identities/counts", middleware.RecoverV1(h.InventoryHandler.Counts)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/grouped-by-class", middleware.RecoverV1(h.InventoryHandler.Grouped)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/dormant", middleware.RecoverV1(h.InventoryHandler.Dormant)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/export", middleware.RecoverV1(h.InventoryHandler.Export)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities", middleware.RecoverV1(h.InventoryHandler.List)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/attributes", middleware.RecoverV1(h.InventoryHandler.Attributes)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}/timeline", middleware.RecoverV1(h.InventoryHandler.Timeline)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Detail)).Methods("GET")
		protected.HandleFunc("/v1/inventory/identities/{id}", middleware.RecoverV1(h.InventoryHandler.Update)).Methods("PATCH")
	}

	// 2. NHI Inventory Explorer, Service Access Lineage & Role Consumers
	protected.HandleFunc("/identities", h.IdentityHandler.List).Methods("GET")
	protected.HandleFunc("/identities/lineage", h.LineageHandler.GetServiceAccess).Methods("GET")
	protected.HandleFunc("/identities/consumers", h.IdentityHandler.Consumers).Methods("GET") // ── NEW ──

	// 3. Secrets & Credentials View
	protected.HandleFunc("/secrets", h.SecretHandler.List).Methods("GET")
	protected.HandleFunc("/credentials", h.CredentialHandler.List).Methods("GET")

	// 4. Scan History
	protected.HandleFunc("/scans", h.ScanHandler.List).Methods("GET")

	// 5. CloudTrail Events
	protected.HandleFunc("/events", h.EventHandler.List).Methods("GET")

	return r
}
```

## `internal/middleware/recover_v1.go`

```go
package middleware

import (
	"log"
	"net/http"
)

type v1Writer struct {
	http.ResponseWriter
	started bool
}

func (w *v1Writer) WriteHeader(code int) { w.started = true; w.ResponseWriter.WriteHeader(code) }
func (w *v1Writer) Write(data []byte) (int, error) {
	w.started = true
	return w.ResponseWriter.Write(data)
}

// RecoverV1 confines panic recovery to newly implemented v1 GET endpoints;
// existing legacy API response contracts are left untouched. Never print the
// recovered value: it might contain raw scanner or database information.
func RecoverV1(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tracked := &v1Writer{ResponseWriter: w}
		defer func() {
			if recovered := recover(); recovered != nil {
				log.Printf("v1 API panic recovered: %T", recovered)
				if tracked.started {
					return
				} // cannot replace an already committed response
				w.Header().Set("Content-Type", "application/json")
				w.Header().Set("Cache-Control", "no-store")
				w.WriteHeader(http.StatusInternalServerError)
				_, _ = w.Write([]byte(`{"error":{"code":"INTERNAL_ERROR","message":"Unable to load API data"}}` + "\n"))
			}
		}()
		next(tracked, r)
	}
}
```

## Tests and validation

The full project ZIP includes the route error matrix and optional `internal/repository/inventory/identities_integration_test.go`. Go 1.26.5: `go test ./... && go vet ./...`. The integration fixture CREATES/TRUNCATES: run **only** on a disposable database whose name ends in `_test`, never `nhi_db`.
