# Complete backend structure

This is a **full backend project**, not just a dashboard-folder overlay. It retains the pre-existing single `cmd/api-server/main.go`, `internal/routes/routes.go`, configurations, SQL migrations, shared packages, and legacy API handlers.

```text
cmd/api-server/main.go                  # single existing entry point; dashboard dependency wiring
configs/                                # config template; no runtime secrets bundled
internal/handlers/dashboard/            # 14 flat, endpoint-named dashboard files + tests/helpers
internal/models/dashboard/              # 14 flat, endpoint-named dashboard files + helpers
internal/repository/dashboard/          # 14 flat, endpoint-named dashboard files + tests/helpers
internal/services/dashboard/            # 14 flat, endpoint-named dashboard files + tests/helpers
internal/{handlers,models,repository,services}/inventory/
                                         # nine A1–A9 endpoint files directly per layer
internal/routes/routes.go               # one protected central router
internal/{config,handlers,middleware,models,repository,services}/
                                         # other existing backend code retained
migrations/                              # existing SQL migrations retained
pkg/                                     # existing shared Go packages retained
docs/                                    # source PDF and integration notes
go.mod, go.sum, README.md
```

Inventory A1–A9 and Dashboard #1–#8 are registered; the other six dashboard endpoints remain placeholders. Inventory A1–A8 are read-only; A9 is a scoped PATCH. All inventory endpoints exclude deleted identities. JWT is required; dashboard account scope follows user-approved policy A. #1 is a partial, explicit-null 200 summary; #2 returns real identity counts; #4/#5 expose `credential_count:null`; #6/#7 return 503 until the credential table exists; #8 exposes `not_in_iac:null`. See [integration status](INTEGRATION_STATUS.md), [#1/#2 contract](docs/API_1_2_SUMMARY_AND_IDENTITY_TYPE.md), [#6/#7 limitations](docs/API_6_7_CREDENTIALS_PENDING_SOURCE.md), and [#8 analysis](docs/API_8_EXPOSURE_ANALYSIS.md). `configs/config.yaml` is deliberately not bundled: create it from `configs/config.example.yaml` and provide secrets securely.
