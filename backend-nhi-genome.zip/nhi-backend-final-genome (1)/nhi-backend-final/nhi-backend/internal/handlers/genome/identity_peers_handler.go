package genome

import (
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"

	"nhi-backend-api/internal/middleware"
	models "nhi-backend-api/internal/models/genome"
	svc "nhi-backend-api/internal/services/genome"
)

// IdentityPeersHandler serves
// GET /api/v1/identities/{source_type}/{identity_name}/peers
// (backend_api_contract.md §5.7 — peer-group comparison). It only reads the
// JWT claims, validates the request and shapes the §1.5 envelope; the data
// work is in svc.IdentityPeersService.
type IdentityPeersHandler struct {
	service *svc.IdentityPeersService
	now     func() time.Time
}

// NewIdentityPeersHandler creates the handler.
func NewIdentityPeersHandler(service *svc.IdentityPeersService) *IdentityPeersHandler {
	return &IdentityPeersHandler{service: service, now: func() time.Time { return time.Now().UTC().Truncate(time.Second) }}
}

// Query parameters of §5.7: the §2 window of recent_call_count and the
// page controls.
var identityPeersAllowed = map[string]struct{}{"from": {}, "to": {}, "limit": {}, "cursor": {}}

// Get handles GET /api/v1/identities/{source_type}/{identity_name}/peers.
func (h *IdentityPeersHandler) Get(w http.ResponseWriter, r *http.Request) {
	rid := summaryRequestID(r)
	w.Header().Set("X-Request-ID", rid)

	claims := middleware.GetClaims(r)
	if claims == nil {
		writeSummaryError(w, http.StatusUnauthorized, models.MonitoringCodeUnauthorized, "authentication required", rid)
		return
	}
	sourceType, identityName, err := identityPath(r)
	if err != nil {
		writeSummaryError(w, http.StatusBadRequest, models.MonitoringCodeValidation, err.Error(), rid)
		return
	}
	q := r.URL.Query()
	if unknown, bad := checkUnknown(q, identityPeersAllowed); bad {
		writeSummaryError(w, http.StatusBadRequest, models.MonitoringCodeValidation,
			fmt.Sprintf("unknown query parameter %q; allowed: %s", unknown, allowedList(identityPeersAllowed)), rid)
		return
	}
	window, err := parseIdentityWindow(q, h.now())
	if err != nil {
		writeSummaryError(w, http.StatusBadRequest, models.MonitoringCodeValidation, err.Error(), rid)
		return
	}
	limit, err := parseIdentityLimit(q, "limit")
	if err != nil {
		writeSummaryError(w, http.StatusBadRequest, models.MonitoringCodeValidation, err.Error(), rid)
		return
	}

	data, next, err := h.service.GetPeers(r.Context(), claims.UserID, claims.TenantID, claims.DBName, sourceType, identityName,
		svc.IdentityPeersParams{Window: window, Limit: limit, Cursor: strings.TrimSpace(q.Get("cursor"))})
	if errors.Is(err, svc.ErrInvalidCursor) {
		writeSummaryError(w, http.StatusBadRequest, models.MonitoringCodeValidation, "cursor is invalid", rid)
		return
	}
	if err != nil {
		writeIdentityServiceError(w, "identity peers", rid, err)
		return
	}
	writeSummaryJSON(w, http.StatusOK, models.MonitoringEnvelope{
		Data: data,
		Meta: models.MonitoringMeta{RequestID: rid, GeneratedAt: h.now(), NextCursor: next},
	})
}
