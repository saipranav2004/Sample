package routes

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/handlers/credential_exposure"
	"nhi-backend-api/internal/handlers/genome"
	handlerv1 "nhi-backend-api/internal/handlers/v1"
	"nhi-backend-api/internal/middleware"
)

type HandlerContainer struct {
	AuthHandler    *handlers.AuthHandler
	AuthMiddleware *middleware.AuthMiddleware

	NewAPIFilterHandler            *handlerv1.FilterHandler
	NewAPISettingsHandler          *handlerv1.SettingsHandler
	NewAPIDashboardOverviewHandler *handlerv1.DashboardOverviewHandler
	NewAPIIdentityDetailHandler    *handlerv1.IdentityDetailHandler
	NewAPIIdentityEventsHandler    *handlerv1.IdentityEventsHandler
	NewAPICredentialsHandler       *handlerv1.CredentialsHandler
	NewAPICredentialDetailHandler  *handlerv1.CredentialDetailHandler
	NewAPIPermissionSourceHandler  *handlerv1.PermissionSourceHandler

	CredentialExposureFindingsHandler  *credential_exposure.FindingsHandler
	CredentialExposureAllowlistHandler *credential_exposure.AllowlistHandler
	CredentialExposureDecisionHandler  *credential_exposure.DecisionHandler
	CredentialExposureDeepScanHandler  *credential_exposure.DeepScanHandler

	// NHI Genome (backend_api_contract.md §4.1 and §5). GET /identities is the §5.1 list.
	GenomeDashboardSummaryHandler *genome.DashboardSummaryHandler
	GenomeIdentityListHandler     *genome.IdentityListHandler
	GenomeIdentitySummaryHandler  *genome.IdentitySummaryHandler
	GenomeIdentityActivityHandler *genome.IdentityActivityHandler
	GenomeIdentityGenomeHandler   *genome.IdentityGenomeHandler
	GenomeIdentityBaselineHandler *genome.IdentityBaselineHandler
	GenomeIdentityTimelineHandler *genome.IdentityTimelineHandler
	GenomeIdentityPeersHandler    *genome.IdentityPeersHandler
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()
	r.Use(middleware.RequestLogger)
	r.Use(middleware.Recoverer)

	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusNotFound, map[string]any{
			"success": false,
			"message": "route not found: " + req.Method + " " + req.URL.Path,
		})
	})
	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{
			"success": false,
			"message": "method not allowed: " + req.Method + " " + req.URL.Path,
		})
	})

	r.HandleFunc("/health", func(w http.ResponseWriter, req *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "healthy", "service": "nhi-backend-api"})
	}).Methods(http.MethodGet)

	if h.AuthHandler != nil {
		r.HandleFunc("/api/v1/login", h.AuthHandler.Login).Methods(http.MethodPost)
		r.HandleFunc("/api/auth/login", h.AuthHandler.Login).Methods(http.MethodPost)
		r.HandleFunc("/api/v1/refresh", h.AuthHandler.Refresh).Methods(http.MethodPost)
		r.HandleFunc("/api/auth/refresh", h.AuthHandler.Refresh).Methods(http.MethodPost)
		r.HandleFunc("/api/v1/logout", h.AuthHandler.Logout).Methods(http.MethodPost)
		r.HandleFunc("/api/auth/logout", h.AuthHandler.Logout).Methods(http.MethodPost)
	}
	if h.AuthMiddleware == nil {
		return r
	}

	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.AuthMiddleware.Authenticate)
	protected := r.PathPrefix("/api").Subrouter()
	protected.Use(h.AuthMiddleware.Authenticate)
	registerProtected(v1, h, true)
	registerProtected(protected, h, false)
	return r
}

func registerProtected(router *mux.Router, h HandlerContainer, versioned bool) {
	if h.AuthHandler != nil {
		path := "/auth/me"
		if versioned {
			path = "/me"
		}
		router.HandleFunc(path, h.AuthHandler.Me).Methods(http.MethodGet)
	}
	if h.NewAPIFilterHandler != nil {
		router.HandleFunc("/filters", h.NewAPIFilterHandler.GetFilters).Methods(http.MethodGet)
	}
	if h.NewAPISettingsHandler != nil {
		router.HandleFunc("/settings", h.NewAPISettingsHandler.Get).Methods(http.MethodGet)
		router.HandleFunc("/settings", h.NewAPISettingsHandler.Update).Methods(http.MethodPut)
	}
	if h.NewAPIDashboardOverviewHandler != nil {
		router.HandleFunc("/dashboard/overview", h.NewAPIDashboardOverviewHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeDashboardSummaryHandler != nil {
		router.HandleFunc("/dashboard/summary", h.GenomeDashboardSummaryHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentityListHandler != nil {
		router.HandleFunc("/identities", h.GenomeIdentityListHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPIIdentityDetailHandler != nil {
		router.HandleFunc("/identities/{id}", h.NewAPIIdentityDetailHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPIIdentityEventsHandler != nil {
		router.HandleFunc("/identities/{id}/events", h.NewAPIIdentityEventsHandler.Get).Methods(http.MethodGet)
	}
	// identity_name is an ARN (contains ':' and '/'), so these patterns use
	// {identity_name:.+}; the sub-resource routes stay above the plain one.
	if h.GenomeIdentityActivityHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}/activity", h.GenomeIdentityActivityHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentityGenomeHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}/genome", h.GenomeIdentityGenomeHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentityBaselineHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}/baseline", h.GenomeIdentityBaselineHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentityTimelineHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}/timeline", h.GenomeIdentityTimelineHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentityPeersHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}/peers", h.GenomeIdentityPeersHandler.Get).Methods(http.MethodGet)
	}
	if h.GenomeIdentitySummaryHandler != nil {
		router.HandleFunc("/identities/{source_type}/{identity_name:.+}", h.GenomeIdentitySummaryHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPICredentialsHandler != nil {
		router.HandleFunc("/credentials", h.NewAPICredentialsHandler.List).Methods(http.MethodGet)
	}
	if h.NewAPICredentialDetailHandler != nil {
		router.HandleFunc("/credentials/{id}", h.NewAPICredentialDetailHandler.Get).Methods(http.MethodGet)
	}
	if h.NewAPIPermissionSourceHandler != nil {
		router.HandleFunc("/permission-source", h.NewAPIPermissionSourceHandler.Get).Methods(http.MethodGet)
	}
	// Credential Exposure — secret scanner findings, tenant-isolated, admin-only
	// These were present in the original backends but not wired in the v1-only build.
	// They live in their own package with strict query validation and tenant scope.
	if h.CredentialExposureFindingsHandler != nil {
		router.HandleFunc("/credential-exposure/findings", h.CredentialExposureFindingsHandler.List).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/findings/flagged", h.CredentialExposureFindingsHandler.ListFlagged).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/findings/summary", h.CredentialExposureFindingsHandler.Summary).Methods(http.MethodGet)
	}
	if h.CredentialExposureAllowlistHandler != nil {
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.List).Methods(http.MethodGet)
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.Create).Methods(http.MethodPost)
		router.HandleFunc("/credential-exposure/allowlist", h.CredentialExposureAllowlistHandler.Delete).Methods(http.MethodDelete)
	}
	if h.CredentialExposureDecisionHandler != nil {
		router.HandleFunc("/credential-exposure/decisions", h.CredentialExposureDecisionHandler.Save).Methods(http.MethodPost)
	}
	if h.CredentialExposureDeepScanHandler != nil {
		router.HandleFunc("/credential-exposure/deep-scan", h.CredentialExposureDeepScanHandler.Trigger).Methods(http.MethodPost)
		router.HandleFunc("/credential-exposure/deep-scan/status", h.CredentialExposureDeepScanHandler.Status).Methods(http.MethodGet)
	}
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
