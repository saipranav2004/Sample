package genome

// Response shapes of
// GET /api/v1/identities/{source_type}/{identity_name}/peers
// (backend_api_contract.md §5.7 / §10.3 "peers[]") in the §1.5 envelope.

// IdentityPeersResponse is the data block of §5.7: the identities that share
// the requested identity's MVP peer key
// (source_type + account_id + region + service_name + cluster_name + role_type),
// excluding the identity itself.
type IdentityPeersResponse struct {
	Peers []IdentityPeer `json:"peers"`
}

// IdentityPeer is one §5.7 peer row. risk_score is the latest
// identity_risk_scores.risk_score (null when unscored), open_anomaly_count
// the grouped count of open alerts, recent_call_count the grouped
// uniqExact(log_events.event_id) in the requested window (null while
// ClickHouse is unavailable) and outlier_dimension the alerts.dimension
// with the most open alerts for the peer (null when it has none).
type IdentityPeer struct {
	IdentityName     string  `json:"identity_name"`
	DisplayName      string  `json:"display_name"`
	RiskScore        *int    `json:"risk_score"`
	OpenAnomalyCount *int    `json:"open_anomaly_count"`
	RecentCallCount  *uint64 `json:"recent_call_count"`
	OutlierDimension *string `json:"outlier_dimension"`
}
