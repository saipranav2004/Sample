package genome

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"sort"
	"strings"

	models "nhi-backend-api/internal/models/genome"
	repo "nhi-backend-api/internal/repository/genome"
)

// IdentityPeersService implements
// GET /api/v1/identities/{source_type}/{identity_name}/peers
// (backend_api_contract.md §5.7 / §10.3) — the peer-group comparison:
//
//   - peers are the other monitored identities of the caller's scope whose
//     MVP peer key (source_type + account_id + region + service_name +
//     cluster_name + role_type) equals the requested identity's;
//   - per peer: latest identity_risk_scores.risk_score, open alerts and the
//     dominant open alerts.dimension (PostgreSQL, one grouped query each)
//     and uniqExact(event_id) in the requested window (ClickHouse, one
//     grouped query).
//
// Peers are ordered by risk score descending (unscored last), then
// identity_name. Nothing is invented: a store that cannot be read leaves its
// fields null (logged server-side).
type IdentityPeersService struct {
	lookup *MonitoredIdentityLookup
	repo   *repo.IdentityPeersRepository
	events *repo.MonitoringEvents // nil when no monitoring ClickHouse is configured
}

// NewIdentityPeersService wires the service.
func NewIdentityPeersService(lookup *MonitoredIdentityLookup, repo *repo.IdentityPeersRepository, events *repo.MonitoringEvents) *IdentityPeersService {
	return &IdentityPeersService{lookup: lookup, repo: repo, events: events}
}

// IdentityPeersParams are the parsed §5.7 query parameters.
type IdentityPeersParams struct {
	Window TimeWindow // §2 from/to of recent_call_count
	Limit  int        // §2 page size: default 25, max 100
	Cursor string     // opaque, from a previous meta.next_cursor; "" for the first page
}

// GetPeers builds the §5.7 page and the meta.next_cursor (nil on the last
// page). Unknown identities are ErrIdentityNotFound, scope/discovery
// failures *StoreUnavailableError, a foreign cursor ErrInvalidCursor.
func (s *IdentityPeersService) GetPeers(ctx context.Context, userID, tenantID, dbName, sourceType, identityName string, p IdentityPeersParams) (*models.IdentityPeersResponse, *string, error) {
	after, err := decodePeersCursor(p.Cursor)
	if err != nil {
		return nil, nil, err
	}
	sc, fleet, err := s.lookup.Fleet(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, nil, err
	}
	var (
		self  monitoredIdentity
		found bool
	)
	for _, id := range fleet {
		if id.Key.SourceType == sourceType && id.Key.IdentityName == identityName {
			self, found = id, true
			break
		}
	}
	if !found {
		return nil, nil, ErrIdentityNotFound
	}

	var peers []peerEntry
	for _, id := range fleet {
		if id.Key != self.Key && id.peerKey() == self.peerKey() {
			peers = append(peers, peerEntry{id: id})
		}
	}
	// The order depends on the risk score, so it is read for the whole group.
	risk, err := s.repo.LatestRiskSnapshots(ctx, sc, peerKeys(peers))
	if !readOK("identity peers risk scores", err) {
		risk = map[repo.MonitoringKey]repo.IdentityRiskSnapshotRow{}
	}
	for i := range peers {
		peers[i].score = riskScore(risk, peers[i].id)
	}
	sort.SliceStable(peers, func(i, j int) bool { return comparePeerEntries(peers[i], peers[j]) < 0 })
	if after != nil {
		cut := sort.Search(len(peers), func(i int) bool { return comparePeerEntries(peers[i], *after) > 0 })
		peers = peers[cut:]
	}
	var next *string
	if len(peers) > p.Limit {
		peers = peers[:p.Limit]
		next = encodePeersCursor(peers[len(peers)-1])
	}

	// The remaining facts are read for the page only, one grouped query each.
	keys := peerKeys(peers)
	dimensionCounts, err := s.repo.OpenAlertsByIdentityDimension(ctx, sc, keys)
	alertsOK := readOK("identity peers open alerts", err)
	identityKeys := make([]repo.MonitoringKey, 0, len(peers))
	for _, pe := range peers {
		identityKeys = append(identityKeys, pe.id.Key)
	}
	calls, err := s.events.CallCountsByIdentity(ctx, identityKeys, p.Window.From, p.Window.To)
	callsOK := eventsReadOK("identity peers call counts", err)

	out := &models.IdentityPeersResponse{Peers: make([]models.IdentityPeer, 0, len(peers))}
	for _, pe := range peers {
		peer := models.IdentityPeer{IdentityName: pe.id.Key.IdentityName, DisplayName: pe.id.DisplayName, RiskScore: pe.score}
		if alertsOK {
			open, outlier := peerAlertSummary(dimensionCounts, pe.id)
			peer.OpenAnomalyCount = intPtr(open)
			peer.OutlierDimension = optionalString(outlier)
		}
		if callsOK {
			n := calls[pe.id.Key]
			peer.RecentCallCount = &n
		}
		out.Peers = append(out.Peers, peer)
	}
	return out, next, nil
}

// peerAlertSummary derives open_anomaly_count (sum over the peer's keys and
// dimensions) and outlier_dimension (the dimension with the most open
// alerts; ties by name, as ordered by the query) from the grouped rows.
func peerAlertSummary(rows []repo.PeerDimensionCountRow, id monitoredIdentity) (open int, outlier string) {
	mine := map[repo.MonitoringKey]struct{}{}
	for _, k := range id.allKeys() {
		mine[k] = struct{}{}
	}
	perDimension := map[string]int{} // merged over the peer's identity and workload keys
	for _, r := range rows {
		if _, ok := mine[r.Key]; !ok {
			continue
		}
		open += r.Count
		perDimension[r.Dimension] += r.Count
	}
	best := 0
	for dimension, n := range perDimension {
		if n > best || (n == best && dimension < outlier) {
			best, outlier = n, dimension
		}
	}
	return open, outlier
}

// peerKeys returns the identity and workload keys of the peers, deduplicated.
func peerKeys(peers []peerEntry) []repo.MonitoringKey {
	seen := map[repo.MonitoringKey]struct{}{}
	out := make([]repo.MonitoringKey, 0, len(peers))
	for _, pe := range peers {
		for _, k := range pe.id.allKeys() {
			if _, dup := seen[k]; !dup {
				seen[k] = struct{}{}
				out = append(out, k)
			}
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// ordering and the keyset cursor
// ---------------------------------------------------------------------------

// peerEntry is one peer with its sort value.
type peerEntry struct {
	id    monitoredIdentity
	score *int
}

// comparePeerEntries orders peers by risk score descending (unscored
// last), then identity_name ascending — a total order within a peer group
// (identity_name is unique per source_type there).
func comparePeerEntries(a, b peerEntry) int {
	if c := compareDesc(a.score != nil, b.score != nil, func() int { return *a.score - *b.score }); c != 0 {
		return c
	}
	return strings.Compare(a.id.Key.IdentityName, b.id.Key.IdentityName)
}

// peersCursor is the opaque §2 cursor: the sort value and identity_name of
// the last returned peer.
type peersCursor struct {
	Score *int   `json:"r,omitempty"`
	Name  string `json:"id"`
}

func encodePeersCursor(last peerEntry) *string {
	raw, _ := json.Marshal(peersCursor{Score: last.score, Name: last.id.Key.IdentityName})
	s := base64.RawURLEncoding.EncodeToString(raw)
	return &s
}

func decodePeersCursor(s string) (*peerEntry, error) {
	if s == "" {
		return nil, nil
	}
	raw, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		return nil, ErrInvalidCursor
	}
	var c peersCursor
	if err := json.Unmarshal(raw, &c); err != nil || c.Name == "" {
		return nil, ErrInvalidCursor
	}
	e := &peerEntry{score: c.Score}
	e.id.Key.IdentityName = c.Name
	return e, nil
}
