package genome

import (
	"context"
	"fmt"
	"nhi-backend-api/internal/scope"
	"time"

	ch "github.com/ClickHouse/clickhouse-go/v2"
)

// IdentityPeersRepository reads the per-peer monitoring facts of
// GET /api/v1/identities/{source_type}/{identity_name}/peers
// (backend_api_contract.md §5.7 / §10.3) from the caller's tenant schema.
// Everything is one grouped query over the whole peer set — the contract
// forbids one query per peer. The peers themselves are the latest
// normalized discovery identities that share the requested identity's peer
// key (resolved in the service); the ClickHouse call counts
// (CallCountsByIdentity) are at the end of this file.
type IdentityPeersRepository struct {
	list IdentityListRepository // the fleet-list grouped readers are reused as-is
}

// NewIdentityPeersRepository creates the repository.
func NewIdentityPeersRepository() *IdentityPeersRepository {
	return &IdentityPeersRepository{}
}

// LatestRiskSnapshots is §10.3 peers[].risk_score: the newest completed
// identity_risk_scores snapshot per key.
func (r *IdentityPeersRepository) LatestRiskSnapshots(ctx context.Context, resolved *scope.DataScope, keys []MonitoringKey) (map[MonitoringKey]IdentityRiskSnapshotRow, error) {
	return r.list.LatestRiskSnapshots(ctx, resolved, keys)
}

// PeerDimensionCountRow is one (identity, dimension) group of open alerts.
type PeerDimensionCountRow struct {
	Key       MonitoringKey
	Dimension string // exact alerts.dimension value
	Count     int
}

// OpenAlertsByIdentityDimension is the single grouped alerts query behind
// peers[].open_anomaly_count (sum of a key's rows) and
// peers[].outlier_dimension (its first row): COUNT(*) of alerts where
// status = 'open', grouped by identity and dimension, ordered per identity
// by count descending and then dimension name.
func (r *IdentityPeersRepository) OpenAlertsByIdentityDimension(ctx context.Context, resolved *scope.DataScope, keys []MonitoringKey) ([]PeerDimensionCountRow, error) {
	out := []PeerDimensionCountRow{}
	if len(keys) == 0 {
		return out, nil
	}
	types, names := keyArrays(keys)
	q := `SELECT a.source_type, a.identity_name, a.dimension, COUNT(*)
	      FROM ` + resolved.Table("alerts") + ` a` + keyJoin("a") + `
	      WHERE a.status = 'open'
	      GROUP BY a.source_type, a.identity_name, a.dimension
	      ORDER BY a.source_type, a.identity_name, COUNT(*) DESC, a.dimension`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names)
	if err != nil {
		return nil, wrapMonitoringErr("open alerts by identity and dimension", err)
	}
	defer rows.Close()
	for rows.Next() {
		var row PeerDimensionCountRow
		if err := rows.Scan(&row.Key.SourceType, &row.Key.IdentityName, &row.Dimension, &row.Count); err != nil {
			return nil, wrapMonitoringErr("open alerts by identity and dimension", err)
		}
		out = append(out, row)
	}
	return out, wrapMonitoringErr("open alerts by identity and dimension", rows.Err())
}

// ---------------------------------------------------------------------------
// ClickHouse log_events (backend_api_contract.md §5.7 / §10.3 peers[].recent_call_count)
// ---------------------------------------------------------------------------

// CallCountsByIdentity is the grouped uniqExact(event_id) per key inside
// [from, to) — one query for the whole peer set. Keys without events in the
// window are absent from the map.
func (e *MonitoringEvents) CallCountsByIdentity(ctx context.Context, keys []MonitoringKey, from, to time.Time) (map[MonitoringKey]uint64, error) {
	if !e.Enabled() {
		return nil, ErrMonitoringEventsNotConfigured
	}
	out := map[MonitoringKey]uint64{}
	if len(keys) == 0 {
		return out, nil
	}
	q := `SELECT source_type, identity_name, uniqExact(event_id)
	      FROM ` + e.table + `
	      WHERE` + keyFilterSQL + `
	        AND event_time >= {from:DateTime64(3)}
	        AND event_time < {to:DateTime64(3)}
	      GROUP BY source_type, identity_name`
	args := append(keyFilterArgs(keys),
		ch.DateNamed("from", from.UTC(), ch.MilliSeconds),
		ch.DateNamed("to", to.UTC(), ch.MilliSeconds))
	ctx, cancel := e.queryContext(ctx)
	defer cancel()
	rows, err := e.conn.Query(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("log_events call counts by identity: %w", err)
	}
	defer rows.Close()
	want := keySet(keys)
	for rows.Next() {
		var (
			k MonitoringKey
			n uint64
		)
		if err := rows.Scan(&k.SourceType, &k.IdentityName, &n); err != nil {
			return nil, fmt.Errorf("log_events call counts by identity: %w", err)
		}
		if _, ok := want[k]; ok {
			out[k] = n
		}
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("log_events call counts by identity: %w", err)
	}
	return out, nil
}
