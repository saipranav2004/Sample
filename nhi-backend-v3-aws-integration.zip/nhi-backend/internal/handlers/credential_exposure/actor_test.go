package credential_exposure

import (
	"context"
	"net/http/httptest"
	"strings"
	"testing"

	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/pkg/jwt"
)

func TestActorOfUsesTheToken(t *testing.T) {
	withClaims := func(c *jwt.CustomClaims) string {
		r := httptest.NewRequest("POST", "/api/v1/credential-exposure/decisions", strings.NewReader(`{"decided_by":"someone-else"}`))
		return actorOf(r.WithContext(context.WithValue(r.Context(), middleware.UserClaimsKey, c)))
	}
	if got := withClaims(&jwt.CustomClaims{UserID: " alice@acme.test ", Email: "other@acme.test"}); got != "alice@acme.test" {
		t.Fatalf("user_id: got %q", got)
	}
	if got := withClaims(&jwt.CustomClaims{Email: "bob@acme.test"}); got != "bob@acme.test" {
		t.Fatalf("email fallback: got %q", got)
	}
	if got := withClaims(&jwt.CustomClaims{UserID: strings.Repeat("a", 300)}); len(got) != 200 {
		t.Fatalf("cap: got %d chars", len(got))
	}
	if got := actorOf(httptest.NewRequest("POST", "/", nil)); got != "" {
		t.Fatalf("no claims: got %q", got)
	}
}
