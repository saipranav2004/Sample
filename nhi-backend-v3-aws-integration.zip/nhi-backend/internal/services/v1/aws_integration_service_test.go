package v1

import (
	"context"
	"errors"
	"reflect"
	"strings"
	"sync"
	"testing"
	"time"

	"nhi-backend-api/internal/awsconnect"
	models "nhi-backend-api/internal/models/v1"
	"nhi-backend-api/internal/repository"
)

const (
	awsTestTenant  = "11111111-1111-1111-1111-111111111111"
	awsTestRoleARN = "arn:aws:iam::222222222222:role/NHIPlatformCollector"
)

var awsTestCaller = AWSCaller{TenantID: awsTestTenant, DBName: "nhi_tenant_a", Actor: "alice@acme.test"}

type fakeAWSStore struct {
	mu       sync.Mutex
	settings *models.AWSTenantSettings
	accounts map[string]models.AWSAccountRecord
	claimed  bool
	saveErr  error
	order    *[]string
}

func newFakeAWSStore() *fakeAWSStore {
	return &fakeAWSStore{
		settings: &models.AWSTenantSettings{
			Domain:       "acme.com",
			AWSAccountID: "999999999999",
			ExternalID:   "ext-0123456789abcdef0123456789abcdef",
			EventBusARN:  "arn:aws:events:ap-south-1:999999999999:event-bus/nhi-central-bus",
		},
		accounts: map[string]models.AWSAccountRecord{},
	}
}

func (f *fakeAWSStore) note(step string) {
	if f.order != nil {
		*f.order = append(*f.order, step)
	}
}

func (f *fakeAWSStore) TenantSettings(context.Context, string) (*models.AWSTenantSettings, error) {
	return f.settings, nil
}

func (f *fakeAWSStore) ListAccounts(_ context.Context, tenantID string) ([]models.AWSAccountRecord, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := []models.AWSAccountRecord{}
	for _, rec := range f.accounts {
		if rec.TenantID == tenantID {
			out = append(out, rec)
		}
	}
	return out, nil
}

func (f *fakeAWSStore) GetAccount(_ context.Context, tenantID, accountID string) (*models.AWSAccountRecord, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	rec, ok := f.accounts[accountID]
	if !ok || rec.TenantID != tenantID {
		return nil, nil
	}
	return &rec, nil
}

func (f *fakeAWSStore) AccountClaimedByOther(context.Context, string, string) (bool, error) {
	return f.claimed, nil
}

func (f *fakeAWSStore) SaveVerification(_ context.Context, rec models.AWSAccountRecord) (*models.AWSAccountRecord, bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.saveErr != nil {
		return nil, false, f.saveErr
	}
	prev, existed := f.accounts[rec.AccountID]
	queue := rec.Status == models.AWSStatusConnected && (!existed || prev.ConnectedAt == nil)
	if existed {
		rec.ConnectedAt = prev.ConnectedAt
		rec.SyncStatus = prev.SyncStatus
	} else {
		rec.SyncStatus = models.AWSSyncIdle
	}
	if rec.Status == models.AWSStatusConnected && rec.ConnectedAt == nil {
		t := rec.LastVerifiedAt
		rec.ConnectedAt = &t
	}
	if queue {
		rec.SyncStatus = models.AWSSyncQueued
	}
	f.accounts[rec.AccountID] = rec
	return &rec, queue, nil
}

func (f *fakeAWSStore) UpdateRegions(_ context.Context, tenantID, accountID string, regions []string) (*models.AWSAccountRecord, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	rec, ok := f.accounts[accountID]
	if !ok || rec.TenantID != tenantID {
		return nil, repository.ErrAWSAccountNotFound
	}
	rec.Regions = regions
	f.accounts[accountID] = rec
	return &rec, nil
}

func (f *fakeAWSStore) RequestSync(_ context.Context, tenantID, accountID, actor string, at time.Time) (*models.AWSAccountRecord, bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	rec, ok := f.accounts[accountID]
	switch {
	case !ok || rec.TenantID != tenantID:
		return nil, false, repository.ErrAWSAccountNotFound
	case rec.Status != models.AWSStatusConnected:
		return &rec, false, repository.ErrAWSAccountNotConnected
	case rec.SyncStatus == models.AWSSyncQueued || rec.SyncStatus == models.AWSSyncRunning:
		return &rec, true, nil
	}
	rec.SyncStatus, rec.SyncRequestedBy, rec.SyncRequestedAt = models.AWSSyncQueued, actor, &at
	f.accounts[accountID] = rec
	return &rec, false, nil
}

func (f *fakeAWSStore) DeleteAccount(_ context.Context, tenantID, accountID string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.note("delete")
	rec, ok := f.accounts[accountID]
	if !ok || rec.TenantID != tenantID {
		return repository.ErrAWSAccountNotFound
	}
	delete(f.accounts, accountID)
	return nil
}

type fakeRegistry struct {
	mu            sync.Mutex
	registered    map[string][]string
	registerErr   error
	unregisterErr error
	order         *[]string
}

func newFakeRegistry() *fakeRegistry { return &fakeRegistry{registered: map[string][]string{}} }

func (r *fakeRegistry) Register(_ context.Context, dbName, tenantID, accountID string, regions []string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.registerErr != nil {
		return r.registerErr
	}
	r.registered[dbName+"|"+tenantID+"|"+accountID] = regions
	return nil
}

func (r *fakeRegistry) Unregister(_ context.Context, dbName, tenantID, accountID string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.order != nil {
		*r.order = append(*r.order, "unregister")
	}
	if r.unregisterErr != nil {
		return r.unregisterErr
	}
	delete(r.registered, dbName+"|"+tenantID+"|"+accountID)
	return nil
}

type fakeAWSVerifier struct {
	assumeErr  error
	readErr    error
	busErr     error
	revokeErr  error
	gotExtID   string
	busAllowed []string
	revoked    []string
	block      chan struct{}
	order      *[]string
}

func (f *fakeAWSVerifier) AssumeRole(_ context.Context, _ awsconnect.Platform, _ awsconnect.RoleARN, externalID string) (*awsconnect.Session, error) {
	if f.block != nil {
		<-f.block
	}
	f.gotExtID = externalID
	if f.assumeErr != nil {
		return nil, f.assumeErr
	}
	return &awsconnect.Session{}, nil
}

func (f *fakeAWSVerifier) TestRead(context.Context, *awsconnect.Session) error { return f.readErr }

func (f *fakeAWSVerifier) AllowAccountOnBus(_ context.Context, _ awsconnect.Platform, accountID string) error {
	if f.busErr != nil {
		return f.busErr
	}
	f.busAllowed = append(f.busAllowed, accountID)
	return nil
}

func (f *fakeAWSVerifier) RevokeAccountOnBus(_ context.Context, _ awsconnect.Platform, accountID string) error {
	if f.order != nil {
		*f.order = append(*f.order, "revoke")
	}
	f.revoked = append(f.revoked, accountID)
	return f.revokeErr
}

type fakeEvents struct {
	found bool
	err   error
}

func (f fakeEvents) HasEventsFrom(context.Context, awsconnect.Platform, string, time.Time) (bool, error) {
	return f.found, f.err
}

type awsHarness struct {
	store    *fakeAWSStore
	registry *fakeRegistry
	verifier *fakeAWSVerifier
	svc      *AWSIntegrationService
}

func newAWSHarness(v *fakeAWSVerifier, events AWSEventSource) awsHarness {
	h := awsHarness{store: newFakeAWSStore(), registry: newFakeRegistry(), verifier: v}
	var verifier AWSVerifier
	if v != nil {
		verifier = v
	}
	h.svc = NewAWSIntegrationService(h.store, h.registry, verifier, events, AWSIntegrationOptions{EventLookback: 24 * time.Hour})
	return h
}

func checkStates(checks []models.AWSCheck) string {
	parts := make([]string, len(checks))
	for i, c := range checks {
		parts[i] = c.State
	}
	return strings.Join(parts, ",")
}

func TestAWSVerifyConnectsQueuesFirstSyncAndRegisters(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	got, err := h.svc.Verify(context.Background(), awsTestCaller, "  "+awsTestRoleARN+" ", []string{"ap-south-1", "US-EAST-1", "ap-south-1"})
	if err != nil {
		t.Fatalf("Verify: %v", err)
	}
	if got.Status != models.AWSStatusConnected || !got.Saved || !got.SyncQueued || checkStates(got.Checks) != "pass,pass,pass" {
		t.Fatalf("result = %+v", got)
	}
	if want := []string{"us-east-1", "ap-south-1"}; !reflect.DeepEqual(got.Regions, want) {
		t.Fatalf("regions = %v, want %v", got.Regions, want)
	}
	if h.verifier.gotExtID != h.store.settings.ExternalID {
		t.Fatalf("AssumeRole used external id %q, tenant has %q", h.verifier.gotExtID, h.store.settings.ExternalID)
	}
	saved := h.store.accounts["222222222222"]
	if saved.ExternalID != h.store.settings.ExternalID || saved.LastVerifiedBy != "alice@acme.test" || !reflect.DeepEqual(saved.Regions, got.Regions) {
		t.Fatalf("saved = %+v", saved)
	}
	if regs := h.registry.registered["nhi_tenant_a|"+awsTestTenant+"|222222222222"]; !reflect.DeepEqual(regs, got.Regions) {
		t.Fatalf("registered in tenant database: %v", regs)
	}
	// Verifying an already connected account again does not queue another sync.
	again, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"})
	if err != nil || again.SyncQueued {
		t.Fatalf("second verify: %+v, %v", again, err)
	}
	if regs := h.registry.registered["nhi_tenant_a|"+awsTestTenant+"|222222222222"]; !reflect.DeepEqual(regs, []string{"us-east-1"}) {
		t.Fatalf("regions not updated in tenant database: %v", regs)
	}
}

func TestAWSVerifyAssumeDeniedStoresNothing(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{assumeErr: awsconnect.ErrAccessDenied}, fakeEvents{found: true})
	got, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"})
	if err != nil {
		t.Fatal(err)
	}
	if got.Saved || checkStates(got.Checks) != "fail,skipped,skipped" || got.Checks[0].Fix != "Check the External ID matches" {
		t.Fatalf("result = %+v", got)
	}
	if len(h.store.accounts) != 0 || len(h.verifier.busAllowed) != 0 || len(h.registry.registered) != 0 {
		t.Fatal("stored, granted or registered an account the tenant has not proved it controls")
	}
}

func TestAWSVerifyFixesMatchSpec(t *testing.T) {
	cases := []struct {
		name   string
		v      *fakeAWSVerifier
		events AWSEventSource
		states string
		fixes  [3]string
	}{
		{"read denied", &fakeAWSVerifier{readErr: awsconnect.ErrAccessDenied}, fakeEvents{found: true}, "pass,fail,pass", [3]string{"", "Attach SecurityAudit + ViewOnlyAccess", ""}},
		{"read empty", &fakeAWSVerifier{readErr: awsconnect.ErrNothingRead}, fakeEvents{found: true}, "pass,fail,pass", [3]string{"", "Attach SecurityAudit + ViewOnlyAccess", ""}},
		{"no events", &fakeAWSVerifier{}, fakeEvents{}, "pass,pass,fail", [3]string{"", "", "Check the EventBridge rule target ARN"}},
		{"bus permission error", &fakeAWSVerifier{busErr: errors.New("boom")}, fakeEvents{found: true}, "pass,pass,error", [3]string{}},
		{"event store error", &fakeAWSVerifier{}, fakeEvents{err: errors.New("down")}, "pass,pass,error", [3]string{}},
		{"no event store", &fakeAWSVerifier{}, nil, "pass,pass,error", [3]string{}},
		{"assume error is ours", &fakeAWSVerifier{assumeErr: errors.New("network")}, fakeEvents{found: true}, "error,skipped,skipped", [3]string{}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			h := newAWSHarness(tc.v, tc.events)
			got, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"})
			if err != nil {
				t.Fatal(err)
			}
			if checkStates(got.Checks) != tc.states {
				t.Fatalf("states = %s, want %s", checkStates(got.Checks), tc.states)
			}
			for i, c := range got.Checks {
				if c.Fix != tc.fixes[i] {
					t.Fatalf("check %s fix = %q, want %q", c.Key, c.Fix, tc.fixes[i])
				}
			}
			if got.Status == models.AWSStatusConnected || got.SyncQueued {
				t.Fatal("a failing account must not connect or queue a sync")
			}
			if len(h.registry.registered) != 0 {
				t.Fatal("a failing account must not join the tenant's account list")
			}
		})
	}
}

func TestAWSVerifyRejectsBadInput(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	var badARN *awsconnect.ErrInvalidRoleARN
	for _, arn := range []string{"", "NHIPlatformCollector", "arn:aws:iam::999999999999:role/NHIPlatformAssumer"} {
		if _, err := h.svc.Verify(context.Background(), awsTestCaller, arn, []string{"us-east-1"}); !errors.As(err, &badARN) {
			t.Fatalf("Verify(%q) = %v, want ErrInvalidRoleARN", arn, err)
		}
	}
	var badRegions *awsconnect.ErrInvalidRegions
	for _, regions := range [][]string{nil, {}, {"mars-1"}} {
		if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, regions); !errors.As(err, &badRegions) {
			t.Fatalf("Verify(regions %v) = %v, want ErrInvalidRegions", regions, err)
		}
	}
}

func TestAWSVerifyAccountOfAnotherTenant(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	h.store.claimed = true
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("err = %v", err)
	}
	h = newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	h.store.saveErr = repository.ErrAWSAccountClaimed
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("race on the unique index: err = %v", err)
	}
}

func TestAWSVerifyWorkspaceUpdateFailure(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	h.registry.registerErr = errors.New("tenant db down")
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSWorkspaceUpdate) {
		t.Fatalf("err = %v, want ErrAWSWorkspaceUpdate", err)
	}
}

func TestAWSTenantNotConfigured(t *testing.T) {
	for name, mutate := range map[string]func(*models.AWSTenantSettings) *models.AWSTenantSettings{
		"no tenant row":     func(*models.AWSTenantSettings) *models.AWSTenantSettings { return nil },
		"no event bus":      func(s *models.AWSTenantSettings) *models.AWSTenantSettings { s.EventBusARN = ""; return s },
		"no external id":    func(s *models.AWSTenantSettings) *models.AWSTenantSettings { s.ExternalID = ""; return s },
		"bus other account": func(s *models.AWSTenantSettings) *models.AWSTenantSettings { s.AWSAccountID = "111111111111"; return s },
	} {
		t.Run(name, func(t *testing.T) {
			h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
			h.store.settings = mutate(h.store.settings)
			if _, err := h.svc.Get(context.Background(), awsTestTenant, true); !errors.Is(err, ErrAWSTenantNotConfigured) {
				t.Fatalf("Get(admin) = %v", err)
			}
			if view, err := h.svc.Get(context.Background(), awsTestTenant, false); err != nil || view.Setup != nil {
				t.Fatalf("Get(non-admin) = %+v, %v", view, err)
			}
			if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSTenantNotConfigured) {
				t.Fatalf("Verify = %v", err)
			}
		})
	}
	h := newAWSHarness(nil, fakeEvents{found: true})
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSUnavailable) {
		t.Fatalf("no AWS config: err = %v", err)
	}
}

func TestAWSGetSetupFromTenantRow(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	view, err := h.svc.Get(context.Background(), awsTestTenant, true)
	if err != nil {
		t.Fatal(err)
	}
	s := view.Setup
	if view.Status != models.AWSStatusNotConnected || view.Workspace.Domain != "acme.com" || s == nil {
		t.Fatalf("view = %+v", view)
	}
	if s.AccountID != "999999999999" || s.Region != "ap-south-1" || s.ExternalID != h.store.settings.ExternalID ||
		s.AssumerRoleARN != "arn:aws:iam::999999999999:role/NHIPlatformAssumer" || s.RoleName != "NHIPlatformCollector" ||
		s.RuleName != "nhi-forward-events" || len(s.Regions) != len(awsconnect.Regions) || len(s.EventSources) != 8 {
		t.Fatalf("setup = %+v", s)
	}
}

func TestAWSOneVerificationPerTenant(t *testing.T) {
	block := make(chan struct{})
	h := newAWSHarness(&fakeAWSVerifier{block: block}, fakeEvents{found: true})
	done := make(chan error, 1)
	go func() {
		_, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"})
		done <- err
	}()
	deadline := time.Now().Add(2 * time.Second)
	for {
		if _, held := h.svc.running.Load(awsTestTenant); held {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("first verification never started")
		}
		time.Sleep(time.Millisecond)
	}
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); !errors.Is(err, ErrAWSVerifyInProgress) {
		t.Fatalf("concurrent Verify = %v", err)
	}
	close(block)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
}

func connectTestAccount(t *testing.T, h awsHarness) {
	t.Helper()
	if got, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); err != nil || got.Status != models.AWSStatusConnected {
		t.Fatalf("connect: %+v, %v", got, err)
	}
}

func TestAWSUpdateRegions(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	connectTestAccount(t, h)
	acct, err := h.svc.UpdateRegions(context.Background(), awsTestCaller, "222222222222", []string{"eu-west-1", "us-east-1"})
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"us-east-1", "eu-west-1"}
	if !reflect.DeepEqual(acct.Regions, want) || !reflect.DeepEqual(h.registry.registered["nhi_tenant_a|"+awsTestTenant+"|222222222222"], want) {
		t.Fatalf("regions = %v / registered %v", acct.Regions, h.registry.registered)
	}
	var bad *awsconnect.ErrInvalidRegions
	if _, err := h.svc.UpdateRegions(context.Background(), awsTestCaller, "222222222222", nil); !errors.As(err, &bad) {
		t.Fatalf("empty regions = %v", err)
	}
	if _, err := h.svc.UpdateRegions(context.Background(), awsTestCaller, "333333333333", []string{"us-east-1"}); !errors.Is(err, repository.ErrAWSAccountNotFound) {
		t.Fatalf("unknown account = %v", err)
	}

	// An account that is not connected keeps out of the tenant's account list.
	h = newAWSHarness(&fakeAWSVerifier{readErr: awsconnect.ErrAccessDenied}, fakeEvents{found: true})
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); err != nil {
		t.Fatal(err)
	}
	if _, err := h.svc.UpdateRegions(context.Background(), awsTestCaller, "222222222222", []string{"eu-west-1"}); err != nil {
		t.Fatal(err)
	}
	if len(h.registry.registered) != 0 {
		t.Fatal("registered an account that has not passed its checks")
	}
}

func TestAWSRequestSync(t *testing.T) {
	h := newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	connectTestAccount(t, h) // queues the first sync
	got, err := h.svc.RequestSync(context.Background(), awsTestCaller, "222222222222")
	if err != nil || !got.AlreadyQueued {
		t.Fatalf("sync while queued: %+v, %v", got, err)
	}
	rec := h.store.accounts["222222222222"]
	rec.SyncStatus = models.AWSSyncSucceeded
	h.store.accounts["222222222222"] = rec
	got, err = h.svc.RequestSync(context.Background(), awsTestCaller, "222222222222")
	if err != nil || got.AlreadyQueued || got.Account.Sync.Status != models.AWSSyncQueued || got.Account.Sync.RequestedBy != "alice@acme.test" {
		t.Fatalf("sync: %+v, %v", got, err)
	}
	if _, err := h.svc.RequestSync(context.Background(), awsTestCaller, "333333333333"); !errors.Is(err, repository.ErrAWSAccountNotFound) {
		t.Fatalf("unknown account: %v", err)
	}

	h = newAWSHarness(&fakeAWSVerifier{readErr: awsconnect.ErrAccessDenied}, fakeEvents{found: true})
	if _, err := h.svc.Verify(context.Background(), awsTestCaller, awsTestRoleARN, []string{"us-east-1"}); err != nil {
		t.Fatal(err)
	}
	if _, err := h.svc.RequestSync(context.Background(), awsTestCaller, "222222222222"); !errors.Is(err, repository.ErrAWSAccountNotConnected) {
		t.Fatalf("sync of a failing account: %v", err)
	}
}

func TestAWSRemoveAccount(t *testing.T) {
	order := []string{}
	h := newAWSHarness(&fakeAWSVerifier{order: &order}, fakeEvents{found: true})
	h.store.order, h.registry.order = &order, &order
	connectTestAccount(t, h)
	if err := h.svc.RemoveAccount(context.Background(), awsTestCaller, "222222222222"); err != nil {
		t.Fatal(err)
	}
	if want := []string{"unregister", "delete", "revoke"}; !reflect.DeepEqual(order, want) {
		t.Fatalf("order = %v, want %v", order, want)
	}
	if len(h.store.accounts) != 0 || len(h.registry.registered) != 0 || !reflect.DeepEqual(h.verifier.revoked, []string{"222222222222"}) {
		t.Fatal("account not fully removed")
	}
	if err := h.svc.RemoveAccount(context.Background(), awsTestCaller, "222222222222"); !errors.Is(err, repository.ErrAWSAccountNotFound) {
		t.Fatalf("second remove = %v", err)
	}

	// The tenant database is down: nothing is deleted, so a retry starts clean.
	h = newAWSHarness(&fakeAWSVerifier{}, fakeEvents{found: true})
	connectTestAccount(t, h)
	h.registry.unregisterErr = errors.New("down")
	if err := h.svc.RemoveAccount(context.Background(), awsTestCaller, "222222222222"); !errors.Is(err, ErrAWSWorkspaceUpdate) {
		t.Fatalf("err = %v", err)
	}
	if _, ok := h.store.accounts["222222222222"]; !ok {
		t.Fatal("account deleted although the tenant database was not updated")
	}

	// Revoking on AWS fails: the removal still stands (best effort, logged).
	h = newAWSHarness(&fakeAWSVerifier{revokeErr: errors.New("aws down")}, fakeEvents{found: true})
	connectTestAccount(t, h)
	if err := h.svc.RemoveAccount(context.Background(), awsTestCaller, "222222222222"); err != nil {
		t.Fatalf("revoke failure must not fail removal: %v", err)
	}
}

func TestAWSHumanHours(t *testing.T) {
	for d, want := range map[time.Duration]string{time.Hour: "hour", 24 * time.Hour: "24 hours", 72 * time.Hour: "3 days"} {
		if got := humanHours(d); got != want {
			t.Fatalf("humanHours(%v) = %q", d, got)
		}
	}
}
