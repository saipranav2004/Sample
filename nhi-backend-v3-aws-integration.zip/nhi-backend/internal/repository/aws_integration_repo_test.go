package repository

import (
	"context"
	"database/sql"
	"errors"
	"os"
	"reflect"
	"sort"
	"sync"
	"testing"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"

	modelsv1 "nhi-backend-api/internal/models/v1"
)

// Runs against real databases:
//
//	NHI_TEST_GLOBAL_DSN  global database with migrations/global/001 and 002 applied
//	NHI_TEST_TENANT_DSN  a tenant database with nhi_scanner.accounts (scripts/test_schema.sql)
//
// e.g. NHI_TEST_GLOBAL_DSN='postgres://postgres@localhost:5432/nhi_global?sslmode=disable'
func openAWSTestDBs(t *testing.T) (*sql.DB, *sql.DB) {
	t.Helper()
	gdsn, tdsn := os.Getenv("NHI_TEST_GLOBAL_DSN"), os.Getenv("NHI_TEST_TENANT_DSN")
	if gdsn == "" || tdsn == "" {
		t.Skip("NHI_TEST_GLOBAL_DSN / NHI_TEST_TENANT_DSN not set")
	}
	open := func(dsn string) *sql.DB {
		db, err := sql.Open("pgx", dsn)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = db.Close() })
		return db
	}
	return open(gdsn), open(tdsn)
}

type staticTenantDB struct{ db *sql.DB }

func (s staticTenantDB) GetTenantDB(string) (*sql.DB, error) { return s.db, nil }

const (
	awsTenantA = "11111111-1111-1111-1111-111111111111"
	awsTenantB = "22222222-2222-2222-2222-222222222222"
)

func mustExec(t *testing.T, db *sql.DB, q string, args ...any) {
	t.Helper()
	if _, err := db.Exec(q, args...); err != nil {
		t.Fatalf("%s: %v", q, err)
	}
}

func TestAWSIntegrationRepositoryAgainstPostgres(t *testing.T) {
	global, tenant := openAWSTestDBs(t)
	ctx := context.Background()
	mustExec(t, global, `DELETE FROM nhi_schema.tenant_aws_accounts`)
	mustExec(t, global, `DELETE FROM nhi_schema.nhi_users`)
	mustExec(t, global, `DELETE FROM nhi_schema.tenants`)
	mustExec(t, global, `INSERT INTO nhi_schema.tenants (tenant_id, db_name, domain, aws_account_id, event_bus_arn)
		VALUES ($1, 'nhi_tenant_a', 'acme.com', '189160505560', 'arn:aws:events:ap-south-1:189160505560:event-bus/nhi-central-bus'),
		       ($2, 'nhi_tenant_b', NULL, NULL, NULL)`, awsTenantA, awsTenantB)
	repo := NewAWSIntegrationRepository(&PostgresDB{DB: global})

	// Tenant values, with the External ID the database generated.
	s, err := repo.TenantSettings(ctx, awsTenantA)
	if err != nil || s == nil || s.Domain != "acme.com" || s.AWSAccountID != "189160505560" || len(s.ExternalID) < 16 {
		t.Fatalf("TenantSettings(A) = %+v, %v", s, err)
	}
	if s, err := repo.TenantSettings(ctx, awsTenantB); err != nil || s == nil || s.AWSAccountID != "" || s.ExternalID == "" {
		t.Fatalf("TenantSettings(B) = %+v, %v", s, err)
	}
	if s, err := repo.TenantSettings(ctx, "33333333-3333-3333-3333-333333333333"); err != nil || s != nil {
		t.Fatalf("TenantSettings(unknown) = %+v, %v", s, err)
	}

	now := time.Now().UTC().Truncate(time.Microsecond)
	rec := modelsv1.AWSAccountRecord{
		TenantID: awsTenantA, AccountID: "222222222222", RoleARN: "arn:aws:iam::222222222222:role/NHIPlatformCollector",
		Regions: []string{"us-east-1", "ap-south-1"}, ExternalID: s.ExternalID, Status: modelsv1.AWSStatusActionNeeded,
		Checks: []modelsv1.AWSCheck{{Key: "assume_role", Label: "Assume your role", State: "pass"}}, LastVerifiedAt: now, LastVerifiedBy: "alice",
	}
	// Failing checks: saved, not queued.
	saved, queued, err := repo.SaveVerification(ctx, rec)
	if err != nil || queued || saved.ConnectedAt != nil || saved.SyncStatus != "idle" || !reflect.DeepEqual(saved.Regions, rec.Regions) || saved.ExternalID != s.ExternalID {
		t.Fatalf("SaveVerification(action_needed) = %+v, %v, %v", saved, queued, err)
	}
	// First pass: connected and the first sync queued.
	rec.Status, rec.LastVerifiedAt = modelsv1.AWSStatusConnected, now.Add(time.Minute)
	saved, queued, err = repo.SaveVerification(ctx, rec)
	if err != nil || !queued || saved.ConnectedAt == nil || saved.SyncStatus != "queued" || saved.SyncRequestedBy != "alice" || saved.SyncRequestedAt == nil {
		t.Fatalf("SaveVerification(connected) = %+v, %v, %v", saved, queued, err)
	}
	firstConnected := *saved.ConnectedAt
	// Verified again: no second queue, connected_at kept, regions replaced.
	rec.Regions, rec.LastVerifiedAt = []string{"eu-west-1"}, now.Add(2*time.Minute)
	saved, queued, err = repo.SaveVerification(ctx, rec)
	if err != nil || queued || !saved.ConnectedAt.Equal(firstConnected) || !reflect.DeepEqual(saved.Regions, []string{"eu-west-1"}) {
		t.Fatalf("SaveVerification(again) = %+v, %v, %v", saved, queued, err)
	}

	// Sync: already queued -> unchanged; the worker finishes -> queue again.
	if got, already, err := repo.RequestSync(ctx, awsTenantA, "222222222222", "bob", now); err != nil || !already || got.SyncRequestedBy != "alice" {
		t.Fatalf("RequestSync while queued = %+v, %v, %v", got, already, err)
	}
	mustExec(t, global, `UPDATE nhi_schema.tenant_aws_accounts SET sync_status = 'succeeded', last_synced_at = now(), last_sync_error = 'old'`)
	got, already, err := repo.RequestSync(ctx, awsTenantA, "222222222222", "bob", now.Add(3*time.Minute))
	if err != nil || already || got.SyncStatus != "queued" || got.SyncRequestedBy != "bob" || got.LastSyncError != "" || got.LastSyncedAt == nil {
		t.Fatalf("RequestSync = %+v, %v, %v", got, already, err)
	}
	if _, _, err := repo.RequestSync(ctx, awsTenantA, "333333333333", "bob", now); !errors.Is(err, ErrAWSAccountNotFound) {
		t.Fatalf("RequestSync(unknown) = %v", err)
	}
	if _, _, err := repo.RequestSync(ctx, awsTenantB, "222222222222", "bob", now); !errors.Is(err, ErrAWSAccountNotFound) {
		t.Fatalf("RequestSync from another tenant = %v", err)
	}
	mustExec(t, global, `UPDATE nhi_schema.tenant_aws_accounts SET status = 'action_needed', sync_status = 'idle'`)
	if _, _, err := repo.RequestSync(ctx, awsTenantA, "222222222222", "bob", now); !errors.Is(err, ErrAWSAccountNotConnected) {
		t.Fatalf("RequestSync(not connected) = %v", err)
	}
	mustExec(t, global, `UPDATE nhi_schema.tenant_aws_accounts SET status = 'connected'`)

	// Regions.
	if got, err := repo.UpdateRegions(ctx, awsTenantA, "222222222222", []string{"us-west-2", "eu-west-1"}); err != nil || !reflect.DeepEqual(got.Regions, []string{"us-west-2", "eu-west-1"}) {
		t.Fatalf("UpdateRegions = %+v, %v", got, err)
	}
	if _, err := repo.UpdateRegions(ctx, awsTenantB, "222222222222", []string{"us-west-2"}); !errors.Is(err, ErrAWSAccountNotFound) {
		t.Fatalf("UpdateRegions from another tenant = %v", err)
	}

	// Lists are per tenant; one AWS account belongs to one tenant.
	if list, err := repo.ListAccounts(ctx, awsTenantA); err != nil || len(list) != 1 || list[0].Checks[0].Key != "assume_role" {
		t.Fatalf("ListAccounts(A) = %+v, %v", list, err)
	}
	if list, err := repo.ListAccounts(ctx, awsTenantB); err != nil || len(list) != 0 {
		t.Fatalf("ListAccounts(B) = %+v, %v", list, err)
	}
	if claimed, err := repo.AccountClaimedByOther(ctx, awsTenantB, "222222222222"); err != nil || !claimed {
		t.Fatalf("AccountClaimedByOther(B) = %v, %v", claimed, err)
	}
	other := rec
	other.TenantID = awsTenantB
	if _, _, err := repo.SaveVerification(ctx, other); !errors.Is(err, ErrAWSAccountClaimed) {
		t.Fatalf("SaveVerification for a second tenant = %v", err)
	}

	// Delete.
	if err := repo.DeleteAccount(ctx, awsTenantB, "222222222222"); !errors.Is(err, ErrAWSAccountNotFound) {
		t.Fatalf("DeleteAccount from another tenant = %v", err)
	}
	if err := repo.DeleteAccount(ctx, awsTenantA, "222222222222"); err != nil {
		t.Fatal(err)
	}
	if acc, err := repo.GetAccount(ctx, awsTenantA, "222222222222"); err != nil || acc != nil {
		t.Fatalf("after delete: %+v, %v", acc, err)
	}

	// ── tenant database registry ──
	mustExec(t, tenant, `DELETE FROM nhi_scanner.accounts`)
	mustExec(t, tenant, `INSERT INTO nhi_scanner.accounts (tenant_id, account_id, region, is_default) VALUES
		($1, '222222222222', 'global', false), ($1, '222222222222', 'eu-west-1', false), ($1, '444444444444', 'us-east-1', true)`, awsTenantA)
	reg := NewTenantAccountRegistry(staticTenantDB{tenant})
	regions := func(account string) []string {
		rows, err := tenant.Query(`SELECT region FROM nhi_scanner.accounts WHERE tenant_id = $1 AND account_id = $2`, awsTenantA, account)
		if err != nil {
			t.Fatal(err)
		}
		defer rows.Close()
		out := []string{}
		for rows.Next() {
			var r string
			_ = rows.Scan(&r)
			out = append(out, r)
		}
		sort.Strings(out)
		return out
	}
	if err := reg.Register(ctx, "nhi_tenant_a", awsTenantA, "222222222222", []string{"us-east-1", "ap-south-1"}); err != nil {
		t.Fatal(err)
	}
	// eu-west-1 deselected and removed, global kept, the two new added.
	if got, want := regions("222222222222"), []string{"ap-south-1", "global", "us-east-1"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("after Register: %v, want %v", got, want)
	}
	// Idempotent and safe under concurrent verifies.
	var wg sync.WaitGroup
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = reg.Register(ctx, "nhi_tenant_a", awsTenantA, "222222222222", []string{"us-east-1", "ap-south-1"})
		}()
	}
	wg.Wait()
	var n int
	_ = tenant.QueryRow(`SELECT count(*) FROM nhi_scanner.accounts WHERE account_id = '222222222222' AND region = 'us-east-1'`).Scan(&n)
	if n != 1 {
		t.Fatalf("%d rows for one region after concurrent registers, want 1", n)
	}
	var isDefault bool
	_ = tenant.QueryRow(`SELECT bool_and(is_default) FROM nhi_scanner.accounts WHERE account_id = '222222222222' AND region IN ('us-east-1','ap-south-1')`).Scan(&isDefault)
	if !isDefault {
		t.Fatal("new regions should join the default scope")
	}
	if err := reg.Unregister(ctx, "nhi_tenant_a", awsTenantA, "222222222222"); err != nil {
		t.Fatal(err)
	}
	if got := regions("222222222222"); len(got) != 0 {
		t.Fatalf("after Unregister: %v", got)
	}
	if got := regions("444444444444"); !reflect.DeepEqual(got, []string{"us-east-1"}) {
		t.Fatalf("another account was touched: %v", got)
	}
}
