package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/joho/godotenv"

	"nhi-backend-api/internal/awsconnect"
	"nhi-backend-api/internal/clickhouse"
	"nhi-backend-api/internal/config"
	"nhi-backend-api/internal/handlers"
	"nhi-backend-api/internal/handlers/credential_exposure"
	handlerv1 "nhi-backend-api/internal/handlers/v1"
	"nhi-backend-api/internal/middleware"
	"nhi-backend-api/internal/repository"
	chrepo "nhi-backend-api/internal/repository/clickhouse"
	repoce "nhi-backend-api/internal/repository/credential_exposure"
	repov1 "nhi-backend-api/internal/repository/v1"
	"nhi-backend-api/internal/routes"
	"nhi-backend-api/internal/scope"
	"nhi-backend-api/internal/services"
	svcce "nhi-backend-api/internal/services/credential_exposure"
	svcv1 "nhi-backend-api/internal/services/v1"
)

func main() {
	// Optional .env for local runs; variables already in the environment win.
	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
		log.Fatalf("load .env: %v", err)
	}

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load configuration: %v", err)
	}

	// DB is the global authentication/tenant registry pool. Tenant pools are
	// opened only through the registry-validated db_name in a signed token.
	db, err := repository.NewPostgresDB(cfg)
	if err != nil {
		log.Fatalf("connect to global database: %v", err)
	}
	defer func() {
		if err := db.Close(); err != nil {
			log.Printf("close database pools: %v", err)
		}
	}()

	// ClickHouse (CloudTrail events) is optional. If it is unconfigured or
	// unreachable the API keeps serving Postgres data; chClient is then nil.
	chCtx, chCancel := context.WithTimeout(context.Background(), 10*time.Second)
	chClient, err := clickhouse.New(chCtx, cfg.ClickHouse)
	chCancel()
	switch {
	case err != nil:
		log.Printf("WARNING: clickhouse unavailable, activity data disabled: %v", err)
	case chClient == nil:
		log.Printf("clickhouse not configured; activity data disabled")
	default:
		log.Printf("clickhouse connected (%s:%d/%s)", cfg.ClickHouse.Host, cfg.ClickHouse.Port, cfg.ClickHouse.Database)
	}
	defer func() {
		if err := chClient.Close(); err != nil {
			log.Printf("close clickhouse: %v", err)
		}
	}()
	activityService := svcv1.NewActivityService(chrepo.New(chClient), repov1.NewIdentityLookupRepository())

	userRepo := repository.NewUserRepository(db)
	resolver := scope.NewResolver(db, db.DataSchema())

	authService := services.NewAuthService(userRepo, cfg.JWT)
	authHandler := handlers.NewAuthHandler(authService)
	authMiddleware := middleware.NewAuthMiddleware(cfg.JWT, userRepo)

	filterHandler := handlerv1.NewFilterHandler(svcv1.NewFilterService(repov1.NewFilterRepository(), resolver))
	settingsHandler := handlerv1.NewSettingsHandler(svcv1.NewSettingsService(repov1.NewSettingsRepository(), db, resolver))
	dashboardHandler := handlerv1.NewDashboardOverviewHandler(svcv1.NewDashboardOverviewService(repov1.NewDashboardOverviewRepository(), resolver, activityService))
	identitiesHandler := handlerv1.NewIdentitiesListHandler(svcv1.NewIdentitiesListService(repov1.NewIdentitiesListRepository(), resolver, activityService))
	identityDetailHandler := handlerv1.NewIdentityDetailHandler(svcv1.NewIdentityDetailService(repov1.NewIdentityDetailRepository(), resolver, activityService))
	credentialsHandler := handlerv1.NewCredentialsHandler(svcv1.NewCredentialsService(repov1.NewCredentialsRepository(), resolver, activityService))
	credentialDetailHandler := handlerv1.NewCredentialDetailHandler(svcv1.NewCredentialDetailService(repov1.NewCredentialDetailRepository(), resolver, activityService))

	permissionSourceHandler := handlerv1.NewPermissionSourceHandler(svcv1.NewPermissionSourceService(repov1.NewPermissionSourceRepository(), resolver))

	// AWS account connection. The SDK's default chain supplies this process's
	// identity (task role, instance profile, AWS_PROFILE); credentials resolve
	// on first use, so a host without AWS access still serves every other route.
	var awsVerifier svcv1.AWSVerifier
	var awsClient *awsconnect.Client
	awsCtx, awsCancel := context.WithTimeout(context.Background(), 10*time.Second)
	awsBase, err := awsconfig.LoadDefaultConfig(awsCtx)
	awsCancel()
	if err != nil {
		log.Printf("aws integration: AWS configuration unavailable, connection checks disabled: %v", err)
	} else {
		awsClient = awsconnect.NewClient(awsBase, cfg.AWSIntegration.AssumeAssumerRole, cfg.AWSIntegration.EventLogGroup)
		awsVerifier = awsClient
	}
	// "Events received" reads the CloudTrail store the pipeline fills from the
	// central bus; a CloudWatch Logs group is the fallback without ClickHouse.
	var awsEvents svcv1.AWSEventSource
	switch chRepo := chrepo.New(chClient); {
	case chRepo.Enabled():
		awsEvents = svcv1.ClickHouseEventSource{Repo: chRepo}
	case awsClient != nil && cfg.AWSIntegration.EventLogGroup != "":
		awsEvents = awsClient
	default:
		log.Printf("aws integration: no event store (ClickHouse or aws_integration.event_log_group); the events check cannot run")
	}
	awsIntegrationHandler := handlerv1.NewAWSIntegrationHandler(svcv1.NewAWSIntegrationService(
		repository.NewAWSIntegrationRepository(db),
		repository.NewTenantAccountRegistry(db),
		awsVerifier,
		awsEvents,
		svcv1.AWSIntegrationOptions{
			AssumerRoleName:   cfg.AWSIntegration.AssumerRoleName,
			CollectorRoleName: cfg.AWSIntegration.CollectorRoleName,
			ForwardRuleName:   cfg.AWSIntegration.ForwardRuleName,
			EventLookback:     time.Duration(cfg.AWSIntegration.EventLookbackHours) * time.Hour,
		},
	))

	// Credential Exposure — tenant-isolated, admin-only
	ceFindingsRepo := repoce.NewFindingsRepository()
	ceAllowlistRepo := repoce.NewAllowlistRepository()
	ceDecisionRepo := repoce.NewDecisionRepository()
	ceDeepScanRepo := repoce.NewDeepScanRepository()

	ceFindingsService := svcce.NewFindingsService(ceFindingsRepo, resolver)
	ceAllowlistService := svcce.NewAllowlistService(ceAllowlistRepo, resolver)
	ceDecisionService := svcce.NewDecisionService(ceDecisionRepo, resolver)
	ceDeepScanService := svcce.NewDeepScanService(ceDeepScanRepo, resolver, cfg.Scanner.BaseURL, cfg.Scanner.DashboardKey)

	ceFindingsHandler := credential_exposure.NewFindingsHandler(ceFindingsService)
	ceAllowlistHandler := credential_exposure.NewAllowlistHandler(ceAllowlistService)
	ceDecisionHandler := credential_exposure.NewDecisionHandler(ceDecisionService)
	ceDeepScanHandler := credential_exposure.NewDeepScanHandler(ceDeepScanService)

	router := routes.SetupRoutes(routes.HandlerContainer{
		AuthHandler:                    authHandler,
		AuthMiddleware:                 authMiddleware,
		NewAPIFilterHandler:            filterHandler,
		NewAPISettingsHandler:          settingsHandler,
		NewAPIDashboardOverviewHandler: dashboardHandler,
		NewAPIIdentitiesListHandler:    identitiesHandler,
		NewAPIIdentityDetailHandler:    identityDetailHandler,
		NewAPICredentialsHandler:       credentialsHandler,
		NewAPICredentialDetailHandler:  credentialDetailHandler,
		NewAPIPermissionSourceHandler:  permissionSourceHandler,
		AWSIntegrationHandler:          awsIntegrationHandler,

		CredentialExposureFindingsHandler:  ceFindingsHandler,
		CredentialExposureAllowlistHandler: ceAllowlistHandler,
		CredentialExposureDecisionHandler:  ceDecisionHandler,
		CredentialExposureDeepScanHandler:  ceDeepScanHandler,
	})

	server := &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
		Handler:      middleware.SetupCORS(cfg.CORS)(router),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}
	// Drain in-flight requests on SIGINT/SIGTERM so deferred cleanup (pool
	// close) runs instead of the process being killed mid-request.
	sigCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	serveErr := make(chan error, 1)
	go func() { serveErr <- server.ListenAndServe() }()
	log.Printf("NHI API server listening on %s", server.Addr)

	select {
	case err := <-serveErr:
		if err != nil && err != http.ErrServerClosed {
			// Keep the original non-zero exit; close pools first since Fatalf skips defers.
			_ = db.Close()
			log.Fatalf("API server: %v", err)
		}
	case <-sigCtx.Done():
		log.Printf("shutdown signal received, draining requests")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdownCtx); err != nil {
			log.Printf("graceful shutdown: %v", err)
		}
	}
}
