# NHI Backend API — merged build

A hardened merge of the two candidate backends, validated against
`AWS-NHI Updated API.pdf` and against a real PostgreSQL instance.

**Base:** the `read.txt` tree — chosen because the tenant/account/region boundary is
enforced in one place (`internal/scope`), not re-implemented per endpoint.
**Harvested from:** the `b1.txt` tree — richer detail-tab payloads, concurrent dashboard
loading, and strict `time_range` handling, all re-expressed on top of the scoped base.

```
go build ./...            # clean
go vet ./...              # clean
go test ./...             # clean (also under -race)
```

---

## Tenant architecture

Three tiers, exactly as the document specifies:

```
nhi_global (config: global_database)
  └── nhi_schema.tenants     tenant_id (uuid) → db_name
  └── nhi_schema.nhi_users   email, bcrypt hash, role, tenant_id, status, last_login_at

nhi_tenant_<name>  (opened on demand, name comes from the JWT — never from config)
  └── nhi_scanner.*          identities, credentials, trust_edges, user_settings, …
```

**One choke point.** Every data request resolves through `scope.Resolver.Resolve()`,
which returns a `DataScope` carrying the tenant's pool *and* the effective
`AccountIDs / Regions / ScanID`:

```go
resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
// every repository entry point takes the scope, never a bare *sql.DB
rows, err := s.repo.List(ctx, resolved, filter)
// DataScope.Predicates("i") → i.scan_id = $1 AND i.account_id = ANY($2) AND i.region = ANY($3)
```

Because the repositories cannot be called without a `DataScope`, steps 3–7 of the
document's "Every Data API" flow are structurally impossible to skip.
`user_settings` appears in exactly one non-test file in the repository.

**No fallback.** `Manager.Tenant("")` returns `ErrTenantDBNotConfigured`. A tenant with no
`db_name` is an error, never a silent switch to another database.

---

## What changed relative to the two inputs

### Correctness / security

| Change | Why |
|---|---|
| **Scoped graph traversal** (`internal/repository/v1/graph_scope.go`) | A graph BFS cannot be constrained by a SQL predicate: hop 2 walks out of the selected accounts. The traversal now prunes every hop against the caller's account/region before expanding the frontier, and fails closed on unparseable ARNs. |
| **`relationships` tab enabled** on both detail endpoints | It was implemented but gated off in `read.txt` ("disabled until graph scope is enforced") and enabled-but-unscoped in `b1.txt`. It is now both enabled and safe — 6/6 tabs per the document. |
| **De-duplicated BFS edges** | Found against the live database: `loadEdgesTouching` matches `source = ANY(frontier) OR target = ANY(frontier)`, so an edge was re-emitted on every hop that touched it. A depth-2 walk reported the same edge twice. |
| **Consolidated `errScopeRequired` sentinel** | Four repositories each built their own `fmt.Errorf("tenant scope is required")`, so callers could not use `errors.Is`. |
| **`page_size` capped at 100**, **`depth` bounded to 1–3** | The document's stated limits were not enforced; `depth` accepted any value and `page_size` was unbounded. |
| **Strict `?time_range=`** (ported from `b1.txt`) | `"banana"` used to silently become 90 days. It is now a 400 with an actionable message, and the response echoes a canonical label rather than raw client input. |
| **Dead legacy code removed** | 301 → 43 Go files. Removed the unrouted dashboard/inventory/credential-exposure packages, which also cleared a genuine `go vet` failure (`fmt.Sprintf` arity bug in `shared_credentials_repo.go`). |
| **`migrations/tenant/001` creates its schema** | It assumed `nhi_scanner` already existed and failed on a fresh tenant database. |

### Performance

**Concurrent dashboard overview.** The four independent loaders (KPIs, identity charts,
credential charts, growth charts) now run in parallel with first-error cancellation of the
remaining queries, instead of sequentially. They write disjoint fields of the response
struct, verified under `-race`.

### Tests

Unit coverage for the parts where a mistake is a tenant-isolation bug:

| Package | Covers |
|---|---|
| `internal/repository/v1` | ARN account/region parsing, scope allow/deny including fail-closed, edge pruning, frontier never leaving scope, BFS de-duplication |
| `internal/scope` | `Predicates()` / `QueryArgs()` shape, empty-scope safety |
| `internal/database` | Identifier quoting, `Tenant()` has no fallback, validation rejects injection attempts |
| `internal/config` | Rejects a tenant `database_name` in config, unsafe schema identifiers, weak JWT secret, out-of-range expiry |
| `pkg/jwt` | Claim round-trip, tamper rejection, wrong-secret rejection, weak-secret rejection |
| `internal/routes` | All seven data endpoints return 401 without a token; 404/405 always return JSON |

---

### Integration tests against real databases

These skip unless pointed at a tenant (a SKIP means nothing was tested):

```bash
export NHI_TEST_TENANT_DB=<tenant db> NHI_TEST_TENANT_ID=<tenant uuid> NHI_TEST_USER_ID=<user email>
# ClickHouse comes from .env (NHI_CLICKHOUSE_*); use NHI_CLICKHOUSE_PROTOCOL=http|native
go test ./internal/repository/clickhouse ./internal/services/v1 ./internal/handlers/v1 -count=1 -v
```

They are read-only: every service and handler is exercised with ClickHouse,
without it, and with ClickHouse failing on every query.

The AWS integration repository test writes to Postgres, so it has its own
switch:

```bash
NHI_TEST_GLOBAL_DSN='postgres://…/nhi_global' NHI_TEST_TENANT_DSN='postgres://…/nhi_tenant_x' \
  go test ./internal/repository -run AWSIntegration -count=1 -v
```

It creates two throwaway tenants with random IDs, touches only those rows and
deletes them afterwards. Point it at a test database all the same.

## Running it locally

```bash
# 1. Postgres, then seed two tenants in two databases
export PGHOST=127.0.0.1 PGPORT=5432 PGUSER=postgres
./scripts/seed_two_tenants.sh

# 2. Point configs/config.yaml at that Postgres and run
NHI_CONFIG_FILE=configs/config.yaml go run ./cmd/api-server

# 3. Verify the tenant guarantees end to end
./scripts/e2e_tenant_scope.sh          # 16 assertions
```

`scripts/test_schema.sql` is a stand-in for the scanner's schema, which this repository
does not own. It is only for local verification — column names were derived from the
queries in `internal/repository/v1`, so treat it as a harness, not as the real schema.

### CloudTrail activity (ClickHouse)

CloudTrail events live in ClickHouse (`cloudtrail_events`); Postgres no longer
stores `identity_usage`, `permission_usage` or `resources`, and the columns
`identities.last_activity_at`, `identities.cloudtrail_creator_arn` and
`credentials.last_used_at` are no longer written by the collector. The two
databases are joined **by ARN only** (never by UUID or scan id):

| ClickHouse | Matches |
|---|---|
| `session_issuer_arn` | `credentials.arn` (a role) |
| `caller_arn` | `identities.arn` (IAM users, root) or an assumed-role session |
| `access_key_id` | `credentials.name` where `credential_type = 'access_key'` |

- **Layout:** `internal/clickhouse` (connection), `internal/repository/clickhouse`
  (SQL, raw rows), `internal/repository/v1/activity_source.go` (the interface the
  repositories use), `internal/services/v1/activity_*.go` (cache, analytics, tab
  builders), `internal/services/v1/identity_resolver.go` (caller → identity).
- **Isolation:** every ClickHouse query is bound to all accounts of the tenant
  (`accounts` table), whatever the user ticked in Settings.
- **Degradation:** unset (`NHI_CLICKHOUSE_HOST` empty), unreachable or failing
  ClickHouse never turns a response into an error. Activity fields are `null` or
  empty and `activity_data_available` is `false`.
- **Lists and dashboard:** idle days, `min_idle_days`, sorting by
  `last_activity_at` / `idle_days` / `last_used_at` / `permission_utilization_pct`
  (and the default sorts) are applied in Go over one bulk ClickHouse lookup,
  cached for 5 minutes. Stale detection falls back to the creation date for
  items never seen in CloudTrail.
- **Windows:** "what a credential actually used" (permission utilisation, the
  permissions tab, the trust summary) looks back 90 days; the relationships tab's
  ACCESSES edges use the requested `time_range`; last-seen is unbounded.
- **Events:** the activity tabs take `page` and `page_size` (max 100, at most 1000
  events per request). Every event carries `caller_arn`, `caller_type` and, when it
  resolves to the inventory, `credential_id/name`, `identity_id/name` and
  `terminated`; events that match nothing keep the raw ARN. ACCESSES edges carry
  `call_count`.
- **Permission source (on demand):** `GET /api/v1/permission-source?credential_id=&event_source=&event_name=`
  returns the policy that granted one event (`policy_source`, `policy_type`,
  `effect`, `resource_arn`, `matched_action`; wildcards such as `ec2:Describe*`
  match, an exact Allow beats a wildcard or a Deny). Nothing matched gives
  `matched: false` and "Policy may have changed since this event".
- **Config:** `NHI_CLICKHOUSE_*` (see `.env.example`); `NHI_CLICKHOUSE_PROTOCOL`
  is `native` (TCP 9000/9440) or `http` (8123/8443).
- **Checking a deployment:** `go run ./cmd/ch-check` prints the table schema, row
  counts, account IDs and ARN-field coverage (read-only).

### Endpoints

| # | Endpoint | Notes |
|---|---|---|
| — | `POST /api/v1/login`, `/api/auth/login` | bcrypt; rejects `status != 'active'`; updates `last_login_at` |
| 1a | `GET /api/v1/settings` | `user_settings` → `accounts.is_default` → latest completed scan |
| 1b | `PUT /api/v1/settings` | upsert; JWT is unchanged |
| 2 | `GET /api/v1/filters` | all dropdown options |
| 3 | `GET /api/v1/dashboard/overview` | KPIs + 13 charts, loaded concurrently |
| 4 | `GET /api/v1/identities` | paginated (max 100), searchable, filterable, sortable |
| 5 | `GET /api/v1/identities/{id}?tab=` | overview, permissions, activity, relationships, credentials, raw |
| 6 | `GET /api/v1/credentials` | |
| 7 | `GET /api/v1/credentials/{id}?tab=` | overview, trust, activity, rotation, relationships, raw |
| 8 | `GET /api/v1/permission-source` | policy behind one CloudTrail event, looked up on demand |
| 9 | `GET /api/v1/integrations/aws` | tenant's setup values + connected accounts (setup values: admin only) |
| 10 | `POST /api/v1/integrations/aws/verify` | admin; `{role_arn, regions}` → 3 checks, saves the account |
| 11 | `PUT /api/v1/integrations/aws/accounts/{account_id}/regions` | admin; `{regions}` |
| 12 | `POST /api/v1/integrations/aws/accounts/{account_id}/sync` | admin; 202, queues a sync |
| 13 | `DELETE /api/v1/integrations/aws/accounts/{account_id}` | admin; removes the account |
| 14 | `GET /api/v1/credential-exposure/findings` | admin; `limit` (≤500), `offset`, `client_id`, `platform`, `ml_flagged`; or `finding_id` alone |
| 15 | `GET /api/v1/credential-exposure/findings/flagged` | admin; findings the model marked false positive |
| 16 | `GET /api/v1/credential-exposure/findings/summary` | admin; totals by severity, affected repositories |
| 17 | `POST /api/v1/credential-exposure/decisions` | admin; `{finding_id, decision}` (`real_secret` / `false_positive`) |
| 18 | `GET`/`POST`/`DELETE /api/v1/credential-exposure/allowlist` | admin; accept a finding / list / restore |
| 19 | `POST /api/v1/credential-exposure/deep-scan`, `GET …/deep-scan/status` | admin; proxied to the scanner (`SECRET_SCANNER_BASE_URL`, https) |

Decisions and accepted findings are attributed to the signed-in user (the
token's email). `decided_by` / `dismissed_by` in a request body are accepted
for older clients but ignored, so nobody can record a verdict in someone
else's name.

---

## Connect AWS Account (Integrations page)

### The flow

1. **Super admin onboards a tenant** (separate admin page) — one row in
   `nhi_schema.tenants` with its database, email domain, our AWS account and
   our event bus. The External ID is generated by the database.
2. **The tenant's users log in** with the accounts we give them on their
   domain; the JWT carries `tenant_id` and `db_name`.
3. **Integrations page** shows *that tenant's* account number, External ID and
   event bus inside the setup steps. The customer creates a read-only role and
   an EventBridge rule in their AWS account, pastes the role ARN, picks the
   regions we may read, and clicks Verify.
4. **Verify** runs three checks and saves the account. Once all pass, the account
   is registered in the tenant database and its first sync is queued.
5. **Accounts table**: every connected account, with Sync now, Edit regions,
   Re-check and Remove.

### Database (apply `migrations/global/002_tenant_aws_integration.sql`)

Global DB, safe to run again. Without it the page answers 503
`AWS_PLATFORM_NOT_CONFIGURED` (Postgres `42P01`).

`nhi_schema.tenants` gains:

| Column | Example | Rule |
|---|---|---|
| `domain` | `acme.com` | lowercase, no `@`, unique |
| `aws_account_id` | `189160505560` | 12 digits — **our** account the customer's role trusts |
| `event_bus_arn` | `arn:aws:events:ap-south-1:189160505560:event-bus/nhi-central-bus` | **our** central bus |
| `external_id` | `ext-3f9c…` | generated; 16–1224 chars, unique. Never change it once customers use it |

The super-admin onboarding insert:

```sql
INSERT INTO nhi_schema.tenants (tenant_id, db_name, domain, aws_account_id, event_bus_arn)
VALUES (gen_random_uuid(), 'nhi_tenant_acme', 'acme.com', '189160505560',
        'arn:aws:events:ap-south-1:189160505560:event-bus/nhi-central-bus')
RETURNING tenant_id, external_id, created_at;
```

`nhi_schema.tenant_aws_accounts` — one row per connected customer account:
`aws_account_id`, `regions text[]`, `role_arn`, `external_id`, `status`
(`connected` / `action_needed`), `checks`, `last_verified_*`, `connected_at`,
and the sync state below. An AWS account can belong to one tenant only.

Upgrading from the earlier integration build: the old
`aws_platform_settings` / `tenant_aws_integrations` values are copied into
`tenants` and the old tables renamed `*_migrated` (drop them after checking).

**Tenant database.** A connected account is also written to the tenant's
`nhi_scanner.accounts` (one row per allowed region, new rows
`is_default = true`). That table is the scope for the dashboard, filters,
settings and ClickHouse isolation, so a connected account shows up everywhere.
Editing regions updates those rows. Removing the account deletes them. The
activity service caches the list for 5 minutes.

### Verify — the three checks

| Check | How | Fix shown to the customer |
|---|---|---|
| Assume your role | `sts:AssumeRole` with the ARN + the tenant's External ID | Check the External ID matches |
| Read your account | `iam:ListRoles` (1 item) with that session | Attach SecurityAudit + ViewOnlyAccess |
| Receive your events | adds the account to our bus policy, then looks for an event from it in the last `event_lookback_hours` | Check the EventBridge rule target ARN |

Events are read from ClickHouse `cloudtrail_events` (`account_id`,
`event_time`). That assumes the pipeline ingests what arrives on the central
bus. Without ClickHouse, set `aws_integration.event_log_group` to the CloudWatch
log group the bus writes to; with neither, the check reports it cannot run.

One verify per tenant at a time (429 `AWS_VERIFY_IN_PROGRESS`), 12 s budget.
Nothing is saved unless AssumeRole succeeds.

### Sync contract (discovery worker)

The API only queues. `POST …/sync` (and the first successful verify) sets
`sync_status = 'queued'`. The worker claims one row at a time:

```sql
UPDATE nhi_schema.tenant_aws_accounts
   SET sync_status = 'running', sync_started_at = now()
 WHERE (tenant_id, aws_account_id) = (
       SELECT tenant_id, aws_account_id FROM nhi_schema.tenant_aws_accounts
        WHERE sync_status = 'queued' ORDER BY sync_requested_at
        FOR UPDATE SKIP LOCKED LIMIT 1)
RETURNING tenant_id, aws_account_id, role_arn, external_id, regions;
```

The worker reads **only** `regions`, assuming `role_arn` with `external_id`. At
the end it sets `sync_status = 'succeeded', last_synced_at = now(),
last_sync_error = NULL`, or `'failed'` with a short `last_sync_error` (shown to
the customer). The page polls while a sync is queued or running.

### AWS identity of the API server

No AWS keys in config files. The SDK default chain is used:

- **Production (ECS / EC2):** run the API *as* `NHIPlatformAssumer` (task role
  or instance profile) and keep `assume_assumer_role: false`.
- **Locally:** `aws configure --profile nhi-platform`, then
  `AWS_PROFILE=nhi-platform` and `assume_assumer_role: true` (or
  `NHI_AWS_ASSUME_ASSUMER_ROLE=true`). Your profile must be allowed to assume
  `arn:aws:iam::<tenant aws_account_id>:role/NHIPlatformAssumer`.

`NHIPlatformAssumer` needs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    { "Effect": "Allow", "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/NHIPlatformCollector" },
    { "Effect": "Allow",
      "Action": ["events:DescribeEventBus", "events:PutPermission", "events:RemovePermission"],
      "Resource": "arn:aws:events:<region>:<our account>:event-bus/<bus name>" },
    { "Effect": "Allow", "Action": "logs:FilterLogEvents",
      "Resource": "arn:aws:logs:<region>:<our account>:log-group:<event_log_group>:*" }
  ]
}
```

The last statement is only needed with `event_log_group`. Settings live under
`aws_integration` in `configs/config.yaml`, with `NHI_AWS_*` overrides (see
`.env.example`).

**Scale note.** Each connected account adds one statement
(`Sid nhi-client-<account>`) to the bus's resource policy, which AWS caps at
about 10 KB (≈100+ accounts per bus). Past that, switch the policy to an
`aws:PrincipalOrgID` condition or shard buses across tenants.

### Errors

| HTTP | `error` | When |
|---|---|---|
| 400 | `INVALID_ROLE_ARN`, `INVALID_REGIONS`, `INVALID_ACCOUNT_ID`, `INVALID_REQUEST` | bad input |
| 403 | `FORBIDDEN` | not an admin |
| 404 | `AWS_ACCOUNT_NOT_FOUND` | not this tenant's account |
| 409 | `AWS_ACCOUNT_NOT_CONNECTED` | sync before the checks pass |
| 409 | `AWS_ACCOUNT_IN_USE` | account belongs to another tenant |
| 429 | `AWS_VERIFY_IN_PROGRESS` | a check is already running |
| 503 | `AWS_PLATFORM_NOT_CONFIGURED` | migration missing or tenant row has no AWS values |
| 503 | `AWS_UNAVAILABLE` | AWS unreachable / server has no AWS identity |
| 500 | `AWS_WORKSPACE_UPDATE_FAILED` | tenant DB registration failed |

---

## Known gaps

- **Endpoint 7 `trust` / `rotation` payloads** are thinner than endpoint 5's.
  `b1.txt` had richer bodies; porting them is mechanical (same
  `(ctx, resolved, id)` signature) but was not completed here.
- **CloudTrail data depends on ClickHouse.** With ClickHouse unset or down every
  endpoint still answers from Postgres; the activity tabs are empty and the
  responses carry `activity_data_available: false` (see below).
- **Role-session attribution is only unit-tested.** The dev ClickHouse has no
  `session_issuer_arn` values, so resolving role sessions to identities, creator
  lookup and permission usage have fixture tests but no real-data test yet.
- **AWS sync needs the discovery worker** to consume the queue described
  above; the API never scans AWS itself.
- **`domain` is not yet checked at login.** Users are tied to a tenant by
  `nhi_users.tenant_id`; matching the email domain is the onboarding page's job.
- **`scripts/test_schema.sql`** is a local harness, not the production schema.
