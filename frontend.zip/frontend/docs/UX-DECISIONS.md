# NHI Console - UX decisions and screen validation

The plan the implementation follows. Revision 3: acts on review feedback about
the shell, the posture column, and the six screens that had not yet had a
proper design pass.

---

## 1. Product archetype

**Security / observability console** - the Wiz, CrowdStrike Falcon, Datadog
family. Chosen because the user's job here is *triage*, not authoring.

| Archetype | Why not |
|---|---|
| Cloud provider console (AWS/Azure) | Resource-detail-as-full-page loses the operator's place in a 137-row list. |
| Enterprise suite (Salesforce/ServiceNow) | Built for record creation, bulk edit, approval chains. This API has one write. |
| Modern B2B SaaS (Linear/Stripe) | Too airy for the data volume, and brand in the sidebar is wrong for a console. |

---

## 2. Shell specification (revised)

```
┌──────────────────────────────────────────────────────────────────┐
│ [DEEP ALGORITHMS]                        [ Search  ⌘K ]   (DA)  │  56px, follows theme
├────────────┬─────────────────────────────────────────────────────┤
│ NHI        │ ‹  Home › Code exposure › Findings   [prod ▾ scan]  │  40px context row
│ DISCOVERY ⟨│─────────────────────────────────────────────────────│
│            │ Secret findings                  [Export] [Refresh] │  title strip
│ POSTURE    │ ┌ All ─ GitHub ─ CodeCommit ┐                       │  view tabs
│  Overview  │ ├──────────┬────────────────┴────────────────────┐   │
│ INVENTORY  │ │ FILTERS  │ records                             │   │
│  ...       │ └──────────┴─────────────────────────────────────┘   │
└────────────┴─────────────────────────────────────────────────────┘
```

Three changes from revision 2, each one a correction:

**The top bar follows the theme.** It was permanently navy. In light mode it is
now a white surface with a hairline base and the dark wordmark; in dark mode
navy with the light wordmark. A permanently dark bar in a light product reads
as a marketing header, not as application chrome.

**The top bar holds exactly three things.** Logo in the left corner; a search
pill and the account avatar in the right corner. Nothing else. Specifically:

- *Search* is a proper pill - icon, the word "Search", a ⌘K chip - sized so it
  reads as a control rather than a cramped afterthought. The command palette
  behind it is the real surface.
- *The account* is the avatar alone. No name, no role, no job title strung out
  across the chrome. That is how Google, Atlassian and GitHub do it, and for a
  good reason: the name is not information the operator needs while working, it
  is information they need when they wonder *who am I signed in as*. So it
  lives inside the menu, with email, role and team.
- *Appearance* (Light / Dark / System) moved into that menu as a three-way
  control. A bare theme toggle in the chrome spends a permanent slot on a
  setting people change twice a year.

**Scan scope moved out of the top bar into a context row**, beside the
breadcrumb. Scope is not global chrome - it is a statement about the data on
*this* screen, so it belongs next to the words that say which screen that is.
The same row carries a **back control**, because a console is a place people
navigate into and the browser button is not a UI.

**The sidebar is titled.** A module header - "NHI DISCOVERY" - sits at the top
with the collapse control beside it, which is where an operator reaches for it.
The old footer ("138 identities in scope") is gone: it restated a number the
page already showed, and filler dressed as telemetry is not enterprise.

**Typography note.** Em and en dashes are replaced with plain hyphens
throughout the interface.

---

## 3. Status, not a fingerprint

Revision 2 rendered posture as five fixed colour slots. It optimised for an
expert scanning a long column and ignored the first-time reader, who has to
learn a legend before the column means anything. In a product where the
operator may open one screen a week, that is a failure.

**Replaced by one status and one reason, in words.**

```
● Critical    MFA disabled  +1 more
● Attention   Dormant 47 days
● Healthy     All checks clear
```

- **One dot, three states** - Critical, Attention, Healthy (plus Unknown when
  nothing was recorded). Three colours total, from the reserved status palette.
- **The leading reason is written out**, so no legend is required. When more
  than one check fails, `+N more` follows, and the full list is the tooltip and
  the accessible label.
- The underlying five checks are unchanged and still documented below - they
  now drive a sentence instead of a bar chart.

| Check | Critical when | Attention when | Source |
|---|---|---|---|
| MFA | human identity with MFA off | - | `mfa_enabled`, `classification` |
| Privilege | admin-equivalent policy attached | - | `is_admin` |
| Ownership | owner type is `ORPHANED` | no owner resolves | `owner_type`, `owner_name`, `primary_owner`, `created_by_name` |
| Activity | last active over 90 days | 30-90 days | `last_active` |
| Secret store | - | credentials in a secret entry | `is_secret` |

Still no score. No 0-100, no letter grade, no weighting: the API supplies none,
and a fabricated score is the most dangerous kind of fake analytics because
people act on it.

---

## 4. Counting without lying

Several screens want totals the summary endpoint does not carry - credentials
by severity, secret-backed identities that are also admin. Rather than compute
them from the loaded page and present them as global figures, the console asks
the API: the same list endpoint with the filter applied and `page_size=1`,
reading `total_count` off the envelope. Cheap, exact, and it cannot drift from
the list it labels.

Where even that is impossible - "mutating vs read-only events", which no
parameter filters - the figure is **either omitted or explicitly scoped**
("in view", "on this page"). A number whose scope is ambiguous is worse than no
number.

---

## 5. Screen-by-screen validation

Every screen answered against the same eleven questions.

### 5.1 Posture (`/posture`)

| Question | Answer |
|---|---|
| Primary goal | "What should I act on before I leave today?" |
| Most attention | The exposure-signal list - the only element ranked by consequence. |
| Easiest actions | Whole signal rows are links carrying the API filter. Scope and refresh are one click. |
| Progressive disclosure | Signal reason always visible; identities one click; a record's credentials two. |
| Fewer clicks | Every counter is a link. Classification slices and credential bars drill through too. |
| Complex data | Signals as meters against *their own* denominator. Composition as a donut whose legend is the value table. Trend as three small multiples, never a dual axis. |
| No data | Per panel: no completed scan, nothing classified, not enough history, and a *positive* state for zero findings. |
| Loading | Metric, donut, bar and timeline skeletons with the real geometry. Panels resolve independently. |
| API failure | Scoped to the failing panel; the scanner diagnoses its own 401 as "not configured". |
| Validation | No inputs. |
| Success | Refresh dims and restores in place. No toast for a read. |

**Analytics motion**: one hover moves a **synchronised crosshair across all
three trend charts**, so identities, events and secrets are compared at the
same scan without three separate hovers. KPI tiles reveal a **sparkline of
that measure across scan history** on hover - only for the three measures scan
history actually carries. Donut segments lift on hover and the centre swaps to
the hovered category.

### 5.2 Identity explorer (`/identities`)

| Question | Answer |
|---|---|
| Primary goal | Narrow 137 principals to the handful that are mine to fix. |
| Most attention | Identity name, then its status sentence. |
| Easiest actions | Facet toggles with live counts; row opens a drawer; copy-ARN on hover. |
| Progressive disclosure | Row - drawer overview - drawer tabs, each fetched on first open. |
| Fewer clicks | Single-parameter view presets; facet counts sized before applying. |
| Complex data | ARNs truncated at the resource segment with full value on hover; posture as a sentence. |
| No data | "None in this scan" and "none match these filters" are different states with different actions. |
| Loading | Column-matched row skeletons; a filter change dims rows instead of collapsing the table. |
| API failure | Full-panel error with retry. |
| Validation | Search cannot fail. |
| Success | Read-only screen. |

### 5.3 Credential register (`/credentials`)

Goal: **decide what to rotate.** The redesign is built around credential age,
which the previous version buried.

- **KPI strip**: total credentials and distinct types from the summary; counts
  per severity from four exact count queries (§4).
- **Severity distribution** as a proportional bar with drill-through, so the
  rotation queue is visible before any filtering.
- **Age column** - days since `created_at`, with a bar scaled against the
  oldest credential in view, because "how overdue is this" is the question.
- **Last used** as relative time over the consuming service, answering "is
  anything still calling it".
- Facet rail: credential type (summary counts), severity (exact counts).
- Row action: copy credential id. Drawer: full record plus its holder.
- Empty states distinguish "no credentials in this scan" from "none match".

### 5.4 Secret-backed identities (`/secrets`)

Goal: **the identities where a leaked secret grants working access.** The
`/api/secrets` endpoint accepts only a search term, so this screen reads
`/api/identities` with `is_secret=true` **locked on** - the same records, with
the full facet vocabulary available for refinement. The lock is shown as a
non-removable chip so the scoping is never invisible.

- **Cross-section KPIs from exact count queries**: secret-backed *and* admin,
  *and* without MFA, *and* stale. Those intersections are the actual risk, and
  the API supports every combination in one request.
- Table: the identity row design, with status.

### 5.5 Code exposure (`/exposure`)

| Question | Answer |
|---|---|
| Primary goal | Triage leaked secrets, clear the noise. |
| Most attention | Risk tier and detector, then repository and author - who fixes it. |
| Easiest actions | Platform tabs, risk facet, row menu with "Open in AWS/GitHub" - the fix is always in the source system. |
| Progressive disclosure | Row - drawer; the dismiss form appears only after intent and needs a second confirm. |
| Fewer clicks | Grouped "by push" view, because one commit routinely leaks several secrets. |
| Complex data | Whole live set arrives in one response, so sort/filter/group are client-side - the only place sorting is honest. |
| No data | Positive state, with a link to the dismissed view so zero is never ambiguous. |
| Loading | Metric strip and table skeletons. |
| API failure | 401 - "not configured", naming the env var. Network - proxy diagnosis. |
| Validation | Reason optional, length-capped; the four identifying fields are copied verbatim. |
| Success | Optimistic removal, one toast naming the file, and where to restore it. |

### 5.6 Dismissed findings (`/exposure/dismissed`)

Goal: **audit what was accepted, and undo mistakes.** Previously a bare table.

- **KPI strip** computed from the full allowlist the service returns: entries,
  distinct detectors, distinct reviewers, oldest entry. All exact - the whole
  set is client-side.
- **Facet rail**: detector, reviewer, and whether a reason was recorded -
  because an entry dismissed with no reason is the audit risk.
- **Two views**: a table, and a **review timeline** grouped by dismissal day,
  which is how an auditor reads this.
- Restore stays a confirmed action, and states the service's own caveat: the
  finding returns only if the scanner still holds the record.

### 5.7 API activity (`/activity`)

Goal: **what did these identities actually do.** 

- **Scan-level totals** from the scan record (exact), never derived from a page.
- **"Shape of recent activity"** panel over the loaded window, labelled with
  the window size, splitting mutating from read-only and naming the top event
  sources. Page-scoped and *said to be* page-scoped.
- **Two views**: a dense table, and the event **timeline**, which is the better
  read for a single identity's history.
- Exact-ARN filter, labelled as exact, because a partial value silently
  matches nothing. Arriving from an identity's Activity tab fills it in.

### 5.8 Discovery scans (`/scans`)

Goal: **pick the snapshot, and see what changed.**

- **Change since the previous scan** - identities, events, secrets - computed
  from the ordered scan list. Real arithmetic on real records, and the most
  useful thing this endpoint can say.
- **Trend** across completed scans, as small multiples.
- Table: status, totals, duration, delta, and the scope action.
- Selecting a scan here is the same action as the context-row switcher: one
  source of truth for scope.

### 5.9 My resources (`/my-resources`)

Goal: **what is mine, and what is wrong with it.**

- Count from the endpoint's own `total_count`; composition **in view** by
  classification, explicitly labelled.
- Status column, so the screen answers "what is wrong with mine" rather than
  only listing them.
- Empty state explains that ownership is resolved from tags and CloudTrail, so
  the fix is tagging - not a setting in this product.

### 5.10 Sign-in (`/login`)

Navy canvas edge to edge, credential card floating on it at the right. Not a
split layout.

| Question | Answer |
|---|---|
| Primary goal | Get in, first attempt. |
| Most attention | Two fields and the submit button. |
| Easiest actions | Username auto-focused; Enter submits. |
| Progressive disclosure | Nothing to disclose - two fields. |
| Fewer clicks | No "remember me", no SSO, **no password reset**: no endpoint backs any of them. |
| Loading | Button pending; form interactive-disabled, not replaced. |
| API failure | The service's message surfaced; password cleared, username kept. |
| Validation | Inline per field on submit, `aria-invalid` plus described error, never colour alone. |
| Success | Navigation is the confirmation. |

---

## 6. Motion inventory

Every animation has a stated job. Anything that could not earn one is absent.

| Motion | Job | Duration |
|---|---|---|
| Panel stagger on mount | Establishes reading order | 420ms, 55ms step |
| Metric count-up | The number was just computed; re-runs when scope changes | 620ms |
| Meter / proportion grow | Reads as a measurement being taken | 900ms |
| Donut sweep, segment lift on hover | Connects legend row to slice without a click | 720ms / 160ms |
| **Synchronised trend crosshair** | One hover compares three measures at the same scan | instant |
| **KPI sparkline reveal** | Adds history to a headline number, where history exists | 240ms |
| Row hover accent and action reveal | Confirms the hit target without permanent clutter | 100ms |
| Sliding tab indicator | Shows which sibling view you moved to | 260ms |
| Drawer slide, backdrop blur | The list is still there behind it | 340ms |
| Refresh dim | Distinguishes background refresh from first load | 200ms |

All disabled under `prefers-reduced-motion`; none blocks input.

---

## 7. Deliberately absent

- **Notifications, alerts, assignment, comments, tickets** - no endpoints.
- **Bulk actions** - the API has one write, on a single allowlist entry.
- **Server-persisted saved views** - nowhere to persist them.
- **Sorting on server-paginated tables** - would sort one page and imply a
  global order.
- **Password reset, remember-me, SSO** - no endpoints.
- **A numeric risk score or grade** - unsupported, and dangerous if invented.
- **Bulk export** - no export endpoint, so the control says "Export page" or
  "Export view" and means it.
- **Mutating-vs-read-only totals for the whole scan** - no filter exists, so
  the split is shown only over the loaded window and labelled as such.

---

## 8. Revision: sign-in from measurement, toolbar from the design systems

Seven changes, each with the evidence that drove it.

### 8.1 The sign-in card went dark in Edge - and it was never an Edge bug

Reported as "Edge renders the right panel dark, Chrome renders it correctly".
Chrome was not correct; it was light-themed. The cause was in our CSS:

```css
/* before */
:root                  { --t-surface: #ffffff; /* light palette */ }
:root[data-theme='dark'] { --t-surface: #0c1626; /* dark palette */ }
```

The sign-in card carried `data-theme="light"` to opt out of theme inversion.
That did nothing. The light values existed only on `:root`, so there was no
rule for a nested `[data-theme='light']` to match, and the dark values
inherited straight through it. Anyone whose theme resolved to dark - Edge with
a dark OS, or our own Dark/System setting - got dark fields inside a white
card. Two fixes:

- The light palette is now declared for `:root, [data-theme='light']`, and the
  dark palette for `[data-theme='dark']` (no `:root` prefix), so either palette
  can be re-established on any subtree.
- Both blocks now declare `color-scheme`. Without it the UA picks form-control
  chrome from the OS preference, which is the *other* half of why Edge and
  Chrome disagreed. Declaring `color-scheme: light` on the card's subtree is
  what makes a browser paint light controls there regardless of OS.

The `dark:` variant is also scoped out of light subtrees, or `dark:hidden`
would still fire inside a card that is light in both themes.

Verified: with the root theme dark, the card is `rgb(255,255,255)`, the fields
`rgb(248,250,252)` and the ink `rgb(11,27,46)` - in light, dark and system.

### 8.2 The sign-in screen is measured from the supplied design, not eyeballed

Every colour was sampled and every size measured off the artwork:

| | Sampled / measured | Was |
|---|---|---|
| Canvas | `#0a192f`, flat - identical at top-left, centre and bottom | a 3-layer radial + linear gradient |
| Action button | `#1492c4`, flat - identical at both ends of its width | a cyan→blue gradient |
| Headline accent | `#53c9ed` | `--t-accent` `#12b0f0` |
| Body / trust text | `#94a3b8` (cool slate) | `#aec6df` / `#cfe0ef` (blue-tinted) |
| Card | `#ffffff` on a `#e2e8f0` border | white, borderless |
| Field fill | `#f8fafc` | `--t-surface` white |
| Link accent | `#1aa6d9` | - |
| Headline | 92px, line-height 1.08, 4 lines | 56px |
| Card | 620px wide, 54px padding | 416px wide, 32px padding |
| Action | 70px tall | 44px |
| Logo | tagline lockup, centred, 56px tall | wordmark, left-aligned, 30px |

Because the reference is a ~1894px rendering, every one of those is now a
`clamp()` against the viewport calibrated to hit the measured value at that
width - so the screen *is* the artwork at the artwork's size, and scales
down rather than being redrawn. Measured at 1894px: card 619px, action 70px,
headline 92px, badge 15px.

The decorative diagonal was removed: the reference canvas samples flat, so it
was invention.

**Both columns now start on the same line.** The grid was `items-center`,
which centres each column independently and is what pushed the statement below
the card. `items-start` with `content-center` aligns the tops and still centres
the pair vertically. Measured at 1894px: badge top 129px, card top 129px.

**Absent, deliberately.** The reference also shows "Forgot password?",
"Onboard Tenant" and "Try it now". There is no password-reset, tenant-signup or
demo endpoint anywhere in the API, and a dead control on a sign-in screen is
worse than a missing one. Colour, type, logo and layout were taken; the links
were not.

**Motion.** The page assembles in sequence rather than appearing at once:
badge → headline → body → trust marks → footnote, 80ms apart, 0.44s each, with
the card on its own slightly longer curve. The whole sequence finishes inside
0.8s, so it never delays a sign-in. Under `prefers-reduced-motion` both the
durations *and the delays* are zeroed - clamping only the duration would leave
a staggered item invisible for its delay.

### 8.3 Table tools: the controls were right, the presentation was wrong

The question was whether `Export page`, `Refresh`, `Compact` and `Comfortable`
belong in an enterprise product at all. They do - "comfortable" and "compact"
are literally Cloudscape's two density modes, and it *requires* a service to
offer a mechanism to choose between them and to persist the choice. What was
wrong is that ours sat in the open as four full-width controls.

Both Carbon and PatternFly give the same rule. PatternFly: *"No more than two
items should be exposed as buttons. If you have more than two items, use an
overflow menu component to save space,"* with secondary actions such as export
as icons. Carbon reserves the table toolbar for global table actions, caps it
at five, and moves the rest to an overflow menu. Cloudscape puts display
preferences behind collection preferences.

So, per screen: **Refresh** is an icon button. **Density** moved into a table
settings popover. **Export** moved into an overflow menu, where a disabled
entry still says why rather than vanishing. **View mode** (Findings/By push,
Table/Timeline) stayed in the open, because it changes *which records are
listed* - that is not a display preference.

Nothing lost a label, a tooltip, a keyboard path or an accessible name.

### 8.4 The filter rail closes

Filtering is a phase of work, not a permanent state. The rail header carries a
close control, the choice persists per viewer and across screens, and the
records take the freed width - the column is dropped, not just hidden, or
closing it would achieve nothing. Measured: table 1072px → 1318px. Applied
filters stay applied and stay visible as chips above the records, and the
reopen control carries the applied count, so a closed rail can never hide
active scoping.

### 8.5 Scan scope belongs in the top bar

It was in the context row, on the argument that it describes this screen. That
was wrong: changing it rescopes every screen in the product at once, which
makes it global state, and a console keeps global state in its global chrome -
the slot AWS gives its region selector. It now sits in the top bar beside the
account, styled against the top-bar tokens so it works on the light and the
dark bar. The context row keeps location, which is what a context row is for.

### 8.6 Chrome sized to be chrome

The bar was 56px with a 22px wordmark - a favicon in a strip. It is 64px with a
34px wordmark, and its controls are full 40px targets. The sidebar lost the rule
under the module name, and lost the "NHI" abbreviation it showed when collapsed:
collapsed, the rail is icons only, and an abbreviation is one more thing to
decode when the expand control already says what the rail is. The first group's
collapsed rule is suppressed too, or it would reinstate the same line.

Pagination's previous/next were 32px boxes around a 14px glyph - under the 40px
touch target every platform guideline asks for, on the most-clicked control of
a record screen. They are 40px boxes with a 17px glyph.

### 8.7 Large displays get a bigger console, not a wider void

On a 2560px monitor the console read as zoomed out: the container capped and
every control stayed at its 1440px size, marooned in whitespace. Widening the
container alone does not fix that - it just moves the controls further apart.

The root scales instead: `zoom` on `html`, 1.08 from 1800px, 1.18 from 2300px,
1.32 from 3000px, which enlarges type, controls and spacing together and holds
every proportion the design was tuned at. `zoom` is the only property that does
this without breaking fixed positioning; a transform would detach the fixed top
bar and the drawers from the viewport. The container cap moved 1640px → 1760px.

The factor is kept in `--app-zoom` so the sign-in screen can cancel it exactly
(`zoom: calc(1 / var(--app-zoom))`). It already scales itself through the
`clamp()`s in §8.2, and without the cancellation it was scaled twice - measured
669px against a 620px reference before the fix, 619px after.

### 8.8 My resources: yes, there is a real endpoint

`GET /api/dashboard/my-resources`, `routes.go:57` → `dashboard.go:43` →
`dashboard_service.go:29`. It takes the email from the JWT claims, paginates
with `page`/`page_size`, accepts `scan_id`, and returns the standard paginated
envelope of identities. The repository resolves ownership as:

```sql
LOWER(owner_name) = LOWER(:1) OR LOWER(primary_owner) LIKE LOWER(:2) OR LOWER(created_by_name) = LOWER(:3)
```

Two consequences the screen has to be honest about: there is no assignment
feature - ownership comes from resource tags and CloudTrail, so tagging is what
makes something appear - and the page can legitimately be empty for a real user
whose resources carry a team address rather than theirs. The empty state says
both.

---

## 9. Revision: stacking order, and a stranded tab indicator

### 9.1 Sign-in stacks statement first

Requested. Neither column carries an `order` override any more: source order is
statement then card, which stacks that way on a phone and reads left to right
on a wide screen. Measured at 390px: statement top 32px, card top 499px. At
1894px both tops are 129px, unchanged.

The card's entrance step is now `6` stacked and `2` side by side. Stacked it is
the last thing on the page, so a fixed step of `2` had the element at the
bottom of a phone screen animating before the ones above it.

Noted for the record, since it is a real cost: stacked this way, signing in on
a phone means scrolling past the whole product statement to reach the form.

### 9.2 The tab indicator sat under the wrong tab

Reported on the dashboard's exposure signals: selecting one navigates to the
filtered identities, and the underline was left between two tabs. Reproduced at
`/identities?without_mfa=true`, with "No MFA" active and the indicator sitting
short of it.

The indicator is measured from the active tab's `offsetLeft` and `offsetWidth`.
It was re-measured on `[measure, value, tabs.length]`, and on a `ResizeObserver`
watching the tab list. Both missed the thing that actually moves the tabs: the
counts arrive from the summary query *after* the first paint, and each count
that lands widens its own tab and shifts every tab after it. `tabs.length` never
changes, `value` never changes, and the list is stretched by its parent so its
own box never changes either - so the observer never fired and the indicator
kept its first-paint geometry.

Three fixes:

- The measurement is keyed on what the tabs render, not how many there are: a
  signature of each tab's value, label and count.
- The `ResizeObserver` observes every tab element, not only the list.
- A `document.fonts.ready` pass re-measures once web fonts land, which changes
  every text width with them.

Verified by comparing the indicator's box against the active tab's on every
preset tab of `/identities`, on `/exposure`, on a cold load, on a reload, and
after arriving from an exposure signal: `left` and `width` both match to 0px in
every case.

---

## 10. Revision: container-relative density, and two broken controls

### 10.1 The metric row was refusing space it already had

Reported as a type-size problem: at 100% browser zoom the four metric tiles
broke to two per row, and at 90% they fitted. Measured, the cause was a
breakpoint, not type.

The row was `sm:grid-cols-2 xl:grid-cols-4`, so four-up required a **1280px
viewport**. At 1279px the content column is already **999px wide** - room for
four 250px tiles with gaps. The layout was keyed to the window while the
constraint is the column, and the sidebar takes 232px of that window before the
grid sees any of it. Zooming to 90% only worked by pushing the viewport past
1280.

Shrinking every text size by 10% would also have worked, by accident, at the
cost of legibility on every screen. Instead the content column is now a
**query container** and the rows read `@min-[30rem]:grid-cols-2
@min-[54rem]:grid-cols-4`, so the column count follows the width the grid
actually has:

| Viewport | Rail | Content | Columns (before → after) |
|---|---|---|---|
| 1024px | open | 744px | 2 → 2 |
| 1024px | collapsed | 916px | 2 → **4** |
| 1180px | open | 900px | 2 → **4** |
| 1252px | open | 972px | 2 → **4** |
| 1280px | open | 1000px | 4 → 4 |

Note the second row: collapsing the sidebar now re-flows the metric row,
because the grid is measuring the space it was given. A viewport breakpoint can
never do that, at any value.

The tile itself also runs about 10% tighter - 27px number, 10.5px label, 14px
padding - since four in a row makes the uppercase label the thing that decides
how narrow a readable tile can be. That is the requested reduction, applied
where the crowding actually was rather than to every string in the product.

### 10.2 Sign-in entrance

Smoothness came from shape, not duration: travel cut to 8px so nothing appears
to fly in, an easing that settles without a late snap (`--ease-soft`), an
opacity ramp that completes at 60% of the movement, and 110ms steps against a
0.72s duration so the parts overlap into one settle instead of queueing. The
canvas fades up too, so the first frame is not a hard cut. `will-change` keeps
each part on its own layer, which is what removes the sub-pixel jitter on large
text.

The sidebar's "Identity & credential posture" subtitle is gone. The module name
is the label; the strapline underneath it was explaining the product to someone
already inside it.

### 10.3 The activity filter could not be used

`GET /api/events` takes `identity_arn`, `scan_id` and pagination. Nothing else,
and the ARN match is exact (`LOWER(TRIM(identity_arn)) = LOWER(TRIM(:1))`). A
free-text box against an exact match is unusable: nobody types a full ARN from
memory, so every attempt returned nothing and the filter read as broken.

The ARN is now chosen rather than typed. `IdentityPicker` lists the scan's
identities from `/api/identities` - an endpoint already in use, already scoped
to the selected scan - searches them client-side on name and ARN, and emits the
exact ARN the events endpoint requires. No endpoint gained a parameter and no
value is guessed. The trade-off is stated in the picker's own footer: it offers
the identities it has loaded, so on a very large account the search narrows a
page rather than the estate.

### 10.4 The timeline could only ever show page one

```jsx
{total > 0 && view === 'table' && <Pagination … />}
```

The pagination was gated on the table view, so switching to Timeline hid the
only way to reach page 2 - the remaining events were unreachable. The gate is
removed. Verified: Timeline now reads 1/10, and Next moves to 2/10 with
different events.

### 10.5 Sign out colours on hover

It is the one destructive action in the menu, so it takes the critical tone on
hover and on keyboard focus. Its resting state stays neutral: a permanently red
row in a profile menu reads as an error rather than an action. Measured:
`rgb(74,91,112)` at rest, `rgb(180,35,24)` on `rgb(253,236,235)` on hover.

---

## 11. Revision: the whole content area is container-relative

§10.1 fixed the metric row. The same fault ran through every other
multi-column layout in the product, and the clarification was right: the
composition should survive a narrowing window, with what is inside it getting
smaller, rather than re-flowing into a stack.

### 11.1 Nothing in the content area keys off the window any more

Converted from viewport breakpoints to container queries against the content
column:

| Layout | Was | Now |
|---|---|---|
| Metric row (8 screens) | `sm:` / `xl:` | `@min-[30rem]` / `@min-[54rem]` |
| Posture: signals + classification | `xl:` (1280px) | `@min-[52rem]` |
| Posture: credentials + trend | `xl:` (1280px) | `@min-[52rem]` |
| Posture: activity + exposure | `xl:` (1280px) | `@min-[52rem]` |
| Activity: window shape split | `lg:` (1024px) | `@min-[34rem]` (its panel) |
| Metric-row skeleton | `sm:` / `xl:` | matches the row it stands in for |

The skeleton mattered: it was still viewport-keyed, so the loading state showed
two columns and the loaded state four, and the page re-flowed the moment data
landed.

`Panel` is now a query container too. What a panel holds should respond to the
panel's width - a legend inside a 420px panel has no business consulting the
viewport - and the classification legend proves it: at a 1024px window it was
side by side with the donut and truncating every label to a single letter
("H 18", "S 17"). It now stacks the donut above the legend below `27rem` of
panel width, and the labels read in full at every width.

### 11.2 The content column scales on a narrow desktop

Keeping the composition is only half of it. Between `lg` and `xl` the content
column runs out of room before the window does, because the sidebar takes 232px
of it first. So the column scales: `--content-zoom` is 0.85 from 1024px, 0.9
from 1100px, and 1 from 1280px up, applied to the content wrapper only.

Two columns of slightly smaller panels beat one column of full-size ones, which
is what "decrease accordingly and fit" asks for. The scale is on the content
column alone - the top bar, the sidebar and every portalled overlay (drawer,
modal, toast, command palette) sit outside it, so nothing fixed is disturbed.
Because `container-type: inline-size` reports the scaled width, the container
queries inside see the extra room and hold their columns; the two mechanisms
compound in the same direction by design.

The one offset that has to know about it is the sticky facet rail, which hangs
below 104px of unscaled chrome: `top-[calc(104px/var(--content-zoom))]`.
Verified sticking at exactly 104px.

### 11.3 Result

Every multi-column row on every screen renders as one row at 1024px, 1252px and
1440px, in both sidebar states, with no horizontal overflow:

```
 1024 /posture:4/4 /credentials:1/1 /secrets:1/1 /exposure:1/1
      /dismissed:1/1 /activity:2/2 /scans:1/1 /my-resources:1/1
```

Checked for regressions from layout containment: every absolutely positioned
element inside a panel already had a `relative` parent, so no containing block
moved, and each popover was probed at three points with `elementFromPoint` to
confirm nothing paints over it.

**Known, not fixed:** on a short viewport the identity picker's list can extend
below the fold. It scrolls internally and the scan switcher has the same shape,
so it is a pre-existing pattern rather than a regression - but placing these
popovers against available space is still open work.

---

## 12. Revision: hierarchy, copy, rhythm, and popover placement

Acting on the audit in §5 of the review notes. Four of the five findings were
worth doing as written; one needed qualifying first.

### 12.1 What was not done, and why

The finding said six of nine screens are the same screen, and that the fix is
to design each for its task. That framing is half wrong. Consoles of this kind
repeat a list pattern deliberately - AWS Console, Datadog and Splunk all ship
near-identical record screens - because consistency across a register is what
makes the tenth screen free to learn. Rearchitecting six screens into six
archetypes trades learnability for novelty, and the honest version of it would
mean stripping the metric rows from list pages, which was explicitly asked for
and then reverted.

So the emphasis differentiates instead of the skeleton. Each screen names the
one panel that carries its work, and demotes the rest; the layout stays shared.

### 12.2 Prominence: one thing leads, the rest support

`Panel` and `PanelHeader` take a `prominence` of `lead`, `default` or `quiet`,
carried by surface, border, padding and title weight rather than by colour, so
the severity palette keeps its meaning.

| | Surface | Elevation | Padding | Title |
|---|---|---|---|---|
| `lead` | base | raised | 24px | 17px bold |
| `default` | base | none | 20px | 14.5px semibold |
| `quiet` | recessed | none | 16px | 13px semibold |

Posture went from six identical panels to one lead (Exposure signals - the
ranked work, every row drilling into identities), one default (Code exposure -
the other actionable queue) and four quiet (classification, credential surface,
trend, activity feed - all reference). On a record screen the table leads and
any analysis panel above it is quiet, which is the per-task differentiation
§12.1 describes.

Verified in both themes: lead 17px/700 raised on the base surface, quiet
13px/600 recessed, text contrast 15:1 and above throughout.

Recessing panels exposed a real defect: meter tracks were `surface-3` on a
`surface-2` panel, 10/255 apart, so the bars looked like they were floating.
Tracks are now `--t-track`, an ink wash at 20% (30% in dark), which holds the
same contrast on any panel. Pills and hover fills keep `surface-3` - they are
solid chips, not a backdrop a coloured bar has to read against.

### 12.3 The product stopped explaining itself

Nine pages each opened with a two-line paragraph, and thirteen panels carried a
subtitle. A screen that describes itself on every visit is documentation; an
operator reads it once and then it is furniture.

The rule applied: keep a line only where it states something the interface
cannot show - a constraint, a definition, or a consequence. Cut everything that
describes what the title already says.

Kept, shortened to the load-bearing clause:

- Secrets: "A leaked secret grants working access to every identity on this list."
- Dismissed: "Everything listed here is filtered out of live findings automatically."
- Findings: "Values are masked by the scanner, so rotate at the source."
- Scans: "Selecting a scan scopes every screen in the product to it."
- My resources: how "mine" is actually resolved, and that there is no assignment setting.

Cut: the posture, identities, credentials and activity ledes, and six panel
subtitles that restated their own titles. Kept in full: the two subtitles that
name an API limitation (my-resources has no filters beyond the scan; the events
endpoint cannot separate read-only from mutating), because those are the reason
a figure is scoped the way it is.

Ledes went from nine paragraphs of 150-200 characters to five lines of 48-70.
Seven decorative icons came off panel headers; icons that encode something - a
severity, a mode, a row type - stayed.

### 12.4 Spacing rhythm

One gap everywhere is what made the pages read flat. There is now a ratio:
**24px between sections**, 16px between columns within a section, 12px between
cards in a group. The eye gets a grouping cue instead of an even field.

### 12.5 Metric numbers are printed, not counted up to

`useCountUp` ran on every mount. An operator reads these figures dozens of
times a day and compares them against what they saw an hour ago; a 620ms
roll-up delays every read and leaves the digits unstable while it runs. It is a
first-impression effect on a screen nobody sees for the first time twice. The
hook is deleted, not just unwired.

### 12.6 Popovers are placed against the space available

Every dropdown opened downward at a fixed height, so a tall one on a short
window ran off the bottom and its last options were unreachable. `usePopover`
now measures the room below the trigger and above it, then either caps the
panel to what is there or flips it above the trigger when that is roomier. It
re-measures on scroll and resize, uses `visualViewport` where available, and
places the panel before paint so it never appears in the wrong spot.

Applied to all five: the identity picker, the scan switcher, table settings,
the overflow menu and the account menu. Each panel clips to its rounded corners
and scrolls internally, so a capped panel can never hide its last row - the two
flat menus were previously relying on their content happening to be short.

Verified at 620px, 760px and 900px viewport heights, at the top of a page and
scrolled to the bottom: every popover sits inside the viewport, and at 760px
the identity picker correctly flips above its trigger.

## 13. Revision: two features on generated data, and a rename

Two features were added - NHI Genome and Reports - plus a rename in the code
exposure group. The information architecture was taken from the reference
console; none of its design was.

### 13.1 The honesty problem, and where the boundary sits

Every previous phase held one rule: invent nothing the backend does not serve.
These two features have no backend. That rule was suspended for them, on
request, and the suspension is contained rather than quiet:

- All generated data lives under `src/lib/demo/`. No other module produces a
  figure the API did not send, so the boundary is a directory, not a habit.
- Both screens carry a `DemoBadge` in the page header - a labelled control, not
  a tooltip - which states plainly that the figures are generated in the
  browser, that they are seeded, and that actions persist locally.
- The demo layer mimics the real transport instead of short-circuiting it.

That last point is the load-bearing one. `demoRequest` is async, cancellable
through an `AbortSignal`, sets `error.code = 'CANCELLED'` on abort exactly as
the axios client does, and honours `dna.demo.latency` and `dna.demo.fail`
switches in `localStorage`. So the skeletons, empty states, error states and
disabled buttons on these two screens are the real ones, exercised under real
latency and real failure - not decoration that would collapse the day an
endpoint appears. When one does, only the module's fetchers change.

Data is deterministic: a mulberry32 PRNG seeded by `hashSeed(name)`, so the
fleet is identical on every reload and a screenshot taken today matches one
taken next week. A reporting screen whose numbers reshuffle on refresh teaches
an operator that the numbers do not mean anything.

Actions are real. Every mutation writes through a `localStorage` overlay and
publishes on an event bus; `useDemoQuery` subscribes, so acknowledging an
anomaly in the drawer updates the feed, the counters and the identity's own
timeline at once, and survives a reload. There is one `Reset demo` control per
feature, because state a user cannot clear is a trap.

### 13.2 NHI Genome: a baseline is only useful next to what broke it

A behavioural anomaly is a claim about a difference, and a screen that shows
only the anomaly is asking to be taken on faith. So the drawer puts the
baseline and the observed behaviour side by side, at equal weight, and names
both in words (`baselineStatement` / `observedStatement`) before showing either
as a chart.

Four visuals, all in `--t-series-1` rather than the severity palette, so a
colour never implies a verdict the data has not made:

| Visual | Answers |
|---|---|
| Fingerprint (radar, 6 axes) | how this identity behaves in shape, and where the peer group differs |
| Schedule grid (7x24) | when it works, with anomalous hours marked in the critical tone |
| Volume band | whether today's call volume sits inside the learned band |
| Ranked API share | what it calls, and what it has never called before |

Dispositions are three, not two: `Suppress`, `Expected` and `Acknowledge`.
A binary of dismiss-or-keep forces an operator to lie about a true-but-intended
departure, and `Expected` is the state that actually describes most of them.

The detail screen is six tabs - Genome, Anomalies, Activity, Timeline, Peer
group, Containment - with open departures banner-ed above the tabs, because a
tab is a place you have to think to visit. Containment shows the generated IAM
policy as its exact JSON in a preview modal before anything is applied: a
remediation screen that hides what it is about to do is worse than none.

### 13.3 Reports: a report you cannot read is a file, not a feature

A reporting feature whose only output is a download is a black box - you cannot
tell whether the figures are right without opening something else. So a run
renders in the product, section by section, and the CSV export is built from
exactly the rows on screen, through the same `lib/csv` helper the record
screens use. The file and the page cannot disagree.

Three tabs, in the order the work happens: Library (what can be produced),
Scheduled (what is produced without asking), History (what was produced). The
tab is in the URL, so a link points at a tab.

A run has real states - `queued`, `running`, `ready`, `failed` - and advances
through them on timers rather than appearing finished instantly. The seeded
history deliberately includes one failed run, and the failure reason is kept
with the run instead of discarded, because a report that failed silently is
worse than one that was never scheduled.

`ScheduleDialog` validates rather than merely collects: a schedule with no
recipients is a report nobody reads, and an hour outside 0-23 is not a time.
Errors appear per field on submit and clear as the field is corrected.

### 13.4 Findings became Exposed credentials

`Findings` names the tool's internal object, not the user's problem. Every
scanner in the category calls its output findings, which is precisely why it
carries no information. The group is now `Credential exposure`, with
`Exposed credentials` and `Accepted` beneath it, and the unit of count reads
`exposed credentials` throughout - titles, captions, empty states and the
dismissal screen.

`Accepted` rather than `Dismissed` for the second screen: dismissing describes
what the operator clicked, accepting describes the decision they made and now
own.

### 13.5 A chart that rendered nothing

The fleet trend painted a 104px recharts surface with no area and no line.
`TrendChart` reads `label` for its x axis; the generator emitted `day`. With
every category resolving to `undefined`, all fourteen points mapped to one
x coordinate and the monotone curve degenerated to an empty path - a silent
failure, since the chart still occupied its box.

Both daily generators now emit the shape the chart documents (`label` for the
axis, `subtitle` for the tooltip). Verified: area and line paths present, no
`NaN` in either path, ticks reading `Sep 8` through `Sep 21`, and the tooltip
showing the date in full.

The same pass fixed a cavern in `Baseline coverage`. The first attempt pushed
its closing note to the panel floor, which equalised the heights and left the
hole in the middle instead - the measurement said the panel matched its sibling,
and the screenshot said it was mostly air. Four figures are not half a row.

The row is now two panels stacked against one: coverage above the daily trend
on the left, departures by type on the right. The trend was previously buried
under that ranked list, which put two questions in one panel and gave the chart
104px; it now has its own title and 132px, and the column comes out level with
the list. Verified at 1440px, 1024px and 390px.

### 13.6 What a screenshot found that the tests did not

The interaction checks passed on figures that were nonsense. Reading the
rendered screens caught five defects no assertion was looking for:

- A new-region anomaly read `us-east-1 -> us-east-1`. The baseline region and
  the observed region were drawn from the same list by independent picks, so
  about one in five collided - and the drawer's whole purpose is to put two
  different things side by side. The region is now drawn once, excluding the
  identity's own, and feeds both the observed statement and the detail field.
  Audited across all 53 anomalies in the 30-day window: no identical pair.
- A report section could claim `Measure 4: 2,141`. Sections emitted two to four
  metrics but named only as many as their label list held, so the rest fell
  back to a placeholder. Sections now emit exactly the measures declared for
  them and the fallback is gone.
- Every figure came from one `intBetween(3, 2400)`, which produced a median
  remediation time of 1,647 days. Each measure now declares its own range, and
  the change is a share of the value rather than a fixed span, so `+34` cannot
  appear against a posture score of 62. File size follows from the row count
  instead of being rolled separately.
- The radar drew the observed shape in the critical tone. Being outside the
  baseline on two axes of six is not a six-way verdict, and the departures are
  named individually above it. Both radars now use two categorical hues
  (`--t-series-1` and `--t-series-4`) with dashes carrying the distinction
  without colour, and the same argument retired the critical tone from the
  peer-group divergence figures.
- The policy preview used the flask icon, which means demonstration data
  everywhere else in this build.

Two layout defects came from the same pass: template cards whose `Generate`
buttons sat on three different lines in one row, because a status pill wrapped
in the action row (the pill moved up into the facts, the action row pins to the
card floor); and a failed run whose reason was ellipsised in the table with no
link to the page that states it in full.

### 13.7 The drawer was not a query container

The anomaly drawer rendered with its baseline and observed cards stacked, its
detail labels sitting above their values, and its content flush to the panel
edges - the opposite of what the code asked for.

`Drawer`'s body was not a query container. Every `@min-*` rule inside a drawer
therefore matched nothing, so a 672px panel laid itself out as though it were
narrow, and the comparison this feature exists to show was not a comparison at
all. The body now declares `@container`, which is the honest reading anyway: a
drawer is a fixed slab that has nothing to do with the window, so what is
inside it must size against the panel. The anomaly drawer also supplies its own
`px-4 sm:px-5`, the same as the record drawers, since the body carries none.

Verified at 1600px, 1024px and 390px, in both themes, across all four drawers:
cards side by side above 26rem and stacked below it, labels and values on one
line, nothing outside the panel, no page overflow.

## 14. Revision: scanner enrichment, unlabelled demo screens, and a deployable image

Three changes: the Secret Scanner's additive response fields, the removal of
every demo marker from the two generated-data screens, and the container files
the app needs to be served anywhere but a dev machine.

### 14.1 Thirteen new fields, and the difference between two kinds of empty

The scanner's contract did not change shape. Same base URL, same five
endpoints, same authentication, no renamed or removed fields - `GET
/api/findings` simply returns thirteen more per finding. So nothing in the
transport needed touching; the work was deciding what each field is evidence
of, and what to say when it is absent.

Six of them are permanently null on CodeCommit, because CodeCommit has no
equivalent concept: `additions`, `deletions`, `repo_visibility`, `repo_stars`,
`repo_forks`, `repo_pushed_at`. The other seven are null only on findings
recorded before the enrichment existed. Those are different statements, and a
dash cannot tell them apart, so `missingFieldReason` makes the distinction once
in `lib/domain` and the drawer renders either "Not reported by CodeCommit" or
"Not recorded for this finding". An operator reading the first knows not to
wait for it; reading the second, they know a newer finding will have it.

What the fields earned in the interface:

| Field | Where, and why |
|---|---|
| `line_preview` | Its own block beside the masked value. "What does this code actually look like" is the first question a reviewer asks, and the answer decides fixture versus live credential. |
| `confidence` | The Assessment list, outside the severity palette. It is pattern-match certainty, not how bad the secret is; sharing a colour scale with `risk_tier` would conflate the two. Also a facet. |
| `category` | Assessment, and a facet - the most useful grouping the scanner has ever returned. |
| `commit_message`, `committer` | A "commit that introduced it" section. The committer gets a row only when it differs from the author, which is the case that tells you something (a rebase, a squash, a bot). |
| `commit_authored_at` | Same section, stated as when the commit was written rather than when it was found. |
| `files_changed` | Same section, with the caveat that on CodeCommit it counts what the scanner read and can undercount. The two platforms' numbers are never presented as comparable. |
| `additions` / `deletions` | Same section, as a single `+n / -n` figure. |
| `repo_visibility` | A "repository it sits in" section, and the only enrichment field carrying a tone: a secret in a public repository has been readable by anyone since the push, which is a fact about this finding rather than a guess. Private is stated neutrally, because private is the baseline expectation, not good news. |
| `repo_forks` | Same section, with a note when non-zero: a fork keeps its own copy of the history, so rotating beats deleting the commit. |
| `repo_stars`, `repo_pushed_at` | Same section, as plain context. |

`commit_authored_at` needed a parser rather than a formatter. It arrives in two
raw shapes, passed through exactly as each platform gave it: ISO 8601 from
GitHub, and git's own `1758454920 +0530` from CodeCommit. `new Date()` on the
second yields Invalid Date, so `parseCommitAuthoredAt` branches on the shape
rather than the platform - a finding can carry either. Verified against both,
plus a bare Unix timestamp, the `created_at` format, and a bogus string.

The whole of this was verified against the two findings the integration guide
captures verbatim, plus a third representing a new CodeCommit finding - a shape
the guide describes but does not show. Twenty-eight checks: every field
rendered where it should be, every platform-only field saying so, the git raw
timestamp parsed, the search reaching commit messages, and the three new facets
counting and filtering.

### 14.2 The demo markers came off

The two generated-data screens carried a `DemoBadge` in their header and a
"Reset demo" button. Both are gone, along with the component, at the product
owner's instruction: the product does not announce its own scaffolding to the
people being shown it.

That removes the visible half of the honesty argument in §13.1, so the code
half was strengthened to carry it alone. `lib/demo/runtime.js` now states that
the containment is structural: everything generated lives under `lib/demo/` and
is imported by exactly two feature folders, every generator is deterministic
and side-effect free, and every write goes to `localStorage` under a
`dna.demo.*` key. There is no path by which a generated figure reaches a live
screen, and none by which anything here touches a real endpoint.

Removing "Reset demo" left a real trap, which is worth stating plainly because
it was created by the removal rather than found: a mis-dispositioned anomaly
had no way back, so one wrong click removed a departure from the queue
permanently. The drawer now offers **Reopen** on a decided anomaly, and hides
the three dispositions while it does - re-offering the same decision beside its
own undo invites making it twice. Reopening deletes the overlay entry rather
than recording "open" as a decision, so the anomaly returns to exactly the
state the detector left it in, with no `decidedAt` implying somebody decided it
was open. That is ordinary product behaviour, not demo scaffolding: an operator
who mis-triages needs an undo whatever the data source is.

Both `resetGenomeDecisions` and `resetReportState` were deleted with their
buttons rather than left as unreferenced exports.

### 14.3 Search and export

Both features now carry the same pair the record screens do.

On the genome feed the search term lives in the URL alongside the facets, and
filters the rows **without** touching the facet counts. That asymmetry is
deliberate: a rail whose numbers move as you type cannot be used to navigate,
so the counts keep describing the window while the grid describes the search.

Reports takes one search box rather than three, because a schedule and a run
are searched by the same words - the report's name - and three boxes would be
three states to keep straight for one question. The placeholder names the tab
it will narrow, since "Search" alone leaves the operator guessing. Each tab
distinguishes "nothing matched" from "nothing here yet", which are different
answers needing different next steps.

Export follows the rule already established on the record screens: it writes
the view in front of you, filtered the way it is filtered and in the order it
is shown. An Export that quietly returned the unfiltered set would be a
different answer to the one the operator was looking at. On Reports it exports
the open tab - catalogue, schedules or history - and the history export keeps
the failure reason column, because a run that failed is the row most worth
having in a spreadsheet.

### 14.4 The Scheduled tab starts empty

It was seeded with three schedules. It now starts empty and fills only from
what the user creates.

An empty Scheduled tab is not a dead end, unlike an empty History: it is the
accurate answer to "what is produced without anyone asking", and the empty
state points straight at the control that changes it. Seeding it also claimed
that someone had configured delivery to recipients who never agreed to receive
anything.

One consequence had to be followed through: the seeded history included runs
marked "Produced on a schedule", which contradicts an empty Scheduled tab on
the screen next to it. Every seeded run is now a manual one. The Library's "On
a schedule" pill was already derived from live schedules rather than stored on
the template, so it correctly shows nothing until the first schedule exists,
and appears on exactly the right card afterwards - verified both ways, and
verified that deleting the last schedule returns the tab to its empty state and
the Library to unmarked.

### 14.5 Dockerfile, nginx, and the key that must not travel

The app had no way to be served outside a dev machine, and the production half
of the `X-Dashboard-Key` story had been a comment in `vite.config.js` since it
was written: *"the same responsibility has to be taken over by a real backend
route or reverse proxy in production"*. This is that reverse proxy.

Two stages. Node builds the bundle; nginx serves 24 static files. Nothing
crosses from the first stage but `dist`, so `node_modules`, the lockfile and
any local `.env` never reach a running container - `.dockerignore` keeps the
last of those out of the build context entirely.

The key is supplied at **run** time and never at build time. There is
deliberately no `ARG` for it: a build argument is recorded in the image history
and readable with `docker history`, so a key passed that way is a published
key. nginx's own template mechanism substitutes it into the config at container
start, with `NGINX_ENVSUBST_FILTER` restricting substitution to four names so
nginx's own `$uri`, `$host` and `$proxy_host` survive untouched. The build
additionally **fails** if `X-Dashboard-Key` appears anywhere in `dist/`, since
that could only mean client code was trying to send it itself.

Three bugs were found by running the thing rather than reasoning about it, and
they are the reason this section exists:

1. **`set` after `rewrite ... break` never executes.** `set` runs in the
   rewrite phase and `break` ends that phase, so `$scanner_upstream` arrived at
   `proxy_pass` empty and every scanner call returned 500. The order is now
   `set`, then `rewrite`, then `proxy_pass`, with a comment saying why.
2. **`listen [::]:8080` makes nginx refuse to start** on a host without IPv6,
   which includes many container runtimes. Dropped: a container bound to
   0.0.0.0 is reachable in a dual-stack network anyway, because the runtime
   maps the published port.
3. **`add_header` does not inherit into a location that declares its own.**
   Every location setting a cache header would have silently served no security
   headers at all. The headers live in `nginx/security-headers.conf` and are
   included in the server block and in each such location.

Two more things that would have broken on first run: `/etc/nginx/conf.d` is
chowned to the `nginx` user, because the image's entrypoint writes the
substituted template there and cannot do so as a non-root user; and `expires`
was removed where an explicit `add_header Cache-Control` already existed, since
`expires` emits its own and the header was being sent twice.

Beyond that, what the config does and why:

- **`/secret-scanner/*`** strips the prefix and attaches the key. The header is
  *set*, not forwarded, so a client-supplied `X-Dashboard-Key` is overwritten -
  nobody reaches the scanner through this service with a key of their own
  choosing. The app's bearer token and cookies are stripped, because forwarding
  credentials to a third party with no use for them is how they end up in
  somebody else's logs.
- **`/api/*`** forwards path, query string and the browser's own bearer token
  unchanged.
- **Everything else** is the SPA, with `index.html` as the fallback so a deep
  link survives a hard refresh, `assets/` cached for a year as immutable
  (fingerprinted filenames make that safe), `brand/` cached for an hour with
  revalidation, and `index.html` never cached, since it is the document naming
  which bundle to load.
- **`connect-src 'self'`** in the CSP is load-bearing rather than decorative:
  both APIs are reached through this server on same-origin paths, so a bundle
  that tried to call an external API directly - including the scanner, with a
  key someone had embedded in the client - would be blocked by the browser
  before the request left.
- **`/healthz`** is answered by nginx alone. It reports whether the web tier is
  serving, which is what a liveness probe asks; whether the APIs are reachable
  is a different question the app already answers on screen rather than by
  failing to start.

Both upstreams are addressed through variables so nginx resolves them per
request instead of at startup - otherwise a compose stack whose API container
had not come up yet would stop the web tier from booting at all.

Verified by running nginx 1.24 against the substituted config with a stub
upstream that echoes back what it was given: 26 checks covering the prefix
strip, the injected key, an overwritten client-supplied key, stripped
credentials, POST and DELETE reaching the scanner, path and query preserved on
the API, five deep links falling back to the shell, a missing asset returning
404 rather than the shell, gzip, exactly one `Cache-Control` header per
response, security headers surviving in every location, and dotfiles refused.

There is no Docker daemon in the environment this was built in, so the image
itself has not been built. The nginx configuration it copies in has been run;
the Dockerfile has not.


## 15. Revision: the access graph, rebuilt on React Flow

The first version of this screen was wrong in a way worth recording, because
the reason it was wrong is measurable rather than a matter of taste.

### The palette was provably unreadable, not merely ugly

The first draft coloured nodes by kind: eight hues for entry point, federated
principal, service principal, identity, credential, resource, account and
policy. A node-link diagram is an **all-pairs** form - panning and expanding
puts arbitrary nodes side by side - so every pair of hues has to separate, not
just the pairs that happen to be adjacent in a legend.

Run through the palette validator, the app's own severity hues fail that test
outright:

```
The four severity hues as node fills   FAIL - high vs medium 1.6 (deutan), 8.2 normal
Three hues (accent, caution, critical) FAIL - critical vs caution 14.4 normal, below the 15 floor
Two hues (accent, critical)            PASS - 23.8 CVD, 31.6 normal light; 19.2 / 29.0 dark
```

(OKLab Delta E x100. The measurements are recorded in
`src/features/access/graphTheme.js` beside the code that uses them.)

So the graph spends colour on **two** roles and nothing else:

- **Neutral** - a node with nothing wrong with it. Most of them.
- **Risk** (`--t-graph-risk`) - an entry point, an administrator-equivalent
  identity, a crown jewel, a stale credential, or a publicly exposed policy.
  One hue, reserved, so red on this canvas always means the same thing.

Kind is carried by an **icon plus a word** under the name. That is slower to
read than colour for one node and faster for a screen full of them, because a
colour legend with eight entries is a lookup table the reader has to hold in
their head.

The dark mode risk red is its own value rather than the app's `#f2837a`: that
step is OKLCH L 0.731, above the 0.67 ceiling for a mark on a dark surface, so
it reads as pink at small sizes. `--t-graph-risk: #d03b3b` sits inside the
band and still separates from the accent by Delta E 19.2 under deuteranopia.

### Identities and credentials are not enough to build a graph

The brief asked whether the identity and credential inventories were sufficient
input. They are not, and the gap is structural rather than a matter of volume:
**an inventory supplies nodes and no edges.** A list of principals and keys
says what exists; it says nothing about what can reach what.

Modelled on Cartography's AWS schema and on the permission-relationship
evaluation that tools like PMapper perform, the graph needs twelve inputs. All
twelve are listed on the screen itself, under the info button beside the focus
picker, tagged Collected or Not yet - so the analyst knows the graph's coverage
rather than assuming completeness:

| Input | What it contributes |
|---|---|
| Principals | the identity nodes |
| Credentials | keys, and their age |
| Identity policies | permission edges to resources |
| Trust policies | who may assume what - the pivot edges |
| Group membership | inherited permissions |
| Resources | the target nodes |
| Resource policies | access granted from the other side |
| Instance profiles | the compute-to-role edge |
| Observed usage | CloudTrail plus Access Advisor: which edges are real |
| Organisation structure | account boundaries, and what crossing one means |
| **Guardrails** | SCPs and permission boundaries - **not yet collected** |
| **Identity provider** | Identity Center assignments - **not yet collected** |

The last two are marked honestly. Without SCPs and permission boundaries the
graph over-states reach, because a policy that grants an action may be capped
by a boundary the graph cannot see. Saying so on the screen is better than a
graph that looks authoritative and is not.

### It opens almost empty, on purpose

Ninety nodes drawn at once is a hairball, and a hairball is read as
decoration. The screen follows Shneiderman's overview-first sequence and the
degree-of-interest tree approach from Card and Nation: keep the drawn graph
inside a fixed budget, and **represent** what was left out rather than dropping
it.

- The graph opens on **one focus node and its first hop**, and auto-opens the
  single most interesting first-hop neighbour so it arrives with a shape rather
  than as two boxes and a line.
- Each expansion shows the **three** most interesting neighbours of that node
  (`VISIBLE_PER_GROUP`) and folds the rest behind a dashed pill: `+6`, plus the
  kinds behind it, so the reader can tell whether opening it is worth a click.
- Clicking the fold reveals **two more** (`REVEAL_STEP`), not all six. The
  graph grows at a pace the eye can follow.
- Interest is scored, not arbitrary: on a critical path +50, an entry point
  +40, administrator-equivalent +30, a crown jewel +22, a stale credential +20,
  a public policy or on any path +18, federated +14, and a policy node -8.

### Row stability, and why it matters more than tidiness

`hopLayout.js` assigns one column per hop and feeds the **previous** layout's
row assignment back in, so a node on screen before an expansion keeps its row
after it. A layout that reflowed on every expansion would make the reader lose
their place, and a reader who loses their place stops expanding.

The guarantee is the **row index**, not the absolute coordinate: every column
is centred against the tallest one, so a column that grows shifts the shorter
columns down by half the difference. That shift is absorbed by the refit, which
animates over the same 420ms; a row shuffle would not be. Fourteen layout
checks cover no-overlap at 2, 6, 18 and 40 nodes, determinism, row assignment
and within-column order across an expansion, fold placement below its column,
the card metrics, and the empty graph.

### One click, in the right place

Expansion was a double-click in the first draft. That was wrong twice over:
React Flow v12 never delivers `onNodeDoubleClick` for a custom node type -
verified by instrumenting the handler, which logged three `nodeClick` events
and no double-click - and a chevron that must be double-clicked is a control
nobody finds. Now the chevron is the expand target (`data-expand`, with its own
hover state) and the rest of the card selects. Keyboard users get the same
action from the panel's Open/Collapse button.

The focus node has **no** chevron: it is always open, and its hidden
neighbours are behind the fold instead. A control whose click changes nothing
is worse than no control.

### Full screen, two ways

The real Fullscreen API on the graph's own element, because an analyst tracing
a six-hop path wants the whole window. The API is refused inside some embedded
frames, so a rejected promise falls back to a fixed overlay that looks the same
and needs no permission. `fullscreenchange` keeps the two in step; Escape
leaves the fallback, and the browser handles Escape for the native case.

### Legibility beats fitting

Three columns of 304px cannot fit in a 390px viewport at any zoom worth
reading. Below that threshold the auto-fit stops shrinking and starts cropping:
it fits the focus and its first hop only, so a phone opens on the node the
reader asked for and pans right for the rest. The floor is `MIN_FIT_ZOOM 0.7`.

### What was removed

- **The KPI cards.** A count of principals or edges is a fact about the
  dataset, not the account. It changes nothing anybody does next, and four of
  them across the top pushed the graph - the only thing on the screen that
  answers a question - below the fold.
- **Choke points.** Asked for and removed. Blast radius, attack paths and hop
  distance stayed, because those three are what turn "here is your graph" into
  "here is the issue and here is what happens".
- **The hand-rolled SVG canvas.** It got zoom space wrong on large displays:
  `getBoundingClientRect` is multiplied by the app zoom and SVG user units are
  not, so at 1800px and above the layout over-scaled by that factor and pushed
  a third of the graph outside the frame. React Flow owns the viewport now, and
  that class of bug with it.

### Attack paths are rows, not a table

A path is a sequence, and a table forces a sequence into one cell where it gets
truncated - which is how the previous version came to display
`token.actions.githubusercontent.com -> session-reaper-146 -> ...` and tell
nobody anything. Closed, a row carries severity and hop count, which is the
whole triage decision. Open, it numbers the steps and names the exact
permission combination for each escalation, because "privilege escalation
possible" is a claim nobody can check and `iam:PassRole + lambda:CreateFunction`
is one anybody can. The twelve escalation methods modelled are the documented
ones from the Rhino Security Labs set, which is the same set `pmapper preset
privesc` checks.

Below 34rem the row stacks - route on the first line, meta on the second.
Flex-wrap alone put the meta cluster on the first line and squeezed the route
to nothing, which at phone width left rows showing a hop count and no names at
all.

### All state is in the URL

Focus, what is expanded, what has been revealed, and which path is traced are
all query parameters, so a link reproduces exactly what somebody was looking at
when they asked a colleague to come and look.

### Verified

26 interaction checks against the running app: nodes and edges draw; no KPI
cards; no truncated node label; the panel reports real connection counts on
arrival rather than after the first click; the fold reveals two at a time; the
focus carries no dead chevron; the chevron expands and collapses; a card click
selects without expanding; hover dims the non-neighbouring edges and clears on
leave; tracing marks the path; the focus picker filters and redraws; the inputs
modal names the coverage gaps; full screen engages and exits with the layout
intact; and no console errors throughout. Eight viewport widths from 390px to
2560px, both themes, with no horizontal page scroll at any of them.

## 16. Revision: the findings model, and a logo rendered twice

Three things were wrong with the previous revision. One was a bug visible on
every page, one was a layout fault, and one was a design failure I should have
caught by asking what the screen was for rather than whether it worked.

### The brand lockup rendered twice below 640px

`BrandLockup` sets `inline-flex` on its own root and merges a caller's
`className`. The top bar passed `hidden sm:inline-flex`. `cn` is a plain join
with no Tailwind merge, so the element kept **both** `inline-flex` and
`hidden`: same property, same specificity, and the winner decided by the order
Tailwind happened to emit the two utilities in. `inline-flex` won, so below the
`sm` breakpoint the wordmark rendered alongside the compact mark that was meant
to replace it, at `y = -4` - overflowing the bar upward.

Measured before the fix, at 390px and 480px:

```
logo-lockup.png  display=block  visible=true   box=64,-4,153x34
mark.png         display=block  visible=true   box=64,36,32x32
```

Two fixes, because one of them is the class of bug rather than the instance:

1. The top bar now puts the display toggle on a **wrapper**, so no component's
   base class competes with it.
2. `cn` resolves the display group, last-wins. It is deliberately not a general
   Tailwind merge - that is a large dependency and a lot of behaviour to reason
   about - but `display` is the one group where a collision is silent,
   indistinguishable from working, and settled by stylesheet order.

A runtime audit across eleven routes at three widths found exactly one such
collision, so hardening `cn` changed the rendering of exactly one element.
Twenty-four other components put a display class in their own base and accept a
`className`; none of their callers currently pass a conflicting one, and now it
would not matter if they did.

### Attack paths were a query result, not analysis

The previous version listed every path the analysis found: twenty-six rows,
most reading "Unconditioned OIDC trust -> something". Nothing on a row said
what was wrong or what to do, and the reader had to notice for themselves that
six of those rows were the same mistake made six times.

Every enterprise tool that does this well groups first and counts second, and
the reason is not presentational - **the group is the unit of work, because one
fix closes all of its instances.** Rapid7's InsightCloudSec lists an attack path
by name with a severity and an instance count, and opens to a description, the
graph and generated remediation steps. BloodHound Enterprise calls the group a
finding and quantifies it as exposure and impact percentages, offering the same
findings as both a graph and a table with the filter and sort state kept in the
URL.

So the twenty-six paths are now **seven findings**, of two kinds:

- **Technique** - the path works because of a documented privilege-escalation
  method. The permission combination is the cause, so the finding carries it
  verbatim, and scoping it is the fix.
- **Grant** - nothing was escalated; the access was granted. The finding names
  what was reached, because the grant is the thing to change.

Each row carries four figures, with a header row to label them:

| Figure | What it answers |
|---|---|
| Paths | how many routes this one finding accounts for |
| Exposure | share of entry points that can start one of them |
| Impact | share of identities that sit on one |
| Hops | the shortest route in the group |

Exposure and impact are measured against the whole environment, not the
filtered set, so a figure means the same thing whatever the reader has filtered
to.

Opened, a finding gives what it is, the permission combination as code, the
counts that matter (reaches an administrator, reaches a crown jewel, crosses an
account), **how to close it** in its own column, and what closing it is worth:
"Closing this removes 6 paths." The instances are still there one level down,
because eventually somebody has to go and look at one, and each can be traced
onto the graph above.

### Filters, which the screen had none of

Four dimensions - severity, what the path reaches, what it starts from, and the
target account - as chips carrying the count each would leave. They stack, and
they live in the URL with the rest of the view state.

The counts come from the **unfiltered** set on purpose. A filter list whose
counts shrink as it is used cannot be undone without clearing everything, and
the reader loses the ability to see what a filter would cost before applying it.

Chips rather than dropdowns because four short lists fit, and a chip shows its
state without being opened.

### An entry point had no blast radius

`blastRadius()` is a permission-space calculation and only ever ran for
identities, so opening an entry point - the node an analyst is most likely to
start from - showed a connection count and nothing else. But "what does an
attacker get from here" is exactly the question an entry point is opened to
ask.

`fetchNode` now derives **reach** for any node that holds no policies of its
own, from the paths that start at it: identities on the way, how many are
administrator-equivalent, crown jewels, accounts, and the shortest hop count.
It is the same analysis the findings are grouped from, so the two agree.

### Layout: two heights, and one that follows the row

The canvas was a fixed 560px, which was wrong at both ends. On a phone that is
most of the screen spent on a graph needing a third of it, and it pushed the
panel explaining the graph out of sight. On a desktop the opposite: the empty
canvas is room to expand and pan into, and the panel beside it is frequently
taller, which left a band of empty page under the graph.

So there are two rules, switched in CSS because it is a viewport question:
below 768px the frame follows the drawn height, floored at 320px and capped at
68vh; from 1120px, where the panel moves beside the graph, the graph takes the
height of the grid row with the old fixed height as its floor.

### Two more phone faults

- **The focus node was clipped off the left edge** (`left: -10` at 390px).
  Three columns cannot fit at a readable zoom, and `fitView` always centres,
  which cuts both ends. The graph reads left to right, so the left edge is the
  anchor: where not even two columns fit, the viewport is set directly with the
  focus pinned 14px from the left and the overflow falling to the right, where
  panning is the obvious gesture. Measured after: `left: 14`.
- **The hop strip clipped a word**, rendering "2 hops" as "2 HOF". Three
  labels, the node count and two buttons do not fit in 364px. The strip now
  scrolls rather than hides its overflow, and the node count moves to the
  footer below 32rem, which is where the room came from.

### Export now carries the finding and the fix

A spreadsheet of twenty-six routes with no statement of what was wrong with any
of them is not actionable. The export is one row per path carrying its finding,
the service, the permission combination, exposure, impact, and the remediation
text - and it respects the filters, because the filtered set is what the person
exporting is looking at.

### One test that was passing without testing anything

The interaction suite's trace assertion was written as
`if (await trace.count()) { ... }`. Once the Trace buttons moved inside a
collapsed finding, the count was zero, the block was skipped, and the suite
reported no failure. A guard that skips silently is worse than a missing test,
because it looks like coverage. It now opens a finding first and fails
explicitly when no Trace button is reachable.

### What is actually failing in this environment

Worth recording, because it is not the frontend. Fourteen routes, deduplicated:

```
14x  502  /api/auth/me            no Go backend on localhost:8080 in this container
14x  502  /api/scans
 5x  502  /api/credentials
 4x  502  /api/dashboard/summary
 3x  502  /api/identities, /api/events
 4x  401  /secret-scanner/api/*   proxy reaches the real upstream, SCANNER_DASHBOARD_KEY is blank
15x       ERR_CERT_AUTHORITY_INVALID  Google Fonts, blocked by the sandbox TLS proxy
```

Zero uncaught page errors across all fourteen. Every one of the three is
missing infrastructure rather than a defect, and the app surfaces each as a
visible error state rather than failing: the "Scan list unavailable - retry"
chip in the top bar is the 401 and the 502 being reported honestly. The 401 in
particular is the security design working - the proxy chain reaches the scanner
and is refused for want of a key that was never in the bundle.

Because `/api/auth/login` is one of the 502s, there is no way to obtain a real
token here, so the screenshots are taken with a synthetic one in
`localStorage`. Every panel on the access graph is fed from `src/lib/demo`, so
the screen renders completely regardless - which is why it is the one screen
that can be assessed in this environment at all.

Fonts fall back to `ui-sans-serif, system-ui` and the layout is unaffected;
only the typeface differs from production.

### Verified

Twenty-seven graph interaction checks, thirty findings checks (grouping,
headers, four filter groups, filters applying and stacking in the URL,
clear-all, a finding's explanation and remediation and permission combination
and instance list, tracing from inside a finding, step expansion, the entry
point's reach, and the export's columns and row count), fourteen layout checks,
one logo check at five widths, a runtime display-collision audit over eleven
routes, and eight viewport widths from 390px to 2560px with no horizontal page
scroll and no overflow outside the graph canvas at any of them.

## 17. Revision: one estate behind every screen

This build has no backend. Every Go-API endpoint now serves generated data, and
the requirement that made it more than a stub was that **the screens have to
agree with each other**.

### Why it is one estate and not one fixture per screen

If the identity explorer invented its own rows and the credential register
invented different ones, an identity would own credentials that do not exist,
an event would name a principal absent from the list, and the dashboard's
totals would contradict the lists they link into. So there is exactly one
generated estate in `lib/demo/estate.js`:

| | |
|---|---|
| Accounts | 6, across production, staging and development |
| Identities | **228** - under 250 on purpose, a set a person can read |
| Non-human share | **83%** (189 of 228). Humans exist to be the owners |
| Credentials | 310, each belonging to a real identity |
| CloudTrail events | 1,069, each attributed to a real identity |
| Assume-role edges | 349 |
| Secret store entries | 161, each mapping to a real credential |

`lib/demo/api.js` serves it under the **same function names, arguments and
return shapes** as the real `lib/api/endpoints.js`, so `endpoints.js` delegates
and **not one screen changed**. Restoring the real API is one file.

The Secret Scanner is the exception and stays live: that service exists and is
reached through the proxy that attaches `X-Dashboard-Key` server-side.

### Counted, never written

No figure is a literal. Every total is `.length` of the same filtered array the
link beside it opens, which makes a class of demo bug impossible: the
dashboard's "admin-level access" count and the list behind it are the same
expression. Verified in the UI rather than only in the module - the posture
tile reads 36 and `/identities?is_admin=true` reports 36 of 228.

Nine such pairs are checked, plus that humans and non-humans sum to the total
and that both breakdowns sum to their totals.

### Names that read like something somebody deployed

Machine identity names are built from a workload and a function rather than
drawn from a word list, because `svc-ledger-writer`, `gha-deploy-payments`,
`agent-cost-optimiser`, `datadog-integration` and `eks-pod-checkout` are what a
real estate looks like and `nhi-042` is not. All 228 names and ARNs are unique.

Age and activity follow the identity's job: ephemeral identities are young and
busy, SaaS integrations old and quiet, CI/CD runs in bursts. That is what makes
"stale for 90+ days" mean anything.

### Two figures that were wrong, and how they were found

- **Half the estate was stale.** A uniform draw over each profile's idle range
  left 109 of 228 (48%) with no activity in 90 days, which reads as an
  abandoned account rather than a working one - and the point of the signal is
  that it picks out a minority worth acting on. Cubing the draw skews activity
  toward recent and leaves a long tail: 49 stale (21%), 40 inactive (18%).
- **Timestamps in the future.** The activity feed rendered "in 1 hour" and the
  snapshot strip "in 48 minutes". The estate pinned "now" to a literal instant
  while the relative formatters compare against the real clock, so every
  generated timestamp was measured from the wrong origin. The anchor is now
  `Date.now()` floored to the minute: offsets stay seeded and stable for the
  life of the page, and nothing is dated forward. Checked across eight screens
  for any "in N minutes/hours/days" outside a legitimate expiry context.

  The data fix was only half of it. `formatRelativeShort` rendered a future
  instant as a bare `1h` - not a shorter way of saying "in 1 hour", but a
  string indistinguishable from `1h ago` except by a missing suffix nobody
  reads as a signal. It is why the first sweep for future dates passed while
  the activity feed was visibly showing them, and in a list sorted by time it
  produced an order that cannot happen: `1h, 55m, 16m` followed by `6m ago`.
  The future form is prefixed now, so a clock skew or a bad timestamp is
  visible as one rather than passing for ordinary data. Verified by asserting
  the feed's WHEN column parses as a past duration on every row and is
  monotonically descending.

Also corrected: access key ids were `AKIA` plus twelve digits. Real ones are
twenty characters from an uppercase base-32 alphabet - close enough to pass a
glance and wrong to anybody who works with them daily.

### The dashboard trend, with the scans screen gone

The scans screen and the top-bar scan picker are commented out: there is one
discovery run behind these screens, so a list of runs and a picker to choose
between them are both controls with nothing to do. Four call sites are
commented together and cross-referenced, so reinstating them is one search.

But the dashboard's trend *is* a history of runs, and one row draws nothing. So
`fetchScans` serves fourteen daily runs converging on the estate as it stands:
the newest run's totals are the estate's actual totals, so the last point on
the chart is the number printed in the tile above it. 215 identities fourteen
days ago, 228 today.

### Sign-in

The credentials are pre-filled - `das.admin` / `Das123` - and focus lands on
the submit button, because with no identity provider behind the screen an empty
form is a guessing game. The fields stay editable and a wrong pair is still
rejected with a message, so the password field is a control rather than
decoration; a failure restores the working pair rather than clearing to empty.

### Pagination on the two generated screens

Both were rendering every matched row. Page and size live in the URL, and:

- Any change to *what* is being listed - a search, a facet, a tab - returns to
  page one. Narrowing the set while holding page seven lands on an empty grid,
  which reads as "no results" rather than "no seventh page".
- The page is **clamped to the last one that exists**. `?page=99` from a stale
  bookmark showed a blank grid with no explanation; it now shows the last page.
- The pager only appears once there is more than one page.
- `rows` stays the full matched set, so the count above the grid and the export
  beside it describe everything the filters matched, not the slice on screen.

The report run history was eight runs across seven templates, which is not what
a month looks like in a product anybody uses and left nothing to page through.
It is six weeks at a realistic rate - 46 runs - with failures distributed by
the seed rather than parked at a fixed index, and four different failure
reasons, because one repeated string reads as a placeholder.

### The code exposure drawer, in four tabs

Eight stacked sections in one column meant the repository's fork count - the
thing that decides whether deleting the commit is enough - sat four scrolls
below the value it applies to. Each tab now answers one question:

| Tab | Question |
|---|---|
| Overview | what is it, how certain is the match, how bad is it |
| Location & commit | where it lives and who put it there |
| Timeline | when it was written, found, and last touched |
| Raw match | the masked value and the line it sits on |

Nothing is duplicated between them, and a different finding opens on Overview
rather than on whichever tab the last one was left on.

**Timeline is new rather than rearranged.** Three timestamps already existed on
a finding; read as three rows of a table they were just dates. In order they
give the figure that was not on any screen before: **how long the secret sat
there before anybody knew.** 91 days, for the worked example - stated with why
it matters, which is that rotating the credential matters more than deleting
the commit. Events with no timestamp are omitted rather than drawn as dashes.

### A key collision the fixture exposed

Testing the drawer against a two-row payload surfaced a React duplicate-key
warning: the findings grid keyed rows on `row.finding_id`, a field **the
scanner API never returns**. Every row got `undefined`, React saw one
duplicated key for the whole list, and reconciliation fell back to index order
- so selecting a row after a dismiss could open its neighbour. The service's
own allowlist endpoints require `client_id`, `file_path`, `detector` and
`redacted` to identify a finding, which is the API telling us what the key is;
`findingKey()` is now shared by the grid, the dismiss set and the drawer. This
would have affected the live scanner, not just the fixture.

### Verified

31 estate-coherence checks (uniqueness, referential integrity in four
directions, nine dashboard-to-list agreements, pagination, determinism,
login accept and reject, lineage, consumers, my-resources, events); 9
timestamp checks plus a future-date sweep over 8 screens; 7 scan-history
checks; 13 sign-in checks; 20 pagination checks including the clamp and three
reset paths; 25 drawer checks including tab content isolation and chronological
order; 9 cross-page connectivity checks; and 4 access-key format checks.

## 18. Revision: one estate behind the graph too, and a full screen worth entering

### Two fields the drawer needed and the demo API did not supply

Both were reported as "always zero" and "blank", and both were contract
mismatches rather than missing data:

- **`owned_credentials`** is rendered by the drawer as a table and guarded with
  `Array.isArray`. The estate set it to a *count*, so the guard failed silently
  and every identity reported "Credentials 0" while the register listed 310 of
  them. It is the credential array now; `credential_count` carries the figure
  for the places that only want the number.
- **Service access** was a table of dashes. The drawer's column is "Target" -
  the far end of the relationship, whichever way it runs, with `direction`
  saying which. `fetchLineage` returned `caller_*` for both directions, so the
  Target column had nothing to read while the relationship and direction beside
  it were correct. It returns `target_name`/`target_type` now, and the edges
  carry the `via` and `source_ip` the Via and Consumers columns were built for.

### The graph is the same estate as everything else

The access graph used to generate its own: its own accounts, its own
identities, its own credentials. An identity opened in the explorer did not
exist in the graph, and the graph's principals appeared nowhere else - which
makes the screen look like a mock-up of a different product rather than a view
of this one.

It is now projected from `lib/demo/estate.js`:

- **Identities** keep the estate's ids, ARNs, names, accounts, admin flags,
  owners and event counts. Verified 64/64 matched by id, with names, ARNs,
  event totals, admin flags and owners agreeing.
- **Credentials** are the estate's own, and only the long-lived kinds become
  nodes - a short-lived federated credential is not something an attacker
  steals and holds. The node carries the register's severity, so the two
  screens rate the same credential the same way.
- **Accounts** are the estate's six.

Sixty-four of the 228, taken in the estate's own risk order: an all-pairs
reachability analysis over 228 principals produces tens of thousands of paths,
and the screen shows one focus and its first hop. Enough for the analysis to be
interesting, small enough to stay instant.

The genome fleet is the same change: 189 identities, which is exactly the
estate's non-human count. Baselines are about machine behaviour, so humans are
out - a statement about the screen rather than a shortcut. An identity the
estate says is too young to have a settled baseline is reported as still
learning, rather than that being a coin toss. The genome keeps its own
behavioural model (fingerprint, drift, peer group, anomalies), because the
estate has no concept of those; what it no longer keeps is its own idea of who
exists.

### Full screen now contains everything

The complaint was that the attack paths are below the graph, and in full screen
they cannot be reached at all. That is worse than an inconvenience: it makes
full screen a dead end you must leave to do anything, so the feature is only
usable for looking.

The pattern the literature settles on is a **docked, collapsible panel inside
the full-screen view** - panels stacked along an edge, opened and closed with a
single command, keyboard reachable and not trapping focus. So:

- The **details panel docks right**, open by default, collapsible.
- The **attack paths dock to the foot**, full width rather than a second side
  panel: a findings list is a column of rows and the graph is what needs the
  horizontal span. The toggle carries the finding count.
- Both panels are the *same elements* the page renders in its grid, declared
  once and placed in one of two arrangements, so the two cannot drift apart.
- Leaving full screen resets the docks, so entering it twice gives the same
  layout twice.

Verified end to end: a path can be traced from inside the bottom dock and the
graph marks it without leaving full screen.

### The two header controls were 32px glyphs

They are full-size secondary buttons now (40x38 measured). They were the only
controls on that strip, and the fullscreen button - the one people look for
first - read as decoration.

### Motion, drag, and a legend

- **Every edge flows at rest**, not only a traced one. An access graph is
  directional, and an arrowhead states that at one end of a line the eye has to
  follow; a slow drift states it continuously. Slow and low-contrast on
  purpose, since it runs on every edge at once. A traced path uses the same
  motion faster, so it stands out from the ambient drift.
  The dash travel is a whole number of dash periods - the first version
  animated to a fixed `-24px` against two different dash patterns, which made
  the pattern jump at every loop.
- **Nodes can be dragged.** `nodesDraggable` alone did nothing: React Flow is
  controlled here, and a controlled graph with no `onNodesChange` silently
  discards every drag. Hand positions are kept and merged over the layout, and
  cleared when the graph's shape changes - keeping them would pin two boxes
  where the reader left them and lay the new ones out around a hole.
- **A legend**, drawn as strokes rather than dots, because the difference
  between the three kinds is as much the dash pattern as the hue. A reader
  could see that some edges were red and dashed and nothing said that meant a
  documented escalation rather than "important".

### What the panel shows now

From the reference: observed behaviour as a nine-figure grid (events seen,
distinct actions, errors, reads, writes, regions, source IPs, relationships,
credentials), most-used actions, why the classifier decided what it decided
with the rules it matched, ownership, attached policies, and key hygiene.

Granted permission and observed behaviour are different kinds of fact, and the
gap between them is the argument for every least-privilege change - so the
panel carries both rather than only the policy side. The figures are counted
from the same CloudTrail sample the activity screen pages through.

Two of them were visibly generated on the first pass and had to be re-derived:
**distinct actions** came straight from the sampled events, reporting three
actions for an identity with six hundred calls, which is not a believable API
surface for anything; and the per-action counts split the total **evenly**,
printing three actions at exactly 209 each. Actions now scale with volume far
slower than linearly - a busy workload repeats a small vocabulary - and call
volume decays across the ranking. Same fix for the top services.

**Paths through it** listed one row per path, which printed the same entry
point four times when four routes shared it. Identical far ends collapse into
one row with a count, and Trace follows the shortest.

### Both columns bounded to one figure

The panel grew from four sections to eleven, and the graph was set to take the
height of the grid row - correct when the panel was short, wrong once it was
1,036px, which stretched the canvas to put five nodes in a screen and a half of
empty grid. Both are now capped by the same rule at the same breakpoint and
each scrolls its own overflow. A container query was wrong for the panel: the
graph's height is a viewport question, so a panel sized against its container
could disagree with it, and did.

### The operator, and what "mine" means

The signed-in operator is `cirm@admin` / `Admin`, with no team. That broke
"Assigned to me", which inferred ownership from the operator's team and went
empty. Inference was the wrong model anyway: the nav section is called
*Assigned to me*, and an assignment is a fact somebody records, not something
derived from an org chart. Twenty-four identities now carry an explicit
assignment, weighted toward the ones an administrator would actually be handed
- administrator-equivalent, unowned, stale.

Sign-in accepts three spellings of the operator - the account name, the email,
and the email's local part, which is what the form pre-fills. Narrowing it to
the account name would have broken the pre-filled form the moment the account
was renamed, which is exactly what happened.

### Verified

258 checks across eighteen suites, all green: 31 estate coherence, 17 drawer
credentials and service access, 12 graph-to-estate agreement, 13 genome-to-
estate agreement, 21 full-screen (docks, drag, animation, legend, tracing
without leaving), 19 inspector sections, 11 column heights, 20 pagination, 13
sign-in, 14 my-resources, 9 scans removal, 9 cross-page connectivity, 9
timestamp, 11 future-date, 14 layout, 7 observed-activity, 25 exposure drawer,
3 filter resets - plus four viewport widths with no horizontal scroll on nine
pages and no console or page errors.

## 19. Revision: the tabs, and the last of the graph's own data

Two questions, and the honest answer to both was "partly".

### What was still the graph's own invention

The previous revision moved identities, credentials and accounts onto the
shared estate and I reported that as done. Three things were still local, and
one of them was a visible contradiction:

- **Policy names.** The graph drew nodes called `PaymentsServiceAccess` and
  `LegacyWildcard` while the estate - and so the identity drawer, and this
  screen's own "Attached policies" list - used AWS-style names. The same
  identity had one set of policies in its drawer and a different set in the
  graph. Policy nodes are the estate's names now, deduplicated across every
  identity, and `managed`/`wildcardAction` are answered by the policy itself
  rather than a dice roll: `AdministratorAccess` grants everything by
  definition and `AmazonS3ReadOnlyAccess` does not.
- **Which policy grants what.** Resource access was attributed to a policy
  picked at random from the whole set, so the graph could claim an identity
  reached a bucket through a policy it does not hold. Every policy the estate
  says an identity carries is now an edge, and the access is attributed to one
  of those.
- **Regions.** The graph's own list included `us-east-2`, where no identity in
  the estate operates, so a resource could sit in a region nothing could reach
  it from.
- **External principals.** Every external trust was routed through one of three
  fixed principals, so a `datadog-integration` was drawn as trusted by Okta -
  a different claim about the environment, and a wrong one. Each identity's own
  `trust_service` now becomes its principal.

**What is still local, and why:** the resources - the S3 buckets, DynamoDB
tables and KMS keys the paths end at. The estate has no resource inventory at
all, and the graph needs targets for "what can this reach". That is a genuine
gap rather than a choice, and it is the one part of this screen whose nouns
exist nowhere else in the product.

### The tabs

The panel was a stack of sections, which worked while there were four. There
were eleven, and a 340px column holding all of them is a 1,200px scroll where
the thing you want is never the thing on screen. All ten tabs from the brief
now exist:

| Tab | What it answers |
|---|---|
| Summary | observed behaviour as nine figures |
| Access | blast radius, reach, connections, paths through it |
| Credentials | the credentials it holds, with age, last use and status |
| Key hygiene | long-lived keys and the oldest one |
| Trust & reach | who can assume it, via what, from where - and what that gets them |
| Behaviour | the genome's baseline, drift, risk score and open departures |
| Top events | most-used actions and busiest services |
| Policies | what it was granted |
| Ownership | owner, creator, assignee |
| Why classified | the evidence and the rules that matched |

A tab is hidden when the node has nothing to put in it - an entry point has no
key hygiene - so the row never offers a click that leads to "nothing here".
Verified both ways: hidden for an identity holding only secrets, present for
one holding a long-lived key.

**Credentials and Behaviour are new content, not rearranged.** The panel showed
a credential *count*; it now lists the estate's own records, matching the
register. And Behaviour reads the **genome's** model rather than computing one:
two screens with two different answers to "how does this identity normally
behave" would be worse than one screen with none. A human gets a statement
that baselines are for machine identities rather than an invented baseline.

### Three bugs the tabs exposed

- **The tab row could not wrap.** The app's `Tabs` is a single scrolling line
  with an absolutely positioned sliding indicator, so ten labels in a 340px
  column showed three and hid seven with no affordance. The panel uses a
  wrapping pill row - ten tabs across four rows, verified none clipped at
  390px, 768px or 1700px - still a real tablist with `aria-selected`, a roving
  tabindex and arrow keys.
- **Arrow keys moved from the selection, not the focus.** Tabbing to a tab and
  pressing an arrow jumped from wherever the selection happened to be, which
  is not where the reader's attention was.
- **The tab row scrolled away with the content.** With the whole panel
  scrolling, reading to the foot of a long pane took the tabs off screen, so
  changing tab meant scrolling back to find the control. The title and tabs are
  pinned; only the pane below them moves.

### Verified

41 tab checks (all ten present, each pane's content, no leakage between panes,
no clipping, keyboard movement, the hidden-tab rule both ways, real credential
ids, real API names, the genome figures matching the genome) and 12 graph-to-
estate consistency checks (policy names, attributed policies, regions, vendor
principals, credentials matching the register, the behavioural baseline
matching the genome exactly, and a human getting no invented baseline). Plus
the existing suites: 265 checks in total, four viewport widths with no
horizontal scroll on nine pages, and no console or page errors.
